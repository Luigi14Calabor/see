<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-30 01:58:00 --> Config Class Initialized
DEBUG - 2011-06-30 01:58:00 --> Hooks Class Initialized
DEBUG - 2011-06-30 01:58:00 --> Utf8 Class Initialized
DEBUG - 2011-06-30 01:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 01:58:00 --> URI Class Initialized
DEBUG - 2011-06-30 01:58:00 --> Router Class Initialized
DEBUG - 2011-06-30 02:00:55 --> Config Class Initialized
DEBUG - 2011-06-30 02:00:55 --> Hooks Class Initialized
DEBUG - 2011-06-30 02:00:55 --> Utf8 Class Initialized
DEBUG - 2011-06-30 02:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 02:00:55 --> URI Class Initialized
DEBUG - 2011-06-30 02:00:55 --> Router Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Config Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:29:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:29:12 --> URI Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Router Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Output Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Input Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:29:12 --> Language Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Loader Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Controller Class Initialized
ERROR - 2011-06-30 03:29:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 03:29:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 03:29:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:29:12 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:29:12 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:29:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:29:13 --> Helper loaded: url_helper
DEBUG - 2011-06-30 03:29:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 03:29:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 03:29:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 03:29:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 03:29:13 --> Final output sent to browser
DEBUG - 2011-06-30 03:29:13 --> Total execution time: 1.3164
DEBUG - 2011-06-30 03:29:14 --> Config Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:29:14 --> URI Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Router Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Output Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Input Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:29:14 --> Language Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Loader Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Controller Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:29:14 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:29:15 --> Final output sent to browser
DEBUG - 2011-06-30 03:29:15 --> Total execution time: 0.7594
DEBUG - 2011-06-30 03:29:43 --> Config Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:29:43 --> URI Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Router Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Output Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Input Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:29:43 --> Language Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Loader Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Controller Class Initialized
ERROR - 2011-06-30 03:29:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 03:29:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 03:29:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:29:43 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:29:43 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:29:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:29:43 --> Helper loaded: url_helper
DEBUG - 2011-06-30 03:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 03:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 03:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 03:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 03:29:43 --> Final output sent to browser
DEBUG - 2011-06-30 03:29:43 --> Total execution time: 0.0493
DEBUG - 2011-06-30 03:29:44 --> Config Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:29:44 --> URI Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Router Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Output Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Input Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:29:44 --> Language Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Loader Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Controller Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:29:44 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:29:44 --> Final output sent to browser
DEBUG - 2011-06-30 03:29:44 --> Total execution time: 0.4999
DEBUG - 2011-06-30 03:29:59 --> Config Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:29:59 --> URI Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Router Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Output Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Input Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:29:59 --> Language Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Loader Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Controller Class Initialized
ERROR - 2011-06-30 03:29:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 03:29:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 03:29:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:29:59 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:29:59 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:29:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:29:59 --> Helper loaded: url_helper
DEBUG - 2011-06-30 03:29:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 03:29:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 03:29:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 03:29:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 03:29:59 --> Final output sent to browser
DEBUG - 2011-06-30 03:29:59 --> Total execution time: 0.0295
DEBUG - 2011-06-30 03:29:59 --> Config Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:29:59 --> URI Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Router Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Output Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Input Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:29:59 --> Language Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Loader Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Controller Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Model Class Initialized
DEBUG - 2011-06-30 03:29:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:29:59 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:00 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:00 --> Total execution time: 0.5492
DEBUG - 2011-06-30 03:30:08 --> Config Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:30:08 --> URI Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Router Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Output Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Input Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:30:08 --> Language Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Loader Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Controller Class Initialized
ERROR - 2011-06-30 03:30:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 03:30:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 03:30:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:30:08 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:30:08 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:30:08 --> Helper loaded: url_helper
DEBUG - 2011-06-30 03:30:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 03:30:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 03:30:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 03:30:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 03:30:08 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:08 --> Total execution time: 0.0541
DEBUG - 2011-06-30 03:30:09 --> Config Class Initialized
DEBUG - 2011-06-30 03:30:09 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:30:09 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:30:09 --> URI Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Router Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Output Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Input Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:30:10 --> Language Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Loader Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Controller Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:30:10 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:15 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:15 --> Total execution time: 5.3958
DEBUG - 2011-06-30 03:30:22 --> Config Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:30:22 --> URI Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Router Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Output Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Input Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:30:22 --> Language Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Loader Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Controller Class Initialized
ERROR - 2011-06-30 03:30:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 03:30:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 03:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:30:22 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:30:22 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:30:22 --> Helper loaded: url_helper
DEBUG - 2011-06-30 03:30:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 03:30:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 03:30:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 03:30:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 03:30:22 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:22 --> Total execution time: 0.0320
DEBUG - 2011-06-30 03:30:23 --> Config Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:30:23 --> URI Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Router Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Output Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Input Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:30:23 --> Language Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Loader Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Controller Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:30:23 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:24 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:24 --> Total execution time: 0.7015
DEBUG - 2011-06-30 03:30:39 --> Config Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:30:39 --> URI Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Router Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Output Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Input Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:30:39 --> Language Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Loader Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Controller Class Initialized
ERROR - 2011-06-30 03:30:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 03:30:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 03:30:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:30:39 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:30:39 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:30:39 --> Helper loaded: url_helper
DEBUG - 2011-06-30 03:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 03:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 03:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 03:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 03:30:39 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:39 --> Total execution time: 0.0268
DEBUG - 2011-06-30 03:30:40 --> Config Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:30:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:30:40 --> URI Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Router Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Output Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Input Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:30:40 --> Language Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Loader Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Controller Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:30:40 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:42 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:42 --> Total execution time: 1.9781
DEBUG - 2011-06-30 03:30:48 --> Config Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:30:48 --> URI Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Router Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Output Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Input Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:30:48 --> Language Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Loader Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Controller Class Initialized
ERROR - 2011-06-30 03:30:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 03:30:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 03:30:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:30:48 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:30:48 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:30:48 --> Helper loaded: url_helper
DEBUG - 2011-06-30 03:30:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 03:30:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 03:30:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 03:30:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 03:30:48 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:48 --> Total execution time: 0.0295
DEBUG - 2011-06-30 03:30:48 --> Config Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:30:48 --> URI Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Router Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Output Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Input Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:30:48 --> Language Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Loader Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Controller Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Model Class Initialized
DEBUG - 2011-06-30 03:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:30:48 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:30:49 --> Final output sent to browser
DEBUG - 2011-06-30 03:30:49 --> Total execution time: 1.0080
DEBUG - 2011-06-30 03:32:59 --> Config Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Hooks Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Utf8 Class Initialized
DEBUG - 2011-06-30 03:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 03:33:00 --> URI Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Router Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Output Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Input Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 03:33:00 --> Language Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Loader Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Controller Class Initialized
ERROR - 2011-06-30 03:33:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 03:33:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 03:33:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:33:00 --> Model Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Model Class Initialized
DEBUG - 2011-06-30 03:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 03:33:00 --> Database Driver Class Initialized
DEBUG - 2011-06-30 03:33:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 03:33:00 --> Helper loaded: url_helper
DEBUG - 2011-06-30 03:33:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 03:33:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 03:33:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 03:33:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 03:33:00 --> Final output sent to browser
DEBUG - 2011-06-30 03:33:00 --> Total execution time: 0.0793
DEBUG - 2011-06-30 05:36:12 --> Config Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Hooks Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Utf8 Class Initialized
DEBUG - 2011-06-30 05:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 05:36:12 --> URI Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Router Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Output Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Input Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 05:36:12 --> Language Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Loader Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Controller Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Model Class Initialized
DEBUG - 2011-06-30 05:36:12 --> Model Class Initialized
DEBUG - 2011-06-30 05:36:13 --> Model Class Initialized
DEBUG - 2011-06-30 05:36:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 05:36:13 --> Database Driver Class Initialized
DEBUG - 2011-06-30 05:36:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 05:36:14 --> Helper loaded: url_helper
DEBUG - 2011-06-30 05:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 05:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 05:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 05:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 05:36:14 --> Final output sent to browser
DEBUG - 2011-06-30 05:36:14 --> Total execution time: 1.9722
DEBUG - 2011-06-30 05:50:42 --> Config Class Initialized
DEBUG - 2011-06-30 05:50:42 --> Hooks Class Initialized
DEBUG - 2011-06-30 05:50:42 --> Utf8 Class Initialized
DEBUG - 2011-06-30 05:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 05:50:42 --> URI Class Initialized
DEBUG - 2011-06-30 05:50:42 --> Router Class Initialized
DEBUG - 2011-06-30 05:50:42 --> Output Class Initialized
DEBUG - 2011-06-30 05:50:42 --> Input Class Initialized
DEBUG - 2011-06-30 05:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 05:50:42 --> Language Class Initialized
DEBUG - 2011-06-30 05:50:42 --> Loader Class Initialized
DEBUG - 2011-06-30 05:50:42 --> Controller Class Initialized
DEBUG - 2011-06-30 05:50:43 --> Model Class Initialized
DEBUG - 2011-06-30 05:50:43 --> Model Class Initialized
DEBUG - 2011-06-30 05:50:44 --> Model Class Initialized
DEBUG - 2011-06-30 05:50:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 05:50:45 --> Database Driver Class Initialized
DEBUG - 2011-06-30 05:50:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 05:50:45 --> Helper loaded: url_helper
DEBUG - 2011-06-30 05:50:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 05:50:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 05:50:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 05:50:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 05:50:45 --> Final output sent to browser
DEBUG - 2011-06-30 05:50:45 --> Total execution time: 4.1720
DEBUG - 2011-06-30 07:21:17 --> Config Class Initialized
DEBUG - 2011-06-30 07:21:17 --> Hooks Class Initialized
DEBUG - 2011-06-30 07:21:17 --> Utf8 Class Initialized
DEBUG - 2011-06-30 07:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 07:21:17 --> URI Class Initialized
DEBUG - 2011-06-30 07:21:17 --> Router Class Initialized
DEBUG - 2011-06-30 07:21:18 --> Output Class Initialized
DEBUG - 2011-06-30 07:21:18 --> Input Class Initialized
DEBUG - 2011-06-30 07:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 07:21:18 --> Language Class Initialized
DEBUG - 2011-06-30 07:21:18 --> Loader Class Initialized
DEBUG - 2011-06-30 07:21:18 --> Controller Class Initialized
ERROR - 2011-06-30 07:21:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 07:21:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 07:21:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 07:21:19 --> Model Class Initialized
DEBUG - 2011-06-30 07:21:19 --> Model Class Initialized
DEBUG - 2011-06-30 07:21:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 07:21:20 --> Database Driver Class Initialized
DEBUG - 2011-06-30 07:21:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 07:21:20 --> Helper loaded: url_helper
DEBUG - 2011-06-30 07:21:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 07:21:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 07:21:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 07:21:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 07:21:21 --> Final output sent to browser
DEBUG - 2011-06-30 07:21:21 --> Total execution time: 4.0516
DEBUG - 2011-06-30 10:07:15 --> Config Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:07:15 --> URI Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Router Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Output Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Input Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:07:15 --> Language Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Loader Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Controller Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:07:15 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Config Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:07:16 --> URI Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Router Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Output Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Input Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:07:16 --> Language Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Loader Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Controller Class Initialized
ERROR - 2011-06-30 10:07:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:07:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:07:16 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:07:16 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 10:07:16 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:07:16 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:07:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:07:16 --> Final output sent to browser
DEBUG - 2011-06-30 10:07:16 --> Total execution time: 0.2028
DEBUG - 2011-06-30 10:07:16 --> Final output sent to browser
DEBUG - 2011-06-30 10:07:16 --> Total execution time: 1.1250
DEBUG - 2011-06-30 10:07:21 --> Config Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:07:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:07:21 --> URI Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Router Class Initialized
ERROR - 2011-06-30 10:07:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 10:07:21 --> Config Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:07:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:07:21 --> URI Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Router Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Output Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Input Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:07:21 --> Language Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Loader Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Controller Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:07:21 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:07:22 --> Final output sent to browser
DEBUG - 2011-06-30 10:07:22 --> Total execution time: 0.6914
DEBUG - 2011-06-30 10:07:47 --> Config Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:07:47 --> URI Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Router Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Output Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Input Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:07:47 --> Language Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Loader Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Controller Class Initialized
ERROR - 2011-06-30 10:07:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:07:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:07:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:07:47 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:07:47 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:07:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:07:47 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:07:47 --> Final output sent to browser
DEBUG - 2011-06-30 10:07:47 --> Total execution time: 0.0305
DEBUG - 2011-06-30 10:07:49 --> Config Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:07:49 --> URI Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Router Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Output Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Input Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:07:49 --> Language Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Loader Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Controller Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:07:49 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:07:49 --> Final output sent to browser
DEBUG - 2011-06-30 10:07:49 --> Total execution time: 0.7716
DEBUG - 2011-06-30 10:07:55 --> Config Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:07:55 --> URI Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Router Class Initialized
ERROR - 2011-06-30 10:07:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-30 10:07:55 --> Config Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:07:55 --> URI Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Router Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Output Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Input Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:07:55 --> Language Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Loader Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Controller Class Initialized
ERROR - 2011-06-30 10:07:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:07:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:07:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:07:55 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Model Class Initialized
DEBUG - 2011-06-30 10:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:07:55 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:07:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:07:55 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:07:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:07:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:07:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:07:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:07:55 --> Final output sent to browser
DEBUG - 2011-06-30 10:07:55 --> Total execution time: 0.0306
DEBUG - 2011-06-30 10:09:41 --> Config Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:09:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:09:41 --> URI Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Router Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Output Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Input Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:09:41 --> Language Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Loader Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Controller Class Initialized
ERROR - 2011-06-30 10:09:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:09:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:09:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:09:41 --> Model Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Model Class Initialized
DEBUG - 2011-06-30 10:09:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:09:41 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:09:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:09:41 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:09:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:09:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:09:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:09:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:09:41 --> Final output sent to browser
DEBUG - 2011-06-30 10:09:41 --> Total execution time: 0.0924
DEBUG - 2011-06-30 10:09:44 --> Config Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:09:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:09:44 --> URI Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Router Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Output Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Input Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:09:44 --> Language Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Loader Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Controller Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Model Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Model Class Initialized
DEBUG - 2011-06-30 10:09:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:09:44 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:09:45 --> Final output sent to browser
DEBUG - 2011-06-30 10:09:45 --> Total execution time: 0.6682
DEBUG - 2011-06-30 10:09:50 --> Config Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:09:50 --> URI Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Router Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Output Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Input Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:09:50 --> Language Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Loader Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Controller Class Initialized
ERROR - 2011-06-30 10:09:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:09:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:09:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:09:50 --> Model Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Model Class Initialized
DEBUG - 2011-06-30 10:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:09:51 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:09:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:09:51 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:09:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:09:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:09:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:09:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:09:51 --> Final output sent to browser
DEBUG - 2011-06-30 10:09:51 --> Total execution time: 0.0305
DEBUG - 2011-06-30 10:10:00 --> Config Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:10:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:10:00 --> URI Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Router Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Output Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Input Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:10:00 --> Language Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Loader Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Controller Class Initialized
ERROR - 2011-06-30 10:10:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:10:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:10:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:10:00 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:10:00 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:10:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:10:00 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:10:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:10:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:10:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:10:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:10:00 --> Final output sent to browser
DEBUG - 2011-06-30 10:10:00 --> Total execution time: 0.0293
DEBUG - 2011-06-30 10:10:04 --> Config Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:10:04 --> URI Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Router Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Output Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Input Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:10:04 --> Language Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Loader Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Controller Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:10:04 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:10:04 --> Final output sent to browser
DEBUG - 2011-06-30 10:10:04 --> Total execution time: 0.4874
DEBUG - 2011-06-30 10:10:41 --> Config Class Initialized
DEBUG - 2011-06-30 10:10:41 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:10:41 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:10:41 --> URI Class Initialized
DEBUG - 2011-06-30 10:10:41 --> Router Class Initialized
DEBUG - 2011-06-30 10:10:41 --> Output Class Initialized
DEBUG - 2011-06-30 10:10:41 --> Input Class Initialized
DEBUG - 2011-06-30 10:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:10:41 --> Language Class Initialized
DEBUG - 2011-06-30 10:10:42 --> Loader Class Initialized
DEBUG - 2011-06-30 10:10:42 --> Controller Class Initialized
ERROR - 2011-06-30 10:10:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:10:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:10:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:10:42 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:42 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:10:42 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:10:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:10:42 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:10:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:10:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:10:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:10:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:10:42 --> Final output sent to browser
DEBUG - 2011-06-30 10:10:42 --> Total execution time: 0.4411
DEBUG - 2011-06-30 10:10:43 --> Config Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:10:43 --> URI Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Router Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Output Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Input Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:10:43 --> Language Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Loader Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Controller Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:10:43 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:10:45 --> Final output sent to browser
DEBUG - 2011-06-30 10:10:45 --> Total execution time: 1.3964
DEBUG - 2011-06-30 10:10:58 --> Config Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:10:58 --> URI Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Router Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Output Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Input Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:10:58 --> Language Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Loader Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Controller Class Initialized
ERROR - 2011-06-30 10:10:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:10:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:10:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:10:58 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:10:58 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:10:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:10:58 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:10:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:10:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:10:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:10:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:10:58 --> Final output sent to browser
DEBUG - 2011-06-30 10:10:58 --> Total execution time: 0.0268
DEBUG - 2011-06-30 10:10:59 --> Config Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:10:59 --> URI Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Router Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Output Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Input Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:10:59 --> Language Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Loader Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Controller Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Model Class Initialized
DEBUG - 2011-06-30 10:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:10:59 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:11:00 --> Final output sent to browser
DEBUG - 2011-06-30 10:11:00 --> Total execution time: 0.9017
DEBUG - 2011-06-30 10:11:18 --> Config Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:11:18 --> URI Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Router Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Output Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Input Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:11:18 --> Language Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Loader Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Controller Class Initialized
ERROR - 2011-06-30 10:11:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:11:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:11:18 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:11:18 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:11:18 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:11:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:11:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:11:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:11:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:11:18 --> Final output sent to browser
DEBUG - 2011-06-30 10:11:18 --> Total execution time: 0.0285
DEBUG - 2011-06-30 10:11:23 --> Config Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:11:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:11:23 --> URI Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Router Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Output Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Input Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:11:23 --> Language Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Loader Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Controller Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:11:23 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:11:24 --> Final output sent to browser
DEBUG - 2011-06-30 10:11:24 --> Total execution time: 1.1434
DEBUG - 2011-06-30 10:11:38 --> Config Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:11:38 --> URI Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Router Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Output Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Input Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:11:38 --> Language Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Loader Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Controller Class Initialized
ERROR - 2011-06-30 10:11:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:11:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:11:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:11:38 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:11:38 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:11:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:11:38 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:11:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:11:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:11:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:11:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:11:38 --> Final output sent to browser
DEBUG - 2011-06-30 10:11:38 --> Total execution time: 0.0272
DEBUG - 2011-06-30 10:11:39 --> Config Class Initialized
DEBUG - 2011-06-30 10:11:39 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:11:40 --> URI Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Router Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Output Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Input Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:11:40 --> Language Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Loader Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Controller Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:11:40 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:11:40 --> Final output sent to browser
DEBUG - 2011-06-30 10:11:40 --> Total execution time: 0.5906
DEBUG - 2011-06-30 10:11:49 --> Config Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:11:49 --> URI Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Router Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Output Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Input Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:11:49 --> Language Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Loader Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Controller Class Initialized
ERROR - 2011-06-30 10:11:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:11:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:11:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:11:49 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:11:49 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:11:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:11:49 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:11:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:11:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:11:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:11:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:11:49 --> Final output sent to browser
DEBUG - 2011-06-30 10:11:49 --> Total execution time: 0.0638
DEBUG - 2011-06-30 10:11:50 --> Config Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:11:50 --> URI Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Router Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Output Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Input Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:11:50 --> Language Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Loader Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Controller Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Model Class Initialized
DEBUG - 2011-06-30 10:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:11:50 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:11:51 --> Final output sent to browser
DEBUG - 2011-06-30 10:11:51 --> Total execution time: 0.5079
DEBUG - 2011-06-30 10:12:04 --> Config Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:12:04 --> URI Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Router Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Output Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Input Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:12:04 --> Language Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Loader Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Controller Class Initialized
ERROR - 2011-06-30 10:12:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:12:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:12:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:12:04 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:12:04 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:12:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:12:04 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:12:04 --> Final output sent to browser
DEBUG - 2011-06-30 10:12:04 --> Total execution time: 0.0305
DEBUG - 2011-06-30 10:12:05 --> Config Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:12:05 --> URI Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Router Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Output Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Input Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:12:05 --> Language Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Loader Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Controller Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:12:05 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:12:05 --> Final output sent to browser
DEBUG - 2011-06-30 10:12:05 --> Total execution time: 0.5549
DEBUG - 2011-06-30 10:12:13 --> Config Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:12:13 --> URI Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Router Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Output Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Input Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:12:13 --> Language Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Loader Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Controller Class Initialized
ERROR - 2011-06-30 10:12:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:12:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:12:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:12:13 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:12:13 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:12:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:12:13 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:12:13 --> Final output sent to browser
DEBUG - 2011-06-30 10:12:13 --> Total execution time: 0.0262
DEBUG - 2011-06-30 10:12:14 --> Config Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:12:14 --> URI Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Router Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Output Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Input Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:12:14 --> Language Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Loader Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Controller Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:12:14 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:12:15 --> Final output sent to browser
DEBUG - 2011-06-30 10:12:15 --> Total execution time: 0.5199
DEBUG - 2011-06-30 10:12:27 --> Config Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:12:27 --> URI Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Router Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Output Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Input Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:12:27 --> Language Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Loader Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Controller Class Initialized
ERROR - 2011-06-30 10:12:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:12:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:12:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:12:27 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:12:27 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:12:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:12:27 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:12:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:12:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:12:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:12:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:12:27 --> Final output sent to browser
DEBUG - 2011-06-30 10:12:27 --> Total execution time: 0.0272
DEBUG - 2011-06-30 10:12:29 --> Config Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:12:29 --> URI Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Router Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Output Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Input Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:12:29 --> Language Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Loader Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Controller Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:12:29 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:12:29 --> Final output sent to browser
DEBUG - 2011-06-30 10:12:29 --> Total execution time: 0.6243
DEBUG - 2011-06-30 10:12:46 --> Config Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:12:46 --> URI Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Router Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Output Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Input Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:12:46 --> Language Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Loader Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Controller Class Initialized
ERROR - 2011-06-30 10:12:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:12:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:12:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:12:46 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:12:46 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:12:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:12:46 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:12:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:12:46 --> Final output sent to browser
DEBUG - 2011-06-30 10:12:46 --> Total execution time: 0.0653
DEBUG - 2011-06-30 10:12:48 --> Config Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:12:48 --> URI Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Router Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Output Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Input Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:12:48 --> Language Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Loader Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Controller Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Model Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:12:48 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:12:48 --> Final output sent to browser
DEBUG - 2011-06-30 10:12:48 --> Total execution time: 0.6212
DEBUG - 2011-06-30 10:13:07 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:07 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:07 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Controller Class Initialized
ERROR - 2011-06-30 10:13:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:07 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:07 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:07 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:13:07 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:07 --> Total execution time: 0.0291
DEBUG - 2011-06-30 10:13:09 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:09 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:09 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Controller Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:09 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:09 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:09 --> Total execution time: 0.5635
DEBUG - 2011-06-30 10:13:19 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:19 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:19 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Controller Class Initialized
ERROR - 2011-06-30 10:13:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:13:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:13:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:19 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:19 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:19 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:13:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:13:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:13:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:13:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:13:19 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:19 --> Total execution time: 0.0258
DEBUG - 2011-06-30 10:13:20 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:20 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:20 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Controller Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:20 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:21 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:21 --> Total execution time: 0.4974
DEBUG - 2011-06-30 10:13:32 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:32 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:32 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Controller Class Initialized
ERROR - 2011-06-30 10:13:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:13:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:13:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:32 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:32 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:32 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:13:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:13:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:13:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:13:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:13:32 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:32 --> Total execution time: 0.0573
DEBUG - 2011-06-30 10:13:38 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:38 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:38 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Controller Class Initialized
ERROR - 2011-06-30 10:13:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:13:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:13:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:38 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:38 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:38 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:13:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:13:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:13:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:13:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:13:38 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:38 --> Total execution time: 0.0268
DEBUG - 2011-06-30 10:13:40 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:40 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:40 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Controller Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:40 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:41 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:41 --> Total execution time: 0.5430
DEBUG - 2011-06-30 10:13:43 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:43 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:43 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Controller Class Initialized
ERROR - 2011-06-30 10:13:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:13:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:13:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:43 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:43 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:43 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:13:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:13:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:13:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:13:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:13:43 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:43 --> Total execution time: 0.0311
DEBUG - 2011-06-30 10:13:44 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:44 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:44 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Controller Class Initialized
ERROR - 2011-06-30 10:13:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:13:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:13:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:44 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:44 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:44 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:13:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:13:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:13:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:13:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:13:44 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:44 --> Total execution time: 0.0289
DEBUG - 2011-06-30 10:13:45 --> Config Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:13:45 --> URI Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Router Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Output Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Input Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:13:45 --> Language Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Loader Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Controller Class Initialized
ERROR - 2011-06-30 10:13:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:13:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:13:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:45 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Model Class Initialized
DEBUG - 2011-06-30 10:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:13:45 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:13:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:13:45 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:13:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:13:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:13:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:13:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:13:45 --> Final output sent to browser
DEBUG - 2011-06-30 10:13:45 --> Total execution time: 0.0307
DEBUG - 2011-06-30 10:14:04 --> Config Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:14:04 --> URI Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Router Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Output Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Input Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:14:04 --> Language Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Loader Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Controller Class Initialized
ERROR - 2011-06-30 10:14:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:14:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:14:04 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:14:04 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:14:04 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:14:04 --> Final output sent to browser
DEBUG - 2011-06-30 10:14:04 --> Total execution time: 0.0750
DEBUG - 2011-06-30 10:14:05 --> Config Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:14:05 --> URI Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Router Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Output Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Input Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:14:05 --> Language Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Loader Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Controller Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:14:05 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:14:06 --> Final output sent to browser
DEBUG - 2011-06-30 10:14:06 --> Total execution time: 0.5604
DEBUG - 2011-06-30 10:14:28 --> Config Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:14:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:14:28 --> URI Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Router Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Output Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Input Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:14:28 --> Language Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Loader Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Controller Class Initialized
ERROR - 2011-06-30 10:14:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:14:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:14:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:14:28 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:14:28 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:14:29 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:14:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:14:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:14:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:14:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:14:29 --> Final output sent to browser
DEBUG - 2011-06-30 10:14:29 --> Total execution time: 0.0368
DEBUG - 2011-06-30 10:14:32 --> Config Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:14:32 --> URI Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Router Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Output Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Input Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:14:32 --> Language Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Loader Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Controller Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:14:32 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:14:32 --> Final output sent to browser
DEBUG - 2011-06-30 10:14:32 --> Total execution time: 0.5557
DEBUG - 2011-06-30 10:14:58 --> Config Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:14:58 --> URI Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Router Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Output Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Input Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:14:58 --> Language Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Loader Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Controller Class Initialized
ERROR - 2011-06-30 10:14:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:14:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:14:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:14:58 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:14:58 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:14:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:14:58 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:14:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:14:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:14:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:14:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:14:58 --> Final output sent to browser
DEBUG - 2011-06-30 10:14:58 --> Total execution time: 0.0497
DEBUG - 2011-06-30 10:14:59 --> Config Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:14:59 --> URI Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Router Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Output Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Input Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:14:59 --> Language Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Loader Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Controller Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Model Class Initialized
DEBUG - 2011-06-30 10:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:14:59 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:00 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:00 --> Total execution time: 0.5495
DEBUG - 2011-06-30 10:15:07 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:07 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:07 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Controller Class Initialized
ERROR - 2011-06-30 10:15:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:15:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:15:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:07 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:07 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:07 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:15:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:15:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:15:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:15:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:15:07 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:07 --> Total execution time: 0.0348
DEBUG - 2011-06-30 10:15:08 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:08 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:08 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Controller Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:08 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:09 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:09 --> Total execution time: 0.5037
DEBUG - 2011-06-30 10:15:14 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:14 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:14 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Controller Class Initialized
ERROR - 2011-06-30 10:15:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:15:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:14 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:14 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:14 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:15:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:15:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:15:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:15:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:15:14 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:14 --> Total execution time: 0.0293
DEBUG - 2011-06-30 10:15:16 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:16 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:16 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Controller Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:16 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:16 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:16 --> Total execution time: 0.4618
DEBUG - 2011-06-30 10:15:27 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:27 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:27 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Controller Class Initialized
ERROR - 2011-06-30 10:15:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:15:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:27 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:27 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:27 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:15:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:15:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:15:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:15:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:15:27 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:27 --> Total execution time: 0.0298
DEBUG - 2011-06-30 10:15:29 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:29 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:29 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Controller Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:29 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:30 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:30 --> Total execution time: 0.4751
DEBUG - 2011-06-30 10:15:36 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:36 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:36 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Controller Class Initialized
ERROR - 2011-06-30 10:15:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:15:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:15:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:36 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:36 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:36 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:15:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:15:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:15:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:15:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:15:36 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:36 --> Total execution time: 0.0394
DEBUG - 2011-06-30 10:15:37 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:37 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:37 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Controller Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:37 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:38 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:38 --> Total execution time: 0.5088
DEBUG - 2011-06-30 10:15:55 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:55 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:55 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Controller Class Initialized
ERROR - 2011-06-30 10:15:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 10:15:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 10:15:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:55 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:55 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 10:15:55 --> Helper loaded: url_helper
DEBUG - 2011-06-30 10:15:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 10:15:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 10:15:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 10:15:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 10:15:55 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:55 --> Total execution time: 0.0286
DEBUG - 2011-06-30 10:15:57 --> Config Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Hooks Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Utf8 Class Initialized
DEBUG - 2011-06-30 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 10:15:57 --> URI Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Router Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Output Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Input Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 10:15:57 --> Language Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Loader Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Controller Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Model Class Initialized
DEBUG - 2011-06-30 10:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 10:15:57 --> Database Driver Class Initialized
DEBUG - 2011-06-30 10:15:58 --> Final output sent to browser
DEBUG - 2011-06-30 10:15:58 --> Total execution time: 0.8898
DEBUG - 2011-06-30 11:37:36 --> Config Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:37:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:37:36 --> URI Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Router Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Output Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Input Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:37:36 --> Language Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Loader Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Controller Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Model Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Model Class Initialized
DEBUG - 2011-06-30 11:37:36 --> Model Class Initialized
DEBUG - 2011-06-30 11:37:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:37:37 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:37:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:37:38 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:37:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:37:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:37:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:37:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:37:38 --> Final output sent to browser
DEBUG - 2011-06-30 11:37:38 --> Total execution time: 2.1133
DEBUG - 2011-06-30 11:37:40 --> Config Class Initialized
DEBUG - 2011-06-30 11:37:40 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:37:40 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:37:40 --> URI Class Initialized
DEBUG - 2011-06-30 11:37:40 --> Router Class Initialized
ERROR - 2011-06-30 11:37:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:37:43 --> Config Class Initialized
DEBUG - 2011-06-30 11:37:43 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:37:43 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:37:43 --> URI Class Initialized
DEBUG - 2011-06-30 11:37:43 --> Router Class Initialized
ERROR - 2011-06-30 11:37:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:37:57 --> Config Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:37:57 --> URI Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Router Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Output Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Input Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:37:57 --> Language Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Loader Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Controller Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Model Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Model Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Model Class Initialized
DEBUG - 2011-06-30 11:37:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:37:57 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:37:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:37:58 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:37:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:37:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:37:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:37:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:37:58 --> Final output sent to browser
DEBUG - 2011-06-30 11:37:58 --> Total execution time: 1.1015
DEBUG - 2011-06-30 11:38:00 --> Config Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:38:00 --> URI Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Router Class Initialized
ERROR - 2011-06-30 11:38:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:38:00 --> Config Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:38:00 --> URI Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Router Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Output Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Input Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:38:00 --> Language Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Loader Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Controller Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:38:00 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:38:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:38:00 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:38:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:38:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:38:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:38:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:38:00 --> Final output sent to browser
DEBUG - 2011-06-30 11:38:00 --> Total execution time: 0.0928
DEBUG - 2011-06-30 11:38:32 --> Config Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:38:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:38:32 --> URI Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Router Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Output Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Input Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:38:32 --> Language Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Loader Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Controller Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:38:32 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:38:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:38:33 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:38:33 --> Final output sent to browser
DEBUG - 2011-06-30 11:38:33 --> Total execution time: 0.9646
DEBUG - 2011-06-30 11:38:35 --> Config Class Initialized
DEBUG - 2011-06-30 11:38:35 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:38:35 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:38:35 --> URI Class Initialized
DEBUG - 2011-06-30 11:38:35 --> Router Class Initialized
ERROR - 2011-06-30 11:38:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:38:44 --> Config Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:38:44 --> URI Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Router Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Output Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Input Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:38:44 --> Language Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Loader Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Controller Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:38:44 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:38:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:38:45 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:38:45 --> Final output sent to browser
DEBUG - 2011-06-30 11:38:45 --> Total execution time: 0.4758
DEBUG - 2011-06-30 11:38:46 --> Config Class Initialized
DEBUG - 2011-06-30 11:38:46 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:38:46 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:38:46 --> URI Class Initialized
DEBUG - 2011-06-30 11:38:46 --> Router Class Initialized
ERROR - 2011-06-30 11:38:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:38:48 --> Config Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:38:48 --> URI Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Router Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Output Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Input Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:38:48 --> Language Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Loader Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Controller Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:38:48 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:38:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:38:48 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:38:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:38:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:38:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:38:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:38:48 --> Final output sent to browser
DEBUG - 2011-06-30 11:38:48 --> Total execution time: 0.1883
DEBUG - 2011-06-30 11:38:51 --> Config Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:38:51 --> URI Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Router Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Output Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Input Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:38:51 --> Language Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Loader Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Controller Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Model Class Initialized
DEBUG - 2011-06-30 11:38:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:38:51 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:38:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:38:51 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:38:51 --> Final output sent to browser
DEBUG - 2011-06-30 11:38:51 --> Total execution time: 0.0486
DEBUG - 2011-06-30 11:39:12 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:12 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:12 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:12 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:15 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:15 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:15 --> Total execution time: 2.1579
DEBUG - 2011-06-30 11:39:16 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:16 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:16 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:16 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:16 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:16 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:16 --> Total execution time: 0.1358
DEBUG - 2011-06-30 11:39:17 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:17 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:17 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:17 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:17 --> Router Class Initialized
ERROR - 2011-06-30 11:39:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:39:18 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:18 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:18 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:18 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:18 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:18 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:18 --> Total execution time: 0.1510
DEBUG - 2011-06-30 11:39:24 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:24 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:24 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:24 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:25 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:25 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:25 --> Total execution time: 1.5199
DEBUG - 2011-06-30 11:39:26 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:26 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:26 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:26 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:26 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:26 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:26 --> Total execution time: 0.1409
DEBUG - 2011-06-30 11:39:26 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:26 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:26 --> Router Class Initialized
ERROR - 2011-06-30 11:39:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:39:44 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:44 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:44 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:44 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:44 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:44 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:44 --> Total execution time: 0.3341
DEBUG - 2011-06-30 11:39:46 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:46 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:46 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:46 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:46 --> Router Class Initialized
ERROR - 2011-06-30 11:39:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:39:51 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:51 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:51 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:51 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:51 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:51 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:51 --> Total execution time: 0.3364
DEBUG - 2011-06-30 11:39:53 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:53 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:53 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:53 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:54 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:54 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:54 --> Total execution time: 0.6925
DEBUG - 2011-06-30 11:39:55 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:55 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Router Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Output Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Input Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:39:55 --> Language Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Loader Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Controller Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Model Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:39:55 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:39:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:39:55 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:39:55 --> Final output sent to browser
DEBUG - 2011-06-30 11:39:55 --> Total execution time: 0.0507
DEBUG - 2011-06-30 11:39:55 --> Config Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:39:55 --> URI Class Initialized
DEBUG - 2011-06-30 11:39:55 --> Router Class Initialized
ERROR - 2011-06-30 11:39:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:40:01 --> Config Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:40:01 --> URI Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Router Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Output Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Input Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:40:01 --> Language Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Loader Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Controller Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Model Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Model Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Model Class Initialized
DEBUG - 2011-06-30 11:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:40:01 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:40:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:40:01 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:40:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:40:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:40:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:40:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:40:01 --> Final output sent to browser
DEBUG - 2011-06-30 11:40:01 --> Total execution time: 0.3076
DEBUG - 2011-06-30 11:40:02 --> Config Class Initialized
DEBUG - 2011-06-30 11:40:02 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:40:02 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:40:02 --> URI Class Initialized
DEBUG - 2011-06-30 11:40:02 --> Router Class Initialized
ERROR - 2011-06-30 11:40:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-30 11:40:06 --> Config Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:40:06 --> URI Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Router Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Output Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Input Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:40:06 --> Language Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Loader Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Controller Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Model Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Model Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Model Class Initialized
DEBUG - 2011-06-30 11:40:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 11:40:06 --> Database Driver Class Initialized
DEBUG - 2011-06-30 11:40:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 11:40:06 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:40:06 --> Final output sent to browser
DEBUG - 2011-06-30 11:40:06 --> Total execution time: 0.0913
DEBUG - 2011-06-30 11:49:12 --> Config Class Initialized
DEBUG - 2011-06-30 11:49:12 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:49:12 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:49:12 --> URI Class Initialized
DEBUG - 2011-06-30 11:49:12 --> Router Class Initialized
ERROR - 2011-06-30 11:49:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-30 11:51:32 --> Config Class Initialized
DEBUG - 2011-06-30 11:51:32 --> Hooks Class Initialized
DEBUG - 2011-06-30 11:51:32 --> Utf8 Class Initialized
DEBUG - 2011-06-30 11:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 11:51:32 --> URI Class Initialized
DEBUG - 2011-06-30 11:51:32 --> Router Class Initialized
DEBUG - 2011-06-30 11:51:32 --> No URI present. Default controller set.
DEBUG - 2011-06-30 11:51:32 --> Output Class Initialized
DEBUG - 2011-06-30 11:51:32 --> Input Class Initialized
DEBUG - 2011-06-30 11:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 11:51:32 --> Language Class Initialized
DEBUG - 2011-06-30 11:51:32 --> Loader Class Initialized
DEBUG - 2011-06-30 11:51:32 --> Controller Class Initialized
DEBUG - 2011-06-30 11:51:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-30 11:51:32 --> Helper loaded: url_helper
DEBUG - 2011-06-30 11:51:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 11:51:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 11:51:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 11:51:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 11:51:32 --> Final output sent to browser
DEBUG - 2011-06-30 11:51:32 --> Total execution time: 0.3846
DEBUG - 2011-06-30 15:40:07 --> Config Class Initialized
DEBUG - 2011-06-30 15:40:07 --> Hooks Class Initialized
DEBUG - 2011-06-30 15:40:07 --> Utf8 Class Initialized
DEBUG - 2011-06-30 15:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 15:40:07 --> URI Class Initialized
DEBUG - 2011-06-30 15:40:07 --> Router Class Initialized
DEBUG - 2011-06-30 15:40:07 --> No URI present. Default controller set.
DEBUG - 2011-06-30 15:40:07 --> Output Class Initialized
DEBUG - 2011-06-30 15:40:07 --> Input Class Initialized
DEBUG - 2011-06-30 15:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 15:40:07 --> Language Class Initialized
DEBUG - 2011-06-30 15:40:07 --> Loader Class Initialized
DEBUG - 2011-06-30 15:40:07 --> Controller Class Initialized
DEBUG - 2011-06-30 15:40:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-30 15:40:07 --> Helper loaded: url_helper
DEBUG - 2011-06-30 15:40:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 15:40:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 15:40:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 15:40:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 15:40:07 --> Final output sent to browser
DEBUG - 2011-06-30 15:40:07 --> Total execution time: 0.2535
DEBUG - 2011-06-30 19:34:24 --> Config Class Initialized
DEBUG - 2011-06-30 19:34:24 --> Hooks Class Initialized
DEBUG - 2011-06-30 19:34:24 --> Utf8 Class Initialized
DEBUG - 2011-06-30 19:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 19:34:24 --> URI Class Initialized
DEBUG - 2011-06-30 19:34:24 --> Router Class Initialized
ERROR - 2011-06-30 19:34:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-30 19:34:25 --> Config Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Hooks Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Utf8 Class Initialized
DEBUG - 2011-06-30 19:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 19:34:25 --> URI Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Router Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Output Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Input Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 19:34:25 --> Language Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Loader Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Controller Class Initialized
ERROR - 2011-06-30 19:34:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 19:34:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 19:34:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 19:34:25 --> Model Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Model Class Initialized
DEBUG - 2011-06-30 19:34:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 19:34:25 --> Database Driver Class Initialized
DEBUG - 2011-06-30 19:34:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 19:34:25 --> Helper loaded: url_helper
DEBUG - 2011-06-30 19:34:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 19:34:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 19:34:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 19:34:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 19:34:25 --> Final output sent to browser
DEBUG - 2011-06-30 19:34:25 --> Total execution time: 0.3248
DEBUG - 2011-06-30 20:05:25 --> Config Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Hooks Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Utf8 Class Initialized
DEBUG - 2011-06-30 20:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 20:05:25 --> URI Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Router Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Output Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Input Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 20:05:25 --> Language Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Loader Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Controller Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Model Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Model Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Model Class Initialized
DEBUG - 2011-06-30 20:05:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 20:05:25 --> Database Driver Class Initialized
DEBUG - 2011-06-30 20:05:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-30 20:05:25 --> Helper loaded: url_helper
DEBUG - 2011-06-30 20:05:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 20:05:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 20:05:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 20:05:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 20:05:25 --> Final output sent to browser
DEBUG - 2011-06-30 20:05:25 --> Total execution time: 0.4236
DEBUG - 2011-06-30 20:05:44 --> Config Class Initialized
DEBUG - 2011-06-30 20:05:44 --> Hooks Class Initialized
DEBUG - 2011-06-30 20:05:44 --> Utf8 Class Initialized
DEBUG - 2011-06-30 20:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-30 20:05:44 --> URI Class Initialized
DEBUG - 2011-06-30 20:05:44 --> Router Class Initialized
DEBUG - 2011-06-30 20:05:44 --> Output Class Initialized
DEBUG - 2011-06-30 20:05:44 --> Input Class Initialized
DEBUG - 2011-06-30 20:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-30 20:05:44 --> Language Class Initialized
DEBUG - 2011-06-30 20:05:44 --> Loader Class Initialized
DEBUG - 2011-06-30 20:05:44 --> Controller Class Initialized
ERROR - 2011-06-30 20:05:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-30 20:05:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-30 20:05:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 20:05:45 --> Model Class Initialized
DEBUG - 2011-06-30 20:05:45 --> Model Class Initialized
DEBUG - 2011-06-30 20:05:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-30 20:05:45 --> Database Driver Class Initialized
DEBUG - 2011-06-30 20:05:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-30 20:05:45 --> Helper loaded: url_helper
DEBUG - 2011-06-30 20:05:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-30 20:05:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-30 20:05:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-30 20:05:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-30 20:05:45 --> Final output sent to browser
DEBUG - 2011-06-30 20:05:45 --> Total execution time: 0.9315

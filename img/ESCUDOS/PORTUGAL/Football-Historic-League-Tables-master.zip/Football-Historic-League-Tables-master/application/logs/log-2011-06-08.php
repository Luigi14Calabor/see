<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-08 01:09:40 --> Config Class Initialized
DEBUG - 2011-06-08 01:09:40 --> Hooks Class Initialized
DEBUG - 2011-06-08 01:09:40 --> Utf8 Class Initialized
DEBUG - 2011-06-08 01:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 01:09:40 --> URI Class Initialized
DEBUG - 2011-06-08 01:09:40 --> Router Class Initialized
ERROR - 2011-06-08 01:09:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-08 01:09:40 --> Config Class Initialized
DEBUG - 2011-06-08 01:09:40 --> Hooks Class Initialized
DEBUG - 2011-06-08 01:09:40 --> Utf8 Class Initialized
DEBUG - 2011-06-08 01:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 01:09:40 --> URI Class Initialized
DEBUG - 2011-06-08 01:09:40 --> Router Class Initialized
DEBUG - 2011-06-08 01:09:40 --> No URI present. Default controller set.
DEBUG - 2011-06-08 01:09:41 --> Output Class Initialized
DEBUG - 2011-06-08 01:09:41 --> Input Class Initialized
DEBUG - 2011-06-08 01:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 01:09:41 --> Language Class Initialized
DEBUG - 2011-06-08 01:09:41 --> Loader Class Initialized
DEBUG - 2011-06-08 01:09:41 --> Controller Class Initialized
DEBUG - 2011-06-08 01:09:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-08 01:09:42 --> Helper loaded: url_helper
DEBUG - 2011-06-08 01:09:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 01:09:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 01:09:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 01:09:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 01:09:42 --> Final output sent to browser
DEBUG - 2011-06-08 01:09:42 --> Total execution time: 1.3696
DEBUG - 2011-06-08 01:12:21 --> Config Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Hooks Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Utf8 Class Initialized
DEBUG - 2011-06-08 01:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 01:12:21 --> URI Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Router Class Initialized
ERROR - 2011-06-08 01:12:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-08 01:12:21 --> Config Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Hooks Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Utf8 Class Initialized
DEBUG - 2011-06-08 01:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 01:12:21 --> URI Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Router Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Output Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Input Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 01:12:21 --> Language Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Loader Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Controller Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Model Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Model Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Model Class Initialized
DEBUG - 2011-06-08 01:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 01:12:21 --> Database Driver Class Initialized
DEBUG - 2011-06-08 01:12:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-08 01:12:22 --> Helper loaded: url_helper
DEBUG - 2011-06-08 01:12:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 01:12:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 01:12:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 01:12:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 01:12:22 --> Final output sent to browser
DEBUG - 2011-06-08 01:12:22 --> Total execution time: 0.5765
DEBUG - 2011-06-08 01:12:52 --> Config Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Hooks Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Utf8 Class Initialized
DEBUG - 2011-06-08 01:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 01:12:52 --> URI Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Router Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Output Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Input Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 01:12:52 --> Language Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Loader Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Controller Class Initialized
ERROR - 2011-06-08 01:12:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-08 01:12:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-08 01:12:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 01:12:52 --> Model Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Model Class Initialized
DEBUG - 2011-06-08 01:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 01:12:52 --> Database Driver Class Initialized
DEBUG - 2011-06-08 01:12:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 01:12:52 --> Helper loaded: url_helper
DEBUG - 2011-06-08 01:12:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 01:12:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 01:12:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 01:12:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 01:12:52 --> Final output sent to browser
DEBUG - 2011-06-08 01:12:52 --> Total execution time: 0.1104
DEBUG - 2011-06-08 03:07:29 --> Config Class Initialized
DEBUG - 2011-06-08 03:07:29 --> Hooks Class Initialized
DEBUG - 2011-06-08 03:07:29 --> Utf8 Class Initialized
DEBUG - 2011-06-08 03:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 03:07:29 --> URI Class Initialized
DEBUG - 2011-06-08 03:07:29 --> Router Class Initialized
DEBUG - 2011-06-08 03:07:29 --> No URI present. Default controller set.
DEBUG - 2011-06-08 03:07:29 --> Output Class Initialized
DEBUG - 2011-06-08 03:07:29 --> Input Class Initialized
DEBUG - 2011-06-08 03:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 03:07:29 --> Language Class Initialized
DEBUG - 2011-06-08 03:07:29 --> Loader Class Initialized
DEBUG - 2011-06-08 03:07:29 --> Controller Class Initialized
DEBUG - 2011-06-08 03:07:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-08 03:07:29 --> Helper loaded: url_helper
DEBUG - 2011-06-08 03:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 03:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 03:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 03:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 03:07:29 --> Final output sent to browser
DEBUG - 2011-06-08 03:07:29 --> Total execution time: 0.2650
DEBUG - 2011-06-08 06:05:52 --> Config Class Initialized
DEBUG - 2011-06-08 06:05:52 --> Hooks Class Initialized
DEBUG - 2011-06-08 06:05:52 --> Utf8 Class Initialized
DEBUG - 2011-06-08 06:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 06:05:52 --> URI Class Initialized
DEBUG - 2011-06-08 06:05:52 --> Router Class Initialized
ERROR - 2011-06-08 06:05:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-08 08:17:21 --> Config Class Initialized
DEBUG - 2011-06-08 08:17:21 --> Hooks Class Initialized
DEBUG - 2011-06-08 08:17:21 --> Utf8 Class Initialized
DEBUG - 2011-06-08 08:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 08:17:21 --> URI Class Initialized
DEBUG - 2011-06-08 08:17:21 --> Router Class Initialized
DEBUG - 2011-06-08 08:17:22 --> Output Class Initialized
DEBUG - 2011-06-08 08:17:22 --> Input Class Initialized
DEBUG - 2011-06-08 08:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 08:17:22 --> Language Class Initialized
DEBUG - 2011-06-08 08:17:22 --> Loader Class Initialized
DEBUG - 2011-06-08 08:17:22 --> Controller Class Initialized
ERROR - 2011-06-08 08:17:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-08 08:17:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-08 08:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 08:17:22 --> Model Class Initialized
DEBUG - 2011-06-08 08:17:22 --> Model Class Initialized
DEBUG - 2011-06-08 08:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 08:17:22 --> Database Driver Class Initialized
DEBUG - 2011-06-08 08:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 08:17:22 --> Helper loaded: url_helper
DEBUG - 2011-06-08 08:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 08:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 08:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 08:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 08:17:22 --> Final output sent to browser
DEBUG - 2011-06-08 08:17:22 --> Total execution time: 0.7842
DEBUG - 2011-06-08 08:17:24 --> Config Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Hooks Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Utf8 Class Initialized
DEBUG - 2011-06-08 08:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 08:17:24 --> URI Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Router Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Output Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Input Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 08:17:24 --> Language Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Loader Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Controller Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Model Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Model Class Initialized
DEBUG - 2011-06-08 08:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 08:17:24 --> Database Driver Class Initialized
DEBUG - 2011-06-08 08:17:25 --> Final output sent to browser
DEBUG - 2011-06-08 08:17:25 --> Total execution time: 0.8305
DEBUG - 2011-06-08 08:17:25 --> Config Class Initialized
DEBUG - 2011-06-08 08:17:25 --> Hooks Class Initialized
DEBUG - 2011-06-08 08:17:25 --> Utf8 Class Initialized
DEBUG - 2011-06-08 08:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 08:17:25 --> URI Class Initialized
DEBUG - 2011-06-08 08:17:25 --> Router Class Initialized
ERROR - 2011-06-08 08:17:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-08 08:17:53 --> Config Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Hooks Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Utf8 Class Initialized
DEBUG - 2011-06-08 08:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 08:17:53 --> URI Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Router Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Output Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Input Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 08:17:53 --> Language Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Loader Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Controller Class Initialized
ERROR - 2011-06-08 08:17:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-08 08:17:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-08 08:17:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 08:17:53 --> Model Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Model Class Initialized
DEBUG - 2011-06-08 08:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 08:17:53 --> Database Driver Class Initialized
DEBUG - 2011-06-08 08:17:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 08:17:53 --> Helper loaded: url_helper
DEBUG - 2011-06-08 08:17:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 08:17:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 08:17:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 08:17:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 08:17:54 --> Final output sent to browser
DEBUG - 2011-06-08 08:17:54 --> Total execution time: 0.0348
DEBUG - 2011-06-08 08:17:54 --> Config Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Hooks Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Utf8 Class Initialized
DEBUG - 2011-06-08 08:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 08:17:54 --> URI Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Router Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Output Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Input Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 08:17:54 --> Language Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Loader Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Controller Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Model Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Model Class Initialized
DEBUG - 2011-06-08 08:17:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 08:17:54 --> Database Driver Class Initialized
DEBUG - 2011-06-08 08:17:55 --> Final output sent to browser
DEBUG - 2011-06-08 08:17:55 --> Total execution time: 0.6255
DEBUG - 2011-06-08 09:48:31 --> Config Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Hooks Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Utf8 Class Initialized
DEBUG - 2011-06-08 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 09:48:31 --> URI Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Router Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Output Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Input Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 09:48:31 --> Language Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Loader Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Controller Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Model Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Model Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Model Class Initialized
DEBUG - 2011-06-08 09:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 09:48:31 --> Database Driver Class Initialized
DEBUG - 2011-06-08 09:48:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-08 09:48:32 --> Helper loaded: url_helper
DEBUG - 2011-06-08 09:48:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 09:48:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 09:48:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 09:48:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 09:48:32 --> Final output sent to browser
DEBUG - 2011-06-08 09:48:32 --> Total execution time: 0.7891
DEBUG - 2011-06-08 09:48:36 --> Config Class Initialized
DEBUG - 2011-06-08 09:48:36 --> Hooks Class Initialized
DEBUG - 2011-06-08 09:48:36 --> Utf8 Class Initialized
DEBUG - 2011-06-08 09:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 09:48:36 --> URI Class Initialized
DEBUG - 2011-06-08 09:48:36 --> Router Class Initialized
ERROR - 2011-06-08 09:48:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-08 09:49:03 --> Config Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Hooks Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Utf8 Class Initialized
DEBUG - 2011-06-08 09:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 09:49:03 --> URI Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Router Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Output Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Input Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 09:49:03 --> Language Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Loader Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Controller Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Model Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Model Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Model Class Initialized
DEBUG - 2011-06-08 09:49:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 09:49:03 --> Database Driver Class Initialized
DEBUG - 2011-06-08 09:49:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-08 09:49:03 --> Helper loaded: url_helper
DEBUG - 2011-06-08 09:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 09:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 09:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 09:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 09:49:03 --> Final output sent to browser
DEBUG - 2011-06-08 09:49:03 --> Total execution time: 0.0595
DEBUG - 2011-06-08 12:14:51 --> Config Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Hooks Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Utf8 Class Initialized
DEBUG - 2011-06-08 12:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 12:14:51 --> URI Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Router Class Initialized
ERROR - 2011-06-08 12:14:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-08 12:14:51 --> Config Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Hooks Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Utf8 Class Initialized
DEBUG - 2011-06-08 12:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 12:14:51 --> URI Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Router Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Output Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Input Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 12:14:51 --> Language Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Loader Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Controller Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Model Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Model Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Model Class Initialized
DEBUG - 2011-06-08 12:14:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 12:14:51 --> Database Driver Class Initialized
DEBUG - 2011-06-08 12:14:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-08 12:14:52 --> Helper loaded: url_helper
DEBUG - 2011-06-08 12:14:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 12:14:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 12:14:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 12:14:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 12:14:52 --> Final output sent to browser
DEBUG - 2011-06-08 12:14:52 --> Total execution time: 1.0996
DEBUG - 2011-06-08 12:15:23 --> Config Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Hooks Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Utf8 Class Initialized
DEBUG - 2011-06-08 12:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 12:15:23 --> URI Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Router Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Output Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Input Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 12:15:23 --> Language Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Loader Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Controller Class Initialized
ERROR - 2011-06-08 12:15:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-08 12:15:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-08 12:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 12:15:23 --> Model Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Model Class Initialized
DEBUG - 2011-06-08 12:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 12:15:23 --> Database Driver Class Initialized
DEBUG - 2011-06-08 12:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 12:15:23 --> Helper loaded: url_helper
DEBUG - 2011-06-08 12:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 12:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 12:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 12:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 12:15:23 --> Final output sent to browser
DEBUG - 2011-06-08 12:15:23 --> Total execution time: 0.1775
DEBUG - 2011-06-08 12:35:51 --> Config Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Hooks Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Utf8 Class Initialized
DEBUG - 2011-06-08 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 12:35:51 --> URI Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Router Class Initialized
ERROR - 2011-06-08 12:35:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-08 12:35:51 --> Config Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Hooks Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Utf8 Class Initialized
DEBUG - 2011-06-08 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 12:35:51 --> URI Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Router Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Output Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Input Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 12:35:51 --> Language Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Loader Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Controller Class Initialized
ERROR - 2011-06-08 12:35:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-08 12:35:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-08 12:35:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 12:35:51 --> Model Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Model Class Initialized
DEBUG - 2011-06-08 12:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 12:35:51 --> Database Driver Class Initialized
DEBUG - 2011-06-08 12:35:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 12:35:51 --> Helper loaded: url_helper
DEBUG - 2011-06-08 12:35:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 12:35:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 12:35:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 12:35:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 12:35:51 --> Final output sent to browser
DEBUG - 2011-06-08 12:35:51 --> Total execution time: 0.3483
DEBUG - 2011-06-08 14:08:06 --> Config Class Initialized
DEBUG - 2011-06-08 14:08:06 --> Hooks Class Initialized
DEBUG - 2011-06-08 14:08:06 --> Utf8 Class Initialized
DEBUG - 2011-06-08 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 14:08:06 --> URI Class Initialized
DEBUG - 2011-06-08 14:08:06 --> Router Class Initialized
DEBUG - 2011-06-08 14:08:06 --> No URI present. Default controller set.
DEBUG - 2011-06-08 14:08:06 --> Output Class Initialized
DEBUG - 2011-06-08 14:08:06 --> Input Class Initialized
DEBUG - 2011-06-08 14:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 14:08:06 --> Language Class Initialized
DEBUG - 2011-06-08 14:08:06 --> Loader Class Initialized
DEBUG - 2011-06-08 14:08:06 --> Controller Class Initialized
DEBUG - 2011-06-08 14:08:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-08 14:08:06 --> Helper loaded: url_helper
DEBUG - 2011-06-08 14:08:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 14:08:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 14:08:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 14:08:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 14:08:06 --> Final output sent to browser
DEBUG - 2011-06-08 14:08:06 --> Total execution time: 0.4193
DEBUG - 2011-06-08 16:32:16 --> Config Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Hooks Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Utf8 Class Initialized
DEBUG - 2011-06-08 16:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 16:32:16 --> URI Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Router Class Initialized
ERROR - 2011-06-08 16:32:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-08 16:32:16 --> Config Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Hooks Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Utf8 Class Initialized
DEBUG - 2011-06-08 16:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 16:32:16 --> URI Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Router Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Output Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Input Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 16:32:16 --> Language Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Loader Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Controller Class Initialized
ERROR - 2011-06-08 16:32:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-08 16:32:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-08 16:32:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 16:32:16 --> Model Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Model Class Initialized
DEBUG - 2011-06-08 16:32:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 16:32:16 --> Database Driver Class Initialized
DEBUG - 2011-06-08 16:32:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 16:32:16 --> Helper loaded: url_helper
DEBUG - 2011-06-08 16:32:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 16:32:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 16:32:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 16:32:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 16:32:16 --> Final output sent to browser
DEBUG - 2011-06-08 16:32:16 --> Total execution time: 0.2360
DEBUG - 2011-06-08 18:40:26 --> Config Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Hooks Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Utf8 Class Initialized
DEBUG - 2011-06-08 18:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 18:40:26 --> URI Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Router Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Output Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Input Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 18:40:26 --> Language Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Loader Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Controller Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Model Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Model Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Model Class Initialized
DEBUG - 2011-06-08 18:40:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 18:40:26 --> Database Driver Class Initialized
DEBUG - 2011-06-08 18:40:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-08 18:40:27 --> Helper loaded: url_helper
DEBUG - 2011-06-08 18:40:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 18:40:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 18:40:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 18:40:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 18:40:27 --> Final output sent to browser
DEBUG - 2011-06-08 18:40:27 --> Total execution time: 0.5911
DEBUG - 2011-06-08 18:40:34 --> Config Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Hooks Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Utf8 Class Initialized
DEBUG - 2011-06-08 18:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-08 18:40:34 --> URI Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Router Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Output Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Input Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-08 18:40:34 --> Language Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Loader Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Controller Class Initialized
ERROR - 2011-06-08 18:40:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-08 18:40:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-08 18:40:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 18:40:34 --> Model Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Model Class Initialized
DEBUG - 2011-06-08 18:40:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-08 18:40:34 --> Database Driver Class Initialized
DEBUG - 2011-06-08 18:40:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-08 18:40:34 --> Helper loaded: url_helper
DEBUG - 2011-06-08 18:40:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-08 18:40:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-08 18:40:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-08 18:40:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-08 18:40:34 --> Final output sent to browser
DEBUG - 2011-06-08 18:40:34 --> Total execution time: 0.0929

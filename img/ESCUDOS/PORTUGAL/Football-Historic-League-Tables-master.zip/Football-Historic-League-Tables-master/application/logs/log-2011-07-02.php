<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-02 01:27:46 --> Config Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Hooks Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Utf8 Class Initialized
DEBUG - 2011-07-02 01:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 01:27:46 --> URI Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Router Class Initialized
ERROR - 2011-07-02 01:27:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-02 01:27:46 --> Config Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Hooks Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Utf8 Class Initialized
DEBUG - 2011-07-02 01:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 01:27:46 --> URI Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Router Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Output Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Input Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 01:27:46 --> Language Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Loader Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Controller Class Initialized
ERROR - 2011-07-02 01:27:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 01:27:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 01:27:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 01:27:46 --> Model Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Model Class Initialized
DEBUG - 2011-07-02 01:27:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 01:27:46 --> Database Driver Class Initialized
DEBUG - 2011-07-02 01:27:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 01:27:46 --> Helper loaded: url_helper
DEBUG - 2011-07-02 01:27:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 01:27:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 01:27:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 01:27:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 01:27:46 --> Final output sent to browser
DEBUG - 2011-07-02 01:27:46 --> Total execution time: 0.2912
DEBUG - 2011-07-02 02:44:23 --> Config Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Hooks Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Utf8 Class Initialized
DEBUG - 2011-07-02 02:44:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 02:44:23 --> URI Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Router Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Output Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Input Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 02:44:23 --> Language Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Loader Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Controller Class Initialized
ERROR - 2011-07-02 02:44:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 02:44:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 02:44:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 02:44:23 --> Model Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Model Class Initialized
DEBUG - 2011-07-02 02:44:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 02:44:24 --> Database Driver Class Initialized
DEBUG - 2011-07-02 02:44:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 02:44:25 --> Helper loaded: url_helper
DEBUG - 2011-07-02 02:44:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 02:44:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 02:44:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 02:44:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 02:44:25 --> Final output sent to browser
DEBUG - 2011-07-02 02:44:25 --> Total execution time: 1.3270
DEBUG - 2011-07-02 02:44:26 --> Config Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Hooks Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Utf8 Class Initialized
DEBUG - 2011-07-02 02:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 02:44:26 --> URI Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Router Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Output Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Input Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 02:44:26 --> Language Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Loader Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Controller Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Model Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Model Class Initialized
DEBUG - 2011-07-02 02:44:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 02:44:26 --> Database Driver Class Initialized
DEBUG - 2011-07-02 02:44:28 --> Final output sent to browser
DEBUG - 2011-07-02 02:44:28 --> Total execution time: 2.1319
DEBUG - 2011-07-02 02:44:30 --> Config Class Initialized
DEBUG - 2011-07-02 02:44:30 --> Hooks Class Initialized
DEBUG - 2011-07-02 02:44:30 --> Utf8 Class Initialized
DEBUG - 2011-07-02 02:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 02:44:30 --> URI Class Initialized
DEBUG - 2011-07-02 02:44:30 --> Router Class Initialized
ERROR - 2011-07-02 02:44:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-02 02:44:31 --> Config Class Initialized
DEBUG - 2011-07-02 02:44:31 --> Hooks Class Initialized
DEBUG - 2011-07-02 02:44:31 --> Utf8 Class Initialized
DEBUG - 2011-07-02 02:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 02:44:31 --> URI Class Initialized
DEBUG - 2011-07-02 02:44:31 --> Router Class Initialized
ERROR - 2011-07-02 02:44:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-02 02:44:31 --> Config Class Initialized
DEBUG - 2011-07-02 02:44:31 --> Hooks Class Initialized
DEBUG - 2011-07-02 02:44:31 --> Utf8 Class Initialized
DEBUG - 2011-07-02 02:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 02:44:31 --> URI Class Initialized
DEBUG - 2011-07-02 02:44:31 --> Router Class Initialized
ERROR - 2011-07-02 02:44:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-02 04:27:47 --> Config Class Initialized
DEBUG - 2011-07-02 04:27:47 --> Hooks Class Initialized
DEBUG - 2011-07-02 04:27:47 --> Utf8 Class Initialized
DEBUG - 2011-07-02 04:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 04:27:47 --> URI Class Initialized
DEBUG - 2011-07-02 04:27:47 --> Router Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Output Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Input Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 04:27:48 --> Language Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Loader Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Controller Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Model Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Model Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Model Class Initialized
DEBUG - 2011-07-02 04:27:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 04:27:48 --> Database Driver Class Initialized
DEBUG - 2011-07-02 04:27:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 04:27:50 --> Helper loaded: url_helper
DEBUG - 2011-07-02 04:27:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 04:27:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 04:27:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 04:27:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 04:27:50 --> Final output sent to browser
DEBUG - 2011-07-02 04:27:50 --> Total execution time: 2.1944
DEBUG - 2011-07-02 04:27:51 --> Config Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Hooks Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Utf8 Class Initialized
DEBUG - 2011-07-02 04:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 04:27:51 --> URI Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Router Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Output Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Input Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 04:27:51 --> Language Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Loader Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Controller Class Initialized
ERROR - 2011-07-02 04:27:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 04:27:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 04:27:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 04:27:51 --> Model Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Model Class Initialized
DEBUG - 2011-07-02 04:27:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 04:27:51 --> Database Driver Class Initialized
DEBUG - 2011-07-02 04:27:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 04:27:51 --> Helper loaded: url_helper
DEBUG - 2011-07-02 04:27:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 04:27:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 04:27:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 04:27:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 04:27:51 --> Final output sent to browser
DEBUG - 2011-07-02 04:27:51 --> Total execution time: 0.1015
DEBUG - 2011-07-02 05:48:38 --> Config Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Hooks Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Utf8 Class Initialized
DEBUG - 2011-07-02 05:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 05:48:38 --> URI Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Router Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Output Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Input Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 05:48:38 --> Language Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Loader Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Controller Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Model Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Model Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Model Class Initialized
DEBUG - 2011-07-02 05:48:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 05:48:38 --> Database Driver Class Initialized
DEBUG - 2011-07-02 05:48:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 05:48:39 --> Helper loaded: url_helper
DEBUG - 2011-07-02 05:48:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 05:48:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 05:48:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 05:48:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 05:48:39 --> Final output sent to browser
DEBUG - 2011-07-02 05:48:39 --> Total execution time: 0.6296
DEBUG - 2011-07-02 05:48:44 --> Config Class Initialized
DEBUG - 2011-07-02 05:48:44 --> Hooks Class Initialized
DEBUG - 2011-07-02 05:48:44 --> Utf8 Class Initialized
DEBUG - 2011-07-02 05:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 05:48:44 --> URI Class Initialized
DEBUG - 2011-07-02 05:48:44 --> Router Class Initialized
ERROR - 2011-07-02 05:48:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-02 05:48:46 --> Config Class Initialized
DEBUG - 2011-07-02 05:48:46 --> Hooks Class Initialized
DEBUG - 2011-07-02 05:48:46 --> Utf8 Class Initialized
DEBUG - 2011-07-02 05:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 05:48:46 --> URI Class Initialized
DEBUG - 2011-07-02 05:48:46 --> Router Class Initialized
ERROR - 2011-07-02 05:48:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-02 10:02:16 --> Config Class Initialized
DEBUG - 2011-07-02 10:02:16 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:02:16 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:02:16 --> URI Class Initialized
DEBUG - 2011-07-02 10:02:16 --> Router Class Initialized
DEBUG - 2011-07-02 10:02:16 --> Output Class Initialized
DEBUG - 2011-07-02 10:02:16 --> Input Class Initialized
DEBUG - 2011-07-02 10:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:02:16 --> Language Class Initialized
DEBUG - 2011-07-02 10:02:16 --> Loader Class Initialized
DEBUG - 2011-07-02 10:02:16 --> Controller Class Initialized
ERROR - 2011-07-02 10:02:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:02:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:02:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:02:17 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:17 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:02:17 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:02:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:02:17 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:02:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:02:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:02:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:02:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:02:17 --> Final output sent to browser
DEBUG - 2011-07-02 10:02:17 --> Total execution time: 0.9471
DEBUG - 2011-07-02 10:02:18 --> Config Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:02:18 --> URI Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Router Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Output Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Input Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:02:18 --> Language Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Loader Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Controller Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:02:18 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:02:19 --> Final output sent to browser
DEBUG - 2011-07-02 10:02:19 --> Total execution time: 0.7467
DEBUG - 2011-07-02 10:02:20 --> Config Class Initialized
DEBUG - 2011-07-02 10:02:20 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:02:20 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:02:20 --> URI Class Initialized
DEBUG - 2011-07-02 10:02:20 --> Router Class Initialized
ERROR - 2011-07-02 10:02:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-02 10:02:36 --> Config Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:02:36 --> URI Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Router Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Output Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Input Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:02:36 --> Language Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Loader Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Controller Class Initialized
ERROR - 2011-07-02 10:02:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:02:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:02:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:02:36 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:02:36 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:02:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:02:36 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:02:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:02:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:02:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:02:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:02:36 --> Final output sent to browser
DEBUG - 2011-07-02 10:02:36 --> Total execution time: 0.0358
DEBUG - 2011-07-02 10:02:36 --> Config Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:02:36 --> URI Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Router Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Output Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Input Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:02:36 --> Language Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Loader Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Controller Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:02:36 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:02:37 --> Final output sent to browser
DEBUG - 2011-07-02 10:02:37 --> Total execution time: 0.6026
DEBUG - 2011-07-02 10:02:53 --> Config Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:02:53 --> URI Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Router Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Output Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Input Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:02:53 --> Language Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Loader Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Controller Class Initialized
ERROR - 2011-07-02 10:02:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:02:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:02:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:02:53 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:02:53 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:02:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:02:53 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:02:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:02:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:02:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:02:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:02:53 --> Final output sent to browser
DEBUG - 2011-07-02 10:02:53 --> Total execution time: 0.0284
DEBUG - 2011-07-02 10:02:54 --> Config Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:02:54 --> URI Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Router Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Output Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Input Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:02:54 --> Language Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Loader Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Controller Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Model Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:02:54 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:02:54 --> Final output sent to browser
DEBUG - 2011-07-02 10:02:54 --> Total execution time: 0.5952
DEBUG - 2011-07-02 10:03:02 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:02 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:02 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:02 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:02 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:02 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:02 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:02 --> Total execution time: 0.0268
DEBUG - 2011-07-02 10:03:02 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:02 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:02 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:02 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:03 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:03 --> Total execution time: 0.6532
DEBUG - 2011-07-02 10:03:09 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:09 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:09 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:09 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:09 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:09 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:09 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:09 --> Total execution time: 0.0340
DEBUG - 2011-07-02 10:03:10 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:10 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:10 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:10 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:10 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:10 --> Total execution time: 0.5690
DEBUG - 2011-07-02 10:03:20 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:20 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:20 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:20 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:20 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:20 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:20 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:20 --> Total execution time: 0.0351
DEBUG - 2011-07-02 10:03:21 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:21 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:21 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:21 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:21 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:21 --> Total execution time: 0.6275
DEBUG - 2011-07-02 10:03:27 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:27 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:27 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:27 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:27 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:27 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:27 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:27 --> Total execution time: 0.0272
DEBUG - 2011-07-02 10:03:27 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:27 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:27 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:27 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:28 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:28 --> Total execution time: 0.5197
DEBUG - 2011-07-02 10:03:32 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:32 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:32 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:32 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:32 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:32 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:32 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:32 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:32 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:32 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:33 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:33 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:33 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:33 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:33 --> Total execution time: 0.0294
DEBUG - 2011-07-02 10:03:33 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:33 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:33 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:33 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:34 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:34 --> Total execution time: 0.5849
DEBUG - 2011-07-02 10:03:38 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:38 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:38 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:38 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:38 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:38 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:38 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:38 --> Total execution time: 0.0291
DEBUG - 2011-07-02 10:03:39 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:39 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:39 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:39 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:39 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:39 --> Total execution time: 0.5417
DEBUG - 2011-07-02 10:03:43 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:43 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:43 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:43 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:43 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:43 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:43 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:43 --> Total execution time: 0.0380
DEBUG - 2011-07-02 10:03:43 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:43 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:43 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:43 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:44 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:44 --> Total execution time: 0.6073
DEBUG - 2011-07-02 10:03:53 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:53 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:53 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:53 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:53 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:53 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:53 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:53 --> Total execution time: 0.0276
DEBUG - 2011-07-02 10:03:53 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:53 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:53 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:53 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:54 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:54 --> Total execution time: 0.5335
DEBUG - 2011-07-02 10:03:59 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:59 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:59 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Controller Class Initialized
ERROR - 2011-07-02 10:03:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:03:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:59 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:59 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:03:59 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:03:59 --> Final output sent to browser
DEBUG - 2011-07-02 10:03:59 --> Total execution time: 0.0285
DEBUG - 2011-07-02 10:03:59 --> Config Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:03:59 --> URI Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Router Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Output Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Input Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:03:59 --> Language Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Loader Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Controller Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Model Class Initialized
DEBUG - 2011-07-02 10:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:03:59 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:04:00 --> Final output sent to browser
DEBUG - 2011-07-02 10:04:00 --> Total execution time: 0.5096
DEBUG - 2011-07-02 10:04:08 --> Config Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:04:08 --> URI Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Router Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Output Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Input Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:04:08 --> Language Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Loader Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Controller Class Initialized
ERROR - 2011-07-02 10:04:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:04:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:04:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:04:08 --> Model Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Model Class Initialized
DEBUG - 2011-07-02 10:04:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:04:08 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:04:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:04:08 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:04:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:04:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:04:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:04:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:04:08 --> Final output sent to browser
DEBUG - 2011-07-02 10:04:08 --> Total execution time: 0.0828
DEBUG - 2011-07-02 10:04:09 --> Config Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:04:09 --> URI Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Router Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Output Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Input Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:04:09 --> Language Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Loader Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Controller Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Model Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Model Class Initialized
DEBUG - 2011-07-02 10:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:04:09 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:04:10 --> Final output sent to browser
DEBUG - 2011-07-02 10:04:10 --> Total execution time: 0.5003
DEBUG - 2011-07-02 10:04:13 --> Config Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:04:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:04:13 --> URI Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Router Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Output Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Input Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:04:13 --> Language Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Loader Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Controller Class Initialized
ERROR - 2011-07-02 10:04:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:04:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:04:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:04:13 --> Model Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Model Class Initialized
DEBUG - 2011-07-02 10:04:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:04:13 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:04:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:04:13 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:04:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:04:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:04:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:04:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:04:13 --> Final output sent to browser
DEBUG - 2011-07-02 10:04:13 --> Total execution time: 0.0273
DEBUG - 2011-07-02 10:04:14 --> Config Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:04:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:04:14 --> URI Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Router Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Output Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Input Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:04:14 --> Language Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Loader Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Controller Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Model Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Model Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:04:14 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:04:14 --> Final output sent to browser
DEBUG - 2011-07-02 10:04:14 --> Total execution time: 0.5005
DEBUG - 2011-07-02 10:05:53 --> Config Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Hooks Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Utf8 Class Initialized
DEBUG - 2011-07-02 10:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 10:05:53 --> URI Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Router Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Output Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Input Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 10:05:53 --> Language Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Loader Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Controller Class Initialized
ERROR - 2011-07-02 10:05:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 10:05:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 10:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:05:53 --> Model Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Model Class Initialized
DEBUG - 2011-07-02 10:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 10:05:53 --> Database Driver Class Initialized
DEBUG - 2011-07-02 10:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 10:05:53 --> Helper loaded: url_helper
DEBUG - 2011-07-02 10:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 10:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 10:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 10:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 10:05:53 --> Final output sent to browser
DEBUG - 2011-07-02 10:05:53 --> Total execution time: 0.0270
DEBUG - 2011-07-02 11:18:07 --> Config Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:18:07 --> URI Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Router Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Output Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Input Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:18:07 --> Language Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Loader Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Controller Class Initialized
ERROR - 2011-07-02 11:18:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:18:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:18:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:18:07 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:18:07 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:18:07 --> Final output sent to browser
DEBUG - 2011-07-02 11:18:07 --> Total execution time: 0.3787
DEBUG - 2011-07-02 11:18:09 --> Config Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:18:09 --> URI Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Router Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Output Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Input Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:18:09 --> Language Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Loader Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Controller Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Model Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Model Class Initialized
DEBUG - 2011-07-02 11:18:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:18:09 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:18:10 --> Final output sent to browser
DEBUG - 2011-07-02 11:18:10 --> Total execution time: 0.6666
DEBUG - 2011-07-02 11:34:49 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:49 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:49 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:49 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:49 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:50 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Controller Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:50 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:34:51 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:51 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:51 --> Total execution time: 1.4545
DEBUG - 2011-07-02 11:34:53 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:53 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:53 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Controller Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:53 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:34:54 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:54 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:54 --> Total execution time: 0.5044
DEBUG - 2011-07-02 11:34:56 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:56 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:56 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Controller Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:56 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:57 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:57 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Controller Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:57 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:34:57 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:57 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:57 --> Total execution time: 0.0519
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:34:57 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:57 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:57 --> Total execution time: 0.5371
DEBUG - 2011-07-02 11:34:57 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:57 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:57 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Controller Class Initialized
ERROR - 2011-07-02 11:34:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:34:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:57 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:34:57 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:57 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:57 --> Total execution time: 0.1317
DEBUG - 2011-07-02 11:34:57 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:57 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:57 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Controller Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:57 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:34:57 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:57 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:57 --> Total execution time: 0.0690
DEBUG - 2011-07-02 11:34:57 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:57 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:57 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Controller Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:57 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:34:57 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:57 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:57 --> Total execution time: 0.0502
DEBUG - 2011-07-02 11:34:58 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:58 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:58 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Controller Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:58 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:34:58 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:58 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:58 --> Total execution time: 0.0534
DEBUG - 2011-07-02 11:34:59 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:59 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:59 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Controller Class Initialized
ERROR - 2011-07-02 11:34:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:34:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:34:59 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:59 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:34:59 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:59 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:59 --> Total execution time: 0.0543
DEBUG - 2011-07-02 11:34:59 --> Config Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:34:59 --> URI Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Router Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Output Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Input Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:34:59 --> Language Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Loader Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Controller Class Initialized
ERROR - 2011-07-02 11:34:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:34:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:34:59 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Model Class Initialized
DEBUG - 2011-07-02 11:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:34:59 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:34:59 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:34:59 --> Final output sent to browser
DEBUG - 2011-07-02 11:34:59 --> Total execution time: 0.0335
DEBUG - 2011-07-02 11:35:00 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:00 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:00 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:00 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:00 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:00 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:00 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:00 --> Total execution time: 0.0479
DEBUG - 2011-07-02 11:35:01 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:01 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:01 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:01 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:01 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:01 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:01 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:01 --> Total execution time: 0.0335
DEBUG - 2011-07-02 11:35:02 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:02 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:02 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:02 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:02 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:02 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:02 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:02 --> Total execution time: 0.0281
DEBUG - 2011-07-02 11:35:04 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:04 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:04 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Controller Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:04 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:35:04 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:04 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:04 --> Total execution time: 0.1434
DEBUG - 2011-07-02 11:35:05 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:05 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:05 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Controller Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:05 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:35:05 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:05 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:05 --> Total execution time: 0.0651
DEBUG - 2011-07-02 11:35:05 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:05 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:05 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Controller Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:05 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:35:05 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:05 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:05 --> Total execution time: 0.1750
DEBUG - 2011-07-02 11:35:07 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:07 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:07 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Controller Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:07 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:07 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:07 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Controller Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:07 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:07 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:07 --> Database Driver Class Initialized
ERROR - 2011-07-02 11:35:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:07 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:35:07 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:07 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:07 --> Total execution time: 0.0644
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:07 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:07 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:07 --> Total execution time: 0.0596
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:07 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:07 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:07 --> Total execution time: 0.0623
DEBUG - 2011-07-02 11:35:08 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:08 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:08 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:08 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:08 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:08 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:08 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:08 --> Total execution time: 0.0679
DEBUG - 2011-07-02 11:35:08 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:08 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:08 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:08 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:08 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:08 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:08 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:08 --> Total execution time: 0.0288
DEBUG - 2011-07-02 11:35:13 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:13 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:13 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:13 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:13 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:13 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:13 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:13 --> Total execution time: 0.0266
DEBUG - 2011-07-02 11:35:17 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:17 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:17 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Controller Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:17 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:35:18 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:18 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:18 --> Total execution time: 0.0733
DEBUG - 2011-07-02 11:35:23 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:23 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:23 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:23 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:23 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:23 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:23 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:23 --> Total execution time: 0.0275
DEBUG - 2011-07-02 11:35:32 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:32 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:32 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Controller Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:32 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 11:35:33 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:33 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:33 --> Total execution time: 0.3431
DEBUG - 2011-07-02 11:35:45 --> Config Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Hooks Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Utf8 Class Initialized
DEBUG - 2011-07-02 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 11:35:45 --> URI Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Router Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Output Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Input Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 11:35:45 --> Language Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Loader Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Controller Class Initialized
ERROR - 2011-07-02 11:35:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 11:35:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 11:35:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:45 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Model Class Initialized
DEBUG - 2011-07-02 11:35:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 11:35:45 --> Database Driver Class Initialized
DEBUG - 2011-07-02 11:35:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 11:35:45 --> Helper loaded: url_helper
DEBUG - 2011-07-02 11:35:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 11:35:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 11:35:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 11:35:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 11:35:45 --> Final output sent to browser
DEBUG - 2011-07-02 11:35:45 --> Total execution time: 0.0493
DEBUG - 2011-07-02 12:09:45 --> Config Class Initialized
DEBUG - 2011-07-02 12:09:45 --> Hooks Class Initialized
DEBUG - 2011-07-02 12:09:45 --> Utf8 Class Initialized
DEBUG - 2011-07-02 12:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 12:09:45 --> URI Class Initialized
DEBUG - 2011-07-02 12:09:45 --> Router Class Initialized
DEBUG - 2011-07-02 12:09:45 --> Output Class Initialized
DEBUG - 2011-07-02 12:09:45 --> Input Class Initialized
DEBUG - 2011-07-02 12:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 12:09:45 --> Language Class Initialized
DEBUG - 2011-07-02 12:09:45 --> Loader Class Initialized
DEBUG - 2011-07-02 12:09:45 --> Controller Class Initialized
DEBUG - 2011-07-02 12:09:46 --> Model Class Initialized
DEBUG - 2011-07-02 12:09:46 --> Model Class Initialized
DEBUG - 2011-07-02 12:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 12:09:46 --> Database Driver Class Initialized
DEBUG - 2011-07-02 12:09:46 --> Final output sent to browser
DEBUG - 2011-07-02 12:09:46 --> Total execution time: 0.9695
DEBUG - 2011-07-02 13:45:22 --> Config Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Hooks Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Utf8 Class Initialized
DEBUG - 2011-07-02 13:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 13:45:22 --> URI Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Router Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Output Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Input Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 13:45:22 --> Language Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Loader Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Controller Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Model Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Model Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Model Class Initialized
DEBUG - 2011-07-02 13:45:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 13:45:22 --> Database Driver Class Initialized
DEBUG - 2011-07-02 13:45:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 13:45:23 --> Helper loaded: url_helper
DEBUG - 2011-07-02 13:45:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 13:45:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 13:45:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 13:45:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 13:45:23 --> Final output sent to browser
DEBUG - 2011-07-02 13:45:23 --> Total execution time: 0.9614
DEBUG - 2011-07-02 13:45:26 --> Config Class Initialized
DEBUG - 2011-07-02 13:45:26 --> Hooks Class Initialized
DEBUG - 2011-07-02 13:45:26 --> Utf8 Class Initialized
DEBUG - 2011-07-02 13:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 13:45:26 --> URI Class Initialized
DEBUG - 2011-07-02 13:45:26 --> Router Class Initialized
ERROR - 2011-07-02 13:45:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-02 13:57:51 --> Config Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Hooks Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Utf8 Class Initialized
DEBUG - 2011-07-02 13:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 13:57:51 --> URI Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Router Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Output Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Input Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 13:57:51 --> Language Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Loader Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Controller Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Model Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Model Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Model Class Initialized
DEBUG - 2011-07-02 13:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 13:57:51 --> Database Driver Class Initialized
DEBUG - 2011-07-02 13:57:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 13:57:51 --> Helper loaded: url_helper
DEBUG - 2011-07-02 13:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 13:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 13:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 13:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 13:57:51 --> Final output sent to browser
DEBUG - 2011-07-02 13:57:51 --> Total execution time: 0.2042
DEBUG - 2011-07-02 13:57:52 --> Config Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Hooks Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Utf8 Class Initialized
DEBUG - 2011-07-02 13:57:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 13:57:52 --> URI Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Router Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Output Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Input Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 13:57:52 --> Language Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Loader Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Controller Class Initialized
ERROR - 2011-07-02 13:57:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 13:57:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 13:57:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 13:57:52 --> Model Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Model Class Initialized
DEBUG - 2011-07-02 13:57:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 13:57:52 --> Database Driver Class Initialized
DEBUG - 2011-07-02 13:57:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 13:57:52 --> Helper loaded: url_helper
DEBUG - 2011-07-02 13:57:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 13:57:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 13:57:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 13:57:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 13:57:52 --> Final output sent to browser
DEBUG - 2011-07-02 13:57:52 --> Total execution time: 0.1036
DEBUG - 2011-07-02 14:10:46 --> Config Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:10:46 --> URI Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Router Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Output Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Input Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:10:46 --> Language Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Loader Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Controller Class Initialized
ERROR - 2011-07-02 14:10:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:10:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:10:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:10:46 --> Model Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Model Class Initialized
DEBUG - 2011-07-02 14:10:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:10:46 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:10:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:10:46 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:10:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:10:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:10:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:10:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:10:46 --> Final output sent to browser
DEBUG - 2011-07-02 14:10:46 --> Total execution time: 0.1251
DEBUG - 2011-07-02 14:10:49 --> Config Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:10:49 --> URI Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Router Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Output Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Input Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:10:49 --> Language Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Loader Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Controller Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Model Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Model Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:10:49 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:10:49 --> Final output sent to browser
DEBUG - 2011-07-02 14:10:49 --> Total execution time: 0.6829
DEBUG - 2011-07-02 14:11:01 --> Config Class Initialized
DEBUG - 2011-07-02 14:11:01 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:11:01 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:11:01 --> URI Class Initialized
DEBUG - 2011-07-02 14:11:01 --> Router Class Initialized
ERROR - 2011-07-02 14:11:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-02 14:41:01 --> Config Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:41:01 --> URI Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Router Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Output Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Input Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:41:01 --> Language Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Loader Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Controller Class Initialized
ERROR - 2011-07-02 14:41:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:41:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:41:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:41:01 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:41:01 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:41:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:41:01 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:41:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:41:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:41:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:41:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:41:01 --> Final output sent to browser
DEBUG - 2011-07-02 14:41:01 --> Total execution time: 0.3501
DEBUG - 2011-07-02 14:41:03 --> Config Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:41:03 --> URI Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Router Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Output Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Input Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:41:03 --> Language Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Loader Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Controller Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:41:03 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:41:03 --> Final output sent to browser
DEBUG - 2011-07-02 14:41:03 --> Total execution time: 0.7300
DEBUG - 2011-07-02 14:41:34 --> Config Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:41:34 --> URI Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Router Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Output Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Input Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:41:34 --> Language Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Loader Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Controller Class Initialized
ERROR - 2011-07-02 14:41:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:41:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:41:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:41:34 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:41:34 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:41:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:41:34 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:41:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:41:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:41:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:41:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:41:34 --> Final output sent to browser
DEBUG - 2011-07-02 14:41:34 --> Total execution time: 0.0270
DEBUG - 2011-07-02 14:41:34 --> Config Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:41:34 --> URI Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Router Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Output Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Input Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:41:34 --> Language Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Loader Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Controller Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:41:34 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:41:35 --> Final output sent to browser
DEBUG - 2011-07-02 14:41:35 --> Total execution time: 0.6574
DEBUG - 2011-07-02 14:41:45 --> Config Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:41:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:41:45 --> URI Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Router Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Output Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Input Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:41:45 --> Language Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Loader Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Controller Class Initialized
ERROR - 2011-07-02 14:41:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:41:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:41:45 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:41:45 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:41:45 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:41:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:41:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:41:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:41:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:41:45 --> Final output sent to browser
DEBUG - 2011-07-02 14:41:45 --> Total execution time: 0.0272
DEBUG - 2011-07-02 14:41:46 --> Config Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:41:46 --> URI Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Router Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Output Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Input Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:41:46 --> Language Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Loader Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Controller Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:41:46 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:41:46 --> Final output sent to browser
DEBUG - 2011-07-02 14:41:46 --> Total execution time: 0.5735
DEBUG - 2011-07-02 14:41:57 --> Config Class Initialized
DEBUG - 2011-07-02 14:41:57 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:41:57 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:41:57 --> URI Class Initialized
DEBUG - 2011-07-02 14:41:57 --> Router Class Initialized
DEBUG - 2011-07-02 14:41:57 --> Output Class Initialized
DEBUG - 2011-07-02 14:41:57 --> Input Class Initialized
DEBUG - 2011-07-02 14:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:41:57 --> Language Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Loader Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Controller Class Initialized
ERROR - 2011-07-02 14:41:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:41:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:41:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:41:58 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:41:58 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:41:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:41:58 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:41:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:41:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:41:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:41:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:41:58 --> Final output sent to browser
DEBUG - 2011-07-02 14:41:58 --> Total execution time: 0.0274
DEBUG - 2011-07-02 14:41:58 --> Config Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:41:58 --> URI Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Router Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Output Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Input Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:41:58 --> Language Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Loader Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Controller Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Model Class Initialized
DEBUG - 2011-07-02 14:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:41:58 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:41:59 --> Final output sent to browser
DEBUG - 2011-07-02 14:41:59 --> Total execution time: 0.5620
DEBUG - 2011-07-02 14:42:03 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:03 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:03 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:03 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:03 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:03 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:03 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:03 --> Total execution time: 0.0307
DEBUG - 2011-07-02 14:42:04 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:04 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:04 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Controller Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:04 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:04 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:04 --> Total execution time: 0.5933
DEBUG - 2011-07-02 14:42:08 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:08 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:08 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:08 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:08 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:08 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:08 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:08 --> Total execution time: 0.0288
DEBUG - 2011-07-02 14:42:09 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:09 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:09 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Controller Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:09 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:10 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:10 --> Total execution time: 0.6073
DEBUG - 2011-07-02 14:42:14 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:14 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:14 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:14 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:14 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:14 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:14 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:14 --> Total execution time: 0.0303
DEBUG - 2011-07-02 14:42:15 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:15 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:15 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Controller Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:15 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:15 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:15 --> Total execution time: 0.5498
DEBUG - 2011-07-02 14:42:19 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:19 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:19 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:19 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:19 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:19 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:19 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:19 --> Total execution time: 0.0287
DEBUG - 2011-07-02 14:42:20 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:20 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:20 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Controller Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:20 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:20 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:20 --> Total execution time: 0.5815
DEBUG - 2011-07-02 14:42:29 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:29 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:29 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:29 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:29 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:29 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:29 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:29 --> Total execution time: 0.0404
DEBUG - 2011-07-02 14:42:29 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:29 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:29 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Controller Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:29 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:30 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:30 --> Total execution time: 0.4901
DEBUG - 2011-07-02 14:42:37 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:37 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:37 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:37 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:37 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:37 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:37 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:37 --> Total execution time: 0.0272
DEBUG - 2011-07-02 14:42:38 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:38 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:38 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Controller Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:38 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:38 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:38 --> Total execution time: 0.5189
DEBUG - 2011-07-02 14:42:43 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:43 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:43 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:43 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:43 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:43 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:43 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:43 --> Total execution time: 0.0329
DEBUG - 2011-07-02 14:42:44 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:44 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:44 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Controller Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:44 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:44 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:44 --> Total execution time: 0.5042
DEBUG - 2011-07-02 14:42:52 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:52 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:52 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:52 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:52 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:52 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:52 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:52 --> Total execution time: 0.0308
DEBUG - 2011-07-02 14:42:53 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:53 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:53 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Controller Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:53 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:54 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:54 --> Total execution time: 0.5266
DEBUG - 2011-07-02 14:42:59 --> Config Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:42:59 --> URI Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Router Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Output Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Input Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:42:59 --> Language Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Loader Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Controller Class Initialized
ERROR - 2011-07-02 14:42:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:42:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:59 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Model Class Initialized
DEBUG - 2011-07-02 14:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:42:59 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:42:59 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:42:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:42:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:42:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:42:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:42:59 --> Final output sent to browser
DEBUG - 2011-07-02 14:42:59 --> Total execution time: 0.0435
DEBUG - 2011-07-02 14:43:00 --> Config Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:43:00 --> URI Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Router Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Output Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Input Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:43:00 --> Language Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Loader Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Controller Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:43:00 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:43:00 --> Final output sent to browser
DEBUG - 2011-07-02 14:43:00 --> Total execution time: 0.5008
DEBUG - 2011-07-02 14:43:02 --> Config Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:43:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:43:02 --> URI Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Router Class Initialized
ERROR - 2011-07-02 14:43:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-02 14:43:02 --> Config Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:43:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:43:02 --> URI Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Router Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Output Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Input Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:43:02 --> Language Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Loader Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Controller Class Initialized
ERROR - 2011-07-02 14:43:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:43:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:43:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:43:02 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:43:02 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:43:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:43:02 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:43:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:43:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:43:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:43:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:43:02 --> Final output sent to browser
DEBUG - 2011-07-02 14:43:02 --> Total execution time: 0.0280
DEBUG - 2011-07-02 14:43:06 --> Config Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:43:06 --> URI Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Router Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Output Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Input Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:43:06 --> Language Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Loader Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Controller Class Initialized
ERROR - 2011-07-02 14:43:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:43:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:43:06 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:43:06 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:43:06 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:43:06 --> Final output sent to browser
DEBUG - 2011-07-02 14:43:06 --> Total execution time: 0.0305
DEBUG - 2011-07-02 14:43:07 --> Config Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:43:07 --> URI Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Router Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Output Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Input Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:43:07 --> Language Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Loader Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Controller Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:43:07 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:43:07 --> Final output sent to browser
DEBUG - 2011-07-02 14:43:07 --> Total execution time: 0.4567
DEBUG - 2011-07-02 14:43:12 --> Config Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:43:12 --> URI Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Router Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Output Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Input Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:43:12 --> Language Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Loader Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Controller Class Initialized
ERROR - 2011-07-02 14:43:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 14:43:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 14:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:43:12 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:43:12 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 14:43:12 --> Helper loaded: url_helper
DEBUG - 2011-07-02 14:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 14:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 14:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 14:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 14:43:12 --> Final output sent to browser
DEBUG - 2011-07-02 14:43:12 --> Total execution time: 0.0282
DEBUG - 2011-07-02 14:43:12 --> Config Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Hooks Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Utf8 Class Initialized
DEBUG - 2011-07-02 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 14:43:12 --> URI Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Router Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Output Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Input Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 14:43:12 --> Language Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Loader Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Controller Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Model Class Initialized
DEBUG - 2011-07-02 14:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 14:43:12 --> Database Driver Class Initialized
DEBUG - 2011-07-02 14:43:13 --> Final output sent to browser
DEBUG - 2011-07-02 14:43:13 --> Total execution time: 0.6989
DEBUG - 2011-07-02 15:47:36 --> Config Class Initialized
DEBUG - 2011-07-02 15:47:36 --> Hooks Class Initialized
DEBUG - 2011-07-02 15:47:36 --> Utf8 Class Initialized
DEBUG - 2011-07-02 15:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 15:47:36 --> URI Class Initialized
DEBUG - 2011-07-02 15:47:37 --> Router Class Initialized
DEBUG - 2011-07-02 15:47:37 --> Output Class Initialized
DEBUG - 2011-07-02 15:47:37 --> Input Class Initialized
DEBUG - 2011-07-02 15:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 15:47:37 --> Language Class Initialized
DEBUG - 2011-07-02 15:47:37 --> Loader Class Initialized
DEBUG - 2011-07-02 15:47:37 --> Controller Class Initialized
ERROR - 2011-07-02 15:47:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 15:47:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 15:47:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 15:47:37 --> Model Class Initialized
DEBUG - 2011-07-02 15:47:37 --> Model Class Initialized
DEBUG - 2011-07-02 15:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 15:47:38 --> Database Driver Class Initialized
DEBUG - 2011-07-02 15:47:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 15:47:38 --> Helper loaded: url_helper
DEBUG - 2011-07-02 15:47:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 15:47:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 15:47:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 15:47:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 18:28:50 --> Config Class Initialized
DEBUG - 2011-07-02 18:28:50 --> Hooks Class Initialized
DEBUG - 2011-07-02 18:28:50 --> Utf8 Class Initialized
DEBUG - 2011-07-02 18:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 18:28:50 --> URI Class Initialized
DEBUG - 2011-07-02 18:28:50 --> Router Class Initialized
ERROR - 2011-07-02 18:28:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-02 18:28:52 --> Config Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Hooks Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Utf8 Class Initialized
DEBUG - 2011-07-02 18:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 18:28:52 --> URI Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Router Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Output Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Input Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 18:28:52 --> Language Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Loader Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Controller Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Model Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Model Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Model Class Initialized
DEBUG - 2011-07-02 18:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 18:28:52 --> Database Driver Class Initialized
DEBUG - 2011-07-02 18:28:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 18:28:52 --> Helper loaded: url_helper
DEBUG - 2011-07-02 18:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 18:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 18:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 18:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 18:28:52 --> Final output sent to browser
DEBUG - 2011-07-02 18:28:52 --> Total execution time: 0.5454
DEBUG - 2011-07-02 19:41:26 --> Config Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Hooks Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Utf8 Class Initialized
DEBUG - 2011-07-02 19:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 19:41:26 --> URI Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Router Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Output Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Input Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 19:41:26 --> Language Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Loader Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Controller Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Model Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Model Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Model Class Initialized
DEBUG - 2011-07-02 19:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 19:41:26 --> Database Driver Class Initialized
DEBUG - 2011-07-02 19:41:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-02 19:41:26 --> Helper loaded: url_helper
DEBUG - 2011-07-02 19:41:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 19:41:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 19:41:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 19:41:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 19:41:26 --> Final output sent to browser
DEBUG - 2011-07-02 19:41:26 --> Total execution time: 0.6321
DEBUG - 2011-07-02 19:41:28 --> Config Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Hooks Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Utf8 Class Initialized
DEBUG - 2011-07-02 19:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 19:41:28 --> URI Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Router Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Output Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Input Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 19:41:28 --> Language Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Loader Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Controller Class Initialized
ERROR - 2011-07-02 19:41:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-02 19:41:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-02 19:41:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 19:41:28 --> Model Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Model Class Initialized
DEBUG - 2011-07-02 19:41:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-02 19:41:28 --> Database Driver Class Initialized
DEBUG - 2011-07-02 19:41:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-02 19:41:28 --> Helper loaded: url_helper
DEBUG - 2011-07-02 19:41:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 19:41:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 19:41:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 19:41:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 19:41:28 --> Final output sent to browser
DEBUG - 2011-07-02 19:41:28 --> Total execution time: 0.1250
DEBUG - 2011-07-02 22:11:36 --> Config Class Initialized
DEBUG - 2011-07-02 22:11:36 --> Hooks Class Initialized
DEBUG - 2011-07-02 22:11:36 --> Utf8 Class Initialized
DEBUG - 2011-07-02 22:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-02 22:11:36 --> URI Class Initialized
DEBUG - 2011-07-02 22:11:36 --> Router Class Initialized
DEBUG - 2011-07-02 22:11:36 --> No URI present. Default controller set.
DEBUG - 2011-07-02 22:11:36 --> Output Class Initialized
DEBUG - 2011-07-02 22:11:36 --> Input Class Initialized
DEBUG - 2011-07-02 22:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-02 22:11:36 --> Language Class Initialized
DEBUG - 2011-07-02 22:11:36 --> Loader Class Initialized
DEBUG - 2011-07-02 22:11:36 --> Controller Class Initialized
DEBUG - 2011-07-02 22:11:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-02 22:11:36 --> Helper loaded: url_helper
DEBUG - 2011-07-02 22:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-02 22:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-02 22:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-02 22:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-02 22:11:36 --> Final output sent to browser
DEBUG - 2011-07-02 22:11:36 --> Total execution time: 0.2746

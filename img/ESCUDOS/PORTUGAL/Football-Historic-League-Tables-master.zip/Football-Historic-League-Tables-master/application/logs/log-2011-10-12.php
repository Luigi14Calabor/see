<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-12 02:06:46 --> Config Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:06:46 --> URI Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Router Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Output Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Input Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:06:46 --> Language Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Loader Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Controller Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Model Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Model Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Model Class Initialized
DEBUG - 2011-10-12 02:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:06:46 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:06:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:06:48 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:06:48 --> Final output sent to browser
DEBUG - 2011-10-12 02:06:48 --> Total execution time: 2.3223
DEBUG - 2011-10-12 02:06:56 --> Config Class Initialized
DEBUG - 2011-10-12 02:06:56 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:06:56 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:06:56 --> URI Class Initialized
DEBUG - 2011-10-12 02:06:56 --> Router Class Initialized
ERROR - 2011-10-12 02:06:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 02:07:02 --> Config Class Initialized
DEBUG - 2011-10-12 02:07:02 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:07:02 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:07:02 --> URI Class Initialized
DEBUG - 2011-10-12 02:07:02 --> Router Class Initialized
DEBUG - 2011-10-12 02:07:02 --> No URI present. Default controller set.
DEBUG - 2011-10-12 02:07:02 --> Output Class Initialized
DEBUG - 2011-10-12 02:07:02 --> Input Class Initialized
DEBUG - 2011-10-12 02:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:07:02 --> Language Class Initialized
DEBUG - 2011-10-12 02:07:02 --> Loader Class Initialized
DEBUG - 2011-10-12 02:07:02 --> Controller Class Initialized
DEBUG - 2011-10-12 02:07:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-12 02:07:02 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:07:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:07:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:07:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:07:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:07:02 --> Final output sent to browser
DEBUG - 2011-10-12 02:07:02 --> Total execution time: 0.1290
DEBUG - 2011-10-12 02:07:42 --> Config Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:07:42 --> URI Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Router Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Output Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Input Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:07:42 --> Language Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Loader Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Controller Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Model Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Model Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Model Class Initialized
DEBUG - 2011-10-12 02:07:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:07:42 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:07:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:07:43 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:07:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:07:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:07:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:07:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:07:43 --> Final output sent to browser
DEBUG - 2011-10-12 02:07:43 --> Total execution time: 0.9425
DEBUG - 2011-10-12 02:07:46 --> Config Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:07:46 --> URI Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Router Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Output Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Input Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:07:46 --> Language Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Loader Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Controller Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Model Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Model Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Model Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:07:46 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Config Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:07:46 --> URI Class Initialized
DEBUG - 2011-10-12 02:07:46 --> Router Class Initialized
ERROR - 2011-10-12 02:07:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 02:07:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:07:46 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:07:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:07:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:07:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:07:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:07:46 --> Final output sent to browser
DEBUG - 2011-10-12 02:07:46 --> Total execution time: 0.1414
DEBUG - 2011-10-12 02:09:42 --> Config Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:09:42 --> URI Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Router Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Output Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Input Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:09:42 --> Language Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Loader Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Controller Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Model Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Model Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Model Class Initialized
DEBUG - 2011-10-12 02:09:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:09:42 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:09:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:09:43 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:09:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:09:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:09:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:09:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:09:43 --> Final output sent to browser
DEBUG - 2011-10-12 02:09:43 --> Total execution time: 0.9834
DEBUG - 2011-10-12 02:09:45 --> Config Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:09:45 --> URI Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Router Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Output Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Input Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:09:45 --> Language Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Loader Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Controller Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Model Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Model Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Model Class Initialized
DEBUG - 2011-10-12 02:09:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:09:45 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:09:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:09:45 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:09:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:09:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:09:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:09:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:09:45 --> Final output sent to browser
DEBUG - 2011-10-12 02:09:45 --> Total execution time: 0.0554
DEBUG - 2011-10-12 02:09:47 --> Config Class Initialized
DEBUG - 2011-10-12 02:09:47 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:09:47 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:09:47 --> URI Class Initialized
DEBUG - 2011-10-12 02:09:47 --> Router Class Initialized
ERROR - 2011-10-12 02:09:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 02:10:17 --> Config Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:10:17 --> URI Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Router Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Output Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Input Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:10:17 --> Language Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Loader Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Controller Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:10:17 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:10:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:10:18 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:10:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:10:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:10:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:10:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:10:18 --> Final output sent to browser
DEBUG - 2011-10-12 02:10:18 --> Total execution time: 0.5714
DEBUG - 2011-10-12 02:10:20 --> Config Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:10:20 --> URI Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Router Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Output Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Input Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:10:20 --> Language Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Loader Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Controller Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:10:20 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:10:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:10:20 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:10:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:10:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:10:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:10:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:10:20 --> Final output sent to browser
DEBUG - 2011-10-12 02:10:20 --> Total execution time: 0.0822
DEBUG - 2011-10-12 02:10:23 --> Config Class Initialized
DEBUG - 2011-10-12 02:10:23 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:10:23 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:10:23 --> URI Class Initialized
DEBUG - 2011-10-12 02:10:23 --> Router Class Initialized
ERROR - 2011-10-12 02:10:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 02:10:57 --> Config Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:10:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:10:57 --> URI Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Router Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Output Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Input Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:10:57 --> Language Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Loader Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Controller Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Model Class Initialized
DEBUG - 2011-10-12 02:10:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:10:57 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:10:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:10:58 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:10:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:10:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:10:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:10:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:10:58 --> Final output sent to browser
DEBUG - 2011-10-12 02:10:58 --> Total execution time: 0.6813
DEBUG - 2011-10-12 02:11:01 --> Config Class Initialized
DEBUG - 2011-10-12 02:11:01 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:11:01 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:11:01 --> URI Class Initialized
DEBUG - 2011-10-12 02:11:01 --> Router Class Initialized
ERROR - 2011-10-12 02:11:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 02:11:02 --> Config Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:11:02 --> URI Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Router Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Output Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Input Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 02:11:02 --> Language Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Loader Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Controller Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Model Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Model Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Model Class Initialized
DEBUG - 2011-10-12 02:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 02:11:02 --> Database Driver Class Initialized
DEBUG - 2011-10-12 02:11:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 02:11:02 --> Helper loaded: url_helper
DEBUG - 2011-10-12 02:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 02:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 02:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 02:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 02:11:02 --> Final output sent to browser
DEBUG - 2011-10-12 02:11:02 --> Total execution time: 0.0562
DEBUG - 2011-10-12 02:11:53 --> Config Class Initialized
DEBUG - 2011-10-12 02:11:53 --> Hooks Class Initialized
DEBUG - 2011-10-12 02:11:53 --> Utf8 Class Initialized
DEBUG - 2011-10-12 02:11:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 02:11:53 --> URI Class Initialized
DEBUG - 2011-10-12 02:11:53 --> Router Class Initialized
ERROR - 2011-10-12 02:11:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 09:19:49 --> Config Class Initialized
DEBUG - 2011-10-12 09:19:49 --> Hooks Class Initialized
DEBUG - 2011-10-12 09:19:49 --> Utf8 Class Initialized
DEBUG - 2011-10-12 09:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 09:19:49 --> URI Class Initialized
DEBUG - 2011-10-12 09:19:49 --> Router Class Initialized
DEBUG - 2011-10-12 09:19:49 --> No URI present. Default controller set.
DEBUG - 2011-10-12 09:19:49 --> Output Class Initialized
DEBUG - 2011-10-12 09:19:49 --> Input Class Initialized
DEBUG - 2011-10-12 09:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 09:19:49 --> Language Class Initialized
DEBUG - 2011-10-12 09:19:49 --> Loader Class Initialized
DEBUG - 2011-10-12 09:19:49 --> Controller Class Initialized
DEBUG - 2011-10-12 09:19:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-12 09:19:49 --> Helper loaded: url_helper
DEBUG - 2011-10-12 09:19:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 09:19:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 09:19:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 09:19:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 09:19:49 --> Final output sent to browser
DEBUG - 2011-10-12 09:19:49 --> Total execution time: 0.2759
DEBUG - 2011-10-12 11:06:42 --> Config Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:06:42 --> URI Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Router Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Output Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Input Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:06:42 --> Language Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Loader Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Controller Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Model Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Model Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Model Class Initialized
DEBUG - 2011-10-12 11:06:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:06:43 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:06:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:06:43 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:06:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:06:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:06:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:06:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:06:43 --> Final output sent to browser
DEBUG - 2011-10-12 11:06:43 --> Total execution time: 1.0834
DEBUG - 2011-10-12 11:06:53 --> Config Class Initialized
DEBUG - 2011-10-12 11:06:53 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:06:53 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:06:53 --> URI Class Initialized
DEBUG - 2011-10-12 11:06:53 --> Router Class Initialized
ERROR - 2011-10-12 11:06:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:07:02 --> Config Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:07:02 --> URI Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Router Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Output Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Input Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:07:02 --> Language Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Loader Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Controller Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Model Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Model Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Model Class Initialized
DEBUG - 2011-10-12 11:07:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:07:02 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:07:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:07:04 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:07:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:07:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:07:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:07:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:07:04 --> Final output sent to browser
DEBUG - 2011-10-12 11:07:04 --> Total execution time: 2.1124
DEBUG - 2011-10-12 11:07:10 --> Config Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:07:10 --> URI Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Router Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Output Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Input Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:07:10 --> Language Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Loader Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Controller Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Model Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Model Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Model Class Initialized
DEBUG - 2011-10-12 11:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:07:10 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:07:11 --> Config Class Initialized
DEBUG - 2011-10-12 11:07:11 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:07:11 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:07:11 --> URI Class Initialized
DEBUG - 2011-10-12 11:07:11 --> Router Class Initialized
ERROR - 2011-10-12 11:07:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:07:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:07:11 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:07:11 --> Final output sent to browser
DEBUG - 2011-10-12 11:07:11 --> Total execution time: 0.7789
DEBUG - 2011-10-12 11:07:19 --> Config Class Initialized
DEBUG - 2011-10-12 11:07:19 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:07:19 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:07:19 --> URI Class Initialized
DEBUG - 2011-10-12 11:07:19 --> Router Class Initialized
ERROR - 2011-10-12 11:07:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:07:37 --> Config Class Initialized
DEBUG - 2011-10-12 11:07:37 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:07:37 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:07:37 --> URI Class Initialized
DEBUG - 2011-10-12 11:07:37 --> Router Class Initialized
ERROR - 2011-10-12 11:07:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:08:32 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:32 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Router Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Output Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Input Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:08:32 --> Language Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Loader Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Controller Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:08:32 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:08:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:08:32 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:08:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:08:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:08:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:08:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:08:32 --> Final output sent to browser
DEBUG - 2011-10-12 11:08:32 --> Total execution time: 0.3441
DEBUG - 2011-10-12 11:08:37 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:37 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Router Class Initialized
ERROR - 2011-10-12 11:08:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:08:37 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:37 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Router Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Output Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Input Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:08:37 --> Language Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Loader Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Controller Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:08:37 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:08:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:08:38 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:08:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:08:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:08:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:08:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:08:38 --> Final output sent to browser
DEBUG - 2011-10-12 11:08:38 --> Total execution time: 0.9913
DEBUG - 2011-10-12 11:08:40 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:40 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Router Class Initialized
ERROR - 2011-10-12 11:08:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-12 11:08:40 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:40 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Router Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Output Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Input Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:08:40 --> Language Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Loader Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Controller Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:08:40 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:08:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:08:40 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:08:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:08:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:08:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:08:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:08:40 --> Final output sent to browser
DEBUG - 2011-10-12 11:08:40 --> Total execution time: 0.0608
DEBUG - 2011-10-12 11:08:41 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:41 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Router Class Initialized
ERROR - 2011-10-12 11:08:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:08:41 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:41 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Router Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Output Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Input Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:08:41 --> Language Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Loader Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Controller Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:08:41 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:08:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:08:42 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:08:42 --> Final output sent to browser
DEBUG - 2011-10-12 11:08:42 --> Total execution time: 0.6328
DEBUG - 2011-10-12 11:08:43 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:43 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Router Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Output Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Input Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:08:43 --> Language Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Loader Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Controller Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:08:43 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:08:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:08:43 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:08:43 --> Final output sent to browser
DEBUG - 2011-10-12 11:08:43 --> Total execution time: 0.1110
DEBUG - 2011-10-12 11:08:51 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:51 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:51 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:51 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:51 --> Router Class Initialized
ERROR - 2011-10-12 11:08:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:08:59 --> Config Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:08:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:08:59 --> URI Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Router Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Output Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Input Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:08:59 --> Language Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Loader Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Controller Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Model Class Initialized
DEBUG - 2011-10-12 11:08:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:08:59 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:08:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:08:59 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:08:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:08:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:08:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:08:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:08:59 --> Final output sent to browser
DEBUG - 2011-10-12 11:08:59 --> Total execution time: 0.0471
DEBUG - 2011-10-12 11:09:05 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:05 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:05 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:05 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:05 --> Router Class Initialized
ERROR - 2011-10-12 11:09:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:09:13 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:13 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Router Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Output Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Input Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:09:13 --> Language Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Loader Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Controller Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:09:13 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:09:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:09:13 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:09:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:09:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:09:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:09:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:09:13 --> Final output sent to browser
DEBUG - 2011-10-12 11:09:13 --> Total execution time: 0.0569
DEBUG - 2011-10-12 11:09:18 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:18 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:18 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:18 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:18 --> Router Class Initialized
ERROR - 2011-10-12 11:09:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:09:26 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:26 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Router Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Output Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Input Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:09:26 --> Language Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Loader Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Controller Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:09:26 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:09:26 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:09:26 --> Final output sent to browser
DEBUG - 2011-10-12 11:09:26 --> Total execution time: 0.0488
DEBUG - 2011-10-12 11:09:26 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:26 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Router Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Output Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Input Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:09:26 --> Language Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Loader Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Controller Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:09:26 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:09:26 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:09:26 --> Final output sent to browser
DEBUG - 2011-10-12 11:09:26 --> Total execution time: 0.0513
DEBUG - 2011-10-12 11:09:29 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:29 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:29 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:29 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:29 --> Router Class Initialized
ERROR - 2011-10-12 11:09:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:09:39 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:39 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:39 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:39 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:39 --> Router Class Initialized
ERROR - 2011-10-12 11:09:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:09:48 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:48 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Router Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Output Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Input Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:09:48 --> Language Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Loader Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Controller Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:09:48 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:09:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:09:48 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:09:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:09:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:09:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:09:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:09:48 --> Final output sent to browser
DEBUG - 2011-10-12 11:09:48 --> Total execution time: 0.0486
DEBUG - 2011-10-12 11:09:50 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:50 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:50 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:50 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:50 --> Router Class Initialized
ERROR - 2011-10-12 11:09:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:09:52 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:52 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Router Class Initialized
ERROR - 2011-10-12 11:09:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:09:52 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:52 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Router Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Output Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Input Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:09:52 --> Language Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Loader Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Controller Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:09:52 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:09:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:09:52 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:09:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:09:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:09:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:09:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:09:52 --> Final output sent to browser
DEBUG - 2011-10-12 11:09:52 --> Total execution time: 0.0500
DEBUG - 2011-10-12 11:09:53 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:53 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:53 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:53 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:53 --> Router Class Initialized
ERROR - 2011-10-12 11:09:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:09:56 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:56 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Router Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Output Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Input Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:09:56 --> Language Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Loader Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Controller Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Model Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:09:56 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Config Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:09:56 --> URI Class Initialized
DEBUG - 2011-10-12 11:09:56 --> Router Class Initialized
ERROR - 2011-10-12 11:09:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:09:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:09:56 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:09:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:09:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:09:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:09:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:09:56 --> Final output sent to browser
DEBUG - 2011-10-12 11:09:56 --> Total execution time: 0.0471
DEBUG - 2011-10-12 11:10:02 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:02 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:02 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:02 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:02 --> Router Class Initialized
ERROR - 2011-10-12 11:10:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:04 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:04 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:04 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:04 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:04 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:04 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:04 --> Total execution time: 0.3644
DEBUG - 2011-10-12 11:10:06 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:06 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:06 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:06 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:06 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:07 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:07 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:07 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:07 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:07 --> Total execution time: 0.0510
DEBUG - 2011-10-12 11:10:07 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:07 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:08 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:08 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:08 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:08 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Controller Class Initialized
ERROR - 2011-10-12 11:10:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:08 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:08 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:08 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:08 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:08 --> Total execution time: 0.3553
DEBUG - 2011-10-12 11:10:11 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:11 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:11 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:11 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:11 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:11 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:11 --> Total execution time: 0.0451
DEBUG - 2011-10-12 11:10:13 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:13 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:13 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:13 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:13 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:13 --> Router Class Initialized
ERROR - 2011-10-12 11:10:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:13 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:13 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:13 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:13 --> Total execution time: 0.0489
DEBUG - 2011-10-12 11:10:18 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:18 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:18 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:18 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:18 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:18 --> Router Class Initialized
ERROR - 2011-10-12 11:10:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:18 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:18 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:18 --> Total execution time: 0.2421
DEBUG - 2011-10-12 11:10:19 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:19 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:19 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:19 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:20 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:20 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:20 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:20 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:20 --> Total execution time: 0.0504
DEBUG - 2011-10-12 11:10:22 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:22 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:22 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:22 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:22 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:22 --> Router Class Initialized
ERROR - 2011-10-12 11:10:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:23 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:23 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:23 --> Total execution time: 0.2856
DEBUG - 2011-10-12 11:10:24 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:24 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:24 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:24 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:24 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:24 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:24 --> Total execution time: 0.0657
DEBUG - 2011-10-12 11:10:31 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:31 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Router Class Initialized
ERROR - 2011-10-12 11:10:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:31 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:31 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:31 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:31 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:31 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:31 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:31 --> Total execution time: 0.6043
DEBUG - 2011-10-12 11:10:33 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:33 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:33 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:33 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:33 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:33 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:33 --> Total execution time: 0.0804
DEBUG - 2011-10-12 11:10:37 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:37 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:37 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:37 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:37 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:37 --> Router Class Initialized
ERROR - 2011-10-12 11:10:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:37 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:37 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:37 --> Total execution time: 0.2462
DEBUG - 2011-10-12 11:10:43 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:43 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:43 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:43 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:43 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:43 --> Router Class Initialized
ERROR - 2011-10-12 11:10:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:43 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:43 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:43 --> Total execution time: 0.2144
DEBUG - 2011-10-12 11:10:44 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:44 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:44 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:44 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:44 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:44 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:44 --> Total execution time: 0.0469
DEBUG - 2011-10-12 11:10:45 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:45 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:45 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:45 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:45 --> Router Class Initialized
ERROR - 2011-10-12 11:10:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:48 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:48 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:48 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:48 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:48 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:48 --> Router Class Initialized
ERROR - 2011-10-12 11:10:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:48 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:48 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:48 --> Total execution time: 0.2808
DEBUG - 2011-10-12 11:10:50 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:50 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:50 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:50 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:50 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:50 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:50 --> Total execution time: 0.0628
DEBUG - 2011-10-12 11:10:52 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:52 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:52 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:52 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:52 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:52 --> Router Class Initialized
ERROR - 2011-10-12 11:10:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:52 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:52 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:52 --> Total execution time: 0.2307
DEBUG - 2011-10-12 11:10:53 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:53 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:53 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:53 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:53 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:53 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:53 --> Total execution time: 0.0478
DEBUG - 2011-10-12 11:10:56 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:56 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:56 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:56 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:56 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:56 --> Router Class Initialized
ERROR - 2011-10-12 11:10:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:56 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:56 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:56 --> Total execution time: 0.0515
DEBUG - 2011-10-12 11:10:58 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:58 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:58 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:58 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:58 --> Router Class Initialized
ERROR - 2011-10-12 11:10:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:59 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:59 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Router Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Output Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Input Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:10:59 --> Language Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Loader Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Controller Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Model Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:10:59 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Config Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:10:59 --> URI Class Initialized
DEBUG - 2011-10-12 11:10:59 --> Router Class Initialized
ERROR - 2011-10-12 11:10:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:10:59 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:10:59 --> Final output sent to browser
DEBUG - 2011-10-12 11:10:59 --> Total execution time: 0.1414
DEBUG - 2011-10-12 11:11:01 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:01 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:01 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:01 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:01 --> Router Class Initialized
ERROR - 2011-10-12 11:11:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:04 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:04 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Router Class Initialized
ERROR - 2011-10-12 11:11:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:04 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:04 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:04 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:04 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:04 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:04 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:04 --> Total execution time: 0.0486
DEBUG - 2011-10-12 11:11:06 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:06 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:06 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:06 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:06 --> Router Class Initialized
ERROR - 2011-10-12 11:11:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:07 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:07 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:07 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:07 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:07 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:07 --> Router Class Initialized
ERROR - 2011-10-12 11:11:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:08 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:08 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:08 --> Total execution time: 0.2610
DEBUG - 2011-10-12 11:11:09 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:09 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:09 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:09 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:09 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:09 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:09 --> Total execution time: 0.0525
DEBUG - 2011-10-12 11:11:11 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:11 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Router Class Initialized
ERROR - 2011-10-12 11:11:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:11 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:11 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:11 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:11 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:12 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:12 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:12 --> Total execution time: 0.3536
DEBUG - 2011-10-12 11:11:13 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:13 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:13 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:13 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:13 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:13 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:13 --> Total execution time: 0.0444
DEBUG - 2011-10-12 11:11:15 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:15 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:15 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:15 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:15 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:15 --> Router Class Initialized
ERROR - 2011-10-12 11:11:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:16 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:16 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:16 --> Total execution time: 0.5583
DEBUG - 2011-10-12 11:11:17 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:17 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:17 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:17 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:17 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:17 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:17 --> Total execution time: 0.0480
DEBUG - 2011-10-12 11:11:19 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:19 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:19 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:19 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:19 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:19 --> Router Class Initialized
ERROR - 2011-10-12 11:11:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:19 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:19 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:19 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:19 --> Total execution time: 0.0480
DEBUG - 2011-10-12 11:11:20 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:20 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:20 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:20 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:20 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:20 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:20 --> Total execution time: 0.0491
DEBUG - 2011-10-12 11:11:26 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:26 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:26 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:26 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:26 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:26 --> Router Class Initialized
ERROR - 2011-10-12 11:11:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:26 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:26 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:26 --> Total execution time: 0.1841
DEBUG - 2011-10-12 11:11:28 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:28 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:28 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:28 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:28 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:28 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:28 --> Total execution time: 0.0441
DEBUG - 2011-10-12 11:11:32 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:32 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:32 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:32 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:32 --> Router Class Initialized
ERROR - 2011-10-12 11:11:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:44 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:44 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:44 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:44 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:44 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:44 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:44 --> Total execution time: 0.1001
DEBUG - 2011-10-12 11:11:46 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:46 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:46 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:46 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:46 --> Router Class Initialized
ERROR - 2011-10-12 11:11:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:50 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:50 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:50 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:50 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:50 --> Router Class Initialized
ERROR - 2011-10-12 11:11:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:51 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:51 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Router Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Output Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Input Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:11:51 --> Language Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Loader Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Controller Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Model Class Initialized
DEBUG - 2011-10-12 11:11:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:11:51 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:11:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:11:51 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:11:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:11:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:11:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:11:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:11:51 --> Final output sent to browser
DEBUG - 2011-10-12 11:11:51 --> Total execution time: 0.3757
DEBUG - 2011-10-12 11:11:54 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:54 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:54 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:54 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:54 --> Router Class Initialized
ERROR - 2011-10-12 11:11:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:11:54 --> Config Class Initialized
DEBUG - 2011-10-12 11:11:54 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:11:54 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:11:54 --> URI Class Initialized
DEBUG - 2011-10-12 11:11:54 --> Router Class Initialized
ERROR - 2011-10-12 11:11:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:12:00 --> Config Class Initialized
DEBUG - 2011-10-12 11:12:00 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:12:00 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:12:00 --> URI Class Initialized
DEBUG - 2011-10-12 11:12:00 --> Router Class Initialized
ERROR - 2011-10-12 11:12:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:12:21 --> Config Class Initialized
DEBUG - 2011-10-12 11:12:21 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:12:21 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:12:21 --> URI Class Initialized
DEBUG - 2011-10-12 11:12:21 --> Router Class Initialized
ERROR - 2011-10-12 11:12:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:13:40 --> Config Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:13:40 --> URI Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Router Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Output Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Input Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:13:40 --> Language Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Loader Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Controller Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:13:40 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:13:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:13:40 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:13:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:13:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:13:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:13:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:13:40 --> Final output sent to browser
DEBUG - 2011-10-12 11:13:40 --> Total execution time: 0.1212
DEBUG - 2011-10-12 11:13:44 --> Config Class Initialized
DEBUG - 2011-10-12 11:13:44 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:13:44 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:13:44 --> URI Class Initialized
DEBUG - 2011-10-12 11:13:44 --> Router Class Initialized
ERROR - 2011-10-12 11:13:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:13:45 --> Config Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:13:45 --> URI Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Router Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Output Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Input Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:13:45 --> Language Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Loader Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Controller Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:13:45 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:13:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:13:45 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:13:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:13:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:13:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:13:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:13:45 --> Final output sent to browser
DEBUG - 2011-10-12 11:13:45 --> Total execution time: 0.1388
DEBUG - 2011-10-12 11:13:45 --> Config Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:13:45 --> URI Class Initialized
DEBUG - 2011-10-12 11:13:45 --> Router Class Initialized
ERROR - 2011-10-12 11:13:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:13:52 --> Config Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:13:52 --> URI Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Router Class Initialized
ERROR - 2011-10-12 11:13:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:13:52 --> Config Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:13:52 --> URI Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Router Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Output Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Input Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:13:52 --> Language Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Loader Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Controller Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Model Class Initialized
DEBUG - 2011-10-12 11:13:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:13:52 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:13:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:13:53 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:13:53 --> Final output sent to browser
DEBUG - 2011-10-12 11:13:53 --> Total execution time: 1.4614
DEBUG - 2011-10-12 11:14:01 --> Config Class Initialized
DEBUG - 2011-10-12 11:14:01 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:14:01 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:14:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:14:01 --> URI Class Initialized
DEBUG - 2011-10-12 11:14:01 --> Router Class Initialized
ERROR - 2011-10-12 11:14:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:14:24 --> Config Class Initialized
DEBUG - 2011-10-12 11:14:24 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:14:24 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:14:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:14:24 --> URI Class Initialized
DEBUG - 2011-10-12 11:14:24 --> Router Class Initialized
ERROR - 2011-10-12 11:14:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:14:26 --> Config Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:14:26 --> URI Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Router Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Output Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Input Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:14:26 --> Language Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Loader Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Controller Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Model Class Initialized
DEBUG - 2011-10-12 11:14:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:14:26 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:14:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:14:27 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:14:27 --> Final output sent to browser
DEBUG - 2011-10-12 11:14:27 --> Total execution time: 1.0800
DEBUG - 2011-10-12 11:14:29 --> Config Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:14:29 --> URI Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Router Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Output Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Input Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:14:29 --> Language Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Loader Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Controller Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Model Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Model Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Model Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:14:29 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:14:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:14:29 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:14:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:14:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:14:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:14:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:14:29 --> Final output sent to browser
DEBUG - 2011-10-12 11:14:29 --> Total execution time: 0.0867
DEBUG - 2011-10-12 11:14:29 --> Config Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:14:29 --> URI Class Initialized
DEBUG - 2011-10-12 11:14:29 --> Router Class Initialized
ERROR - 2011-10-12 11:14:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:14:35 --> Config Class Initialized
DEBUG - 2011-10-12 11:14:35 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:14:35 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:14:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:14:35 --> URI Class Initialized
DEBUG - 2011-10-12 11:14:35 --> Router Class Initialized
ERROR - 2011-10-12 11:14:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:14:55 --> Config Class Initialized
DEBUG - 2011-10-12 11:14:55 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:14:55 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:14:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:14:55 --> URI Class Initialized
DEBUG - 2011-10-12 11:14:55 --> Router Class Initialized
ERROR - 2011-10-12 11:14:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:16:20 --> Config Class Initialized
DEBUG - 2011-10-12 11:16:20 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:16:20 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:16:20 --> URI Class Initialized
DEBUG - 2011-10-12 11:16:20 --> Router Class Initialized
ERROR - 2011-10-12 11:16:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:18:22 --> Config Class Initialized
DEBUG - 2011-10-12 11:18:22 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:18:22 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:18:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:18:22 --> URI Class Initialized
DEBUG - 2011-10-12 11:18:22 --> Router Class Initialized
ERROR - 2011-10-12 11:18:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 11:19:27 --> Config Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:19:27 --> URI Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Router Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Output Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Input Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:19:27 --> Language Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Loader Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Controller Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Model Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Model Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Model Class Initialized
DEBUG - 2011-10-12 11:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:19:27 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:19:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 11:19:27 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:19:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:19:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:19:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:19:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:19:27 --> Final output sent to browser
DEBUG - 2011-10-12 11:19:27 --> Total execution time: 0.0530
DEBUG - 2011-10-12 11:19:28 --> Config Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Hooks Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Utf8 Class Initialized
DEBUG - 2011-10-12 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 11:19:28 --> URI Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Router Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Output Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Input Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 11:19:28 --> Language Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Loader Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Controller Class Initialized
ERROR - 2011-10-12 11:19:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-12 11:19:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-12 11:19:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-12 11:19:28 --> Model Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Model Class Initialized
DEBUG - 2011-10-12 11:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 11:19:28 --> Database Driver Class Initialized
DEBUG - 2011-10-12 11:19:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-12 11:19:28 --> Helper loaded: url_helper
DEBUG - 2011-10-12 11:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 11:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 11:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 11:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 11:19:28 --> Final output sent to browser
DEBUG - 2011-10-12 11:19:28 --> Total execution time: 0.1162
DEBUG - 2011-10-12 13:30:42 --> Config Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Hooks Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Utf8 Class Initialized
DEBUG - 2011-10-12 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 13:30:42 --> URI Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Router Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Output Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Input Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 13:30:42 --> Language Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Loader Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Controller Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Model Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Model Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Model Class Initialized
DEBUG - 2011-10-12 13:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 13:30:42 --> Database Driver Class Initialized
DEBUG - 2011-10-12 13:30:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-12 13:30:43 --> Helper loaded: url_helper
DEBUG - 2011-10-12 13:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 13:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 13:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 13:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 13:30:43 --> Final output sent to browser
DEBUG - 2011-10-12 13:30:43 --> Total execution time: 1.6452
DEBUG - 2011-10-12 13:31:51 --> Config Class Initialized
DEBUG - 2011-10-12 13:31:51 --> Hooks Class Initialized
DEBUG - 2011-10-12 13:31:51 --> Utf8 Class Initialized
DEBUG - 2011-10-12 13:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 13:31:51 --> URI Class Initialized
DEBUG - 2011-10-12 13:31:51 --> Router Class Initialized
ERROR - 2011-10-12 13:31:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-12 16:40:06 --> Config Class Initialized
DEBUG - 2011-10-12 16:40:06 --> Hooks Class Initialized
DEBUG - 2011-10-12 16:40:06 --> Utf8 Class Initialized
DEBUG - 2011-10-12 16:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 16:40:06 --> URI Class Initialized
DEBUG - 2011-10-12 16:40:06 --> Router Class Initialized
DEBUG - 2011-10-12 16:40:06 --> No URI present. Default controller set.
DEBUG - 2011-10-12 16:40:06 --> Output Class Initialized
DEBUG - 2011-10-12 16:40:06 --> Input Class Initialized
DEBUG - 2011-10-12 16:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 16:40:06 --> Language Class Initialized
DEBUG - 2011-10-12 16:40:06 --> Loader Class Initialized
DEBUG - 2011-10-12 16:40:06 --> Controller Class Initialized
DEBUG - 2011-10-12 16:40:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-12 16:40:06 --> Helper loaded: url_helper
DEBUG - 2011-10-12 16:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 16:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 16:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 16:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 16:40:06 --> Final output sent to browser
DEBUG - 2011-10-12 16:40:06 --> Total execution time: 0.2419
DEBUG - 2011-10-12 17:18:23 --> Config Class Initialized
DEBUG - 2011-10-12 17:18:23 --> Hooks Class Initialized
DEBUG - 2011-10-12 17:18:23 --> Utf8 Class Initialized
DEBUG - 2011-10-12 17:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 17:18:23 --> URI Class Initialized
DEBUG - 2011-10-12 17:18:23 --> Router Class Initialized
ERROR - 2011-10-12 17:18:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-12 17:18:59 --> Config Class Initialized
DEBUG - 2011-10-12 17:18:59 --> Hooks Class Initialized
DEBUG - 2011-10-12 17:18:59 --> Utf8 Class Initialized
DEBUG - 2011-10-12 17:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 17:19:00 --> URI Class Initialized
DEBUG - 2011-10-12 17:19:00 --> Router Class Initialized
DEBUG - 2011-10-12 17:19:00 --> No URI present. Default controller set.
DEBUG - 2011-10-12 17:19:00 --> Output Class Initialized
DEBUG - 2011-10-12 17:19:00 --> Input Class Initialized
DEBUG - 2011-10-12 17:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 17:19:00 --> Language Class Initialized
DEBUG - 2011-10-12 17:19:00 --> Loader Class Initialized
DEBUG - 2011-10-12 17:19:01 --> Controller Class Initialized
DEBUG - 2011-10-12 17:19:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-12 17:19:01 --> Helper loaded: url_helper
DEBUG - 2011-10-12 17:19:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 17:19:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 17:19:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 17:19:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 17:19:01 --> Final output sent to browser
DEBUG - 2011-10-12 17:19:01 --> Total execution time: 1.0545
DEBUG - 2011-10-12 19:19:48 --> Config Class Initialized
DEBUG - 2011-10-12 19:19:48 --> Hooks Class Initialized
DEBUG - 2011-10-12 19:19:48 --> Utf8 Class Initialized
DEBUG - 2011-10-12 19:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 19:19:48 --> URI Class Initialized
DEBUG - 2011-10-12 19:19:48 --> Router Class Initialized
ERROR - 2011-10-12 19:19:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-12 21:10:36 --> Config Class Initialized
DEBUG - 2011-10-12 21:10:36 --> Hooks Class Initialized
DEBUG - 2011-10-12 21:10:36 --> Utf8 Class Initialized
DEBUG - 2011-10-12 21:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 21:10:36 --> URI Class Initialized
DEBUG - 2011-10-12 21:10:36 --> Router Class Initialized
ERROR - 2011-10-12 21:10:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-12 21:10:38 --> Config Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Hooks Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Utf8 Class Initialized
DEBUG - 2011-10-12 21:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 21:10:38 --> URI Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Router Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Output Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Input Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 21:10:38 --> Language Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Loader Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Controller Class Initialized
ERROR - 2011-10-12 21:10:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-12 21:10:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-12 21:10:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-12 21:10:38 --> Model Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Model Class Initialized
DEBUG - 2011-10-12 21:10:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-12 21:10:38 --> Database Driver Class Initialized
DEBUG - 2011-10-12 21:10:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-12 21:10:38 --> Helper loaded: url_helper
DEBUG - 2011-10-12 21:10:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 21:10:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 21:10:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 21:10:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 21:10:38 --> Final output sent to browser
DEBUG - 2011-10-12 21:10:38 --> Total execution time: 0.8963
DEBUG - 2011-10-12 23:45:36 --> Config Class Initialized
DEBUG - 2011-10-12 23:45:36 --> Hooks Class Initialized
DEBUG - 2011-10-12 23:45:36 --> Utf8 Class Initialized
DEBUG - 2011-10-12 23:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-12 23:45:36 --> URI Class Initialized
DEBUG - 2011-10-12 23:45:36 --> Router Class Initialized
DEBUG - 2011-10-12 23:45:36 --> No URI present. Default controller set.
DEBUG - 2011-10-12 23:45:36 --> Output Class Initialized
DEBUG - 2011-10-12 23:45:37 --> Input Class Initialized
DEBUG - 2011-10-12 23:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-12 23:45:37 --> Language Class Initialized
DEBUG - 2011-10-12 23:45:37 --> Loader Class Initialized
DEBUG - 2011-10-12 23:45:37 --> Controller Class Initialized
DEBUG - 2011-10-12 23:45:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-12 23:45:37 --> Helper loaded: url_helper
DEBUG - 2011-10-12 23:45:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-12 23:45:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-12 23:45:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-12 23:45:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-12 23:45:37 --> Final output sent to browser
DEBUG - 2011-10-12 23:45:37 --> Total execution time: 0.1494

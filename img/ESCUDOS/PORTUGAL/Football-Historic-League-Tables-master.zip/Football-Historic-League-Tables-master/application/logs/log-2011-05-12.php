<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-12 02:00:28 --> Config Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Hooks Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Utf8 Class Initialized
DEBUG - 2011-05-12 02:00:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 02:00:28 --> URI Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Router Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Output Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Input Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 02:00:28 --> Language Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Loader Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Controller Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Model Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Model Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Model Class Initialized
DEBUG - 2011-05-12 02:00:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 02:00:28 --> Database Driver Class Initialized
DEBUG - 2011-05-12 02:01:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 02:01:59 --> Helper loaded: url_helper
DEBUG - 2011-05-12 02:01:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 02:01:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 02:01:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 02:01:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 02:01:59 --> Final output sent to browser
DEBUG - 2011-05-12 02:01:59 --> Total execution time: 91.4167
DEBUG - 2011-05-12 02:19:14 --> Config Class Initialized
DEBUG - 2011-05-12 02:19:14 --> Hooks Class Initialized
DEBUG - 2011-05-12 02:19:14 --> Utf8 Class Initialized
DEBUG - 2011-05-12 02:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 02:19:14 --> URI Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Router Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Output Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Input Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 02:19:15 --> Language Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Loader Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Controller Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Model Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Model Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Model Class Initialized
DEBUG - 2011-05-12 02:19:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 02:19:16 --> Database Driver Class Initialized
DEBUG - 2011-05-12 02:19:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 02:19:32 --> Helper loaded: url_helper
DEBUG - 2011-05-12 02:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 02:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 02:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 02:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 02:19:32 --> Final output sent to browser
DEBUG - 2011-05-12 02:19:32 --> Total execution time: 18.3441
DEBUG - 2011-05-12 02:19:34 --> Config Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Hooks Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Utf8 Class Initialized
DEBUG - 2011-05-12 02:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 02:19:34 --> URI Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Router Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Output Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Input Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 02:19:34 --> Language Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Loader Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Controller Class Initialized
ERROR - 2011-05-12 02:19:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 02:19:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 02:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 02:19:34 --> Model Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Model Class Initialized
DEBUG - 2011-05-12 02:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 02:19:34 --> Database Driver Class Initialized
DEBUG - 2011-05-12 02:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 02:19:34 --> Helper loaded: url_helper
DEBUG - 2011-05-12 02:19:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 02:19:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 02:19:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 02:19:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 02:19:34 --> Final output sent to browser
DEBUG - 2011-05-12 02:19:34 --> Total execution time: 0.1702
DEBUG - 2011-05-12 03:14:39 --> Config Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Hooks Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Utf8 Class Initialized
DEBUG - 2011-05-12 03:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 03:14:39 --> URI Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Router Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Output Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Input Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 03:14:39 --> Language Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Loader Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Controller Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Model Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Model Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Model Class Initialized
DEBUG - 2011-05-12 03:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 03:14:39 --> Database Driver Class Initialized
DEBUG - 2011-05-12 03:14:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 03:14:51 --> Helper loaded: url_helper
DEBUG - 2011-05-12 03:14:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 03:14:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 03:14:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 03:14:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 03:14:51 --> Final output sent to browser
DEBUG - 2011-05-12 03:14:51 --> Total execution time: 12.5550
DEBUG - 2011-05-12 03:33:30 --> Config Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Hooks Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Utf8 Class Initialized
DEBUG - 2011-05-12 03:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 03:33:30 --> URI Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Router Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Output Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Input Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 03:33:30 --> Language Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Loader Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Controller Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Model Class Initialized
DEBUG - 2011-05-12 03:33:30 --> Model Class Initialized
DEBUG - 2011-05-12 03:33:31 --> Model Class Initialized
DEBUG - 2011-05-12 03:33:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 03:33:31 --> Database Driver Class Initialized
DEBUG - 2011-05-12 03:33:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 03:33:42 --> Helper loaded: url_helper
DEBUG - 2011-05-12 03:33:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 03:33:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 03:33:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 03:33:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 03:33:42 --> Final output sent to browser
DEBUG - 2011-05-12 03:33:42 --> Total execution time: 12.2839
DEBUG - 2011-05-12 03:33:44 --> Config Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Hooks Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Utf8 Class Initialized
DEBUG - 2011-05-12 03:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 03:33:44 --> URI Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Router Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Output Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Input Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 03:33:44 --> Language Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Loader Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Controller Class Initialized
ERROR - 2011-05-12 03:33:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 03:33:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 03:33:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 03:33:44 --> Model Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Model Class Initialized
DEBUG - 2011-05-12 03:33:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 03:33:44 --> Database Driver Class Initialized
DEBUG - 2011-05-12 03:33:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 03:33:44 --> Helper loaded: url_helper
DEBUG - 2011-05-12 03:33:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 03:33:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 03:33:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 03:33:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 03:33:44 --> Final output sent to browser
DEBUG - 2011-05-12 03:33:44 --> Total execution time: 0.2237
DEBUG - 2011-05-12 04:01:01 --> Config Class Initialized
DEBUG - 2011-05-12 04:01:01 --> Hooks Class Initialized
DEBUG - 2011-05-12 04:01:01 --> Utf8 Class Initialized
DEBUG - 2011-05-12 04:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 04:01:01 --> URI Class Initialized
DEBUG - 2011-05-12 04:01:01 --> Router Class Initialized
DEBUG - 2011-05-12 04:01:01 --> Output Class Initialized
DEBUG - 2011-05-12 04:01:01 --> Input Class Initialized
DEBUG - 2011-05-12 04:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 04:01:01 --> Language Class Initialized
DEBUG - 2011-05-12 04:01:02 --> Loader Class Initialized
DEBUG - 2011-05-12 04:01:02 --> Controller Class Initialized
DEBUG - 2011-05-12 04:01:02 --> Model Class Initialized
DEBUG - 2011-05-12 04:01:02 --> Model Class Initialized
DEBUG - 2011-05-12 04:01:02 --> Model Class Initialized
DEBUG - 2011-05-12 04:01:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 04:01:02 --> Database Driver Class Initialized
DEBUG - 2011-05-12 04:01:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 04:01:18 --> Helper loaded: url_helper
DEBUG - 2011-05-12 04:01:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 04:01:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 04:01:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 04:01:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 04:01:18 --> Final output sent to browser
DEBUG - 2011-05-12 04:01:18 --> Total execution time: 18.5739
DEBUG - 2011-05-12 04:38:40 --> Config Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Config Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Hooks Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Hooks Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Utf8 Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Utf8 Class Initialized
DEBUG - 2011-05-12 04:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 04:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 04:38:40 --> URI Class Initialized
DEBUG - 2011-05-12 04:38:40 --> URI Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Router Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Router Class Initialized
DEBUG - 2011-05-12 04:38:40 --> No URI present. Default controller set.
DEBUG - 2011-05-12 04:38:40 --> Output Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Output Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Input Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Input Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 04:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 04:38:40 --> Language Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Language Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Loader Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Loader Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Controller Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Controller Class Initialized
ERROR - 2011-05-12 04:38:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 04:38:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 04:38:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 04:38:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-12 04:38:40 --> Model Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Model Class Initialized
DEBUG - 2011-05-12 04:38:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 04:38:40 --> Helper loaded: url_helper
DEBUG - 2011-05-12 04:38:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 04:38:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 04:38:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 04:38:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 04:38:40 --> Final output sent to browser
DEBUG - 2011-05-12 04:38:40 --> Total execution time: 0.3451
DEBUG - 2011-05-12 04:38:40 --> Database Driver Class Initialized
DEBUG - 2011-05-12 04:38:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 04:38:41 --> Helper loaded: url_helper
DEBUG - 2011-05-12 04:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 04:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 04:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 04:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 04:38:41 --> Final output sent to browser
DEBUG - 2011-05-12 04:38:41 --> Total execution time: 0.6251
DEBUG - 2011-05-12 04:38:43 --> Config Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Hooks Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Utf8 Class Initialized
DEBUG - 2011-05-12 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 04:38:43 --> URI Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Router Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Output Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Input Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 04:38:43 --> Language Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Loader Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Controller Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Model Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Model Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Model Class Initialized
DEBUG - 2011-05-12 04:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 04:38:43 --> Database Driver Class Initialized
DEBUG - 2011-05-12 04:38:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 04:38:43 --> Helper loaded: url_helper
DEBUG - 2011-05-12 04:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 04:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 04:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 04:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 04:38:43 --> Final output sent to browser
DEBUG - 2011-05-12 04:38:43 --> Total execution time: 0.8086
DEBUG - 2011-05-12 08:12:10 --> Config Class Initialized
DEBUG - 2011-05-12 08:12:10 --> Hooks Class Initialized
DEBUG - 2011-05-12 08:12:10 --> Utf8 Class Initialized
DEBUG - 2011-05-12 08:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 08:12:10 --> URI Class Initialized
DEBUG - 2011-05-12 08:12:10 --> Router Class Initialized
DEBUG - 2011-05-12 08:12:10 --> Output Class Initialized
DEBUG - 2011-05-12 08:12:10 --> Input Class Initialized
DEBUG - 2011-05-12 08:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 08:12:10 --> Language Class Initialized
DEBUG - 2011-05-12 08:12:10 --> Loader Class Initialized
DEBUG - 2011-05-12 08:12:11 --> Controller Class Initialized
DEBUG - 2011-05-12 08:12:11 --> Model Class Initialized
DEBUG - 2011-05-12 08:12:11 --> Model Class Initialized
DEBUG - 2011-05-12 08:12:11 --> Model Class Initialized
DEBUG - 2011-05-12 08:12:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 08:12:11 --> Database Driver Class Initialized
DEBUG - 2011-05-12 08:12:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 08:12:14 --> Helper loaded: url_helper
DEBUG - 2011-05-12 08:12:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 08:12:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 08:12:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 08:12:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 08:12:14 --> Final output sent to browser
DEBUG - 2011-05-12 08:12:14 --> Total execution time: 3.1615
DEBUG - 2011-05-12 08:12:15 --> Config Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Hooks Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Utf8 Class Initialized
DEBUG - 2011-05-12 08:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 08:12:15 --> URI Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Router Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Output Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Input Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 08:12:15 --> Language Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Loader Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Controller Class Initialized
ERROR - 2011-05-12 08:12:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 08:12:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 08:12:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 08:12:15 --> Model Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Model Class Initialized
DEBUG - 2011-05-12 08:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 08:12:15 --> Database Driver Class Initialized
DEBUG - 2011-05-12 08:12:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 08:12:15 --> Helper loaded: url_helper
DEBUG - 2011-05-12 08:12:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 08:12:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 08:12:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 08:12:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 08:12:15 --> Final output sent to browser
DEBUG - 2011-05-12 08:12:15 --> Total execution time: 0.1041
DEBUG - 2011-05-12 08:31:36 --> Config Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Hooks Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Utf8 Class Initialized
DEBUG - 2011-05-12 08:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 08:31:36 --> URI Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Router Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Output Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Input Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 08:31:36 --> Language Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Loader Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Controller Class Initialized
ERROR - 2011-05-12 08:31:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 08:31:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 08:31:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 08:31:36 --> Model Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Model Class Initialized
DEBUG - 2011-05-12 08:31:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 08:31:36 --> Database Driver Class Initialized
DEBUG - 2011-05-12 08:31:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 08:31:36 --> Helper loaded: url_helper
DEBUG - 2011-05-12 08:31:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 08:31:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 08:31:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 08:31:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 08:31:36 --> Final output sent to browser
DEBUG - 2011-05-12 08:31:36 --> Total execution time: 0.5982
DEBUG - 2011-05-12 08:31:37 --> Config Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Hooks Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Utf8 Class Initialized
DEBUG - 2011-05-12 08:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 08:31:37 --> URI Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Router Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Output Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Input Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 08:31:37 --> Language Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Loader Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Controller Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Model Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Model Class Initialized
DEBUG - 2011-05-12 08:31:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 08:31:37 --> Database Driver Class Initialized
DEBUG - 2011-05-12 08:31:38 --> Final output sent to browser
DEBUG - 2011-05-12 08:31:38 --> Total execution time: 0.8215
DEBUG - 2011-05-12 08:31:41 --> Config Class Initialized
DEBUG - 2011-05-12 08:31:41 --> Hooks Class Initialized
DEBUG - 2011-05-12 08:31:41 --> Utf8 Class Initialized
DEBUG - 2011-05-12 08:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 08:31:41 --> URI Class Initialized
DEBUG - 2011-05-12 08:31:41 --> Router Class Initialized
ERROR - 2011-05-12 08:31:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 08:35:23 --> Config Class Initialized
DEBUG - 2011-05-12 08:35:23 --> Hooks Class Initialized
DEBUG - 2011-05-12 08:35:23 --> Utf8 Class Initialized
DEBUG - 2011-05-12 08:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 08:35:23 --> URI Class Initialized
DEBUG - 2011-05-12 08:35:23 --> Router Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Output Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Input Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 08:35:25 --> Language Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Loader Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Controller Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Model Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Model Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Model Class Initialized
DEBUG - 2011-05-12 08:35:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 08:35:25 --> Database Driver Class Initialized
DEBUG - 2011-05-12 08:35:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 08:35:28 --> Helper loaded: url_helper
DEBUG - 2011-05-12 08:35:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 08:35:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 08:35:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 08:35:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 08:35:28 --> Final output sent to browser
DEBUG - 2011-05-12 08:35:28 --> Total execution time: 4.9579
DEBUG - 2011-05-12 08:35:30 --> Config Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Hooks Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Utf8 Class Initialized
DEBUG - 2011-05-12 08:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 08:35:30 --> URI Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Router Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Output Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Input Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 08:35:30 --> Language Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Loader Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Controller Class Initialized
ERROR - 2011-05-12 08:35:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 08:35:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 08:35:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 08:35:30 --> Model Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Model Class Initialized
DEBUG - 2011-05-12 08:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 08:35:30 --> Database Driver Class Initialized
DEBUG - 2011-05-12 08:35:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 08:35:30 --> Helper loaded: url_helper
DEBUG - 2011-05-12 08:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 08:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 08:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 08:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 08:35:30 --> Final output sent to browser
DEBUG - 2011-05-12 08:35:30 --> Total execution time: 0.0514
DEBUG - 2011-05-12 13:42:29 --> Config Class Initialized
DEBUG - 2011-05-12 13:42:29 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:42:29 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:42:29 --> URI Class Initialized
DEBUG - 2011-05-12 13:42:29 --> Router Class Initialized
DEBUG - 2011-05-12 13:42:30 --> Output Class Initialized
DEBUG - 2011-05-12 13:42:30 --> Input Class Initialized
DEBUG - 2011-05-12 13:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 13:42:30 --> Language Class Initialized
DEBUG - 2011-05-12 13:42:30 --> Loader Class Initialized
DEBUG - 2011-05-12 13:42:30 --> Controller Class Initialized
ERROR - 2011-05-12 13:42:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 13:42:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 13:42:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 13:42:30 --> Model Class Initialized
DEBUG - 2011-05-12 13:42:30 --> Model Class Initialized
DEBUG - 2011-05-12 13:42:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 13:42:30 --> Database Driver Class Initialized
DEBUG - 2011-05-12 13:42:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 13:42:30 --> Helper loaded: url_helper
DEBUG - 2011-05-12 13:42:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 13:42:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 13:42:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 13:42:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 13:42:30 --> Final output sent to browser
DEBUG - 2011-05-12 13:42:30 --> Total execution time: 0.6182
DEBUG - 2011-05-12 13:42:31 --> Config Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:42:31 --> URI Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Router Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Output Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Input Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 13:42:31 --> Language Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Loader Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Controller Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Model Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Model Class Initialized
DEBUG - 2011-05-12 13:42:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 13:42:31 --> Database Driver Class Initialized
DEBUG - 2011-05-12 13:42:32 --> Final output sent to browser
DEBUG - 2011-05-12 13:42:32 --> Total execution time: 0.8734
DEBUG - 2011-05-12 13:42:33 --> Config Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:42:33 --> URI Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Router Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Output Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Input Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 13:42:33 --> Language Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Loader Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Controller Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Model Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Model Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Model Class Initialized
DEBUG - 2011-05-12 13:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 13:42:33 --> Database Driver Class Initialized
DEBUG - 2011-05-12 13:42:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 13:42:33 --> Helper loaded: url_helper
DEBUG - 2011-05-12 13:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 13:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 13:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 13:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 13:42:33 --> Final output sent to browser
DEBUG - 2011-05-12 13:42:33 --> Total execution time: 0.2423
DEBUG - 2011-05-12 13:42:35 --> Config Class Initialized
DEBUG - 2011-05-12 13:42:35 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:42:35 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:42:35 --> URI Class Initialized
DEBUG - 2011-05-12 13:42:35 --> Router Class Initialized
ERROR - 2011-05-12 13:42:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 13:42:35 --> Config Class Initialized
DEBUG - 2011-05-12 13:42:35 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:42:35 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:42:35 --> URI Class Initialized
DEBUG - 2011-05-12 13:42:35 --> Router Class Initialized
ERROR - 2011-05-12 13:42:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 13:42:36 --> Config Class Initialized
DEBUG - 2011-05-12 13:42:36 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:42:36 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:42:36 --> URI Class Initialized
DEBUG - 2011-05-12 13:42:36 --> Router Class Initialized
ERROR - 2011-05-12 13:42:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 13:42:36 --> Config Class Initialized
DEBUG - 2011-05-12 13:42:36 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:42:36 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:42:36 --> URI Class Initialized
DEBUG - 2011-05-12 13:42:36 --> Router Class Initialized
ERROR - 2011-05-12 13:42:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 13:42:37 --> Config Class Initialized
DEBUG - 2011-05-12 13:42:37 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:42:37 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:42:37 --> URI Class Initialized
DEBUG - 2011-05-12 13:42:37 --> Router Class Initialized
ERROR - 2011-05-12 13:42:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 13:51:40 --> Config Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:51:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:51:40 --> URI Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Router Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Output Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Input Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 13:51:40 --> Language Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Loader Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Controller Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Model Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Model Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Model Class Initialized
DEBUG - 2011-05-12 13:51:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 13:51:40 --> Database Driver Class Initialized
DEBUG - 2011-05-12 13:51:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 13:51:40 --> Helper loaded: url_helper
DEBUG - 2011-05-12 13:51:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 13:51:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 13:51:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 13:51:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 13:51:40 --> Final output sent to browser
DEBUG - 2011-05-12 13:51:40 --> Total execution time: 0.5792
DEBUG - 2011-05-12 13:53:15 --> Config Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:53:15 --> URI Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Router Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Output Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Input Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 13:53:15 --> Language Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Loader Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Controller Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Model Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Model Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Model Class Initialized
DEBUG - 2011-05-12 13:53:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 13:53:15 --> Database Driver Class Initialized
DEBUG - 2011-05-12 13:53:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 13:53:15 --> Helper loaded: url_helper
DEBUG - 2011-05-12 13:53:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 13:53:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 13:53:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 13:53:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 13:53:15 --> Final output sent to browser
DEBUG - 2011-05-12 13:53:15 --> Total execution time: 0.0486
DEBUG - 2011-05-12 13:53:18 --> Config Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Hooks Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Utf8 Class Initialized
DEBUG - 2011-05-12 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 13:53:18 --> URI Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Router Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Output Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Input Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 13:53:18 --> Language Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Loader Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Controller Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Model Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Model Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Model Class Initialized
DEBUG - 2011-05-12 13:53:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 13:53:18 --> Database Driver Class Initialized
DEBUG - 2011-05-12 13:53:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 13:53:18 --> Helper loaded: url_helper
DEBUG - 2011-05-12 13:53:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 13:53:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 13:53:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 13:53:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 13:53:18 --> Final output sent to browser
DEBUG - 2011-05-12 13:53:18 --> Total execution time: 0.0459
DEBUG - 2011-05-12 16:29:41 --> Config Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Hooks Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Utf8 Class Initialized
DEBUG - 2011-05-12 16:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 16:29:41 --> URI Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Router Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Output Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Input Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 16:29:41 --> Language Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Loader Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Controller Class Initialized
ERROR - 2011-05-12 16:29:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 16:29:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 16:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 16:29:41 --> Model Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Model Class Initialized
DEBUG - 2011-05-12 16:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 16:29:41 --> Database Driver Class Initialized
DEBUG - 2011-05-12 16:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 16:29:42 --> Helper loaded: url_helper
DEBUG - 2011-05-12 16:29:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 16:29:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 16:29:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 16:29:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 16:29:42 --> Final output sent to browser
DEBUG - 2011-05-12 16:29:42 --> Total execution time: 0.4202
DEBUG - 2011-05-12 16:29:43 --> Config Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Hooks Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Utf8 Class Initialized
DEBUG - 2011-05-12 16:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 16:29:43 --> URI Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Router Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Output Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Input Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 16:29:43 --> Language Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Loader Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Controller Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Model Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Model Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 16:29:43 --> Database Driver Class Initialized
DEBUG - 2011-05-12 16:29:43 --> Final output sent to browser
DEBUG - 2011-05-12 16:29:43 --> Total execution time: 0.7492
DEBUG - 2011-05-12 16:29:47 --> Config Class Initialized
DEBUG - 2011-05-12 16:29:47 --> Hooks Class Initialized
DEBUG - 2011-05-12 16:29:47 --> Utf8 Class Initialized
DEBUG - 2011-05-12 16:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 16:29:47 --> URI Class Initialized
DEBUG - 2011-05-12 16:29:47 --> Router Class Initialized
ERROR - 2011-05-12 16:29:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 16:29:48 --> Config Class Initialized
DEBUG - 2011-05-12 16:29:48 --> Hooks Class Initialized
DEBUG - 2011-05-12 16:29:48 --> Utf8 Class Initialized
DEBUG - 2011-05-12 16:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 16:29:48 --> URI Class Initialized
DEBUG - 2011-05-12 16:29:48 --> Router Class Initialized
ERROR - 2011-05-12 16:29:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 16:29:48 --> Config Class Initialized
DEBUG - 2011-05-12 16:29:48 --> Hooks Class Initialized
DEBUG - 2011-05-12 16:29:48 --> Utf8 Class Initialized
DEBUG - 2011-05-12 16:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 16:29:48 --> URI Class Initialized
DEBUG - 2011-05-12 16:29:48 --> Router Class Initialized
ERROR - 2011-05-12 16:29:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-12 16:43:33 --> Config Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Hooks Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Utf8 Class Initialized
DEBUG - 2011-05-12 16:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 16:43:33 --> URI Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Router Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Output Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Input Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 16:43:33 --> Language Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Loader Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Controller Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Model Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Model Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Model Class Initialized
DEBUG - 2011-05-12 16:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 16:43:33 --> Database Driver Class Initialized
DEBUG - 2011-05-12 16:43:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 16:43:33 --> Helper loaded: url_helper
DEBUG - 2011-05-12 16:43:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 16:43:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 16:43:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 16:43:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 16:43:33 --> Final output sent to browser
DEBUG - 2011-05-12 16:43:33 --> Total execution time: 0.3966
DEBUG - 2011-05-12 16:43:34 --> Config Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Hooks Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Utf8 Class Initialized
DEBUG - 2011-05-12 16:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 16:43:34 --> URI Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Router Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Output Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Input Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 16:43:34 --> Language Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Loader Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Controller Class Initialized
ERROR - 2011-05-12 16:43:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 16:43:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 16:43:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 16:43:34 --> Model Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Model Class Initialized
DEBUG - 2011-05-12 16:43:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 16:43:34 --> Database Driver Class Initialized
DEBUG - 2011-05-12 16:43:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 16:43:34 --> Helper loaded: url_helper
DEBUG - 2011-05-12 16:43:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 16:43:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 16:43:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 16:43:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 16:43:34 --> Final output sent to browser
DEBUG - 2011-05-12 16:43:34 --> Total execution time: 0.0427
DEBUG - 2011-05-12 18:27:26 --> Config Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Hooks Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Utf8 Class Initialized
DEBUG - 2011-05-12 18:27:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 18:27:26 --> URI Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Router Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Output Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Input Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 18:27:26 --> Language Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Loader Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Controller Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Model Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Model Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Model Class Initialized
DEBUG - 2011-05-12 18:27:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 18:27:26 --> Database Driver Class Initialized
DEBUG - 2011-05-12 18:27:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 18:27:26 --> Helper loaded: url_helper
DEBUG - 2011-05-12 18:27:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 18:27:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 18:27:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 18:27:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 18:27:26 --> Final output sent to browser
DEBUG - 2011-05-12 18:27:26 --> Total execution time: 0.5057
DEBUG - 2011-05-12 18:27:27 --> Config Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Hooks Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Utf8 Class Initialized
DEBUG - 2011-05-12 18:27:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 18:27:27 --> URI Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Router Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Output Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Input Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 18:27:27 --> Language Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Loader Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Controller Class Initialized
ERROR - 2011-05-12 18:27:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 18:27:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 18:27:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 18:27:27 --> Model Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Model Class Initialized
DEBUG - 2011-05-12 18:27:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 18:27:27 --> Database Driver Class Initialized
DEBUG - 2011-05-12 18:27:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 18:27:27 --> Helper loaded: url_helper
DEBUG - 2011-05-12 18:27:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 18:27:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 18:27:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 18:27:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 18:27:27 --> Final output sent to browser
DEBUG - 2011-05-12 18:27:27 --> Total execution time: 0.0913
DEBUG - 2011-05-12 20:03:21 --> Config Class Initialized
DEBUG - 2011-05-12 20:03:21 --> Hooks Class Initialized
DEBUG - 2011-05-12 20:03:21 --> Utf8 Class Initialized
DEBUG - 2011-05-12 20:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 20:03:21 --> URI Class Initialized
DEBUG - 2011-05-12 20:03:21 --> Router Class Initialized
DEBUG - 2011-05-12 20:03:21 --> No URI present. Default controller set.
DEBUG - 2011-05-12 20:03:21 --> Output Class Initialized
DEBUG - 2011-05-12 20:03:21 --> Input Class Initialized
DEBUG - 2011-05-12 20:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 20:03:21 --> Language Class Initialized
DEBUG - 2011-05-12 20:03:21 --> Loader Class Initialized
DEBUG - 2011-05-12 20:03:21 --> Controller Class Initialized
DEBUG - 2011-05-12 20:03:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-12 20:03:21 --> Helper loaded: url_helper
DEBUG - 2011-05-12 20:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 20:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 20:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 20:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 20:03:21 --> Final output sent to browser
DEBUG - 2011-05-12 20:03:21 --> Total execution time: 0.3216
DEBUG - 2011-05-12 20:08:46 --> Config Class Initialized
DEBUG - 2011-05-12 20:08:46 --> Hooks Class Initialized
DEBUG - 2011-05-12 20:08:46 --> Utf8 Class Initialized
DEBUG - 2011-05-12 20:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 20:08:46 --> URI Class Initialized
DEBUG - 2011-05-12 20:08:46 --> Router Class Initialized
DEBUG - 2011-05-12 20:08:46 --> Output Class Initialized
DEBUG - 2011-05-12 20:08:46 --> Input Class Initialized
DEBUG - 2011-05-12 20:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 20:08:46 --> Language Class Initialized
DEBUG - 2011-05-12 20:08:46 --> Loader Class Initialized
DEBUG - 2011-05-12 20:08:46 --> Controller Class Initialized
DEBUG - 2011-05-12 20:08:47 --> Model Class Initialized
DEBUG - 2011-05-12 20:08:47 --> Model Class Initialized
DEBUG - 2011-05-12 20:08:47 --> Model Class Initialized
DEBUG - 2011-05-12 20:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 20:08:47 --> Database Driver Class Initialized
DEBUG - 2011-05-12 20:08:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 20:08:48 --> Helper loaded: url_helper
DEBUG - 2011-05-12 20:08:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 20:08:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 20:08:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 20:08:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 20:08:48 --> Final output sent to browser
DEBUG - 2011-05-12 20:08:48 --> Total execution time: 2.1559
DEBUG - 2011-05-12 20:08:50 --> Config Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Hooks Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Utf8 Class Initialized
DEBUG - 2011-05-12 20:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 20:08:50 --> URI Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Router Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Output Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Input Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 20:08:50 --> Language Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Loader Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Controller Class Initialized
ERROR - 2011-05-12 20:08:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 20:08:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 20:08:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 20:08:50 --> Model Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Model Class Initialized
DEBUG - 2011-05-12 20:08:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 20:08:50 --> Database Driver Class Initialized
DEBUG - 2011-05-12 20:08:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 20:08:50 --> Helper loaded: url_helper
DEBUG - 2011-05-12 20:08:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 20:08:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 20:08:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 20:08:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 20:08:50 --> Final output sent to browser
DEBUG - 2011-05-12 20:08:50 --> Total execution time: 0.5169
DEBUG - 2011-05-12 21:48:12 --> Config Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Hooks Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Utf8 Class Initialized
DEBUG - 2011-05-12 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 21:48:12 --> URI Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Router Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Output Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Input Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 21:48:12 --> Language Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Loader Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Controller Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Model Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Model Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Model Class Initialized
DEBUG - 2011-05-12 21:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 21:48:12 --> Database Driver Class Initialized
DEBUG - 2011-05-12 21:48:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 21:48:13 --> Helper loaded: url_helper
DEBUG - 2011-05-12 21:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 21:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 21:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 21:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 21:48:13 --> Final output sent to browser
DEBUG - 2011-05-12 21:48:13 --> Total execution time: 0.9599
DEBUG - 2011-05-12 21:48:25 --> Config Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Hooks Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Utf8 Class Initialized
DEBUG - 2011-05-12 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 21:48:25 --> URI Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Router Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Output Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Input Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 21:48:25 --> Language Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Loader Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Controller Class Initialized
ERROR - 2011-05-12 21:48:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 21:48:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 21:48:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 21:48:25 --> Model Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Model Class Initialized
DEBUG - 2011-05-12 21:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 21:48:25 --> Database Driver Class Initialized
DEBUG - 2011-05-12 21:48:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 21:48:25 --> Helper loaded: url_helper
DEBUG - 2011-05-12 21:48:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 21:48:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 21:48:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 21:48:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 21:48:25 --> Final output sent to browser
DEBUG - 2011-05-12 21:48:25 --> Total execution time: 0.1215
DEBUG - 2011-05-12 21:57:48 --> Config Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Hooks Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Utf8 Class Initialized
DEBUG - 2011-05-12 21:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 21:57:48 --> URI Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Router Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Output Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Input Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 21:57:48 --> Language Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Loader Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Controller Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Model Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Model Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Model Class Initialized
DEBUG - 2011-05-12 21:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 21:57:48 --> Database Driver Class Initialized
DEBUG - 2011-05-12 21:57:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-12 21:57:48 --> Helper loaded: url_helper
DEBUG - 2011-05-12 21:57:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 21:57:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 21:57:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 21:57:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 21:57:48 --> Final output sent to browser
DEBUG - 2011-05-12 21:57:48 --> Total execution time: 0.0598
DEBUG - 2011-05-12 21:57:51 --> Config Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Hooks Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Utf8 Class Initialized
DEBUG - 2011-05-12 21:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 21:57:51 --> URI Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Router Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Output Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Input Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 21:57:51 --> Language Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Loader Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Controller Class Initialized
ERROR - 2011-05-12 21:57:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 21:57:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 21:57:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 21:57:51 --> Model Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Model Class Initialized
DEBUG - 2011-05-12 21:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 21:57:51 --> Database Driver Class Initialized
DEBUG - 2011-05-12 21:57:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 21:57:51 --> Helper loaded: url_helper
DEBUG - 2011-05-12 21:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 21:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 21:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 21:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 21:57:51 --> Final output sent to browser
DEBUG - 2011-05-12 21:57:51 --> Total execution time: 0.0304
DEBUG - 2011-05-12 22:01:10 --> Config Class Initialized
DEBUG - 2011-05-12 22:01:10 --> Hooks Class Initialized
DEBUG - 2011-05-12 22:01:10 --> Utf8 Class Initialized
DEBUG - 2011-05-12 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 22:01:10 --> URI Class Initialized
DEBUG - 2011-05-12 22:01:10 --> Router Class Initialized
ERROR - 2011-05-12 22:01:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-12 22:24:55 --> Config Class Initialized
DEBUG - 2011-05-12 22:24:55 --> Hooks Class Initialized
DEBUG - 2011-05-12 22:24:55 --> Utf8 Class Initialized
DEBUG - 2011-05-12 22:24:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-12 22:24:55 --> URI Class Initialized
DEBUG - 2011-05-12 22:24:55 --> Router Class Initialized
DEBUG - 2011-05-12 22:24:56 --> Output Class Initialized
DEBUG - 2011-05-12 22:24:56 --> Input Class Initialized
DEBUG - 2011-05-12 22:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-12 22:24:56 --> Language Class Initialized
DEBUG - 2011-05-12 22:24:56 --> Loader Class Initialized
DEBUG - 2011-05-12 22:24:56 --> Controller Class Initialized
ERROR - 2011-05-12 22:24:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-12 22:24:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-12 22:24:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 22:24:56 --> Model Class Initialized
DEBUG - 2011-05-12 22:24:56 --> Model Class Initialized
DEBUG - 2011-05-12 22:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-12 22:24:56 --> Database Driver Class Initialized
DEBUG - 2011-05-12 22:24:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-12 22:24:56 --> Helper loaded: url_helper
DEBUG - 2011-05-12 22:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-12 22:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-12 22:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-12 22:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-12 22:24:56 --> Final output sent to browser
DEBUG - 2011-05-12 22:24:56 --> Total execution time: 0.3245

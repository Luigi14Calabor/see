<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-26 00:00:07 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:07 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:07 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Controller Class Initialized
ERROR - 2011-08-26 00:00:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:00:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:00:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:07 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:08 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:08 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:00:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:00:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:00:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:00:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:00:08 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:08 --> Total execution time: 0.6767
DEBUG - 2011-08-26 00:00:09 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:09 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:09 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Controller Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:09 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:10 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:10 --> Total execution time: 0.9079
DEBUG - 2011-08-26 00:00:19 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:19 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:19 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Controller Class Initialized
ERROR - 2011-08-26 00:00:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:00:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:00:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:19 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:19 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:19 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:00:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:00:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:00:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:00:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:00:19 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:19 --> Total execution time: 0.0289
DEBUG - 2011-08-26 00:00:19 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:19 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:19 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Controller Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:19 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:20 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:20 --> Total execution time: 0.5061
DEBUG - 2011-08-26 00:00:27 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:27 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:27 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Controller Class Initialized
ERROR - 2011-08-26 00:00:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:00:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:00:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:27 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:27 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:27 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:00:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:00:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:00:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:00:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:00:27 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:27 --> Total execution time: 0.0431
DEBUG - 2011-08-26 00:00:28 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:28 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:28 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Controller Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:28 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:29 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:29 --> Total execution time: 0.5621
DEBUG - 2011-08-26 00:00:37 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:37 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:37 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Controller Class Initialized
ERROR - 2011-08-26 00:00:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:00:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:37 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:37 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:37 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:00:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:00:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:00:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:00:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:00:37 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:37 --> Total execution time: 0.0448
DEBUG - 2011-08-26 00:00:38 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:38 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:38 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Controller Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:38 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:39 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:39 --> Total execution time: 0.4491
DEBUG - 2011-08-26 00:00:46 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:46 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:46 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Controller Class Initialized
ERROR - 2011-08-26 00:00:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:00:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:46 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:46 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:46 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:00:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:00:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:00:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:00:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:00:46 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:46 --> Total execution time: 0.0709
DEBUG - 2011-08-26 00:00:47 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:47 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:47 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Controller Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:47 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:48 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:48 --> Total execution time: 0.6770
DEBUG - 2011-08-26 00:00:58 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:58 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:58 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Controller Class Initialized
ERROR - 2011-08-26 00:00:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:00:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:00:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:58 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:58 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:00:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:00:59 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:00:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:00:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:00:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:00:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:00:59 --> Final output sent to browser
DEBUG - 2011-08-26 00:00:59 --> Total execution time: 0.0283
DEBUG - 2011-08-26 00:00:59 --> Config Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:00:59 --> URI Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Router Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Output Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Input Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:00:59 --> Language Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Loader Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Controller Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Model Class Initialized
DEBUG - 2011-08-26 00:00:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:00:59 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:01:00 --> Final output sent to browser
DEBUG - 2011-08-26 00:01:00 --> Total execution time: 0.5256
DEBUG - 2011-08-26 00:01:16 --> Config Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:01:16 --> URI Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Router Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Output Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Input Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:01:16 --> Language Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Loader Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Controller Class Initialized
ERROR - 2011-08-26 00:01:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:01:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:01:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:01:16 --> Model Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Model Class Initialized
DEBUG - 2011-08-26 00:01:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:01:16 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:01:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:01:16 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:01:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:01:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:01:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:01:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:01:16 --> Final output sent to browser
DEBUG - 2011-08-26 00:01:16 --> Total execution time: 0.0276
DEBUG - 2011-08-26 00:01:17 --> Config Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:01:17 --> URI Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Router Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Output Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Input Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:01:17 --> Language Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Loader Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Controller Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Model Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Model Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:01:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:01:17 --> Final output sent to browser
DEBUG - 2011-08-26 00:01:17 --> Total execution time: 0.4969
DEBUG - 2011-08-26 00:07:34 --> Config Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:07:34 --> URI Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Router Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Output Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Input Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:07:34 --> Language Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Loader Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Controller Class Initialized
ERROR - 2011-08-26 00:07:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:07:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:07:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:07:34 --> Model Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Model Class Initialized
DEBUG - 2011-08-26 00:07:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:07:34 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:07:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:07:34 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:07:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:07:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:07:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:07:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:07:34 --> Final output sent to browser
DEBUG - 2011-08-26 00:07:34 --> Total execution time: 0.0879
DEBUG - 2011-08-26 00:07:35 --> Config Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:07:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:07:35 --> URI Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Router Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Output Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Input Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:07:35 --> Language Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Loader Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Controller Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Model Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Model Class Initialized
DEBUG - 2011-08-26 00:07:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:07:35 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:07:36 --> Final output sent to browser
DEBUG - 2011-08-26 00:07:36 --> Total execution time: 0.4919
DEBUG - 2011-08-26 00:07:37 --> Config Class Initialized
DEBUG - 2011-08-26 00:07:37 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:07:37 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:07:37 --> URI Class Initialized
DEBUG - 2011-08-26 00:07:37 --> Router Class Initialized
ERROR - 2011-08-26 00:07:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 00:07:37 --> Config Class Initialized
DEBUG - 2011-08-26 00:07:37 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:07:37 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:07:37 --> URI Class Initialized
DEBUG - 2011-08-26 00:07:37 --> Router Class Initialized
ERROR - 2011-08-26 00:07:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 00:09:06 --> Config Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:09:06 --> URI Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Router Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Output Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Input Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:09:06 --> Language Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Loader Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Controller Class Initialized
ERROR - 2011-08-26 00:09:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:09:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:09:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:09:06 --> Model Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Model Class Initialized
DEBUG - 2011-08-26 00:09:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:09:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:09:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:09:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:09:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:09:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:09:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:09:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:09:06 --> Final output sent to browser
DEBUG - 2011-08-26 00:09:06 --> Total execution time: 0.0508
DEBUG - 2011-08-26 00:09:07 --> Config Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:09:07 --> URI Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Router Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Output Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Input Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:09:07 --> Language Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Loader Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Controller Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Model Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Model Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:09:07 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Config Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:09:07 --> URI Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Router Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Output Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Input Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:09:07 --> Language Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Loader Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Controller Class Initialized
ERROR - 2011-08-26 00:09:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:09:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:09:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:09:07 --> Model Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Model Class Initialized
DEBUG - 2011-08-26 00:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:09:07 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:09:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:09:07 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:09:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:09:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:09:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:09:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:09:07 --> Final output sent to browser
DEBUG - 2011-08-26 00:09:07 --> Total execution time: 0.0408
DEBUG - 2011-08-26 00:09:07 --> Final output sent to browser
DEBUG - 2011-08-26 00:09:07 --> Total execution time: 0.5504
DEBUG - 2011-08-26 00:09:08 --> Config Class Initialized
DEBUG - 2011-08-26 00:09:08 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:09:08 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:09:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:09:08 --> URI Class Initialized
DEBUG - 2011-08-26 00:09:08 --> Router Class Initialized
ERROR - 2011-08-26 00:09:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 00:10:02 --> Config Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:10:02 --> URI Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Router Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Output Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Input Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:10:02 --> Language Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Loader Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Controller Class Initialized
ERROR - 2011-08-26 00:10:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:10:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:10:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:10:02 --> Model Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Model Class Initialized
DEBUG - 2011-08-26 00:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:10:02 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:10:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:10:02 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:10:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:10:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:10:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:10:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:10:02 --> Final output sent to browser
DEBUG - 2011-08-26 00:10:02 --> Total execution time: 0.2384
DEBUG - 2011-08-26 00:10:03 --> Config Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:10:03 --> URI Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Router Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Output Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Input Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:10:03 --> Language Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Loader Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Controller Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Model Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Model Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:10:03 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:10:03 --> Final output sent to browser
DEBUG - 2011-08-26 00:10:03 --> Total execution time: 0.6760
DEBUG - 2011-08-26 00:10:04 --> Config Class Initialized
DEBUG - 2011-08-26 00:10:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:10:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:10:04 --> URI Class Initialized
DEBUG - 2011-08-26 00:10:04 --> Router Class Initialized
ERROR - 2011-08-26 00:10:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 00:10:44 --> Config Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:10:44 --> URI Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Router Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Output Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Input Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:10:44 --> Language Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Loader Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Controller Class Initialized
ERROR - 2011-08-26 00:10:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:10:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:10:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:10:44 --> Model Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Model Class Initialized
DEBUG - 2011-08-26 00:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:10:44 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:10:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:10:44 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:10:44 --> Final output sent to browser
DEBUG - 2011-08-26 00:10:44 --> Total execution time: 0.0372
DEBUG - 2011-08-26 00:10:45 --> Config Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:10:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:10:45 --> URI Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Router Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Output Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Input Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:10:45 --> Language Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Loader Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Controller Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Model Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Model Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:10:45 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:10:45 --> Final output sent to browser
DEBUG - 2011-08-26 00:10:45 --> Total execution time: 0.4791
DEBUG - 2011-08-26 00:10:46 --> Config Class Initialized
DEBUG - 2011-08-26 00:10:46 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:10:46 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:10:46 --> URI Class Initialized
DEBUG - 2011-08-26 00:10:46 --> Router Class Initialized
ERROR - 2011-08-26 00:10:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 00:11:00 --> Config Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:11:00 --> URI Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Router Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Output Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Input Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:11:00 --> Language Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Loader Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Controller Class Initialized
ERROR - 2011-08-26 00:11:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:11:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:11:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:11:00 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:11:00 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:11:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:11:00 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:11:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:11:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:11:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:11:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:11:00 --> Final output sent to browser
DEBUG - 2011-08-26 00:11:00 --> Total execution time: 0.0273
DEBUG - 2011-08-26 00:11:00 --> Config Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:11:00 --> URI Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Router Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Output Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Input Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:11:00 --> Language Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Loader Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Controller Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:11:00 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:11:01 --> Final output sent to browser
DEBUG - 2011-08-26 00:11:01 --> Total execution time: 0.7169
DEBUG - 2011-08-26 00:11:02 --> Config Class Initialized
DEBUG - 2011-08-26 00:11:02 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:11:02 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:11:02 --> URI Class Initialized
DEBUG - 2011-08-26 00:11:02 --> Router Class Initialized
ERROR - 2011-08-26 00:11:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 00:11:04 --> Config Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:11:04 --> URI Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Router Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Output Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Input Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:11:04 --> Language Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Loader Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Controller Class Initialized
ERROR - 2011-08-26 00:11:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:11:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:11:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:11:04 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:11:04 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:11:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:11:04 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:11:04 --> Final output sent to browser
DEBUG - 2011-08-26 00:11:04 --> Total execution time: 0.0358
DEBUG - 2011-08-26 00:11:08 --> Config Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:11:08 --> URI Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Router Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Output Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Input Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:11:08 --> Language Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Loader Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Controller Class Initialized
ERROR - 2011-08-26 00:11:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:11:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:11:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:11:08 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:11:08 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:11:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:11:08 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:11:08 --> Final output sent to browser
DEBUG - 2011-08-26 00:11:08 --> Total execution time: 0.0331
DEBUG - 2011-08-26 00:11:08 --> Config Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:11:08 --> URI Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Router Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Output Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Input Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:11:08 --> Language Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Loader Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Controller Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:11:08 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:11:09 --> Final output sent to browser
DEBUG - 2011-08-26 00:11:09 --> Total execution time: 0.5314
DEBUG - 2011-08-26 00:11:10 --> Config Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:11:10 --> URI Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Router Class Initialized
ERROR - 2011-08-26 00:11:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 00:11:10 --> Config Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 00:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 00:11:10 --> URI Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Router Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Output Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Input Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 00:11:10 --> Language Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Loader Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Controller Class Initialized
ERROR - 2011-08-26 00:11:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 00:11:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 00:11:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:11:10 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Model Class Initialized
DEBUG - 2011-08-26 00:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 00:11:10 --> Database Driver Class Initialized
DEBUG - 2011-08-26 00:11:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 00:11:10 --> Helper loaded: url_helper
DEBUG - 2011-08-26 00:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 00:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 00:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 00:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 00:11:10 --> Final output sent to browser
DEBUG - 2011-08-26 00:11:10 --> Total execution time: 0.0294
DEBUG - 2011-08-26 01:00:42 --> Config Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Hooks Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Utf8 Class Initialized
DEBUG - 2011-08-26 01:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 01:00:42 --> URI Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Router Class Initialized
ERROR - 2011-08-26 01:00:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 01:00:42 --> Config Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Hooks Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Utf8 Class Initialized
DEBUG - 2011-08-26 01:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 01:00:42 --> URI Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Router Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Output Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Input Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 01:00:42 --> Language Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Loader Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Controller Class Initialized
ERROR - 2011-08-26 01:00:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 01:00:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 01:00:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 01:00:42 --> Model Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Model Class Initialized
DEBUG - 2011-08-26 01:00:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 01:00:42 --> Database Driver Class Initialized
DEBUG - 2011-08-26 01:00:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 01:00:42 --> Helper loaded: url_helper
DEBUG - 2011-08-26 01:00:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 01:00:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 01:00:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 01:00:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 01:00:42 --> Final output sent to browser
DEBUG - 2011-08-26 01:00:42 --> Total execution time: 0.2506
DEBUG - 2011-08-26 02:51:24 --> Config Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Hooks Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Utf8 Class Initialized
DEBUG - 2011-08-26 02:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 02:51:24 --> URI Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Router Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Output Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Input Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 02:51:24 --> Language Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Loader Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Controller Class Initialized
DEBUG - 2011-08-26 02:51:24 --> Model Class Initialized
DEBUG - 2011-08-26 02:51:25 --> Model Class Initialized
DEBUG - 2011-08-26 02:51:25 --> Model Class Initialized
DEBUG - 2011-08-26 02:51:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 02:51:25 --> Database Driver Class Initialized
DEBUG - 2011-08-26 02:51:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 02:51:27 --> Helper loaded: url_helper
DEBUG - 2011-08-26 02:51:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 02:51:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 02:51:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 02:51:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 02:51:27 --> Final output sent to browser
DEBUG - 2011-08-26 02:51:27 --> Total execution time: 2.9759
DEBUG - 2011-08-26 03:41:58 --> Config Class Initialized
DEBUG - 2011-08-26 03:41:58 --> Hooks Class Initialized
DEBUG - 2011-08-26 03:41:58 --> Utf8 Class Initialized
DEBUG - 2011-08-26 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 03:41:58 --> URI Class Initialized
DEBUG - 2011-08-26 03:41:58 --> Router Class Initialized
ERROR - 2011-08-26 03:41:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 04:36:56 --> Config Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Hooks Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Utf8 Class Initialized
DEBUG - 2011-08-26 04:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 04:36:56 --> URI Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Router Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Output Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Input Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 04:36:56 --> Language Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Loader Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Controller Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Model Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Model Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Model Class Initialized
DEBUG - 2011-08-26 04:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 04:36:56 --> Database Driver Class Initialized
DEBUG - 2011-08-26 04:36:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 04:36:59 --> Helper loaded: url_helper
DEBUG - 2011-08-26 04:36:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 04:36:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 04:36:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 04:36:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 04:36:59 --> Final output sent to browser
DEBUG - 2011-08-26 04:36:59 --> Total execution time: 3.1216
DEBUG - 2011-08-26 05:39:00 --> Config Class Initialized
DEBUG - 2011-08-26 05:39:00 --> Hooks Class Initialized
DEBUG - 2011-08-26 05:39:00 --> Utf8 Class Initialized
DEBUG - 2011-08-26 05:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 05:39:00 --> URI Class Initialized
DEBUG - 2011-08-26 05:39:00 --> Router Class Initialized
DEBUG - 2011-08-26 05:39:00 --> No URI present. Default controller set.
DEBUG - 2011-08-26 05:39:00 --> Output Class Initialized
DEBUG - 2011-08-26 05:39:00 --> Input Class Initialized
DEBUG - 2011-08-26 05:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 05:39:00 --> Language Class Initialized
DEBUG - 2011-08-26 05:39:00 --> Loader Class Initialized
DEBUG - 2011-08-26 05:39:00 --> Controller Class Initialized
DEBUG - 2011-08-26 05:39:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-26 05:39:00 --> Helper loaded: url_helper
DEBUG - 2011-08-26 05:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 05:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 05:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 05:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 05:39:00 --> Final output sent to browser
DEBUG - 2011-08-26 05:39:00 --> Total execution time: 0.2091
DEBUG - 2011-08-26 05:43:24 --> Config Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Hooks Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Utf8 Class Initialized
DEBUG - 2011-08-26 05:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 05:43:24 --> URI Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Router Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Output Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Input Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 05:43:24 --> Language Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Loader Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Controller Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Model Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Model Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Model Class Initialized
DEBUG - 2011-08-26 05:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 05:43:24 --> Database Driver Class Initialized
DEBUG - 2011-08-26 05:43:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 05:43:26 --> Helper loaded: url_helper
DEBUG - 2011-08-26 05:43:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 05:43:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 05:43:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 05:43:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 05:43:26 --> Final output sent to browser
DEBUG - 2011-08-26 05:43:26 --> Total execution time: 1.4745
DEBUG - 2011-08-26 05:43:27 --> Config Class Initialized
DEBUG - 2011-08-26 05:43:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 05:43:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 05:43:27 --> URI Class Initialized
DEBUG - 2011-08-26 05:43:27 --> Router Class Initialized
ERROR - 2011-08-26 05:43:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 05:43:30 --> Config Class Initialized
DEBUG - 2011-08-26 05:43:30 --> Hooks Class Initialized
DEBUG - 2011-08-26 05:43:30 --> Utf8 Class Initialized
DEBUG - 2011-08-26 05:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 05:43:30 --> URI Class Initialized
DEBUG - 2011-08-26 05:43:30 --> Router Class Initialized
ERROR - 2011-08-26 05:43:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 05:45:33 --> Config Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Hooks Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Utf8 Class Initialized
DEBUG - 2011-08-26 05:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 05:45:33 --> URI Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Router Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Output Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Input Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 05:45:33 --> Language Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Loader Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Controller Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Model Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Model Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Model Class Initialized
DEBUG - 2011-08-26 05:45:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 05:45:33 --> Database Driver Class Initialized
DEBUG - 2011-08-26 05:45:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 05:45:33 --> Helper loaded: url_helper
DEBUG - 2011-08-26 05:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 05:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 05:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 05:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 05:45:33 --> Final output sent to browser
DEBUG - 2011-08-26 05:45:33 --> Total execution time: 0.0522
DEBUG - 2011-08-26 05:47:23 --> Config Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-26 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 05:47:23 --> URI Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Router Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Output Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Input Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 05:47:23 --> Language Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Loader Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Controller Class Initialized
ERROR - 2011-08-26 05:47:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 05:47:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 05:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 05:47:23 --> Model Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Model Class Initialized
DEBUG - 2011-08-26 05:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 05:47:23 --> Database Driver Class Initialized
DEBUG - 2011-08-26 05:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 05:47:23 --> Helper loaded: url_helper
DEBUG - 2011-08-26 05:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 05:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 05:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 05:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 05:47:23 --> Final output sent to browser
DEBUG - 2011-08-26 05:47:23 --> Total execution time: 0.0808
DEBUG - 2011-08-26 06:44:23 --> Config Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Hooks Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Utf8 Class Initialized
DEBUG - 2011-08-26 06:44:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 06:44:23 --> URI Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Router Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Output Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Input Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 06:44:23 --> Language Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Loader Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Controller Class Initialized
ERROR - 2011-08-26 06:44:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 06:44:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 06:44:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 06:44:23 --> Model Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Model Class Initialized
DEBUG - 2011-08-26 06:44:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 06:44:23 --> Database Driver Class Initialized
DEBUG - 2011-08-26 06:44:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 06:44:23 --> Helper loaded: url_helper
DEBUG - 2011-08-26 06:44:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 06:44:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 06:44:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 06:44:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 06:44:23 --> Final output sent to browser
DEBUG - 2011-08-26 06:44:23 --> Total execution time: 0.2995
DEBUG - 2011-08-26 06:57:30 --> Config Class Initialized
DEBUG - 2011-08-26 06:57:30 --> Hooks Class Initialized
DEBUG - 2011-08-26 06:57:30 --> Utf8 Class Initialized
DEBUG - 2011-08-26 06:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 06:57:30 --> URI Class Initialized
DEBUG - 2011-08-26 06:57:30 --> Router Class Initialized
DEBUG - 2011-08-26 06:57:30 --> No URI present. Default controller set.
DEBUG - 2011-08-26 06:57:30 --> Output Class Initialized
DEBUG - 2011-08-26 06:57:30 --> Input Class Initialized
DEBUG - 2011-08-26 06:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 06:57:30 --> Language Class Initialized
DEBUG - 2011-08-26 06:57:30 --> Loader Class Initialized
DEBUG - 2011-08-26 06:57:30 --> Controller Class Initialized
DEBUG - 2011-08-26 06:57:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-26 06:57:30 --> Helper loaded: url_helper
DEBUG - 2011-08-26 06:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 06:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 06:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 06:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 06:57:30 --> Final output sent to browser
DEBUG - 2011-08-26 06:57:30 --> Total execution time: 0.1903
DEBUG - 2011-08-26 07:42:25 --> Config Class Initialized
DEBUG - 2011-08-26 07:42:25 --> Hooks Class Initialized
DEBUG - 2011-08-26 07:42:25 --> Utf8 Class Initialized
DEBUG - 2011-08-26 07:42:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 07:42:25 --> URI Class Initialized
DEBUG - 2011-08-26 07:42:25 --> Router Class Initialized
DEBUG - 2011-08-26 07:42:25 --> No URI present. Default controller set.
DEBUG - 2011-08-26 07:42:25 --> Output Class Initialized
DEBUG - 2011-08-26 07:42:25 --> Input Class Initialized
DEBUG - 2011-08-26 07:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 07:42:25 --> Language Class Initialized
DEBUG - 2011-08-26 07:42:25 --> Loader Class Initialized
DEBUG - 2011-08-26 07:42:25 --> Controller Class Initialized
DEBUG - 2011-08-26 07:42:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-26 07:42:25 --> Helper loaded: url_helper
DEBUG - 2011-08-26 07:42:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 07:42:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 07:42:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 07:42:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 07:42:25 --> Final output sent to browser
DEBUG - 2011-08-26 07:42:25 --> Total execution time: 0.2067
DEBUG - 2011-08-26 07:51:30 --> Config Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Hooks Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Utf8 Class Initialized
DEBUG - 2011-08-26 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 07:51:30 --> URI Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Router Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Output Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Input Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 07:51:30 --> Language Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Loader Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Controller Class Initialized
ERROR - 2011-08-26 07:51:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 07:51:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 07:51:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 07:51:30 --> Model Class Initialized
DEBUG - 2011-08-26 07:51:30 --> Model Class Initialized
DEBUG - 2011-08-26 07:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 07:51:31 --> Database Driver Class Initialized
DEBUG - 2011-08-26 07:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 07:51:31 --> Helper loaded: url_helper
DEBUG - 2011-08-26 07:51:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 07:51:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 07:51:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 07:51:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 07:51:31 --> Final output sent to browser
DEBUG - 2011-08-26 07:51:31 --> Total execution time: 0.2053
DEBUG - 2011-08-26 07:51:32 --> Config Class Initialized
DEBUG - 2011-08-26 07:51:32 --> Hooks Class Initialized
DEBUG - 2011-08-26 07:51:32 --> Utf8 Class Initialized
DEBUG - 2011-08-26 07:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 07:51:32 --> URI Class Initialized
DEBUG - 2011-08-26 07:51:32 --> Router Class Initialized
DEBUG - 2011-08-26 07:51:32 --> Output Class Initialized
DEBUG - 2011-08-26 07:51:32 --> Input Class Initialized
DEBUG - 2011-08-26 07:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 07:51:32 --> Language Class Initialized
DEBUG - 2011-08-26 07:51:32 --> Loader Class Initialized
DEBUG - 2011-08-26 07:51:33 --> Controller Class Initialized
DEBUG - 2011-08-26 07:51:33 --> Model Class Initialized
DEBUG - 2011-08-26 07:51:33 --> Model Class Initialized
DEBUG - 2011-08-26 07:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 07:51:33 --> Database Driver Class Initialized
DEBUG - 2011-08-26 07:51:33 --> Final output sent to browser
DEBUG - 2011-08-26 07:51:33 --> Total execution time: 0.6903
DEBUG - 2011-08-26 07:51:38 --> Config Class Initialized
DEBUG - 2011-08-26 07:51:38 --> Hooks Class Initialized
DEBUG - 2011-08-26 07:51:38 --> Utf8 Class Initialized
DEBUG - 2011-08-26 07:51:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 07:51:38 --> URI Class Initialized
DEBUG - 2011-08-26 07:51:38 --> Router Class Initialized
ERROR - 2011-08-26 07:51:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 07:51:39 --> Config Class Initialized
DEBUG - 2011-08-26 07:51:39 --> Hooks Class Initialized
DEBUG - 2011-08-26 07:51:39 --> Utf8 Class Initialized
DEBUG - 2011-08-26 07:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 07:51:39 --> URI Class Initialized
DEBUG - 2011-08-26 07:51:39 --> Router Class Initialized
ERROR - 2011-08-26 07:51:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 08:24:27 --> Config Class Initialized
DEBUG - 2011-08-26 08:24:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 08:24:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 08:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 08:24:27 --> URI Class Initialized
DEBUG - 2011-08-26 08:24:27 --> Router Class Initialized
ERROR - 2011-08-26 08:24:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 08:42:27 --> Config Class Initialized
DEBUG - 2011-08-26 08:42:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 08:42:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 08:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 08:42:28 --> URI Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Router Class Initialized
ERROR - 2011-08-26 08:42:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 08:42:28 --> Config Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Hooks Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Utf8 Class Initialized
DEBUG - 2011-08-26 08:42:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 08:42:28 --> URI Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Router Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Output Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Input Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 08:42:28 --> Language Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Loader Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Controller Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Model Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Model Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Model Class Initialized
DEBUG - 2011-08-26 08:42:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 08:42:28 --> Database Driver Class Initialized
DEBUG - 2011-08-26 08:42:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 08:42:28 --> Helper loaded: url_helper
DEBUG - 2011-08-26 08:42:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 08:42:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 08:42:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 08:42:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 08:42:28 --> Final output sent to browser
DEBUG - 2011-08-26 08:42:28 --> Total execution time: 0.4846
DEBUG - 2011-08-26 10:10:49 --> Config Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Config Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:10:49 --> URI Class Initialized
DEBUG - 2011-08-26 10:10:49 --> URI Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Router Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Router Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Output Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Output Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Input Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Input Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:10:49 --> Language Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Language Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Loader Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Loader Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Controller Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Controller Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Model Class Initialized
ERROR - 2011-08-26 10:10:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:10:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:10:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:10:49 --> Model Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Model Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Model Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Model Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:10:49 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:10:49 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:10:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:10:49 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:10:49 --> Final output sent to browser
DEBUG - 2011-08-26 10:10:49 --> Total execution time: 0.3160
DEBUG - 2011-08-26 10:10:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 10:10:50 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:10:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:10:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:10:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:10:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:10:50 --> Final output sent to browser
DEBUG - 2011-08-26 10:10:50 --> Total execution time: 0.4274
DEBUG - 2011-08-26 10:10:50 --> Config Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:10:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:10:50 --> URI Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Router Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Output Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Input Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:10:50 --> Language Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Loader Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Controller Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Model Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Model Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:10:50 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:10:50 --> Final output sent to browser
DEBUG - 2011-08-26 10:10:50 --> Total execution time: 0.5422
DEBUG - 2011-08-26 10:10:52 --> Config Class Initialized
DEBUG - 2011-08-26 10:10:52 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:10:52 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:10:52 --> URI Class Initialized
DEBUG - 2011-08-26 10:10:52 --> Router Class Initialized
ERROR - 2011-08-26 10:10:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 10:10:52 --> Config Class Initialized
DEBUG - 2011-08-26 10:10:52 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:10:52 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:10:52 --> URI Class Initialized
DEBUG - 2011-08-26 10:10:52 --> Router Class Initialized
ERROR - 2011-08-26 10:10:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 10:11:17 --> Config Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:11:17 --> URI Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Router Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Output Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Input Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:11:17 --> Language Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Loader Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Controller Class Initialized
ERROR - 2011-08-26 10:11:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:11:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:11:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:11:17 --> Model Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Model Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:11:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:11:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:11:17 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:11:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:11:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:11:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:11:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:11:17 --> Final output sent to browser
DEBUG - 2011-08-26 10:11:17 --> Total execution time: 0.0407
DEBUG - 2011-08-26 10:11:17 --> Config Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:11:17 --> URI Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Router Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Output Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Input Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:11:17 --> Language Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Loader Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Controller Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Model Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Model Class Initialized
DEBUG - 2011-08-26 10:11:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:11:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:11:18 --> Final output sent to browser
DEBUG - 2011-08-26 10:11:18 --> Total execution time: 0.6005
DEBUG - 2011-08-26 10:11:40 --> Config Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:11:40 --> URI Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Router Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Output Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Input Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:11:40 --> Language Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Loader Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Controller Class Initialized
ERROR - 2011-08-26 10:11:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:11:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:11:40 --> Model Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Model Class Initialized
DEBUG - 2011-08-26 10:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:11:40 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:11:40 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:11:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:11:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:11:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:11:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:11:40 --> Final output sent to browser
DEBUG - 2011-08-26 10:11:40 --> Total execution time: 0.0452
DEBUG - 2011-08-26 10:11:41 --> Config Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:11:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:11:41 --> URI Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Router Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Output Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Input Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:11:41 --> Language Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Loader Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Controller Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Model Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Model Class Initialized
DEBUG - 2011-08-26 10:11:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:11:41 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:11:42 --> Final output sent to browser
DEBUG - 2011-08-26 10:11:42 --> Total execution time: 0.7303
DEBUG - 2011-08-26 10:19:13 --> Config Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:19:13 --> URI Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Router Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Output Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Input Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:19:13 --> Language Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Loader Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Controller Class Initialized
ERROR - 2011-08-26 10:19:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:19:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:19:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:19:13 --> Model Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Model Class Initialized
DEBUG - 2011-08-26 10:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:19:13 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:19:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:19:13 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:19:13 --> Final output sent to browser
DEBUG - 2011-08-26 10:19:13 --> Total execution time: 0.0420
DEBUG - 2011-08-26 10:19:15 --> Config Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:19:15 --> URI Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Router Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Output Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Input Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:19:15 --> Language Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Loader Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Controller Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Model Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Model Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:19:15 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:19:15 --> Final output sent to browser
DEBUG - 2011-08-26 10:19:15 --> Total execution time: 0.4855
DEBUG - 2011-08-26 10:20:04 --> Config Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:20:04 --> URI Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Router Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Output Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Input Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:20:04 --> Language Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Loader Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Controller Class Initialized
ERROR - 2011-08-26 10:20:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:20:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:20:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:20:04 --> Model Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Model Class Initialized
DEBUG - 2011-08-26 10:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:20:04 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:20:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:20:04 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:20:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:20:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:20:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:20:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:20:04 --> Final output sent to browser
DEBUG - 2011-08-26 10:20:04 --> Total execution time: 0.0658
DEBUG - 2011-08-26 10:20:10 --> Config Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:20:10 --> URI Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Router Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Output Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Input Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:20:10 --> Language Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Loader Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Controller Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Model Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Model Class Initialized
DEBUG - 2011-08-26 10:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:20:10 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:20:11 --> Final output sent to browser
DEBUG - 2011-08-26 10:20:11 --> Total execution time: 1.0284
DEBUG - 2011-08-26 10:20:40 --> Config Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:20:40 --> URI Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Router Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Output Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Input Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:20:40 --> Language Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Loader Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Controller Class Initialized
ERROR - 2011-08-26 10:20:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:20:40 --> Model Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Model Class Initialized
DEBUG - 2011-08-26 10:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:20:40 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:20:40 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:20:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:20:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:20:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:20:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:20:40 --> Final output sent to browser
DEBUG - 2011-08-26 10:20:40 --> Total execution time: 0.0291
DEBUG - 2011-08-26 10:20:44 --> Config Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:20:44 --> URI Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Router Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Output Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Input Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:20:44 --> Language Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Loader Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Controller Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Model Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Model Class Initialized
DEBUG - 2011-08-26 10:20:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:20:44 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:20:45 --> Final output sent to browser
DEBUG - 2011-08-26 10:20:45 --> Total execution time: 0.6620
DEBUG - 2011-08-26 10:32:55 --> Config Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:32:55 --> URI Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Router Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Output Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Input Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:32:55 --> Language Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Loader Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Controller Class Initialized
ERROR - 2011-08-26 10:32:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:32:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:32:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:32:55 --> Model Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Model Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:32:55 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:32:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:32:55 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:32:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:32:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:32:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:32:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:32:55 --> Final output sent to browser
DEBUG - 2011-08-26 10:32:55 --> Total execution time: 0.0311
DEBUG - 2011-08-26 10:32:55 --> Config Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:32:55 --> URI Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Router Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Output Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Input Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:32:55 --> Language Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Loader Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Controller Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Model Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Model Class Initialized
DEBUG - 2011-08-26 10:32:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:32:55 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:32:56 --> Final output sent to browser
DEBUG - 2011-08-26 10:32:56 --> Total execution time: 0.5004
DEBUG - 2011-08-26 10:33:04 --> Config Class Initialized
DEBUG - 2011-08-26 10:33:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:33:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:33:04 --> URI Class Initialized
DEBUG - 2011-08-26 10:33:04 --> Router Class Initialized
ERROR - 2011-08-26 10:33:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 10:33:05 --> Config Class Initialized
DEBUG - 2011-08-26 10:33:05 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:33:05 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:33:05 --> URI Class Initialized
DEBUG - 2011-08-26 10:33:05 --> Router Class Initialized
ERROR - 2011-08-26 10:33:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 10:55:22 --> Config Class Initialized
DEBUG - 2011-08-26 10:55:22 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:55:22 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:55:22 --> URI Class Initialized
DEBUG - 2011-08-26 10:55:22 --> Router Class Initialized
DEBUG - 2011-08-26 10:55:22 --> Output Class Initialized
DEBUG - 2011-08-26 10:55:22 --> Input Class Initialized
DEBUG - 2011-08-26 10:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:55:22 --> Language Class Initialized
DEBUG - 2011-08-26 10:55:22 --> Loader Class Initialized
DEBUG - 2011-08-26 10:55:22 --> Controller Class Initialized
ERROR - 2011-08-26 10:55:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:55:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:55:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:55:23 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:55:23 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:55:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:55:23 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:55:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:55:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:55:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:55:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:55:23 --> Final output sent to browser
DEBUG - 2011-08-26 10:55:23 --> Total execution time: 0.0307
DEBUG - 2011-08-26 10:55:23 --> Config Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:55:23 --> URI Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Router Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Output Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Input Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:55:23 --> Language Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Loader Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Controller Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:55:23 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:55:24 --> Final output sent to browser
DEBUG - 2011-08-26 10:55:24 --> Total execution time: 0.5502
DEBUG - 2011-08-26 10:55:44 --> Config Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:55:44 --> URI Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Router Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Output Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Input Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:55:44 --> Language Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Loader Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Controller Class Initialized
ERROR - 2011-08-26 10:55:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:55:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:55:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:55:44 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:55:44 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:55:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:55:44 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:55:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:55:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:55:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:55:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:55:44 --> Final output sent to browser
DEBUG - 2011-08-26 10:55:44 --> Total execution time: 0.0508
DEBUG - 2011-08-26 10:55:45 --> Config Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:55:45 --> URI Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Router Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Output Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Input Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:55:45 --> Language Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Loader Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Controller Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:55:45 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:55:46 --> Final output sent to browser
DEBUG - 2011-08-26 10:55:46 --> Total execution time: 0.8669
DEBUG - 2011-08-26 10:55:50 --> Config Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:55:50 --> URI Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Router Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Output Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Input Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:55:50 --> Language Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Loader Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Controller Class Initialized
ERROR - 2011-08-26 10:55:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:55:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:55:50 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:55:50 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:55:50 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:55:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:55:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:55:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:55:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:55:50 --> Final output sent to browser
DEBUG - 2011-08-26 10:55:50 --> Total execution time: 0.0338
DEBUG - 2011-08-26 10:55:53 --> Config Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:55:53 --> URI Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Router Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Output Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Input Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:55:53 --> Language Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Loader Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Controller Class Initialized
ERROR - 2011-08-26 10:55:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:55:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:55:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:55:53 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:55:53 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:55:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:55:53 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:55:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:55:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:55:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:55:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:55:53 --> Final output sent to browser
DEBUG - 2011-08-26 10:55:53 --> Total execution time: 0.0323
DEBUG - 2011-08-26 10:55:54 --> Config Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:55:54 --> URI Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Router Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Output Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Input Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:55:54 --> Language Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Loader Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Controller Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Model Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:55:54 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:55:54 --> Final output sent to browser
DEBUG - 2011-08-26 10:55:54 --> Total execution time: 0.5788
DEBUG - 2011-08-26 10:56:07 --> Config Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:56:07 --> URI Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Router Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Output Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Input Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:56:07 --> Language Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Loader Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Controller Class Initialized
ERROR - 2011-08-26 10:56:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:56:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:56:07 --> Model Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Model Class Initialized
DEBUG - 2011-08-26 10:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:56:07 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:56:07 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:56:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:56:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:56:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:56:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:56:07 --> Final output sent to browser
DEBUG - 2011-08-26 10:56:07 --> Total execution time: 0.0911
DEBUG - 2011-08-26 10:56:08 --> Config Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:56:08 --> URI Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Router Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Output Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Input Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:56:08 --> Language Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Loader Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Controller Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Model Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Model Class Initialized
DEBUG - 2011-08-26 10:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:56:08 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:56:09 --> Final output sent to browser
DEBUG - 2011-08-26 10:56:09 --> Total execution time: 0.5606
DEBUG - 2011-08-26 10:56:24 --> Config Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:56:24 --> URI Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Router Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Output Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Input Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:56:24 --> Language Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Loader Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Controller Class Initialized
ERROR - 2011-08-26 10:56:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 10:56:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 10:56:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:56:24 --> Model Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Model Class Initialized
DEBUG - 2011-08-26 10:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:56:24 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:56:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 10:56:24 --> Helper loaded: url_helper
DEBUG - 2011-08-26 10:56:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 10:56:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 10:56:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 10:56:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 10:56:24 --> Final output sent to browser
DEBUG - 2011-08-26 10:56:24 --> Total execution time: 0.0477
DEBUG - 2011-08-26 10:56:25 --> Config Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Hooks Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Utf8 Class Initialized
DEBUG - 2011-08-26 10:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 10:56:25 --> URI Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Router Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Output Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Input Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 10:56:25 --> Language Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Loader Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Controller Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Model Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Model Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 10:56:25 --> Database Driver Class Initialized
DEBUG - 2011-08-26 10:56:25 --> Final output sent to browser
DEBUG - 2011-08-26 10:56:25 --> Total execution time: 0.7436
DEBUG - 2011-08-26 11:06:40 --> Config Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:06:40 --> URI Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Router Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Output Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Input Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:06:40 --> Language Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Loader Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Controller Class Initialized
ERROR - 2011-08-26 11:06:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 11:06:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 11:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:06:40 --> Model Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Model Class Initialized
DEBUG - 2011-08-26 11:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:06:40 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:06:40 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:06:40 --> Final output sent to browser
DEBUG - 2011-08-26 11:06:40 --> Total execution time: 0.0794
DEBUG - 2011-08-26 11:06:41 --> Config Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:06:41 --> URI Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Router Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Output Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Input Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:06:41 --> Language Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Loader Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Controller Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Model Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Model Class Initialized
DEBUG - 2011-08-26 11:06:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:06:41 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:06:42 --> Final output sent to browser
DEBUG - 2011-08-26 11:06:42 --> Total execution time: 0.5698
DEBUG - 2011-08-26 11:07:14 --> Config Class Initialized
DEBUG - 2011-08-26 11:07:14 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:07:14 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:07:14 --> URI Class Initialized
DEBUG - 2011-08-26 11:07:14 --> Router Class Initialized
ERROR - 2011-08-26 11:07:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 11:42:48 --> Config Class Initialized
DEBUG - 2011-08-26 11:42:48 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:42:48 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:42:48 --> URI Class Initialized
DEBUG - 2011-08-26 11:42:48 --> Router Class Initialized
ERROR - 2011-08-26 11:42:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 11:45:56 --> Config Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:45:56 --> URI Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Router Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Output Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Input Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:45:56 --> Language Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Loader Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Controller Class Initialized
DEBUG - 2011-08-26 11:45:56 --> Model Class Initialized
DEBUG - 2011-08-26 11:45:57 --> Model Class Initialized
DEBUG - 2011-08-26 11:45:57 --> Model Class Initialized
DEBUG - 2011-08-26 11:45:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:45:57 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:45:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 11:45:57 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:45:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:45:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:45:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:45:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:45:57 --> Final output sent to browser
DEBUG - 2011-08-26 11:45:57 --> Total execution time: 0.7138
DEBUG - 2011-08-26 11:45:59 --> Config Class Initialized
DEBUG - 2011-08-26 11:45:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:45:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:45:59 --> URI Class Initialized
DEBUG - 2011-08-26 11:45:59 --> Router Class Initialized
ERROR - 2011-08-26 11:45:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 11:46:12 --> Config Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:46:12 --> URI Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Router Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Output Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Input Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:46:12 --> Language Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Loader Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Controller Class Initialized
ERROR - 2011-08-26 11:46:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 11:46:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 11:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:46:12 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:46:12 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:46:12 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:46:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:46:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:46:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:46:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:46:12 --> Final output sent to browser
DEBUG - 2011-08-26 11:46:12 --> Total execution time: 0.0313
DEBUG - 2011-08-26 11:46:13 --> Config Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:46:13 --> URI Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Router Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Output Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Input Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:46:13 --> Language Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Loader Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Controller Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:46:13 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:46:14 --> Final output sent to browser
DEBUG - 2011-08-26 11:46:14 --> Total execution time: 0.6881
DEBUG - 2011-08-26 11:46:22 --> Config Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:46:22 --> URI Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Router Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Output Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Input Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:46:22 --> Language Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Loader Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Controller Class Initialized
ERROR - 2011-08-26 11:46:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 11:46:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 11:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:46:22 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:46:22 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:46:22 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:46:22 --> Final output sent to browser
DEBUG - 2011-08-26 11:46:22 --> Total execution time: 0.0292
DEBUG - 2011-08-26 11:46:23 --> Config Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:46:23 --> URI Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Router Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Output Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Input Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:46:23 --> Language Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Loader Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Controller Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:46:23 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:46:24 --> Final output sent to browser
DEBUG - 2011-08-26 11:46:24 --> Total execution time: 0.7998
DEBUG - 2011-08-26 11:46:40 --> Config Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:46:40 --> URI Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Router Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Output Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Input Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:46:40 --> Language Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Loader Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Controller Class Initialized
ERROR - 2011-08-26 11:46:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 11:46:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 11:46:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:46:40 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:46:40 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:46:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:46:40 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:46:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:46:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:46:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:46:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:46:40 --> Final output sent to browser
DEBUG - 2011-08-26 11:46:40 --> Total execution time: 0.0819
DEBUG - 2011-08-26 11:46:41 --> Config Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:46:41 --> URI Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Router Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Output Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Input Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:46:41 --> Language Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Loader Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Controller Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:46:41 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:46:42 --> Final output sent to browser
DEBUG - 2011-08-26 11:46:42 --> Total execution time: 0.5683
DEBUG - 2011-08-26 11:46:48 --> Config Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:46:48 --> URI Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Router Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Output Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Input Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:46:48 --> Language Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Loader Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Controller Class Initialized
ERROR - 2011-08-26 11:46:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 11:46:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 11:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:46:48 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:46:48 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:46:48 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:46:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:46:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:46:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:46:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:46:48 --> Final output sent to browser
DEBUG - 2011-08-26 11:46:48 --> Total execution time: 0.0356
DEBUG - 2011-08-26 11:46:49 --> Config Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:46:49 --> URI Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Router Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Output Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Input Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:46:49 --> Language Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Loader Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Controller Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Model Class Initialized
DEBUG - 2011-08-26 11:46:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:46:49 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:46:50 --> Final output sent to browser
DEBUG - 2011-08-26 11:46:50 --> Total execution time: 0.6442
DEBUG - 2011-08-26 11:52:23 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:23 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Router Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Output Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Input Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:52:23 --> Language Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Loader Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Controller Class Initialized
ERROR - 2011-08-26 11:52:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 11:52:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 11:52:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:52:23 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:52:23 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:52:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:52:24 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:52:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:52:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:52:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:52:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:52:24 --> Final output sent to browser
DEBUG - 2011-08-26 11:52:24 --> Total execution time: 0.0301
DEBUG - 2011-08-26 11:52:25 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:25 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Router Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Output Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Input Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:52:25 --> Language Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Loader Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Controller Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:52:25 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:52:25 --> Final output sent to browser
DEBUG - 2011-08-26 11:52:25 --> Total execution time: 0.4963
DEBUG - 2011-08-26 11:52:27 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:27 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:27 --> Router Class Initialized
ERROR - 2011-08-26 11:52:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 11:52:34 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:34 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Router Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Output Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Input Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:52:34 --> Language Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Loader Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Controller Class Initialized
ERROR - 2011-08-26 11:52:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 11:52:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 11:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:52:34 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:52:34 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:52:34 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:52:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:52:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:52:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:52:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:52:34 --> Final output sent to browser
DEBUG - 2011-08-26 11:52:34 --> Total execution time: 0.1079
DEBUG - 2011-08-26 11:52:35 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:35 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Router Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Output Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Input Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:52:35 --> Language Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Loader Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Controller Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:52:35 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:52:35 --> Final output sent to browser
DEBUG - 2011-08-26 11:52:35 --> Total execution time: 0.5891
DEBUG - 2011-08-26 11:52:36 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:36 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:36 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:36 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:36 --> Router Class Initialized
ERROR - 2011-08-26 11:52:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 11:52:40 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:40 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Router Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Output Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Input Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:52:40 --> Language Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Loader Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Controller Class Initialized
ERROR - 2011-08-26 11:52:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 11:52:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 11:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:52:40 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:52:40 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 11:52:40 --> Helper loaded: url_helper
DEBUG - 2011-08-26 11:52:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 11:52:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 11:52:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 11:52:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 11:52:40 --> Final output sent to browser
DEBUG - 2011-08-26 11:52:40 --> Total execution time: 0.1153
DEBUG - 2011-08-26 11:52:41 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:41 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Router Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Output Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Input Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 11:52:41 --> Language Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Loader Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Controller Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Model Class Initialized
DEBUG - 2011-08-26 11:52:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 11:52:41 --> Database Driver Class Initialized
DEBUG - 2011-08-26 11:52:42 --> Final output sent to browser
DEBUG - 2011-08-26 11:52:42 --> Total execution time: 0.7306
DEBUG - 2011-08-26 11:52:42 --> Config Class Initialized
DEBUG - 2011-08-26 11:52:42 --> Hooks Class Initialized
DEBUG - 2011-08-26 11:52:42 --> Utf8 Class Initialized
DEBUG - 2011-08-26 11:52:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 11:52:42 --> URI Class Initialized
DEBUG - 2011-08-26 11:52:42 --> Router Class Initialized
ERROR - 2011-08-26 11:52:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 13:06:04 --> Config Class Initialized
DEBUG - 2011-08-26 13:06:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:06:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:06:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:06:04 --> URI Class Initialized
DEBUG - 2011-08-26 13:06:04 --> Router Class Initialized
ERROR - 2011-08-26 13:06:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 13:30:38 --> Config Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:30:38 --> URI Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Router Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Output Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Input Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:30:38 --> Language Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Loader Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Controller Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Model Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Model Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Model Class Initialized
DEBUG - 2011-08-26 13:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:30:38 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:30:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:30:38 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:30:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:30:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:30:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:30:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:30:38 --> Final output sent to browser
DEBUG - 2011-08-26 13:30:38 --> Total execution time: 0.9149
DEBUG - 2011-08-26 13:30:41 --> Config Class Initialized
DEBUG - 2011-08-26 13:30:41 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:30:41 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:30:41 --> URI Class Initialized
DEBUG - 2011-08-26 13:30:41 --> Router Class Initialized
ERROR - 2011-08-26 13:30:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 13:30:42 --> Config Class Initialized
DEBUG - 2011-08-26 13:30:42 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:30:42 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:30:42 --> URI Class Initialized
DEBUG - 2011-08-26 13:30:42 --> Router Class Initialized
ERROR - 2011-08-26 13:30:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 13:31:32 --> Config Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:31:32 --> URI Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Router Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Output Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Input Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:31:32 --> Language Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Loader Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Controller Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Model Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Model Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Model Class Initialized
DEBUG - 2011-08-26 13:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:31:32 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:31:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:31:32 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:31:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:31:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:31:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:31:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:31:32 --> Final output sent to browser
DEBUG - 2011-08-26 13:31:32 --> Total execution time: 0.4216
DEBUG - 2011-08-26 13:32:00 --> Config Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:32:00 --> URI Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Router Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Output Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Input Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:32:00 --> Language Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Loader Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Controller Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:32:00 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:32:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:32:01 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:32:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:32:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:32:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:32:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:32:01 --> Final output sent to browser
DEBUG - 2011-08-26 13:32:01 --> Total execution time: 0.4838
DEBUG - 2011-08-26 13:32:06 --> Config Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:32:06 --> URI Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Router Class Initialized
ERROR - 2011-08-26 13:32:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 13:32:06 --> Config Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:32:06 --> URI Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Router Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Output Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Input Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:32:06 --> Language Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Loader Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Controller Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:32:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:32:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:32:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:32:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:32:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:32:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:32:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:32:06 --> Final output sent to browser
DEBUG - 2011-08-26 13:32:06 --> Total execution time: 0.0450
DEBUG - 2011-08-26 13:32:10 --> Config Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:32:10 --> URI Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Router Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Output Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Input Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:32:10 --> Language Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Loader Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Controller Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:32:10 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:32:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:32:10 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:32:10 --> Final output sent to browser
DEBUG - 2011-08-26 13:32:10 --> Total execution time: 0.0829
DEBUG - 2011-08-26 13:32:25 --> Config Class Initialized
DEBUG - 2011-08-26 13:32:25 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:32:25 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:32:25 --> URI Class Initialized
DEBUG - 2011-08-26 13:32:25 --> Router Class Initialized
DEBUG - 2011-08-26 13:32:25 --> Output Class Initialized
DEBUG - 2011-08-26 13:32:25 --> Input Class Initialized
DEBUG - 2011-08-26 13:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:32:25 --> Language Class Initialized
DEBUG - 2011-08-26 13:32:26 --> Loader Class Initialized
DEBUG - 2011-08-26 13:32:26 --> Controller Class Initialized
DEBUG - 2011-08-26 13:32:26 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:26 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:26 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:32:26 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:32:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:32:26 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:32:26 --> Final output sent to browser
DEBUG - 2011-08-26 13:32:26 --> Total execution time: 0.9018
DEBUG - 2011-08-26 13:32:28 --> Config Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:32:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:32:28 --> URI Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Router Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Output Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Input Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:32:28 --> Language Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Loader Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Controller Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:32:28 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:32:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:32:28 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:32:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:32:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:32:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:32:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:32:28 --> Final output sent to browser
DEBUG - 2011-08-26 13:32:28 --> Total execution time: 0.0449
DEBUG - 2011-08-26 13:32:39 --> Config Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:32:39 --> URI Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Router Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Output Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Input Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:32:39 --> Language Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Loader Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Controller Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:32:39 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:32:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:32:40 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:32:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:32:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:32:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:32:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:32:40 --> Final output sent to browser
DEBUG - 2011-08-26 13:32:40 --> Total execution time: 1.1882
DEBUG - 2011-08-26 13:32:49 --> Config Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:32:49 --> URI Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Router Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Output Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Input Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:32:49 --> Language Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Loader Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Controller Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Model Class Initialized
DEBUG - 2011-08-26 13:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:32:49 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:32:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:32:49 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:32:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:32:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:32:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:32:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:32:49 --> Final output sent to browser
DEBUG - 2011-08-26 13:32:49 --> Total execution time: 0.0543
DEBUG - 2011-08-26 13:33:03 --> Config Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:33:03 --> URI Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Router Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Output Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Input Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:33:03 --> Language Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Loader Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Controller Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:33:03 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:33:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:33:04 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:33:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:33:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:33:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:33:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:33:04 --> Final output sent to browser
DEBUG - 2011-08-26 13:33:04 --> Total execution time: 0.3030
DEBUG - 2011-08-26 13:33:05 --> Config Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:33:05 --> URI Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Router Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Output Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Input Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:33:05 --> Language Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Loader Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Controller Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:33:05 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:33:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:33:05 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:33:05 --> Final output sent to browser
DEBUG - 2011-08-26 13:33:05 --> Total execution time: 0.0578
DEBUG - 2011-08-26 13:33:46 --> Config Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:33:46 --> URI Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Router Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Output Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Input Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:33:46 --> Language Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Loader Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Controller Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:33:46 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:33:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:33:47 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:33:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:33:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:33:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:33:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:33:47 --> Final output sent to browser
DEBUG - 2011-08-26 13:33:47 --> Total execution time: 0.3790
DEBUG - 2011-08-26 13:33:48 --> Config Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:33:48 --> URI Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Router Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Output Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Input Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:33:48 --> Language Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Loader Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Controller Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Model Class Initialized
DEBUG - 2011-08-26 13:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:33:48 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:33:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:33:48 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:33:48 --> Final output sent to browser
DEBUG - 2011-08-26 13:33:48 --> Total execution time: 0.0444
DEBUG - 2011-08-26 13:34:04 --> Config Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:34:04 --> URI Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Router Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Output Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Input Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:34:04 --> Language Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Loader Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Controller Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:34:04 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:34:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:34:04 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:34:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:34:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:34:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:34:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:34:04 --> Final output sent to browser
DEBUG - 2011-08-26 13:34:04 --> Total execution time: 0.2854
DEBUG - 2011-08-26 13:34:05 --> Config Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:34:05 --> URI Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Router Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Output Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Input Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:34:05 --> Language Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Loader Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Controller Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:34:05 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:34:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:34:05 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:34:05 --> Final output sent to browser
DEBUG - 2011-08-26 13:34:05 --> Total execution time: 0.1061
DEBUG - 2011-08-26 13:34:18 --> Config Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:34:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:34:18 --> URI Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Router Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Output Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Input Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:34:18 --> Language Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Loader Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Controller Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:34:18 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:34:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:34:19 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:34:19 --> Final output sent to browser
DEBUG - 2011-08-26 13:34:19 --> Total execution time: 0.8640
DEBUG - 2011-08-26 13:34:20 --> Config Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:34:20 --> URI Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Router Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Output Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Input Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:34:20 --> Language Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Loader Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Controller Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Model Class Initialized
DEBUG - 2011-08-26 13:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:34:20 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:34:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:34:20 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:34:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:34:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:34:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:34:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:34:20 --> Final output sent to browser
DEBUG - 2011-08-26 13:34:20 --> Total execution time: 0.0793
DEBUG - 2011-08-26 13:35:07 --> Config Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:35:07 --> URI Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Router Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Output Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Input Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:35:07 --> Language Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Loader Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Controller Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:35:07 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:35:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:35:07 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:35:07 --> Final output sent to browser
DEBUG - 2011-08-26 13:35:07 --> Total execution time: 0.0586
DEBUG - 2011-08-26 13:35:19 --> Config Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:35:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:35:19 --> URI Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Router Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Output Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Input Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:35:19 --> Language Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Loader Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Controller Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:35:19 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:35:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:35:19 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:35:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:35:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:35:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:35:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:35:19 --> Final output sent to browser
DEBUG - 2011-08-26 13:35:19 --> Total execution time: 0.0696
DEBUG - 2011-08-26 13:35:33 --> Config Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:35:33 --> URI Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Router Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Output Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Input Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:35:33 --> Language Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Loader Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Controller Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:35:33 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:35:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:35:34 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:35:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:35:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:35:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:35:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:35:34 --> Final output sent to browser
DEBUG - 2011-08-26 13:35:34 --> Total execution time: 0.4853
DEBUG - 2011-08-26 13:35:35 --> Config Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:35:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:35:35 --> URI Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Router Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Output Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Input Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:35:35 --> Language Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Loader Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Controller Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Model Class Initialized
DEBUG - 2011-08-26 13:35:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:35:35 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:35:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:35:35 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:35:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:35:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:35:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:35:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:35:35 --> Final output sent to browser
DEBUG - 2011-08-26 13:35:35 --> Total execution time: 0.0603
DEBUG - 2011-08-26 13:36:03 --> Config Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:36:03 --> URI Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Router Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Output Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Input Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:36:03 --> Language Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Loader Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Controller Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:36:03 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:36:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:36:04 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:36:04 --> Final output sent to browser
DEBUG - 2011-08-26 13:36:04 --> Total execution time: 0.3706
DEBUG - 2011-08-26 13:36:17 --> Config Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:36:17 --> URI Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Router Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Output Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Input Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:36:17 --> Language Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Loader Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Controller Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:36:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:36:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:36:17 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:36:17 --> Final output sent to browser
DEBUG - 2011-08-26 13:36:17 --> Total execution time: 0.2802
DEBUG - 2011-08-26 13:36:26 --> Config Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:36:26 --> URI Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Router Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Output Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Input Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:36:26 --> Language Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Loader Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Controller Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:36:26 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:36:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:36:26 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:36:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:36:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:36:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:36:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:36:26 --> Final output sent to browser
DEBUG - 2011-08-26 13:36:26 --> Total execution time: 0.2340
DEBUG - 2011-08-26 13:36:36 --> Config Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:36:36 --> URI Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Router Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Output Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Input Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:36:36 --> Language Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Loader Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Controller Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:36:36 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:36:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:36:36 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:36:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:36:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:36:36 --> Final output sent to browser
DEBUG - 2011-08-26 13:36:36 --> Total execution time: 0.2429
DEBUG - 2011-08-26 13:36:43 --> Config Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:36:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:36:43 --> URI Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Router Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Output Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Input Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:36:43 --> Language Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Loader Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Controller Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Model Class Initialized
DEBUG - 2011-08-26 13:36:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:36:43 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:36:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:36:44 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:36:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:36:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:36:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:36:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:36:44 --> Final output sent to browser
DEBUG - 2011-08-26 13:36:44 --> Total execution time: 0.3015
DEBUG - 2011-08-26 13:37:06 --> Config Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:37:06 --> URI Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Router Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Output Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Input Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:37:06 --> Language Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Loader Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Controller Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:37:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:37:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:37:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:37:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:37:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:37:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:37:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:37:06 --> Final output sent to browser
DEBUG - 2011-08-26 13:37:06 --> Total execution time: 0.2818
DEBUG - 2011-08-26 13:37:19 --> Config Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:37:19 --> URI Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Router Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Output Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Input Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:37:19 --> Language Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Loader Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Controller Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:37:19 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:37:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:37:19 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:37:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:37:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:37:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:37:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:37:19 --> Final output sent to browser
DEBUG - 2011-08-26 13:37:19 --> Total execution time: 0.2678
DEBUG - 2011-08-26 13:37:41 --> Config Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:37:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:37:41 --> URI Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Router Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Output Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Input Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:37:41 --> Language Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Loader Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Controller Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:37:41 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:37:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:37:42 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:37:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:37:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:37:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:37:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:37:42 --> Final output sent to browser
DEBUG - 2011-08-26 13:37:42 --> Total execution time: 0.2168
DEBUG - 2011-08-26 13:37:55 --> Config Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:37:55 --> URI Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Router Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Output Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Input Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:37:55 --> Language Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Loader Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Controller Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Model Class Initialized
DEBUG - 2011-08-26 13:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:37:55 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:37:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:37:55 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:37:55 --> Final output sent to browser
DEBUG - 2011-08-26 13:37:55 --> Total execution time: 0.1367
DEBUG - 2011-08-26 13:38:06 --> Config Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:38:06 --> URI Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Router Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Output Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Input Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:38:06 --> Language Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Loader Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Controller Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:38:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:38:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:38:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:38:06 --> Final output sent to browser
DEBUG - 2011-08-26 13:38:06 --> Total execution time: 0.0584
DEBUG - 2011-08-26 13:38:43 --> Config Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:38:43 --> URI Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Router Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Output Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Input Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:38:43 --> Language Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Loader Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Controller Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:38:43 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:38:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:38:43 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:38:43 --> Final output sent to browser
DEBUG - 2011-08-26 13:38:43 --> Total execution time: 0.1521
DEBUG - 2011-08-26 13:38:52 --> Config Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:38:52 --> URI Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Router Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Output Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Input Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:38:52 --> Language Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Loader Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Controller Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:38:52 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:38:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:38:52 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:38:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:38:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:38:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:38:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:38:52 --> Final output sent to browser
DEBUG - 2011-08-26 13:38:52 --> Total execution time: 0.0485
DEBUG - 2011-08-26 13:38:53 --> Config Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:38:53 --> URI Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Router Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Output Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Input Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:38:53 --> Language Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Loader Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Controller Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:38:53 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:38:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:38:53 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:38:53 --> Final output sent to browser
DEBUG - 2011-08-26 13:38:53 --> Total execution time: 0.0685
DEBUG - 2011-08-26 13:38:55 --> Config Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:38:55 --> URI Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Router Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Output Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Input Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:38:55 --> Language Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Loader Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Controller Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:38:55 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:38:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:38:55 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:38:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:38:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:38:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:38:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:38:55 --> Final output sent to browser
DEBUG - 2011-08-26 13:38:55 --> Total execution time: 0.1241
DEBUG - 2011-08-26 13:38:59 --> Config Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:38:59 --> URI Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Router Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Output Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Input Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:38:59 --> Language Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Loader Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Controller Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Model Class Initialized
DEBUG - 2011-08-26 13:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:38:59 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:38:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:38:59 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:38:59 --> Final output sent to browser
DEBUG - 2011-08-26 13:38:59 --> Total execution time: 0.0523
DEBUG - 2011-08-26 13:39:01 --> Config Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:39:01 --> URI Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Router Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Output Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Input Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:39:01 --> Language Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Loader Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Controller Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:39:01 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:39:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:39:01 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:39:01 --> Final output sent to browser
DEBUG - 2011-08-26 13:39:01 --> Total execution time: 0.0800
DEBUG - 2011-08-26 13:39:02 --> Config Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:39:02 --> URI Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Router Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Output Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Input Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:39:02 --> Language Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Loader Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Controller Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:39:02 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:39:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:39:02 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:39:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:39:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:39:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:39:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:39:02 --> Final output sent to browser
DEBUG - 2011-08-26 13:39:02 --> Total execution time: 0.4550
DEBUG - 2011-08-26 13:39:06 --> Config Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:39:06 --> URI Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Router Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Output Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Input Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:39:06 --> Language Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Loader Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Controller Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Model Class Initialized
DEBUG - 2011-08-26 13:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 13:39:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 13:39:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 13:39:07 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:39:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:39:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:39:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:39:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:39:07 --> Final output sent to browser
DEBUG - 2011-08-26 13:39:07 --> Total execution time: 0.1194
DEBUG - 2011-08-26 13:54:59 --> Config Class Initialized
DEBUG - 2011-08-26 13:54:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 13:54:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 13:54:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 13:54:59 --> URI Class Initialized
DEBUG - 2011-08-26 13:54:59 --> Router Class Initialized
DEBUG - 2011-08-26 13:54:59 --> No URI present. Default controller set.
DEBUG - 2011-08-26 13:54:59 --> Output Class Initialized
DEBUG - 2011-08-26 13:54:59 --> Input Class Initialized
DEBUG - 2011-08-26 13:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 13:54:59 --> Language Class Initialized
DEBUG - 2011-08-26 13:54:59 --> Loader Class Initialized
DEBUG - 2011-08-26 13:54:59 --> Controller Class Initialized
DEBUG - 2011-08-26 13:54:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-26 13:54:59 --> Helper loaded: url_helper
DEBUG - 2011-08-26 13:54:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 13:54:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 13:54:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 13:54:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 13:54:59 --> Final output sent to browser
DEBUG - 2011-08-26 13:54:59 --> Total execution time: 0.6383
DEBUG - 2011-08-26 14:36:51 --> Config Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Hooks Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Utf8 Class Initialized
DEBUG - 2011-08-26 14:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 14:36:51 --> URI Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Router Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Output Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Input Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 14:36:51 --> Language Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Loader Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Controller Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Model Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Model Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Model Class Initialized
DEBUG - 2011-08-26 14:36:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 14:36:51 --> Database Driver Class Initialized
DEBUG - 2011-08-26 14:36:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 14:36:51 --> Helper loaded: url_helper
DEBUG - 2011-08-26 14:36:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 14:36:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 14:36:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 14:36:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 14:36:51 --> Final output sent to browser
DEBUG - 2011-08-26 14:36:51 --> Total execution time: 0.2540
DEBUG - 2011-08-26 14:36:55 --> Config Class Initialized
DEBUG - 2011-08-26 14:36:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 14:36:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 14:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 14:36:55 --> URI Class Initialized
DEBUG - 2011-08-26 14:36:55 --> Router Class Initialized
ERROR - 2011-08-26 14:36:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 14:36:55 --> Config Class Initialized
DEBUG - 2011-08-26 14:36:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 14:36:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 14:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 14:36:55 --> URI Class Initialized
DEBUG - 2011-08-26 14:36:55 --> Router Class Initialized
ERROR - 2011-08-26 14:36:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 14:36:56 --> Config Class Initialized
DEBUG - 2011-08-26 14:36:56 --> Hooks Class Initialized
DEBUG - 2011-08-26 14:36:56 --> Utf8 Class Initialized
DEBUG - 2011-08-26 14:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 14:36:56 --> URI Class Initialized
DEBUG - 2011-08-26 14:36:56 --> Router Class Initialized
ERROR - 2011-08-26 14:36:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 14:37:34 --> Config Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Hooks Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Utf8 Class Initialized
DEBUG - 2011-08-26 14:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 14:37:34 --> URI Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Router Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Output Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Input Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 14:37:34 --> Language Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Loader Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Controller Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 14:37:34 --> Database Driver Class Initialized
DEBUG - 2011-08-26 14:37:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 14:37:34 --> Helper loaded: url_helper
DEBUG - 2011-08-26 14:37:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 14:37:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 14:37:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 14:37:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 14:37:34 --> Final output sent to browser
DEBUG - 2011-08-26 14:37:34 --> Total execution time: 0.0463
DEBUG - 2011-08-26 14:37:37 --> Config Class Initialized
DEBUG - 2011-08-26 14:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-26 14:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-26 14:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 14:37:37 --> URI Class Initialized
DEBUG - 2011-08-26 14:37:37 --> Router Class Initialized
ERROR - 2011-08-26 14:37:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 14:37:44 --> Config Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Hooks Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Utf8 Class Initialized
DEBUG - 2011-08-26 14:37:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 14:37:44 --> URI Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Router Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Output Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Input Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 14:37:44 --> Language Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Loader Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Controller Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 14:37:44 --> Database Driver Class Initialized
DEBUG - 2011-08-26 14:37:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 14:37:45 --> Helper loaded: url_helper
DEBUG - 2011-08-26 14:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 14:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 14:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 14:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 14:37:45 --> Final output sent to browser
DEBUG - 2011-08-26 14:37:45 --> Total execution time: 0.4496
DEBUG - 2011-08-26 14:37:50 --> Config Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Hooks Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Utf8 Class Initialized
DEBUG - 2011-08-26 14:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 14:37:50 --> URI Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Router Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Output Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Input Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 14:37:50 --> Language Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Loader Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Controller Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Model Class Initialized
DEBUG - 2011-08-26 14:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 14:37:50 --> Database Driver Class Initialized
DEBUG - 2011-08-26 14:37:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 14:37:50 --> Helper loaded: url_helper
DEBUG - 2011-08-26 14:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 14:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 14:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 14:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 14:37:50 --> Final output sent to browser
DEBUG - 2011-08-26 14:37:50 --> Total execution time: 0.0452
DEBUG - 2011-08-26 15:35:53 --> Config Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:35:53 --> URI Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Router Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Output Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Input Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 15:35:53 --> Language Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Loader Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Controller Class Initialized
ERROR - 2011-08-26 15:35:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 15:35:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 15:35:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:35:53 --> Model Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Model Class Initialized
DEBUG - 2011-08-26 15:35:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 15:35:53 --> Database Driver Class Initialized
DEBUG - 2011-08-26 15:35:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:35:53 --> Helper loaded: url_helper
DEBUG - 2011-08-26 15:35:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 15:35:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 15:35:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 15:35:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 15:35:53 --> Final output sent to browser
DEBUG - 2011-08-26 15:35:53 --> Total execution time: 0.1201
DEBUG - 2011-08-26 15:35:54 --> Config Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:35:54 --> URI Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Router Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Output Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Input Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 15:35:54 --> Language Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Loader Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Controller Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Model Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Model Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 15:35:54 --> Database Driver Class Initialized
DEBUG - 2011-08-26 15:35:54 --> Final output sent to browser
DEBUG - 2011-08-26 15:35:54 --> Total execution time: 0.6593
DEBUG - 2011-08-26 15:35:55 --> Config Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:35:55 --> URI Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Router Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Output Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Input Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 15:35:55 --> Language Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Loader Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Controller Class Initialized
ERROR - 2011-08-26 15:35:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 15:35:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 15:35:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:35:55 --> Model Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Model Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 15:35:55 --> Database Driver Class Initialized
DEBUG - 2011-08-26 15:35:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:35:55 --> Helper loaded: url_helper
DEBUG - 2011-08-26 15:35:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 15:35:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 15:35:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 15:35:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 15:35:55 --> Final output sent to browser
DEBUG - 2011-08-26 15:35:55 --> Total execution time: 0.0577
DEBUG - 2011-08-26 15:35:55 --> Config Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:35:55 --> URI Class Initialized
DEBUG - 2011-08-26 15:35:55 --> Router Class Initialized
ERROR - 2011-08-26 15:35:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 15:35:56 --> Config Class Initialized
DEBUG - 2011-08-26 15:35:56 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:35:56 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:35:56 --> URI Class Initialized
DEBUG - 2011-08-26 15:35:56 --> Router Class Initialized
ERROR - 2011-08-26 15:35:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 15:35:56 --> Config Class Initialized
DEBUG - 2011-08-26 15:35:56 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:35:56 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:35:56 --> URI Class Initialized
DEBUG - 2011-08-26 15:35:56 --> Router Class Initialized
ERROR - 2011-08-26 15:35:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 15:36:06 --> Config Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:36:06 --> URI Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Router Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Output Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Input Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 15:36:06 --> Language Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Loader Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Controller Class Initialized
ERROR - 2011-08-26 15:36:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 15:36:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 15:36:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:36:06 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 15:36:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 15:36:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:36:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 15:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 15:36:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 15:36:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 15:36:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 15:36:06 --> Final output sent to browser
DEBUG - 2011-08-26 15:36:06 --> Total execution time: 0.0313
DEBUG - 2011-08-26 15:36:07 --> Config Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:36:07 --> URI Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Router Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Output Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Input Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 15:36:07 --> Language Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Loader Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Controller Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 15:36:07 --> Database Driver Class Initialized
DEBUG - 2011-08-26 15:36:07 --> Final output sent to browser
DEBUG - 2011-08-26 15:36:07 --> Total execution time: 0.4695
DEBUG - 2011-08-26 15:36:23 --> Config Class Initialized
DEBUG - 2011-08-26 15:36:23 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:36:23 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:36:23 --> URI Class Initialized
DEBUG - 2011-08-26 15:36:23 --> Router Class Initialized
DEBUG - 2011-08-26 15:36:23 --> Output Class Initialized
DEBUG - 2011-08-26 15:36:23 --> Input Class Initialized
DEBUG - 2011-08-26 15:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 15:36:23 --> Language Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Loader Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Controller Class Initialized
ERROR - 2011-08-26 15:36:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 15:36:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 15:36:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:36:24 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 15:36:24 --> Database Driver Class Initialized
DEBUG - 2011-08-26 15:36:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:36:24 --> Helper loaded: url_helper
DEBUG - 2011-08-26 15:36:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 15:36:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 15:36:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 15:36:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 15:36:24 --> Final output sent to browser
DEBUG - 2011-08-26 15:36:24 --> Total execution time: 0.0725
DEBUG - 2011-08-26 15:36:24 --> Config Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:36:24 --> URI Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Router Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Output Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Input Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 15:36:24 --> Language Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Loader Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Controller Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 15:36:24 --> Database Driver Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Config Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Hooks Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Utf8 Class Initialized
DEBUG - 2011-08-26 15:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 15:36:25 --> URI Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Router Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Output Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Input Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 15:36:25 --> Language Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Loader Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Controller Class Initialized
ERROR - 2011-08-26 15:36:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 15:36:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 15:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:36:25 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Model Class Initialized
DEBUG - 2011-08-26 15:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 15:36:25 --> Database Driver Class Initialized
DEBUG - 2011-08-26 15:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 15:36:25 --> Helper loaded: url_helper
DEBUG - 2011-08-26 15:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 15:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 15:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 15:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 15:36:25 --> Final output sent to browser
DEBUG - 2011-08-26 15:36:25 --> Total execution time: 0.0450
DEBUG - 2011-08-26 15:36:25 --> Final output sent to browser
DEBUG - 2011-08-26 15:36:25 --> Total execution time: 0.5766
DEBUG - 2011-08-26 16:00:37 --> Config Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Hooks Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Utf8 Class Initialized
DEBUG - 2011-08-26 16:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 16:00:37 --> URI Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Router Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Output Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Input Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 16:00:37 --> Language Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Loader Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Controller Class Initialized
ERROR - 2011-08-26 16:00:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 16:00:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 16:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 16:00:37 --> Model Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Model Class Initialized
DEBUG - 2011-08-26 16:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 16:00:37 --> Database Driver Class Initialized
DEBUG - 2011-08-26 16:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 16:00:37 --> Helper loaded: url_helper
DEBUG - 2011-08-26 16:00:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 16:00:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 16:00:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 16:00:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 16:00:37 --> Final output sent to browser
DEBUG - 2011-08-26 16:00:37 --> Total execution time: 0.0995
DEBUG - 2011-08-26 16:00:39 --> Config Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Hooks Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Utf8 Class Initialized
DEBUG - 2011-08-26 16:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 16:00:39 --> URI Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Router Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Output Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Input Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 16:00:39 --> Language Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Loader Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Controller Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Model Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Model Class Initialized
DEBUG - 2011-08-26 16:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 16:00:39 --> Database Driver Class Initialized
DEBUG - 2011-08-26 16:00:40 --> Final output sent to browser
DEBUG - 2011-08-26 16:00:40 --> Total execution time: 1.1531
DEBUG - 2011-08-26 16:00:42 --> Config Class Initialized
DEBUG - 2011-08-26 16:00:42 --> Hooks Class Initialized
DEBUG - 2011-08-26 16:00:42 --> Utf8 Class Initialized
DEBUG - 2011-08-26 16:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 16:00:42 --> URI Class Initialized
DEBUG - 2011-08-26 16:00:42 --> Router Class Initialized
ERROR - 2011-08-26 16:00:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 16:06:13 --> Config Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Hooks Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Utf8 Class Initialized
DEBUG - 2011-08-26 16:06:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 16:06:13 --> URI Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Router Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Output Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Input Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 16:06:13 --> Language Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Loader Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Controller Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Model Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Model Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Model Class Initialized
DEBUG - 2011-08-26 16:06:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 16:06:13 --> Database Driver Class Initialized
DEBUG - 2011-08-26 16:06:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 16:06:14 --> Helper loaded: url_helper
DEBUG - 2011-08-26 16:06:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 16:06:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 16:06:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 16:06:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 16:06:14 --> Final output sent to browser
DEBUG - 2011-08-26 16:06:14 --> Total execution time: 0.6211
DEBUG - 2011-08-26 16:22:32 --> Config Class Initialized
DEBUG - 2011-08-26 16:22:32 --> Hooks Class Initialized
DEBUG - 2011-08-26 16:22:32 --> Utf8 Class Initialized
DEBUG - 2011-08-26 16:22:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 16:22:32 --> URI Class Initialized
DEBUG - 2011-08-26 16:22:32 --> Router Class Initialized
ERROR - 2011-08-26 16:22:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 16:22:33 --> Config Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Hooks Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Utf8 Class Initialized
DEBUG - 2011-08-26 16:22:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 16:22:33 --> URI Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Router Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Output Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Input Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 16:22:33 --> Language Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Loader Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Controller Class Initialized
ERROR - 2011-08-26 16:22:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 16:22:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 16:22:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 16:22:33 --> Model Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Model Class Initialized
DEBUG - 2011-08-26 16:22:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 16:22:33 --> Database Driver Class Initialized
DEBUG - 2011-08-26 16:22:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 16:22:33 --> Helper loaded: url_helper
DEBUG - 2011-08-26 16:22:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 16:22:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 16:22:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 16:22:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 16:22:33 --> Final output sent to browser
DEBUG - 2011-08-26 16:22:33 --> Total execution time: 0.0339
DEBUG - 2011-08-26 16:35:46 --> Config Class Initialized
DEBUG - 2011-08-26 16:35:46 --> Hooks Class Initialized
DEBUG - 2011-08-26 16:35:46 --> Utf8 Class Initialized
DEBUG - 2011-08-26 16:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 16:35:46 --> URI Class Initialized
DEBUG - 2011-08-26 16:35:46 --> Router Class Initialized
ERROR - 2011-08-26 16:35:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 17:15:45 --> Config Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:15:45 --> URI Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Router Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Output Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Input Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:15:45 --> Language Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Loader Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Controller Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Model Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Model Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Model Class Initialized
DEBUG - 2011-08-26 17:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:15:45 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:15:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:15:46 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:15:46 --> Final output sent to browser
DEBUG - 2011-08-26 17:15:46 --> Total execution time: 0.4972
DEBUG - 2011-08-26 17:15:50 --> Config Class Initialized
DEBUG - 2011-08-26 17:15:50 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:15:50 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:15:50 --> URI Class Initialized
DEBUG - 2011-08-26 17:15:50 --> Router Class Initialized
ERROR - 2011-08-26 17:15:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 17:16:03 --> Config Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:16:03 --> URI Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Router Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Output Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Input Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:16:03 --> Language Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Loader Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Controller Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:16:03 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:16:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:16:03 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:16:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:16:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:16:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:16:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:16:03 --> Final output sent to browser
DEBUG - 2011-08-26 17:16:03 --> Total execution time: 0.2519
DEBUG - 2011-08-26 17:16:13 --> Config Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:16:13 --> URI Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Router Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Output Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Input Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:16:13 --> Language Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Loader Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Controller Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:16:13 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:16:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:16:13 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:16:13 --> Final output sent to browser
DEBUG - 2011-08-26 17:16:13 --> Total execution time: 0.3864
DEBUG - 2011-08-26 17:16:24 --> Config Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:16:24 --> URI Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Router Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Output Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Input Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:16:24 --> Language Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Loader Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Controller Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:16:24 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:16:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:16:24 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:16:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:16:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:16:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:16:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:16:24 --> Final output sent to browser
DEBUG - 2011-08-26 17:16:24 --> Total execution time: 0.2315
DEBUG - 2011-08-26 17:16:46 --> Config Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:16:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:16:46 --> URI Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Router Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Output Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Input Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:16:46 --> Language Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Loader Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Controller Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Model Class Initialized
DEBUG - 2011-08-26 17:16:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:16:46 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:16:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:16:46 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:16:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:16:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:16:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:16:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:16:46 --> Final output sent to browser
DEBUG - 2011-08-26 17:16:46 --> Total execution time: 0.1870
DEBUG - 2011-08-26 17:17:20 --> Config Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:17:20 --> URI Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Router Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Output Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Input Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:17:20 --> Language Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Loader Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Controller Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:17:20 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:17:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:17:20 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:17:20 --> Final output sent to browser
DEBUG - 2011-08-26 17:17:20 --> Total execution time: 0.5056
DEBUG - 2011-08-26 17:17:22 --> Config Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:17:22 --> URI Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Router Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Output Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Input Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:17:22 --> Language Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Loader Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Controller Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:17:22 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:17:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:17:22 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:17:22 --> Final output sent to browser
DEBUG - 2011-08-26 17:17:22 --> Total execution time: 0.0517
DEBUG - 2011-08-26 17:17:33 --> Config Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:17:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:17:33 --> URI Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Router Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Output Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Input Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:17:33 --> Language Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Loader Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Controller Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:17:33 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:17:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:17:33 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:17:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:17:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:17:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:17:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:17:33 --> Final output sent to browser
DEBUG - 2011-08-26 17:17:33 --> Total execution time: 0.0601
DEBUG - 2011-08-26 17:17:41 --> Config Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:17:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:17:41 --> URI Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Router Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Output Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Input Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:17:41 --> Language Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Loader Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Controller Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:17:41 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:17:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:17:42 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:17:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:17:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:17:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:17:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:17:42 --> Final output sent to browser
DEBUG - 2011-08-26 17:17:42 --> Total execution time: 0.3884
DEBUG - 2011-08-26 17:17:44 --> Config Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:17:44 --> URI Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Router Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Output Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Input Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:17:44 --> Language Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Loader Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Controller Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:17:44 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:17:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:17:44 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:17:44 --> Final output sent to browser
DEBUG - 2011-08-26 17:17:44 --> Total execution time: 0.1214
DEBUG - 2011-08-26 17:17:51 --> Config Class Initialized
DEBUG - 2011-08-26 17:17:51 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:17:51 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:17:52 --> URI Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Router Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Output Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Input Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:17:52 --> Language Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Loader Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Controller Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:17:52 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:17:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:17:52 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:17:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:17:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:17:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:17:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:17:52 --> Final output sent to browser
DEBUG - 2011-08-26 17:17:52 --> Total execution time: 0.5634
DEBUG - 2011-08-26 17:17:53 --> Config Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:17:53 --> URI Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Router Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Output Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Input Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:17:53 --> Language Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Loader Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Controller Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Model Class Initialized
DEBUG - 2011-08-26 17:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:17:53 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:17:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:17:53 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:17:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:17:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:17:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:17:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:17:53 --> Final output sent to browser
DEBUG - 2011-08-26 17:17:53 --> Total execution time: 0.0461
DEBUG - 2011-08-26 17:18:01 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:01 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:01 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:01 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:02 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:02 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:02 --> Total execution time: 1.0543
DEBUG - 2011-08-26 17:18:05 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:05 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:05 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:05 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:05 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:05 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:05 --> Total execution time: 0.0471
DEBUG - 2011-08-26 17:18:10 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:10 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:10 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:10 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:10 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:10 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:10 --> Total execution time: 0.2102
DEBUG - 2011-08-26 17:18:11 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:11 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:11 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:11 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:11 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:11 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:11 --> Total execution time: 0.0440
DEBUG - 2011-08-26 17:18:17 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:17 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:17 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:18 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:18 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:18 --> Total execution time: 0.3745
DEBUG - 2011-08-26 17:18:20 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:20 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:20 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:20 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:20 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:20 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:20 --> Total execution time: 0.0624
DEBUG - 2011-08-26 17:18:32 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:32 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:32 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:32 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:32 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:32 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:32 --> Total execution time: 0.2476
DEBUG - 2011-08-26 17:18:33 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:33 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:33 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:33 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:33 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:33 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:33 --> Total execution time: 0.0448
DEBUG - 2011-08-26 17:18:46 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:46 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:46 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:46 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:46 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:46 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:46 --> Total execution time: 0.4183
DEBUG - 2011-08-26 17:18:47 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:47 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:47 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:47 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:47 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:47 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:47 --> Total execution time: 0.0509
DEBUG - 2011-08-26 17:18:57 --> Config Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:18:57 --> URI Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Router Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Output Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Input Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:18:57 --> Language Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Loader Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Controller Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Model Class Initialized
DEBUG - 2011-08-26 17:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:18:57 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:18:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:18:58 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:18:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:18:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:18:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:18:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:18:58 --> Final output sent to browser
DEBUG - 2011-08-26 17:18:58 --> Total execution time: 1.1317
DEBUG - 2011-08-26 17:19:00 --> Config Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:19:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:19:00 --> URI Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Router Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Output Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Input Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:19:00 --> Language Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Loader Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Controller Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Model Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Model Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Model Class Initialized
DEBUG - 2011-08-26 17:19:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:19:00 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:19:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 17:19:00 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:19:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:19:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:19:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:19:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:19:00 --> Final output sent to browser
DEBUG - 2011-08-26 17:19:00 --> Total execution time: 0.0531
DEBUG - 2011-08-26 17:36:54 --> Config Class Initialized
DEBUG - 2011-08-26 17:36:54 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:36:54 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:36:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:36:54 --> URI Class Initialized
DEBUG - 2011-08-26 17:36:54 --> Router Class Initialized
ERROR - 2011-08-26 17:36:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-26 17:49:50 --> Config Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Hooks Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Utf8 Class Initialized
DEBUG - 2011-08-26 17:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 17:49:50 --> URI Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Router Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Output Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Input Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 17:49:50 --> Language Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Loader Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Controller Class Initialized
ERROR - 2011-08-26 17:49:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 17:49:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 17:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 17:49:50 --> Model Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Model Class Initialized
DEBUG - 2011-08-26 17:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 17:49:50 --> Database Driver Class Initialized
DEBUG - 2011-08-26 17:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 17:49:50 --> Helper loaded: url_helper
DEBUG - 2011-08-26 17:49:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 17:49:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 17:49:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 17:49:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 17:49:50 --> Final output sent to browser
DEBUG - 2011-08-26 17:49:50 --> Total execution time: 0.0710
DEBUG - 2011-08-26 18:36:14 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:14 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Router Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Output Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Input Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:36:14 --> Language Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Loader Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Controller Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:36:14 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:36:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 18:36:14 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:36:14 --> Final output sent to browser
DEBUG - 2011-08-26 18:36:14 --> Total execution time: 0.2634
DEBUG - 2011-08-26 18:36:16 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:16 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Router Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Output Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Input Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:36:16 --> Language Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Loader Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Controller Class Initialized
ERROR - 2011-08-26 18:36:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:36:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:36:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:36:16 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:36:16 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:36:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:36:16 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:36:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:36:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:36:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:36:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:36:16 --> Final output sent to browser
DEBUG - 2011-08-26 18:36:16 --> Total execution time: 0.0299
DEBUG - 2011-08-26 18:36:16 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:16 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Router Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Output Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Input Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:36:16 --> Language Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Loader Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Controller Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:36:16 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:36:17 --> Final output sent to browser
DEBUG - 2011-08-26 18:36:17 --> Total execution time: 0.5739
DEBUG - 2011-08-26 18:36:18 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:18 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:18 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:18 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:18 --> Router Class Initialized
ERROR - 2011-08-26 18:36:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 18:36:18 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:18 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:18 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:18 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:18 --> Router Class Initialized
ERROR - 2011-08-26 18:36:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 18:36:37 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:37 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Router Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Output Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Input Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:36:37 --> Language Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Loader Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Controller Class Initialized
ERROR - 2011-08-26 18:36:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:36:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:36:37 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:36:38 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:36:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:36:38 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:36:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:36:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:36:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:36:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:36:38 --> Final output sent to browser
DEBUG - 2011-08-26 18:36:38 --> Total execution time: 0.0334
DEBUG - 2011-08-26 18:36:38 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:38 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Router Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Output Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Input Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:36:38 --> Language Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Loader Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Controller Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:36:38 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:36:38 --> Final output sent to browser
DEBUG - 2011-08-26 18:36:38 --> Total execution time: 0.6016
DEBUG - 2011-08-26 18:36:52 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:52 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Router Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Output Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Input Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:36:52 --> Language Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Loader Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Controller Class Initialized
ERROR - 2011-08-26 18:36:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:36:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:36:52 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:36:52 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:36:52 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:36:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:36:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:36:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:36:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:36:52 --> Final output sent to browser
DEBUG - 2011-08-26 18:36:52 --> Total execution time: 0.0291
DEBUG - 2011-08-26 18:36:52 --> Config Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:36:52 --> URI Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Router Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Output Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Input Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:36:52 --> Language Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Loader Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Controller Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Model Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:36:52 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:36:52 --> Final output sent to browser
DEBUG - 2011-08-26 18:36:52 --> Total execution time: 0.4995
DEBUG - 2011-08-26 18:37:01 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:01 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:01 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Controller Class Initialized
ERROR - 2011-08-26 18:37:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:37:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:37:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:01 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:01 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:01 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:37:01 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:01 --> Total execution time: 0.0849
DEBUG - 2011-08-26 18:37:01 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:01 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:01 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Controller Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:01 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:02 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:02 --> Total execution time: 0.8544
DEBUG - 2011-08-26 18:37:10 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:10 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:10 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Controller Class Initialized
ERROR - 2011-08-26 18:37:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:37:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:10 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:10 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:10 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:37:10 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:10 --> Total execution time: 0.0287
DEBUG - 2011-08-26 18:37:11 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:11 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:11 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Controller Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:11 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:11 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:11 --> Total execution time: 0.5941
DEBUG - 2011-08-26 18:37:20 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:20 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:20 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Controller Class Initialized
ERROR - 2011-08-26 18:37:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:37:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:20 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:20 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:20 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:37:20 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:20 --> Total execution time: 0.0279
DEBUG - 2011-08-26 18:37:21 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:21 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:21 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Controller Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:21 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:21 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:21 --> Total execution time: 0.4997
DEBUG - 2011-08-26 18:37:32 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:32 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:32 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Controller Class Initialized
ERROR - 2011-08-26 18:37:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:37:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:37:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:32 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:32 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:32 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:37:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:37:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:37:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:37:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:37:32 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:32 --> Total execution time: 0.0276
DEBUG - 2011-08-26 18:37:32 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:32 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:32 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Controller Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:32 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:33 --> Total execution time: 0.5633
DEBUG - 2011-08-26 18:37:33 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:33 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:33 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Controller Class Initialized
ERROR - 2011-08-26 18:37:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:37:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:37:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:33 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:33 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:33 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:37:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:37:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:37:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:37:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:37:33 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:33 --> Total execution time: 0.0327
DEBUG - 2011-08-26 18:37:55 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:55 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:55 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Controller Class Initialized
ERROR - 2011-08-26 18:37:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:37:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:37:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:55 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:55 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:55 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:37:55 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:55 --> Total execution time: 0.0274
DEBUG - 2011-08-26 18:37:55 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:55 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:55 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Controller Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:55 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:56 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:56 --> Total execution time: 0.5045
DEBUG - 2011-08-26 18:37:57 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:57 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:57 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Controller Class Initialized
ERROR - 2011-08-26 18:37:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:37:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:37:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:57 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:57 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:37:57 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:37:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:37:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:37:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:37:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:37:57 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:57 --> Total execution time: 0.0264
DEBUG - 2011-08-26 18:37:57 --> Config Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:37:57 --> URI Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Router Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Output Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Input Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:37:57 --> Language Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Loader Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Controller Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Model Class Initialized
DEBUG - 2011-08-26 18:37:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:37:57 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:37:58 --> Final output sent to browser
DEBUG - 2011-08-26 18:37:58 --> Total execution time: 0.5318
DEBUG - 2011-08-26 18:38:04 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:04 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:04 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Controller Class Initialized
ERROR - 2011-08-26 18:38:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:38:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:38:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:04 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:04 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:04 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:38:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:38:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:38:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:38:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:38:04 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:04 --> Total execution time: 0.0290
DEBUG - 2011-08-26 18:38:04 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:04 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:04 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Controller Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:04 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:04 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:04 --> Total execution time: 0.5013
DEBUG - 2011-08-26 18:38:06 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:06 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:06 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Controller Class Initialized
ERROR - 2011-08-26 18:38:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:38:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:38:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:38:06 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:06 --> Total execution time: 0.0334
DEBUG - 2011-08-26 18:38:06 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:06 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:06 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Controller Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:07 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:07 --> Total execution time: 0.5981
DEBUG - 2011-08-26 18:38:11 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:11 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:11 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Controller Class Initialized
ERROR - 2011-08-26 18:38:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:38:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:11 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:11 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:11 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:38:11 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:11 --> Total execution time: 0.0288
DEBUG - 2011-08-26 18:38:12 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:12 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:12 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Controller Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:12 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:12 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:12 --> Total execution time: 0.4959
DEBUG - 2011-08-26 18:38:13 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:13 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:13 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Controller Class Initialized
ERROR - 2011-08-26 18:38:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:38:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:13 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:13 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:13 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:38:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:38:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:38:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:38:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:38:13 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:13 --> Total execution time: 0.0262
DEBUG - 2011-08-26 18:38:17 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:17 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:17 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Controller Class Initialized
ERROR - 2011-08-26 18:38:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:38:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:38:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:17 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:17 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:38:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:38:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:38:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:38:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:38:17 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:17 --> Total execution time: 0.0313
DEBUG - 2011-08-26 18:38:17 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:17 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:17 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Controller Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:18 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:18 --> Total execution time: 0.6070
DEBUG - 2011-08-26 18:38:21 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:21 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:21 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Controller Class Initialized
ERROR - 2011-08-26 18:38:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:38:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:38:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:21 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:21 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:21 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:38:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:38:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:38:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:38:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:38:21 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:21 --> Total execution time: 0.0330
DEBUG - 2011-08-26 18:38:21 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:21 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:21 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Controller Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:21 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:21 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:21 --> Total execution time: 0.5644
DEBUG - 2011-08-26 18:38:27 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:27 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:27 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Controller Class Initialized
ERROR - 2011-08-26 18:38:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:38:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:38:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:27 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:27 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:27 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:38:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:38:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:38:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:38:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:38:27 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:27 --> Total execution time: 0.0274
DEBUG - 2011-08-26 18:38:27 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:27 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:27 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Controller Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:27 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:28 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:28 --> Total execution time: 0.5680
DEBUG - 2011-08-26 18:38:40 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:40 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:40 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Controller Class Initialized
ERROR - 2011-08-26 18:38:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 18:38:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 18:38:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:40 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:40 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 18:38:40 --> Helper loaded: url_helper
DEBUG - 2011-08-26 18:38:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 18:38:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 18:38:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 18:38:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 18:38:40 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:40 --> Total execution time: 0.0283
DEBUG - 2011-08-26 18:38:40 --> Config Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Hooks Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Utf8 Class Initialized
DEBUG - 2011-08-26 18:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 18:38:40 --> URI Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Router Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Output Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Input Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 18:38:40 --> Language Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Loader Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Controller Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Model Class Initialized
DEBUG - 2011-08-26 18:38:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 18:38:40 --> Database Driver Class Initialized
DEBUG - 2011-08-26 18:38:41 --> Final output sent to browser
DEBUG - 2011-08-26 18:38:41 --> Total execution time: 0.5525
DEBUG - 2011-08-26 19:29:17 --> Config Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 19:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 19:29:17 --> URI Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Router Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Output Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Input Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 19:29:17 --> Language Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Loader Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Controller Class Initialized
ERROR - 2011-08-26 19:29:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 19:29:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 19:29:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 19:29:17 --> Model Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Model Class Initialized
DEBUG - 2011-08-26 19:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 19:29:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 19:29:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 19:29:17 --> Helper loaded: url_helper
DEBUG - 2011-08-26 19:29:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 19:29:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 19:29:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 19:29:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 19:29:17 --> Final output sent to browser
DEBUG - 2011-08-26 19:29:17 --> Total execution time: 0.0308
DEBUG - 2011-08-26 19:29:18 --> Config Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Hooks Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Utf8 Class Initialized
DEBUG - 2011-08-26 19:29:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 19:29:18 --> URI Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Router Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Output Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Input Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 19:29:18 --> Language Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Loader Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Controller Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Model Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Model Class Initialized
DEBUG - 2011-08-26 19:29:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 19:29:18 --> Database Driver Class Initialized
DEBUG - 2011-08-26 19:29:19 --> Final output sent to browser
DEBUG - 2011-08-26 19:29:19 --> Total execution time: 0.8595
DEBUG - 2011-08-26 19:29:21 --> Config Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Hooks Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Utf8 Class Initialized
DEBUG - 2011-08-26 19:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 19:29:21 --> URI Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Router Class Initialized
ERROR - 2011-08-26 19:29:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 19:29:21 --> Config Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Hooks Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Utf8 Class Initialized
DEBUG - 2011-08-26 19:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 19:29:21 --> URI Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Router Class Initialized
ERROR - 2011-08-26 19:29:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 19:29:21 --> Config Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Hooks Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Utf8 Class Initialized
DEBUG - 2011-08-26 19:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 19:29:21 --> URI Class Initialized
DEBUG - 2011-08-26 19:29:21 --> Router Class Initialized
ERROR - 2011-08-26 19:29:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 19:53:18 --> Config Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Hooks Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Utf8 Class Initialized
DEBUG - 2011-08-26 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 19:53:18 --> URI Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Router Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Output Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Input Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 19:53:18 --> Language Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Loader Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Controller Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Model Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Model Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Model Class Initialized
DEBUG - 2011-08-26 19:53:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 19:53:18 --> Database Driver Class Initialized
DEBUG - 2011-08-26 19:53:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 19:53:18 --> Helper loaded: url_helper
DEBUG - 2011-08-26 19:53:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 19:53:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 19:53:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 19:53:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 19:53:18 --> Final output sent to browser
DEBUG - 2011-08-26 19:53:18 --> Total execution time: 0.2305
DEBUG - 2011-08-26 21:07:06 --> Config Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:07:06 --> URI Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Router Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Output Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Input Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 21:07:06 --> Language Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Loader Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Controller Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Model Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Model Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Model Class Initialized
DEBUG - 2011-08-26 21:07:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 21:07:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 21:07:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 21:07:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 21:07:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 21:07:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 21:07:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 21:07:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 21:07:06 --> Final output sent to browser
DEBUG - 2011-08-26 21:07:06 --> Total execution time: 0.2694
DEBUG - 2011-08-26 21:08:09 --> Config Class Initialized
DEBUG - 2011-08-26 21:08:09 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:08:09 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:08:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:08:09 --> URI Class Initialized
DEBUG - 2011-08-26 21:08:09 --> Router Class Initialized
ERROR - 2011-08-26 21:08:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 21:08:11 --> Config Class Initialized
DEBUG - 2011-08-26 21:08:11 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:08:11 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:08:11 --> URI Class Initialized
DEBUG - 2011-08-26 21:08:11 --> Router Class Initialized
ERROR - 2011-08-26 21:08:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 21:08:20 --> Config Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:08:20 --> URI Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Router Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Output Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Input Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 21:08:20 --> Language Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Loader Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Controller Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 21:08:20 --> Database Driver Class Initialized
DEBUG - 2011-08-26 21:08:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 21:08:20 --> Helper loaded: url_helper
DEBUG - 2011-08-26 21:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 21:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 21:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 21:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 21:08:20 --> Final output sent to browser
DEBUG - 2011-08-26 21:08:20 --> Total execution time: 0.4035
DEBUG - 2011-08-26 21:08:22 --> Config Class Initialized
DEBUG - 2011-08-26 21:08:22 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:08:22 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:08:22 --> URI Class Initialized
DEBUG - 2011-08-26 21:08:22 --> Router Class Initialized
ERROR - 2011-08-26 21:08:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 21:08:40 --> Config Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:08:40 --> URI Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Router Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Output Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Input Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 21:08:40 --> Language Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Loader Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Controller Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 21:08:40 --> Database Driver Class Initialized
DEBUG - 2011-08-26 21:08:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 21:08:40 --> Helper loaded: url_helper
DEBUG - 2011-08-26 21:08:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 21:08:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 21:08:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 21:08:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 21:08:40 --> Final output sent to browser
DEBUG - 2011-08-26 21:08:40 --> Total execution time: 0.2711
DEBUG - 2011-08-26 21:08:42 --> Config Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:08:42 --> URI Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Router Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Output Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Input Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 21:08:42 --> Language Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Loader Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Controller Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Model Class Initialized
DEBUG - 2011-08-26 21:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 21:08:42 --> Database Driver Class Initialized
DEBUG - 2011-08-26 21:08:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 21:08:42 --> Helper loaded: url_helper
DEBUG - 2011-08-26 21:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 21:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 21:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 21:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 21:08:42 --> Final output sent to browser
DEBUG - 2011-08-26 21:08:42 --> Total execution time: 0.0453
DEBUG - 2011-08-26 21:08:51 --> Config Class Initialized
DEBUG - 2011-08-26 21:08:51 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:08:51 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:08:51 --> URI Class Initialized
DEBUG - 2011-08-26 21:08:51 --> Router Class Initialized
DEBUG - 2011-08-26 21:08:51 --> No URI present. Default controller set.
DEBUG - 2011-08-26 21:08:51 --> Output Class Initialized
DEBUG - 2011-08-26 21:08:51 --> Input Class Initialized
DEBUG - 2011-08-26 21:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 21:08:51 --> Language Class Initialized
DEBUG - 2011-08-26 21:08:51 --> Loader Class Initialized
DEBUG - 2011-08-26 21:08:51 --> Controller Class Initialized
DEBUG - 2011-08-26 21:08:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-26 21:08:51 --> Helper loaded: url_helper
DEBUG - 2011-08-26 21:08:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 21:08:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 21:08:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 21:08:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 21:08:51 --> Final output sent to browser
DEBUG - 2011-08-26 21:08:51 --> Total execution time: 0.0952
DEBUG - 2011-08-26 21:08:52 --> Config Class Initialized
DEBUG - 2011-08-26 21:08:52 --> Hooks Class Initialized
DEBUG - 2011-08-26 21:08:52 --> Utf8 Class Initialized
DEBUG - 2011-08-26 21:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 21:08:52 --> URI Class Initialized
DEBUG - 2011-08-26 21:08:52 --> Router Class Initialized
ERROR - 2011-08-26 21:08:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 22:37:04 --> Config Class Initialized
DEBUG - 2011-08-26 22:37:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 22:37:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 22:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 22:37:04 --> URI Class Initialized
DEBUG - 2011-08-26 22:37:04 --> Router Class Initialized
DEBUG - 2011-08-26 22:37:04 --> No URI present. Default controller set.
DEBUG - 2011-08-26 22:37:04 --> Output Class Initialized
DEBUG - 2011-08-26 22:37:04 --> Input Class Initialized
DEBUG - 2011-08-26 22:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 22:37:04 --> Language Class Initialized
DEBUG - 2011-08-26 22:37:04 --> Loader Class Initialized
DEBUG - 2011-08-26 22:37:04 --> Controller Class Initialized
DEBUG - 2011-08-26 22:37:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-26 22:37:04 --> Helper loaded: url_helper
DEBUG - 2011-08-26 22:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 22:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 22:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 22:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 22:37:04 --> Final output sent to browser
DEBUG - 2011-08-26 22:37:04 --> Total execution time: 0.0439
DEBUG - 2011-08-26 23:05:06 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:06 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Router Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Output Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Input Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:05:06 --> Language Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Loader Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Controller Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:05:07 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:05:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:05:07 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:05:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:05:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:05:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:05:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:05:07 --> Final output sent to browser
DEBUG - 2011-08-26 23:05:07 --> Total execution time: 1.2075
DEBUG - 2011-08-26 23:05:10 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:10 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:10 --> Router Class Initialized
ERROR - 2011-08-26 23:05:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:05:14 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:14 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:14 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:14 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:14 --> Router Class Initialized
DEBUG - 2011-08-26 23:05:15 --> Output Class Initialized
DEBUG - 2011-08-26 23:05:15 --> Input Class Initialized
DEBUG - 2011-08-26 23:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:05:15 --> Language Class Initialized
DEBUG - 2011-08-26 23:05:15 --> Loader Class Initialized
DEBUG - 2011-08-26 23:05:15 --> Controller Class Initialized
ERROR - 2011-08-26 23:05:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 23:05:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 23:05:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 23:05:16 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:16 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:05:16 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:05:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 23:05:16 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:05:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:05:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:05:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:05:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:05:16 --> Final output sent to browser
DEBUG - 2011-08-26 23:05:16 --> Total execution time: 2.3889
DEBUG - 2011-08-26 23:05:17 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:17 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Router Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Output Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Input Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:05:17 --> Language Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Loader Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Controller Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:05:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:05:18 --> Final output sent to browser
DEBUG - 2011-08-26 23:05:18 --> Total execution time: 1.1730
DEBUG - 2011-08-26 23:05:19 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:19 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:19 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:19 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:19 --> Router Class Initialized
ERROR - 2011-08-26 23:05:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:05:32 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:32 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Router Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Output Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Input Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:05:32 --> Language Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Loader Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Controller Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:05:32 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:05:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:05:33 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:05:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:05:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:05:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:05:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:05:33 --> Final output sent to browser
DEBUG - 2011-08-26 23:05:33 --> Total execution time: 0.3957
DEBUG - 2011-08-26 23:05:34 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:34 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:34 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:34 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:34 --> Router Class Initialized
ERROR - 2011-08-26 23:05:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:05:43 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:43 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Router Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Output Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Input Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:05:43 --> Language Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Loader Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Controller Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:05:43 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:05:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:05:43 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:05:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:05:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:05:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:05:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:05:43 --> Final output sent to browser
DEBUG - 2011-08-26 23:05:43 --> Total execution time: 0.3066
DEBUG - 2011-08-26 23:05:45 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:45 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Router Class Initialized
ERROR - 2011-08-26 23:05:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:05:45 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:45 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Router Class Initialized
ERROR - 2011-08-26 23:05:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:05:45 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:45 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:45 --> Router Class Initialized
ERROR - 2011-08-26 23:05:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:05:58 --> Config Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:05:58 --> URI Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Router Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Output Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Input Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:05:58 --> Language Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Loader Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Controller Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:05:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:05:58 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:05:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:05:59 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:05:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:05:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:05:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:05:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:05:59 --> Final output sent to browser
DEBUG - 2011-08-26 23:05:59 --> Total execution time: 0.4123
DEBUG - 2011-08-26 23:06:00 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:00 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:00 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:00 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:00 --> Router Class Initialized
ERROR - 2011-08-26 23:06:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:06:08 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:08 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Router Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Output Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Input Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:06:08 --> Language Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Loader Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Controller Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:06:08 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:06:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:06:08 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:06:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:06:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:06:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:06:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:06:08 --> Final output sent to browser
DEBUG - 2011-08-26 23:06:08 --> Total execution time: 0.2479
DEBUG - 2011-08-26 23:06:09 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:09 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:09 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:09 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:09 --> Router Class Initialized
ERROR - 2011-08-26 23:06:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:06:18 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:18 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Router Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Output Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Input Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:06:18 --> Language Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Loader Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Controller Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:06:18 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:06:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:06:18 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:06:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:06:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:06:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:06:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:06:18 --> Final output sent to browser
DEBUG - 2011-08-26 23:06:18 --> Total execution time: 0.2474
DEBUG - 2011-08-26 23:06:19 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:19 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:19 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:19 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:19 --> Router Class Initialized
ERROR - 2011-08-26 23:06:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:06:25 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:25 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Router Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Output Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Input Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:06:25 --> Language Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Loader Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Controller Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:06:25 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:06:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:06:25 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:06:25 --> Final output sent to browser
DEBUG - 2011-08-26 23:06:25 --> Total execution time: 0.2991
DEBUG - 2011-08-26 23:06:27 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:27 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:27 --> Router Class Initialized
ERROR - 2011-08-26 23:06:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:06:35 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:35 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Router Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Output Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Input Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:06:35 --> Language Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Loader Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Controller Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:06:35 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:06:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:06:35 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:06:35 --> Final output sent to browser
DEBUG - 2011-08-26 23:06:35 --> Total execution time: 0.3132
DEBUG - 2011-08-26 23:06:36 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:36 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:36 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:36 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:36 --> Router Class Initialized
ERROR - 2011-08-26 23:06:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:06:44 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:44 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Router Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Output Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Input Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:06:44 --> Language Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Loader Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Controller Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:06:44 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:06:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:06:44 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:06:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:06:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:06:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:06:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:06:44 --> Final output sent to browser
DEBUG - 2011-08-26 23:06:44 --> Total execution time: 0.0415
DEBUG - 2011-08-26 23:06:45 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:45 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:45 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:45 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:45 --> Router Class Initialized
ERROR - 2011-08-26 23:06:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:06:54 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:54 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Router Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Output Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Input Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:06:54 --> Language Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Loader Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Controller Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Model Class Initialized
DEBUG - 2011-08-26 23:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:06:54 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:06:54 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:06:54 --> Final output sent to browser
DEBUG - 2011-08-26 23:06:54 --> Total execution time: 0.2238
DEBUG - 2011-08-26 23:06:59 --> Config Class Initialized
DEBUG - 2011-08-26 23:06:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:06:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:06:59 --> URI Class Initialized
DEBUG - 2011-08-26 23:06:59 --> Router Class Initialized
ERROR - 2011-08-26 23:06:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:07:02 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:02 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Router Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Output Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Input Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:07:02 --> Language Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Loader Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Controller Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:07:02 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:07:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:07:04 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:07:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:07:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:07:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:07:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:07:04 --> Final output sent to browser
DEBUG - 2011-08-26 23:07:04 --> Total execution time: 1.2779
DEBUG - 2011-08-26 23:07:05 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:05 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:05 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:05 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:05 --> Router Class Initialized
ERROR - 2011-08-26 23:07:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:07:20 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:20 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Router Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Output Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Input Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:07:20 --> Language Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Loader Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Controller Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:07:20 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:07:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:07:21 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:07:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:07:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:07:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:07:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:07:21 --> Final output sent to browser
DEBUG - 2011-08-26 23:07:21 --> Total execution time: 0.3300
DEBUG - 2011-08-26 23:07:22 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:22 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Router Class Initialized
ERROR - 2011-08-26 23:07:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:07:22 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:22 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Router Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Output Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Input Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:07:22 --> Language Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Loader Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Controller Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:07:22 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:07:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:07:22 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:07:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:07:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:07:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:07:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:07:22 --> Final output sent to browser
DEBUG - 2011-08-26 23:07:22 --> Total execution time: 0.0455
DEBUG - 2011-08-26 23:07:37 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:37 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Router Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Output Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Input Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:07:37 --> Language Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Loader Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Controller Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:07:37 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:07:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:07:37 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:07:37 --> Final output sent to browser
DEBUG - 2011-08-26 23:07:37 --> Total execution time: 0.0417
DEBUG - 2011-08-26 23:07:38 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:38 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:38 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:38 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:38 --> Router Class Initialized
ERROR - 2011-08-26 23:07:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:07:49 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:49 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Router Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Output Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Input Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:07:49 --> Language Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Loader Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Controller Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:07:49 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:07:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:07:49 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:07:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:07:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:07:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:07:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:07:49 --> Final output sent to browser
DEBUG - 2011-08-26 23:07:49 --> Total execution time: 0.2855
DEBUG - 2011-08-26 23:07:50 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:50 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:50 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:50 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:50 --> Router Class Initialized
ERROR - 2011-08-26 23:07:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:07:58 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:58 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Router Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Output Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Input Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:07:58 --> Language Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Loader Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Controller Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:07:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:07:58 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:07:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:07:58 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:07:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:07:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:07:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:07:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:07:58 --> Final output sent to browser
DEBUG - 2011-08-26 23:07:58 --> Total execution time: 0.2039
DEBUG - 2011-08-26 23:07:59 --> Config Class Initialized
DEBUG - 2011-08-26 23:07:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:07:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:07:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:07:59 --> URI Class Initialized
DEBUG - 2011-08-26 23:07:59 --> Router Class Initialized
ERROR - 2011-08-26 23:07:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:08:19 --> Config Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:08:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:08:19 --> URI Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Router Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Output Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Input Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:08:19 --> Language Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Loader Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Controller Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:08:19 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:08:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:08:19 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:08:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:08:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:08:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:08:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:08:19 --> Final output sent to browser
DEBUG - 2011-08-26 23:08:19 --> Total execution time: 0.0508
DEBUG - 2011-08-26 23:08:20 --> Config Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:08:20 --> URI Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Router Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Output Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Input Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:08:20 --> Language Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Loader Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Controller Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:08:20 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:08:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:08:20 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:08:20 --> Final output sent to browser
DEBUG - 2011-08-26 23:08:20 --> Total execution time: 0.0679
DEBUG - 2011-08-26 23:08:20 --> Config Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:08:20 --> URI Class Initialized
DEBUG - 2011-08-26 23:08:20 --> Router Class Initialized
ERROR - 2011-08-26 23:08:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:08:28 --> Config Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:08:28 --> URI Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Router Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Output Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Input Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:08:28 --> Language Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Loader Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Controller Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:08:28 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:08:29 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:08:29 --> Final output sent to browser
DEBUG - 2011-08-26 23:08:29 --> Total execution time: 0.2521
DEBUG - 2011-08-26 23:08:29 --> Config Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:08:29 --> URI Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Router Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Output Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Input Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:08:29 --> Language Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Loader Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Controller Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Model Class Initialized
DEBUG - 2011-08-26 23:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:08:29 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:08:29 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:08:29 --> Final output sent to browser
DEBUG - 2011-08-26 23:08:29 --> Total execution time: 0.0489
DEBUG - 2011-08-26 23:08:30 --> Config Class Initialized
DEBUG - 2011-08-26 23:08:30 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:08:30 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:08:30 --> URI Class Initialized
DEBUG - 2011-08-26 23:08:30 --> Router Class Initialized
ERROR - 2011-08-26 23:08:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:11:25 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:25 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Router Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Output Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Input Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:11:25 --> Language Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Loader Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Controller Class Initialized
ERROR - 2011-08-26 23:11:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 23:11:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 23:11:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 23:11:25 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:11:25 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:11:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 23:11:25 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:11:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:11:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:11:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:11:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:11:25 --> Final output sent to browser
DEBUG - 2011-08-26 23:11:25 --> Total execution time: 0.0302
DEBUG - 2011-08-26 23:11:26 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:26 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Router Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Output Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Input Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:11:26 --> Language Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Loader Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Controller Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:11:26 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:11:26 --> Final output sent to browser
DEBUG - 2011-08-26 23:11:26 --> Total execution time: 0.5892
DEBUG - 2011-08-26 23:11:27 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:27 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:27 --> Router Class Initialized
ERROR - 2011-08-26 23:11:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:11:28 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:28 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:28 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:28 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:28 --> Router Class Initialized
ERROR - 2011-08-26 23:11:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:11:50 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:50 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Router Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Output Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Input Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:11:50 --> Language Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Loader Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Controller Class Initialized
ERROR - 2011-08-26 23:11:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 23:11:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 23:11:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 23:11:50 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:11:50 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:11:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 23:11:50 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:11:50 --> Final output sent to browser
DEBUG - 2011-08-26 23:11:50 --> Total execution time: 0.0394
DEBUG - 2011-08-26 23:11:51 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:51 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Router Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Output Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Input Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:11:51 --> Language Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Loader Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Controller Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:11:51 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:11:51 --> Final output sent to browser
DEBUG - 2011-08-26 23:11:51 --> Total execution time: 0.5797
DEBUG - 2011-08-26 23:11:52 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:52 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:52 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:52 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:52 --> Router Class Initialized
ERROR - 2011-08-26 23:11:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:11:54 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:54 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Router Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Output Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Input Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:11:54 --> Language Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Loader Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Controller Class Initialized
ERROR - 2011-08-26 23:11:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-26 23:11:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-26 23:11:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 23:11:54 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:11:54 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:11:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-26 23:11:54 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:11:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:11:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:11:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:11:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:11:54 --> Final output sent to browser
DEBUG - 2011-08-26 23:11:54 --> Total execution time: 0.0277
DEBUG - 2011-08-26 23:11:55 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:55 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Router Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Output Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Input Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:11:55 --> Language Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Loader Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Controller Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Model Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:11:55 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:11:55 --> Final output sent to browser
DEBUG - 2011-08-26 23:11:55 --> Total execution time: 0.5439
DEBUG - 2011-08-26 23:11:56 --> Config Class Initialized
DEBUG - 2011-08-26 23:11:56 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:11:56 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:11:56 --> URI Class Initialized
DEBUG - 2011-08-26 23:11:56 --> Router Class Initialized
ERROR - 2011-08-26 23:11:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:19:31 --> Config Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:19:31 --> URI Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Router Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Output Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Input Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:19:31 --> Language Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Loader Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Controller Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Model Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Model Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Model Class Initialized
DEBUG - 2011-08-26 23:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:19:31 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:19:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:19:31 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:19:31 --> Final output sent to browser
DEBUG - 2011-08-26 23:19:31 --> Total execution time: 0.0799
DEBUG - 2011-08-26 23:19:35 --> Config Class Initialized
DEBUG - 2011-08-26 23:19:35 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:19:35 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:19:35 --> URI Class Initialized
DEBUG - 2011-08-26 23:19:35 --> Router Class Initialized
ERROR - 2011-08-26 23:19:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:19:36 --> Config Class Initialized
DEBUG - 2011-08-26 23:19:36 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:19:36 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:19:36 --> URI Class Initialized
DEBUG - 2011-08-26 23:19:36 --> Router Class Initialized
ERROR - 2011-08-26 23:19:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-26 23:19:47 --> Config Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:19:47 --> URI Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Router Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Output Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Input Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:19:47 --> Language Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Loader Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Controller Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Model Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Model Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Model Class Initialized
DEBUG - 2011-08-26 23:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:19:47 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:19:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:19:47 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:19:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:19:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:19:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:19:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:19:47 --> Final output sent to browser
DEBUG - 2011-08-26 23:19:47 --> Total execution time: 0.0448
DEBUG - 2011-08-26 23:20:01 --> Config Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:20:01 --> URI Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Router Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Output Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Input Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:20:01 --> Language Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Loader Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Controller Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:20:01 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:20:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:20:01 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:20:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:20:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:20:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:20:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:20:01 --> Final output sent to browser
DEBUG - 2011-08-26 23:20:01 --> Total execution time: 0.0442
DEBUG - 2011-08-26 23:20:18 --> Config Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:20:18 --> URI Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Router Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Output Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Input Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:20:18 --> Language Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Loader Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Controller Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:20:18 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:20:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:20:18 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:20:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:20:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:20:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:20:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:20:18 --> Final output sent to browser
DEBUG - 2011-08-26 23:20:18 --> Total execution time: 0.3141
DEBUG - 2011-08-26 23:20:20 --> Config Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:20:20 --> URI Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Router Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Output Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Input Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:20:20 --> Language Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Loader Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Controller Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Model Class Initialized
DEBUG - 2011-08-26 23:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:20:20 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:20:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:20:20 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:20:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:20:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:20:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:20:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:20:20 --> Final output sent to browser
DEBUG - 2011-08-26 23:20:20 --> Total execution time: 0.0950
DEBUG - 2011-08-26 23:21:23 --> Config Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:21:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:21:23 --> URI Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Router Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Output Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Input Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:21:23 --> Language Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Loader Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Controller Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:21:23 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:21:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:21:23 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:21:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:21:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:21:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:21:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:21:23 --> Final output sent to browser
DEBUG - 2011-08-26 23:21:23 --> Total execution time: 0.2435
DEBUG - 2011-08-26 23:21:24 --> Config Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:21:24 --> URI Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Router Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Output Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Input Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:21:24 --> Language Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Loader Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Controller Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:21:24 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:21:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:21:24 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:21:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:21:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:21:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:21:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:21:24 --> Final output sent to browser
DEBUG - 2011-08-26 23:21:24 --> Total execution time: 0.1280
DEBUG - 2011-08-26 23:21:59 --> Config Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:21:59 --> URI Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Router Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Output Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Input Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:21:59 --> Language Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Loader Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Controller Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:21:59 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:21:59 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:21:59 --> Final output sent to browser
DEBUG - 2011-08-26 23:21:59 --> Total execution time: 0.1897
DEBUG - 2011-08-26 23:22:01 --> Config Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:22:01 --> URI Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Router Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Output Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Input Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:22:01 --> Language Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Loader Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Controller Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:22:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:22:01 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:22:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:22:01 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:22:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:22:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:22:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:22:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:22:01 --> Final output sent to browser
DEBUG - 2011-08-26 23:22:01 --> Total execution time: 0.0506
DEBUG - 2011-08-26 23:22:58 --> Config Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:22:58 --> URI Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Router Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Output Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Input Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:22:58 --> Language Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Loader Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Controller Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:22:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:22:58 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:22:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:22:58 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:22:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:22:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:22:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:22:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:22:58 --> Final output sent to browser
DEBUG - 2011-08-26 23:22:58 --> Total execution time: 0.2607
DEBUG - 2011-08-26 23:23:00 --> Config Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:23:00 --> URI Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Router Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Output Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Input Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:23:00 --> Language Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Loader Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Controller Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:23:00 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:23:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:23:00 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:23:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:23:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:23:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:23:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:23:00 --> Final output sent to browser
DEBUG - 2011-08-26 23:23:00 --> Total execution time: 0.0484
DEBUG - 2011-08-26 23:23:57 --> Config Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:23:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:23:57 --> URI Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Router Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Output Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Input Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:23:57 --> Language Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Loader Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Controller Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:23:57 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:23:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:23:57 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:23:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:23:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:23:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:23:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:23:57 --> Final output sent to browser
DEBUG - 2011-08-26 23:23:57 --> Total execution time: 0.2044
DEBUG - 2011-08-26 23:23:58 --> Config Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:23:58 --> URI Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Router Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Output Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Input Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:23:58 --> Language Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Loader Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Controller Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Model Class Initialized
DEBUG - 2011-08-26 23:23:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:23:58 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:23:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:23:58 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:23:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:23:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:23:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:23:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:23:58 --> Final output sent to browser
DEBUG - 2011-08-26 23:23:58 --> Total execution time: 0.0487
DEBUG - 2011-08-26 23:24:25 --> Config Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:24:25 --> URI Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Router Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Output Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Input Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:24:25 --> Language Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Loader Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Controller Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Model Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Model Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Model Class Initialized
DEBUG - 2011-08-26 23:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:24:25 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:24:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:24:25 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:24:25 --> Final output sent to browser
DEBUG - 2011-08-26 23:24:25 --> Total execution time: 0.2543
DEBUG - 2011-08-26 23:24:27 --> Config Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:24:27 --> URI Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Router Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Output Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Input Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:24:27 --> Language Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Loader Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Controller Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Model Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Model Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Model Class Initialized
DEBUG - 2011-08-26 23:24:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:24:27 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:24:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:24:27 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:24:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:24:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:24:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:24:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:24:27 --> Final output sent to browser
DEBUG - 2011-08-26 23:24:27 --> Total execution time: 0.0420
DEBUG - 2011-08-26 23:25:54 --> Config Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:25:54 --> URI Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Router Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Output Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Input Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:25:54 --> Language Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Loader Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Controller Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Model Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Model Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Model Class Initialized
DEBUG - 2011-08-26 23:25:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:25:54 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:25:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:25:55 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:25:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:25:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:25:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:25:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:25:55 --> Final output sent to browser
DEBUG - 2011-08-26 23:25:55 --> Total execution time: 0.6201
DEBUG - 2011-08-26 23:25:57 --> Config Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:25:57 --> URI Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Router Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Output Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Input Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:25:57 --> Language Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Loader Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Controller Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:25:57 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:25:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:25:57 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:25:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:25:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:25:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:25:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:25:57 --> Final output sent to browser
DEBUG - 2011-08-26 23:25:57 --> Total execution time: 0.0745
DEBUG - 2011-08-26 23:26:44 --> Config Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:26:44 --> URI Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Router Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Output Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Input Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:26:44 --> Language Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Loader Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Controller Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:26:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:26:44 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:26:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:26:44 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:26:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:26:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:26:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:26:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:26:44 --> Final output sent to browser
DEBUG - 2011-08-26 23:26:44 --> Total execution time: 0.3373
DEBUG - 2011-08-26 23:26:46 --> Config Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:26:46 --> URI Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Router Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Output Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Input Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:26:46 --> Language Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Loader Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Controller Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Model Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Model Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Model Class Initialized
DEBUG - 2011-08-26 23:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:26:46 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:26:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:26:46 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:26:46 --> Final output sent to browser
DEBUG - 2011-08-26 23:26:46 --> Total execution time: 0.0451
DEBUG - 2011-08-26 23:27:06 --> Config Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:27:06 --> URI Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Router Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Output Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Input Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:27:06 --> Language Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Loader Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Controller Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:27:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:27:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:27:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:27:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:27:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:27:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:27:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:27:06 --> Final output sent to browser
DEBUG - 2011-08-26 23:27:06 --> Total execution time: 0.2508
DEBUG - 2011-08-26 23:27:08 --> Config Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:27:08 --> URI Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Router Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Output Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Input Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:27:08 --> Language Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Loader Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Controller Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:27:08 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:27:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:27:08 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:27:08 --> Final output sent to browser
DEBUG - 2011-08-26 23:27:08 --> Total execution time: 0.0436
DEBUG - 2011-08-26 23:27:28 --> Config Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:27:28 --> URI Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Router Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Output Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Input Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:27:28 --> Language Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Loader Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Controller Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:27:28 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:27:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:27:28 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:27:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:27:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:27:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:27:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:27:28 --> Final output sent to browser
DEBUG - 2011-08-26 23:27:28 --> Total execution time: 0.3765
DEBUG - 2011-08-26 23:27:30 --> Config Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:27:30 --> URI Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Router Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Output Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Input Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:27:30 --> Language Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Loader Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Controller Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Model Class Initialized
DEBUG - 2011-08-26 23:27:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:27:30 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:27:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:27:30 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:27:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:27:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:27:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:27:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:27:30 --> Final output sent to browser
DEBUG - 2011-08-26 23:27:30 --> Total execution time: 0.0825
DEBUG - 2011-08-26 23:28:08 --> Config Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:28:08 --> URI Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Router Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Output Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Input Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:28:08 --> Language Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Loader Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Controller Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:28:08 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:28:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:28:08 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:28:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:28:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:28:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:28:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:28:08 --> Final output sent to browser
DEBUG - 2011-08-26 23:28:08 --> Total execution time: 0.2125
DEBUG - 2011-08-26 23:28:10 --> Config Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:28:10 --> URI Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Router Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Output Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Input Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:28:10 --> Language Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Loader Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Controller Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:28:10 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:28:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:28:10 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:28:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:28:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:28:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:28:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:28:10 --> Final output sent to browser
DEBUG - 2011-08-26 23:28:10 --> Total execution time: 0.0637
DEBUG - 2011-08-26 23:28:33 --> Config Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:28:33 --> URI Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Router Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Output Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Input Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:28:33 --> Language Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Loader Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Controller Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:28:33 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:28:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:28:33 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:28:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:28:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:28:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:28:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:28:33 --> Final output sent to browser
DEBUG - 2011-08-26 23:28:33 --> Total execution time: 0.1917
DEBUG - 2011-08-26 23:28:35 --> Config Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:28:35 --> URI Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Router Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Output Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Input Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:28:35 --> Language Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Loader Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Controller Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:28:35 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:28:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:28:35 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:28:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:28:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:28:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:28:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:28:35 --> Final output sent to browser
DEBUG - 2011-08-26 23:28:35 --> Total execution time: 0.0762
DEBUG - 2011-08-26 23:28:59 --> Config Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:28:59 --> URI Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Router Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Output Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Input Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:28:59 --> Language Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Loader Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Controller Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:28:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:28:59 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:28:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:28:59 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:28:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:28:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:28:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:28:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:28:59 --> Final output sent to browser
DEBUG - 2011-08-26 23:28:59 --> Total execution time: 0.2732
DEBUG - 2011-08-26 23:29:01 --> Config Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:29:01 --> URI Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Router Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Output Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Input Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:29:01 --> Language Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Loader Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Controller Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:29:01 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:29:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:29:01 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:29:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:29:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:29:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:29:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:29:01 --> Final output sent to browser
DEBUG - 2011-08-26 23:29:01 --> Total execution time: 0.0465
DEBUG - 2011-08-26 23:29:14 --> Config Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:29:14 --> URI Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Router Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Output Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Input Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:29:14 --> Language Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Loader Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Controller Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:29:14 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:29:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:29:14 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:29:14 --> Final output sent to browser
DEBUG - 2011-08-26 23:29:14 --> Total execution time: 0.1968
DEBUG - 2011-08-26 23:29:15 --> Config Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:29:15 --> URI Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Router Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Output Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Input Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:29:15 --> Language Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Loader Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Controller Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:29:15 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:29:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:29:15 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:29:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:29:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:29:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:29:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:29:15 --> Final output sent to browser
DEBUG - 2011-08-26 23:29:15 --> Total execution time: 0.0613
DEBUG - 2011-08-26 23:29:37 --> Config Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:29:37 --> URI Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Router Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Output Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Input Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:29:37 --> Language Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Loader Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Controller Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:29:37 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:29:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:29:37 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:29:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:29:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:29:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:29:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:29:37 --> Final output sent to browser
DEBUG - 2011-08-26 23:29:37 --> Total execution time: 0.0928
DEBUG - 2011-08-26 23:29:38 --> Config Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:29:38 --> URI Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Router Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Output Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Input Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:29:38 --> Language Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Loader Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Controller Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:29:38 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:29:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:29:38 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:29:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:29:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:29:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:29:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:29:38 --> Final output sent to browser
DEBUG - 2011-08-26 23:29:38 --> Total execution time: 0.0416
DEBUG - 2011-08-26 23:29:57 --> Config Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:29:57 --> URI Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Router Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Output Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Input Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:29:57 --> Language Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Loader Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Controller Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:29:57 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:29:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:29:57 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:29:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:29:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:29:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:29:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:29:57 --> Final output sent to browser
DEBUG - 2011-08-26 23:29:57 --> Total execution time: 0.1612
DEBUG - 2011-08-26 23:29:59 --> Config Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:29:59 --> URI Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Router Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Output Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Input Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:29:59 --> Language Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Loader Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Controller Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Model Class Initialized
DEBUG - 2011-08-26 23:29:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:29:59 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:29:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:29:59 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:29:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:29:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:29:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:29:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:29:59 --> Final output sent to browser
DEBUG - 2011-08-26 23:29:59 --> Total execution time: 0.0426
DEBUG - 2011-08-26 23:30:04 --> Config Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:30:04 --> URI Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Router Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Output Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Input Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:30:04 --> Language Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Loader Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Controller Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Model Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Model Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Model Class Initialized
DEBUG - 2011-08-26 23:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:30:04 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:30:05 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:30:05 --> Final output sent to browser
DEBUG - 2011-08-26 23:30:05 --> Total execution time: 1.1593
DEBUG - 2011-08-26 23:30:06 --> Config Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:30:06 --> URI Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Router Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Output Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Input Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:30:06 --> Language Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Loader Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Controller Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:30:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:30:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:30:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:30:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:30:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:30:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:30:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:30:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:30:06 --> Final output sent to browser
DEBUG - 2011-08-26 23:30:06 --> Total execution time: 0.0734
DEBUG - 2011-08-26 23:31:07 --> Config Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:31:07 --> URI Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Router Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Output Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Input Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:31:07 --> Language Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Loader Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Controller Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:31:07 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:31:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:31:07 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:31:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:31:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:31:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:31:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:31:07 --> Final output sent to browser
DEBUG - 2011-08-26 23:31:07 --> Total execution time: 0.2203
DEBUG - 2011-08-26 23:31:10 --> Config Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:31:10 --> URI Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Router Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Output Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Input Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:31:10 --> Language Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Loader Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Controller Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:31:10 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:31:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:31:10 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:31:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:31:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:31:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:31:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:31:10 --> Final output sent to browser
DEBUG - 2011-08-26 23:31:10 --> Total execution time: 0.0427
DEBUG - 2011-08-26 23:31:42 --> Config Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:31:42 --> URI Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Router Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Output Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Input Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:31:42 --> Language Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Loader Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Controller Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:31:42 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:31:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:31:42 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:31:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:31:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:31:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:31:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:31:42 --> Final output sent to browser
DEBUG - 2011-08-26 23:31:42 --> Total execution time: 0.2231
DEBUG - 2011-08-26 23:31:44 --> Config Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:31:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:31:44 --> URI Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Router Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Output Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Input Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:31:44 --> Language Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Loader Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Controller Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Model Class Initialized
DEBUG - 2011-08-26 23:31:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:31:44 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:31:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:31:44 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:31:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:31:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:31:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:31:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:31:44 --> Final output sent to browser
DEBUG - 2011-08-26 23:31:44 --> Total execution time: 0.0654
DEBUG - 2011-08-26 23:32:15 --> Config Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:32:15 --> URI Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Router Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Output Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Input Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:32:15 --> Language Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Loader Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Controller Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:32:15 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:32:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:32:16 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:32:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:32:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:32:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:32:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:32:16 --> Final output sent to browser
DEBUG - 2011-08-26 23:32:16 --> Total execution time: 0.2375
DEBUG - 2011-08-26 23:32:17 --> Config Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:32:17 --> URI Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Router Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Output Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Input Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:32:17 --> Language Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Loader Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Controller Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Model Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Model Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Model Class Initialized
DEBUG - 2011-08-26 23:32:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:32:17 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:32:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:32:17 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:32:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:32:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:32:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:32:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:32:17 --> Final output sent to browser
DEBUG - 2011-08-26 23:32:17 --> Total execution time: 0.0462
DEBUG - 2011-08-26 23:37:51 --> Config Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:37:51 --> URI Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Router Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Output Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Input Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:37:51 --> Language Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Loader Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Controller Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Model Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Model Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Model Class Initialized
DEBUG - 2011-08-26 23:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:37:51 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:37:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:37:51 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:37:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:37:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:37:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:37:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:37:51 --> Final output sent to browser
DEBUG - 2011-08-26 23:37:51 --> Total execution time: 0.2651
DEBUG - 2011-08-26 23:37:53 --> Config Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:37:53 --> URI Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Router Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Output Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Input Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:37:53 --> Language Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Loader Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Controller Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Model Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Model Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Model Class Initialized
DEBUG - 2011-08-26 23:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:37:53 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:37:53 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:37:53 --> Final output sent to browser
DEBUG - 2011-08-26 23:37:53 --> Total execution time: 0.0481
DEBUG - 2011-08-26 23:38:06 --> Config Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:38:06 --> URI Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Router Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Output Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Input Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:38:06 --> Language Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Loader Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Controller Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Model Class Initialized
DEBUG - 2011-08-26 23:38:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:38:06 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:38:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:38:06 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:38:06 --> Final output sent to browser
DEBUG - 2011-08-26 23:38:06 --> Total execution time: 0.2282
DEBUG - 2011-08-26 23:38:07 --> Config Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:38:07 --> URI Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Router Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Output Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Input Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:38:07 --> Language Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Loader Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Controller Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Model Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Model Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Model Class Initialized
DEBUG - 2011-08-26 23:38:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:38:07 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:38:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:38:07 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:38:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:38:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:38:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:38:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:38:07 --> Final output sent to browser
DEBUG - 2011-08-26 23:38:07 --> Total execution time: 0.0433
DEBUG - 2011-08-26 23:40:12 --> Config Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:40:12 --> URI Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Router Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Output Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Input Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:40:12 --> Language Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Loader Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Controller Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:40:12 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:40:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:40:12 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:40:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:40:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:40:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:40:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:40:12 --> Final output sent to browser
DEBUG - 2011-08-26 23:40:12 --> Total execution time: 0.2099
DEBUG - 2011-08-26 23:40:15 --> Config Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:40:15 --> URI Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Router Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Output Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Input Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:40:15 --> Language Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Loader Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Controller Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:40:15 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:40:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:40:15 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:40:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:40:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:40:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:40:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:40:15 --> Final output sent to browser
DEBUG - 2011-08-26 23:40:15 --> Total execution time: 0.0758
DEBUG - 2011-08-26 23:40:28 --> Config Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:40:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:40:28 --> URI Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Router Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Output Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Input Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:40:28 --> Language Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Loader Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Controller Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:40:28 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:40:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:40:28 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:40:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:40:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:40:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:40:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:40:28 --> Final output sent to browser
DEBUG - 2011-08-26 23:40:28 --> Total execution time: 0.1888
DEBUG - 2011-08-26 23:40:31 --> Config Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Hooks Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Utf8 Class Initialized
DEBUG - 2011-08-26 23:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-26 23:40:31 --> URI Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Router Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Output Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Input Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-26 23:40:31 --> Language Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Loader Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Controller Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Model Class Initialized
DEBUG - 2011-08-26 23:40:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-26 23:40:31 --> Database Driver Class Initialized
DEBUG - 2011-08-26 23:40:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-26 23:40:31 --> Helper loaded: url_helper
DEBUG - 2011-08-26 23:40:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-26 23:40:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-26 23:40:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-26 23:40:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-26 23:40:31 --> Final output sent to browser
DEBUG - 2011-08-26 23:40:31 --> Total execution time: 0.0493

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-27 00:26:08 --> Config Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Hooks Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Utf8 Class Initialized
DEBUG - 2011-05-27 00:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 00:26:08 --> URI Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Router Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Output Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Input Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 00:26:08 --> Language Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Loader Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Controller Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Model Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Model Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Model Class Initialized
DEBUG - 2011-05-27 00:26:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 00:26:08 --> Database Driver Class Initialized
DEBUG - 2011-05-27 00:26:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-27 00:26:09 --> Helper loaded: url_helper
DEBUG - 2011-05-27 00:26:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 00:26:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 00:26:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 00:26:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 00:26:09 --> Final output sent to browser
DEBUG - 2011-05-27 00:26:09 --> Total execution time: 0.7276
DEBUG - 2011-05-27 00:26:11 --> Config Class Initialized
DEBUG - 2011-05-27 00:26:11 --> Hooks Class Initialized
DEBUG - 2011-05-27 00:26:11 --> Utf8 Class Initialized
DEBUG - 2011-05-27 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 00:26:11 --> URI Class Initialized
DEBUG - 2011-05-27 00:26:11 --> Router Class Initialized
ERROR - 2011-05-27 00:26:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 00:26:12 --> Config Class Initialized
DEBUG - 2011-05-27 00:26:12 --> Hooks Class Initialized
DEBUG - 2011-05-27 00:26:12 --> Utf8 Class Initialized
DEBUG - 2011-05-27 00:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 00:26:12 --> URI Class Initialized
DEBUG - 2011-05-27 00:26:12 --> Router Class Initialized
ERROR - 2011-05-27 00:26:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 00:28:43 --> Config Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Hooks Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Utf8 Class Initialized
DEBUG - 2011-05-27 00:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 00:28:43 --> URI Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Router Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Output Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Input Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 00:28:43 --> Language Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Loader Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Controller Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Model Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Model Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Model Class Initialized
DEBUG - 2011-05-27 00:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 00:28:43 --> Database Driver Class Initialized
DEBUG - 2011-05-27 00:28:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-27 00:28:44 --> Helper loaded: url_helper
DEBUG - 2011-05-27 00:28:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 00:28:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 00:28:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 00:28:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 00:28:44 --> Final output sent to browser
DEBUG - 2011-05-27 00:28:44 --> Total execution time: 0.2345
DEBUG - 2011-05-27 00:28:48 --> Config Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Hooks Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Utf8 Class Initialized
DEBUG - 2011-05-27 00:28:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 00:28:48 --> URI Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Router Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Output Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Input Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 00:28:48 --> Language Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Loader Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Controller Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Model Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Model Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Model Class Initialized
DEBUG - 2011-05-27 00:28:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 00:28:48 --> Database Driver Class Initialized
DEBUG - 2011-05-27 00:28:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-27 00:28:48 --> Helper loaded: url_helper
DEBUG - 2011-05-27 00:28:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 00:28:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 00:28:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 00:28:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 00:28:48 --> Final output sent to browser
DEBUG - 2011-05-27 00:28:48 --> Total execution time: 0.0627
DEBUG - 2011-05-27 05:25:46 --> Config Class Initialized
DEBUG - 2011-05-27 05:25:46 --> Hooks Class Initialized
DEBUG - 2011-05-27 05:25:46 --> Utf8 Class Initialized
DEBUG - 2011-05-27 05:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 05:25:46 --> URI Class Initialized
DEBUG - 2011-05-27 05:25:46 --> Router Class Initialized
DEBUG - 2011-05-27 05:25:46 --> Output Class Initialized
DEBUG - 2011-05-27 05:25:46 --> Input Class Initialized
DEBUG - 2011-05-27 05:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 05:25:46 --> Language Class Initialized
DEBUG - 2011-05-27 05:25:46 --> Loader Class Initialized
DEBUG - 2011-05-27 05:25:46 --> Controller Class Initialized
ERROR - 2011-05-27 05:25:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 05:25:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 05:25:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 05:25:47 --> Model Class Initialized
DEBUG - 2011-05-27 05:25:47 --> Model Class Initialized
DEBUG - 2011-05-27 05:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 05:25:47 --> Database Driver Class Initialized
DEBUG - 2011-05-27 05:25:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 05:25:47 --> Helper loaded: url_helper
DEBUG - 2011-05-27 05:25:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 05:25:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 05:25:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 05:25:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 05:25:47 --> Final output sent to browser
DEBUG - 2011-05-27 05:25:47 --> Total execution time: 0.8762
DEBUG - 2011-05-27 05:25:50 --> Config Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Hooks Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Utf8 Class Initialized
DEBUG - 2011-05-27 05:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 05:25:50 --> URI Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Router Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Output Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Input Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 05:25:50 --> Language Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Loader Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Controller Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Model Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Model Class Initialized
DEBUG - 2011-05-27 05:25:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 05:25:50 --> Database Driver Class Initialized
DEBUG - 2011-05-27 05:25:51 --> Final output sent to browser
DEBUG - 2011-05-27 05:25:51 --> Total execution time: 1.2289
DEBUG - 2011-05-27 05:25:53 --> Config Class Initialized
DEBUG - 2011-05-27 05:25:53 --> Hooks Class Initialized
DEBUG - 2011-05-27 05:25:53 --> Utf8 Class Initialized
DEBUG - 2011-05-27 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 05:25:53 --> URI Class Initialized
DEBUG - 2011-05-27 05:25:53 --> Router Class Initialized
ERROR - 2011-05-27 05:25:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 05:26:38 --> Config Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Hooks Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Utf8 Class Initialized
DEBUG - 2011-05-27 05:26:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 05:26:38 --> URI Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Router Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Output Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Input Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 05:26:38 --> Language Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Loader Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Controller Class Initialized
ERROR - 2011-05-27 05:26:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 05:26:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 05:26:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 05:26:38 --> Model Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Model Class Initialized
DEBUG - 2011-05-27 05:26:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 05:26:38 --> Database Driver Class Initialized
DEBUG - 2011-05-27 05:26:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 05:26:38 --> Helper loaded: url_helper
DEBUG - 2011-05-27 05:26:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 05:26:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 05:26:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 05:26:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 05:26:38 --> Final output sent to browser
DEBUG - 2011-05-27 05:26:38 --> Total execution time: 0.0303
DEBUG - 2011-05-27 05:26:40 --> Config Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Hooks Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Utf8 Class Initialized
DEBUG - 2011-05-27 05:26:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 05:26:40 --> URI Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Router Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Output Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Input Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 05:26:40 --> Language Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Loader Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Controller Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Model Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Model Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 05:26:40 --> Database Driver Class Initialized
DEBUG - 2011-05-27 05:26:40 --> Final output sent to browser
DEBUG - 2011-05-27 05:26:40 --> Total execution time: 0.5902
DEBUG - 2011-05-27 05:26:43 --> Config Class Initialized
DEBUG - 2011-05-27 05:26:43 --> Hooks Class Initialized
DEBUG - 2011-05-27 05:26:43 --> Utf8 Class Initialized
DEBUG - 2011-05-27 05:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 05:26:43 --> URI Class Initialized
DEBUG - 2011-05-27 05:26:43 --> Router Class Initialized
ERROR - 2011-05-27 05:26:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 08:41:58 --> Config Class Initialized
DEBUG - 2011-05-27 08:41:58 --> Hooks Class Initialized
DEBUG - 2011-05-27 08:41:58 --> Utf8 Class Initialized
DEBUG - 2011-05-27 08:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 08:41:58 --> URI Class Initialized
DEBUG - 2011-05-27 08:41:58 --> Router Class Initialized
ERROR - 2011-05-27 08:41:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-27 08:41:59 --> Config Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Hooks Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Utf8 Class Initialized
DEBUG - 2011-05-27 08:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 08:41:59 --> URI Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Router Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Output Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Input Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 08:41:59 --> Language Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Loader Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Controller Class Initialized
ERROR - 2011-05-27 08:41:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 08:41:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 08:41:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 08:41:59 --> Model Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Model Class Initialized
DEBUG - 2011-05-27 08:41:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 08:41:59 --> Database Driver Class Initialized
DEBUG - 2011-05-27 08:41:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 08:41:59 --> Helper loaded: url_helper
DEBUG - 2011-05-27 08:41:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 08:41:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 08:41:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 08:41:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 08:41:59 --> Final output sent to browser
DEBUG - 2011-05-27 08:41:59 --> Total execution time: 0.2835
DEBUG - 2011-05-27 10:18:47 --> Config Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Hooks Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Utf8 Class Initialized
DEBUG - 2011-05-27 10:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 10:18:47 --> URI Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Router Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Output Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Input Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 10:18:47 --> Language Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Loader Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Controller Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Model Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Model Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Model Class Initialized
DEBUG - 2011-05-27 10:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 10:18:47 --> Database Driver Class Initialized
DEBUG - 2011-05-27 10:18:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-27 10:18:48 --> Helper loaded: url_helper
DEBUG - 2011-05-27 10:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 10:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 10:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 10:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 10:18:48 --> Final output sent to browser
DEBUG - 2011-05-27 10:18:48 --> Total execution time: 0.7489
DEBUG - 2011-05-27 10:18:57 --> Config Class Initialized
DEBUG - 2011-05-27 10:18:57 --> Hooks Class Initialized
DEBUG - 2011-05-27 10:18:57 --> Utf8 Class Initialized
DEBUG - 2011-05-27 10:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 10:18:57 --> URI Class Initialized
DEBUG - 2011-05-27 10:18:57 --> Router Class Initialized
ERROR - 2011-05-27 10:18:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-27 11:18:41 --> Config Class Initialized
DEBUG - 2011-05-27 11:18:41 --> Hooks Class Initialized
DEBUG - 2011-05-27 11:18:41 --> Utf8 Class Initialized
DEBUG - 2011-05-27 11:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 11:18:41 --> URI Class Initialized
DEBUG - 2011-05-27 11:18:41 --> Router Class Initialized
DEBUG - 2011-05-27 11:18:41 --> No URI present. Default controller set.
DEBUG - 2011-05-27 11:18:41 --> Output Class Initialized
DEBUG - 2011-05-27 11:18:41 --> Input Class Initialized
DEBUG - 2011-05-27 11:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 11:18:41 --> Language Class Initialized
DEBUG - 2011-05-27 11:18:41 --> Loader Class Initialized
DEBUG - 2011-05-27 11:18:41 --> Controller Class Initialized
DEBUG - 2011-05-27 11:18:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-27 11:18:41 --> Helper loaded: url_helper
DEBUG - 2011-05-27 11:18:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 11:18:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 11:18:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 11:18:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 11:18:41 --> Final output sent to browser
DEBUG - 2011-05-27 11:18:41 --> Total execution time: 0.2790
DEBUG - 2011-05-27 11:18:45 --> Config Class Initialized
DEBUG - 2011-05-27 11:18:45 --> Hooks Class Initialized
DEBUG - 2011-05-27 11:18:45 --> Utf8 Class Initialized
DEBUG - 2011-05-27 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 11:18:45 --> URI Class Initialized
DEBUG - 2011-05-27 11:18:45 --> Router Class Initialized
DEBUG - 2011-05-27 11:18:45 --> No URI present. Default controller set.
DEBUG - 2011-05-27 11:18:45 --> Output Class Initialized
DEBUG - 2011-05-27 11:18:45 --> Input Class Initialized
DEBUG - 2011-05-27 11:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 11:18:45 --> Language Class Initialized
DEBUG - 2011-05-27 11:18:45 --> Loader Class Initialized
DEBUG - 2011-05-27 11:18:45 --> Controller Class Initialized
DEBUG - 2011-05-27 11:18:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-27 11:18:45 --> Helper loaded: url_helper
DEBUG - 2011-05-27 11:18:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 11:18:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 11:18:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 11:18:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 11:18:45 --> Final output sent to browser
DEBUG - 2011-05-27 11:18:45 --> Total execution time: 0.0147
DEBUG - 2011-05-27 11:19:08 --> Config Class Initialized
DEBUG - 2011-05-27 11:19:08 --> Hooks Class Initialized
DEBUG - 2011-05-27 11:19:08 --> Utf8 Class Initialized
DEBUG - 2011-05-27 11:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 11:19:08 --> URI Class Initialized
DEBUG - 2011-05-27 11:19:08 --> Router Class Initialized
DEBUG - 2011-05-27 11:19:08 --> Output Class Initialized
DEBUG - 2011-05-27 11:19:08 --> Input Class Initialized
DEBUG - 2011-05-27 11:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 11:19:08 --> Language Class Initialized
DEBUG - 2011-05-27 11:19:09 --> Loader Class Initialized
DEBUG - 2011-05-27 11:19:09 --> Controller Class Initialized
DEBUG - 2011-05-27 11:19:09 --> Model Class Initialized
DEBUG - 2011-05-27 11:19:09 --> Model Class Initialized
DEBUG - 2011-05-27 11:19:09 --> Model Class Initialized
DEBUG - 2011-05-27 11:19:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 11:19:09 --> Database Driver Class Initialized
DEBUG - 2011-05-27 11:19:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-27 11:19:09 --> Helper loaded: url_helper
DEBUG - 2011-05-27 11:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 11:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 11:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 11:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 11:19:09 --> Final output sent to browser
DEBUG - 2011-05-27 11:19:09 --> Total execution time: 0.8180
DEBUG - 2011-05-27 11:29:47 --> Config Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Hooks Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Utf8 Class Initialized
DEBUG - 2011-05-27 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 11:29:47 --> URI Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Router Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Output Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Input Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 11:29:47 --> Language Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Loader Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Controller Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Model Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Model Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Model Class Initialized
DEBUG - 2011-05-27 11:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 11:29:47 --> Database Driver Class Initialized
DEBUG - 2011-05-27 11:29:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-27 11:29:48 --> Helper loaded: url_helper
DEBUG - 2011-05-27 11:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 11:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 11:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 11:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 11:29:48 --> Final output sent to browser
DEBUG - 2011-05-27 11:29:48 --> Total execution time: 0.2584
DEBUG - 2011-05-27 11:29:48 --> Config Class Initialized
DEBUG - 2011-05-27 11:29:48 --> Hooks Class Initialized
DEBUG - 2011-05-27 11:29:48 --> Utf8 Class Initialized
DEBUG - 2011-05-27 11:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 11:29:48 --> URI Class Initialized
DEBUG - 2011-05-27 11:29:48 --> Router Class Initialized
DEBUG - 2011-05-27 11:29:48 --> Output Class Initialized
DEBUG - 2011-05-27 11:29:48 --> Input Class Initialized
DEBUG - 2011-05-27 11:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 11:29:48 --> Language Class Initialized
DEBUG - 2011-05-27 11:29:48 --> Loader Class Initialized
DEBUG - 2011-05-27 11:29:48 --> Controller Class Initialized
ERROR - 2011-05-27 11:29:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 11:29:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 11:29:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 11:29:49 --> Model Class Initialized
DEBUG - 2011-05-27 11:29:49 --> Model Class Initialized
DEBUG - 2011-05-27 11:29:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 11:29:49 --> Database Driver Class Initialized
DEBUG - 2011-05-27 11:29:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 11:29:49 --> Helper loaded: url_helper
DEBUG - 2011-05-27 11:29:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 11:29:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 11:29:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 11:29:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 11:29:49 --> Final output sent to browser
DEBUG - 2011-05-27 11:29:49 --> Total execution time: 0.1621
DEBUG - 2011-05-27 12:26:04 --> Config Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Hooks Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Utf8 Class Initialized
DEBUG - 2011-05-27 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 12:26:04 --> URI Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Router Class Initialized
ERROR - 2011-05-27 12:26:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-27 12:26:04 --> Config Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Hooks Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Utf8 Class Initialized
DEBUG - 2011-05-27 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 12:26:04 --> URI Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Router Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Output Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Input Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 12:26:04 --> Language Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Loader Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Controller Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Model Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Model Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Model Class Initialized
DEBUG - 2011-05-27 12:26:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 12:26:04 --> Database Driver Class Initialized
DEBUG - 2011-05-27 12:26:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-27 12:26:05 --> Helper loaded: url_helper
DEBUG - 2011-05-27 12:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 12:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 12:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 12:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 12:26:05 --> Final output sent to browser
DEBUG - 2011-05-27 12:26:05 --> Total execution time: 0.8281
DEBUG - 2011-05-27 12:26:35 --> Config Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Hooks Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Utf8 Class Initialized
DEBUG - 2011-05-27 12:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 12:26:35 --> URI Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Router Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Output Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Input Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 12:26:35 --> Language Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Loader Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Controller Class Initialized
ERROR - 2011-05-27 12:26:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 12:26:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 12:26:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 12:26:35 --> Model Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Model Class Initialized
DEBUG - 2011-05-27 12:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 12:26:35 --> Database Driver Class Initialized
DEBUG - 2011-05-27 12:26:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 12:26:35 --> Helper loaded: url_helper
DEBUG - 2011-05-27 12:26:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 12:26:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 12:26:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 12:26:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 12:26:35 --> Final output sent to browser
DEBUG - 2011-05-27 12:26:35 --> Total execution time: 0.0836
DEBUG - 2011-05-27 13:16:47 --> Config Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Hooks Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Utf8 Class Initialized
DEBUG - 2011-05-27 13:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 13:16:47 --> URI Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Router Class Initialized
ERROR - 2011-05-27 13:16:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-27 13:16:47 --> Config Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Hooks Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Utf8 Class Initialized
DEBUG - 2011-05-27 13:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 13:16:47 --> URI Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Router Class Initialized
DEBUG - 2011-05-27 13:16:47 --> No URI present. Default controller set.
DEBUG - 2011-05-27 13:16:47 --> Output Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Input Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 13:16:47 --> Language Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Loader Class Initialized
DEBUG - 2011-05-27 13:16:47 --> Controller Class Initialized
DEBUG - 2011-05-27 13:16:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-27 13:16:47 --> Helper loaded: url_helper
DEBUG - 2011-05-27 13:16:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 13:16:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 13:16:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 13:16:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 13:16:47 --> Final output sent to browser
DEBUG - 2011-05-27 13:16:47 --> Total execution time: 0.2310
DEBUG - 2011-05-27 13:16:49 --> Config Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Hooks Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Utf8 Class Initialized
DEBUG - 2011-05-27 13:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 13:16:49 --> URI Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Router Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Output Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Input Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 13:16:49 --> Language Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Loader Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Controller Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Model Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Model Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Model Class Initialized
DEBUG - 2011-05-27 13:16:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 13:16:49 --> Database Driver Class Initialized
DEBUG - 2011-05-27 13:16:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-27 13:16:49 --> Helper loaded: url_helper
DEBUG - 2011-05-27 13:16:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 13:16:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 13:16:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 13:16:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 13:16:49 --> Final output sent to browser
DEBUG - 2011-05-27 13:16:49 --> Total execution time: 0.5430
DEBUG - 2011-05-27 14:21:44 --> Config Class Initialized
DEBUG - 2011-05-27 14:21:44 --> Hooks Class Initialized
DEBUG - 2011-05-27 14:21:45 --> Utf8 Class Initialized
DEBUG - 2011-05-27 14:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 14:21:45 --> URI Class Initialized
DEBUG - 2011-05-27 14:21:45 --> Router Class Initialized
DEBUG - 2011-05-27 14:21:45 --> No URI present. Default controller set.
DEBUG - 2011-05-27 14:21:45 --> Output Class Initialized
DEBUG - 2011-05-27 14:21:45 --> Input Class Initialized
DEBUG - 2011-05-27 14:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 14:21:45 --> Language Class Initialized
DEBUG - 2011-05-27 14:21:45 --> Loader Class Initialized
DEBUG - 2011-05-27 14:21:45 --> Controller Class Initialized
DEBUG - 2011-05-27 14:21:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-27 14:21:45 --> Helper loaded: url_helper
DEBUG - 2011-05-27 14:21:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 14:21:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 14:21:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 14:21:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 14:21:45 --> Final output sent to browser
DEBUG - 2011-05-27 14:21:45 --> Total execution time: 0.5467
DEBUG - 2011-05-27 17:43:16 --> Config Class Initialized
DEBUG - 2011-05-27 17:43:16 --> Hooks Class Initialized
DEBUG - 2011-05-27 17:43:16 --> Utf8 Class Initialized
DEBUG - 2011-05-27 17:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 17:43:16 --> URI Class Initialized
DEBUG - 2011-05-27 17:43:16 --> Router Class Initialized
ERROR - 2011-05-27 17:43:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-27 17:44:01 --> Config Class Initialized
DEBUG - 2011-05-27 17:44:01 --> Hooks Class Initialized
DEBUG - 2011-05-27 17:44:01 --> Utf8 Class Initialized
DEBUG - 2011-05-27 17:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 17:44:01 --> URI Class Initialized
DEBUG - 2011-05-27 17:44:01 --> Router Class Initialized
DEBUG - 2011-05-27 17:44:01 --> Output Class Initialized
DEBUG - 2011-05-27 17:44:01 --> Input Class Initialized
DEBUG - 2011-05-27 17:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 17:44:01 --> Language Class Initialized
DEBUG - 2011-05-27 17:44:02 --> Loader Class Initialized
DEBUG - 2011-05-27 17:44:02 --> Controller Class Initialized
ERROR - 2011-05-27 17:44:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 17:44:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 17:44:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 17:44:04 --> Model Class Initialized
DEBUG - 2011-05-27 17:44:04 --> Model Class Initialized
DEBUG - 2011-05-27 17:44:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 17:44:05 --> Database Driver Class Initialized
DEBUG - 2011-05-27 17:44:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 17:44:05 --> Helper loaded: url_helper
DEBUG - 2011-05-27 17:44:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 17:44:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 17:44:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 17:44:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 17:44:05 --> Final output sent to browser
DEBUG - 2011-05-27 17:44:05 --> Total execution time: 3.8154
DEBUG - 2011-05-27 22:03:00 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:00 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:00 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:00 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:00 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:00 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:00 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:00 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:00 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:00 --> Controller Class Initialized
ERROR - 2011-05-27 22:03:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 22:03:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 22:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:01 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:01 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:01 --> Helper loaded: url_helper
DEBUG - 2011-05-27 22:03:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 22:03:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 22:03:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 22:03:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 22:03:01 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:01 --> Total execution time: 0.3319
DEBUG - 2011-05-27 22:03:01 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:01 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:01 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Controller Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:01 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:02 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:02 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Controller Class Initialized
ERROR - 2011-05-27 22:03:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 22:03:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 22:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:02 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:02 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:02 --> Helper loaded: url_helper
DEBUG - 2011-05-27 22:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 22:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 22:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 22:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 22:03:02 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:02 --> Total execution time: 0.0419
DEBUG - 2011-05-27 22:03:02 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:02 --> Total execution time: 0.9470
DEBUG - 2011-05-27 22:03:03 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:03 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Router Class Initialized
ERROR - 2011-05-27 22:03:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 22:03:03 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:03 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Router Class Initialized
ERROR - 2011-05-27 22:03:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 22:03:03 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:03 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:03 --> Router Class Initialized
ERROR - 2011-05-27 22:03:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 22:03:16 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:16 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:16 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Controller Class Initialized
ERROR - 2011-05-27 22:03:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 22:03:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 22:03:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:16 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:16 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:16 --> Helper loaded: url_helper
DEBUG - 2011-05-27 22:03:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 22:03:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 22:03:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 22:03:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 22:03:16 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:16 --> Total execution time: 0.0314
DEBUG - 2011-05-27 22:03:16 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:16 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:16 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Controller Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:16 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:17 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:17 --> Total execution time: 0.6700
DEBUG - 2011-05-27 22:03:17 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:17 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:17 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:17 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:17 --> Router Class Initialized
ERROR - 2011-05-27 22:03:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-27 22:03:18 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:18 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:18 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Controller Class Initialized
ERROR - 2011-05-27 22:03:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 22:03:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 22:03:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:18 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:18 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:18 --> Helper loaded: url_helper
DEBUG - 2011-05-27 22:03:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 22:03:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 22:03:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 22:03:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 22:03:18 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:18 --> Total execution time: 0.0313
DEBUG - 2011-05-27 22:03:23 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:23 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:23 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Controller Class Initialized
ERROR - 2011-05-27 22:03:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 22:03:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 22:03:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:23 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:23 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:23 --> Helper loaded: url_helper
DEBUG - 2011-05-27 22:03:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 22:03:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 22:03:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 22:03:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 22:03:23 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:23 --> Total execution time: 0.0310
DEBUG - 2011-05-27 22:03:23 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:23 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:23 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Controller Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:23 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:23 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:23 --> Total execution time: 0.6627
DEBUG - 2011-05-27 22:03:25 --> Config Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:03:25 --> URI Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Router Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Output Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Input Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:03:25 --> Language Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Loader Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Controller Class Initialized
ERROR - 2011-05-27 22:03:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-27 22:03:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-27 22:03:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:25 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Model Class Initialized
DEBUG - 2011-05-27 22:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-27 22:03:25 --> Database Driver Class Initialized
DEBUG - 2011-05-27 22:03:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-27 22:03:25 --> Helper loaded: url_helper
DEBUG - 2011-05-27 22:03:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 22:03:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 22:03:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 22:03:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 22:03:25 --> Final output sent to browser
DEBUG - 2011-05-27 22:03:25 --> Total execution time: 0.0808
DEBUG - 2011-05-27 22:10:32 --> Config Class Initialized
DEBUG - 2011-05-27 22:10:32 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:10:32 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:10:32 --> URI Class Initialized
DEBUG - 2011-05-27 22:10:32 --> Router Class Initialized
DEBUG - 2011-05-27 22:10:32 --> No URI present. Default controller set.
DEBUG - 2011-05-27 22:10:32 --> Output Class Initialized
DEBUG - 2011-05-27 22:10:32 --> Input Class Initialized
DEBUG - 2011-05-27 22:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:10:32 --> Language Class Initialized
DEBUG - 2011-05-27 22:10:32 --> Loader Class Initialized
DEBUG - 2011-05-27 22:10:32 --> Controller Class Initialized
DEBUG - 2011-05-27 22:10:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-27 22:10:32 --> Helper loaded: url_helper
DEBUG - 2011-05-27 22:10:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 22:10:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 22:10:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 22:10:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 22:10:32 --> Final output sent to browser
DEBUG - 2011-05-27 22:10:32 --> Total execution time: 0.0743
DEBUG - 2011-05-27 22:56:27 --> Config Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:56:27 --> URI Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Router Class Initialized
ERROR - 2011-05-27 22:56:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-27 22:56:27 --> Config Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Hooks Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Utf8 Class Initialized
DEBUG - 2011-05-27 22:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 22:56:27 --> URI Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Router Class Initialized
DEBUG - 2011-05-27 22:56:27 --> No URI present. Default controller set.
DEBUG - 2011-05-27 22:56:27 --> Output Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Input Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 22:56:27 --> Language Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Loader Class Initialized
DEBUG - 2011-05-27 22:56:27 --> Controller Class Initialized
DEBUG - 2011-05-27 22:56:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-27 22:56:27 --> Helper loaded: url_helper
DEBUG - 2011-05-27 22:56:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-27 22:56:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-27 22:56:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-27 22:56:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-27 22:56:27 --> Final output sent to browser
DEBUG - 2011-05-27 22:56:27 --> Total execution time: 0.1762

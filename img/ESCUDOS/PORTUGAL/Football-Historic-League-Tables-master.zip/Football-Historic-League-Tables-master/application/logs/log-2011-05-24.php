<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-24 01:19:16 --> Config Class Initialized
DEBUG - 2011-05-24 01:19:16 --> Hooks Class Initialized
DEBUG - 2011-05-24 01:19:16 --> Utf8 Class Initialized
DEBUG - 2011-05-24 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 01:19:16 --> URI Class Initialized
DEBUG - 2011-05-24 01:19:16 --> Router Class Initialized
ERROR - 2011-05-24 01:19:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-24 01:19:17 --> Config Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Hooks Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Utf8 Class Initialized
DEBUG - 2011-05-24 01:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 01:19:17 --> URI Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Router Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Output Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Input Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 01:19:17 --> Language Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Loader Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Controller Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Model Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Model Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Model Class Initialized
DEBUG - 2011-05-24 01:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 01:19:17 --> Database Driver Class Initialized
DEBUG - 2011-05-24 01:19:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 01:19:17 --> Helper loaded: url_helper
DEBUG - 2011-05-24 01:19:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 01:19:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 01:19:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 01:19:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 01:19:17 --> Final output sent to browser
DEBUG - 2011-05-24 01:19:17 --> Total execution time: 0.6527
DEBUG - 2011-05-24 01:19:48 --> Config Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Hooks Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Utf8 Class Initialized
DEBUG - 2011-05-24 01:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 01:19:48 --> URI Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Router Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Output Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Input Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 01:19:48 --> Language Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Loader Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Controller Class Initialized
ERROR - 2011-05-24 01:19:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 01:19:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 01:19:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 01:19:48 --> Model Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Model Class Initialized
DEBUG - 2011-05-24 01:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 01:19:48 --> Database Driver Class Initialized
DEBUG - 2011-05-24 01:19:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 01:19:48 --> Helper loaded: url_helper
DEBUG - 2011-05-24 01:19:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 01:19:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 01:19:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 01:19:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 01:19:48 --> Final output sent to browser
DEBUG - 2011-05-24 01:19:48 --> Total execution time: 0.1920
DEBUG - 2011-05-24 01:45:05 --> Config Class Initialized
DEBUG - 2011-05-24 01:45:05 --> Hooks Class Initialized
DEBUG - 2011-05-24 01:45:05 --> Utf8 Class Initialized
DEBUG - 2011-05-24 01:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 01:45:05 --> URI Class Initialized
DEBUG - 2011-05-24 01:45:05 --> Router Class Initialized
DEBUG - 2011-05-24 01:45:05 --> No URI present. Default controller set.
DEBUG - 2011-05-24 01:45:05 --> Output Class Initialized
DEBUG - 2011-05-24 01:45:05 --> Input Class Initialized
DEBUG - 2011-05-24 01:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 01:45:05 --> Language Class Initialized
DEBUG - 2011-05-24 01:45:05 --> Loader Class Initialized
DEBUG - 2011-05-24 01:45:05 --> Controller Class Initialized
DEBUG - 2011-05-24 01:45:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 01:45:06 --> Helper loaded: url_helper
DEBUG - 2011-05-24 01:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 01:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 01:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 01:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 01:45:06 --> Final output sent to browser
DEBUG - 2011-05-24 01:45:06 --> Total execution time: 1.7283
DEBUG - 2011-05-24 01:45:11 --> Config Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Hooks Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Utf8 Class Initialized
DEBUG - 2011-05-24 01:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 01:45:11 --> URI Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Router Class Initialized
ERROR - 2011-05-24 01:45:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 01:45:11 --> Config Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Hooks Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Utf8 Class Initialized
DEBUG - 2011-05-24 01:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 01:45:11 --> URI Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Router Class Initialized
ERROR - 2011-05-24 01:45:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 01:45:11 --> Config Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Hooks Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Utf8 Class Initialized
DEBUG - 2011-05-24 01:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 01:45:11 --> URI Class Initialized
DEBUG - 2011-05-24 01:45:11 --> Router Class Initialized
ERROR - 2011-05-24 01:45:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 03:17:03 --> Config Class Initialized
DEBUG - 2011-05-24 03:17:03 --> Hooks Class Initialized
DEBUG - 2011-05-24 03:17:03 --> Utf8 Class Initialized
DEBUG - 2011-05-24 03:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 03:17:03 --> URI Class Initialized
DEBUG - 2011-05-24 03:17:03 --> Router Class Initialized
DEBUG - 2011-05-24 03:17:03 --> No URI present. Default controller set.
DEBUG - 2011-05-24 03:17:03 --> Output Class Initialized
DEBUG - 2011-05-24 03:17:03 --> Input Class Initialized
DEBUG - 2011-05-24 03:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 03:17:03 --> Language Class Initialized
DEBUG - 2011-05-24 03:17:03 --> Loader Class Initialized
DEBUG - 2011-05-24 03:17:03 --> Controller Class Initialized
DEBUG - 2011-05-24 03:17:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 03:17:03 --> Helper loaded: url_helper
DEBUG - 2011-05-24 03:17:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 03:17:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 03:17:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 03:17:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 03:17:03 --> Final output sent to browser
DEBUG - 2011-05-24 03:17:03 --> Total execution time: 0.4315
DEBUG - 2011-05-24 03:22:45 --> Config Class Initialized
DEBUG - 2011-05-24 03:22:45 --> Hooks Class Initialized
DEBUG - 2011-05-24 03:22:45 --> Utf8 Class Initialized
DEBUG - 2011-05-24 03:22:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 03:22:45 --> URI Class Initialized
DEBUG - 2011-05-24 03:22:45 --> Router Class Initialized
ERROR - 2011-05-24 03:22:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-24 03:47:34 --> Config Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Hooks Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Utf8 Class Initialized
DEBUG - 2011-05-24 03:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 03:47:34 --> URI Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Router Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Output Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Input Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 03:47:34 --> Language Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Loader Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Controller Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Model Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Model Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Model Class Initialized
DEBUG - 2011-05-24 03:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 03:47:34 --> Database Driver Class Initialized
DEBUG - 2011-05-24 03:47:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 03:47:40 --> Helper loaded: url_helper
DEBUG - 2011-05-24 03:47:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 03:47:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 03:47:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 03:47:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 03:47:40 --> Final output sent to browser
DEBUG - 2011-05-24 03:47:40 --> Total execution time: 6.9333
DEBUG - 2011-05-24 04:18:46 --> Config Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Hooks Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Utf8 Class Initialized
DEBUG - 2011-05-24 04:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 04:18:46 --> URI Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Router Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Output Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Input Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 04:18:46 --> Language Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Loader Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Controller Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Model Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Model Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Model Class Initialized
DEBUG - 2011-05-24 04:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 04:18:47 --> Database Driver Class Initialized
DEBUG - 2011-05-24 04:19:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 04:19:01 --> Helper loaded: url_helper
DEBUG - 2011-05-24 04:19:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 04:19:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 04:19:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 04:19:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 04:19:01 --> Final output sent to browser
DEBUG - 2011-05-24 04:19:01 --> Total execution time: 15.0928
DEBUG - 2011-05-24 04:19:04 --> Config Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Hooks Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Utf8 Class Initialized
DEBUG - 2011-05-24 04:19:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 04:19:04 --> URI Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Router Class Initialized
ERROR - 2011-05-24 04:19:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 04:19:04 --> Config Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Hooks Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Utf8 Class Initialized
DEBUG - 2011-05-24 04:19:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 04:19:04 --> URI Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Router Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Output Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Input Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 04:19:04 --> Language Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Loader Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Controller Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Model Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Model Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Model Class Initialized
DEBUG - 2011-05-24 04:19:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 04:19:04 --> Database Driver Class Initialized
DEBUG - 2011-05-24 04:19:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 04:19:04 --> Helper loaded: url_helper
DEBUG - 2011-05-24 04:19:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 04:19:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 04:19:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 04:19:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 04:19:04 --> Final output sent to browser
DEBUG - 2011-05-24 04:19:04 --> Total execution time: 0.0528
DEBUG - 2011-05-24 05:23:34 --> Config Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:23:34 --> URI Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Router Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Output Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Input Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:23:34 --> Language Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Loader Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Controller Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Model Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Model Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Model Class Initialized
DEBUG - 2011-05-24 05:23:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:23:34 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:23:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 05:23:41 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:23:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:23:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:23:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:23:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:23:41 --> Final output sent to browser
DEBUG - 2011-05-24 05:23:41 --> Total execution time: 7.5446
DEBUG - 2011-05-24 05:23:59 --> Config Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:23:59 --> URI Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Router Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Output Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Input Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:23:59 --> Language Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Loader Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Controller Class Initialized
ERROR - 2011-05-24 05:23:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 05:23:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 05:23:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:23:59 --> Model Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Model Class Initialized
DEBUG - 2011-05-24 05:23:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:23:59 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:23:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:23:59 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:23:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:23:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:23:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:23:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:23:59 --> Final output sent to browser
DEBUG - 2011-05-24 05:23:59 --> Total execution time: 0.1565
DEBUG - 2011-05-24 05:35:13 --> Config Class Initialized
DEBUG - 2011-05-24 05:35:14 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:35:14 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:35:14 --> URI Class Initialized
DEBUG - 2011-05-24 05:35:14 --> Router Class Initialized
DEBUG - 2011-05-24 05:35:14 --> Output Class Initialized
DEBUG - 2011-05-24 05:35:15 --> Input Class Initialized
DEBUG - 2011-05-24 05:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:35:15 --> Language Class Initialized
DEBUG - 2011-05-24 05:35:16 --> Loader Class Initialized
DEBUG - 2011-05-24 05:35:16 --> Controller Class Initialized
DEBUG - 2011-05-24 05:35:16 --> Model Class Initialized
DEBUG - 2011-05-24 05:35:16 --> Model Class Initialized
DEBUG - 2011-05-24 05:35:17 --> Model Class Initialized
DEBUG - 2011-05-24 05:35:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:35:17 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:35:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 05:35:52 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:35:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:35:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:35:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:35:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:35:53 --> Final output sent to browser
DEBUG - 2011-05-24 05:35:53 --> Total execution time: 39.3892
DEBUG - 2011-05-24 05:35:57 --> Config Class Initialized
DEBUG - 2011-05-24 05:35:57 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:35:57 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:35:57 --> URI Class Initialized
DEBUG - 2011-05-24 05:35:57 --> Router Class Initialized
ERROR - 2011-05-24 05:35:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 05:35:58 --> Config Class Initialized
DEBUG - 2011-05-24 05:35:58 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:35:58 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:35:58 --> URI Class Initialized
DEBUG - 2011-05-24 05:35:58 --> Router Class Initialized
ERROR - 2011-05-24 05:35:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 05:47:36 --> Config Class Initialized
DEBUG - 2011-05-24 05:47:36 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:47:36 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:47:36 --> URI Class Initialized
DEBUG - 2011-05-24 05:47:36 --> Router Class Initialized
DEBUG - 2011-05-24 05:47:36 --> No URI present. Default controller set.
DEBUG - 2011-05-24 05:47:36 --> Output Class Initialized
DEBUG - 2011-05-24 05:47:36 --> Input Class Initialized
DEBUG - 2011-05-24 05:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:47:36 --> Language Class Initialized
DEBUG - 2011-05-24 05:47:36 --> Loader Class Initialized
DEBUG - 2011-05-24 05:47:36 --> Controller Class Initialized
DEBUG - 2011-05-24 05:47:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 05:47:36 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:47:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:47:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:47:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:47:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:47:36 --> Final output sent to browser
DEBUG - 2011-05-24 05:47:36 --> Total execution time: 0.2393
DEBUG - 2011-05-24 05:47:37 --> Config Class Initialized
DEBUG - 2011-05-24 05:47:37 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:47:37 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:47:37 --> URI Class Initialized
DEBUG - 2011-05-24 05:47:37 --> Router Class Initialized
DEBUG - 2011-05-24 05:47:37 --> No URI present. Default controller set.
DEBUG - 2011-05-24 05:47:37 --> Output Class Initialized
DEBUG - 2011-05-24 05:47:37 --> Input Class Initialized
DEBUG - 2011-05-24 05:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:47:37 --> Language Class Initialized
DEBUG - 2011-05-24 05:47:37 --> Loader Class Initialized
DEBUG - 2011-05-24 05:47:37 --> Controller Class Initialized
DEBUG - 2011-05-24 05:47:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 05:47:37 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:47:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:47:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:47:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:47:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:47:37 --> Final output sent to browser
DEBUG - 2011-05-24 05:47:37 --> Total execution time: 0.0216
DEBUG - 2011-05-24 05:47:43 --> Config Class Initialized
DEBUG - 2011-05-24 05:47:43 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:47:43 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:47:43 --> URI Class Initialized
DEBUG - 2011-05-24 05:47:43 --> Router Class Initialized
ERROR - 2011-05-24 05:47:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 05:47:43 --> Config Class Initialized
DEBUG - 2011-05-24 05:47:43 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:47:43 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:47:43 --> URI Class Initialized
DEBUG - 2011-05-24 05:47:43 --> Router Class Initialized
ERROR - 2011-05-24 05:47:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 05:47:49 --> Config Class Initialized
DEBUG - 2011-05-24 05:47:49 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:47:49 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:47:49 --> URI Class Initialized
DEBUG - 2011-05-24 05:47:49 --> Router Class Initialized
DEBUG - 2011-05-24 05:47:49 --> Output Class Initialized
DEBUG - 2011-05-24 05:47:49 --> Input Class Initialized
DEBUG - 2011-05-24 05:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:47:49 --> Language Class Initialized
DEBUG - 2011-05-24 05:47:49 --> Loader Class Initialized
DEBUG - 2011-05-24 05:47:49 --> Controller Class Initialized
ERROR - 2011-05-24 05:47:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 05:47:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 05:47:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:47:50 --> Model Class Initialized
DEBUG - 2011-05-24 05:47:50 --> Model Class Initialized
DEBUG - 2011-05-24 05:47:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:47:50 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:47:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:47:50 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:47:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:47:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:47:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:47:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:47:50 --> Final output sent to browser
DEBUG - 2011-05-24 05:47:50 --> Total execution time: 0.2211
DEBUG - 2011-05-24 05:47:51 --> Config Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:47:51 --> URI Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Router Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Output Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Input Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:47:51 --> Language Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Loader Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Controller Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Model Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Model Class Initialized
DEBUG - 2011-05-24 05:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:47:51 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:47:52 --> Final output sent to browser
DEBUG - 2011-05-24 05:47:52 --> Total execution time: 0.6915
DEBUG - 2011-05-24 05:49:06 --> Config Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:49:06 --> URI Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Router Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Output Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Input Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:49:06 --> Language Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Loader Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Controller Class Initialized
ERROR - 2011-05-24 05:49:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 05:49:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 05:49:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:49:06 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:49:06 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:49:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:49:06 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:49:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:49:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:49:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:49:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:49:06 --> Final output sent to browser
DEBUG - 2011-05-24 05:49:06 --> Total execution time: 0.0291
DEBUG - 2011-05-24 05:49:08 --> Config Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:49:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:49:08 --> URI Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Router Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Output Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Input Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:49:08 --> Language Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Loader Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Controller Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:49:08 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:49:08 --> Final output sent to browser
DEBUG - 2011-05-24 05:49:08 --> Total execution time: 0.6883
DEBUG - 2011-05-24 05:49:19 --> Config Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:49:19 --> URI Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Router Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Output Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Input Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:49:19 --> Language Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Loader Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Controller Class Initialized
ERROR - 2011-05-24 05:49:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 05:49:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 05:49:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:49:19 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:49:19 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:49:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:49:19 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:49:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:49:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:49:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:49:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:49:19 --> Final output sent to browser
DEBUG - 2011-05-24 05:49:19 --> Total execution time: 0.0332
DEBUG - 2011-05-24 05:49:21 --> Config Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:49:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:49:21 --> URI Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Router Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Output Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Input Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:49:21 --> Language Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Loader Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Controller Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:49:21 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:49:23 --> Final output sent to browser
DEBUG - 2011-05-24 05:49:23 --> Total execution time: 1.5292
DEBUG - 2011-05-24 05:49:38 --> Config Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:49:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:49:38 --> URI Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Router Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Output Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Input Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:49:38 --> Language Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Loader Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Controller Class Initialized
ERROR - 2011-05-24 05:49:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 05:49:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 05:49:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:49:38 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:49:38 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:49:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:49:38 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:49:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:49:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:49:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:49:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:49:38 --> Final output sent to browser
DEBUG - 2011-05-24 05:49:38 --> Total execution time: 0.0753
DEBUG - 2011-05-24 05:49:39 --> Config Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:49:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:49:39 --> URI Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Router Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Output Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Input Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:49:39 --> Language Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Loader Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Controller Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:49:39 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:49:40 --> Final output sent to browser
DEBUG - 2011-05-24 05:49:40 --> Total execution time: 0.8926
DEBUG - 2011-05-24 05:49:52 --> Config Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:49:52 --> URI Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Router Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Output Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Input Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:49:52 --> Language Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Loader Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Controller Class Initialized
ERROR - 2011-05-24 05:49:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 05:49:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 05:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:49:52 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:49:52 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:49:52 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:49:52 --> Final output sent to browser
DEBUG - 2011-05-24 05:49:52 --> Total execution time: 0.0308
DEBUG - 2011-05-24 05:49:54 --> Config Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:49:54 --> URI Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Router Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Output Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Input Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:49:54 --> Language Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Loader Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Controller Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Model Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:49:54 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:49:54 --> Final output sent to browser
DEBUG - 2011-05-24 05:49:54 --> Total execution time: 0.7845
DEBUG - 2011-05-24 05:50:11 --> Config Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:50:11 --> URI Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Router Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Output Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Input Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:50:11 --> Language Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Loader Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Controller Class Initialized
ERROR - 2011-05-24 05:50:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 05:50:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 05:50:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:50:11 --> Model Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Model Class Initialized
DEBUG - 2011-05-24 05:50:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:50:11 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:50:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 05:50:11 --> Helper loaded: url_helper
DEBUG - 2011-05-24 05:50:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 05:50:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 05:50:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 05:50:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 05:50:11 --> Final output sent to browser
DEBUG - 2011-05-24 05:50:11 --> Total execution time: 0.0292
DEBUG - 2011-05-24 05:50:12 --> Config Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Hooks Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Utf8 Class Initialized
DEBUG - 2011-05-24 05:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 05:50:12 --> URI Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Router Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Output Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Input Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 05:50:12 --> Language Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Loader Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Controller Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Model Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Model Class Initialized
DEBUG - 2011-05-24 05:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 05:50:12 --> Database Driver Class Initialized
DEBUG - 2011-05-24 05:50:13 --> Final output sent to browser
DEBUG - 2011-05-24 05:50:13 --> Total execution time: 0.5055
DEBUG - 2011-05-24 06:23:24 --> Config Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:23:24 --> URI Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Router Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Output Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Input Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:23:24 --> Language Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Loader Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Controller Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Model Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Model Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Model Class Initialized
DEBUG - 2011-05-24 06:23:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:23:24 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:23:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:23:25 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:23:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:23:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:23:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:23:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:23:25 --> Final output sent to browser
DEBUG - 2011-05-24 06:23:25 --> Total execution time: 0.9045
DEBUG - 2011-05-24 06:23:45 --> Config Class Initialized
DEBUG - 2011-05-24 06:23:45 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:23:45 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:23:45 --> URI Class Initialized
DEBUG - 2011-05-24 06:23:45 --> Router Class Initialized
DEBUG - 2011-05-24 06:23:45 --> Output Class Initialized
DEBUG - 2011-05-24 06:23:45 --> Input Class Initialized
DEBUG - 2011-05-24 06:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:23:45 --> Language Class Initialized
DEBUG - 2011-05-24 06:23:45 --> Loader Class Initialized
DEBUG - 2011-05-24 06:23:45 --> Controller Class Initialized
ERROR - 2011-05-24 06:23:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 06:23:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 06:23:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 06:23:46 --> Model Class Initialized
DEBUG - 2011-05-24 06:23:46 --> Model Class Initialized
DEBUG - 2011-05-24 06:23:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:23:46 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:23:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 06:23:46 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:23:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:23:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:23:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:23:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:23:46 --> Final output sent to browser
DEBUG - 2011-05-24 06:23:46 --> Total execution time: 0.1426
DEBUG - 2011-05-24 06:26:43 --> Config Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:26:43 --> URI Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Router Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Output Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Input Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:26:43 --> Language Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Loader Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Controller Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Model Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Model Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Model Class Initialized
DEBUG - 2011-05-24 06:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:26:43 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:26:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:26:43 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:26:43 --> Final output sent to browser
DEBUG - 2011-05-24 06:26:43 --> Total execution time: 0.1496
DEBUG - 2011-05-24 06:26:49 --> Config Class Initialized
DEBUG - 2011-05-24 06:26:49 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:26:49 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:26:49 --> URI Class Initialized
DEBUG - 2011-05-24 06:26:49 --> Router Class Initialized
ERROR - 2011-05-24 06:26:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 06:27:00 --> Config Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:27:00 --> URI Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Router Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Output Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Input Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:27:00 --> Language Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Loader Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Controller Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:27:00 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:27:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:27:02 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:27:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:27:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:27:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:27:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:27:02 --> Final output sent to browser
DEBUG - 2011-05-24 06:27:02 --> Total execution time: 1.9227
DEBUG - 2011-05-24 06:27:06 --> Config Class Initialized
DEBUG - 2011-05-24 06:27:06 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:27:06 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:27:06 --> URI Class Initialized
DEBUG - 2011-05-24 06:27:06 --> Router Class Initialized
ERROR - 2011-05-24 06:27:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 06:27:35 --> Config Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:27:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:27:35 --> URI Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Router Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Output Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Input Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:27:35 --> Language Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Loader Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Controller Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:27:35 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:27:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:27:38 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:27:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:27:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:27:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:27:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:27:38 --> Final output sent to browser
DEBUG - 2011-05-24 06:27:38 --> Total execution time: 2.4445
DEBUG - 2011-05-24 06:27:55 --> Config Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:27:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:27:55 --> URI Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Router Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Output Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Input Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:27:55 --> Language Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Loader Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Controller Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Model Class Initialized
DEBUG - 2011-05-24 06:27:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:27:55 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:27:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:27:58 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:27:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:27:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:27:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:27:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:27:58 --> Final output sent to browser
DEBUG - 2011-05-24 06:27:58 --> Total execution time: 2.4298
DEBUG - 2011-05-24 06:28:06 --> Config Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:28:06 --> URI Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Router Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Output Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Input Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:28:06 --> Language Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Loader Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Controller Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:28:06 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:28:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:28:08 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:28:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:28:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:28:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:28:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:28:08 --> Final output sent to browser
DEBUG - 2011-05-24 06:28:08 --> Total execution time: 1.7559
DEBUG - 2011-05-24 06:28:10 --> Config Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:28:10 --> URI Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Router Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Output Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Input Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:28:10 --> Language Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Loader Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Controller Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:28:10 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:28:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:28:10 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:28:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:28:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:28:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:28:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:28:10 --> Final output sent to browser
DEBUG - 2011-05-24 06:28:10 --> Total execution time: 0.0570
DEBUG - 2011-05-24 06:28:19 --> Config Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:28:19 --> URI Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Router Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Output Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Input Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:28:19 --> Language Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Loader Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Controller Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:28:19 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:28:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:28:19 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:28:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:28:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:28:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:28:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:28:19 --> Final output sent to browser
DEBUG - 2011-05-24 06:28:19 --> Total execution time: 0.1217
DEBUG - 2011-05-24 06:28:20 --> Config Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:28:20 --> URI Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Router Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Output Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Input Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:28:20 --> Language Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Loader Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Controller Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:28:20 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:28:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:28:20 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:28:20 --> Final output sent to browser
DEBUG - 2011-05-24 06:28:20 --> Total execution time: 0.0598
DEBUG - 2011-05-24 06:28:21 --> Config Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:28:21 --> URI Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Router Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Output Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Input Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:28:21 --> Language Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Loader Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Controller Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:28:21 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:28:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:28:21 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:28:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:28:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:28:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:28:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:28:21 --> Final output sent to browser
DEBUG - 2011-05-24 06:28:21 --> Total execution time: 0.0460
DEBUG - 2011-05-24 06:28:22 --> Config Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:28:22 --> URI Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Router Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Output Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Input Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:28:22 --> Language Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Loader Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Controller Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:28:22 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:28:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:28:22 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:28:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:28:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:28:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:28:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:28:22 --> Final output sent to browser
DEBUG - 2011-05-24 06:28:22 --> Total execution time: 0.3043
DEBUG - 2011-05-24 06:28:25 --> Config Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:28:25 --> URI Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Router Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Output Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Input Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:28:25 --> Language Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Loader Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Controller Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Model Class Initialized
DEBUG - 2011-05-24 06:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:28:25 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:28:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:28:25 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:28:25 --> Final output sent to browser
DEBUG - 2011-05-24 06:28:25 --> Total execution time: 0.0464
DEBUG - 2011-05-24 06:29:03 --> Config Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:29:03 --> URI Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Router Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Output Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Input Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:29:03 --> Language Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Loader Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Controller Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:29:03 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:29:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:29:04 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:29:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:29:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:29:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:29:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:29:04 --> Final output sent to browser
DEBUG - 2011-05-24 06:29:04 --> Total execution time: 0.5912
DEBUG - 2011-05-24 06:29:05 --> Config Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:29:05 --> URI Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Router Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Output Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Input Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:29:05 --> Language Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Loader Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Controller Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:29:05 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:29:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:29:05 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:29:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:29:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:29:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:29:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:29:05 --> Final output sent to browser
DEBUG - 2011-05-24 06:29:05 --> Total execution time: 0.1419
DEBUG - 2011-05-24 06:29:13 --> Config Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:29:13 --> URI Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Router Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Output Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Input Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:29:13 --> Language Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Loader Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Controller Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:29:13 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:29:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:29:14 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:29:14 --> Final output sent to browser
DEBUG - 2011-05-24 06:29:14 --> Total execution time: 0.9682
DEBUG - 2011-05-24 06:29:16 --> Config Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:29:16 --> URI Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Router Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Output Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Input Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:29:16 --> Language Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Loader Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Controller Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Model Class Initialized
DEBUG - 2011-05-24 06:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:29:16 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:29:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:29:16 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:29:16 --> Final output sent to browser
DEBUG - 2011-05-24 06:29:16 --> Total execution time: 0.0469
DEBUG - 2011-05-24 06:30:03 --> Config Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:30:03 --> URI Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Router Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Output Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Input Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:30:03 --> Language Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Loader Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Controller Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:30:03 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:30:05 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:30:05 --> Final output sent to browser
DEBUG - 2011-05-24 06:30:05 --> Total execution time: 2.6931
DEBUG - 2011-05-24 06:30:19 --> Config Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:30:19 --> URI Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Router Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Output Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Input Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:30:19 --> Language Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Loader Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Controller Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:30:19 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:30:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:30:19 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:30:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:30:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:30:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:30:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:30:19 --> Final output sent to browser
DEBUG - 2011-05-24 06:30:19 --> Total execution time: 0.1007
DEBUG - 2011-05-24 06:30:48 --> Config Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:30:48 --> URI Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Router Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Output Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Input Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:30:48 --> Language Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Loader Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Controller Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:30:48 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:30:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:30:49 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:30:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:30:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:30:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:30:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:30:49 --> Final output sent to browser
DEBUG - 2011-05-24 06:30:49 --> Total execution time: 0.2842
DEBUG - 2011-05-24 06:30:50 --> Config Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:30:50 --> URI Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Router Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Output Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Input Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:30:50 --> Language Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Loader Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Controller Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:30:50 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:30:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:30:50 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:30:50 --> Final output sent to browser
DEBUG - 2011-05-24 06:30:50 --> Total execution time: 0.0571
DEBUG - 2011-05-24 06:30:57 --> Config Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:30:57 --> URI Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Router Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Output Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Input Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:30:57 --> Language Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Loader Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Controller Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:30:57 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:30:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:30:58 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:30:58 --> Final output sent to browser
DEBUG - 2011-05-24 06:30:58 --> Total execution time: 0.2645
DEBUG - 2011-05-24 06:30:58 --> Config Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:30:58 --> URI Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Router Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Output Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Input Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:30:58 --> Language Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Loader Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Controller Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Model Class Initialized
DEBUG - 2011-05-24 06:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:30:59 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:30:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:30:59 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:30:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:30:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:30:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:30:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:30:59 --> Final output sent to browser
DEBUG - 2011-05-24 06:30:59 --> Total execution time: 0.1091
DEBUG - 2011-05-24 06:31:07 --> Config Class Initialized
DEBUG - 2011-05-24 06:31:07 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:31:07 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:31:07 --> URI Class Initialized
DEBUG - 2011-05-24 06:31:07 --> Router Class Initialized
ERROR - 2011-05-24 06:31:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-24 06:31:09 --> Config Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:31:09 --> URI Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Router Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Output Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Input Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:31:09 --> Language Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Loader Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Controller Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:31:09 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:31:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:31:10 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:31:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:31:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:31:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:31:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:31:10 --> Final output sent to browser
DEBUG - 2011-05-24 06:31:10 --> Total execution time: 0.7484
DEBUG - 2011-05-24 06:31:11 --> Config Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:31:11 --> URI Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Router Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Output Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Input Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:31:11 --> Language Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Loader Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Controller Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:31:11 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:31:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:31:11 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:31:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:31:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:31:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:31:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:31:11 --> Final output sent to browser
DEBUG - 2011-05-24 06:31:11 --> Total execution time: 0.1005
DEBUG - 2011-05-24 06:31:18 --> Config Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:31:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:31:18 --> URI Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Router Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Output Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Input Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:31:18 --> Language Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Loader Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Controller Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:31:18 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:31:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:31:18 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:31:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:31:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:31:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:31:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:31:18 --> Final output sent to browser
DEBUG - 2011-05-24 06:31:18 --> Total execution time: 0.6579
DEBUG - 2011-05-24 06:31:21 --> Config Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:31:21 --> URI Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Router Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Output Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Input Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:31:21 --> Language Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Loader Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Controller Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:31:21 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:31:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:31:21 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:31:21 --> Final output sent to browser
DEBUG - 2011-05-24 06:31:21 --> Total execution time: 0.0570
DEBUG - 2011-05-24 06:31:28 --> Config Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:31:28 --> URI Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Router Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Output Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Input Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:31:28 --> Language Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Loader Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Controller Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:31:28 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:31:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:31:28 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:31:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:31:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:31:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:31:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:31:28 --> Final output sent to browser
DEBUG - 2011-05-24 06:31:28 --> Total execution time: 0.2669
DEBUG - 2011-05-24 06:31:29 --> Config Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:31:29 --> URI Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Router Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Output Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Input Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:31:29 --> Language Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Loader Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Controller Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Model Class Initialized
DEBUG - 2011-05-24 06:31:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:31:29 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:31:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:31:29 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:31:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:31:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:31:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:31:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:31:29 --> Final output sent to browser
DEBUG - 2011-05-24 06:31:29 --> Total execution time: 0.0473
DEBUG - 2011-05-24 06:32:07 --> Config Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:32:07 --> URI Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Router Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Output Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Input Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:32:07 --> Language Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Loader Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Controller Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:32:07 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:32:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:32:07 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:32:07 --> Final output sent to browser
DEBUG - 2011-05-24 06:32:07 --> Total execution time: 0.0466
DEBUG - 2011-05-24 06:32:43 --> Config Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:32:43 --> URI Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Router Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Output Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Input Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:32:43 --> Language Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Loader Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Controller Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:32:43 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:32:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:32:43 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:32:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:32:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:32:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:32:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:32:43 --> Final output sent to browser
DEBUG - 2011-05-24 06:32:43 --> Total execution time: 0.8099
DEBUG - 2011-05-24 06:32:46 --> Config Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:32:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:32:46 --> URI Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Router Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Output Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Input Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:32:46 --> Language Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Loader Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Controller Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:32:46 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:32:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:32:46 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:32:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:32:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:32:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:32:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:32:46 --> Final output sent to browser
DEBUG - 2011-05-24 06:32:46 --> Total execution time: 0.0469
DEBUG - 2011-05-24 06:32:50 --> Config Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:32:50 --> URI Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Router Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Output Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Input Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:32:50 --> Language Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Loader Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Controller Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:32:50 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:32:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:32:50 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:32:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:32:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:32:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:32:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:32:50 --> Final output sent to browser
DEBUG - 2011-05-24 06:32:50 --> Total execution time: 0.2107
DEBUG - 2011-05-24 06:32:51 --> Config Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:32:51 --> URI Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Router Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Output Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Input Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:32:51 --> Language Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Loader Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Controller Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:32:51 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:32:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:32:51 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:32:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:32:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:32:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:32:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:32:51 --> Final output sent to browser
DEBUG - 2011-05-24 06:32:51 --> Total execution time: 0.0636
DEBUG - 2011-05-24 06:32:58 --> Config Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:32:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:32:58 --> URI Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Router Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Output Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Input Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:32:58 --> Language Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Loader Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Controller Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Model Class Initialized
DEBUG - 2011-05-24 06:32:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:32:58 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:32:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:32:59 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:32:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:32:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:32:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:32:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:32:59 --> Final output sent to browser
DEBUG - 2011-05-24 06:32:59 --> Total execution time: 0.5486
DEBUG - 2011-05-24 06:33:00 --> Config Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:33:00 --> URI Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Router Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Output Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Input Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:33:00 --> Language Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Loader Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Controller Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:33:00 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:33:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:33:00 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:33:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:33:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:33:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:33:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:33:00 --> Final output sent to browser
DEBUG - 2011-05-24 06:33:00 --> Total execution time: 0.0665
DEBUG - 2011-05-24 06:33:13 --> Config Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:33:13 --> URI Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Router Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Output Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Input Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:33:13 --> Language Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Loader Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Controller Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:33:13 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:33:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:33:14 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:33:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:33:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:33:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:33:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:33:14 --> Final output sent to browser
DEBUG - 2011-05-24 06:33:14 --> Total execution time: 0.4584
DEBUG - 2011-05-24 06:33:15 --> Config Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:33:15 --> URI Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Router Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Output Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Input Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:33:15 --> Language Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Loader Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Controller Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:33:15 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:33:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:33:15 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:33:15 --> Final output sent to browser
DEBUG - 2011-05-24 06:33:15 --> Total execution time: 0.0446
DEBUG - 2011-05-24 06:33:16 --> Config Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:33:16 --> URI Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Router Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Output Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Input Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:33:16 --> Language Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Loader Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Controller Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:33:16 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:33:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:33:16 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:33:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:33:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:33:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:33:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:33:16 --> Final output sent to browser
DEBUG - 2011-05-24 06:33:16 --> Total execution time: 0.1629
DEBUG - 2011-05-24 06:33:21 --> Config Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:33:21 --> URI Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Router Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Output Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Input Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:33:21 --> Language Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Loader Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Controller Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:33:21 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:33:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:33:21 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:33:21 --> Final output sent to browser
DEBUG - 2011-05-24 06:33:21 --> Total execution time: 0.0685
DEBUG - 2011-05-24 06:33:30 --> Config Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Hooks Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Utf8 Class Initialized
DEBUG - 2011-05-24 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 06:33:30 --> URI Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Router Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Output Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Input Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 06:33:30 --> Language Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Loader Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Controller Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Model Class Initialized
DEBUG - 2011-05-24 06:33:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 06:33:30 --> Database Driver Class Initialized
DEBUG - 2011-05-24 06:33:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 06:33:30 --> Helper loaded: url_helper
DEBUG - 2011-05-24 06:33:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 06:33:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 06:33:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 06:33:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 06:33:30 --> Final output sent to browser
DEBUG - 2011-05-24 06:33:30 --> Total execution time: 0.0508
DEBUG - 2011-05-24 08:09:35 --> Config Class Initialized
DEBUG - 2011-05-24 08:09:35 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:09:35 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:09:35 --> URI Class Initialized
DEBUG - 2011-05-24 08:09:35 --> Router Class Initialized
DEBUG - 2011-05-24 08:09:35 --> No URI present. Default controller set.
DEBUG - 2011-05-24 08:09:35 --> Output Class Initialized
DEBUG - 2011-05-24 08:09:35 --> Input Class Initialized
DEBUG - 2011-05-24 08:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:09:35 --> Language Class Initialized
DEBUG - 2011-05-24 08:09:35 --> Loader Class Initialized
DEBUG - 2011-05-24 08:09:35 --> Controller Class Initialized
DEBUG - 2011-05-24 08:09:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 08:09:35 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:09:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:09:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:09:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:09:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:09:35 --> Final output sent to browser
DEBUG - 2011-05-24 08:09:35 --> Total execution time: 0.3489
DEBUG - 2011-05-24 08:09:37 --> Config Class Initialized
DEBUG - 2011-05-24 08:09:37 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:09:37 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:09:37 --> URI Class Initialized
DEBUG - 2011-05-24 08:09:37 --> Router Class Initialized
ERROR - 2011-05-24 08:09:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 08:09:37 --> Config Class Initialized
DEBUG - 2011-05-24 08:09:37 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:09:37 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:09:37 --> URI Class Initialized
DEBUG - 2011-05-24 08:09:37 --> Router Class Initialized
ERROR - 2011-05-24 08:09:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 08:09:39 --> Config Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:09:39 --> URI Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Router Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Output Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Input Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:09:39 --> Language Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Loader Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Controller Class Initialized
ERROR - 2011-05-24 08:09:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:09:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:09:39 --> Model Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Model Class Initialized
DEBUG - 2011-05-24 08:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:09:39 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:09:39 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:09:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:09:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:09:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:09:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:09:39 --> Final output sent to browser
DEBUG - 2011-05-24 08:09:39 --> Total execution time: 0.1853
DEBUG - 2011-05-24 08:09:40 --> Config Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:09:40 --> URI Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Router Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Output Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Input Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:09:40 --> Language Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Loader Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Controller Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Model Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Model Class Initialized
DEBUG - 2011-05-24 08:09:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:09:40 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:09:41 --> Final output sent to browser
DEBUG - 2011-05-24 08:09:41 --> Total execution time: 0.8010
DEBUG - 2011-05-24 08:10:03 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:03 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:03 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Controller Class Initialized
ERROR - 2011-05-24 08:10:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:10:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:10:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:03 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:03 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:03 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:10:03 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:03 --> Total execution time: 0.2032
DEBUG - 2011-05-24 08:10:03 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:03 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:03 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Controller Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:03 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:04 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:04 --> Total execution time: 0.8369
DEBUG - 2011-05-24 08:10:11 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:11 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:11 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Controller Class Initialized
ERROR - 2011-05-24 08:10:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:10:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:10:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:11 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:11 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:11 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:10:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:10:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:10:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:10:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:10:11 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:11 --> Total execution time: 0.0316
DEBUG - 2011-05-24 08:10:21 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:21 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:21 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Controller Class Initialized
ERROR - 2011-05-24 08:10:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:10:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:21 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:21 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:21 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:10:21 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:21 --> Total execution time: 0.0529
DEBUG - 2011-05-24 08:10:22 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:22 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:22 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Controller Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:22 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:24 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:24 --> Total execution time: 2.3402
DEBUG - 2011-05-24 08:10:31 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:31 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:31 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Controller Class Initialized
ERROR - 2011-05-24 08:10:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:10:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:10:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:31 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:31 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:31 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:10:31 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:31 --> Total execution time: 0.0822
DEBUG - 2011-05-24 08:10:33 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:33 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:33 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Controller Class Initialized
ERROR - 2011-05-24 08:10:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:10:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:10:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:33 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:33 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:33 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:10:33 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:33 --> Total execution time: 0.0317
DEBUG - 2011-05-24 08:10:34 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:34 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:34 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Controller Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:34 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:34 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:34 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Controller Class Initialized
ERROR - 2011-05-24 08:10:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:10:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:10:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:34 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:34 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:34 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:10:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:10:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:10:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:10:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:10:34 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:34 --> Total execution time: 0.0613
DEBUG - 2011-05-24 08:10:34 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:34 --> Total execution time: 0.6953
DEBUG - 2011-05-24 08:10:49 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:49 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:49 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Controller Class Initialized
ERROR - 2011-05-24 08:10:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:10:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:10:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:49 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:49 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:10:49 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:10:49 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:49 --> Total execution time: 0.0409
DEBUG - 2011-05-24 08:10:50 --> Config Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:10:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:10:50 --> URI Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Router Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Output Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Input Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:10:50 --> Language Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Loader Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Controller Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Model Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:10:50 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:10:50 --> Final output sent to browser
DEBUG - 2011-05-24 08:10:50 --> Total execution time: 0.5547
DEBUG - 2011-05-24 08:11:08 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:08 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:08 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Controller Class Initialized
ERROR - 2011-05-24 08:11:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:11:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:11:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:08 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:08 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:08 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:11:08 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:08 --> Total execution time: 0.0468
DEBUG - 2011-05-24 08:11:09 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:09 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:09 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Controller Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:09 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:09 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:09 --> Total execution time: 0.7945
DEBUG - 2011-05-24 08:11:24 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:24 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:24 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Controller Class Initialized
ERROR - 2011-05-24 08:11:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:11:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:24 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:24 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:24 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:11:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:11:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:11:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:11:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:11:24 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:24 --> Total execution time: 0.0441
DEBUG - 2011-05-24 08:11:28 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:28 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:28 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Controller Class Initialized
ERROR - 2011-05-24 08:11:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:11:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:11:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:28 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:28 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:28 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:11:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:11:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:11:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:11:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:11:28 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:28 --> Total execution time: 0.0344
DEBUG - 2011-05-24 08:11:28 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:28 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:28 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Controller Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:28 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:29 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:29 --> Total execution time: 0.5687
DEBUG - 2011-05-24 08:11:36 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:36 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:36 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Controller Class Initialized
ERROR - 2011-05-24 08:11:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:11:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:36 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:36 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:36 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:11:36 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:36 --> Total execution time: 0.0299
DEBUG - 2011-05-24 08:11:36 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:36 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:36 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Controller Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:36 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:37 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:37 --> Total execution time: 0.5810
DEBUG - 2011-05-24 08:11:54 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:54 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:54 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Controller Class Initialized
ERROR - 2011-05-24 08:11:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:11:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:11:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:54 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:54 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:11:55 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:11:55 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:55 --> Total execution time: 0.0316
DEBUG - 2011-05-24 08:11:56 --> Config Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:11:56 --> URI Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Router Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Output Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Input Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:11:56 --> Language Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Loader Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Controller Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Model Class Initialized
DEBUG - 2011-05-24 08:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:11:56 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:11:57 --> Final output sent to browser
DEBUG - 2011-05-24 08:11:57 --> Total execution time: 1.1123
DEBUG - 2011-05-24 08:12:07 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:07 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:07 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Controller Class Initialized
ERROR - 2011-05-24 08:12:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:12:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:07 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:07 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:07 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:12:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:12:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:12:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:12:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:12:07 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:07 --> Total execution time: 0.0342
DEBUG - 2011-05-24 08:12:08 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:08 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:08 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Controller Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:08 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:09 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:09 --> Total execution time: 0.8714
DEBUG - 2011-05-24 08:12:24 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:24 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:24 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Controller Class Initialized
ERROR - 2011-05-24 08:12:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:24 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:24 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:25 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:12:25 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:25 --> Total execution time: 0.1659
DEBUG - 2011-05-24 08:12:25 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:25 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:25 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Controller Class Initialized
ERROR - 2011-05-24 08:12:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:12:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:25 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:25 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:25 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:12:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:12:25 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:25 --> Total execution time: 0.0680
DEBUG - 2011-05-24 08:12:26 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:26 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:26 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Controller Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:26 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:27 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:27 --> Total execution time: 1.0432
DEBUG - 2011-05-24 08:12:29 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:29 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:29 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Controller Class Initialized
ERROR - 2011-05-24 08:12:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:12:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:12:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:29 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:29 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:29 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:12:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:12:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:12:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:12:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:12:29 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:29 --> Total execution time: 0.0344
DEBUG - 2011-05-24 08:12:37 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:37 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:37 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Controller Class Initialized
ERROR - 2011-05-24 08:12:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:12:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:12:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:37 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:37 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:37 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:12:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:12:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:12:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:12:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:12:37 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:37 --> Total execution time: 0.0427
DEBUG - 2011-05-24 08:12:38 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:38 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:38 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Controller Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:38 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:38 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:38 --> Total execution time: 0.8149
DEBUG - 2011-05-24 08:12:39 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:39 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:39 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Controller Class Initialized
ERROR - 2011-05-24 08:12:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:12:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:39 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:39 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:39 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:12:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:12:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:12:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:12:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:12:39 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:39 --> Total execution time: 0.0630
DEBUG - 2011-05-24 08:12:55 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:55 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:55 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Controller Class Initialized
ERROR - 2011-05-24 08:12:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:12:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:55 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:55 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:12:55 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:12:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:12:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:12:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:12:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:12:55 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:55 --> Total execution time: 0.0400
DEBUG - 2011-05-24 08:12:56 --> Config Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:12:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:12:56 --> URI Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Router Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Output Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Input Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:12:56 --> Language Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Loader Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Controller Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Model Class Initialized
DEBUG - 2011-05-24 08:12:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:12:56 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:12:57 --> Final output sent to browser
DEBUG - 2011-05-24 08:12:57 --> Total execution time: 1.1289
DEBUG - 2011-05-24 08:13:40 --> Config Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Hooks Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Utf8 Class Initialized
DEBUG - 2011-05-24 08:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 08:13:40 --> URI Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Router Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Output Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Input Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 08:13:40 --> Language Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Loader Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Controller Class Initialized
ERROR - 2011-05-24 08:13:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 08:13:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 08:13:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:13:40 --> Model Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Model Class Initialized
DEBUG - 2011-05-24 08:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 08:13:40 --> Database Driver Class Initialized
DEBUG - 2011-05-24 08:13:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 08:13:40 --> Helper loaded: url_helper
DEBUG - 2011-05-24 08:13:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 08:13:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 08:13:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 08:13:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 08:13:40 --> Final output sent to browser
DEBUG - 2011-05-24 08:13:40 --> Total execution time: 0.0269
DEBUG - 2011-05-24 09:33:49 --> Config Class Initialized
DEBUG - 2011-05-24 09:33:49 --> Hooks Class Initialized
DEBUG - 2011-05-24 09:33:49 --> Utf8 Class Initialized
DEBUG - 2011-05-24 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 09:33:49 --> URI Class Initialized
DEBUG - 2011-05-24 09:33:49 --> Router Class Initialized
ERROR - 2011-05-24 09:33:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-24 09:34:37 --> Config Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Hooks Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Utf8 Class Initialized
DEBUG - 2011-05-24 09:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 09:34:37 --> URI Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Router Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Output Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Input Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 09:34:37 --> Language Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Loader Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Controller Class Initialized
ERROR - 2011-05-24 09:34:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 09:34:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 09:34:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 09:34:37 --> Model Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Model Class Initialized
DEBUG - 2011-05-24 09:34:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 09:34:38 --> Database Driver Class Initialized
DEBUG - 2011-05-24 09:34:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 09:34:38 --> Helper loaded: url_helper
DEBUG - 2011-05-24 09:34:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 09:34:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 09:34:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 09:34:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 09:34:38 --> Final output sent to browser
DEBUG - 2011-05-24 09:34:38 --> Total execution time: 1.2654
DEBUG - 2011-05-24 11:17:41 --> Config Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:17:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:17:41 --> URI Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Router Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Output Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Input Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 11:17:41 --> Language Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Loader Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Controller Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Model Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Model Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Model Class Initialized
DEBUG - 2011-05-24 11:17:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 11:17:41 --> Database Driver Class Initialized
DEBUG - 2011-05-24 11:17:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 11:17:41 --> Helper loaded: url_helper
DEBUG - 2011-05-24 11:17:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 11:17:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 11:17:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 11:17:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 11:17:41 --> Final output sent to browser
DEBUG - 2011-05-24 11:17:41 --> Total execution time: 0.6139
DEBUG - 2011-05-24 11:17:45 --> Config Class Initialized
DEBUG - 2011-05-24 11:17:45 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:17:45 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:17:45 --> URI Class Initialized
DEBUG - 2011-05-24 11:17:45 --> Router Class Initialized
ERROR - 2011-05-24 11:17:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 11:17:47 --> Config Class Initialized
DEBUG - 2011-05-24 11:17:47 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:17:47 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:17:47 --> URI Class Initialized
DEBUG - 2011-05-24 11:17:47 --> Router Class Initialized
ERROR - 2011-05-24 11:17:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 11:17:53 --> Config Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:17:53 --> URI Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Router Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Output Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Input Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 11:17:53 --> Language Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Loader Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Controller Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Model Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Model Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Model Class Initialized
DEBUG - 2011-05-24 11:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 11:17:53 --> Database Driver Class Initialized
DEBUG - 2011-05-24 11:17:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 11:17:53 --> Helper loaded: url_helper
DEBUG - 2011-05-24 11:17:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 11:17:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 11:17:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 11:17:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 11:17:53 --> Final output sent to browser
DEBUG - 2011-05-24 11:17:53 --> Total execution time: 0.2842
DEBUG - 2011-05-24 11:18:13 --> Config Class Initialized
DEBUG - 2011-05-24 11:18:13 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:18:13 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:18:13 --> URI Class Initialized
DEBUG - 2011-05-24 11:18:13 --> Router Class Initialized
ERROR - 2011-05-24 11:18:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-24 11:18:14 --> Config Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:18:14 --> URI Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Router Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Output Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Input Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 11:18:14 --> Language Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Loader Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Controller Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Model Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Model Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Model Class Initialized
DEBUG - 2011-05-24 11:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 11:18:14 --> Database Driver Class Initialized
DEBUG - 2011-05-24 11:18:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 11:18:14 --> Helper loaded: url_helper
DEBUG - 2011-05-24 11:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 11:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 11:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 11:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 11:18:14 --> Final output sent to browser
DEBUG - 2011-05-24 11:18:14 --> Total execution time: 0.2771
DEBUG - 2011-05-24 11:18:26 --> Config Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:18:26 --> URI Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Router Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Output Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Input Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 11:18:26 --> Language Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Loader Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Controller Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Model Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Model Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Model Class Initialized
DEBUG - 2011-05-24 11:18:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 11:18:26 --> Database Driver Class Initialized
DEBUG - 2011-05-24 11:18:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 11:18:26 --> Helper loaded: url_helper
DEBUG - 2011-05-24 11:18:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 11:18:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 11:18:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 11:18:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 11:18:26 --> Final output sent to browser
DEBUG - 2011-05-24 11:18:26 --> Total execution time: 0.2296
DEBUG - 2011-05-24 11:55:01 --> Config Class Initialized
DEBUG - 2011-05-24 11:55:01 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:55:01 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:55:01 --> URI Class Initialized
DEBUG - 2011-05-24 11:55:01 --> Router Class Initialized
ERROR - 2011-05-24 11:55:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-24 11:55:02 --> Config Class Initialized
DEBUG - 2011-05-24 11:55:02 --> Hooks Class Initialized
DEBUG - 2011-05-24 11:55:02 --> Utf8 Class Initialized
DEBUG - 2011-05-24 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 11:55:02 --> URI Class Initialized
DEBUG - 2011-05-24 11:55:02 --> Router Class Initialized
DEBUG - 2011-05-24 11:55:02 --> No URI present. Default controller set.
DEBUG - 2011-05-24 11:55:02 --> Output Class Initialized
DEBUG - 2011-05-24 11:55:02 --> Input Class Initialized
DEBUG - 2011-05-24 11:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 11:55:02 --> Language Class Initialized
DEBUG - 2011-05-24 11:55:02 --> Loader Class Initialized
DEBUG - 2011-05-24 11:55:02 --> Controller Class Initialized
DEBUG - 2011-05-24 11:55:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 11:55:02 --> Helper loaded: url_helper
DEBUG - 2011-05-24 11:55:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 11:55:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 11:55:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 11:55:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 11:55:02 --> Final output sent to browser
DEBUG - 2011-05-24 11:55:02 --> Total execution time: 0.3500
DEBUG - 2011-05-24 13:17:24 --> Config Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Hooks Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Utf8 Class Initialized
DEBUG - 2011-05-24 13:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 13:17:24 --> URI Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Router Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Output Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Input Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 13:17:24 --> Language Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Loader Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Controller Class Initialized
ERROR - 2011-05-24 13:17:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 13:17:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 13:17:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 13:17:24 --> Model Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Model Class Initialized
DEBUG - 2011-05-24 13:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 13:17:24 --> Database Driver Class Initialized
DEBUG - 2011-05-24 13:17:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 13:17:24 --> Helper loaded: url_helper
DEBUG - 2011-05-24 13:17:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 13:17:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 13:17:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 13:17:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 13:17:24 --> Final output sent to browser
DEBUG - 2011-05-24 13:17:24 --> Total execution time: 0.5256
DEBUG - 2011-05-24 13:17:25 --> Config Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Hooks Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Utf8 Class Initialized
DEBUG - 2011-05-24 13:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 13:17:25 --> URI Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Router Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Output Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Input Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 13:17:25 --> Language Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Loader Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Controller Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Model Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Model Class Initialized
DEBUG - 2011-05-24 13:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 13:17:25 --> Database Driver Class Initialized
DEBUG - 2011-05-24 13:17:27 --> Final output sent to browser
DEBUG - 2011-05-24 13:17:27 --> Total execution time: 1.5003
DEBUG - 2011-05-24 13:17:28 --> Config Class Initialized
DEBUG - 2011-05-24 13:17:28 --> Hooks Class Initialized
DEBUG - 2011-05-24 13:17:28 --> Utf8 Class Initialized
DEBUG - 2011-05-24 13:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 13:17:28 --> URI Class Initialized
DEBUG - 2011-05-24 13:17:28 --> Router Class Initialized
ERROR - 2011-05-24 13:17:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 13:17:37 --> Config Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Hooks Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Utf8 Class Initialized
DEBUG - 2011-05-24 13:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 13:17:37 --> URI Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Router Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Output Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Input Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 13:17:37 --> Language Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Loader Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Controller Class Initialized
ERROR - 2011-05-24 13:17:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 13:17:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 13:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 13:17:37 --> Model Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Model Class Initialized
DEBUG - 2011-05-24 13:17:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 13:17:37 --> Database Driver Class Initialized
DEBUG - 2011-05-24 13:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 13:17:37 --> Helper loaded: url_helper
DEBUG - 2011-05-24 13:17:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 13:17:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 13:17:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 13:17:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 13:17:37 --> Final output sent to browser
DEBUG - 2011-05-24 13:17:37 --> Total execution time: 0.0291
DEBUG - 2011-05-24 13:17:38 --> Config Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Hooks Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Utf8 Class Initialized
DEBUG - 2011-05-24 13:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 13:17:38 --> URI Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Router Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Output Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Input Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 13:17:38 --> Language Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Loader Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Controller Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Model Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Model Class Initialized
DEBUG - 2011-05-24 13:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 13:17:38 --> Database Driver Class Initialized
DEBUG - 2011-05-24 13:17:39 --> Final output sent to browser
DEBUG - 2011-05-24 13:17:39 --> Total execution time: 0.6325
DEBUG - 2011-05-24 13:17:40 --> Config Class Initialized
DEBUG - 2011-05-24 13:17:40 --> Hooks Class Initialized
DEBUG - 2011-05-24 13:17:40 --> Utf8 Class Initialized
DEBUG - 2011-05-24 13:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 13:17:40 --> URI Class Initialized
DEBUG - 2011-05-24 13:17:40 --> Router Class Initialized
ERROR - 2011-05-24 13:17:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 13:56:31 --> Config Class Initialized
DEBUG - 2011-05-24 13:56:31 --> Hooks Class Initialized
DEBUG - 2011-05-24 13:56:31 --> Utf8 Class Initialized
DEBUG - 2011-05-24 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 13:56:31 --> URI Class Initialized
DEBUG - 2011-05-24 13:56:31 --> Router Class Initialized
DEBUG - 2011-05-24 13:56:31 --> No URI present. Default controller set.
DEBUG - 2011-05-24 13:56:31 --> Output Class Initialized
DEBUG - 2011-05-24 13:56:31 --> Input Class Initialized
DEBUG - 2011-05-24 13:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 13:56:31 --> Language Class Initialized
DEBUG - 2011-05-24 13:56:31 --> Loader Class Initialized
DEBUG - 2011-05-24 13:56:31 --> Controller Class Initialized
DEBUG - 2011-05-24 13:56:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 13:56:31 --> Helper loaded: url_helper
DEBUG - 2011-05-24 13:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 13:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 13:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 13:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 13:56:31 --> Final output sent to browser
DEBUG - 2011-05-24 13:56:31 --> Total execution time: 0.3066
DEBUG - 2011-05-24 14:10:43 --> Config Class Initialized
DEBUG - 2011-05-24 14:10:43 --> Hooks Class Initialized
DEBUG - 2011-05-24 14:10:43 --> Utf8 Class Initialized
DEBUG - 2011-05-24 14:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 14:10:43 --> URI Class Initialized
DEBUG - 2011-05-24 14:10:43 --> Router Class Initialized
DEBUG - 2011-05-24 14:10:43 --> No URI present. Default controller set.
DEBUG - 2011-05-24 14:10:43 --> Output Class Initialized
DEBUG - 2011-05-24 14:10:43 --> Input Class Initialized
DEBUG - 2011-05-24 14:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 14:10:43 --> Language Class Initialized
DEBUG - 2011-05-24 14:10:43 --> Loader Class Initialized
DEBUG - 2011-05-24 14:10:43 --> Controller Class Initialized
DEBUG - 2011-05-24 14:10:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 14:10:43 --> Helper loaded: url_helper
DEBUG - 2011-05-24 14:10:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 14:10:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 14:10:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 14:10:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 14:10:43 --> Final output sent to browser
DEBUG - 2011-05-24 14:10:43 --> Total execution time: 0.2484
DEBUG - 2011-05-24 14:59:30 --> Config Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Hooks Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Utf8 Class Initialized
DEBUG - 2011-05-24 14:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 14:59:30 --> URI Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Router Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Output Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Input Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 14:59:30 --> Language Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Loader Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Controller Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Model Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Model Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Model Class Initialized
DEBUG - 2011-05-24 14:59:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 14:59:30 --> Database Driver Class Initialized
DEBUG - 2011-05-24 14:59:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 14:59:30 --> Helper loaded: url_helper
DEBUG - 2011-05-24 14:59:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 14:59:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 14:59:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 14:59:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 14:59:30 --> Final output sent to browser
DEBUG - 2011-05-24 14:59:30 --> Total execution time: 0.6003
DEBUG - 2011-05-24 14:59:35 --> Config Class Initialized
DEBUG - 2011-05-24 14:59:35 --> Hooks Class Initialized
DEBUG - 2011-05-24 14:59:35 --> Utf8 Class Initialized
DEBUG - 2011-05-24 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 14:59:35 --> URI Class Initialized
DEBUG - 2011-05-24 14:59:35 --> Router Class Initialized
ERROR - 2011-05-24 14:59:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 14:59:35 --> Config Class Initialized
DEBUG - 2011-05-24 14:59:35 --> Hooks Class Initialized
DEBUG - 2011-05-24 14:59:35 --> Utf8 Class Initialized
DEBUG - 2011-05-24 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 14:59:35 --> URI Class Initialized
DEBUG - 2011-05-24 14:59:35 --> Router Class Initialized
ERROR - 2011-05-24 14:59:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 14:59:36 --> Config Class Initialized
DEBUG - 2011-05-24 14:59:36 --> Hooks Class Initialized
DEBUG - 2011-05-24 14:59:36 --> Utf8 Class Initialized
DEBUG - 2011-05-24 14:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 14:59:36 --> URI Class Initialized
DEBUG - 2011-05-24 14:59:36 --> Router Class Initialized
ERROR - 2011-05-24 14:59:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 15:51:23 --> Config Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Hooks Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Utf8 Class Initialized
DEBUG - 2011-05-24 15:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 15:51:23 --> URI Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Router Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Output Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Input Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 15:51:23 --> Language Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Loader Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Controller Class Initialized
ERROR - 2011-05-24 15:51:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 15:51:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 15:51:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 15:51:23 --> Model Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Model Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 15:51:23 --> Database Driver Class Initialized
DEBUG - 2011-05-24 15:51:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 15:51:23 --> Helper loaded: url_helper
DEBUG - 2011-05-24 15:51:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 15:51:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 15:51:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 15:51:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 15:51:23 --> Final output sent to browser
DEBUG - 2011-05-24 15:51:23 --> Total execution time: 0.3485
DEBUG - 2011-05-24 15:51:23 --> Config Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Hooks Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Utf8 Class Initialized
DEBUG - 2011-05-24 15:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 15:51:23 --> URI Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Router Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Output Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Input Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 15:51:23 --> Language Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Loader Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Controller Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Model Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Model Class Initialized
DEBUG - 2011-05-24 15:51:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 15:51:23 --> Database Driver Class Initialized
DEBUG - 2011-05-24 15:51:24 --> Final output sent to browser
DEBUG - 2011-05-24 15:51:24 --> Total execution time: 0.8490
DEBUG - 2011-05-24 15:51:25 --> Config Class Initialized
DEBUG - 2011-05-24 15:51:25 --> Hooks Class Initialized
DEBUG - 2011-05-24 15:51:25 --> Utf8 Class Initialized
DEBUG - 2011-05-24 15:51:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 15:51:25 --> URI Class Initialized
DEBUG - 2011-05-24 15:51:25 --> Router Class Initialized
ERROR - 2011-05-24 15:51:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 15:51:25 --> Config Class Initialized
DEBUG - 2011-05-24 15:51:25 --> Hooks Class Initialized
DEBUG - 2011-05-24 15:51:25 --> Utf8 Class Initialized
DEBUG - 2011-05-24 15:51:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 15:51:25 --> URI Class Initialized
DEBUG - 2011-05-24 15:51:25 --> Router Class Initialized
ERROR - 2011-05-24 15:51:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 16:49:47 --> Config Class Initialized
DEBUG - 2011-05-24 16:49:47 --> Hooks Class Initialized
DEBUG - 2011-05-24 16:49:47 --> Utf8 Class Initialized
DEBUG - 2011-05-24 16:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 16:49:47 --> URI Class Initialized
DEBUG - 2011-05-24 16:49:47 --> Router Class Initialized
ERROR - 2011-05-24 16:49:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-24 17:33:24 --> Config Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Hooks Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Utf8 Class Initialized
DEBUG - 2011-05-24 17:33:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 17:33:24 --> URI Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Router Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Output Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Input Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 17:33:24 --> Language Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Loader Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Controller Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Model Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Model Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Model Class Initialized
DEBUG - 2011-05-24 17:33:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 17:33:24 --> Database Driver Class Initialized
DEBUG - 2011-05-24 17:33:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 17:33:25 --> Helper loaded: url_helper
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 17:33:25 --> Final output sent to browser
DEBUG - 2011-05-24 17:33:25 --> Total execution time: 0.5747
DEBUG - 2011-05-24 17:33:25 --> Config Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Hooks Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Utf8 Class Initialized
DEBUG - 2011-05-24 17:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 17:33:25 --> URI Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Router Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Output Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Input Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 17:33:25 --> Language Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Loader Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Controller Class Initialized
ERROR - 2011-05-24 17:33:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-24 17:33:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 17:33:25 --> Model Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Model Class Initialized
DEBUG - 2011-05-24 17:33:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 17:33:25 --> Database Driver Class Initialized
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-24 17:33:25 --> Helper loaded: url_helper
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 17:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 17:33:25 --> Final output sent to browser
DEBUG - 2011-05-24 17:33:25 --> Total execution time: 0.1176
DEBUG - 2011-05-24 21:09:49 --> Config Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Hooks Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Utf8 Class Initialized
DEBUG - 2011-05-24 21:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 21:09:49 --> URI Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Router Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Output Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Input Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 21:09:49 --> Language Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Loader Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Controller Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Model Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Model Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Model Class Initialized
DEBUG - 2011-05-24 21:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 21:09:49 --> Database Driver Class Initialized
DEBUG - 2011-05-24 21:09:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 21:09:50 --> Helper loaded: url_helper
DEBUG - 2011-05-24 21:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 21:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 21:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 21:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 21:09:50 --> Final output sent to browser
DEBUG - 2011-05-24 21:09:50 --> Total execution time: 0.6160
DEBUG - 2011-05-24 21:09:52 --> Config Class Initialized
DEBUG - 2011-05-24 21:09:52 --> Hooks Class Initialized
DEBUG - 2011-05-24 21:09:52 --> Utf8 Class Initialized
DEBUG - 2011-05-24 21:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 21:09:52 --> URI Class Initialized
DEBUG - 2011-05-24 21:09:52 --> Router Class Initialized
ERROR - 2011-05-24 21:09:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 21:10:00 --> Config Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Hooks Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Utf8 Class Initialized
DEBUG - 2011-05-24 21:10:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 21:10:00 --> URI Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Router Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Output Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Input Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 21:10:00 --> Language Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Loader Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Controller Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Model Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Model Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Model Class Initialized
DEBUG - 2011-05-24 21:10:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 21:10:00 --> Database Driver Class Initialized
DEBUG - 2011-05-24 21:10:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 21:10:00 --> Helper loaded: url_helper
DEBUG - 2011-05-24 21:10:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 21:10:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 21:10:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 21:10:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 21:10:00 --> Final output sent to browser
DEBUG - 2011-05-24 21:10:00 --> Total execution time: 0.2162
DEBUG - 2011-05-24 21:10:01 --> Config Class Initialized
DEBUG - 2011-05-24 21:10:01 --> Hooks Class Initialized
DEBUG - 2011-05-24 21:10:01 --> Utf8 Class Initialized
DEBUG - 2011-05-24 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 21:10:01 --> URI Class Initialized
DEBUG - 2011-05-24 21:10:01 --> Router Class Initialized
ERROR - 2011-05-24 21:10:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-24 21:10:02 --> Config Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Hooks Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Utf8 Class Initialized
DEBUG - 2011-05-24 21:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 21:10:02 --> URI Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Router Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Output Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Input Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 21:10:02 --> Language Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Loader Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Controller Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Model Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Model Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Model Class Initialized
DEBUG - 2011-05-24 21:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 21:10:02 --> Database Driver Class Initialized
DEBUG - 2011-05-24 21:10:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 21:10:02 --> Helper loaded: url_helper
DEBUG - 2011-05-24 21:10:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 21:10:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 21:10:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 21:10:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 21:10:02 --> Final output sent to browser
DEBUG - 2011-05-24 21:10:02 --> Total execution time: 0.4296
DEBUG - 2011-05-24 22:13:40 --> Config Class Initialized
DEBUG - 2011-05-24 22:13:40 --> Hooks Class Initialized
DEBUG - 2011-05-24 22:13:40 --> Utf8 Class Initialized
DEBUG - 2011-05-24 22:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 22:13:40 --> URI Class Initialized
DEBUG - 2011-05-24 22:13:40 --> Router Class Initialized
DEBUG - 2011-05-24 22:13:40 --> No URI present. Default controller set.
DEBUG - 2011-05-24 22:13:40 --> Output Class Initialized
DEBUG - 2011-05-24 22:13:40 --> Input Class Initialized
DEBUG - 2011-05-24 22:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 22:13:40 --> Language Class Initialized
DEBUG - 2011-05-24 22:13:40 --> Loader Class Initialized
DEBUG - 2011-05-24 22:13:40 --> Controller Class Initialized
DEBUG - 2011-05-24 22:13:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-24 22:13:40 --> Helper loaded: url_helper
DEBUG - 2011-05-24 22:13:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 22:13:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 22:13:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 22:13:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 22:13:40 --> Final output sent to browser
DEBUG - 2011-05-24 22:13:40 --> Total execution time: 0.3081
DEBUG - 2011-05-24 22:47:55 --> Config Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Hooks Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Utf8 Class Initialized
DEBUG - 2011-05-24 22:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-24 22:47:55 --> URI Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Router Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Output Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Input Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-24 22:47:55 --> Language Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Loader Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Controller Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Model Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Model Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Model Class Initialized
DEBUG - 2011-05-24 22:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-24 22:47:55 --> Database Driver Class Initialized
DEBUG - 2011-05-24 22:47:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-24 22:47:55 --> Helper loaded: url_helper
DEBUG - 2011-05-24 22:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-24 22:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-24 22:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-24 22:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-24 22:47:55 --> Final output sent to browser
DEBUG - 2011-05-24 22:47:55 --> Total execution time: 0.4834

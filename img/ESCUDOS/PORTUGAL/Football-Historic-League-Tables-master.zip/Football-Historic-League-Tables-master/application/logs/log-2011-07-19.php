<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-19 01:44:20 --> Config Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:44:20 --> URI Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Router Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Output Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Input Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 01:44:20 --> Language Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Loader Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Controller Class Initialized
ERROR - 2011-07-19 01:44:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 01:44:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 01:44:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 01:44:20 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 01:44:20 --> Database Driver Class Initialized
DEBUG - 2011-07-19 01:44:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 01:44:21 --> Helper loaded: url_helper
DEBUG - 2011-07-19 01:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 01:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 01:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 01:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 01:44:21 --> Final output sent to browser
DEBUG - 2011-07-19 01:44:21 --> Total execution time: 0.6561
DEBUG - 2011-07-19 01:44:24 --> Config Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:44:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:44:24 --> URI Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Router Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Output Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Input Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 01:44:24 --> Language Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Loader Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Controller Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 01:44:24 --> Database Driver Class Initialized
DEBUG - 2011-07-19 01:44:25 --> Final output sent to browser
DEBUG - 2011-07-19 01:44:25 --> Total execution time: 0.6875
DEBUG - 2011-07-19 01:44:30 --> Config Class Initialized
DEBUG - 2011-07-19 01:44:30 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:44:30 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:44:30 --> URI Class Initialized
DEBUG - 2011-07-19 01:44:30 --> Router Class Initialized
ERROR - 2011-07-19 01:44:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 01:44:47 --> Config Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:44:47 --> URI Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Router Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Output Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Input Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 01:44:47 --> Language Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Loader Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Controller Class Initialized
ERROR - 2011-07-19 01:44:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 01:44:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 01:44:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 01:44:47 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 01:44:47 --> Database Driver Class Initialized
DEBUG - 2011-07-19 01:44:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 01:44:47 --> Helper loaded: url_helper
DEBUG - 2011-07-19 01:44:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 01:44:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 01:44:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 01:44:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 01:44:47 --> Final output sent to browser
DEBUG - 2011-07-19 01:44:47 --> Total execution time: 0.0320
DEBUG - 2011-07-19 01:44:49 --> Config Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:44:49 --> URI Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Router Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Output Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Input Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 01:44:49 --> Language Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Loader Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Controller Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 01:44:49 --> Database Driver Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Final output sent to browser
DEBUG - 2011-07-19 01:44:49 --> Total execution time: 0.6624
DEBUG - 2011-07-19 01:44:49 --> Config Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:44:49 --> URI Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Router Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Output Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Input Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 01:44:49 --> Language Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Loader Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Controller Class Initialized
ERROR - 2011-07-19 01:44:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 01:44:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 01:44:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 01:44:49 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Model Class Initialized
DEBUG - 2011-07-19 01:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 01:44:49 --> Database Driver Class Initialized
DEBUG - 2011-07-19 01:44:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 01:44:50 --> Helper loaded: url_helper
DEBUG - 2011-07-19 01:44:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 01:44:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 01:44:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 01:44:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 01:44:50 --> Final output sent to browser
DEBUG - 2011-07-19 01:44:50 --> Total execution time: 0.0301
DEBUG - 2011-07-19 01:44:52 --> Config Class Initialized
DEBUG - 2011-07-19 01:44:52 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:44:52 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:44:52 --> URI Class Initialized
DEBUG - 2011-07-19 01:44:52 --> Router Class Initialized
ERROR - 2011-07-19 01:44:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 01:45:04 --> Config Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:45:04 --> URI Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Router Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Output Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Input Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 01:45:04 --> Language Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Loader Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Controller Class Initialized
ERROR - 2011-07-19 01:45:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 01:45:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 01:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 01:45:04 --> Model Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Model Class Initialized
DEBUG - 2011-07-19 01:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 01:45:04 --> Database Driver Class Initialized
DEBUG - 2011-07-19 01:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 01:45:04 --> Helper loaded: url_helper
DEBUG - 2011-07-19 01:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 01:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 01:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 01:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 01:45:04 --> Final output sent to browser
DEBUG - 2011-07-19 01:45:04 --> Total execution time: 0.0516
DEBUG - 2011-07-19 01:45:05 --> Config Class Initialized
DEBUG - 2011-07-19 01:45:05 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:45:05 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:45:05 --> URI Class Initialized
DEBUG - 2011-07-19 01:45:05 --> Router Class Initialized
DEBUG - 2011-07-19 01:45:05 --> Output Class Initialized
DEBUG - 2011-07-19 01:45:06 --> Input Class Initialized
DEBUG - 2011-07-19 01:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 01:45:06 --> Language Class Initialized
DEBUG - 2011-07-19 01:45:06 --> Loader Class Initialized
DEBUG - 2011-07-19 01:45:06 --> Controller Class Initialized
DEBUG - 2011-07-19 01:45:06 --> Model Class Initialized
DEBUG - 2011-07-19 01:45:06 --> Model Class Initialized
DEBUG - 2011-07-19 01:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 01:45:06 --> Database Driver Class Initialized
DEBUG - 2011-07-19 01:45:07 --> Final output sent to browser
DEBUG - 2011-07-19 01:45:07 --> Total execution time: 1.0618
DEBUG - 2011-07-19 01:45:10 --> Config Class Initialized
DEBUG - 2011-07-19 01:45:10 --> Hooks Class Initialized
DEBUG - 2011-07-19 01:45:10 --> Utf8 Class Initialized
DEBUG - 2011-07-19 01:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 01:45:10 --> URI Class Initialized
DEBUG - 2011-07-19 01:45:10 --> Router Class Initialized
ERROR - 2011-07-19 01:45:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 02:42:20 --> Config Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:42:20 --> URI Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Router Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Output Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Input Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:42:20 --> Language Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Loader Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Controller Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Model Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Model Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Model Class Initialized
DEBUG - 2011-07-19 02:42:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:42:20 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:42:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:42:28 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:42:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:42:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:42:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:42:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:42:28 --> Final output sent to browser
DEBUG - 2011-07-19 02:42:28 --> Total execution time: 7.8523
DEBUG - 2011-07-19 02:42:29 --> Config Class Initialized
DEBUG - 2011-07-19 02:42:29 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:42:29 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:42:29 --> URI Class Initialized
DEBUG - 2011-07-19 02:42:29 --> Router Class Initialized
ERROR - 2011-07-19 02:42:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 02:57:21 --> Config Class Initialized
DEBUG - 2011-07-19 02:57:21 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:57:21 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:57:21 --> URI Class Initialized
DEBUG - 2011-07-19 02:57:21 --> Router Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Output Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Input Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:57:22 --> Language Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Loader Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Controller Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 02:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:57:22 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:57:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:57:22 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:57:22 --> Final output sent to browser
DEBUG - 2011-07-19 02:57:22 --> Total execution time: 0.4811
DEBUG - 2011-07-19 02:58:10 --> Config Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:58:10 --> URI Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Router Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Output Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Input Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:58:10 --> Language Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Loader Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Controller Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:58:10 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:58:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:58:11 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:58:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:58:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:58:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:58:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:58:11 --> Final output sent to browser
DEBUG - 2011-07-19 02:58:11 --> Total execution time: 0.4258
DEBUG - 2011-07-19 02:58:14 --> Config Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:58:14 --> URI Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Router Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Output Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Input Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:58:14 --> Language Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Loader Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Controller Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:58:14 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:58:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:58:14 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:58:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:58:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:58:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:58:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:58:14 --> Final output sent to browser
DEBUG - 2011-07-19 02:58:14 --> Total execution time: 0.0452
DEBUG - 2011-07-19 02:58:42 --> Config Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:58:42 --> URI Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Router Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Output Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Input Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:58:42 --> Language Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Loader Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Controller Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:58:42 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:58:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:58:43 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:58:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:58:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:58:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:58:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:58:43 --> Final output sent to browser
DEBUG - 2011-07-19 02:58:43 --> Total execution time: 0.3056
DEBUG - 2011-07-19 02:58:44 --> Config Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:58:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:58:44 --> URI Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Router Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Output Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Input Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:58:44 --> Language Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Loader Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Controller Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Model Class Initialized
DEBUG - 2011-07-19 02:58:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:58:44 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:58:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:58:45 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:58:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:58:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:58:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:58:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:58:45 --> Final output sent to browser
DEBUG - 2011-07-19 02:58:45 --> Total execution time: 0.0500
DEBUG - 2011-07-19 02:59:06 --> Config Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:59:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:59:06 --> URI Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Router Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Output Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Input Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:59:06 --> Language Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Loader Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Controller Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:59:06 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:59:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:59:06 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:59:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:59:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:59:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:59:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:59:06 --> Final output sent to browser
DEBUG - 2011-07-19 02:59:06 --> Total execution time: 0.2538
DEBUG - 2011-07-19 02:59:09 --> Config Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:59:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:59:09 --> URI Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Router Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Output Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Input Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:59:09 --> Language Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Loader Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Controller Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:59:09 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:59:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:59:09 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:59:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:59:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:59:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:59:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:59:09 --> Final output sent to browser
DEBUG - 2011-07-19 02:59:09 --> Total execution time: 0.0567
DEBUG - 2011-07-19 02:59:22 --> Config Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:59:22 --> URI Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Router Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Output Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Input Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:59:22 --> Language Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Loader Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Controller Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:59:22 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:59:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:59:23 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:59:23 --> Final output sent to browser
DEBUG - 2011-07-19 02:59:23 --> Total execution time: 1.0384
DEBUG - 2011-07-19 02:59:25 --> Config Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:59:25 --> URI Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Router Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Output Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Input Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:59:25 --> Language Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Loader Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Controller Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:59:25 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:59:25 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:59:25 --> Final output sent to browser
DEBUG - 2011-07-19 02:59:25 --> Total execution time: 0.0456
DEBUG - 2011-07-19 02:59:42 --> Config Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:59:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:59:42 --> URI Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Router Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Output Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Input Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:59:42 --> Language Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Loader Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Controller Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:59:42 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:59:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:59:42 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:59:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:59:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:59:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:59:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:59:42 --> Final output sent to browser
DEBUG - 2011-07-19 02:59:42 --> Total execution time: 0.2063
DEBUG - 2011-07-19 02:59:44 --> Config Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:59:44 --> URI Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Router Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Output Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Input Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:59:44 --> Language Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Loader Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Controller Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:59:44 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:59:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:59:44 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:59:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:59:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:59:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:59:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:59:44 --> Final output sent to browser
DEBUG - 2011-07-19 02:59:44 --> Total execution time: 0.0496
DEBUG - 2011-07-19 02:59:56 --> Config Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:59:56 --> URI Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Router Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Output Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Input Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:59:56 --> Language Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Loader Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Controller Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:59:56 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:59:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:59:56 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:59:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:59:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:59:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:59:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:59:56 --> Final output sent to browser
DEBUG - 2011-07-19 02:59:56 --> Total execution time: 0.2607
DEBUG - 2011-07-19 02:59:58 --> Config Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Hooks Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Utf8 Class Initialized
DEBUG - 2011-07-19 02:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 02:59:58 --> URI Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Router Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Output Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Input Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 02:59:58 --> Language Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Loader Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Controller Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Model Class Initialized
DEBUG - 2011-07-19 02:59:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 02:59:58 --> Database Driver Class Initialized
DEBUG - 2011-07-19 02:59:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 02:59:58 --> Helper loaded: url_helper
DEBUG - 2011-07-19 02:59:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 02:59:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 02:59:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 02:59:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 02:59:58 --> Final output sent to browser
DEBUG - 2011-07-19 02:59:58 --> Total execution time: 0.0495
DEBUG - 2011-07-19 03:00:25 --> Config Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Hooks Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Utf8 Class Initialized
DEBUG - 2011-07-19 03:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 03:00:25 --> URI Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Router Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Output Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Input Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 03:00:25 --> Language Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Loader Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Controller Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Model Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Model Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Model Class Initialized
DEBUG - 2011-07-19 03:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 03:00:25 --> Database Driver Class Initialized
DEBUG - 2011-07-19 03:00:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 03:00:27 --> Helper loaded: url_helper
DEBUG - 2011-07-19 03:00:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 03:00:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 03:00:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 03:00:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 03:00:27 --> Final output sent to browser
DEBUG - 2011-07-19 03:00:27 --> Total execution time: 2.2703
DEBUG - 2011-07-19 03:00:30 --> Config Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Hooks Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Utf8 Class Initialized
DEBUG - 2011-07-19 03:00:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 03:00:30 --> URI Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Router Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Output Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Input Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 03:00:30 --> Language Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Loader Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Controller Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Model Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Model Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Model Class Initialized
DEBUG - 2011-07-19 03:00:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 03:00:30 --> Database Driver Class Initialized
DEBUG - 2011-07-19 03:00:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 03:00:30 --> Helper loaded: url_helper
DEBUG - 2011-07-19 03:00:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 03:00:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 03:00:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 03:00:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 03:00:30 --> Final output sent to browser
DEBUG - 2011-07-19 03:00:30 --> Total execution time: 0.0528
DEBUG - 2011-07-19 03:06:31 --> Config Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Hooks Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Utf8 Class Initialized
DEBUG - 2011-07-19 03:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 03:06:31 --> URI Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Router Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Output Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Input Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 03:06:31 --> Language Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Loader Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Controller Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 03:06:31 --> Database Driver Class Initialized
DEBUG - 2011-07-19 03:06:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 03:06:33 --> Helper loaded: url_helper
DEBUG - 2011-07-19 03:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 03:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 03:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 03:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 03:06:33 --> Final output sent to browser
DEBUG - 2011-07-19 03:06:33 --> Total execution time: 1.9525
DEBUG - 2011-07-19 03:06:39 --> Config Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Hooks Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Utf8 Class Initialized
DEBUG - 2011-07-19 03:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 03:06:39 --> URI Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Router Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Output Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Input Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 03:06:39 --> Language Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Loader Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Controller Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 03:06:39 --> Database Driver Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Config Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Hooks Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Utf8 Class Initialized
DEBUG - 2011-07-19 03:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 03:06:40 --> URI Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Router Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Output Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Input Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 03:06:40 --> Language Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Loader Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Controller Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Model Class Initialized
DEBUG - 2011-07-19 03:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 03:06:40 --> Database Driver Class Initialized
DEBUG - 2011-07-19 03:06:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 03:06:40 --> Helper loaded: url_helper
DEBUG - 2011-07-19 03:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 03:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 03:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 03:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 03:06:40 --> Final output sent to browser
DEBUG - 2011-07-19 03:06:40 --> Total execution time: 0.7853
DEBUG - 2011-07-19 03:06:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 03:06:41 --> Helper loaded: url_helper
DEBUG - 2011-07-19 03:06:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 03:06:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 03:06:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 03:06:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 03:06:41 --> Final output sent to browser
DEBUG - 2011-07-19 03:06:41 --> Total execution time: 1.4870
DEBUG - 2011-07-19 03:07:02 --> Config Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Hooks Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Utf8 Class Initialized
DEBUG - 2011-07-19 03:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 03:07:02 --> URI Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Router Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Output Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Input Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 03:07:02 --> Language Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Loader Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Controller Class Initialized
ERROR - 2011-07-19 03:07:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 03:07:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 03:07:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 03:07:02 --> Model Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Model Class Initialized
DEBUG - 2011-07-19 03:07:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 03:07:02 --> Database Driver Class Initialized
DEBUG - 2011-07-19 03:07:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 03:07:02 --> Helper loaded: url_helper
DEBUG - 2011-07-19 03:07:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 03:07:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 03:07:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 03:07:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 03:07:02 --> Final output sent to browser
DEBUG - 2011-07-19 03:07:02 --> Total execution time: 0.1890
DEBUG - 2011-07-19 03:07:04 --> Config Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Hooks Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Utf8 Class Initialized
DEBUG - 2011-07-19 03:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 03:07:04 --> URI Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Router Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Output Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Input Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 03:07:04 --> Language Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Loader Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Controller Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Model Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Model Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 03:07:04 --> Database Driver Class Initialized
DEBUG - 2011-07-19 03:07:04 --> Final output sent to browser
DEBUG - 2011-07-19 03:07:04 --> Total execution time: 0.7315
DEBUG - 2011-07-19 04:01:25 --> Config Class Initialized
DEBUG - 2011-07-19 04:01:25 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:01:25 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:01:25 --> URI Class Initialized
DEBUG - 2011-07-19 04:01:25 --> Router Class Initialized
ERROR - 2011-07-19 04:01:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-19 04:03:30 --> Config Class Initialized
DEBUG - 2011-07-19 04:03:30 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:03:30 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:03:30 --> URI Class Initialized
DEBUG - 2011-07-19 04:03:30 --> Router Class Initialized
DEBUG - 2011-07-19 04:03:30 --> Output Class Initialized
DEBUG - 2011-07-19 04:03:30 --> Input Class Initialized
DEBUG - 2011-07-19 04:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:03:30 --> Language Class Initialized
DEBUG - 2011-07-19 04:03:30 --> Loader Class Initialized
DEBUG - 2011-07-19 04:03:30 --> Controller Class Initialized
ERROR - 2011-07-19 04:03:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 04:03:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 04:03:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 04:03:31 --> Model Class Initialized
DEBUG - 2011-07-19 04:03:31 --> Model Class Initialized
DEBUG - 2011-07-19 04:03:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:03:31 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:03:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 04:03:31 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:03:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:03:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:03:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:03:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:03:31 --> Final output sent to browser
DEBUG - 2011-07-19 04:03:31 --> Total execution time: 0.4597
DEBUG - 2011-07-19 04:57:21 --> Config Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Config Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:57:21 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:57:21 --> URI Class Initialized
DEBUG - 2011-07-19 04:57:21 --> URI Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Router Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Router Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Output Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Output Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Input Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Input Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:57:21 --> Language Class Initialized
DEBUG - 2011-07-19 04:57:21 --> Language Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Loader Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Loader Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Controller Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Controller Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Model Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:57:22 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:57:22 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:57:22 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:57:22 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:57:22 --> Final output sent to browser
DEBUG - 2011-07-19 04:57:22 --> Total execution time: 0.7628
DEBUG - 2011-07-19 04:57:22 --> Final output sent to browser
DEBUG - 2011-07-19 04:57:22 --> Total execution time: 0.7629
DEBUG - 2011-07-19 04:57:25 --> Config Class Initialized
DEBUG - 2011-07-19 04:57:25 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:57:25 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:57:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:57:25 --> URI Class Initialized
DEBUG - 2011-07-19 04:57:25 --> Router Class Initialized
ERROR - 2011-07-19 04:57:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:58:00 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:00 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:00 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:00 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:01 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:01 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:01 --> Total execution time: 0.8865
DEBUG - 2011-07-19 04:58:03 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:03 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:03 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:03 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:03 --> Router Class Initialized
ERROR - 2011-07-19 04:58:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:58:05 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:05 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:05 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:05 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:05 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:05 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:05 --> Total execution time: 0.0431
DEBUG - 2011-07-19 04:58:21 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:21 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:21 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:21 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:21 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:21 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:21 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:23 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:23 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:23 --> Total execution time: 1.7391
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:23 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:23 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:23 --> Total execution time: 1.5253
DEBUG - 2011-07-19 04:58:24 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:24 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:24 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:24 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:24 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:24 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:24 --> Total execution time: 0.0428
DEBUG - 2011-07-19 04:58:24 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:24 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:24 --> Router Class Initialized
ERROR - 2011-07-19 04:58:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:58:34 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:34 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:34 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:34 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:35 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:35 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:35 --> Total execution time: 0.3325
DEBUG - 2011-07-19 04:58:35 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:35 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:35 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:36 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:36 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:36 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:36 --> Total execution time: 0.0684
DEBUG - 2011-07-19 04:58:36 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:36 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:36 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:36 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:36 --> Router Class Initialized
ERROR - 2011-07-19 04:58:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:58:49 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:49 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:49 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:49 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:49 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:49 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:49 --> Total execution time: 0.3353
DEBUG - 2011-07-19 04:58:50 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:50 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:50 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:50 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:50 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:50 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:50 --> Total execution time: 0.0502
DEBUG - 2011-07-19 04:58:50 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:50 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:50 --> Router Class Initialized
ERROR - 2011-07-19 04:58:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:58:55 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:55 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:55 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:55 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:56 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:56 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:56 --> Total execution time: 0.6579
DEBUG - 2011-07-19 04:58:57 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:57 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Router Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Output Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Input Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:58:57 --> Language Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Loader Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Controller Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Model Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:58:57 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:58:57 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:58:57 --> Final output sent to browser
DEBUG - 2011-07-19 04:58:57 --> Total execution time: 0.0562
DEBUG - 2011-07-19 04:58:57 --> Config Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:58:57 --> URI Class Initialized
DEBUG - 2011-07-19 04:58:57 --> Router Class Initialized
ERROR - 2011-07-19 04:58:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:59:05 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:05 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:05 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:05 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:05 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:05 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:05 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:08 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:08 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:08 --> Total execution time: 3.3309
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:08 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:08 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:08 --> Total execution time: 3.6994
DEBUG - 2011-07-19 04:59:10 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:10 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:10 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:10 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:10 --> Router Class Initialized
ERROR - 2011-07-19 04:59:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:59:16 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:16 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:16 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:16 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:16 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:16 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:16 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:16 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:16 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:16 --> Total execution time: 0.0792
DEBUG - 2011-07-19 04:59:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:17 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:17 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:17 --> Total execution time: 0.3637
DEBUG - 2011-07-19 04:59:18 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:18 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:18 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:18 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:18 --> Router Class Initialized
ERROR - 2011-07-19 04:59:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:59:19 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:19 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:19 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:19 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:19 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:19 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:19 --> Total execution time: 0.0905
DEBUG - 2011-07-19 04:59:27 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:27 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:27 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:28 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:28 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:28 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:28 --> Total execution time: 0.3663
DEBUG - 2011-07-19 04:59:29 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:29 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:29 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:29 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:29 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:29 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:29 --> Total execution time: 0.0909
DEBUG - 2011-07-19 04:59:29 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:29 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:29 --> Router Class Initialized
ERROR - 2011-07-19 04:59:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 04:59:39 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:39 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:39 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:39 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:39 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:39 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:39 --> Total execution time: 0.2583
DEBUG - 2011-07-19 04:59:41 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:41 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Router Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Output Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Input Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 04:59:41 --> Language Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Loader Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Controller Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Model Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 04:59:41 --> Database Driver Class Initialized
DEBUG - 2011-07-19 04:59:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 04:59:41 --> Helper loaded: url_helper
DEBUG - 2011-07-19 04:59:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 04:59:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 04:59:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 04:59:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 04:59:41 --> Final output sent to browser
DEBUG - 2011-07-19 04:59:41 --> Total execution time: 0.0776
DEBUG - 2011-07-19 04:59:41 --> Config Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Hooks Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Utf8 Class Initialized
DEBUG - 2011-07-19 04:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 04:59:41 --> URI Class Initialized
DEBUG - 2011-07-19 04:59:41 --> Router Class Initialized
ERROR - 2011-07-19 04:59:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 05:18:06 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:06 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Router Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Output Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Input Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:18:06 --> Language Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Loader Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Controller Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:06 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:18:07 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:18:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:18:07 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:18:07 --> Final output sent to browser
DEBUG - 2011-07-19 05:18:07 --> Total execution time: 0.4998
DEBUG - 2011-07-19 05:18:10 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:10 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Router Class Initialized
ERROR - 2011-07-19 05:18:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 05:18:10 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:10 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Router Class Initialized
ERROR - 2011-07-19 05:18:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 05:18:10 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:10 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:10 --> Router Class Initialized
ERROR - 2011-07-19 05:18:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 05:18:17 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:17 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Router Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Output Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Input Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:18:17 --> Language Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Loader Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Controller Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:18:17 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:18:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:18:18 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:18:18 --> Final output sent to browser
DEBUG - 2011-07-19 05:18:18 --> Total execution time: 0.0758
DEBUG - 2011-07-19 05:18:25 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:25 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Router Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Output Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Input Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:18:25 --> Language Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Loader Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Controller Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:18:25 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:18:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:18:25 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:18:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:18:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:18:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:18:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:18:25 --> Final output sent to browser
DEBUG - 2011-07-19 05:18:25 --> Total execution time: 0.2174
DEBUG - 2011-07-19 05:18:34 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:34 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Router Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Output Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Input Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:18:34 --> Language Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Loader Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Controller Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:18:34 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:18:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:18:34 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:18:34 --> Final output sent to browser
DEBUG - 2011-07-19 05:18:34 --> Total execution time: 0.3664
DEBUG - 2011-07-19 05:18:40 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:40 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Router Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Output Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Input Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:18:40 --> Language Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Loader Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Controller Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:18:40 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:18:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:18:40 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:18:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:18:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:18:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:18:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:18:40 --> Final output sent to browser
DEBUG - 2011-07-19 05:18:40 --> Total execution time: 0.2079
DEBUG - 2011-07-19 05:18:47 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:47 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Router Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Output Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Input Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:18:47 --> Language Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Loader Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Controller Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:18:47 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:18:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:18:47 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:18:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:18:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:18:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:18:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:18:47 --> Final output sent to browser
DEBUG - 2011-07-19 05:18:47 --> Total execution time: 0.3822
DEBUG - 2011-07-19 05:18:54 --> Config Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:18:54 --> URI Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Router Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Output Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Input Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:18:54 --> Language Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Loader Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Controller Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Model Class Initialized
DEBUG - 2011-07-19 05:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:18:54 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:18:54 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:18:54 --> Final output sent to browser
DEBUG - 2011-07-19 05:18:54 --> Total execution time: 0.2223
DEBUG - 2011-07-19 05:19:05 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:05 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:05 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:05 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:05 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:05 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:05 --> Total execution time: 0.7525
DEBUG - 2011-07-19 05:19:16 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:16 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:16 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:16 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:16 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:16 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:16 --> Total execution time: 0.2943
DEBUG - 2011-07-19 05:19:21 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:21 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:21 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:21 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:22 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:22 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:22 --> Total execution time: 0.3073
DEBUG - 2011-07-19 05:19:28 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:28 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:28 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:28 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:28 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:28 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:28 --> Total execution time: 0.0540
DEBUG - 2011-07-19 05:19:28 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:28 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:28 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:28 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:29 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:29 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:29 --> Total execution time: 0.5320
DEBUG - 2011-07-19 05:19:35 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:35 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:35 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:35 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:36 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:36 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:36 --> Total execution time: 1.0549
DEBUG - 2011-07-19 05:19:39 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:39 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:39 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:39 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:39 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:39 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:39 --> Total execution time: 0.0509
DEBUG - 2011-07-19 05:19:43 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:43 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:43 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:43 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:43 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:43 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:43 --> Total execution time: 0.2967
DEBUG - 2011-07-19 05:19:50 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:50 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:50 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:50 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:50 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:50 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:50 --> Total execution time: 0.3801
DEBUG - 2011-07-19 05:19:54 --> Config Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Hooks Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Utf8 Class Initialized
DEBUG - 2011-07-19 05:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 05:19:54 --> URI Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Router Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Output Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Input Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 05:19:54 --> Language Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Loader Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Controller Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Model Class Initialized
DEBUG - 2011-07-19 05:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 05:19:54 --> Database Driver Class Initialized
DEBUG - 2011-07-19 05:19:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 05:19:54 --> Helper loaded: url_helper
DEBUG - 2011-07-19 05:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 05:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 05:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 05:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 05:19:54 --> Final output sent to browser
DEBUG - 2011-07-19 05:19:54 --> Total execution time: 0.0526
DEBUG - 2011-07-19 08:23:53 --> Config Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Hooks Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Utf8 Class Initialized
DEBUG - 2011-07-19 08:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 08:23:53 --> URI Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Router Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Output Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Input Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 08:23:53 --> Language Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Loader Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Controller Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Model Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Model Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Model Class Initialized
DEBUG - 2011-07-19 08:23:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 08:23:53 --> Database Driver Class Initialized
DEBUG - 2011-07-19 08:23:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 08:23:54 --> Helper loaded: url_helper
DEBUG - 2011-07-19 08:23:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 08:23:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 08:23:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 08:23:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 08:23:54 --> Final output sent to browser
DEBUG - 2011-07-19 08:23:54 --> Total execution time: 1.2402
DEBUG - 2011-07-19 08:40:44 --> Config Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Hooks Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Utf8 Class Initialized
DEBUG - 2011-07-19 08:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 08:40:44 --> URI Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Router Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Output Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Input Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 08:40:44 --> Language Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Loader Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Controller Class Initialized
ERROR - 2011-07-19 08:40:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 08:40:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 08:40:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 08:40:44 --> Model Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Model Class Initialized
DEBUG - 2011-07-19 08:40:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 08:40:44 --> Database Driver Class Initialized
DEBUG - 2011-07-19 08:40:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 08:40:44 --> Helper loaded: url_helper
DEBUG - 2011-07-19 08:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 08:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 08:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 08:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 08:40:44 --> Final output sent to browser
DEBUG - 2011-07-19 08:40:44 --> Total execution time: 0.3745
DEBUG - 2011-07-19 08:40:46 --> Config Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Hooks Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Utf8 Class Initialized
DEBUG - 2011-07-19 08:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 08:40:46 --> URI Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Router Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Output Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Input Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 08:40:46 --> Language Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Loader Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Controller Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Model Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Model Class Initialized
DEBUG - 2011-07-19 08:40:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 08:40:46 --> Database Driver Class Initialized
DEBUG - 2011-07-19 08:40:47 --> Final output sent to browser
DEBUG - 2011-07-19 08:40:47 --> Total execution time: 1.5553
DEBUG - 2011-07-19 09:53:00 --> Config Class Initialized
DEBUG - 2011-07-19 09:53:00 --> Config Class Initialized
DEBUG - 2011-07-19 09:53:00 --> Hooks Class Initialized
DEBUG - 2011-07-19 09:53:00 --> Hooks Class Initialized
DEBUG - 2011-07-19 09:53:00 --> Utf8 Class Initialized
DEBUG - 2011-07-19 09:53:00 --> Utf8 Class Initialized
DEBUG - 2011-07-19 09:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 09:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 09:53:01 --> URI Class Initialized
DEBUG - 2011-07-19 09:53:01 --> URI Class Initialized
DEBUG - 2011-07-19 09:53:01 --> Router Class Initialized
DEBUG - 2011-07-19 09:53:01 --> Router Class Initialized
DEBUG - 2011-07-19 09:53:02 --> Output Class Initialized
DEBUG - 2011-07-19 09:53:02 --> Output Class Initialized
DEBUG - 2011-07-19 09:53:02 --> Input Class Initialized
DEBUG - 2011-07-19 09:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 09:53:02 --> Input Class Initialized
DEBUG - 2011-07-19 09:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 09:53:02 --> Language Class Initialized
DEBUG - 2011-07-19 09:53:02 --> Language Class Initialized
DEBUG - 2011-07-19 09:53:02 --> Loader Class Initialized
DEBUG - 2011-07-19 09:53:02 --> Loader Class Initialized
DEBUG - 2011-07-19 09:53:03 --> Controller Class Initialized
DEBUG - 2011-07-19 09:53:03 --> Controller Class Initialized
ERROR - 2011-07-19 09:53:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 09:53:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 09:53:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/snakes/main.php
ERROR - 2011-07-19 09:53:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 09:53:04 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:04 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:04 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:04 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 09:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 09:53:04 --> Database Driver Class Initialized
DEBUG - 2011-07-19 09:53:04 --> Database Driver Class Initialized
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 09:53:04 --> Helper loaded: url_helper
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 09:53:04 --> Helper loaded: url_helper
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 09:53:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 09:53:04 --> Final output sent to browser
DEBUG - 2011-07-19 09:53:04 --> Final output sent to browser
DEBUG - 2011-07-19 09:53:04 --> Total execution time: 5.2853
DEBUG - 2011-07-19 09:53:04 --> Total execution time: 5.2854
DEBUG - 2011-07-19 09:53:06 --> Config Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Hooks Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Utf8 Class Initialized
DEBUG - 2011-07-19 09:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 09:53:06 --> URI Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Router Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Output Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Input Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 09:53:06 --> Language Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Loader Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Controller Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 09:53:06 --> Database Driver Class Initialized
DEBUG - 2011-07-19 09:53:07 --> Final output sent to browser
DEBUG - 2011-07-19 09:53:07 --> Total execution time: 1.2555
DEBUG - 2011-07-19 09:53:08 --> Config Class Initialized
DEBUG - 2011-07-19 09:53:08 --> Hooks Class Initialized
DEBUG - 2011-07-19 09:53:08 --> Utf8 Class Initialized
DEBUG - 2011-07-19 09:53:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 09:53:08 --> URI Class Initialized
DEBUG - 2011-07-19 09:53:08 --> Router Class Initialized
ERROR - 2011-07-19 09:53:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 09:53:38 --> Config Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Hooks Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Utf8 Class Initialized
DEBUG - 2011-07-19 09:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 09:53:38 --> URI Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Router Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Output Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Input Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 09:53:38 --> Language Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Loader Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Controller Class Initialized
ERROR - 2011-07-19 09:53:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 09:53:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 09:53:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 09:53:38 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 09:53:38 --> Database Driver Class Initialized
DEBUG - 2011-07-19 09:53:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 09:53:38 --> Helper loaded: url_helper
DEBUG - 2011-07-19 09:53:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 09:53:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 09:53:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 09:53:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 09:53:38 --> Final output sent to browser
DEBUG - 2011-07-19 09:53:38 --> Total execution time: 0.0631
DEBUG - 2011-07-19 09:53:39 --> Config Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Hooks Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Utf8 Class Initialized
DEBUG - 2011-07-19 09:53:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 09:53:39 --> URI Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Router Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Output Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Input Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 09:53:39 --> Language Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Loader Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Controller Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 09:53:39 --> Database Driver Class Initialized
DEBUG - 2011-07-19 09:53:40 --> Final output sent to browser
DEBUG - 2011-07-19 09:53:40 --> Total execution time: 0.7316
DEBUG - 2011-07-19 09:53:59 --> Config Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Hooks Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Utf8 Class Initialized
DEBUG - 2011-07-19 09:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 09:53:59 --> URI Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Router Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Output Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Input Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 09:53:59 --> Language Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Loader Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Controller Class Initialized
ERROR - 2011-07-19 09:53:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 09:53:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 09:53:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 09:53:59 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Model Class Initialized
DEBUG - 2011-07-19 09:53:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 09:53:59 --> Database Driver Class Initialized
DEBUG - 2011-07-19 09:53:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 09:53:59 --> Helper loaded: url_helper
DEBUG - 2011-07-19 09:53:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 09:53:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 09:53:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 09:53:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 09:53:59 --> Final output sent to browser
DEBUG - 2011-07-19 09:53:59 --> Total execution time: 0.1153
DEBUG - 2011-07-19 09:54:00 --> Config Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Hooks Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Utf8 Class Initialized
DEBUG - 2011-07-19 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 09:54:00 --> URI Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Router Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Output Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Input Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 09:54:00 --> Language Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Loader Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Controller Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Model Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Model Class Initialized
DEBUG - 2011-07-19 09:54:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 09:54:00 --> Database Driver Class Initialized
DEBUG - 2011-07-19 09:54:01 --> Final output sent to browser
DEBUG - 2011-07-19 09:54:01 --> Total execution time: 0.8465
DEBUG - 2011-07-19 15:17:14 --> Config Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:17:14 --> URI Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Router Class Initialized
ERROR - 2011-07-19 15:17:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-19 15:17:14 --> Config Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:17:14 --> URI Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Router Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Output Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Input Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:17:14 --> Language Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Loader Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Controller Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Model Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Model Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Model Class Initialized
DEBUG - 2011-07-19 15:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:17:14 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:17:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 15:17:16 --> Helper loaded: url_helper
DEBUG - 2011-07-19 15:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 15:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 15:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 15:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 15:17:16 --> Final output sent to browser
DEBUG - 2011-07-19 15:17:16 --> Total execution time: 1.3370
DEBUG - 2011-07-19 15:53:50 --> Config Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:53:50 --> URI Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Router Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Output Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Input Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:53:50 --> Language Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Loader Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Controller Class Initialized
ERROR - 2011-07-19 15:53:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 15:53:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 15:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 15:53:50 --> Model Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Model Class Initialized
DEBUG - 2011-07-19 15:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:53:50 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 15:53:51 --> Helper loaded: url_helper
DEBUG - 2011-07-19 15:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 15:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 15:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 15:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 15:53:51 --> Final output sent to browser
DEBUG - 2011-07-19 15:53:51 --> Total execution time: 0.3570
DEBUG - 2011-07-19 15:53:52 --> Config Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:53:52 --> URI Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Router Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Output Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Input Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:53:52 --> Language Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Loader Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Controller Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Model Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Model Class Initialized
DEBUG - 2011-07-19 15:53:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:53:52 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:53:53 --> Final output sent to browser
DEBUG - 2011-07-19 15:53:53 --> Total execution time: 0.7645
DEBUG - 2011-07-19 15:53:54 --> Config Class Initialized
DEBUG - 2011-07-19 15:53:54 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:53:54 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:53:54 --> URI Class Initialized
DEBUG - 2011-07-19 15:53:54 --> Router Class Initialized
ERROR - 2011-07-19 15:53:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 15:54:12 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:12 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Router Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Output Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Input Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:54:12 --> Language Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Loader Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Controller Class Initialized
ERROR - 2011-07-19 15:54:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 15:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 15:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 15:54:12 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:54:12 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 15:54:12 --> Helper loaded: url_helper
DEBUG - 2011-07-19 15:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 15:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 15:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 15:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 15:54:12 --> Final output sent to browser
DEBUG - 2011-07-19 15:54:12 --> Total execution time: 0.0663
DEBUG - 2011-07-19 15:54:13 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:13 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Router Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Output Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Input Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:54:13 --> Language Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Loader Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Controller Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:54:13 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:54:13 --> Final output sent to browser
DEBUG - 2011-07-19 15:54:13 --> Total execution time: 0.7193
DEBUG - 2011-07-19 15:54:14 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:14 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:14 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:14 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:14 --> Router Class Initialized
ERROR - 2011-07-19 15:54:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 15:54:24 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:24 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Router Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Output Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Input Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:54:24 --> Language Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Loader Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Controller Class Initialized
ERROR - 2011-07-19 15:54:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 15:54:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 15:54:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 15:54:24 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:54:24 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:54:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 15:54:24 --> Helper loaded: url_helper
DEBUG - 2011-07-19 15:54:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 15:54:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 15:54:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 15:54:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 15:54:24 --> Final output sent to browser
DEBUG - 2011-07-19 15:54:24 --> Total execution time: 0.0282
DEBUG - 2011-07-19 15:54:25 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:25 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Router Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Output Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Input Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:54:25 --> Language Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Loader Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Controller Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:54:25 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:54:26 --> Final output sent to browser
DEBUG - 2011-07-19 15:54:26 --> Total execution time: 0.7173
DEBUG - 2011-07-19 15:54:27 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:27 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:27 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:27 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:27 --> Router Class Initialized
ERROR - 2011-07-19 15:54:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 15:54:37 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:37 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Router Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Output Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Input Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:54:37 --> Language Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Loader Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Controller Class Initialized
ERROR - 2011-07-19 15:54:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 15:54:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 15:54:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 15:54:37 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:54:37 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:54:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 15:54:37 --> Helper loaded: url_helper
DEBUG - 2011-07-19 15:54:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 15:54:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 15:54:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 15:54:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 15:54:37 --> Final output sent to browser
DEBUG - 2011-07-19 15:54:37 --> Total execution time: 0.0285
DEBUG - 2011-07-19 15:54:38 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:38 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Router Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Output Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Input Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 15:54:38 --> Language Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Loader Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Controller Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Model Class Initialized
DEBUG - 2011-07-19 15:54:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 15:54:38 --> Database Driver Class Initialized
DEBUG - 2011-07-19 15:54:39 --> Final output sent to browser
DEBUG - 2011-07-19 15:54:39 --> Total execution time: 0.9173
DEBUG - 2011-07-19 15:54:40 --> Config Class Initialized
DEBUG - 2011-07-19 15:54:40 --> Hooks Class Initialized
DEBUG - 2011-07-19 15:54:40 --> Utf8 Class Initialized
DEBUG - 2011-07-19 15:54:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 15:54:40 --> URI Class Initialized
DEBUG - 2011-07-19 15:54:40 --> Router Class Initialized
ERROR - 2011-07-19 15:54:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 17:39:17 --> Config Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Hooks Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Utf8 Class Initialized
DEBUG - 2011-07-19 17:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 17:39:17 --> URI Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Router Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Output Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Input Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 17:39:17 --> Language Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Loader Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Controller Class Initialized
ERROR - 2011-07-19 17:39:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 17:39:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 17:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 17:39:17 --> Model Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Model Class Initialized
DEBUG - 2011-07-19 17:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 17:39:17 --> Database Driver Class Initialized
DEBUG - 2011-07-19 17:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 17:39:17 --> Helper loaded: url_helper
DEBUG - 2011-07-19 17:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 17:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 17:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 17:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 17:39:17 --> Final output sent to browser
DEBUG - 2011-07-19 17:39:17 --> Total execution time: 0.3816
DEBUG - 2011-07-19 17:39:19 --> Config Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Hooks Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Utf8 Class Initialized
DEBUG - 2011-07-19 17:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 17:39:19 --> URI Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Router Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Output Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Input Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 17:39:19 --> Language Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Loader Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Controller Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Model Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Model Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 17:39:19 --> Database Driver Class Initialized
DEBUG - 2011-07-19 17:39:19 --> Final output sent to browser
DEBUG - 2011-07-19 17:39:19 --> Total execution time: 0.7898
DEBUG - 2011-07-19 17:39:20 --> Config Class Initialized
DEBUG - 2011-07-19 17:39:20 --> Hooks Class Initialized
DEBUG - 2011-07-19 17:39:20 --> Utf8 Class Initialized
DEBUG - 2011-07-19 17:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 17:39:20 --> URI Class Initialized
DEBUG - 2011-07-19 17:39:20 --> Router Class Initialized
ERROR - 2011-07-19 17:39:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-19 19:33:40 --> Config Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Hooks Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Utf8 Class Initialized
DEBUG - 2011-07-19 19:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 19:33:40 --> URI Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Router Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Output Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Input Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 19:33:40 --> Language Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Loader Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Controller Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Model Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Model Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Model Class Initialized
DEBUG - 2011-07-19 19:33:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 19:33:40 --> Database Driver Class Initialized
DEBUG - 2011-07-19 19:33:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-19 19:33:41 --> Helper loaded: url_helper
DEBUG - 2011-07-19 19:33:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 19:33:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 19:33:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 19:33:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 19:33:41 --> Final output sent to browser
DEBUG - 2011-07-19 19:33:41 --> Total execution time: 1.2536
DEBUG - 2011-07-19 19:33:46 --> Config Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Hooks Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Utf8 Class Initialized
DEBUG - 2011-07-19 19:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 19:33:46 --> URI Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Router Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Output Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Input Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 19:33:46 --> Language Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Loader Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Controller Class Initialized
ERROR - 2011-07-19 19:33:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-19 19:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-19 19:33:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 19:33:46 --> Model Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Model Class Initialized
DEBUG - 2011-07-19 19:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-19 19:33:46 --> Database Driver Class Initialized
DEBUG - 2011-07-19 19:33:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-19 19:33:46 --> Helper loaded: url_helper
DEBUG - 2011-07-19 19:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 19:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 19:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 19:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 19:33:46 --> Final output sent to browser
DEBUG - 2011-07-19 19:33:46 --> Total execution time: 0.1439
DEBUG - 2011-07-19 23:12:45 --> Config Class Initialized
DEBUG - 2011-07-19 23:12:45 --> Hooks Class Initialized
DEBUG - 2011-07-19 23:12:45 --> Utf8 Class Initialized
DEBUG - 2011-07-19 23:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-19 23:12:45 --> URI Class Initialized
DEBUG - 2011-07-19 23:12:45 --> Router Class Initialized
DEBUG - 2011-07-19 23:12:45 --> No URI present. Default controller set.
DEBUG - 2011-07-19 23:12:45 --> Output Class Initialized
DEBUG - 2011-07-19 23:12:45 --> Input Class Initialized
DEBUG - 2011-07-19 23:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-19 23:12:45 --> Language Class Initialized
DEBUG - 2011-07-19 23:12:45 --> Loader Class Initialized
DEBUG - 2011-07-19 23:12:45 --> Controller Class Initialized
DEBUG - 2011-07-19 23:12:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-19 23:12:45 --> Helper loaded: url_helper
DEBUG - 2011-07-19 23:12:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-19 23:12:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-19 23:12:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-19 23:12:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-19 23:12:45 --> Final output sent to browser
DEBUG - 2011-07-19 23:12:45 --> Total execution time: 0.6392

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-12 00:03:06 --> Config Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:03:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:03:06 --> URI Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Router Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Output Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Input Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:03:06 --> Language Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Loader Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Controller Class Initialized
ERROR - 2011-07-12 00:03:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 00:03:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 00:03:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 00:03:06 --> Model Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Model Class Initialized
DEBUG - 2011-07-12 00:03:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:03:06 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:03:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 00:03:06 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:03:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:03:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:03:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:03:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:03:06 --> Final output sent to browser
DEBUG - 2011-07-12 00:03:06 --> Total execution time: 0.1671
DEBUG - 2011-07-12 00:03:18 --> Config Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:03:18 --> URI Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Router Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Output Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Input Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:03:18 --> Language Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Loader Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Controller Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Model Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Model Class Initialized
DEBUG - 2011-07-12 00:03:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:03:18 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:03:19 --> Final output sent to browser
DEBUG - 2011-07-12 00:03:19 --> Total execution time: 0.6495
DEBUG - 2011-07-12 00:03:27 --> Config Class Initialized
DEBUG - 2011-07-12 00:03:27 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:03:27 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:03:27 --> URI Class Initialized
DEBUG - 2011-07-12 00:03:27 --> Router Class Initialized
ERROR - 2011-07-12 00:03:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 00:33:27 --> Config Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:33:27 --> URI Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Router Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Output Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Input Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:33:27 --> Language Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Loader Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Controller Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:33:27 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:33:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:33:28 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:33:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:33:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:33:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:33:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:33:28 --> Final output sent to browser
DEBUG - 2011-07-12 00:33:28 --> Total execution time: 0.3598
DEBUG - 2011-07-12 00:33:32 --> Config Class Initialized
DEBUG - 2011-07-12 00:33:32 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:33:32 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:33:32 --> URI Class Initialized
DEBUG - 2011-07-12 00:33:32 --> Router Class Initialized
ERROR - 2011-07-12 00:33:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 00:33:43 --> Config Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:33:43 --> URI Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Router Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Output Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Input Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:33:43 --> Language Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Loader Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Controller Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:33:43 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:33:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:33:43 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:33:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:33:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:33:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:33:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:33:43 --> Final output sent to browser
DEBUG - 2011-07-12 00:33:43 --> Total execution time: 0.0745
DEBUG - 2011-07-12 00:33:55 --> Config Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:33:55 --> URI Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Router Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Output Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Input Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:33:55 --> Language Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Loader Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Controller Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:33:55 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:33:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:33:55 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:33:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:33:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:33:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:33:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:33:55 --> Final output sent to browser
DEBUG - 2011-07-12 00:33:55 --> Total execution time: 0.4199
DEBUG - 2011-07-12 00:33:57 --> Config Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:33:57 --> URI Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Router Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Output Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Input Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:33:57 --> Language Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Loader Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Controller Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Model Class Initialized
DEBUG - 2011-07-12 00:33:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:33:57 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:33:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:33:57 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:33:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:33:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:33:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:33:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:33:57 --> Final output sent to browser
DEBUG - 2011-07-12 00:33:57 --> Total execution time: 0.0818
DEBUG - 2011-07-12 00:34:09 --> Config Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:34:09 --> URI Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Router Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Output Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Input Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:34:09 --> Language Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Loader Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Controller Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:34:09 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:34:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:34:10 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:34:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:34:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:34:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:34:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:34:10 --> Final output sent to browser
DEBUG - 2011-07-12 00:34:10 --> Total execution time: 0.2111
DEBUG - 2011-07-12 00:34:11 --> Config Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:34:11 --> URI Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Router Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Output Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Input Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:34:11 --> Language Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Loader Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Controller Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:34:11 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:34:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:34:11 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:34:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:34:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:34:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:34:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:34:11 --> Final output sent to browser
DEBUG - 2011-07-12 00:34:11 --> Total execution time: 0.0430
DEBUG - 2011-07-12 00:34:12 --> Config Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:34:12 --> URI Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Router Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Output Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Input Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:34:12 --> Language Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Loader Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Controller Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:34:12 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:34:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:34:12 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:34:12 --> Final output sent to browser
DEBUG - 2011-07-12 00:34:12 --> Total execution time: 0.0626
DEBUG - 2011-07-12 00:34:25 --> Config Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:34:25 --> URI Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Router Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Output Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Input Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:34:25 --> Language Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Loader Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Controller Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:34:25 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:34:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:34:26 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:34:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:34:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:34:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:34:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:34:26 --> Final output sent to browser
DEBUG - 2011-07-12 00:34:26 --> Total execution time: 0.9124
DEBUG - 2011-07-12 00:34:33 --> Config Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:34:33 --> URI Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Router Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Output Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Input Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:34:33 --> Language Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Loader Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Controller Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:34:33 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:34:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:34:33 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:34:33 --> Final output sent to browser
DEBUG - 2011-07-12 00:34:33 --> Total execution time: 0.0836
DEBUG - 2011-07-12 00:34:36 --> Config Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:34:36 --> URI Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Router Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Output Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Input Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:34:36 --> Language Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Loader Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Controller Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:34:36 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:34:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:34:37 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:34:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:34:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:34:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:34:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:34:37 --> Final output sent to browser
DEBUG - 2011-07-12 00:34:37 --> Total execution time: 0.4354
DEBUG - 2011-07-12 00:34:38 --> Config Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:34:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:34:38 --> URI Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Router Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Output Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Input Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:34:38 --> Language Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Loader Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Controller Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Model Class Initialized
DEBUG - 2011-07-12 00:34:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:34:38 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:34:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:34:38 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:34:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:34:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:34:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:34:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:34:38 --> Final output sent to browser
DEBUG - 2011-07-12 00:34:38 --> Total execution time: 0.1150
DEBUG - 2011-07-12 00:35:12 --> Config Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:35:12 --> URI Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Router Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Output Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Input Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:35:12 --> Language Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Loader Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Controller Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:35:12 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:35:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:35:12 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:35:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:35:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:35:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:35:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:35:12 --> Final output sent to browser
DEBUG - 2011-07-12 00:35:12 --> Total execution time: 0.2972
DEBUG - 2011-07-12 00:35:14 --> Config Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:35:14 --> URI Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Router Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Output Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Input Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:35:14 --> Language Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Loader Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Controller Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:35:14 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:35:14 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:35:14 --> Final output sent to browser
DEBUG - 2011-07-12 00:35:14 --> Total execution time: 0.0466
DEBUG - 2011-07-12 00:35:14 --> Config Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:35:14 --> URI Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Router Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Output Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Input Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:35:14 --> Language Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Loader Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Controller Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:35:14 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:35:14 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:35:14 --> Final output sent to browser
DEBUG - 2011-07-12 00:35:14 --> Total execution time: 0.0432
DEBUG - 2011-07-12 00:35:40 --> Config Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:35:40 --> URI Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Router Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Output Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Input Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:35:40 --> Language Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Loader Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Controller Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:35:40 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:35:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:35:40 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:35:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:35:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:35:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:35:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:35:40 --> Final output sent to browser
DEBUG - 2011-07-12 00:35:40 --> Total execution time: 0.5980
DEBUG - 2011-07-12 00:35:42 --> Config Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:35:42 --> URI Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Router Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Output Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Input Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:35:42 --> Language Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Loader Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Controller Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Model Class Initialized
DEBUG - 2011-07-12 00:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:35:42 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:35:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:35:42 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:35:42 --> Final output sent to browser
DEBUG - 2011-07-12 00:35:42 --> Total execution time: 0.0760
DEBUG - 2011-07-12 00:36:03 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:03 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:03 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:03 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:04 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:04 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:04 --> Total execution time: 0.4523
DEBUG - 2011-07-12 00:36:05 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:05 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:05 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:05 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:05 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:05 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:05 --> Total execution time: 0.0650
DEBUG - 2011-07-12 00:36:25 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:25 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:25 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:25 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:25 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:25 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:25 --> Total execution time: 0.2345
DEBUG - 2011-07-12 00:36:28 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:28 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Router Class Initialized
ERROR - 2011-07-12 00:36:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 00:36:28 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:28 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:28 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:28 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:28 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:28 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:28 --> Total execution time: 0.0411
DEBUG - 2011-07-12 00:36:38 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:38 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:38 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:38 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:38 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:38 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:38 --> Total execution time: 0.2309
DEBUG - 2011-07-12 00:36:39 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:39 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:39 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:39 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:39 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:39 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:39 --> Total execution time: 0.0433
DEBUG - 2011-07-12 00:36:48 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:48 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:48 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:48 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:48 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:48 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:48 --> Total execution time: 0.2065
DEBUG - 2011-07-12 00:36:49 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:49 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:49 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:49 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:49 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:49 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:49 --> Total execution time: 0.0443
DEBUG - 2011-07-12 00:36:58 --> Config Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:36:58 --> URI Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Router Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Output Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Input Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:36:58 --> Language Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Loader Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Controller Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Model Class Initialized
DEBUG - 2011-07-12 00:36:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:36:58 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:36:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:36:58 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:36:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:36:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:36:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:36:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:36:58 --> Final output sent to browser
DEBUG - 2011-07-12 00:36:58 --> Total execution time: 0.6338
DEBUG - 2011-07-12 00:37:00 --> Config Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:37:00 --> URI Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Router Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Output Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Input Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:37:00 --> Language Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Loader Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Controller Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:37:00 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:37:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:37:00 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:37:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:37:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:37:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:37:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:37:00 --> Final output sent to browser
DEBUG - 2011-07-12 00:37:00 --> Total execution time: 0.0767
DEBUG - 2011-07-12 00:37:07 --> Config Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:37:07 --> URI Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Router Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Output Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Input Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:37:07 --> Language Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Loader Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Controller Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:37:07 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:37:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:37:07 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:37:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:37:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:37:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:37:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:37:07 --> Final output sent to browser
DEBUG - 2011-07-12 00:37:07 --> Total execution time: 0.2233
DEBUG - 2011-07-12 00:37:08 --> Config Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:37:08 --> URI Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Router Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Output Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Input Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:37:08 --> Language Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Loader Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Controller Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:37:08 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:37:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:37:08 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:37:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:37:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:37:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:37:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:37:08 --> Final output sent to browser
DEBUG - 2011-07-12 00:37:08 --> Total execution time: 0.0456
DEBUG - 2011-07-12 00:37:25 --> Config Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:37:25 --> URI Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Router Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Output Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Input Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:37:25 --> Language Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Loader Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Controller Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:37:25 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:37:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:37:25 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:37:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:37:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:37:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:37:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:37:25 --> Final output sent to browser
DEBUG - 2011-07-12 00:37:25 --> Total execution time: 0.2006
DEBUG - 2011-07-12 00:37:26 --> Config Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Hooks Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Utf8 Class Initialized
DEBUG - 2011-07-12 00:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 00:37:26 --> URI Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Router Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Output Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Input Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 00:37:26 --> Language Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Loader Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Controller Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Model Class Initialized
DEBUG - 2011-07-12 00:37:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 00:37:26 --> Database Driver Class Initialized
DEBUG - 2011-07-12 00:37:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 00:37:26 --> Helper loaded: url_helper
DEBUG - 2011-07-12 00:37:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 00:37:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 00:37:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 00:37:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 00:37:26 --> Final output sent to browser
DEBUG - 2011-07-12 00:37:26 --> Total execution time: 0.0446
DEBUG - 2011-07-12 03:35:13 --> Config Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Hooks Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Utf8 Class Initialized
DEBUG - 2011-07-12 03:35:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 03:35:13 --> URI Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Router Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Output Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Input Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 03:35:13 --> Language Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Loader Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Controller Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Model Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Model Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Model Class Initialized
DEBUG - 2011-07-12 03:35:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 03:35:13 --> Database Driver Class Initialized
DEBUG - 2011-07-12 03:35:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 03:35:14 --> Helper loaded: url_helper
DEBUG - 2011-07-12 03:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 03:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 03:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 03:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 03:35:14 --> Final output sent to browser
DEBUG - 2011-07-12 03:35:14 --> Total execution time: 1.6302
DEBUG - 2011-07-12 03:35:15 --> Config Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Hooks Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Utf8 Class Initialized
DEBUG - 2011-07-12 03:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 03:35:15 --> URI Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Router Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Output Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Input Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 03:35:15 --> Language Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Loader Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Controller Class Initialized
ERROR - 2011-07-12 03:35:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 03:35:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 03:35:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 03:35:15 --> Model Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Model Class Initialized
DEBUG - 2011-07-12 03:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 03:35:15 --> Database Driver Class Initialized
DEBUG - 2011-07-12 03:35:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 03:35:15 --> Helper loaded: url_helper
DEBUG - 2011-07-12 03:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 03:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 03:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 03:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 03:35:15 --> Final output sent to browser
DEBUG - 2011-07-12 03:35:15 --> Total execution time: 0.7051
DEBUG - 2011-07-12 05:22:02 --> Config Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Hooks Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Utf8 Class Initialized
DEBUG - 2011-07-12 05:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 05:22:02 --> URI Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Router Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Output Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Input Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 05:22:02 --> Language Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Loader Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Controller Class Initialized
ERROR - 2011-07-12 05:22:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 05:22:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 05:22:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 05:22:02 --> Model Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Model Class Initialized
DEBUG - 2011-07-12 05:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 05:22:02 --> Database Driver Class Initialized
DEBUG - 2011-07-12 05:22:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 05:22:03 --> Helper loaded: url_helper
DEBUG - 2011-07-12 05:22:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 05:22:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 05:22:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 05:22:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 05:22:03 --> Final output sent to browser
DEBUG - 2011-07-12 05:22:03 --> Total execution time: 0.3555
DEBUG - 2011-07-12 05:22:04 --> Config Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Hooks Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Utf8 Class Initialized
DEBUG - 2011-07-12 05:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 05:22:04 --> URI Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Router Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Output Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Input Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 05:22:04 --> Language Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Loader Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Controller Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Model Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Model Class Initialized
DEBUG - 2011-07-12 05:22:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 05:22:04 --> Database Driver Class Initialized
DEBUG - 2011-07-12 05:22:05 --> Final output sent to browser
DEBUG - 2011-07-12 05:22:05 --> Total execution time: 1.0450
DEBUG - 2011-07-12 09:04:49 --> Config Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Hooks Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Utf8 Class Initialized
DEBUG - 2011-07-12 09:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 09:04:49 --> URI Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Router Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Output Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Input Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 09:04:49 --> Language Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Loader Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Controller Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Model Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Model Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Model Class Initialized
DEBUG - 2011-07-12 09:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 09:04:49 --> Database Driver Class Initialized
DEBUG - 2011-07-12 09:04:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 09:04:50 --> Helper loaded: url_helper
DEBUG - 2011-07-12 09:04:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 09:04:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 09:04:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 09:04:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 09:04:50 --> Final output sent to browser
DEBUG - 2011-07-12 09:04:50 --> Total execution time: 0.7408
DEBUG - 2011-07-12 09:05:20 --> Config Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Hooks Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Utf8 Class Initialized
DEBUG - 2011-07-12 09:05:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 09:05:20 --> URI Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Router Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Output Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Input Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 09:05:20 --> Language Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Loader Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Controller Class Initialized
ERROR - 2011-07-12 09:05:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 09:05:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 09:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 09:05:20 --> Model Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Model Class Initialized
DEBUG - 2011-07-12 09:05:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 09:05:20 --> Database Driver Class Initialized
DEBUG - 2011-07-12 09:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 09:05:20 --> Helper loaded: url_helper
DEBUG - 2011-07-12 09:05:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 09:05:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 09:05:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 09:05:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 09:05:20 --> Final output sent to browser
DEBUG - 2011-07-12 09:05:20 --> Total execution time: 0.2437
DEBUG - 2011-07-12 09:50:14 --> Config Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Hooks Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Utf8 Class Initialized
DEBUG - 2011-07-12 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 09:50:14 --> URI Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Router Class Initialized
ERROR - 2011-07-12 09:50:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-12 09:50:14 --> Config Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Hooks Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Utf8 Class Initialized
DEBUG - 2011-07-12 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 09:50:14 --> URI Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Router Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Output Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Input Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 09:50:14 --> Language Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Loader Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Controller Class Initialized
ERROR - 2011-07-12 09:50:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 09:50:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 09:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 09:50:14 --> Model Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Model Class Initialized
DEBUG - 2011-07-12 09:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 09:50:14 --> Database Driver Class Initialized
DEBUG - 2011-07-12 09:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 09:50:14 --> Helper loaded: url_helper
DEBUG - 2011-07-12 09:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 09:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 09:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 09:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 09:50:14 --> Final output sent to browser
DEBUG - 2011-07-12 09:50:14 --> Total execution time: 0.5010
DEBUG - 2011-07-12 12:37:29 --> Config Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Hooks Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Utf8 Class Initialized
DEBUG - 2011-07-12 12:37:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 12:37:29 --> URI Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Router Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Output Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Input Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 12:37:29 --> Language Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Loader Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Controller Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Model Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Model Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Model Class Initialized
DEBUG - 2011-07-12 12:37:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 12:37:29 --> Database Driver Class Initialized
DEBUG - 2011-07-12 12:37:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 12:37:30 --> Helper loaded: url_helper
DEBUG - 2011-07-12 12:37:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 12:37:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 12:37:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 12:37:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 12:37:30 --> Final output sent to browser
DEBUG - 2011-07-12 12:37:30 --> Total execution time: 0.5677
DEBUG - 2011-07-12 12:37:32 --> Config Class Initialized
DEBUG - 2011-07-12 12:37:32 --> Hooks Class Initialized
DEBUG - 2011-07-12 12:37:32 --> Utf8 Class Initialized
DEBUG - 2011-07-12 12:37:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 12:37:32 --> URI Class Initialized
DEBUG - 2011-07-12 12:37:32 --> Router Class Initialized
ERROR - 2011-07-12 12:37:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 12:37:45 --> Config Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Hooks Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Utf8 Class Initialized
DEBUG - 2011-07-12 12:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 12:37:45 --> URI Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Router Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Output Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Input Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 12:37:45 --> Language Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Loader Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Controller Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Model Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Model Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Model Class Initialized
DEBUG - 2011-07-12 12:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 12:37:45 --> Database Driver Class Initialized
DEBUG - 2011-07-12 12:37:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 12:37:45 --> Helper loaded: url_helper
DEBUG - 2011-07-12 12:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 12:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 12:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 12:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 12:37:45 --> Final output sent to browser
DEBUG - 2011-07-12 12:37:45 --> Total execution time: 0.0935
DEBUG - 2011-07-12 12:38:04 --> Config Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Hooks Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Utf8 Class Initialized
DEBUG - 2011-07-12 12:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 12:38:04 --> URI Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Router Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Output Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Input Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 12:38:04 --> Language Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Loader Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Controller Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Model Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Model Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Model Class Initialized
DEBUG - 2011-07-12 12:38:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 12:38:04 --> Database Driver Class Initialized
DEBUG - 2011-07-12 12:38:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 12:38:04 --> Helper loaded: url_helper
DEBUG - 2011-07-12 12:38:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 12:38:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 12:38:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 12:38:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 12:38:04 --> Final output sent to browser
DEBUG - 2011-07-12 12:38:04 --> Total execution time: 0.0601
DEBUG - 2011-07-12 13:35:39 --> Config Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Hooks Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Utf8 Class Initialized
DEBUG - 2011-07-12 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 13:35:39 --> URI Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Router Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Output Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Input Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 13:35:39 --> Language Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Loader Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Controller Class Initialized
ERROR - 2011-07-12 13:35:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 13:35:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 13:35:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 13:35:39 --> Model Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Model Class Initialized
DEBUG - 2011-07-12 13:35:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 13:35:39 --> Database Driver Class Initialized
DEBUG - 2011-07-12 13:35:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 13:35:39 --> Helper loaded: url_helper
DEBUG - 2011-07-12 13:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 13:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 13:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 13:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 13:35:39 --> Final output sent to browser
DEBUG - 2011-07-12 13:35:39 --> Total execution time: 0.3923
DEBUG - 2011-07-12 14:28:29 --> Config Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Hooks Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Utf8 Class Initialized
DEBUG - 2011-07-12 14:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 14:28:29 --> URI Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Router Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Output Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Input Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 14:28:29 --> Language Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Loader Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Controller Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Model Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Model Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Model Class Initialized
DEBUG - 2011-07-12 14:28:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 14:28:29 --> Database Driver Class Initialized
DEBUG - 2011-07-12 14:28:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 14:28:30 --> Helper loaded: url_helper
DEBUG - 2011-07-12 14:28:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 14:28:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 14:28:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 14:28:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 14:28:30 --> Final output sent to browser
DEBUG - 2011-07-12 14:28:30 --> Total execution time: 1.3880
DEBUG - 2011-07-12 14:28:31 --> Config Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Hooks Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Utf8 Class Initialized
DEBUG - 2011-07-12 14:28:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 14:28:31 --> URI Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Router Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Output Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Input Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 14:28:31 --> Language Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Loader Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Controller Class Initialized
ERROR - 2011-07-12 14:28:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 14:28:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 14:28:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 14:28:31 --> Model Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Model Class Initialized
DEBUG - 2011-07-12 14:28:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 14:28:31 --> Database Driver Class Initialized
DEBUG - 2011-07-12 14:28:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 14:28:31 --> Helper loaded: url_helper
DEBUG - 2011-07-12 14:28:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 14:28:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 14:28:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 14:28:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 14:28:31 --> Final output sent to browser
DEBUG - 2011-07-12 14:28:31 --> Total execution time: 0.0971
DEBUG - 2011-07-12 14:55:04 --> Config Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Hooks Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Utf8 Class Initialized
DEBUG - 2011-07-12 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 14:55:04 --> URI Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Router Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Output Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Input Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 14:55:04 --> Language Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Loader Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Controller Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Model Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Model Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Model Class Initialized
DEBUG - 2011-07-12 14:55:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 14:55:04 --> Database Driver Class Initialized
DEBUG - 2011-07-12 14:55:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 14:55:04 --> Helper loaded: url_helper
DEBUG - 2011-07-12 14:55:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 14:55:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 14:55:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 14:55:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 14:55:04 --> Final output sent to browser
DEBUG - 2011-07-12 14:55:04 --> Total execution time: 0.4128
DEBUG - 2011-07-12 14:55:05 --> Config Class Initialized
DEBUG - 2011-07-12 14:55:05 --> Hooks Class Initialized
DEBUG - 2011-07-12 14:55:05 --> Utf8 Class Initialized
DEBUG - 2011-07-12 14:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 14:55:05 --> URI Class Initialized
DEBUG - 2011-07-12 14:55:05 --> Router Class Initialized
DEBUG - 2011-07-12 14:55:05 --> Output Class Initialized
DEBUG - 2011-07-12 14:55:05 --> Input Class Initialized
DEBUG - 2011-07-12 14:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 14:55:05 --> Language Class Initialized
DEBUG - 2011-07-12 14:55:05 --> Loader Class Initialized
DEBUG - 2011-07-12 14:55:05 --> Controller Class Initialized
ERROR - 2011-07-12 14:55:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 14:55:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 14:55:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 14:55:06 --> Model Class Initialized
DEBUG - 2011-07-12 14:55:06 --> Model Class Initialized
DEBUG - 2011-07-12 14:55:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 14:55:06 --> Database Driver Class Initialized
DEBUG - 2011-07-12 14:55:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 14:55:06 --> Helper loaded: url_helper
DEBUG - 2011-07-12 14:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 14:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 14:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 14:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 14:55:06 --> Final output sent to browser
DEBUG - 2011-07-12 14:55:06 --> Total execution time: 0.0755
DEBUG - 2011-07-12 15:25:43 --> Config Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Hooks Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Utf8 Class Initialized
DEBUG - 2011-07-12 15:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 15:25:43 --> URI Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Router Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Output Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Input Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 15:25:43 --> Language Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Loader Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Controller Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Model Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Model Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Model Class Initialized
DEBUG - 2011-07-12 15:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 15:25:43 --> Database Driver Class Initialized
DEBUG - 2011-07-12 15:25:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 15:25:43 --> Helper loaded: url_helper
DEBUG - 2011-07-12 15:25:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 15:25:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 15:25:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 15:25:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 15:25:43 --> Final output sent to browser
DEBUG - 2011-07-12 15:25:43 --> Total execution time: 0.7901
DEBUG - 2011-07-12 15:25:44 --> Config Class Initialized
DEBUG - 2011-07-12 15:25:44 --> Hooks Class Initialized
DEBUG - 2011-07-12 15:25:44 --> Utf8 Class Initialized
DEBUG - 2011-07-12 15:25:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 15:25:44 --> URI Class Initialized
DEBUG - 2011-07-12 15:25:44 --> Router Class Initialized
DEBUG - 2011-07-12 15:25:44 --> No URI present. Default controller set.
DEBUG - 2011-07-12 15:25:44 --> Output Class Initialized
DEBUG - 2011-07-12 15:25:44 --> Input Class Initialized
DEBUG - 2011-07-12 15:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 15:25:44 --> Language Class Initialized
DEBUG - 2011-07-12 15:25:44 --> Loader Class Initialized
DEBUG - 2011-07-12 15:25:44 --> Controller Class Initialized
DEBUG - 2011-07-12 15:25:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-12 15:25:44 --> Helper loaded: url_helper
DEBUG - 2011-07-12 15:25:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 15:25:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 15:25:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 15:25:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 15:25:44 --> Final output sent to browser
DEBUG - 2011-07-12 15:25:44 --> Total execution time: 0.0832
DEBUG - 2011-07-12 15:25:47 --> Config Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Hooks Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Utf8 Class Initialized
DEBUG - 2011-07-12 15:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 15:25:47 --> URI Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Router Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Output Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Input Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 15:25:47 --> Language Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Loader Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Controller Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Model Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Model Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Model Class Initialized
DEBUG - 2011-07-12 15:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 15:25:47 --> Database Driver Class Initialized
DEBUG - 2011-07-12 15:25:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 15:25:47 --> Helper loaded: url_helper
DEBUG - 2011-07-12 15:25:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 15:25:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 15:25:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 15:25:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 15:25:47 --> Final output sent to browser
DEBUG - 2011-07-12 15:25:47 --> Total execution time: 0.0577
DEBUG - 2011-07-12 15:25:51 --> Config Class Initialized
DEBUG - 2011-07-12 15:25:51 --> Hooks Class Initialized
DEBUG - 2011-07-12 15:25:51 --> Utf8 Class Initialized
DEBUG - 2011-07-12 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 15:25:51 --> URI Class Initialized
DEBUG - 2011-07-12 15:25:51 --> Router Class Initialized
ERROR - 2011-07-12 15:25:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 15:25:51 --> Config Class Initialized
DEBUG - 2011-07-12 15:25:51 --> Hooks Class Initialized
DEBUG - 2011-07-12 15:25:51 --> Utf8 Class Initialized
DEBUG - 2011-07-12 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 15:25:51 --> URI Class Initialized
DEBUG - 2011-07-12 15:25:51 --> Router Class Initialized
ERROR - 2011-07-12 15:25:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 15:25:52 --> Config Class Initialized
DEBUG - 2011-07-12 15:25:52 --> Hooks Class Initialized
DEBUG - 2011-07-12 15:25:52 --> Utf8 Class Initialized
DEBUG - 2011-07-12 15:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 15:25:52 --> URI Class Initialized
DEBUG - 2011-07-12 15:25:52 --> Router Class Initialized
ERROR - 2011-07-12 15:25:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 15:59:15 --> Config Class Initialized
DEBUG - 2011-07-12 15:59:15 --> Hooks Class Initialized
DEBUG - 2011-07-12 15:59:16 --> Utf8 Class Initialized
DEBUG - 2011-07-12 15:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 15:59:16 --> URI Class Initialized
DEBUG - 2011-07-12 15:59:16 --> Router Class Initialized
ERROR - 2011-07-12 15:59:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-12 16:16:20 --> Config Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Hooks Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Utf8 Class Initialized
DEBUG - 2011-07-12 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 16:16:20 --> URI Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Router Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Output Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Input Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 16:16:20 --> Language Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Loader Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Controller Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Model Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Model Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Model Class Initialized
DEBUG - 2011-07-12 16:16:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 16:16:20 --> Database Driver Class Initialized
DEBUG - 2011-07-12 16:16:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 16:16:21 --> Helper loaded: url_helper
DEBUG - 2011-07-12 16:16:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 16:16:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 16:16:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 16:16:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 16:16:21 --> Final output sent to browser
DEBUG - 2011-07-12 16:16:21 --> Total execution time: 1.6328
DEBUG - 2011-07-12 16:16:25 --> Config Class Initialized
DEBUG - 2011-07-12 16:16:25 --> Hooks Class Initialized
DEBUG - 2011-07-12 16:16:25 --> Utf8 Class Initialized
DEBUG - 2011-07-12 16:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 16:16:25 --> URI Class Initialized
DEBUG - 2011-07-12 16:16:25 --> Router Class Initialized
ERROR - 2011-07-12 16:16:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 16:17:50 --> Config Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Hooks Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Utf8 Class Initialized
DEBUG - 2011-07-12 16:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 16:17:50 --> URI Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Router Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Output Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Input Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 16:17:50 --> Language Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Loader Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Controller Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Model Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Model Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Model Class Initialized
DEBUG - 2011-07-12 16:17:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 16:17:50 --> Database Driver Class Initialized
DEBUG - 2011-07-12 16:17:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 16:17:50 --> Helper loaded: url_helper
DEBUG - 2011-07-12 16:17:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 16:17:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 16:17:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 16:17:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 16:17:50 --> Final output sent to browser
DEBUG - 2011-07-12 16:17:50 --> Total execution time: 0.0418
DEBUG - 2011-07-12 16:17:51 --> Config Class Initialized
DEBUG - 2011-07-12 16:17:51 --> Hooks Class Initialized
DEBUG - 2011-07-12 16:17:51 --> Utf8 Class Initialized
DEBUG - 2011-07-12 16:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 16:17:52 --> URI Class Initialized
DEBUG - 2011-07-12 16:17:52 --> Router Class Initialized
ERROR - 2011-07-12 16:17:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-12 16:20:33 --> Config Class Initialized
DEBUG - 2011-07-12 16:20:33 --> Hooks Class Initialized
DEBUG - 2011-07-12 16:20:33 --> Utf8 Class Initialized
DEBUG - 2011-07-12 16:20:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 16:20:33 --> URI Class Initialized
DEBUG - 2011-07-12 16:20:33 --> Router Class Initialized
ERROR - 2011-07-12 16:20:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-12 16:20:34 --> Config Class Initialized
DEBUG - 2011-07-12 16:20:34 --> Hooks Class Initialized
DEBUG - 2011-07-12 16:20:34 --> Utf8 Class Initialized
DEBUG - 2011-07-12 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 16:20:34 --> URI Class Initialized
DEBUG - 2011-07-12 16:20:34 --> Router Class Initialized
DEBUG - 2011-07-12 16:20:34 --> No URI present. Default controller set.
DEBUG - 2011-07-12 16:20:34 --> Output Class Initialized
DEBUG - 2011-07-12 16:20:34 --> Input Class Initialized
DEBUG - 2011-07-12 16:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 16:20:34 --> Language Class Initialized
DEBUG - 2011-07-12 16:20:34 --> Loader Class Initialized
DEBUG - 2011-07-12 16:20:34 --> Controller Class Initialized
DEBUG - 2011-07-12 16:20:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-12 16:20:34 --> Helper loaded: url_helper
DEBUG - 2011-07-12 16:20:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 16:20:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 16:20:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 16:20:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 16:20:34 --> Final output sent to browser
DEBUG - 2011-07-12 16:20:34 --> Total execution time: 0.3685
DEBUG - 2011-07-12 16:47:27 --> Config Class Initialized
DEBUG - 2011-07-12 16:47:27 --> Hooks Class Initialized
DEBUG - 2011-07-12 16:47:27 --> Utf8 Class Initialized
DEBUG - 2011-07-12 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 16:47:27 --> URI Class Initialized
DEBUG - 2011-07-12 16:47:27 --> Router Class Initialized
ERROR - 2011-07-12 16:47:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-12 16:48:07 --> Config Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Hooks Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Utf8 Class Initialized
DEBUG - 2011-07-12 16:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 16:48:07 --> URI Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Router Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Output Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Input Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 16:48:07 --> Language Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Loader Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Controller Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Model Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Model Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Model Class Initialized
DEBUG - 2011-07-12 16:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 16:48:07 --> Database Driver Class Initialized
DEBUG - 2011-07-12 16:48:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 16:48:08 --> Helper loaded: url_helper
DEBUG - 2011-07-12 16:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 16:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 16:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 16:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 16:48:08 --> Final output sent to browser
DEBUG - 2011-07-12 16:48:08 --> Total execution time: 0.6155
DEBUG - 2011-07-12 19:13:21 --> Config Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Hooks Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Utf8 Class Initialized
DEBUG - 2011-07-12 19:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 19:13:21 --> URI Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Router Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Output Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Input Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 19:13:21 --> Language Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Loader Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Controller Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Model Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Model Class Initialized
DEBUG - 2011-07-12 19:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 19:13:21 --> Database Driver Class Initialized
DEBUG - 2011-07-12 19:13:22 --> Final output sent to browser
DEBUG - 2011-07-12 19:13:22 --> Total execution time: 1.1969
DEBUG - 2011-07-12 20:16:08 --> Config Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Hooks Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Utf8 Class Initialized
DEBUG - 2011-07-12 20:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 20:16:08 --> URI Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Router Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Output Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Input Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 20:16:08 --> Language Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Loader Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Controller Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 20:16:08 --> Database Driver Class Initialized
DEBUG - 2011-07-12 20:16:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 20:16:08 --> Helper loaded: url_helper
DEBUG - 2011-07-12 20:16:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 20:16:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 20:16:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 20:16:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 20:16:08 --> Final output sent to browser
DEBUG - 2011-07-12 20:16:08 --> Total execution time: 0.5647
DEBUG - 2011-07-12 20:16:12 --> Config Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Hooks Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Utf8 Class Initialized
DEBUG - 2011-07-12 20:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 20:16:12 --> URI Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Router Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Output Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Input Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 20:16:12 --> Language Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Loader Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Controller Class Initialized
ERROR - 2011-07-12 20:16:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 20:16:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 20:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 20:16:12 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 20:16:12 --> Database Driver Class Initialized
DEBUG - 2011-07-12 20:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 20:16:12 --> Helper loaded: url_helper
DEBUG - 2011-07-12 20:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 20:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 20:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 20:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 20:16:12 --> Final output sent to browser
DEBUG - 2011-07-12 20:16:12 --> Total execution time: 0.1021
DEBUG - 2011-07-12 20:16:55 --> Config Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Hooks Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Utf8 Class Initialized
DEBUG - 2011-07-12 20:16:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 20:16:55 --> URI Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Router Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Output Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Input Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 20:16:55 --> Language Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Loader Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Controller Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 20:16:55 --> Database Driver Class Initialized
DEBUG - 2011-07-12 20:16:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-12 20:16:55 --> Helper loaded: url_helper
DEBUG - 2011-07-12 20:16:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 20:16:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 20:16:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 20:16:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 20:16:55 --> Final output sent to browser
DEBUG - 2011-07-12 20:16:55 --> Total execution time: 0.0498
DEBUG - 2011-07-12 20:16:58 --> Config Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Hooks Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Utf8 Class Initialized
DEBUG - 2011-07-12 20:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 20:16:58 --> URI Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Router Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Output Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Input Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 20:16:58 --> Language Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Loader Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Controller Class Initialized
ERROR - 2011-07-12 20:16:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-12 20:16:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-12 20:16:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 20:16:58 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Model Class Initialized
DEBUG - 2011-07-12 20:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-12 20:16:58 --> Database Driver Class Initialized
DEBUG - 2011-07-12 20:16:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-12 20:16:58 --> Helper loaded: url_helper
DEBUG - 2011-07-12 20:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 20:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 20:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 20:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 20:16:58 --> Final output sent to browser
DEBUG - 2011-07-12 20:16:58 --> Total execution time: 0.0392
DEBUG - 2011-07-12 22:35:20 --> Config Class Initialized
DEBUG - 2011-07-12 22:35:20 --> Hooks Class Initialized
DEBUG - 2011-07-12 22:35:20 --> Utf8 Class Initialized
DEBUG - 2011-07-12 22:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-12 22:35:20 --> URI Class Initialized
DEBUG - 2011-07-12 22:35:20 --> Router Class Initialized
DEBUG - 2011-07-12 22:35:20 --> No URI present. Default controller set.
DEBUG - 2011-07-12 22:35:20 --> Output Class Initialized
DEBUG - 2011-07-12 22:35:21 --> Input Class Initialized
DEBUG - 2011-07-12 22:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-12 22:35:21 --> Language Class Initialized
DEBUG - 2011-07-12 22:35:21 --> Loader Class Initialized
DEBUG - 2011-07-12 22:35:21 --> Controller Class Initialized
DEBUG - 2011-07-12 22:35:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-12 22:35:21 --> Helper loaded: url_helper
DEBUG - 2011-07-12 22:35:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-12 22:35:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-12 22:35:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-12 22:35:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-12 22:35:21 --> Final output sent to browser
DEBUG - 2011-07-12 22:35:21 --> Total execution time: 0.3533

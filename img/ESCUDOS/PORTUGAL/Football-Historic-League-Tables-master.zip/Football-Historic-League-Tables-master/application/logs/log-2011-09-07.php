<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-07 00:09:30 --> Config Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:09:30 --> URI Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Router Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Output Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Input Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:09:30 --> Language Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Loader Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Controller Class Initialized
ERROR - 2011-09-07 00:09:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 00:09:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 00:09:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 00:09:30 --> Model Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Model Class Initialized
DEBUG - 2011-09-07 00:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:09:30 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:09:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 00:09:30 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:09:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:09:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:09:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:09:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:09:30 --> Final output sent to browser
DEBUG - 2011-09-07 00:09:30 --> Total execution time: 0.0433
DEBUG - 2011-09-07 00:45:28 --> Config Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:45:28 --> URI Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Router Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Output Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Input Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:45:28 --> Language Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Loader Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Controller Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Model Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Model Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Model Class Initialized
DEBUG - 2011-09-07 00:45:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:45:28 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:45:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:45:29 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:45:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:45:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:45:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:45:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:45:29 --> Final output sent to browser
DEBUG - 2011-09-07 00:45:29 --> Total execution time: 0.5851
DEBUG - 2011-09-07 00:45:30 --> Config Class Initialized
DEBUG - 2011-09-07 00:45:30 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:45:30 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:45:30 --> URI Class Initialized
DEBUG - 2011-09-07 00:45:30 --> Router Class Initialized
ERROR - 2011-09-07 00:45:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:45:59 --> Config Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:45:59 --> URI Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Router Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Output Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Input Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:45:59 --> Language Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Loader Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Controller Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Model Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Model Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Model Class Initialized
DEBUG - 2011-09-07 00:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:45:59 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:46:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:46:00 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:46:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:46:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:46:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:46:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:46:00 --> Final output sent to browser
DEBUG - 2011-09-07 00:46:00 --> Total execution time: 0.8180
DEBUG - 2011-09-07 00:46:01 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:01 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Router Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Output Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Input Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:46:01 --> Language Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Loader Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Controller Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:46:01 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:46:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:46:01 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:46:01 --> Final output sent to browser
DEBUG - 2011-09-07 00:46:01 --> Total execution time: 0.0995
DEBUG - 2011-09-07 00:46:01 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:01 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:01 --> Router Class Initialized
ERROR - 2011-09-07 00:46:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:46:22 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:22 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Router Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Output Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Input Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:46:22 --> Language Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Loader Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Controller Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:46:22 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:46:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:46:22 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:46:22 --> Final output sent to browser
DEBUG - 2011-09-07 00:46:22 --> Total execution time: 0.2573
DEBUG - 2011-09-07 00:46:23 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:23 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Router Class Initialized
ERROR - 2011-09-07 00:46:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:46:23 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:23 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Router Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Output Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Input Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:46:23 --> Language Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Loader Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Controller Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:46:23 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:46:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:46:24 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:46:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:46:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:46:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:46:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:46:24 --> Final output sent to browser
DEBUG - 2011-09-07 00:46:24 --> Total execution time: 0.0462
DEBUG - 2011-09-07 00:46:33 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:33 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Router Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Output Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Input Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:46:33 --> Language Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Loader Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Controller Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:46:33 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:46:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:46:34 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:46:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:46:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:46:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:46:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:46:34 --> Final output sent to browser
DEBUG - 2011-09-07 00:46:34 --> Total execution time: 0.6981
DEBUG - 2011-09-07 00:46:34 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:34 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:34 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:34 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:34 --> Router Class Initialized
ERROR - 2011-09-07 00:46:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:46:35 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:35 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Router Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Output Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Input Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:46:35 --> Language Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Loader Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Controller Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:46:35 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:46:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:46:35 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:46:35 --> Final output sent to browser
DEBUG - 2011-09-07 00:46:35 --> Total execution time: 0.1227
DEBUG - 2011-09-07 00:46:57 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:57 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Router Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Output Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Input Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:46:57 --> Language Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Loader Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Controller Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Model Class Initialized
DEBUG - 2011-09-07 00:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:46:57 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:46:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:46:58 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:46:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:46:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:46:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:46:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:46:58 --> Final output sent to browser
DEBUG - 2011-09-07 00:46:58 --> Total execution time: 0.2942
DEBUG - 2011-09-07 00:46:59 --> Config Class Initialized
DEBUG - 2011-09-07 00:46:59 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:46:59 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:46:59 --> URI Class Initialized
DEBUG - 2011-09-07 00:46:59 --> Router Class Initialized
ERROR - 2011-09-07 00:46:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:47:00 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:00 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:00 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:00 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:00 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:00 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:00 --> Total execution time: 0.0459
DEBUG - 2011-09-07 00:47:07 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:07 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:07 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:07 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:07 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:07 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:07 --> Total execution time: 0.2411
DEBUG - 2011-09-07 00:47:08 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:08 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Router Class Initialized
ERROR - 2011-09-07 00:47:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:47:08 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:08 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:08 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:08 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:08 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:08 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:08 --> Total execution time: 0.0743
DEBUG - 2011-09-07 00:47:12 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:12 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:12 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:12 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:12 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:12 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:12 --> Total execution time: 0.2166
DEBUG - 2011-09-07 00:47:13 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:13 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:13 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:13 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:13 --> Router Class Initialized
ERROR - 2011-09-07 00:47:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:47:14 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:14 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:14 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:14 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:14 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:14 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:14 --> Total execution time: 0.0473
DEBUG - 2011-09-07 00:47:25 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:25 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:25 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:25 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:25 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:25 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:25 --> Total execution time: 0.1907
DEBUG - 2011-09-07 00:47:26 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:26 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:26 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:26 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:26 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:26 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:26 --> Total execution time: 0.0500
DEBUG - 2011-09-07 00:47:26 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:26 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:26 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:26 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:26 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:26 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:26 --> Total execution time: 0.0432
DEBUG - 2011-09-07 00:47:26 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:26 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:26 --> Router Class Initialized
ERROR - 2011-09-07 00:47:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:47:32 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:32 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:32 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:32 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:32 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:32 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:32 --> Total execution time: 0.0471
DEBUG - 2011-09-07 00:47:33 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:33 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:33 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:33 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:33 --> Router Class Initialized
ERROR - 2011-09-07 00:47:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:47:51 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:51 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:51 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:51 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:51 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:51 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:51 --> Total execution time: 0.2492
DEBUG - 2011-09-07 00:47:52 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:52 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Router Class Initialized
ERROR - 2011-09-07 00:47:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:47:52 --> Config Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:47:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:47:52 --> URI Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Router Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Output Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Input Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:47:52 --> Language Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Loader Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Controller Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Model Class Initialized
DEBUG - 2011-09-07 00:47:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:47:52 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:47:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:47:52 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:47:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:47:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:47:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:47:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:47:52 --> Final output sent to browser
DEBUG - 2011-09-07 00:47:52 --> Total execution time: 0.0535
DEBUG - 2011-09-07 00:48:02 --> Config Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:48:02 --> URI Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Router Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Output Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Input Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:48:02 --> Language Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Loader Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Controller Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Model Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Model Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Model Class Initialized
DEBUG - 2011-09-07 00:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:48:02 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:48:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:48:03 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:48:03 --> Final output sent to browser
DEBUG - 2011-09-07 00:48:03 --> Total execution time: 0.3837
DEBUG - 2011-09-07 00:48:04 --> Config Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:48:04 --> URI Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Router Class Initialized
ERROR - 2011-09-07 00:48:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 00:48:04 --> Config Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Hooks Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Utf8 Class Initialized
DEBUG - 2011-09-07 00:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 00:48:04 --> URI Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Router Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Output Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Input Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 00:48:04 --> Language Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Loader Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Controller Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Model Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Model Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Model Class Initialized
DEBUG - 2011-09-07 00:48:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 00:48:04 --> Database Driver Class Initialized
DEBUG - 2011-09-07 00:48:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 00:48:04 --> Helper loaded: url_helper
DEBUG - 2011-09-07 00:48:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 00:48:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 00:48:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 00:48:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 00:48:04 --> Final output sent to browser
DEBUG - 2011-09-07 00:48:04 --> Total execution time: 0.0520
DEBUG - 2011-09-07 01:23:48 --> Config Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Hooks Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Utf8 Class Initialized
DEBUG - 2011-09-07 01:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 01:23:48 --> URI Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Router Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Output Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Input Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 01:23:48 --> Language Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Loader Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Controller Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Model Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Model Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Model Class Initialized
DEBUG - 2011-09-07 01:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 01:23:48 --> Database Driver Class Initialized
DEBUG - 2011-09-07 01:23:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 01:23:48 --> Helper loaded: url_helper
DEBUG - 2011-09-07 01:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 01:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 01:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 01:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 01:23:48 --> Final output sent to browser
DEBUG - 2011-09-07 01:23:48 --> Total execution time: 0.2653
DEBUG - 2011-09-07 01:23:49 --> Config Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Hooks Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Utf8 Class Initialized
DEBUG - 2011-09-07 01:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 01:23:49 --> URI Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Router Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Output Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Input Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 01:23:49 --> Language Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Loader Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Controller Class Initialized
ERROR - 2011-09-07 01:23:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 01:23:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 01:23:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 01:23:49 --> Model Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Model Class Initialized
DEBUG - 2011-09-07 01:23:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 01:23:49 --> Database Driver Class Initialized
DEBUG - 2011-09-07 01:23:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 01:23:49 --> Helper loaded: url_helper
DEBUG - 2011-09-07 01:23:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 01:23:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 01:23:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 01:23:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 01:23:49 --> Final output sent to browser
DEBUG - 2011-09-07 01:23:49 --> Total execution time: 0.0382
DEBUG - 2011-09-07 01:39:45 --> Config Class Initialized
DEBUG - 2011-09-07 01:39:45 --> Hooks Class Initialized
DEBUG - 2011-09-07 01:39:45 --> Utf8 Class Initialized
DEBUG - 2011-09-07 01:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 01:39:45 --> URI Class Initialized
DEBUG - 2011-09-07 01:39:45 --> Router Class Initialized
ERROR - 2011-09-07 01:39:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-07 01:39:46 --> Config Class Initialized
DEBUG - 2011-09-07 01:39:46 --> Hooks Class Initialized
DEBUG - 2011-09-07 01:39:46 --> Utf8 Class Initialized
DEBUG - 2011-09-07 01:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 01:39:46 --> URI Class Initialized
DEBUG - 2011-09-07 01:39:46 --> Router Class Initialized
DEBUG - 2011-09-07 01:39:46 --> No URI present. Default controller set.
DEBUG - 2011-09-07 01:39:46 --> Output Class Initialized
DEBUG - 2011-09-07 01:39:46 --> Input Class Initialized
DEBUG - 2011-09-07 01:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 01:39:46 --> Language Class Initialized
DEBUG - 2011-09-07 01:39:46 --> Loader Class Initialized
DEBUG - 2011-09-07 01:39:46 --> Controller Class Initialized
DEBUG - 2011-09-07 01:39:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-07 01:39:46 --> Helper loaded: url_helper
DEBUG - 2011-09-07 01:39:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 01:39:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 01:39:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 01:39:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 01:39:46 --> Final output sent to browser
DEBUG - 2011-09-07 01:39:46 --> Total execution time: 0.0881
DEBUG - 2011-09-07 02:22:08 --> Config Class Initialized
DEBUG - 2011-09-07 02:22:08 --> Hooks Class Initialized
DEBUG - 2011-09-07 02:22:08 --> Utf8 Class Initialized
DEBUG - 2011-09-07 02:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 02:22:08 --> URI Class Initialized
DEBUG - 2011-09-07 02:22:08 --> Router Class Initialized
ERROR - 2011-09-07 02:22:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-07 02:22:10 --> Config Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Hooks Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Utf8 Class Initialized
DEBUG - 2011-09-07 02:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 02:22:10 --> URI Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Router Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Output Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Input Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 02:22:10 --> Language Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Loader Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Controller Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Model Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Model Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Model Class Initialized
DEBUG - 2011-09-07 02:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 02:22:10 --> Database Driver Class Initialized
DEBUG - 2011-09-07 02:22:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 02:22:12 --> Helper loaded: url_helper
DEBUG - 2011-09-07 02:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 02:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 02:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 02:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 02:22:12 --> Final output sent to browser
DEBUG - 2011-09-07 02:22:12 --> Total execution time: 2.2749
DEBUG - 2011-09-07 02:22:13 --> Config Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Hooks Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Utf8 Class Initialized
DEBUG - 2011-09-07 02:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 02:22:13 --> URI Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Router Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Output Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Input Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 02:22:13 --> Language Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Loader Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Controller Class Initialized
ERROR - 2011-09-07 02:22:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 02:22:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 02:22:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 02:22:13 --> Model Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Model Class Initialized
DEBUG - 2011-09-07 02:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 02:22:13 --> Database Driver Class Initialized
DEBUG - 2011-09-07 02:22:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 02:22:13 --> Helper loaded: url_helper
DEBUG - 2011-09-07 02:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 02:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 02:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 02:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 02:22:13 --> Final output sent to browser
DEBUG - 2011-09-07 02:22:13 --> Total execution time: 0.1778
DEBUG - 2011-09-07 02:41:42 --> Config Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Hooks Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Utf8 Class Initialized
DEBUG - 2011-09-07 02:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 02:41:42 --> URI Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Router Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Output Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Input Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 02:41:42 --> Language Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Loader Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Controller Class Initialized
ERROR - 2011-09-07 02:41:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 02:41:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 02:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 02:41:42 --> Model Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Model Class Initialized
DEBUG - 2011-09-07 02:41:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 02:41:42 --> Database Driver Class Initialized
DEBUG - 2011-09-07 02:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 02:41:42 --> Helper loaded: url_helper
DEBUG - 2011-09-07 02:41:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 02:41:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 02:41:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 02:41:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 02:41:42 --> Final output sent to browser
DEBUG - 2011-09-07 02:41:42 --> Total execution time: 0.1248
DEBUG - 2011-09-07 02:41:44 --> Config Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Hooks Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Utf8 Class Initialized
DEBUG - 2011-09-07 02:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 02:41:44 --> URI Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Router Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Output Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Input Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 02:41:44 --> Language Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Loader Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Controller Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Model Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Model Class Initialized
DEBUG - 2011-09-07 02:41:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 02:41:44 --> Database Driver Class Initialized
DEBUG - 2011-09-07 02:41:45 --> Final output sent to browser
DEBUG - 2011-09-07 02:41:45 --> Total execution time: 0.7585
DEBUG - 2011-09-07 02:41:50 --> Config Class Initialized
DEBUG - 2011-09-07 02:41:50 --> Hooks Class Initialized
DEBUG - 2011-09-07 02:41:50 --> Utf8 Class Initialized
DEBUG - 2011-09-07 02:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 02:41:50 --> URI Class Initialized
DEBUG - 2011-09-07 02:41:50 --> Router Class Initialized
ERROR - 2011-09-07 02:41:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 03:18:46 --> Config Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:18:46 --> URI Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Router Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Output Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Input Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 03:18:46 --> Language Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Loader Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Controller Class Initialized
ERROR - 2011-09-07 03:18:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 03:18:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 03:18:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 03:18:46 --> Model Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Model Class Initialized
DEBUG - 2011-09-07 03:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 03:18:46 --> Database Driver Class Initialized
DEBUG - 2011-09-07 03:18:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 03:18:46 --> Helper loaded: url_helper
DEBUG - 2011-09-07 03:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 03:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 03:18:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 03:18:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 03:18:47 --> Final output sent to browser
DEBUG - 2011-09-07 03:18:47 --> Total execution time: 0.8722
DEBUG - 2011-09-07 03:18:47 --> Config Class Initialized
DEBUG - 2011-09-07 03:18:47 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:18:47 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:18:47 --> URI Class Initialized
DEBUG - 2011-09-07 03:18:47 --> Router Class Initialized
DEBUG - 2011-09-07 03:18:47 --> Output Class Initialized
DEBUG - 2011-09-07 03:18:47 --> Input Class Initialized
DEBUG - 2011-09-07 03:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 03:18:48 --> Language Class Initialized
DEBUG - 2011-09-07 03:18:48 --> Loader Class Initialized
DEBUG - 2011-09-07 03:18:48 --> Controller Class Initialized
DEBUG - 2011-09-07 03:18:48 --> Model Class Initialized
DEBUG - 2011-09-07 03:18:48 --> Model Class Initialized
DEBUG - 2011-09-07 03:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 03:18:48 --> Database Driver Class Initialized
DEBUG - 2011-09-07 03:18:48 --> Final output sent to browser
DEBUG - 2011-09-07 03:18:48 --> Total execution time: 0.8127
DEBUG - 2011-09-07 03:18:49 --> Config Class Initialized
DEBUG - 2011-09-07 03:18:49 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:18:49 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:18:49 --> URI Class Initialized
DEBUG - 2011-09-07 03:18:49 --> Router Class Initialized
ERROR - 2011-09-07 03:18:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 03:19:06 --> Config Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:19:06 --> URI Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Router Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Output Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Input Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 03:19:06 --> Language Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Loader Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Controller Class Initialized
ERROR - 2011-09-07 03:19:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 03:19:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 03:19:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 03:19:06 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 03:19:06 --> Database Driver Class Initialized
DEBUG - 2011-09-07 03:19:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 03:19:06 --> Helper loaded: url_helper
DEBUG - 2011-09-07 03:19:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 03:19:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 03:19:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 03:19:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 03:19:06 --> Final output sent to browser
DEBUG - 2011-09-07 03:19:06 --> Total execution time: 0.0586
DEBUG - 2011-09-07 03:19:06 --> Config Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:19:06 --> URI Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Router Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Output Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Input Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 03:19:06 --> Language Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Loader Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Controller Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 03:19:06 --> Database Driver Class Initialized
DEBUG - 2011-09-07 03:19:07 --> Final output sent to browser
DEBUG - 2011-09-07 03:19:07 --> Total execution time: 0.7891
DEBUG - 2011-09-07 03:19:07 --> Config Class Initialized
DEBUG - 2011-09-07 03:19:07 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:19:07 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:19:07 --> URI Class Initialized
DEBUG - 2011-09-07 03:19:07 --> Router Class Initialized
ERROR - 2011-09-07 03:19:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 03:19:13 --> Config Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:19:13 --> URI Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Router Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Output Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Input Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 03:19:13 --> Language Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Loader Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Controller Class Initialized
ERROR - 2011-09-07 03:19:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 03:19:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 03:19:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 03:19:13 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 03:19:13 --> Database Driver Class Initialized
DEBUG - 2011-09-07 03:19:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 03:19:13 --> Helper loaded: url_helper
DEBUG - 2011-09-07 03:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 03:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 03:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 03:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 03:19:13 --> Final output sent to browser
DEBUG - 2011-09-07 03:19:13 --> Total execution time: 0.0629
DEBUG - 2011-09-07 03:19:14 --> Config Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:19:14 --> URI Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Router Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Output Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Input Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 03:19:14 --> Language Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Loader Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Controller Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 03:19:14 --> Database Driver Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Config Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:19:15 --> URI Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Router Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Output Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Input Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 03:19:15 --> Language Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Loader Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Controller Class Initialized
ERROR - 2011-09-07 03:19:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 03:19:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 03:19:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 03:19:15 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Model Class Initialized
DEBUG - 2011-09-07 03:19:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 03:19:15 --> Database Driver Class Initialized
DEBUG - 2011-09-07 03:19:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 03:19:15 --> Helper loaded: url_helper
DEBUG - 2011-09-07 03:19:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 03:19:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 03:19:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 03:19:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 03:19:15 --> Final output sent to browser
DEBUG - 2011-09-07 03:19:15 --> Total execution time: 0.0409
DEBUG - 2011-09-07 03:19:15 --> Final output sent to browser
DEBUG - 2011-09-07 03:19:15 --> Total execution time: 1.5649
DEBUG - 2011-09-07 03:19:16 --> Config Class Initialized
DEBUG - 2011-09-07 03:19:16 --> Hooks Class Initialized
DEBUG - 2011-09-07 03:19:16 --> Utf8 Class Initialized
DEBUG - 2011-09-07 03:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 03:19:16 --> URI Class Initialized
DEBUG - 2011-09-07 03:19:16 --> Router Class Initialized
ERROR - 2011-09-07 03:19:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 04:10:37 --> Config Class Initialized
DEBUG - 2011-09-07 04:10:37 --> Hooks Class Initialized
DEBUG - 2011-09-07 04:10:37 --> Utf8 Class Initialized
DEBUG - 2011-09-07 04:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 04:10:37 --> URI Class Initialized
DEBUG - 2011-09-07 04:10:37 --> Router Class Initialized
DEBUG - 2011-09-07 04:10:37 --> No URI present. Default controller set.
DEBUG - 2011-09-07 04:10:37 --> Output Class Initialized
DEBUG - 2011-09-07 04:10:37 --> Input Class Initialized
DEBUG - 2011-09-07 04:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 04:10:37 --> Language Class Initialized
DEBUG - 2011-09-07 04:10:37 --> Loader Class Initialized
DEBUG - 2011-09-07 04:10:37 --> Controller Class Initialized
DEBUG - 2011-09-07 04:10:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-07 04:10:37 --> Helper loaded: url_helper
DEBUG - 2011-09-07 04:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 04:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 04:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 04:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 04:10:37 --> Final output sent to browser
DEBUG - 2011-09-07 04:10:37 --> Total execution time: 0.4670
DEBUG - 2011-09-07 04:25:19 --> Config Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Hooks Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Utf8 Class Initialized
DEBUG - 2011-09-07 04:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 04:25:19 --> URI Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Router Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Output Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Input Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 04:25:19 --> Language Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Loader Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Controller Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Model Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Model Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Model Class Initialized
DEBUG - 2011-09-07 04:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 04:25:19 --> Database Driver Class Initialized
DEBUG - 2011-09-07 04:25:23 --> Config Class Initialized
DEBUG - 2011-09-07 04:25:23 --> Hooks Class Initialized
DEBUG - 2011-09-07 04:25:23 --> Utf8 Class Initialized
DEBUG - 2011-09-07 04:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 04:25:23 --> URI Class Initialized
DEBUG - 2011-09-07 04:25:23 --> Router Class Initialized
DEBUG - 2011-09-07 04:25:23 --> Output Class Initialized
DEBUG - 2011-09-07 04:25:23 --> Input Class Initialized
DEBUG - 2011-09-07 04:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 04:25:23 --> Language Class Initialized
DEBUG - 2011-09-07 04:25:24 --> Loader Class Initialized
DEBUG - 2011-09-07 04:25:24 --> Controller Class Initialized
ERROR - 2011-09-07 04:25:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 04:25:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 04:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 04:25:24 --> Model Class Initialized
DEBUG - 2011-09-07 04:25:24 --> Model Class Initialized
DEBUG - 2011-09-07 04:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 04:25:24 --> Database Driver Class Initialized
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 04:25:25 --> Helper loaded: url_helper
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 04:25:25 --> Final output sent to browser
DEBUG - 2011-09-07 04:25:25 --> Total execution time: 1.5711
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 04:25:25 --> Helper loaded: url_helper
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 04:25:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 04:25:25 --> Final output sent to browser
DEBUG - 2011-09-07 04:25:25 --> Total execution time: 6.5755
DEBUG - 2011-09-07 04:33:23 --> Config Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Hooks Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Utf8 Class Initialized
DEBUG - 2011-09-07 04:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 04:33:23 --> URI Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Router Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Output Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Input Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 04:33:23 --> Language Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Loader Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Controller Class Initialized
ERROR - 2011-09-07 04:33:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 04:33:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 04:33:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 04:33:23 --> Model Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Model Class Initialized
DEBUG - 2011-09-07 04:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 04:33:23 --> Database Driver Class Initialized
DEBUG - 2011-09-07 04:33:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 04:33:23 --> Helper loaded: url_helper
DEBUG - 2011-09-07 04:33:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 04:33:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 04:33:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 04:33:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 04:33:23 --> Final output sent to browser
DEBUG - 2011-09-07 04:33:23 --> Total execution time: 0.0458
DEBUG - 2011-09-07 05:52:56 --> Config Class Initialized
DEBUG - 2011-09-07 05:52:56 --> Hooks Class Initialized
DEBUG - 2011-09-07 05:52:56 --> Utf8 Class Initialized
DEBUG - 2011-09-07 05:52:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 05:52:56 --> URI Class Initialized
DEBUG - 2011-09-07 05:52:56 --> Router Class Initialized
DEBUG - 2011-09-07 05:52:57 --> No URI present. Default controller set.
DEBUG - 2011-09-07 05:52:57 --> Output Class Initialized
DEBUG - 2011-09-07 05:52:57 --> Input Class Initialized
DEBUG - 2011-09-07 05:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 05:52:57 --> Language Class Initialized
DEBUG - 2011-09-07 05:52:57 --> Loader Class Initialized
DEBUG - 2011-09-07 05:52:57 --> Controller Class Initialized
DEBUG - 2011-09-07 05:52:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-07 05:52:57 --> Helper loaded: url_helper
DEBUG - 2011-09-07 05:52:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 05:52:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 05:52:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 05:52:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 05:52:57 --> Final output sent to browser
DEBUG - 2011-09-07 05:52:57 --> Total execution time: 0.1506
DEBUG - 2011-09-07 06:07:19 --> Config Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:07:19 --> URI Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Router Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Output Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Input Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:07:19 --> Language Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Loader Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Controller Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:07:19 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:07:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:07:20 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:07:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:07:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:07:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:07:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:07:20 --> Final output sent to browser
DEBUG - 2011-09-07 06:07:20 --> Total execution time: 1.1965
DEBUG - 2011-09-07 06:07:22 --> Config Class Initialized
DEBUG - 2011-09-07 06:07:22 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:07:22 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:07:22 --> URI Class Initialized
DEBUG - 2011-09-07 06:07:22 --> Router Class Initialized
ERROR - 2011-09-07 06:07:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:07:34 --> Config Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:07:34 --> URI Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Router Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Output Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Input Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:07:34 --> Language Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Loader Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Controller Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:07:34 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:07:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:07:36 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:07:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:07:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:07:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:07:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:07:36 --> Final output sent to browser
DEBUG - 2011-09-07 06:07:36 --> Total execution time: 1.7944
DEBUG - 2011-09-07 06:07:37 --> Config Class Initialized
DEBUG - 2011-09-07 06:07:37 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:07:37 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:07:37 --> URI Class Initialized
DEBUG - 2011-09-07 06:07:37 --> Router Class Initialized
ERROR - 2011-09-07 06:07:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:07:55 --> Config Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:07:55 --> URI Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Router Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Output Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Input Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:07:55 --> Language Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Loader Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Controller Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Model Class Initialized
DEBUG - 2011-09-07 06:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:07:55 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:07:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:07:56 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:07:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:07:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:07:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:07:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:07:56 --> Final output sent to browser
DEBUG - 2011-09-07 06:07:56 --> Total execution time: 0.3158
DEBUG - 2011-09-07 06:07:57 --> Config Class Initialized
DEBUG - 2011-09-07 06:07:57 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:07:57 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:07:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:07:57 --> URI Class Initialized
DEBUG - 2011-09-07 06:07:57 --> Router Class Initialized
ERROR - 2011-09-07 06:07:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:08:06 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:06 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Router Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Output Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Input Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:08:06 --> Language Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Loader Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Controller Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:08:06 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:08:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:08:06 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:08:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:08:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:08:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:08:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:08:06 --> Final output sent to browser
DEBUG - 2011-09-07 06:08:06 --> Total execution time: 0.4751
DEBUG - 2011-09-07 06:08:07 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:07 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:07 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:07 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:07 --> Router Class Initialized
ERROR - 2011-09-07 06:08:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:08:12 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:12 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Router Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Output Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Input Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:08:12 --> Language Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Loader Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Controller Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:08:12 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:08:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:08:12 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:08:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:08:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:08:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:08:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:08:12 --> Final output sent to browser
DEBUG - 2011-09-07 06:08:12 --> Total execution time: 0.0475
DEBUG - 2011-09-07 06:08:13 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:13 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:13 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:13 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:13 --> Router Class Initialized
ERROR - 2011-09-07 06:08:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:08:18 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:18 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Router Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Output Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Input Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:08:18 --> Language Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Loader Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Controller Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:08:18 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:08:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:08:18 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:08:18 --> Final output sent to browser
DEBUG - 2011-09-07 06:08:18 --> Total execution time: 0.6155
DEBUG - 2011-09-07 06:08:21 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:21 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:21 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:21 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:21 --> Router Class Initialized
ERROR - 2011-09-07 06:08:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:08:24 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:24 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Router Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Output Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Input Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:08:24 --> Language Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Loader Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Controller Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:08:24 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:08:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:08:24 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:08:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:08:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:08:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:08:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:08:24 --> Final output sent to browser
DEBUG - 2011-09-07 06:08:24 --> Total execution time: 0.2341
DEBUG - 2011-09-07 06:08:25 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:25 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:25 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:25 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:25 --> Router Class Initialized
ERROR - 2011-09-07 06:08:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:08:32 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:32 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Router Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Output Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Input Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:08:32 --> Language Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Loader Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Controller Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:08:32 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:08:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:08:32 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:08:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:08:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:08:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:08:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:08:32 --> Final output sent to browser
DEBUG - 2011-09-07 06:08:32 --> Total execution time: 0.2645
DEBUG - 2011-09-07 06:08:33 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:33 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:33 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:33 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:33 --> Router Class Initialized
ERROR - 2011-09-07 06:08:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:08:39 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:39 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Router Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Output Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Input Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:08:39 --> Language Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Loader Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Controller Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:08:39 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:08:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:08:40 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:08:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:08:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:08:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:08:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:08:40 --> Final output sent to browser
DEBUG - 2011-09-07 06:08:40 --> Total execution time: 0.3534
DEBUG - 2011-09-07 06:08:41 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:41 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:41 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:41 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:41 --> Router Class Initialized
ERROR - 2011-09-07 06:08:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:08:46 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:46 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Router Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Output Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Input Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:08:46 --> Language Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Loader Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Controller Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:08:46 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:08:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:08:46 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:08:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:08:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:08:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:08:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:08:46 --> Final output sent to browser
DEBUG - 2011-09-07 06:08:46 --> Total execution time: 0.7538
DEBUG - 2011-09-07 06:08:47 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:47 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:47 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:47 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:47 --> Router Class Initialized
ERROR - 2011-09-07 06:08:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:08:51 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:51 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Router Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Output Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Input Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:08:51 --> Language Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Loader Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Controller Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Model Class Initialized
DEBUG - 2011-09-07 06:08:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:08:51 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:08:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:08:52 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:08:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:08:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:08:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:08:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:08:52 --> Final output sent to browser
DEBUG - 2011-09-07 06:08:52 --> Total execution time: 0.2137
DEBUG - 2011-09-07 06:08:53 --> Config Class Initialized
DEBUG - 2011-09-07 06:08:53 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:08:53 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:08:53 --> URI Class Initialized
DEBUG - 2011-09-07 06:08:53 --> Router Class Initialized
ERROR - 2011-09-07 06:08:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:09:00 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:00 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:00 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:00 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:00 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:00 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:00 --> Total execution time: 0.0460
DEBUG - 2011-09-07 06:09:01 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:01 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:01 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:01 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:01 --> Router Class Initialized
ERROR - 2011-09-07 06:09:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:09:06 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:06 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:06 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:06 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:07 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:07 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:07 --> Total execution time: 0.2594
DEBUG - 2011-09-07 06:09:07 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:07 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:07 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:07 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:07 --> Router Class Initialized
ERROR - 2011-09-07 06:09:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:09:11 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:11 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:11 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:11 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:11 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:11 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:11 --> Total execution time: 0.0506
DEBUG - 2011-09-07 06:09:12 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:12 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:12 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:12 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:12 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:12 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:12 --> Total execution time: 0.0483
DEBUG - 2011-09-07 06:09:12 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:12 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:12 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:12 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:13 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:13 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:13 --> Total execution time: 0.5157
DEBUG - 2011-09-07 06:09:14 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:14 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:14 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:14 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:14 --> Router Class Initialized
ERROR - 2011-09-07 06:09:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:09:20 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:20 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:20 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:20 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:20 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:20 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:20 --> Total execution time: 0.0621
DEBUG - 2011-09-07 06:09:21 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:21 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:21 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:21 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:21 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:21 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:21 --> Total execution time: 0.0781
DEBUG - 2011-09-07 06:09:22 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:22 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:22 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:22 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:22 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:22 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:22 --> Total execution time: 0.0479
DEBUG - 2011-09-07 06:09:22 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:22 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:22 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:22 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:22 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:22 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:22 --> Total execution time: 0.0414
DEBUG - 2011-09-07 06:09:23 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:23 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:23 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:23 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:23 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:23 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:23 --> Total execution time: 0.0588
DEBUG - 2011-09-07 06:09:24 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:24 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:24 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:24 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:24 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:24 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:24 --> Total execution time: 0.0561
DEBUG - 2011-09-07 06:09:24 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:24 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:24 --> Router Class Initialized
ERROR - 2011-09-07 06:09:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:09:25 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:25 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:25 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:25 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:25 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:25 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:25 --> Total execution time: 0.0553
DEBUG - 2011-09-07 06:09:26 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:26 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:26 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:26 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:26 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:26 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:26 --> Total execution time: 0.0847
DEBUG - 2011-09-07 06:09:27 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:27 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:27 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:27 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:27 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:27 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:27 --> Total execution time: 0.0719
DEBUG - 2011-09-07 06:09:32 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:32 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:32 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:32 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:32 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:32 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:32 --> Total execution time: 0.0467
DEBUG - 2011-09-07 06:09:33 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:33 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:33 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:33 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:33 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:33 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:33 --> Total execution time: 0.1297
DEBUG - 2011-09-07 06:09:34 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:34 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:34 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:34 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:34 --> Router Class Initialized
ERROR - 2011-09-07 06:09:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 06:09:36 --> Config Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Hooks Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Utf8 Class Initialized
DEBUG - 2011-09-07 06:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 06:09:36 --> URI Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Router Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Output Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Input Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 06:09:36 --> Language Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Loader Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Controller Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Model Class Initialized
DEBUG - 2011-09-07 06:09:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 06:09:36 --> Database Driver Class Initialized
DEBUG - 2011-09-07 06:09:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 06:09:36 --> Helper loaded: url_helper
DEBUG - 2011-09-07 06:09:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 06:09:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 06:09:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 06:09:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 06:09:36 --> Final output sent to browser
DEBUG - 2011-09-07 06:09:36 --> Total execution time: 0.0440
DEBUG - 2011-09-07 07:56:03 --> Config Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Hooks Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Utf8 Class Initialized
DEBUG - 2011-09-07 07:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 07:56:03 --> URI Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Router Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Output Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Input Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 07:56:03 --> Language Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Loader Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Controller Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 07:56:03 --> Database Driver Class Initialized
DEBUG - 2011-09-07 07:56:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 07:56:04 --> Helper loaded: url_helper
DEBUG - 2011-09-07 07:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 07:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 07:56:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 07:56:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 07:56:04 --> Final output sent to browser
DEBUG - 2011-09-07 07:56:04 --> Total execution time: 1.0231
DEBUG - 2011-09-07 07:56:07 --> Config Class Initialized
DEBUG - 2011-09-07 07:56:07 --> Hooks Class Initialized
DEBUG - 2011-09-07 07:56:07 --> Utf8 Class Initialized
DEBUG - 2011-09-07 07:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 07:56:07 --> URI Class Initialized
DEBUG - 2011-09-07 07:56:07 --> Router Class Initialized
ERROR - 2011-09-07 07:56:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 07:56:20 --> Config Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Hooks Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Utf8 Class Initialized
DEBUG - 2011-09-07 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 07:56:20 --> URI Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Router Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Output Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Input Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 07:56:20 --> Language Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Loader Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Controller Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 07:56:20 --> Database Driver Class Initialized
DEBUG - 2011-09-07 07:56:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 07:56:20 --> Helper loaded: url_helper
DEBUG - 2011-09-07 07:56:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 07:56:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 07:56:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 07:56:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 07:56:20 --> Final output sent to browser
DEBUG - 2011-09-07 07:56:20 --> Total execution time: 0.4612
DEBUG - 2011-09-07 07:56:23 --> Config Class Initialized
DEBUG - 2011-09-07 07:56:23 --> Hooks Class Initialized
DEBUG - 2011-09-07 07:56:23 --> Utf8 Class Initialized
DEBUG - 2011-09-07 07:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 07:56:23 --> URI Class Initialized
DEBUG - 2011-09-07 07:56:23 --> Router Class Initialized
ERROR - 2011-09-07 07:56:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 07:56:24 --> Config Class Initialized
DEBUG - 2011-09-07 07:56:24 --> Hooks Class Initialized
DEBUG - 2011-09-07 07:56:24 --> Utf8 Class Initialized
DEBUG - 2011-09-07 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 07:56:24 --> URI Class Initialized
DEBUG - 2011-09-07 07:56:24 --> Router Class Initialized
ERROR - 2011-09-07 07:56:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 07:56:44 --> Config Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Hooks Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Utf8 Class Initialized
DEBUG - 2011-09-07 07:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 07:56:44 --> URI Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Router Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Output Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Input Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 07:56:44 --> Language Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Loader Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Controller Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Model Class Initialized
DEBUG - 2011-09-07 07:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 07:56:44 --> Database Driver Class Initialized
DEBUG - 2011-09-07 07:56:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 07:56:45 --> Helper loaded: url_helper
DEBUG - 2011-09-07 07:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 07:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 07:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 07:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 07:56:45 --> Final output sent to browser
DEBUG - 2011-09-07 07:56:45 --> Total execution time: 0.2934
DEBUG - 2011-09-07 07:56:48 --> Config Class Initialized
DEBUG - 2011-09-07 07:56:48 --> Hooks Class Initialized
DEBUG - 2011-09-07 07:56:48 --> Utf8 Class Initialized
DEBUG - 2011-09-07 07:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 07:56:48 --> URI Class Initialized
DEBUG - 2011-09-07 07:56:48 --> Router Class Initialized
ERROR - 2011-09-07 07:56:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 08:26:02 --> Config Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:26:02 --> URI Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Router Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Output Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Input Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:26:02 --> Language Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Loader Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Controller Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:26:02 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:26:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:26:03 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:26:03 --> Final output sent to browser
DEBUG - 2011-09-07 08:26:03 --> Total execution time: 1.1061
DEBUG - 2011-09-07 08:26:08 --> Config Class Initialized
DEBUG - 2011-09-07 08:26:08 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:26:08 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:26:08 --> URI Class Initialized
DEBUG - 2011-09-07 08:26:08 --> Router Class Initialized
ERROR - 2011-09-07 08:26:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 08:26:24 --> Config Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:26:24 --> URI Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Router Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Output Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Input Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:26:24 --> Language Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Loader Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Controller Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:26:24 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:26:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:26:25 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:26:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:26:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:26:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:26:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:26:25 --> Final output sent to browser
DEBUG - 2011-09-07 08:26:25 --> Total execution time: 0.4979
DEBUG - 2011-09-07 08:26:26 --> Config Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:26:26 --> URI Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Router Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Output Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Input Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:26:26 --> Language Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Loader Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Controller Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:26:26 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:26:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:26:26 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:26:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:26:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:26:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:26:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:26:26 --> Final output sent to browser
DEBUG - 2011-09-07 08:26:26 --> Total execution time: 0.0428
DEBUG - 2011-09-07 08:26:28 --> Config Class Initialized
DEBUG - 2011-09-07 08:26:28 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:26:28 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:26:28 --> URI Class Initialized
DEBUG - 2011-09-07 08:26:28 --> Router Class Initialized
ERROR - 2011-09-07 08:26:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 08:26:58 --> Config Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:26:58 --> URI Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Router Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Output Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Input Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:26:58 --> Language Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Loader Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Controller Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Model Class Initialized
DEBUG - 2011-09-07 08:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:26:58 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:26:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:26:58 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:26:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:26:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:26:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:26:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:26:58 --> Final output sent to browser
DEBUG - 2011-09-07 08:26:58 --> Total execution time: 0.2980
DEBUG - 2011-09-07 08:27:03 --> Config Class Initialized
DEBUG - 2011-09-07 08:27:03 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:27:03 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:27:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:27:03 --> URI Class Initialized
DEBUG - 2011-09-07 08:27:03 --> Router Class Initialized
ERROR - 2011-09-07 08:27:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 08:27:05 --> Config Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:27:05 --> URI Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Router Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Output Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Input Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:27:05 --> Language Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Loader Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Controller Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Model Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Model Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Model Class Initialized
DEBUG - 2011-09-07 08:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:27:05 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:27:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:27:05 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:27:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:27:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:27:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:27:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:27:05 --> Final output sent to browser
DEBUG - 2011-09-07 08:27:05 --> Total execution time: 0.0527
DEBUG - 2011-09-07 08:27:34 --> Config Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:27:34 --> URI Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Router Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Output Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Input Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:27:34 --> Language Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Loader Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Controller Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Model Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Model Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Model Class Initialized
DEBUG - 2011-09-07 08:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:27:34 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:27:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:27:34 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:27:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:27:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:27:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:27:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:27:34 --> Final output sent to browser
DEBUG - 2011-09-07 08:27:34 --> Total execution time: 0.2892
DEBUG - 2011-09-07 08:27:37 --> Config Class Initialized
DEBUG - 2011-09-07 08:27:37 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:27:37 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:27:37 --> URI Class Initialized
DEBUG - 2011-09-07 08:27:37 --> Router Class Initialized
ERROR - 2011-09-07 08:27:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 08:28:02 --> Config Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:28:02 --> URI Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Router Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Output Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Input Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:28:02 --> Language Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Loader Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Controller Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:28:02 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:28:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:28:03 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:28:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:28:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:28:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:28:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:28:03 --> Final output sent to browser
DEBUG - 2011-09-07 08:28:03 --> Total execution time: 1.0252
DEBUG - 2011-09-07 08:28:05 --> Config Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:28:05 --> URI Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Router Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Output Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Input Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:28:05 --> Language Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Loader Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Controller Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:28:05 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:28:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:28:05 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:28:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:28:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:28:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:28:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:28:05 --> Final output sent to browser
DEBUG - 2011-09-07 08:28:05 --> Total execution time: 0.0839
DEBUG - 2011-09-07 08:28:07 --> Config Class Initialized
DEBUG - 2011-09-07 08:28:07 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:28:07 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:28:07 --> URI Class Initialized
DEBUG - 2011-09-07 08:28:07 --> Router Class Initialized
ERROR - 2011-09-07 08:28:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 08:28:23 --> Config Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:28:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:28:23 --> URI Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Router Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Output Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Input Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:28:23 --> Language Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Loader Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Controller Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Model Class Initialized
DEBUG - 2011-09-07 08:28:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:28:23 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:28:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 08:28:23 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:28:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:28:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:28:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:28:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:28:23 --> Final output sent to browser
DEBUG - 2011-09-07 08:28:23 --> Total execution time: 0.4446
DEBUG - 2011-09-07 08:28:26 --> Config Class Initialized
DEBUG - 2011-09-07 08:28:26 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:28:26 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:28:26 --> URI Class Initialized
DEBUG - 2011-09-07 08:28:26 --> Router Class Initialized
ERROR - 2011-09-07 08:28:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 08:35:54 --> Config Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:35:54 --> URI Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Router Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Output Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Input Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:35:54 --> Language Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Loader Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Controller Class Initialized
ERROR - 2011-09-07 08:35:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 08:35:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 08:35:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 08:35:54 --> Model Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Model Class Initialized
DEBUG - 2011-09-07 08:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:35:54 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:35:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 08:35:54 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:35:54 --> Final output sent to browser
DEBUG - 2011-09-07 08:35:54 --> Total execution time: 0.1288
DEBUG - 2011-09-07 08:35:57 --> Config Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:35:57 --> URI Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Router Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Output Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Input Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:35:57 --> Language Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Loader Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Controller Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Model Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Model Class Initialized
DEBUG - 2011-09-07 08:35:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:35:57 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:35:58 --> Final output sent to browser
DEBUG - 2011-09-07 08:35:58 --> Total execution time: 0.6024
DEBUG - 2011-09-07 08:36:00 --> Config Class Initialized
DEBUG - 2011-09-07 08:36:00 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:36:00 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:36:00 --> URI Class Initialized
DEBUG - 2011-09-07 08:36:00 --> Router Class Initialized
ERROR - 2011-09-07 08:36:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 08:36:25 --> Config Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:36:25 --> URI Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Router Class Initialized
ERROR - 2011-09-07 08:36:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-07 08:36:25 --> Config Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:36:25 --> URI Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Router Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Output Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Input Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:36:25 --> Language Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Loader Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Controller Class Initialized
ERROR - 2011-09-07 08:36:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 08:36:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 08:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 08:36:25 --> Model Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Model Class Initialized
DEBUG - 2011-09-07 08:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:36:25 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 08:36:25 --> Helper loaded: url_helper
DEBUG - 2011-09-07 08:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 08:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 08:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 08:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 08:36:25 --> Final output sent to browser
DEBUG - 2011-09-07 08:36:25 --> Total execution time: 0.0277
DEBUG - 2011-09-07 08:36:27 --> Config Class Initialized
DEBUG - 2011-09-07 08:36:27 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:36:27 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:36:27 --> URI Class Initialized
DEBUG - 2011-09-07 08:36:27 --> Router Class Initialized
ERROR - 2011-09-07 08:36:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-07 08:36:28 --> Config Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Hooks Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Utf8 Class Initialized
DEBUG - 2011-09-07 08:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 08:36:28 --> URI Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Router Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Output Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Input Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 08:36:28 --> Language Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Loader Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Controller Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Model Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Model Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 08:36:28 --> Database Driver Class Initialized
DEBUG - 2011-09-07 08:36:28 --> Final output sent to browser
DEBUG - 2011-09-07 08:36:28 --> Total execution time: 0.3253
DEBUG - 2011-09-07 09:22:40 --> Config Class Initialized
DEBUG - 2011-09-07 09:22:40 --> Hooks Class Initialized
DEBUG - 2011-09-07 09:22:40 --> Utf8 Class Initialized
DEBUG - 2011-09-07 09:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 09:22:40 --> URI Class Initialized
DEBUG - 2011-09-07 09:22:40 --> Router Class Initialized
ERROR - 2011-09-07 09:22:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-07 10:27:39 --> Config Class Initialized
DEBUG - 2011-09-07 10:27:39 --> Hooks Class Initialized
DEBUG - 2011-09-07 10:27:39 --> Utf8 Class Initialized
DEBUG - 2011-09-07 10:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 10:27:39 --> URI Class Initialized
DEBUG - 2011-09-07 10:27:39 --> Router Class Initialized
DEBUG - 2011-09-07 10:27:39 --> No URI present. Default controller set.
DEBUG - 2011-09-07 10:27:39 --> Output Class Initialized
DEBUG - 2011-09-07 10:27:39 --> Input Class Initialized
DEBUG - 2011-09-07 10:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 10:27:39 --> Language Class Initialized
DEBUG - 2011-09-07 10:27:39 --> Loader Class Initialized
DEBUG - 2011-09-07 10:27:39 --> Controller Class Initialized
DEBUG - 2011-09-07 10:27:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-07 10:27:39 --> Helper loaded: url_helper
DEBUG - 2011-09-07 10:27:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 10:27:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 10:27:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 10:27:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 10:27:39 --> Final output sent to browser
DEBUG - 2011-09-07 10:27:39 --> Total execution time: 0.1846
DEBUG - 2011-09-07 10:44:48 --> Config Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Hooks Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Utf8 Class Initialized
DEBUG - 2011-09-07 10:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 10:44:48 --> URI Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Router Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Output Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Input Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 10:44:48 --> Language Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Loader Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Controller Class Initialized
ERROR - 2011-09-07 10:44:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 10:44:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 10:44:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 10:44:48 --> Model Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Model Class Initialized
DEBUG - 2011-09-07 10:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 10:44:48 --> Database Driver Class Initialized
DEBUG - 2011-09-07 10:44:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 10:44:48 --> Helper loaded: url_helper
DEBUG - 2011-09-07 10:44:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 10:44:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 10:44:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 10:44:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 10:44:48 --> Final output sent to browser
DEBUG - 2011-09-07 10:44:48 --> Total execution time: 0.2293
DEBUG - 2011-09-07 10:44:53 --> Config Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Hooks Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Utf8 Class Initialized
DEBUG - 2011-09-07 10:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 10:44:53 --> URI Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Router Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Output Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Input Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 10:44:53 --> Language Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Loader Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Controller Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Model Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Model Class Initialized
DEBUG - 2011-09-07 10:44:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 10:44:53 --> Database Driver Class Initialized
DEBUG - 2011-09-07 10:44:55 --> Final output sent to browser
DEBUG - 2011-09-07 10:44:55 --> Total execution time: 1.9720
DEBUG - 2011-09-07 10:45:03 --> Config Class Initialized
DEBUG - 2011-09-07 10:45:03 --> Hooks Class Initialized
DEBUG - 2011-09-07 10:45:03 --> Utf8 Class Initialized
DEBUG - 2011-09-07 10:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 10:45:03 --> URI Class Initialized
DEBUG - 2011-09-07 10:45:03 --> Router Class Initialized
ERROR - 2011-09-07 10:45:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 10:47:12 --> Config Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Hooks Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Utf8 Class Initialized
DEBUG - 2011-09-07 10:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 10:47:12 --> URI Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Router Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Output Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Input Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 10:47:12 --> Language Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Loader Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Controller Class Initialized
ERROR - 2011-09-07 10:47:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 10:47:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 10:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 10:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 10:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 10:47:12 --> Database Driver Class Initialized
DEBUG - 2011-09-07 10:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 10:47:12 --> Helper loaded: url_helper
DEBUG - 2011-09-07 10:47:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 10:47:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 10:47:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 10:47:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 10:47:12 --> Final output sent to browser
DEBUG - 2011-09-07 10:47:12 --> Total execution time: 0.0331
DEBUG - 2011-09-07 10:47:13 --> Config Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Hooks Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Utf8 Class Initialized
DEBUG - 2011-09-07 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 10:47:13 --> URI Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Router Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Output Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Input Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 10:47:13 --> Language Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Loader Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Controller Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Model Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Model Class Initialized
DEBUG - 2011-09-07 10:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 10:47:13 --> Database Driver Class Initialized
DEBUG - 2011-09-07 10:47:14 --> Final output sent to browser
DEBUG - 2011-09-07 10:47:14 --> Total execution time: 0.5763
DEBUG - 2011-09-07 11:49:38 --> Config Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Hooks Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Utf8 Class Initialized
DEBUG - 2011-09-07 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 11:49:38 --> URI Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Router Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Output Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Input Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 11:49:38 --> Language Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Loader Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Controller Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Model Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Model Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Model Class Initialized
DEBUG - 2011-09-07 11:49:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 11:49:38 --> Database Driver Class Initialized
DEBUG - 2011-09-07 11:49:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 11:49:39 --> Helper loaded: url_helper
DEBUG - 2011-09-07 11:49:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 11:49:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 11:49:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 11:49:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 11:49:39 --> Final output sent to browser
DEBUG - 2011-09-07 11:49:39 --> Total execution time: 1.0164
DEBUG - 2011-09-07 11:49:43 --> Config Class Initialized
DEBUG - 2011-09-07 11:49:43 --> Hooks Class Initialized
DEBUG - 2011-09-07 11:49:43 --> Utf8 Class Initialized
DEBUG - 2011-09-07 11:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 11:49:43 --> URI Class Initialized
DEBUG - 2011-09-07 11:49:43 --> Router Class Initialized
ERROR - 2011-09-07 11:49:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 11:49:50 --> Config Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Hooks Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Utf8 Class Initialized
DEBUG - 2011-09-07 11:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 11:49:50 --> URI Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Router Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Output Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Input Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 11:49:50 --> Language Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Loader Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Controller Class Initialized
ERROR - 2011-09-07 11:49:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 11:49:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 11:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 11:49:50 --> Model Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Model Class Initialized
DEBUG - 2011-09-07 11:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 11:49:50 --> Database Driver Class Initialized
DEBUG - 2011-09-07 11:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 11:49:50 --> Helper loaded: url_helper
DEBUG - 2011-09-07 11:49:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 11:49:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 11:49:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 11:49:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 11:49:50 --> Final output sent to browser
DEBUG - 2011-09-07 11:49:50 --> Total execution time: 0.1363
DEBUG - 2011-09-07 11:49:51 --> Config Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Hooks Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Utf8 Class Initialized
DEBUG - 2011-09-07 11:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 11:49:51 --> URI Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Router Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Output Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Input Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 11:49:51 --> Language Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Loader Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Controller Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Model Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Model Class Initialized
DEBUG - 2011-09-07 11:49:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 11:49:51 --> Database Driver Class Initialized
DEBUG - 2011-09-07 11:49:52 --> Final output sent to browser
DEBUG - 2011-09-07 11:49:52 --> Total execution time: 0.8281
DEBUG - 2011-09-07 11:49:52 --> Config Class Initialized
DEBUG - 2011-09-07 11:49:52 --> Hooks Class Initialized
DEBUG - 2011-09-07 11:49:52 --> Utf8 Class Initialized
DEBUG - 2011-09-07 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 11:49:52 --> URI Class Initialized
DEBUG - 2011-09-07 11:49:52 --> Router Class Initialized
ERROR - 2011-09-07 11:49:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 12:47:02 --> Config Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:47:02 --> URI Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Router Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Output Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Input Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:47:02 --> Language Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Loader Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Controller Class Initialized
ERROR - 2011-09-07 12:47:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 12:47:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 12:47:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:47:02 --> Model Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Model Class Initialized
DEBUG - 2011-09-07 12:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:47:02 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:47:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:47:02 --> Helper loaded: url_helper
DEBUG - 2011-09-07 12:47:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 12:47:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 12:47:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 12:47:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 12:47:02 --> Final output sent to browser
DEBUG - 2011-09-07 12:47:02 --> Total execution time: 0.1326
DEBUG - 2011-09-07 12:47:05 --> Config Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:47:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:47:05 --> URI Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Router Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Output Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Input Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:47:05 --> Language Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Loader Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Controller Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Model Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Model Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:47:05 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:47:05 --> Final output sent to browser
DEBUG - 2011-09-07 12:47:05 --> Total execution time: 0.5649
DEBUG - 2011-09-07 12:48:15 --> Config Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:48:15 --> URI Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Router Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Output Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Input Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:48:15 --> Language Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Loader Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Controller Class Initialized
ERROR - 2011-09-07 12:48:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 12:48:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 12:48:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:48:15 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:48:15 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:48:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:48:15 --> Helper loaded: url_helper
DEBUG - 2011-09-07 12:48:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 12:48:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 12:48:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 12:48:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 12:48:15 --> Final output sent to browser
DEBUG - 2011-09-07 12:48:15 --> Total execution time: 0.0304
DEBUG - 2011-09-07 12:48:16 --> Config Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:48:16 --> URI Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Router Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Output Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Input Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:48:16 --> Language Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Loader Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Controller Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:48:16 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:48:16 --> Final output sent to browser
DEBUG - 2011-09-07 12:48:16 --> Total execution time: 0.5470
DEBUG - 2011-09-07 12:48:45 --> Config Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:48:45 --> URI Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Router Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Output Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Input Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:48:45 --> Language Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Loader Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Controller Class Initialized
ERROR - 2011-09-07 12:48:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 12:48:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 12:48:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:48:45 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:48:45 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:48:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:48:45 --> Helper loaded: url_helper
DEBUG - 2011-09-07 12:48:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 12:48:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 12:48:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 12:48:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 12:48:45 --> Final output sent to browser
DEBUG - 2011-09-07 12:48:45 --> Total execution time: 0.0723
DEBUG - 2011-09-07 12:48:47 --> Config Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:48:47 --> URI Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Router Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Output Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Input Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:48:47 --> Language Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Loader Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Controller Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:48:47 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:48:47 --> Final output sent to browser
DEBUG - 2011-09-07 12:48:47 --> Total execution time: 0.5945
DEBUG - 2011-09-07 12:48:54 --> Config Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:48:54 --> URI Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Router Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Output Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Input Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:48:54 --> Language Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Loader Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Controller Class Initialized
ERROR - 2011-09-07 12:48:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 12:48:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 12:48:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:48:54 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:48:54 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:48:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:48:54 --> Helper loaded: url_helper
DEBUG - 2011-09-07 12:48:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 12:48:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 12:48:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 12:48:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 12:48:54 --> Final output sent to browser
DEBUG - 2011-09-07 12:48:54 --> Total execution time: 0.0268
DEBUG - 2011-09-07 12:48:55 --> Config Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:48:55 --> URI Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Router Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Output Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Input Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:48:55 --> Language Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Loader Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Controller Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Model Class Initialized
DEBUG - 2011-09-07 12:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:48:55 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:48:56 --> Final output sent to browser
DEBUG - 2011-09-07 12:48:56 --> Total execution time: 0.6753
DEBUG - 2011-09-07 12:49:43 --> Config Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:49:43 --> URI Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Router Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Output Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Input Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:49:43 --> Language Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Loader Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Controller Class Initialized
ERROR - 2011-09-07 12:49:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 12:49:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 12:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:49:43 --> Model Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Model Class Initialized
DEBUG - 2011-09-07 12:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:49:43 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:49:43 --> Helper loaded: url_helper
DEBUG - 2011-09-07 12:49:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 12:49:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 12:49:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 12:49:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 12:49:43 --> Final output sent to browser
DEBUG - 2011-09-07 12:49:43 --> Total execution time: 0.0332
DEBUG - 2011-09-07 12:49:44 --> Config Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:49:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:49:44 --> URI Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Router Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Output Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Input Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:49:44 --> Language Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Loader Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Controller Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Model Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Model Class Initialized
DEBUG - 2011-09-07 12:49:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:49:44 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:49:45 --> Final output sent to browser
DEBUG - 2011-09-07 12:49:45 --> Total execution time: 1.3762
DEBUG - 2011-09-07 12:49:46 --> Config Class Initialized
DEBUG - 2011-09-07 12:49:46 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:49:46 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:49:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:49:46 --> URI Class Initialized
DEBUG - 2011-09-07 12:49:46 --> Router Class Initialized
ERROR - 2011-09-07 12:49:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-07 12:49:47 --> Config Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:49:47 --> URI Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Router Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Output Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Input Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:49:47 --> Language Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Loader Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Controller Class Initialized
ERROR - 2011-09-07 12:49:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 12:49:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 12:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:49:47 --> Model Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Model Class Initialized
DEBUG - 2011-09-07 12:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:49:47 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:49:47 --> Helper loaded: url_helper
DEBUG - 2011-09-07 12:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 12:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 12:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 12:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 12:49:47 --> Final output sent to browser
DEBUG - 2011-09-07 12:49:47 --> Total execution time: 0.0301
DEBUG - 2011-09-07 12:50:00 --> Config Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:50:00 --> URI Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Router Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Output Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Input Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:50:00 --> Language Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Loader Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Controller Class Initialized
ERROR - 2011-09-07 12:50:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 12:50:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 12:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:50:00 --> Model Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Model Class Initialized
DEBUG - 2011-09-07 12:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:50:00 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:50:00 --> Helper loaded: url_helper
DEBUG - 2011-09-07 12:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 12:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 12:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 12:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 12:50:00 --> Final output sent to browser
DEBUG - 2011-09-07 12:50:00 --> Total execution time: 0.1023
DEBUG - 2011-09-07 12:50:02 --> Config Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:50:02 --> URI Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Router Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Output Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Input Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:50:02 --> Language Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Loader Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Controller Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Model Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Model Class Initialized
DEBUG - 2011-09-07 12:50:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:50:02 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:50:03 --> Final output sent to browser
DEBUG - 2011-09-07 12:50:03 --> Total execution time: 0.5684
DEBUG - 2011-09-07 12:50:04 --> Config Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Hooks Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Utf8 Class Initialized
DEBUG - 2011-09-07 12:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 12:50:04 --> URI Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Router Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Output Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Input Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 12:50:04 --> Language Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Loader Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Controller Class Initialized
ERROR - 2011-09-07 12:50:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 12:50:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 12:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:50:04 --> Model Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Model Class Initialized
DEBUG - 2011-09-07 12:50:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 12:50:04 --> Database Driver Class Initialized
DEBUG - 2011-09-07 12:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 12:50:04 --> Helper loaded: url_helper
DEBUG - 2011-09-07 12:50:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 12:50:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 12:50:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 12:50:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 12:50:04 --> Final output sent to browser
DEBUG - 2011-09-07 12:50:04 --> Total execution time: 0.0280
DEBUG - 2011-09-07 13:00:42 --> Config Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:00:42 --> URI Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Router Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Output Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Input Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:00:42 --> Language Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Loader Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Controller Class Initialized
ERROR - 2011-09-07 13:00:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 13:00:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 13:00:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 13:00:42 --> Model Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Model Class Initialized
DEBUG - 2011-09-07 13:00:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:00:42 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:00:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 13:00:42 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:00:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:00:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:00:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:00:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:00:42 --> Final output sent to browser
DEBUG - 2011-09-07 13:00:42 --> Total execution time: 0.0311
DEBUG - 2011-09-07 13:00:44 --> Config Class Initialized
DEBUG - 2011-09-07 13:00:44 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:00:44 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:00:44 --> URI Class Initialized
DEBUG - 2011-09-07 13:00:44 --> Router Class Initialized
DEBUG - 2011-09-07 13:00:44 --> Output Class Initialized
DEBUG - 2011-09-07 13:00:44 --> Input Class Initialized
DEBUG - 2011-09-07 13:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:00:44 --> Language Class Initialized
DEBUG - 2011-09-07 13:00:45 --> Loader Class Initialized
DEBUG - 2011-09-07 13:00:45 --> Controller Class Initialized
DEBUG - 2011-09-07 13:00:45 --> Model Class Initialized
DEBUG - 2011-09-07 13:00:45 --> Model Class Initialized
DEBUG - 2011-09-07 13:00:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:00:45 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:00:45 --> Final output sent to browser
DEBUG - 2011-09-07 13:00:45 --> Total execution time: 0.6089
DEBUG - 2011-09-07 13:00:47 --> Config Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:00:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:00:47 --> URI Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Router Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Output Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Input Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:00:47 --> Language Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Loader Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Controller Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Model Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Model Class Initialized
DEBUG - 2011-09-07 13:00:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:00:47 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:00:48 --> Final output sent to browser
DEBUG - 2011-09-07 13:00:48 --> Total execution time: 0.6442
DEBUG - 2011-09-07 13:24:40 --> Config Class Initialized
DEBUG - 2011-09-07 13:24:40 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:24:40 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:24:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:24:40 --> URI Class Initialized
DEBUG - 2011-09-07 13:24:40 --> Router Class Initialized
DEBUG - 2011-09-07 13:24:40 --> No URI present. Default controller set.
DEBUG - 2011-09-07 13:24:40 --> Output Class Initialized
DEBUG - 2011-09-07 13:24:40 --> Input Class Initialized
DEBUG - 2011-09-07 13:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:24:40 --> Language Class Initialized
DEBUG - 2011-09-07 13:24:40 --> Loader Class Initialized
DEBUG - 2011-09-07 13:24:40 --> Controller Class Initialized
DEBUG - 2011-09-07 13:24:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-07 13:24:40 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:24:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:24:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:24:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:24:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:24:40 --> Final output sent to browser
DEBUG - 2011-09-07 13:24:40 --> Total execution time: 0.0817
DEBUG - 2011-09-07 13:45:21 --> Config Class Initialized
DEBUG - 2011-09-07 13:45:21 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:45:21 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:45:21 --> URI Class Initialized
DEBUG - 2011-09-07 13:45:21 --> Router Class Initialized
DEBUG - 2011-09-07 13:45:21 --> Output Class Initialized
DEBUG - 2011-09-07 13:45:21 --> Input Class Initialized
DEBUG - 2011-09-07 13:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:45:21 --> Language Class Initialized
DEBUG - 2011-09-07 13:45:22 --> Loader Class Initialized
DEBUG - 2011-09-07 13:45:22 --> Controller Class Initialized
DEBUG - 2011-09-07 13:45:22 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:22 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:22 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:45:22 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:45:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:45:22 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:45:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:45:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:45:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:45:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:45:22 --> Final output sent to browser
DEBUG - 2011-09-07 13:45:22 --> Total execution time: 1.2714
DEBUG - 2011-09-07 13:45:27 --> Config Class Initialized
DEBUG - 2011-09-07 13:45:27 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:45:27 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:45:27 --> URI Class Initialized
DEBUG - 2011-09-07 13:45:27 --> Router Class Initialized
ERROR - 2011-09-07 13:45:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 13:45:31 --> Config Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:45:31 --> URI Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Router Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Output Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Input Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:45:31 --> Language Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Loader Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Controller Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:45:31 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:45:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:45:31 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:45:31 --> Final output sent to browser
DEBUG - 2011-09-07 13:45:31 --> Total execution time: 0.5408
DEBUG - 2011-09-07 13:45:37 --> Config Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:45:37 --> URI Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Router Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Output Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Input Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:45:37 --> Language Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Loader Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Controller Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:45:37 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:45:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:45:37 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:45:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:45:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:45:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:45:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:45:37 --> Final output sent to browser
DEBUG - 2011-09-07 13:45:37 --> Total execution time: 0.0479
DEBUG - 2011-09-07 13:45:51 --> Config Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:45:51 --> URI Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Router Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Output Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Input Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:45:51 --> Language Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Loader Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Controller Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:45:51 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:45:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:45:51 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:45:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:45:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:45:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:45:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:45:51 --> Final output sent to browser
DEBUG - 2011-09-07 13:45:51 --> Total execution time: 0.3413
DEBUG - 2011-09-07 13:45:54 --> Config Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:45:54 --> URI Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Router Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Output Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Input Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:45:54 --> Language Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Loader Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Controller Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:45:54 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:45:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:45:54 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:45:54 --> Final output sent to browser
DEBUG - 2011-09-07 13:45:54 --> Total execution time: 0.0506
DEBUG - 2011-09-07 13:45:58 --> Config Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:45:58 --> URI Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Router Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Output Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Input Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:45:58 --> Language Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Loader Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Controller Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Model Class Initialized
DEBUG - 2011-09-07 13:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:45:58 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:45:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:45:58 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:45:58 --> Final output sent to browser
DEBUG - 2011-09-07 13:45:58 --> Total execution time: 0.2468
DEBUG - 2011-09-07 13:46:01 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:01 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:01 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:01 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:01 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:01 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:01 --> Total execution time: 0.0544
DEBUG - 2011-09-07 13:46:02 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:02 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:02 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:02 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:03 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:03 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:03 --> Total execution time: 0.6797
DEBUG - 2011-09-07 13:46:07 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:07 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:07 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:08 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:08 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:08 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:08 --> Total execution time: 0.6883
DEBUG - 2011-09-07 13:46:24 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:24 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:24 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:24 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:25 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:25 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:25 --> Total execution time: 0.4859
DEBUG - 2011-09-07 13:46:30 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:30 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:30 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:30 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:30 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:30 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:30 --> Total execution time: 0.2652
DEBUG - 2011-09-07 13:46:34 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:34 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:34 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:34 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:34 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:34 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:34 --> Total execution time: 0.3416
DEBUG - 2011-09-07 13:46:39 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:39 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:39 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:39 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:39 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:39 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:39 --> Total execution time: 0.2298
DEBUG - 2011-09-07 13:46:43 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:43 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:43 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:43 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:43 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:43 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:43 --> Total execution time: 0.3213
DEBUG - 2011-09-07 13:46:48 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:48 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:48 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:48 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:49 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:49 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:49 --> Total execution time: 0.5339
DEBUG - 2011-09-07 13:46:52 --> Config Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:46:52 --> URI Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Router Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Output Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Input Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:46:52 --> Language Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Loader Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Controller Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Model Class Initialized
DEBUG - 2011-09-07 13:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:46:52 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:46:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:46:53 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:46:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:46:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:46:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:46:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:46:53 --> Final output sent to browser
DEBUG - 2011-09-07 13:46:53 --> Total execution time: 0.5419
DEBUG - 2011-09-07 13:47:08 --> Config Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:47:08 --> URI Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Router Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Output Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Input Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:47:08 --> Language Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Loader Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Controller Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:47:08 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:47:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:47:08 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:47:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:47:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:47:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:47:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:47:08 --> Final output sent to browser
DEBUG - 2011-09-07 13:47:08 --> Total execution time: 0.5299
DEBUG - 2011-09-07 13:47:14 --> Config Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:47:14 --> URI Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Router Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Output Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Input Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:47:14 --> Language Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Loader Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Controller Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:47:14 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:47:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:47:14 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:47:14 --> Final output sent to browser
DEBUG - 2011-09-07 13:47:14 --> Total execution time: 0.2549
DEBUG - 2011-09-07 13:47:17 --> Config Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:47:17 --> URI Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Router Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Output Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Input Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:47:17 --> Language Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Loader Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Controller Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:47:17 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:47:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:47:17 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:47:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:47:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:47:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:47:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:47:17 --> Final output sent to browser
DEBUG - 2011-09-07 13:47:17 --> Total execution time: 0.1084
DEBUG - 2011-09-07 13:47:25 --> Config Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:47:25 --> URI Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Router Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Output Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Input Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:47:25 --> Language Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Loader Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Controller Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:47:25 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:47:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:47:26 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:47:26 --> Final output sent to browser
DEBUG - 2011-09-07 13:47:26 --> Total execution time: 0.3589
DEBUG - 2011-09-07 13:47:27 --> Config Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:47:27 --> URI Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Router Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Output Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Input Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:47:27 --> Language Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Loader Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Controller Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:47:27 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:47:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:47:27 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:47:27 --> Final output sent to browser
DEBUG - 2011-09-07 13:47:27 --> Total execution time: 0.0489
DEBUG - 2011-09-07 13:47:28 --> Config Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Hooks Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Utf8 Class Initialized
DEBUG - 2011-09-07 13:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 13:47:28 --> URI Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Router Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Output Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Input Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 13:47:28 --> Language Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Loader Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Controller Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Model Class Initialized
DEBUG - 2011-09-07 13:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 13:47:28 --> Database Driver Class Initialized
DEBUG - 2011-09-07 13:47:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 13:47:28 --> Helper loaded: url_helper
DEBUG - 2011-09-07 13:47:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 13:47:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 13:47:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 13:47:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 13:47:28 --> Final output sent to browser
DEBUG - 2011-09-07 13:47:28 --> Total execution time: 0.0814
DEBUG - 2011-09-07 14:45:48 --> Config Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:45:48 --> URI Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Router Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Output Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Input Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 14:45:48 --> Language Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Loader Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Controller Class Initialized
ERROR - 2011-09-07 14:45:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 14:45:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 14:45:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 14:45:48 --> Model Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Model Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 14:45:48 --> Database Driver Class Initialized
DEBUG - 2011-09-07 14:45:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 14:45:48 --> Helper loaded: url_helper
DEBUG - 2011-09-07 14:45:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 14:45:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 14:45:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 14:45:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 14:45:48 --> Final output sent to browser
DEBUG - 2011-09-07 14:45:48 --> Total execution time: 0.0671
DEBUG - 2011-09-07 14:45:48 --> Config Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:45:48 --> URI Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Router Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Output Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Input Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 14:45:48 --> Language Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Loader Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Controller Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Model Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Model Class Initialized
DEBUG - 2011-09-07 14:45:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 14:45:48 --> Database Driver Class Initialized
DEBUG - 2011-09-07 14:45:49 --> Final output sent to browser
DEBUG - 2011-09-07 14:45:49 --> Total execution time: 0.6335
DEBUG - 2011-09-07 14:45:50 --> Config Class Initialized
DEBUG - 2011-09-07 14:45:50 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:45:50 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:45:50 --> URI Class Initialized
DEBUG - 2011-09-07 14:45:50 --> Router Class Initialized
ERROR - 2011-09-07 14:45:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 14:45:50 --> Config Class Initialized
DEBUG - 2011-09-07 14:45:50 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:45:50 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:45:50 --> URI Class Initialized
DEBUG - 2011-09-07 14:45:50 --> Router Class Initialized
ERROR - 2011-09-07 14:45:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 14:46:20 --> Config Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:46:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:46:20 --> URI Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Router Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Output Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Input Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 14:46:20 --> Language Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Loader Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Controller Class Initialized
ERROR - 2011-09-07 14:46:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 14:46:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 14:46:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 14:46:20 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 14:46:20 --> Database Driver Class Initialized
DEBUG - 2011-09-07 14:46:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 14:46:20 --> Helper loaded: url_helper
DEBUG - 2011-09-07 14:46:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 14:46:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 14:46:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 14:46:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 14:46:20 --> Final output sent to browser
DEBUG - 2011-09-07 14:46:20 --> Total execution time: 0.0370
DEBUG - 2011-09-07 14:46:20 --> Config Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:46:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:46:20 --> URI Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Router Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Output Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Input Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 14:46:20 --> Language Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Loader Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Controller Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 14:46:20 --> Database Driver Class Initialized
DEBUG - 2011-09-07 14:46:21 --> Final output sent to browser
DEBUG - 2011-09-07 14:46:21 --> Total execution time: 0.5588
DEBUG - 2011-09-07 14:46:24 --> Config Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:46:24 --> URI Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Router Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Output Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Input Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 14:46:24 --> Language Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Loader Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Controller Class Initialized
ERROR - 2011-09-07 14:46:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 14:46:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 14:46:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 14:46:24 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 14:46:24 --> Database Driver Class Initialized
DEBUG - 2011-09-07 14:46:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 14:46:24 --> Helper loaded: url_helper
DEBUG - 2011-09-07 14:46:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 14:46:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 14:46:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 14:46:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 14:46:24 --> Final output sent to browser
DEBUG - 2011-09-07 14:46:24 --> Total execution time: 0.0311
DEBUG - 2011-09-07 14:46:40 --> Config Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:46:40 --> URI Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Router Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Output Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Input Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 14:46:40 --> Language Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Loader Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Controller Class Initialized
ERROR - 2011-09-07 14:46:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 14:46:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 14:46:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 14:46:40 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 14:46:40 --> Database Driver Class Initialized
DEBUG - 2011-09-07 14:46:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 14:46:40 --> Helper loaded: url_helper
DEBUG - 2011-09-07 14:46:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 14:46:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 14:46:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 14:46:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 14:46:40 --> Final output sent to browser
DEBUG - 2011-09-07 14:46:40 --> Total execution time: 0.0273
DEBUG - 2011-09-07 14:46:40 --> Config Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Hooks Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Utf8 Class Initialized
DEBUG - 2011-09-07 14:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 14:46:40 --> URI Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Router Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Output Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Input Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 14:46:40 --> Language Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Loader Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Controller Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Model Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 14:46:40 --> Database Driver Class Initialized
DEBUG - 2011-09-07 14:46:40 --> Final output sent to browser
DEBUG - 2011-09-07 14:46:40 --> Total execution time: 0.4500
DEBUG - 2011-09-07 15:46:03 --> Config Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:46:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:46:03 --> URI Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Router Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Output Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Input Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:46:03 --> Language Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Loader Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Controller Class Initialized
ERROR - 2011-09-07 15:46:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 15:46:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 15:46:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:46:03 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:46:03 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:46:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:46:03 --> Helper loaded: url_helper
DEBUG - 2011-09-07 15:46:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 15:46:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 15:46:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 15:46:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 15:46:03 --> Final output sent to browser
DEBUG - 2011-09-07 15:46:03 --> Total execution time: 0.0579
DEBUG - 2011-09-07 15:46:05 --> Config Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:46:05 --> URI Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Router Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Output Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Input Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:46:05 --> Language Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Loader Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Controller Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:46:05 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:46:07 --> Final output sent to browser
DEBUG - 2011-09-07 15:46:07 --> Total execution time: 1.6676
DEBUG - 2011-09-07 15:46:10 --> Config Class Initialized
DEBUG - 2011-09-07 15:46:10 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:46:10 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:46:10 --> URI Class Initialized
DEBUG - 2011-09-07 15:46:10 --> Router Class Initialized
ERROR - 2011-09-07 15:46:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 15:46:10 --> Config Class Initialized
DEBUG - 2011-09-07 15:46:10 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:46:10 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:46:10 --> URI Class Initialized
DEBUG - 2011-09-07 15:46:10 --> Router Class Initialized
ERROR - 2011-09-07 15:46:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 15:46:55 --> Config Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:46:55 --> URI Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Router Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Output Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Input Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:46:55 --> Language Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Loader Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Controller Class Initialized
ERROR - 2011-09-07 15:46:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 15:46:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 15:46:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:46:55 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:46:55 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:46:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:46:55 --> Helper loaded: url_helper
DEBUG - 2011-09-07 15:46:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 15:46:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 15:46:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 15:46:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 15:46:55 --> Final output sent to browser
DEBUG - 2011-09-07 15:46:55 --> Total execution time: 0.0305
DEBUG - 2011-09-07 15:46:56 --> Config Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:46:56 --> URI Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Router Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Output Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Input Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:46:56 --> Language Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Loader Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Controller Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:46:56 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:46:57 --> Final output sent to browser
DEBUG - 2011-09-07 15:46:57 --> Total execution time: 0.6062
DEBUG - 2011-09-07 15:46:58 --> Config Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:46:58 --> URI Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Router Class Initialized
ERROR - 2011-09-07 15:46:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-07 15:46:58 --> Config Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:46:58 --> URI Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Router Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Output Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Input Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:46:58 --> Language Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Loader Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Controller Class Initialized
ERROR - 2011-09-07 15:46:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 15:46:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 15:46:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:46:58 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Model Class Initialized
DEBUG - 2011-09-07 15:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:46:58 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:46:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:46:58 --> Helper loaded: url_helper
DEBUG - 2011-09-07 15:46:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 15:46:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 15:46:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 15:46:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 15:46:58 --> Final output sent to browser
DEBUG - 2011-09-07 15:46:58 --> Total execution time: 0.0333
DEBUG - 2011-09-07 15:47:12 --> Config Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:47:12 --> URI Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Router Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Output Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Input Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:47:12 --> Language Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Loader Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Controller Class Initialized
ERROR - 2011-09-07 15:47:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 15:47:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 15:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:47:12 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:47:12 --> Helper loaded: url_helper
DEBUG - 2011-09-07 15:47:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 15:47:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 15:47:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 15:47:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 15:47:12 --> Final output sent to browser
DEBUG - 2011-09-07 15:47:12 --> Total execution time: 0.0395
DEBUG - 2011-09-07 15:47:12 --> Config Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:47:12 --> URI Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Router Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Output Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Input Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:47:12 --> Language Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Loader Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Controller Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:47:12 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Config Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:47:13 --> URI Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Router Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Output Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Input Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:47:13 --> Language Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Loader Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Controller Class Initialized
ERROR - 2011-09-07 15:47:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 15:47:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 15:47:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:47:13 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:47:13 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:47:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:47:13 --> Helper loaded: url_helper
DEBUG - 2011-09-07 15:47:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 15:47:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 15:47:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 15:47:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 15:47:13 --> Final output sent to browser
DEBUG - 2011-09-07 15:47:13 --> Total execution time: 0.0299
DEBUG - 2011-09-07 15:47:13 --> Final output sent to browser
DEBUG - 2011-09-07 15:47:13 --> Total execution time: 0.9183
DEBUG - 2011-09-07 15:47:24 --> Config Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:47:24 --> URI Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Router Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Output Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Input Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:47:24 --> Language Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Loader Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Controller Class Initialized
ERROR - 2011-09-07 15:47:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 15:47:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 15:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:47:24 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:47:24 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:47:24 --> Helper loaded: url_helper
DEBUG - 2011-09-07 15:47:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 15:47:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 15:47:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 15:47:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 15:47:24 --> Final output sent to browser
DEBUG - 2011-09-07 15:47:24 --> Total execution time: 0.0282
DEBUG - 2011-09-07 15:47:25 --> Config Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:47:25 --> URI Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Router Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Output Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Input Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:47:25 --> Language Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Loader Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Controller Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:47:25 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:47:25 --> Final output sent to browser
DEBUG - 2011-09-07 15:47:25 --> Total execution time: 0.6097
DEBUG - 2011-09-07 15:47:39 --> Config Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:47:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:47:39 --> URI Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Router Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Output Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Input Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:47:39 --> Language Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Loader Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Controller Class Initialized
ERROR - 2011-09-07 15:47:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 15:47:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 15:47:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:47:39 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:47:39 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:47:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 15:47:39 --> Helper loaded: url_helper
DEBUG - 2011-09-07 15:47:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 15:47:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 15:47:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 15:47:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 15:47:39 --> Final output sent to browser
DEBUG - 2011-09-07 15:47:39 --> Total execution time: 0.0285
DEBUG - 2011-09-07 15:47:40 --> Config Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Hooks Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Utf8 Class Initialized
DEBUG - 2011-09-07 15:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 15:47:40 --> URI Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Router Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Output Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Input Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 15:47:40 --> Language Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Loader Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Controller Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Model Class Initialized
DEBUG - 2011-09-07 15:47:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 15:47:40 --> Database Driver Class Initialized
DEBUG - 2011-09-07 15:47:41 --> Final output sent to browser
DEBUG - 2011-09-07 15:47:41 --> Total execution time: 0.8758
DEBUG - 2011-09-07 16:32:41 --> Config Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:32:41 --> URI Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Router Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Output Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Input Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:32:41 --> Language Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Loader Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Controller Class Initialized
ERROR - 2011-09-07 16:32:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 16:32:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 16:32:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:32:41 --> Model Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Model Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:32:41 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:32:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:32:41 --> Helper loaded: url_helper
DEBUG - 2011-09-07 16:32:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 16:32:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 16:32:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 16:32:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 16:32:41 --> Final output sent to browser
DEBUG - 2011-09-07 16:32:41 --> Total execution time: 0.0458
DEBUG - 2011-09-07 16:32:41 --> Config Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:32:41 --> URI Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Router Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Output Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Input Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:32:41 --> Language Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Loader Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Controller Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Model Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Model Class Initialized
DEBUG - 2011-09-07 16:32:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:32:41 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:32:42 --> Final output sent to browser
DEBUG - 2011-09-07 16:32:42 --> Total execution time: 0.8019
DEBUG - 2011-09-07 16:32:43 --> Config Class Initialized
DEBUG - 2011-09-07 16:32:43 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:32:43 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:32:43 --> URI Class Initialized
DEBUG - 2011-09-07 16:32:43 --> Router Class Initialized
ERROR - 2011-09-07 16:32:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 16:32:44 --> Config Class Initialized
DEBUG - 2011-09-07 16:32:44 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:32:44 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:32:44 --> URI Class Initialized
DEBUG - 2011-09-07 16:32:44 --> Router Class Initialized
ERROR - 2011-09-07 16:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 16:33:27 --> Config Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:33:27 --> URI Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Router Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Output Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Input Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:33:27 --> Language Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Loader Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Controller Class Initialized
ERROR - 2011-09-07 16:33:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 16:33:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 16:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:33:27 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:33:27 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:33:27 --> Helper loaded: url_helper
DEBUG - 2011-09-07 16:33:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 16:33:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 16:33:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 16:33:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 16:33:27 --> Final output sent to browser
DEBUG - 2011-09-07 16:33:27 --> Total execution time: 0.0279
DEBUG - 2011-09-07 16:33:27 --> Config Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:33:27 --> URI Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Router Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Output Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Input Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:33:27 --> Language Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Loader Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Controller Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:33:27 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:33:28 --> Final output sent to browser
DEBUG - 2011-09-07 16:33:28 --> Total execution time: 0.8980
DEBUG - 2011-09-07 16:33:38 --> Config Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:33:38 --> URI Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Router Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Output Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Input Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:33:38 --> Language Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Loader Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Controller Class Initialized
ERROR - 2011-09-07 16:33:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 16:33:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 16:33:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:33:38 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:33:38 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:33:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:33:38 --> Helper loaded: url_helper
DEBUG - 2011-09-07 16:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 16:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 16:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 16:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 16:33:38 --> Final output sent to browser
DEBUG - 2011-09-07 16:33:38 --> Total execution time: 0.0391
DEBUG - 2011-09-07 16:33:38 --> Config Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:33:38 --> URI Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Router Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Output Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Input Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:33:38 --> Language Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Loader Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Controller Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:33:38 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Config Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:33:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:33:39 --> URI Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Router Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Output Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Input Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:33:39 --> Language Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Loader Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Controller Class Initialized
ERROR - 2011-09-07 16:33:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 16:33:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 16:33:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:33:39 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Model Class Initialized
DEBUG - 2011-09-07 16:33:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:33:39 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:33:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:33:39 --> Helper loaded: url_helper
DEBUG - 2011-09-07 16:33:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 16:33:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 16:33:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 16:33:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 16:33:39 --> Final output sent to browser
DEBUG - 2011-09-07 16:33:39 --> Total execution time: 0.0308
DEBUG - 2011-09-07 16:33:40 --> Final output sent to browser
DEBUG - 2011-09-07 16:33:40 --> Total execution time: 1.4798
DEBUG - 2011-09-07 16:34:04 --> Config Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:34:04 --> URI Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Router Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Output Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Input Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:34:04 --> Language Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Loader Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Controller Class Initialized
ERROR - 2011-09-07 16:34:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 16:34:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 16:34:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:34:04 --> Model Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Model Class Initialized
DEBUG - 2011-09-07 16:34:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:34:04 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:34:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:34:04 --> Helper loaded: url_helper
DEBUG - 2011-09-07 16:34:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 16:34:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 16:34:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 16:34:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 16:34:04 --> Final output sent to browser
DEBUG - 2011-09-07 16:34:04 --> Total execution time: 0.0453
DEBUG - 2011-09-07 16:34:05 --> Config Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:34:05 --> URI Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Router Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Output Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Input Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:34:05 --> Language Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Loader Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Controller Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Model Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Model Class Initialized
DEBUG - 2011-09-07 16:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:34:05 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:34:06 --> Final output sent to browser
DEBUG - 2011-09-07 16:34:06 --> Total execution time: 0.8937
DEBUG - 2011-09-07 16:34:15 --> Config Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:34:15 --> URI Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Router Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Output Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Input Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:34:15 --> Language Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Loader Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Controller Class Initialized
ERROR - 2011-09-07 16:34:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 16:34:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 16:34:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:34:15 --> Model Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Model Class Initialized
DEBUG - 2011-09-07 16:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:34:15 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:34:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 16:34:15 --> Helper loaded: url_helper
DEBUG - 2011-09-07 16:34:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 16:34:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 16:34:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 16:34:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 16:34:15 --> Final output sent to browser
DEBUG - 2011-09-07 16:34:15 --> Total execution time: 0.0293
DEBUG - 2011-09-07 16:34:16 --> Config Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Hooks Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Utf8 Class Initialized
DEBUG - 2011-09-07 16:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 16:34:16 --> URI Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Router Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Output Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Input Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 16:34:16 --> Language Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Loader Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Controller Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Model Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Model Class Initialized
DEBUG - 2011-09-07 16:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 16:34:16 --> Database Driver Class Initialized
DEBUG - 2011-09-07 16:34:17 --> Final output sent to browser
DEBUG - 2011-09-07 16:34:17 --> Total execution time: 0.7913
DEBUG - 2011-09-07 17:04:57 --> Config Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:04:57 --> URI Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Router Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Output Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Input Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:04:57 --> Language Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Loader Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Controller Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Model Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Model Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Model Class Initialized
DEBUG - 2011-09-07 17:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:04:57 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:04:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 17:04:57 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:04:57 --> Final output sent to browser
DEBUG - 2011-09-07 17:04:57 --> Total execution time: 0.3788
DEBUG - 2011-09-07 17:04:59 --> Config Class Initialized
DEBUG - 2011-09-07 17:04:59 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:04:59 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:04:59 --> URI Class Initialized
DEBUG - 2011-09-07 17:04:59 --> Router Class Initialized
ERROR - 2011-09-07 17:04:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 17:08:11 --> Config Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:08:11 --> URI Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Router Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Output Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Input Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:08:11 --> Language Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Loader Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Controller Class Initialized
ERROR - 2011-09-07 17:08:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 17:08:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 17:08:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:08:11 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:08:11 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:08:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:08:11 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:08:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:08:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:08:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:08:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:08:11 --> Final output sent to browser
DEBUG - 2011-09-07 17:08:11 --> Total execution time: 0.0305
DEBUG - 2011-09-07 17:08:13 --> Config Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:08:13 --> URI Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Router Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Output Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Input Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:08:13 --> Language Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Loader Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Controller Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:08:13 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:08:13 --> Final output sent to browser
DEBUG - 2011-09-07 17:08:13 --> Total execution time: 0.5464
DEBUG - 2011-09-07 17:08:15 --> Config Class Initialized
DEBUG - 2011-09-07 17:08:15 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:08:15 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:08:15 --> URI Class Initialized
DEBUG - 2011-09-07 17:08:15 --> Router Class Initialized
ERROR - 2011-09-07 17:08:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 17:08:25 --> Config Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:08:25 --> URI Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Router Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Output Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Input Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:08:25 --> Language Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Loader Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Controller Class Initialized
ERROR - 2011-09-07 17:08:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 17:08:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 17:08:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:08:25 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:08:25 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:08:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:08:25 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:08:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:08:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:08:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:08:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:08:25 --> Final output sent to browser
DEBUG - 2011-09-07 17:08:25 --> Total execution time: 0.0306
DEBUG - 2011-09-07 17:08:26 --> Config Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:08:26 --> URI Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Router Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Output Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Input Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:08:26 --> Language Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Loader Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Controller Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:08:26 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:08:27 --> Final output sent to browser
DEBUG - 2011-09-07 17:08:27 --> Total execution time: 0.5784
DEBUG - 2011-09-07 17:08:31 --> Config Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:08:31 --> URI Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Router Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Output Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Input Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:08:31 --> Language Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Loader Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Controller Class Initialized
ERROR - 2011-09-07 17:08:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 17:08:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 17:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:08:31 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:08:31 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:08:31 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:08:31 --> Final output sent to browser
DEBUG - 2011-09-07 17:08:31 --> Total execution time: 0.0824
DEBUG - 2011-09-07 17:08:32 --> Config Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:08:32 --> URI Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Router Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Output Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Input Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:08:32 --> Language Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Loader Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Controller Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Model Class Initialized
DEBUG - 2011-09-07 17:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:08:32 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:08:33 --> Final output sent to browser
DEBUG - 2011-09-07 17:08:33 --> Total execution time: 0.5083
DEBUG - 2011-09-07 17:21:48 --> Config Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:21:48 --> URI Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Router Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Output Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Input Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:21:48 --> Language Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Loader Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Controller Class Initialized
ERROR - 2011-09-07 17:21:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 17:21:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 17:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:21:48 --> Model Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Model Class Initialized
DEBUG - 2011-09-07 17:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:21:48 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:21:48 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:21:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:21:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:21:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:21:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:21:48 --> Final output sent to browser
DEBUG - 2011-09-07 17:21:48 --> Total execution time: 0.0353
DEBUG - 2011-09-07 17:28:34 --> Config Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:28:34 --> URI Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Router Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Output Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Input Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:28:34 --> Language Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Loader Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Controller Class Initialized
ERROR - 2011-09-07 17:28:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 17:28:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 17:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:28:34 --> Model Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Model Class Initialized
DEBUG - 2011-09-07 17:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:28:34 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:28:34 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:28:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:28:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:28:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:28:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:28:34 --> Final output sent to browser
DEBUG - 2011-09-07 17:28:34 --> Total execution time: 0.0341
DEBUG - 2011-09-07 17:28:35 --> Config Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:28:35 --> URI Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Router Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Output Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Input Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:28:35 --> Language Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Loader Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Controller Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Model Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Model Class Initialized
DEBUG - 2011-09-07 17:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:28:35 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:28:36 --> Final output sent to browser
DEBUG - 2011-09-07 17:28:36 --> Total execution time: 0.5870
DEBUG - 2011-09-07 17:28:38 --> Config Class Initialized
DEBUG - 2011-09-07 17:28:38 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:28:38 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:28:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:28:38 --> URI Class Initialized
DEBUG - 2011-09-07 17:28:38 --> Router Class Initialized
ERROR - 2011-09-07 17:28:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 17:28:39 --> Config Class Initialized
DEBUG - 2011-09-07 17:28:39 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:28:39 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:28:39 --> URI Class Initialized
DEBUG - 2011-09-07 17:28:39 --> Router Class Initialized
ERROR - 2011-09-07 17:28:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 17:29:37 --> Config Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:29:37 --> URI Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Router Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Output Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Input Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:29:37 --> Language Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Loader Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Controller Class Initialized
ERROR - 2011-09-07 17:29:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 17:29:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 17:29:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:29:37 --> Model Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Model Class Initialized
DEBUG - 2011-09-07 17:29:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:29:37 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:29:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:29:37 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:29:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:29:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:29:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:29:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:29:37 --> Final output sent to browser
DEBUG - 2011-09-07 17:29:37 --> Total execution time: 0.0283
DEBUG - 2011-09-07 17:29:41 --> Config Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:29:41 --> URI Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Router Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Output Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Input Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:29:41 --> Language Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Loader Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Controller Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Model Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Model Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:29:41 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:29:41 --> Final output sent to browser
DEBUG - 2011-09-07 17:29:41 --> Total execution time: 0.5620
DEBUG - 2011-09-07 17:30:02 --> Config Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:30:03 --> URI Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Router Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Output Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Input Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:30:03 --> Language Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Loader Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Controller Class Initialized
ERROR - 2011-09-07 17:30:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 17:30:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 17:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:30:03 --> Model Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Model Class Initialized
DEBUG - 2011-09-07 17:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:30:03 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 17:30:03 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:30:03 --> Final output sent to browser
DEBUG - 2011-09-07 17:30:03 --> Total execution time: 0.3512
DEBUG - 2011-09-07 17:30:05 --> Config Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:30:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:30:05 --> URI Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Router Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Output Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Input Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:30:05 --> Language Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Loader Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Controller Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Model Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Model Class Initialized
DEBUG - 2011-09-07 17:30:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:30:05 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:30:06 --> Final output sent to browser
DEBUG - 2011-09-07 17:30:06 --> Total execution time: 1.3140
DEBUG - 2011-09-07 17:40:22 --> Config Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Hooks Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Utf8 Class Initialized
DEBUG - 2011-09-07 17:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 17:40:22 --> URI Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Router Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Output Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Input Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 17:40:22 --> Language Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Loader Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Controller Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Model Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Model Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Model Class Initialized
DEBUG - 2011-09-07 17:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 17:40:22 --> Database Driver Class Initialized
DEBUG - 2011-09-07 17:40:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 17:40:22 --> Helper loaded: url_helper
DEBUG - 2011-09-07 17:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 17:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 17:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 17:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 17:40:22 --> Final output sent to browser
DEBUG - 2011-09-07 17:40:22 --> Total execution time: 0.2520
DEBUG - 2011-09-07 19:04:05 --> Config Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Hooks Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Utf8 Class Initialized
DEBUG - 2011-09-07 19:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 19:04:05 --> URI Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Router Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Output Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Input Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 19:04:05 --> Language Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Loader Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Controller Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Model Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Model Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Model Class Initialized
DEBUG - 2011-09-07 19:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 19:04:05 --> Database Driver Class Initialized
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 19:04:06 --> Helper loaded: url_helper
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 19:04:06 --> Final output sent to browser
DEBUG - 2011-09-07 19:04:06 --> Total execution time: 0.9586
DEBUG - 2011-09-07 19:04:06 --> Config Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Hooks Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Utf8 Class Initialized
DEBUG - 2011-09-07 19:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 19:04:06 --> URI Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Router Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Output Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Input Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 19:04:06 --> Language Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Loader Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Controller Class Initialized
ERROR - 2011-09-07 19:04:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 19:04:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 19:04:06 --> Model Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Model Class Initialized
DEBUG - 2011-09-07 19:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 19:04:06 --> Database Driver Class Initialized
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 19:04:06 --> Helper loaded: url_helper
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 19:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 19:04:06 --> Final output sent to browser
DEBUG - 2011-09-07 19:04:06 --> Total execution time: 0.0284
DEBUG - 2011-09-07 20:24:30 --> Config Class Initialized
DEBUG - 2011-09-07 20:24:30 --> Hooks Class Initialized
DEBUG - 2011-09-07 20:24:30 --> Utf8 Class Initialized
DEBUG - 2011-09-07 20:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 20:24:30 --> URI Class Initialized
DEBUG - 2011-09-07 20:24:30 --> Router Class Initialized
DEBUG - 2011-09-07 20:24:30 --> No URI present. Default controller set.
DEBUG - 2011-09-07 20:24:30 --> Output Class Initialized
DEBUG - 2011-09-07 20:24:30 --> Input Class Initialized
DEBUG - 2011-09-07 20:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 20:24:30 --> Language Class Initialized
DEBUG - 2011-09-07 20:24:30 --> Loader Class Initialized
DEBUG - 2011-09-07 20:24:30 --> Controller Class Initialized
DEBUG - 2011-09-07 20:24:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-07 20:24:30 --> Helper loaded: url_helper
DEBUG - 2011-09-07 20:24:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 20:24:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 20:24:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 20:24:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 20:24:30 --> Final output sent to browser
DEBUG - 2011-09-07 20:24:30 --> Total execution time: 0.0984
DEBUG - 2011-09-07 20:47:58 --> Config Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Hooks Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Utf8 Class Initialized
DEBUG - 2011-09-07 20:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 20:47:58 --> URI Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Router Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Output Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Input Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 20:47:58 --> Language Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Loader Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Controller Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Model Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Model Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Model Class Initialized
DEBUG - 2011-09-07 20:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 20:47:58 --> Database Driver Class Initialized
DEBUG - 2011-09-07 20:47:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 20:47:58 --> Helper loaded: url_helper
DEBUG - 2011-09-07 20:47:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 20:47:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 20:47:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 20:47:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 20:47:58 --> Final output sent to browser
DEBUG - 2011-09-07 20:47:58 --> Total execution time: 0.2789
DEBUG - 2011-09-07 20:48:15 --> Config Class Initialized
DEBUG - 2011-09-07 20:48:15 --> Hooks Class Initialized
DEBUG - 2011-09-07 20:48:15 --> Utf8 Class Initialized
DEBUG - 2011-09-07 20:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 20:48:15 --> URI Class Initialized
DEBUG - 2011-09-07 20:48:15 --> Router Class Initialized
ERROR - 2011-09-07 20:48:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-07 23:02:46 --> Config Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Hooks Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Utf8 Class Initialized
DEBUG - 2011-09-07 23:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 23:02:46 --> URI Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Router Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Output Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Input Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 23:02:46 --> Language Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Loader Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Controller Class Initialized
ERROR - 2011-09-07 23:02:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-07 23:02:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-07 23:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 23:02:46 --> Model Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Model Class Initialized
DEBUG - 2011-09-07 23:02:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 23:02:46 --> Database Driver Class Initialized
DEBUG - 2011-09-07 23:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-07 23:02:46 --> Helper loaded: url_helper
DEBUG - 2011-09-07 23:02:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 23:02:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 23:02:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 23:02:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 23:02:46 --> Final output sent to browser
DEBUG - 2011-09-07 23:02:46 --> Total execution time: 0.2921
DEBUG - 2011-09-07 23:41:21 --> Config Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Hooks Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Utf8 Class Initialized
DEBUG - 2011-09-07 23:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 23:41:21 --> URI Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Router Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Output Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Input Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-07 23:41:21 --> Language Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Loader Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Controller Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Model Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Model Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Model Class Initialized
DEBUG - 2011-09-07 23:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-07 23:41:21 --> Database Driver Class Initialized
DEBUG - 2011-09-07 23:41:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-07 23:41:21 --> Helper loaded: url_helper
DEBUG - 2011-09-07 23:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-07 23:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-07 23:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-07 23:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-07 23:41:21 --> Final output sent to browser
DEBUG - 2011-09-07 23:41:21 --> Total execution time: 0.2941
DEBUG - 2011-09-07 23:41:23 --> Config Class Initialized
DEBUG - 2011-09-07 23:41:23 --> Hooks Class Initialized
DEBUG - 2011-09-07 23:41:23 --> Utf8 Class Initialized
DEBUG - 2011-09-07 23:41:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-07 23:41:23 --> URI Class Initialized
DEBUG - 2011-09-07 23:41:23 --> Router Class Initialized
ERROR - 2011-09-07 23:41:23 --> 404 Page Not Found --> favicon.ico

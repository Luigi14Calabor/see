<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-02 00:05:01 --> Config Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Hooks Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Utf8 Class Initialized
DEBUG - 2011-06-02 00:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 00:05:01 --> URI Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Router Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Output Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Input Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 00:05:01 --> Language Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Loader Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Controller Class Initialized
ERROR - 2011-06-02 00:05:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 00:05:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 00:05:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 00:05:01 --> Model Class Initialized
DEBUG - 2011-06-02 00:05:01 --> Model Class Initialized
DEBUG - 2011-06-02 00:05:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 00:05:02 --> Database Driver Class Initialized
DEBUG - 2011-06-02 00:05:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 00:05:02 --> Helper loaded: url_helper
DEBUG - 2011-06-02 00:05:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 00:05:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 00:05:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 00:05:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 00:05:03 --> Final output sent to browser
DEBUG - 2011-06-02 00:05:03 --> Total execution time: 1.8180
DEBUG - 2011-06-02 01:12:31 --> Config Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Hooks Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Utf8 Class Initialized
DEBUG - 2011-06-02 01:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 01:12:31 --> URI Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Router Class Initialized
ERROR - 2011-06-02 01:12:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 01:12:31 --> Config Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Hooks Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Utf8 Class Initialized
DEBUG - 2011-06-02 01:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 01:12:31 --> URI Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Router Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Output Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Input Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 01:12:31 --> Language Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Loader Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Controller Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Model Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Model Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Model Class Initialized
DEBUG - 2011-06-02 01:12:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 01:12:31 --> Database Driver Class Initialized
DEBUG - 2011-06-02 01:12:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 01:12:31 --> Helper loaded: url_helper
DEBUG - 2011-06-02 01:12:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 01:12:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 01:12:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 01:12:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 01:12:31 --> Final output sent to browser
DEBUG - 2011-06-02 01:12:31 --> Total execution time: 0.5498
DEBUG - 2011-06-02 01:13:02 --> Config Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Hooks Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Utf8 Class Initialized
DEBUG - 2011-06-02 01:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 01:13:02 --> URI Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Router Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Output Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Input Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 01:13:02 --> Language Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Loader Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Controller Class Initialized
ERROR - 2011-06-02 01:13:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 01:13:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 01:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 01:13:02 --> Model Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Model Class Initialized
DEBUG - 2011-06-02 01:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 01:13:02 --> Database Driver Class Initialized
DEBUG - 2011-06-02 01:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 01:13:02 --> Helper loaded: url_helper
DEBUG - 2011-06-02 01:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 01:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 01:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 01:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 01:13:02 --> Final output sent to browser
DEBUG - 2011-06-02 01:13:02 --> Total execution time: 0.1952
DEBUG - 2011-06-02 02:12:19 --> Config Class Initialized
DEBUG - 2011-06-02 02:12:19 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:12:19 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:12:19 --> URI Class Initialized
DEBUG - 2011-06-02 02:12:19 --> Router Class Initialized
ERROR - 2011-06-02 02:12:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 02:41:06 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:06 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Router Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Output Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Input Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 02:41:06 --> Language Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Loader Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Controller Class Initialized
ERROR - 2011-06-02 02:41:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 02:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 02:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 02:41:06 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 02:41:06 --> Database Driver Class Initialized
DEBUG - 2011-06-02 02:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 02:41:06 --> Helper loaded: url_helper
DEBUG - 2011-06-02 02:41:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 02:41:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 02:41:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 02:41:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 02:41:06 --> Final output sent to browser
DEBUG - 2011-06-02 02:41:06 --> Total execution time: 0.3571
DEBUG - 2011-06-02 02:41:08 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:08 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Router Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Output Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Input Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 02:41:08 --> Language Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Loader Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Controller Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 02:41:08 --> Database Driver Class Initialized
DEBUG - 2011-06-02 02:41:08 --> Final output sent to browser
DEBUG - 2011-06-02 02:41:08 --> Total execution time: 0.6325
DEBUG - 2011-06-02 02:41:11 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:11 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:11 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:11 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:11 --> Router Class Initialized
ERROR - 2011-06-02 02:41:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 02:41:24 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:24 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Router Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Output Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Input Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 02:41:24 --> Language Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Loader Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Controller Class Initialized
ERROR - 2011-06-02 02:41:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 02:41:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 02:41:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 02:41:24 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 02:41:24 --> Database Driver Class Initialized
DEBUG - 2011-06-02 02:41:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 02:41:24 --> Helper loaded: url_helper
DEBUG - 2011-06-02 02:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 02:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 02:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 02:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 02:41:24 --> Final output sent to browser
DEBUG - 2011-06-02 02:41:24 --> Total execution time: 0.0307
DEBUG - 2011-06-02 02:41:25 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:25 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Router Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Output Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Input Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 02:41:25 --> Language Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Loader Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Controller Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 02:41:25 --> Database Driver Class Initialized
DEBUG - 2011-06-02 02:41:25 --> Final output sent to browser
DEBUG - 2011-06-02 02:41:25 --> Total execution time: 0.6270
DEBUG - 2011-06-02 02:41:31 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:31 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Router Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Output Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Input Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 02:41:31 --> Language Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Loader Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Controller Class Initialized
ERROR - 2011-06-02 02:41:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 02:41:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 02:41:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 02:41:31 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 02:41:31 --> Database Driver Class Initialized
DEBUG - 2011-06-02 02:41:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 02:41:31 --> Helper loaded: url_helper
DEBUG - 2011-06-02 02:41:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 02:41:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 02:41:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 02:41:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 02:41:31 --> Final output sent to browser
DEBUG - 2011-06-02 02:41:31 --> Total execution time: 0.0287
DEBUG - 2011-06-02 02:41:32 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:32 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Router Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Output Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Input Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 02:41:32 --> Language Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Loader Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Controller Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 02:41:32 --> Database Driver Class Initialized
DEBUG - 2011-06-02 02:41:32 --> Final output sent to browser
DEBUG - 2011-06-02 02:41:32 --> Total execution time: 0.5705
DEBUG - 2011-06-02 02:41:35 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:35 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Router Class Initialized
ERROR - 2011-06-02 02:41:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 02:41:35 --> Config Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Hooks Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Utf8 Class Initialized
DEBUG - 2011-06-02 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 02:41:35 --> URI Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Router Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Output Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Input Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 02:41:35 --> Language Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Loader Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Controller Class Initialized
ERROR - 2011-06-02 02:41:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 02:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 02:41:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 02:41:35 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Model Class Initialized
DEBUG - 2011-06-02 02:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 02:41:35 --> Database Driver Class Initialized
DEBUG - 2011-06-02 02:41:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 02:41:35 --> Helper loaded: url_helper
DEBUG - 2011-06-02 02:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 02:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 02:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 02:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 02:41:35 --> Final output sent to browser
DEBUG - 2011-06-02 02:41:35 --> Total execution time: 0.0334
DEBUG - 2011-06-02 03:05:57 --> Config Class Initialized
DEBUG - 2011-06-02 03:05:57 --> Hooks Class Initialized
DEBUG - 2011-06-02 03:05:57 --> Utf8 Class Initialized
DEBUG - 2011-06-02 03:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 03:05:57 --> URI Class Initialized
DEBUG - 2011-06-02 03:05:57 --> Router Class Initialized
DEBUG - 2011-06-02 03:05:57 --> No URI present. Default controller set.
DEBUG - 2011-06-02 03:05:57 --> Output Class Initialized
DEBUG - 2011-06-02 03:05:57 --> Input Class Initialized
DEBUG - 2011-06-02 03:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 03:05:57 --> Language Class Initialized
DEBUG - 2011-06-02 03:05:57 --> Loader Class Initialized
DEBUG - 2011-06-02 03:05:57 --> Controller Class Initialized
DEBUG - 2011-06-02 03:05:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-02 03:05:58 --> Helper loaded: url_helper
DEBUG - 2011-06-02 03:05:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 03:05:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 03:05:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 03:05:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 03:05:58 --> Final output sent to browser
DEBUG - 2011-06-02 03:05:58 --> Total execution time: 0.2252
DEBUG - 2011-06-02 03:35:04 --> Config Class Initialized
DEBUG - 2011-06-02 03:35:04 --> Hooks Class Initialized
DEBUG - 2011-06-02 03:35:04 --> Utf8 Class Initialized
DEBUG - 2011-06-02 03:35:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 03:35:04 --> URI Class Initialized
DEBUG - 2011-06-02 03:35:04 --> Router Class Initialized
ERROR - 2011-06-02 03:35:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 03:54:32 --> Config Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Hooks Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Utf8 Class Initialized
DEBUG - 2011-06-02 03:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 03:54:32 --> URI Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Router Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Output Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Input Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 03:54:32 --> Language Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Loader Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Controller Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Model Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Model Class Initialized
DEBUG - 2011-06-02 03:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 03:54:32 --> Database Driver Class Initialized
DEBUG - 2011-06-02 03:54:33 --> Final output sent to browser
DEBUG - 2011-06-02 03:54:33 --> Total execution time: 1.0487
DEBUG - 2011-06-02 04:00:43 --> Config Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Hooks Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Utf8 Class Initialized
DEBUG - 2011-06-02 04:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 04:00:43 --> URI Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Router Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Output Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Input Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 04:00:43 --> Language Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Loader Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Controller Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Model Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Model Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Model Class Initialized
DEBUG - 2011-06-02 04:00:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 04:00:43 --> Database Driver Class Initialized
DEBUG - 2011-06-02 04:00:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 04:00:44 --> Helper loaded: url_helper
DEBUG - 2011-06-02 04:00:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 04:00:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 04:00:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 04:00:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 04:00:44 --> Final output sent to browser
DEBUG - 2011-06-02 04:00:44 --> Total execution time: 0.5078
DEBUG - 2011-06-02 04:04:06 --> Config Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Hooks Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Utf8 Class Initialized
DEBUG - 2011-06-02 04:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 04:04:06 --> URI Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Router Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Output Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Input Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 04:04:06 --> Language Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Loader Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Controller Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Model Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Model Class Initialized
DEBUG - 2011-06-02 04:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 04:04:06 --> Database Driver Class Initialized
DEBUG - 2011-06-02 04:04:07 --> Final output sent to browser
DEBUG - 2011-06-02 04:04:07 --> Total execution time: 0.5675
DEBUG - 2011-06-02 07:55:58 --> Config Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Hooks Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Utf8 Class Initialized
DEBUG - 2011-06-02 07:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 07:55:58 --> URI Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Router Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Output Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Input Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 07:55:58 --> Language Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Loader Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Controller Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Model Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Model Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Model Class Initialized
DEBUG - 2011-06-02 07:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 07:55:58 --> Database Driver Class Initialized
DEBUG - 2011-06-02 07:55:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 07:55:59 --> Helper loaded: url_helper
DEBUG - 2011-06-02 07:55:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 07:55:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 07:55:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 07:55:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 07:55:59 --> Final output sent to browser
DEBUG - 2011-06-02 07:55:59 --> Total execution time: 1.4460
DEBUG - 2011-06-02 07:56:12 --> Config Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Hooks Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Utf8 Class Initialized
DEBUG - 2011-06-02 07:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 07:56:12 --> URI Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Router Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Output Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Input Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 07:56:12 --> Language Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Loader Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Controller Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Model Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Model Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Model Class Initialized
DEBUG - 2011-06-02 07:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 07:56:12 --> Database Driver Class Initialized
DEBUG - 2011-06-02 07:56:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 07:56:12 --> Helper loaded: url_helper
DEBUG - 2011-06-02 07:56:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 07:56:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 07:56:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 07:56:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 07:56:12 --> Final output sent to browser
DEBUG - 2011-06-02 07:56:12 --> Total execution time: 0.0581
DEBUG - 2011-06-02 07:56:32 --> Config Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Hooks Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Utf8 Class Initialized
DEBUG - 2011-06-02 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 07:56:32 --> URI Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Router Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Output Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Input Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 07:56:32 --> Language Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Loader Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Controller Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Model Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Model Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Model Class Initialized
DEBUG - 2011-06-02 07:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 07:56:32 --> Database Driver Class Initialized
DEBUG - 2011-06-02 07:56:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 07:56:32 --> Helper loaded: url_helper
DEBUG - 2011-06-02 07:56:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 07:56:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 07:56:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 07:56:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 07:56:32 --> Final output sent to browser
DEBUG - 2011-06-02 07:56:32 --> Total execution time: 0.0505
DEBUG - 2011-06-02 07:57:01 --> Config Class Initialized
DEBUG - 2011-06-02 07:57:01 --> Hooks Class Initialized
DEBUG - 2011-06-02 07:57:01 --> Utf8 Class Initialized
DEBUG - 2011-06-02 07:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 07:57:02 --> URI Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Router Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Output Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Input Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 07:57:02 --> Language Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Loader Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Controller Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Model Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Model Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Model Class Initialized
DEBUG - 2011-06-02 07:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 07:57:02 --> Database Driver Class Initialized
DEBUG - 2011-06-02 07:57:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 07:57:02 --> Helper loaded: url_helper
DEBUG - 2011-06-02 07:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 07:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 07:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 07:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 07:57:02 --> Final output sent to browser
DEBUG - 2011-06-02 07:57:02 --> Total execution time: 0.5609
DEBUG - 2011-06-02 07:57:22 --> Config Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Hooks Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Utf8 Class Initialized
DEBUG - 2011-06-02 07:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 07:57:22 --> URI Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Router Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Output Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Input Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 07:57:22 --> Language Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Loader Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Controller Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Model Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Model Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Model Class Initialized
DEBUG - 2011-06-02 07:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 07:57:22 --> Database Driver Class Initialized
DEBUG - 2011-06-02 07:57:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 07:57:22 --> Helper loaded: url_helper
DEBUG - 2011-06-02 07:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 07:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 07:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 07:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 07:57:22 --> Final output sent to browser
DEBUG - 2011-06-02 07:57:22 --> Total execution time: 0.0840
DEBUG - 2011-06-02 08:02:02 --> Config Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Hooks Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Utf8 Class Initialized
DEBUG - 2011-06-02 08:02:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 08:02:02 --> URI Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Router Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Output Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Input Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 08:02:02 --> Language Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Loader Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Controller Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Model Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Model Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Model Class Initialized
DEBUG - 2011-06-02 08:02:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 08:02:02 --> Database Driver Class Initialized
DEBUG - 2011-06-02 08:02:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 08:02:02 --> Helper loaded: url_helper
DEBUG - 2011-06-02 08:02:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 08:02:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 08:02:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 08:02:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 08:02:02 --> Final output sent to browser
DEBUG - 2011-06-02 08:02:02 --> Total execution time: 0.0536
DEBUG - 2011-06-02 08:02:43 --> Config Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Hooks Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Utf8 Class Initialized
DEBUG - 2011-06-02 08:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 08:02:43 --> URI Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Router Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Output Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Input Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 08:02:43 --> Language Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Loader Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Controller Class Initialized
ERROR - 2011-06-02 08:02:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 08:02:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 08:02:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 08:02:43 --> Model Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Model Class Initialized
DEBUG - 2011-06-02 08:02:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 08:02:43 --> Database Driver Class Initialized
DEBUG - 2011-06-02 08:02:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 08:02:43 --> Helper loaded: url_helper
DEBUG - 2011-06-02 08:02:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 08:02:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 08:02:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 08:02:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 08:02:43 --> Final output sent to browser
DEBUG - 2011-06-02 08:02:43 --> Total execution time: 0.1086
DEBUG - 2011-06-02 08:02:48 --> Config Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Hooks Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Utf8 Class Initialized
DEBUG - 2011-06-02 08:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 08:02:48 --> URI Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Router Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Output Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Input Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 08:02:48 --> Language Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Loader Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Controller Class Initialized
ERROR - 2011-06-02 08:02:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 08:02:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 08:02:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 08:02:48 --> Model Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Model Class Initialized
DEBUG - 2011-06-02 08:02:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 08:02:48 --> Database Driver Class Initialized
DEBUG - 2011-06-02 08:02:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 08:02:48 --> Helper loaded: url_helper
DEBUG - 2011-06-02 08:02:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 08:02:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 08:02:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 08:02:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 08:02:48 --> Final output sent to browser
DEBUG - 2011-06-02 08:02:48 --> Total execution time: 0.1040
DEBUG - 2011-06-02 10:28:18 --> Config Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Hooks Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Utf8 Class Initialized
DEBUG - 2011-06-02 10:28:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 10:28:18 --> URI Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Router Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Output Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Input Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 10:28:18 --> Language Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Loader Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Controller Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Model Class Initialized
DEBUG - 2011-06-02 10:28:18 --> Model Class Initialized
DEBUG - 2011-06-02 10:28:19 --> Model Class Initialized
DEBUG - 2011-06-02 10:28:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 10:28:19 --> Database Driver Class Initialized
DEBUG - 2011-06-02 10:28:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 10:28:19 --> Helper loaded: url_helper
DEBUG - 2011-06-02 10:28:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 10:28:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 10:28:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 10:28:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 10:28:19 --> Final output sent to browser
DEBUG - 2011-06-02 10:28:19 --> Total execution time: 1.0294
DEBUG - 2011-06-02 10:29:34 --> Config Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Hooks Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Utf8 Class Initialized
DEBUG - 2011-06-02 10:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 10:29:34 --> URI Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Router Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Output Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Input Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 10:29:34 --> Language Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Loader Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Controller Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Model Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Model Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Model Class Initialized
DEBUG - 2011-06-02 10:29:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 10:29:34 --> Database Driver Class Initialized
DEBUG - 2011-06-02 10:29:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 10:29:34 --> Helper loaded: url_helper
DEBUG - 2011-06-02 10:29:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 10:29:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 10:29:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 10:29:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 10:29:34 --> Final output sent to browser
DEBUG - 2011-06-02 10:29:34 --> Total execution time: 0.3594
DEBUG - 2011-06-02 10:29:36 --> Config Class Initialized
DEBUG - 2011-06-02 10:29:36 --> Hooks Class Initialized
DEBUG - 2011-06-02 10:29:36 --> Utf8 Class Initialized
DEBUG - 2011-06-02 10:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 10:29:36 --> URI Class Initialized
DEBUG - 2011-06-02 10:29:36 --> Router Class Initialized
ERROR - 2011-06-02 10:29:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 11:20:38 --> Config Class Initialized
DEBUG - 2011-06-02 11:20:38 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:20:38 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:20:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:20:38 --> URI Class Initialized
DEBUG - 2011-06-02 11:20:38 --> Router Class Initialized
DEBUG - 2011-06-02 11:20:39 --> No URI present. Default controller set.
DEBUG - 2011-06-02 11:20:39 --> Output Class Initialized
DEBUG - 2011-06-02 11:20:39 --> Input Class Initialized
DEBUG - 2011-06-02 11:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:20:39 --> Language Class Initialized
DEBUG - 2011-06-02 11:20:39 --> Loader Class Initialized
DEBUG - 2011-06-02 11:20:39 --> Controller Class Initialized
DEBUG - 2011-06-02 11:20:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-02 11:20:39 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:20:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:20:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:20:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:20:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:20:39 --> Final output sent to browser
DEBUG - 2011-06-02 11:20:39 --> Total execution time: 0.2493
DEBUG - 2011-06-02 11:20:43 --> Config Class Initialized
DEBUG - 2011-06-02 11:20:43 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:20:43 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:20:43 --> URI Class Initialized
DEBUG - 2011-06-02 11:20:43 --> Router Class Initialized
ERROR - 2011-06-02 11:20:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 11:20:50 --> Config Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:20:50 --> URI Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Router Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Output Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Input Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:20:50 --> Language Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Loader Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Controller Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Model Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Model Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Model Class Initialized
DEBUG - 2011-06-02 11:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:20:50 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:20:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:20:51 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:20:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:20:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:20:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:20:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:20:51 --> Final output sent to browser
DEBUG - 2011-06-02 11:20:51 --> Total execution time: 0.6288
DEBUG - 2011-06-02 11:21:03 --> Config Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:21:03 --> URI Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Router Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Output Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Input Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:21:03 --> Language Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Loader Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Controller Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:21:03 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:21:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:21:05 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:21:05 --> Final output sent to browser
DEBUG - 2011-06-02 11:21:05 --> Total execution time: 2.5935
DEBUG - 2011-06-02 11:21:08 --> Config Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:21:08 --> URI Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Router Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Output Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Input Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:21:08 --> Language Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Loader Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Controller Class Initialized
DEBUG - 2011-06-02 11:21:08 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:09 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:09 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:21:09 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:21:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:21:09 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:21:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:21:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:21:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:21:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:21:09 --> Final output sent to browser
DEBUG - 2011-06-02 11:21:09 --> Total execution time: 0.4921
DEBUG - 2011-06-02 11:21:20 --> Config Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:21:20 --> URI Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Router Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Output Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Input Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:21:20 --> Language Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Loader Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Controller Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:21:20 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:21:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:21:21 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:21:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:21:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:21:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:21:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:21:21 --> Final output sent to browser
DEBUG - 2011-06-02 11:21:21 --> Total execution time: 0.3682
DEBUG - 2011-06-02 11:21:52 --> Config Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:21:52 --> URI Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Router Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Output Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Input Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:21:52 --> Language Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Loader Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Controller Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:21:52 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:21:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:21:52 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:21:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:21:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:21:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:21:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:21:52 --> Final output sent to browser
DEBUG - 2011-06-02 11:21:52 --> Total execution time: 0.1986
DEBUG - 2011-06-02 11:21:56 --> Config Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:21:56 --> URI Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Router Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Output Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Input Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:21:56 --> Language Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Loader Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Controller Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Model Class Initialized
DEBUG - 2011-06-02 11:21:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:21:56 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:21:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:21:56 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:21:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:21:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:21:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:21:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:21:56 --> Final output sent to browser
DEBUG - 2011-06-02 11:21:56 --> Total execution time: 0.0527
DEBUG - 2011-06-02 11:22:05 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:05 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:05 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:05 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:06 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:06 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:06 --> Total execution time: 0.9989
DEBUG - 2011-06-02 11:22:09 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:09 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:09 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:09 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:09 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:09 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:09 --> Total execution time: 0.1096
DEBUG - 2011-06-02 11:22:14 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:14 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:14 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:14 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:14 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:14 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:14 --> Total execution time: 0.4952
DEBUG - 2011-06-02 11:22:15 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:15 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:15 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:15 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:15 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:15 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:15 --> Total execution time: 0.0678
DEBUG - 2011-06-02 11:22:19 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:19 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:19 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:19 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:19 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:19 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:19 --> Total execution time: 0.2213
DEBUG - 2011-06-02 11:22:21 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:21 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:21 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:21 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:21 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:21 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:21 --> Total execution time: 0.0672
DEBUG - 2011-06-02 11:22:23 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:23 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:23 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:23 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:23 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:23 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:23 --> Total execution time: 0.7182
DEBUG - 2011-06-02 11:22:26 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:26 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:26 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:26 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:26 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:26 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:26 --> Total execution time: 0.0948
DEBUG - 2011-06-02 11:22:29 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:29 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:29 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:29 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:29 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:29 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:29 --> Total execution time: 0.4102
DEBUG - 2011-06-02 11:22:31 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:31 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:31 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:31 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:31 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:31 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:31 --> Total execution time: 0.0555
DEBUG - 2011-06-02 11:22:36 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:36 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:36 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:36 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:36 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:36 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:36 --> Total execution time: 0.0487
DEBUG - 2011-06-02 11:22:41 --> Config Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:22:41 --> URI Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Router Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Output Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Input Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:22:41 --> Language Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Loader Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Controller Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Model Class Initialized
DEBUG - 2011-06-02 11:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:22:41 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:22:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:22:41 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:22:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:22:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:22:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:22:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:22:41 --> Final output sent to browser
DEBUG - 2011-06-02 11:22:41 --> Total execution time: 0.0491
DEBUG - 2011-06-02 11:50:02 --> Config Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:50:02 --> URI Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Router Class Initialized
ERROR - 2011-06-02 11:50:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 11:50:02 --> Config Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:50:02 --> URI Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Router Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Output Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Input Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:50:02 --> Language Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Loader Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Controller Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Model Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Model Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Model Class Initialized
DEBUG - 2011-06-02 11:50:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:50:02 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:50:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 11:50:04 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:50:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:50:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:50:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:50:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:50:04 --> Final output sent to browser
DEBUG - 2011-06-02 11:50:04 --> Total execution time: 2.0077
DEBUG - 2011-06-02 11:50:35 --> Config Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Hooks Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Utf8 Class Initialized
DEBUG - 2011-06-02 11:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 11:50:35 --> URI Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Router Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Output Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Input Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 11:50:35 --> Language Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Loader Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Controller Class Initialized
ERROR - 2011-06-02 11:50:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 11:50:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 11:50:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 11:50:35 --> Model Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Model Class Initialized
DEBUG - 2011-06-02 11:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 11:50:35 --> Database Driver Class Initialized
DEBUG - 2011-06-02 11:50:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 11:50:35 --> Helper loaded: url_helper
DEBUG - 2011-06-02 11:50:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 11:50:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 11:50:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 11:50:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 11:50:35 --> Final output sent to browser
DEBUG - 2011-06-02 11:50:35 --> Total execution time: 0.1444
DEBUG - 2011-06-02 13:32:22 --> Config Class Initialized
DEBUG - 2011-06-02 13:32:22 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:32:22 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:32:22 --> URI Class Initialized
DEBUG - 2011-06-02 13:32:22 --> Router Class Initialized
DEBUG - 2011-06-02 13:32:22 --> No URI present. Default controller set.
DEBUG - 2011-06-02 13:32:22 --> Output Class Initialized
DEBUG - 2011-06-02 13:32:22 --> Input Class Initialized
DEBUG - 2011-06-02 13:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 13:32:22 --> Language Class Initialized
DEBUG - 2011-06-02 13:32:22 --> Loader Class Initialized
DEBUG - 2011-06-02 13:32:22 --> Controller Class Initialized
DEBUG - 2011-06-02 13:32:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-02 13:32:22 --> Helper loaded: url_helper
DEBUG - 2011-06-02 13:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 13:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 13:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 13:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 13:32:22 --> Final output sent to browser
DEBUG - 2011-06-02 13:32:22 --> Total execution time: 0.2649
DEBUG - 2011-06-02 13:32:24 --> Config Class Initialized
DEBUG - 2011-06-02 13:32:24 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:32:24 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:32:24 --> URI Class Initialized
DEBUG - 2011-06-02 13:32:24 --> Router Class Initialized
ERROR - 2011-06-02 13:32:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 13:32:24 --> Config Class Initialized
DEBUG - 2011-06-02 13:32:24 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:32:24 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:32:24 --> URI Class Initialized
DEBUG - 2011-06-02 13:32:24 --> Router Class Initialized
ERROR - 2011-06-02 13:32:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 13:32:32 --> Config Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:32:32 --> URI Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Router Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Output Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Input Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 13:32:32 --> Language Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Loader Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Controller Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Model Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Model Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Model Class Initialized
DEBUG - 2011-06-02 13:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 13:32:32 --> Database Driver Class Initialized
DEBUG - 2011-06-02 13:32:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 13:32:34 --> Helper loaded: url_helper
DEBUG - 2011-06-02 13:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 13:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 13:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 13:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 13:32:34 --> Final output sent to browser
DEBUG - 2011-06-02 13:32:34 --> Total execution time: 1.7387
DEBUG - 2011-06-02 13:32:35 --> Config Class Initialized
DEBUG - 2011-06-02 13:32:35 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:32:35 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:32:35 --> URI Class Initialized
DEBUG - 2011-06-02 13:32:35 --> Router Class Initialized
ERROR - 2011-06-02 13:32:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 13:32:47 --> Config Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:32:47 --> URI Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Router Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Output Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Input Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 13:32:47 --> Language Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Loader Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Controller Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Model Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Model Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Model Class Initialized
DEBUG - 2011-06-02 13:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 13:32:47 --> Database Driver Class Initialized
DEBUG - 2011-06-02 13:32:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 13:32:48 --> Helper loaded: url_helper
DEBUG - 2011-06-02 13:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 13:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 13:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 13:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 13:32:48 --> Final output sent to browser
DEBUG - 2011-06-02 13:32:48 --> Total execution time: 0.5985
DEBUG - 2011-06-02 13:32:49 --> Config Class Initialized
DEBUG - 2011-06-02 13:32:49 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:32:49 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:32:49 --> URI Class Initialized
DEBUG - 2011-06-02 13:32:49 --> Router Class Initialized
ERROR - 2011-06-02 13:32:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 13:33:03 --> Config Class Initialized
DEBUG - 2011-06-02 13:33:03 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:33:03 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:33:03 --> URI Class Initialized
DEBUG - 2011-06-02 13:33:03 --> Router Class Initialized
ERROR - 2011-06-02 13:33:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 13:33:04 --> Config Class Initialized
DEBUG - 2011-06-02 13:33:04 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:33:04 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:33:04 --> URI Class Initialized
DEBUG - 2011-06-02 13:33:04 --> Router Class Initialized
ERROR - 2011-06-02 13:33:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 13:42:58 --> Config Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:42:58 --> URI Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Router Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Output Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Input Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 13:42:58 --> Language Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Loader Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Controller Class Initialized
ERROR - 2011-06-02 13:42:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 13:42:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 13:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 13:42:58 --> Model Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Model Class Initialized
DEBUG - 2011-06-02 13:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 13:42:58 --> Database Driver Class Initialized
DEBUG - 2011-06-02 13:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 13:42:58 --> Helper loaded: url_helper
DEBUG - 2011-06-02 13:42:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 13:42:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 13:42:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 13:42:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 13:42:58 --> Final output sent to browser
DEBUG - 2011-06-02 13:42:58 --> Total execution time: 0.0950
DEBUG - 2011-06-02 13:43:14 --> Config Class Initialized
DEBUG - 2011-06-02 13:43:14 --> Hooks Class Initialized
DEBUG - 2011-06-02 13:43:14 --> Utf8 Class Initialized
DEBUG - 2011-06-02 13:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 13:43:14 --> URI Class Initialized
DEBUG - 2011-06-02 13:43:14 --> Router Class Initialized
DEBUG - 2011-06-02 13:43:14 --> No URI present. Default controller set.
DEBUG - 2011-06-02 13:43:14 --> Output Class Initialized
DEBUG - 2011-06-02 13:43:14 --> Input Class Initialized
DEBUG - 2011-06-02 13:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 13:43:14 --> Language Class Initialized
DEBUG - 2011-06-02 13:43:14 --> Loader Class Initialized
DEBUG - 2011-06-02 13:43:14 --> Controller Class Initialized
DEBUG - 2011-06-02 13:43:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-02 13:43:14 --> Helper loaded: url_helper
DEBUG - 2011-06-02 13:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 13:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 13:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 13:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 13:43:14 --> Final output sent to browser
DEBUG - 2011-06-02 13:43:14 --> Total execution time: 0.0269
DEBUG - 2011-06-02 14:10:44 --> Config Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Hooks Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Utf8 Class Initialized
DEBUG - 2011-06-02 14:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 14:10:44 --> URI Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Router Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Output Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Input Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 14:10:44 --> Language Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Loader Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Controller Class Initialized
ERROR - 2011-06-02 14:10:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 14:10:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 14:10:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 14:10:44 --> Model Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Model Class Initialized
DEBUG - 2011-06-02 14:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 14:10:44 --> Database Driver Class Initialized
DEBUG - 2011-06-02 14:10:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 14:10:44 --> Helper loaded: url_helper
DEBUG - 2011-06-02 14:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 14:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 14:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 14:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 14:10:44 --> Final output sent to browser
DEBUG - 2011-06-02 14:10:44 --> Total execution time: 0.3353
DEBUG - 2011-06-02 14:10:45 --> Config Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Hooks Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Utf8 Class Initialized
DEBUG - 2011-06-02 14:10:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 14:10:45 --> URI Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Router Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Output Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Input Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 14:10:45 --> Language Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Loader Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Controller Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Model Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Model Class Initialized
DEBUG - 2011-06-02 14:10:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 14:10:45 --> Database Driver Class Initialized
DEBUG - 2011-06-02 14:10:46 --> Final output sent to browser
DEBUG - 2011-06-02 14:10:46 --> Total execution time: 0.6142
DEBUG - 2011-06-02 14:10:48 --> Config Class Initialized
DEBUG - 2011-06-02 14:10:48 --> Hooks Class Initialized
DEBUG - 2011-06-02 14:10:48 --> Utf8 Class Initialized
DEBUG - 2011-06-02 14:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 14:10:48 --> URI Class Initialized
DEBUG - 2011-06-02 14:10:48 --> Router Class Initialized
ERROR - 2011-06-02 14:10:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 14:10:48 --> Config Class Initialized
DEBUG - 2011-06-02 14:10:48 --> Hooks Class Initialized
DEBUG - 2011-06-02 14:10:48 --> Utf8 Class Initialized
DEBUG - 2011-06-02 14:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 14:10:48 --> URI Class Initialized
DEBUG - 2011-06-02 14:10:48 --> Router Class Initialized
ERROR - 2011-06-02 14:10:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 14:10:49 --> Config Class Initialized
DEBUG - 2011-06-02 14:10:49 --> Hooks Class Initialized
DEBUG - 2011-06-02 14:10:49 --> Utf8 Class Initialized
DEBUG - 2011-06-02 14:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 14:10:49 --> URI Class Initialized
DEBUG - 2011-06-02 14:10:49 --> Router Class Initialized
ERROR - 2011-06-02 14:10:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 14:27:54 --> Config Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Hooks Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Utf8 Class Initialized
DEBUG - 2011-06-02 14:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 14:27:54 --> URI Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Router Class Initialized
ERROR - 2011-06-02 14:27:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 14:27:54 --> Config Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Hooks Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Utf8 Class Initialized
DEBUG - 2011-06-02 14:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 14:27:54 --> URI Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Router Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Output Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Input Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 14:27:54 --> Language Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Loader Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Controller Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Model Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Model Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Model Class Initialized
DEBUG - 2011-06-02 14:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 14:27:54 --> Database Driver Class Initialized
DEBUG - 2011-06-02 14:27:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 14:27:55 --> Helper loaded: url_helper
DEBUG - 2011-06-02 14:27:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 14:27:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 14:27:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 14:27:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 14:27:55 --> Final output sent to browser
DEBUG - 2011-06-02 14:27:55 --> Total execution time: 0.7734
DEBUG - 2011-06-02 15:47:07 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:07 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:07 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:07 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:07 --> Router Class Initialized
DEBUG - 2011-06-02 15:47:07 --> No URI present. Default controller set.
DEBUG - 2011-06-02 15:47:07 --> Output Class Initialized
DEBUG - 2011-06-02 15:47:07 --> Input Class Initialized
DEBUG - 2011-06-02 15:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:47:07 --> Language Class Initialized
DEBUG - 2011-06-02 15:47:07 --> Loader Class Initialized
DEBUG - 2011-06-02 15:47:07 --> Controller Class Initialized
DEBUG - 2011-06-02 15:47:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-02 15:47:07 --> Helper loaded: url_helper
DEBUG - 2011-06-02 15:47:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 15:47:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 15:47:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 15:47:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 15:47:08 --> Final output sent to browser
DEBUG - 2011-06-02 15:47:08 --> Total execution time: 0.2864
DEBUG - 2011-06-02 15:47:08 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:08 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:08 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:08 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:08 --> Router Class Initialized
ERROR - 2011-06-02 15:47:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 15:47:22 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:22 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:22 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:22 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:22 --> Router Class Initialized
DEBUG - 2011-06-02 15:47:22 --> Output Class Initialized
DEBUG - 2011-06-02 15:47:22 --> Input Class Initialized
DEBUG - 2011-06-02 15:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:47:22 --> Language Class Initialized
DEBUG - 2011-06-02 15:47:22 --> Loader Class Initialized
DEBUG - 2011-06-02 15:47:22 --> Controller Class Initialized
ERROR - 2011-06-02 15:47:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 15:47:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 15:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:47:23 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:47:23 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:47:23 --> Helper loaded: url_helper
DEBUG - 2011-06-02 15:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 15:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 15:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 15:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 15:47:23 --> Final output sent to browser
DEBUG - 2011-06-02 15:47:23 --> Total execution time: 0.2353
DEBUG - 2011-06-02 15:47:23 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:23 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Router Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Output Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Input Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:47:23 --> Language Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Loader Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Controller Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:47:23 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:47:24 --> Final output sent to browser
DEBUG - 2011-06-02 15:47:24 --> Total execution time: 0.7157
DEBUG - 2011-06-02 15:47:25 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:25 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Router Class Initialized
ERROR - 2011-06-02 15:47:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 15:47:25 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:25 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Router Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Output Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Input Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:47:25 --> Language Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Loader Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Controller Class Initialized
ERROR - 2011-06-02 15:47:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 15:47:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 15:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:47:25 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:47:25 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:47:25 --> Helper loaded: url_helper
DEBUG - 2011-06-02 15:47:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 15:47:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 15:47:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 15:47:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 15:47:25 --> Final output sent to browser
DEBUG - 2011-06-02 15:47:25 --> Total execution time: 0.0447
DEBUG - 2011-06-02 15:47:36 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:36 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Router Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Output Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Input Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:47:36 --> Language Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Loader Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Controller Class Initialized
ERROR - 2011-06-02 15:47:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 15:47:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 15:47:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:47:36 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:47:36 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:47:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:47:36 --> Helper loaded: url_helper
DEBUG - 2011-06-02 15:47:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 15:47:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 15:47:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 15:47:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 15:47:36 --> Final output sent to browser
DEBUG - 2011-06-02 15:47:36 --> Total execution time: 0.0433
DEBUG - 2011-06-02 15:47:36 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:36 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Router Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Output Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Input Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:47:36 --> Language Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Loader Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Controller Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:47:36 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Config Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:47:37 --> URI Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Router Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Output Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Input Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:47:37 --> Language Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Loader Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Controller Class Initialized
ERROR - 2011-06-02 15:47:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 15:47:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 15:47:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:47:37 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Model Class Initialized
DEBUG - 2011-06-02 15:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:47:37 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:47:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:47:37 --> Helper loaded: url_helper
DEBUG - 2011-06-02 15:47:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 15:47:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 15:47:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 15:47:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 15:47:37 --> Final output sent to browser
DEBUG - 2011-06-02 15:47:37 --> Total execution time: 0.0282
DEBUG - 2011-06-02 15:47:37 --> Final output sent to browser
DEBUG - 2011-06-02 15:47:37 --> Total execution time: 0.5755
DEBUG - 2011-06-02 15:48:08 --> Config Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:48:08 --> URI Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Router Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Output Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Input Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:48:08 --> Language Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Loader Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Controller Class Initialized
ERROR - 2011-06-02 15:48:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 15:48:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 15:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:48:08 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:48:08 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:48:08 --> Helper loaded: url_helper
DEBUG - 2011-06-02 15:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 15:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 15:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 15:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 15:48:08 --> Final output sent to browser
DEBUG - 2011-06-02 15:48:08 --> Total execution time: 0.0385
DEBUG - 2011-06-02 15:48:12 --> Config Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:48:12 --> URI Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Router Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Output Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Input Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:48:12 --> Language Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Loader Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Controller Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:48:12 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:48:13 --> Final output sent to browser
DEBUG - 2011-06-02 15:48:13 --> Total execution time: 0.7121
DEBUG - 2011-06-02 15:48:38 --> Config Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:48:38 --> URI Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Router Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Output Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Input Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:48:38 --> Language Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Loader Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Controller Class Initialized
ERROR - 2011-06-02 15:48:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 15:48:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 15:48:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:48:38 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:48:38 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:48:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:48:38 --> Helper loaded: url_helper
DEBUG - 2011-06-02 15:48:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 15:48:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 15:48:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 15:48:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 15:48:38 --> Final output sent to browser
DEBUG - 2011-06-02 15:48:38 --> Total execution time: 0.1023
DEBUG - 2011-06-02 15:48:40 --> Config Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:48:40 --> URI Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Router Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Output Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Input Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:48:40 --> Language Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Loader Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Controller Class Initialized
ERROR - 2011-06-02 15:48:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 15:48:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 15:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:48:40 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:48:40 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 15:48:40 --> Helper loaded: url_helper
DEBUG - 2011-06-02 15:48:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 15:48:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 15:48:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 15:48:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 15:48:40 --> Final output sent to browser
DEBUG - 2011-06-02 15:48:40 --> Total execution time: 0.1265
DEBUG - 2011-06-02 15:48:40 --> Config Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Hooks Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Utf8 Class Initialized
DEBUG - 2011-06-02 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 15:48:40 --> URI Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Router Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Output Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Input Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 15:48:40 --> Language Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Loader Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Controller Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Model Class Initialized
DEBUG - 2011-06-02 15:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 15:48:40 --> Database Driver Class Initialized
DEBUG - 2011-06-02 15:48:41 --> Final output sent to browser
DEBUG - 2011-06-02 15:48:41 --> Total execution time: 0.6563
DEBUG - 2011-06-02 16:21:00 --> Config Class Initialized
DEBUG - 2011-06-02 16:21:00 --> Hooks Class Initialized
DEBUG - 2011-06-02 16:21:00 --> Utf8 Class Initialized
DEBUG - 2011-06-02 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 16:21:00 --> URI Class Initialized
DEBUG - 2011-06-02 16:21:00 --> Router Class Initialized
ERROR - 2011-06-02 16:21:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 16:21:03 --> Config Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Hooks Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Utf8 Class Initialized
DEBUG - 2011-06-02 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 16:21:03 --> URI Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Router Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Output Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Input Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 16:21:03 --> Language Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Loader Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Controller Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Model Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Model Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Model Class Initialized
DEBUG - 2011-06-02 16:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 16:21:03 --> Database Driver Class Initialized
DEBUG - 2011-06-02 16:21:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 16:21:03 --> Helper loaded: url_helper
DEBUG - 2011-06-02 16:21:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 16:21:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 16:21:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 16:21:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 16:21:03 --> Final output sent to browser
DEBUG - 2011-06-02 16:21:03 --> Total execution time: 0.4628
DEBUG - 2011-06-02 18:07:02 --> Config Class Initialized
DEBUG - 2011-06-02 18:07:02 --> Hooks Class Initialized
DEBUG - 2011-06-02 18:07:02 --> Utf8 Class Initialized
DEBUG - 2011-06-02 18:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 18:07:02 --> URI Class Initialized
DEBUG - 2011-06-02 18:07:02 --> Router Class Initialized
ERROR - 2011-06-02 18:07:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 18:26:25 --> Config Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Hooks Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Utf8 Class Initialized
DEBUG - 2011-06-02 18:26:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 18:26:25 --> URI Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Router Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Output Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Input Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 18:26:25 --> Language Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Loader Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Controller Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Model Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Model Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Model Class Initialized
DEBUG - 2011-06-02 18:26:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 18:26:25 --> Database Driver Class Initialized
DEBUG - 2011-06-02 18:26:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 18:26:25 --> Helper loaded: url_helper
DEBUG - 2011-06-02 18:26:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 18:26:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 18:26:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 18:26:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 18:26:25 --> Final output sent to browser
DEBUG - 2011-06-02 18:26:25 --> Total execution time: 0.5252
DEBUG - 2011-06-02 19:46:03 --> Config Class Initialized
DEBUG - 2011-06-02 19:46:03 --> Hooks Class Initialized
DEBUG - 2011-06-02 19:46:03 --> Utf8 Class Initialized
DEBUG - 2011-06-02 19:46:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 19:46:03 --> URI Class Initialized
DEBUG - 2011-06-02 19:46:03 --> Router Class Initialized
DEBUG - 2011-06-02 19:46:04 --> Output Class Initialized
DEBUG - 2011-06-02 19:46:04 --> Input Class Initialized
DEBUG - 2011-06-02 19:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 19:46:04 --> Language Class Initialized
DEBUG - 2011-06-02 19:46:04 --> Loader Class Initialized
DEBUG - 2011-06-02 19:46:04 --> Controller Class Initialized
ERROR - 2011-06-02 19:46:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 19:46:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 19:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 19:46:04 --> Model Class Initialized
DEBUG - 2011-06-02 19:46:04 --> Model Class Initialized
DEBUG - 2011-06-02 19:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 19:46:04 --> Database Driver Class Initialized
DEBUG - 2011-06-02 19:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 19:46:05 --> Helper loaded: url_helper
DEBUG - 2011-06-02 19:46:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 19:46:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 19:46:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 19:46:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 19:46:05 --> Final output sent to browser
DEBUG - 2011-06-02 19:46:05 --> Total execution time: 1.9737
DEBUG - 2011-06-02 20:39:53 --> Config Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Hooks Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Utf8 Class Initialized
DEBUG - 2011-06-02 20:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 20:39:53 --> URI Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Router Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Output Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Input Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 20:39:53 --> Language Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Loader Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Controller Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Model Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Model Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Model Class Initialized
DEBUG - 2011-06-02 20:39:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 20:39:53 --> Database Driver Class Initialized
DEBUG - 2011-06-02 20:39:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-02 20:39:53 --> Helper loaded: url_helper
DEBUG - 2011-06-02 20:39:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 20:39:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 20:39:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 20:39:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 20:39:53 --> Final output sent to browser
DEBUG - 2011-06-02 20:39:53 --> Total execution time: 0.5501
DEBUG - 2011-06-02 20:39:54 --> Config Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Hooks Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Utf8 Class Initialized
DEBUG - 2011-06-02 20:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 20:39:54 --> URI Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Router Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Output Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Input Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 20:39:54 --> Language Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Loader Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Controller Class Initialized
ERROR - 2011-06-02 20:39:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 20:39:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 20:39:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 20:39:54 --> Model Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Model Class Initialized
DEBUG - 2011-06-02 20:39:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 20:39:54 --> Database Driver Class Initialized
DEBUG - 2011-06-02 20:39:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 20:39:54 --> Helper loaded: url_helper
DEBUG - 2011-06-02 20:39:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 20:39:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 20:39:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 20:39:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 20:39:54 --> Final output sent to browser
DEBUG - 2011-06-02 20:39:54 --> Total execution time: 0.0848
DEBUG - 2011-06-02 20:58:01 --> Config Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Hooks Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Utf8 Class Initialized
DEBUG - 2011-06-02 20:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 20:58:01 --> URI Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Router Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Output Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Input Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 20:58:01 --> Language Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Loader Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Controller Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Model Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Model Class Initialized
DEBUG - 2011-06-02 20:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 20:58:01 --> Database Driver Class Initialized
DEBUG - 2011-06-02 20:58:02 --> Final output sent to browser
DEBUG - 2011-06-02 20:58:02 --> Total execution time: 0.6108
DEBUG - 2011-06-02 23:05:06 --> Config Class Initialized
DEBUG - 2011-06-02 23:05:06 --> Hooks Class Initialized
DEBUG - 2011-06-02 23:05:06 --> Utf8 Class Initialized
DEBUG - 2011-06-02 23:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 23:05:06 --> URI Class Initialized
DEBUG - 2011-06-02 23:05:06 --> Router Class Initialized
DEBUG - 2011-06-02 23:05:06 --> Output Class Initialized
DEBUG - 2011-06-02 23:05:06 --> Input Class Initialized
DEBUG - 2011-06-02 23:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 23:05:06 --> Language Class Initialized
DEBUG - 2011-06-02 23:05:06 --> Loader Class Initialized
DEBUG - 2011-06-02 23:05:06 --> Controller Class Initialized
ERROR - 2011-06-02 23:05:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 23:05:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 23:05:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 23:05:07 --> Model Class Initialized
DEBUG - 2011-06-02 23:05:07 --> Model Class Initialized
DEBUG - 2011-06-02 23:05:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 23:05:07 --> Database Driver Class Initialized
DEBUG - 2011-06-02 23:05:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 23:05:07 --> Helper loaded: url_helper
DEBUG - 2011-06-02 23:05:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 23:05:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 23:05:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 23:05:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 23:05:07 --> Final output sent to browser
DEBUG - 2011-06-02 23:05:07 --> Total execution time: 0.8863
DEBUG - 2011-06-02 23:05:09 --> Config Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Hooks Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Utf8 Class Initialized
DEBUG - 2011-06-02 23:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 23:05:09 --> URI Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Router Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Output Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Input Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 23:05:09 --> Language Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Loader Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Controller Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Model Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Model Class Initialized
DEBUG - 2011-06-02 23:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 23:05:09 --> Database Driver Class Initialized
DEBUG - 2011-06-02 23:05:10 --> Final output sent to browser
DEBUG - 2011-06-02 23:05:10 --> Total execution time: 0.7630
DEBUG - 2011-06-02 23:05:12 --> Config Class Initialized
DEBUG - 2011-06-02 23:05:12 --> Hooks Class Initialized
DEBUG - 2011-06-02 23:05:12 --> Utf8 Class Initialized
DEBUG - 2011-06-02 23:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 23:05:12 --> URI Class Initialized
DEBUG - 2011-06-02 23:05:12 --> Router Class Initialized
ERROR - 2011-06-02 23:05:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 23:05:21 --> Config Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Hooks Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Utf8 Class Initialized
DEBUG - 2011-06-02 23:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 23:05:21 --> URI Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Router Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Output Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Input Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 23:05:21 --> Language Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Loader Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Controller Class Initialized
ERROR - 2011-06-02 23:05:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 23:05:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 23:05:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 23:05:21 --> Model Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Model Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 23:05:21 --> Database Driver Class Initialized
DEBUG - 2011-06-02 23:05:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 23:05:21 --> Helper loaded: url_helper
DEBUG - 2011-06-02 23:05:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 23:05:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 23:05:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 23:05:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 23:05:21 --> Final output sent to browser
DEBUG - 2011-06-02 23:05:21 --> Total execution time: 0.0291
DEBUG - 2011-06-02 23:05:21 --> Config Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Hooks Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Utf8 Class Initialized
DEBUG - 2011-06-02 23:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 23:05:21 --> URI Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Router Class Initialized
DEBUG - 2011-06-02 23:05:21 --> Output Class Initialized
DEBUG - 2011-06-02 23:05:22 --> Input Class Initialized
DEBUG - 2011-06-02 23:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 23:05:22 --> Language Class Initialized
DEBUG - 2011-06-02 23:05:22 --> Loader Class Initialized
DEBUG - 2011-06-02 23:05:22 --> Controller Class Initialized
DEBUG - 2011-06-02 23:05:22 --> Model Class Initialized
DEBUG - 2011-06-02 23:05:22 --> Model Class Initialized
DEBUG - 2011-06-02 23:05:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 23:05:22 --> Database Driver Class Initialized
DEBUG - 2011-06-02 23:05:22 --> Final output sent to browser
DEBUG - 2011-06-02 23:05:22 --> Total execution time: 0.5679
DEBUG - 2011-06-02 23:05:23 --> Config Class Initialized
DEBUG - 2011-06-02 23:05:23 --> Hooks Class Initialized
DEBUG - 2011-06-02 23:05:23 --> Utf8 Class Initialized
DEBUG - 2011-06-02 23:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 23:05:23 --> URI Class Initialized
DEBUG - 2011-06-02 23:05:23 --> Router Class Initialized
ERROR - 2011-06-02 23:05:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-02 23:29:42 --> Config Class Initialized
DEBUG - 2011-06-02 23:29:42 --> Hooks Class Initialized
DEBUG - 2011-06-02 23:29:42 --> Utf8 Class Initialized
DEBUG - 2011-06-02 23:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 23:29:42 --> URI Class Initialized
DEBUG - 2011-06-02 23:29:42 --> Router Class Initialized
ERROR - 2011-06-02 23:29:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-02 23:59:19 --> Config Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Hooks Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Utf8 Class Initialized
DEBUG - 2011-06-02 23:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-02 23:59:19 --> URI Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Router Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Output Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Input Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-02 23:59:19 --> Language Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Loader Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Controller Class Initialized
ERROR - 2011-06-02 23:59:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-02 23:59:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-02 23:59:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 23:59:19 --> Model Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Model Class Initialized
DEBUG - 2011-06-02 23:59:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-02 23:59:19 --> Database Driver Class Initialized
DEBUG - 2011-06-02 23:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-02 23:59:20 --> Helper loaded: url_helper
DEBUG - 2011-06-02 23:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-02 23:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-02 23:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-02 23:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-02 23:59:20 --> Final output sent to browser
DEBUG - 2011-06-02 23:59:20 --> Total execution time: 0.5569

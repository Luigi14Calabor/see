<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-18 00:23:54 --> Config Class Initialized
DEBUG - 2011-04-18 00:23:54 --> Hooks Class Initialized
DEBUG - 2011-04-18 00:23:54 --> Utf8 Class Initialized
DEBUG - 2011-04-18 00:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 00:23:54 --> URI Class Initialized
DEBUG - 2011-04-18 00:23:54 --> Router Class Initialized
DEBUG - 2011-04-18 00:23:54 --> No URI present. Default controller set.
DEBUG - 2011-04-18 00:23:54 --> Output Class Initialized
DEBUG - 2011-04-18 00:23:54 --> Input Class Initialized
DEBUG - 2011-04-18 00:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 00:23:54 --> Language Class Initialized
DEBUG - 2011-04-18 00:23:54 --> Loader Class Initialized
DEBUG - 2011-04-18 00:23:54 --> Controller Class Initialized
DEBUG - 2011-04-18 00:23:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 00:23:54 --> Helper loaded: url_helper
DEBUG - 2011-04-18 00:23:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 00:23:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 00:23:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 00:23:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 00:23:54 --> Final output sent to browser
DEBUG - 2011-04-18 00:23:54 --> Total execution time: 0.2343
DEBUG - 2011-04-18 00:23:55 --> Config Class Initialized
DEBUG - 2011-04-18 00:23:55 --> Hooks Class Initialized
DEBUG - 2011-04-18 00:23:55 --> Utf8 Class Initialized
DEBUG - 2011-04-18 00:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 00:23:56 --> URI Class Initialized
DEBUG - 2011-04-18 00:23:56 --> Router Class Initialized
ERROR - 2011-04-18 00:23:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 00:24:00 --> Config Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Hooks Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Utf8 Class Initialized
DEBUG - 2011-04-18 00:24:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 00:24:00 --> URI Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Router Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Output Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Input Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 00:24:00 --> Language Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Loader Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Controller Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Model Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Model Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Model Class Initialized
DEBUG - 2011-04-18 00:24:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 00:24:00 --> Database Driver Class Initialized
DEBUG - 2011-04-18 00:24:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 00:24:00 --> Helper loaded: url_helper
DEBUG - 2011-04-18 00:24:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 00:24:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 00:24:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 00:24:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 00:24:00 --> Final output sent to browser
DEBUG - 2011-04-18 00:24:00 --> Total execution time: 0.3187
DEBUG - 2011-04-18 00:24:07 --> Config Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Hooks Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Utf8 Class Initialized
DEBUG - 2011-04-18 00:24:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 00:24:07 --> URI Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Router Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Output Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Input Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 00:24:07 --> Language Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Loader Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Controller Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Model Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Model Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Model Class Initialized
DEBUG - 2011-04-18 00:24:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 00:24:07 --> Database Driver Class Initialized
DEBUG - 2011-04-18 00:24:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 00:24:07 --> Helper loaded: url_helper
DEBUG - 2011-04-18 00:24:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 00:24:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 00:24:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 00:24:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 00:24:07 --> Final output sent to browser
DEBUG - 2011-04-18 00:24:07 --> Total execution time: 0.4199
DEBUG - 2011-04-18 00:28:19 --> Config Class Initialized
DEBUG - 2011-04-18 00:28:19 --> Hooks Class Initialized
DEBUG - 2011-04-18 00:28:19 --> Utf8 Class Initialized
DEBUG - 2011-04-18 00:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 00:28:19 --> URI Class Initialized
DEBUG - 2011-04-18 00:28:19 --> Router Class Initialized
DEBUG - 2011-04-18 00:28:19 --> No URI present. Default controller set.
DEBUG - 2011-04-18 00:28:19 --> Output Class Initialized
DEBUG - 2011-04-18 00:28:19 --> Input Class Initialized
DEBUG - 2011-04-18 00:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 00:28:19 --> Language Class Initialized
DEBUG - 2011-04-18 00:28:19 --> Loader Class Initialized
DEBUG - 2011-04-18 00:28:19 --> Controller Class Initialized
DEBUG - 2011-04-18 00:28:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 00:28:19 --> Helper loaded: url_helper
DEBUG - 2011-04-18 00:28:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 00:28:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 00:28:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 00:28:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 00:28:19 --> Final output sent to browser
DEBUG - 2011-04-18 00:28:19 --> Total execution time: 0.0161
DEBUG - 2011-04-18 01:02:19 --> Config Class Initialized
DEBUG - 2011-04-18 01:02:19 --> Hooks Class Initialized
DEBUG - 2011-04-18 01:02:19 --> Utf8 Class Initialized
DEBUG - 2011-04-18 01:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 01:02:19 --> URI Class Initialized
DEBUG - 2011-04-18 01:02:19 --> Router Class Initialized
ERROR - 2011-04-18 01:02:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-18 01:03:01 --> Config Class Initialized
DEBUG - 2011-04-18 01:03:01 --> Hooks Class Initialized
DEBUG - 2011-04-18 01:03:01 --> Utf8 Class Initialized
DEBUG - 2011-04-18 01:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 01:03:01 --> URI Class Initialized
DEBUG - 2011-04-18 01:03:01 --> Router Class Initialized
DEBUG - 2011-04-18 01:03:01 --> No URI present. Default controller set.
DEBUG - 2011-04-18 01:03:01 --> Output Class Initialized
DEBUG - 2011-04-18 01:03:01 --> Input Class Initialized
DEBUG - 2011-04-18 01:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 01:03:01 --> Language Class Initialized
DEBUG - 2011-04-18 01:03:01 --> Loader Class Initialized
DEBUG - 2011-04-18 01:03:01 --> Controller Class Initialized
DEBUG - 2011-04-18 01:03:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 01:03:02 --> Helper loaded: url_helper
DEBUG - 2011-04-18 01:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 01:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 01:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 01:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 01:03:02 --> Final output sent to browser
DEBUG - 2011-04-18 01:03:02 --> Total execution time: 0.7174
DEBUG - 2011-04-18 01:08:47 --> Config Class Initialized
DEBUG - 2011-04-18 01:08:47 --> Hooks Class Initialized
DEBUG - 2011-04-18 01:08:47 --> Utf8 Class Initialized
DEBUG - 2011-04-18 01:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 01:08:47 --> URI Class Initialized
DEBUG - 2011-04-18 01:08:47 --> Router Class Initialized
ERROR - 2011-04-18 01:08:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-18 01:08:48 --> Config Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 01:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 01:08:48 --> URI Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Router Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Output Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Input Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 01:08:48 --> Language Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Loader Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Controller Class Initialized
ERROR - 2011-04-18 01:08:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 01:08:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 01:08:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 01:08:48 --> Model Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Model Class Initialized
DEBUG - 2011-04-18 01:08:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 01:08:49 --> Database Driver Class Initialized
DEBUG - 2011-04-18 01:08:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 01:08:49 --> Helper loaded: url_helper
DEBUG - 2011-04-18 01:08:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 01:08:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 01:08:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 01:08:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 01:08:49 --> Final output sent to browser
DEBUG - 2011-04-18 01:08:49 --> Total execution time: 0.3030
DEBUG - 2011-04-18 01:18:45 --> Config Class Initialized
DEBUG - 2011-04-18 01:18:45 --> Hooks Class Initialized
DEBUG - 2011-04-18 01:18:45 --> Utf8 Class Initialized
DEBUG - 2011-04-18 01:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 01:18:45 --> URI Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Router Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Output Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Input Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 01:18:46 --> Language Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Loader Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Controller Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Model Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Model Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Model Class Initialized
DEBUG - 2011-04-18 01:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 01:18:46 --> Database Driver Class Initialized
DEBUG - 2011-04-18 01:18:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 01:18:46 --> Helper loaded: url_helper
DEBUG - 2011-04-18 01:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 01:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 01:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 01:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 01:18:46 --> Final output sent to browser
DEBUG - 2011-04-18 01:18:46 --> Total execution time: 0.9555
DEBUG - 2011-04-18 03:12:35 --> Config Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Hooks Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Utf8 Class Initialized
DEBUG - 2011-04-18 03:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 03:12:35 --> URI Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Router Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Output Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Input Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 03:12:35 --> Language Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Loader Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Controller Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Model Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Model Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Model Class Initialized
DEBUG - 2011-04-18 03:12:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 03:12:35 --> Database Driver Class Initialized
DEBUG - 2011-04-18 03:12:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 03:12:44 --> Helper loaded: url_helper
DEBUG - 2011-04-18 03:12:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 03:12:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 03:12:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 03:12:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 03:12:44 --> Final output sent to browser
DEBUG - 2011-04-18 03:12:44 --> Total execution time: 9.4021
DEBUG - 2011-04-18 03:12:45 --> Config Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Hooks Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Utf8 Class Initialized
DEBUG - 2011-04-18 03:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 03:12:45 --> URI Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Router Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Output Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Input Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 03:12:45 --> Language Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Loader Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Controller Class Initialized
ERROR - 2011-04-18 03:12:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 03:12:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 03:12:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 03:12:45 --> Model Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Model Class Initialized
DEBUG - 2011-04-18 03:12:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 03:12:45 --> Database Driver Class Initialized
DEBUG - 2011-04-18 03:12:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 03:12:45 --> Helper loaded: url_helper
DEBUG - 2011-04-18 03:12:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 03:12:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 03:12:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 03:12:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 03:12:45 --> Final output sent to browser
DEBUG - 2011-04-18 03:12:45 --> Total execution time: 0.4185
DEBUG - 2011-04-18 03:13:27 --> Config Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Hooks Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Utf8 Class Initialized
DEBUG - 2011-04-18 03:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 03:13:27 --> URI Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Router Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Output Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Input Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 03:13:27 --> Language Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Loader Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Controller Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Model Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Model Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Model Class Initialized
DEBUG - 2011-04-18 03:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 03:13:27 --> Database Driver Class Initialized
DEBUG - 2011-04-18 03:13:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 03:13:27 --> Helper loaded: url_helper
DEBUG - 2011-04-18 03:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 03:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 03:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 03:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 03:13:27 --> Final output sent to browser
DEBUG - 2011-04-18 03:13:27 --> Total execution time: 0.1454
DEBUG - 2011-04-18 03:13:29 --> Config Class Initialized
DEBUG - 2011-04-18 03:13:29 --> Hooks Class Initialized
DEBUG - 2011-04-18 03:13:29 --> Utf8 Class Initialized
DEBUG - 2011-04-18 03:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 03:13:29 --> URI Class Initialized
DEBUG - 2011-04-18 03:13:29 --> Router Class Initialized
ERROR - 2011-04-18 03:13:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 04:27:17 --> Config Class Initialized
DEBUG - 2011-04-18 04:27:17 --> Hooks Class Initialized
DEBUG - 2011-04-18 04:27:17 --> Utf8 Class Initialized
DEBUG - 2011-04-18 04:27:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 04:27:17 --> URI Class Initialized
DEBUG - 2011-04-18 04:27:17 --> Router Class Initialized
DEBUG - 2011-04-18 04:27:17 --> No URI present. Default controller set.
DEBUG - 2011-04-18 04:27:17 --> Output Class Initialized
DEBUG - 2011-04-18 04:27:17 --> Input Class Initialized
DEBUG - 2011-04-18 04:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 04:27:17 --> Language Class Initialized
DEBUG - 2011-04-18 04:27:17 --> Loader Class Initialized
DEBUG - 2011-04-18 04:27:17 --> Controller Class Initialized
DEBUG - 2011-04-18 04:27:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 04:27:17 --> Helper loaded: url_helper
DEBUG - 2011-04-18 04:27:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 04:27:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 04:27:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 04:27:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 04:27:17 --> Final output sent to browser
DEBUG - 2011-04-18 04:27:17 --> Total execution time: 0.4724
DEBUG - 2011-04-18 04:27:19 --> Config Class Initialized
DEBUG - 2011-04-18 04:27:19 --> Hooks Class Initialized
DEBUG - 2011-04-18 04:27:19 --> Utf8 Class Initialized
DEBUG - 2011-04-18 04:27:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 04:27:19 --> URI Class Initialized
DEBUG - 2011-04-18 04:27:19 --> Router Class Initialized
ERROR - 2011-04-18 04:27:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 04:45:27 --> Config Class Initialized
DEBUG - 2011-04-18 04:45:27 --> Hooks Class Initialized
DEBUG - 2011-04-18 04:45:27 --> Utf8 Class Initialized
DEBUG - 2011-04-18 04:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 04:45:27 --> URI Class Initialized
DEBUG - 2011-04-18 04:45:27 --> Router Class Initialized
DEBUG - 2011-04-18 04:45:27 --> Output Class Initialized
DEBUG - 2011-04-18 04:45:28 --> Input Class Initialized
DEBUG - 2011-04-18 04:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 04:45:28 --> Language Class Initialized
DEBUG - 2011-04-18 04:45:28 --> Loader Class Initialized
DEBUG - 2011-04-18 04:45:28 --> Controller Class Initialized
ERROR - 2011-04-18 04:45:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 04:45:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 04:45:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 04:45:29 --> Model Class Initialized
DEBUG - 2011-04-18 04:45:29 --> Model Class Initialized
DEBUG - 2011-04-18 04:45:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 04:45:29 --> Database Driver Class Initialized
DEBUG - 2011-04-18 04:45:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 04:45:30 --> Helper loaded: url_helper
DEBUG - 2011-04-18 04:45:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 04:45:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 04:45:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 04:45:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 04:45:30 --> Final output sent to browser
DEBUG - 2011-04-18 04:45:30 --> Total execution time: 3.4868
DEBUG - 2011-04-18 04:45:31 --> Config Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Hooks Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Utf8 Class Initialized
DEBUG - 2011-04-18 04:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 04:45:31 --> URI Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Router Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Output Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Input Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 04:45:31 --> Language Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Loader Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Controller Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Model Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Model Class Initialized
DEBUG - 2011-04-18 04:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 04:45:31 --> Database Driver Class Initialized
DEBUG - 2011-04-18 04:45:32 --> Final output sent to browser
DEBUG - 2011-04-18 04:45:32 --> Total execution time: 0.7143
DEBUG - 2011-04-18 05:19:23 --> Config Class Initialized
DEBUG - 2011-04-18 05:19:23 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:19:23 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:19:23 --> URI Class Initialized
DEBUG - 2011-04-18 05:19:23 --> Router Class Initialized
ERROR - 2011-04-18 05:19:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-18 05:20:05 --> Config Class Initialized
DEBUG - 2011-04-18 05:20:05 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:20:05 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:20:05 --> URI Class Initialized
DEBUG - 2011-04-18 05:20:05 --> Router Class Initialized
DEBUG - 2011-04-18 05:20:05 --> Output Class Initialized
DEBUG - 2011-04-18 05:20:05 --> Input Class Initialized
DEBUG - 2011-04-18 05:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:20:05 --> Language Class Initialized
DEBUG - 2011-04-18 05:20:06 --> Loader Class Initialized
DEBUG - 2011-04-18 05:20:06 --> Controller Class Initialized
ERROR - 2011-04-18 05:20:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:20:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:20:06 --> Model Class Initialized
DEBUG - 2011-04-18 05:20:06 --> Model Class Initialized
DEBUG - 2011-04-18 05:20:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:20:06 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:20:07 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:20:07 --> Final output sent to browser
DEBUG - 2011-04-18 05:20:07 --> Total execution time: 1.8657
DEBUG - 2011-04-18 05:42:12 --> Config Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:42:12 --> URI Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Router Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Output Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Input Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:42:12 --> Language Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Loader Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Controller Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:42:12 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Config Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:42:12 --> URI Class Initialized
DEBUG - 2011-04-18 05:42:12 --> Router Class Initialized
DEBUG - 2011-04-18 05:42:13 --> Output Class Initialized
DEBUG - 2011-04-18 05:42:13 --> Input Class Initialized
DEBUG - 2011-04-18 05:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:42:13 --> Language Class Initialized
DEBUG - 2011-04-18 05:42:13 --> Loader Class Initialized
DEBUG - 2011-04-18 05:42:13 --> Controller Class Initialized
ERROR - 2011-04-18 05:42:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:42:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:42:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:42:13 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:13 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:42:13 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:42:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:42:13 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:42:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:42:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:42:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:42:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:42:13 --> Final output sent to browser
DEBUG - 2011-04-18 05:42:13 --> Total execution time: 0.1919
DEBUG - 2011-04-18 05:42:14 --> Config Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:42:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:42:14 --> URI Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Router Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Output Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Input Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:42:14 --> Language Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Loader Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Controller Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:42:14 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:42:15 --> Final output sent to browser
DEBUG - 2011-04-18 05:42:15 --> Total execution time: 1.3460
DEBUG - 2011-04-18 05:42:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 05:42:16 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:42:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:42:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:42:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:42:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:42:16 --> Final output sent to browser
DEBUG - 2011-04-18 05:42:16 --> Total execution time: 3.5858
DEBUG - 2011-04-18 05:42:16 --> Config Class Initialized
DEBUG - 2011-04-18 05:42:16 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:42:16 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:42:16 --> URI Class Initialized
DEBUG - 2011-04-18 05:42:16 --> Router Class Initialized
ERROR - 2011-04-18 05:42:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 05:42:51 --> Config Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:42:51 --> URI Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Router Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Output Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Input Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:42:51 --> Language Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Loader Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Controller Class Initialized
ERROR - 2011-04-18 05:42:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:42:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:42:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:42:51 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:42:51 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:42:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:42:51 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:42:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:42:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:42:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:42:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:42:51 --> Final output sent to browser
DEBUG - 2011-04-18 05:42:51 --> Total execution time: 0.0314
DEBUG - 2011-04-18 05:42:52 --> Config Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:42:52 --> URI Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Router Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Output Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Input Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:42:52 --> Language Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Loader Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Controller Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:42:53 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:42:53 --> Final output sent to browser
DEBUG - 2011-04-18 05:42:53 --> Total execution time: 0.7753
DEBUG - 2011-04-18 05:42:55 --> Config Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:42:55 --> URI Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Router Class Initialized
ERROR - 2011-04-18 05:42:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-18 05:42:55 --> Config Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:42:55 --> URI Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Router Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Output Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Input Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:42:55 --> Language Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Loader Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Controller Class Initialized
ERROR - 2011-04-18 05:42:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:42:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:42:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:42:55 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Model Class Initialized
DEBUG - 2011-04-18 05:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:42:55 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:42:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:42:55 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:42:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:42:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:42:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:42:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:42:55 --> Final output sent to browser
DEBUG - 2011-04-18 05:42:55 --> Total execution time: 0.0348
DEBUG - 2011-04-18 05:43:11 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:11 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:11 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Controller Class Initialized
ERROR - 2011-04-18 05:43:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:43:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:11 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:11 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:11 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:43:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:43:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:43:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:43:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:43:11 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:11 --> Total execution time: 0.0377
DEBUG - 2011-04-18 05:43:12 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:12 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:12 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Controller Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:12 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:14 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:14 --> Total execution time: 1.5010
DEBUG - 2011-04-18 05:43:15 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:15 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:15 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Controller Class Initialized
ERROR - 2011-04-18 05:43:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:43:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:43:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:15 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:15 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:15 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:43:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:43:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:43:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:43:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:43:15 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:15 --> Total execution time: 0.0389
DEBUG - 2011-04-18 05:43:23 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:23 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:23 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Controller Class Initialized
ERROR - 2011-04-18 05:43:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:43:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:43:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:23 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:23 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:23 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:43:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:43:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:43:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:43:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:43:23 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:23 --> Total execution time: 0.0926
DEBUG - 2011-04-18 05:43:24 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:24 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:24 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Controller Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:24 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:24 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:24 --> Total execution time: 0.5238
DEBUG - 2011-04-18 05:43:28 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:28 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:28 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Controller Class Initialized
ERROR - 2011-04-18 05:43:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:43:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:43:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:28 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:28 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:28 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:43:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:43:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:43:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:43:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:43:28 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:28 --> Total execution time: 0.0403
DEBUG - 2011-04-18 05:43:35 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:35 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:35 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Controller Class Initialized
ERROR - 2011-04-18 05:43:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:43:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:43:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:35 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:35 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:35 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:43:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:43:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:43:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:43:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:43:35 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:35 --> Total execution time: 0.0284
DEBUG - 2011-04-18 05:43:36 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:36 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:36 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Controller Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:36 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:36 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:36 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Controller Class Initialized
ERROR - 2011-04-18 05:43:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:43:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:43:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:36 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:36 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:36 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:43:36 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:36 --> Total execution time: 0.0318
DEBUG - 2011-04-18 05:43:38 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:38 --> Total execution time: 1.7207
DEBUG - 2011-04-18 05:43:47 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:47 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:47 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Controller Class Initialized
ERROR - 2011-04-18 05:43:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:43:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:43:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:47 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:47 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:47 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:43:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:43:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:43:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:43:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:43:47 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:47 --> Total execution time: 0.0288
DEBUG - 2011-04-18 05:43:48 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:48 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:48 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Controller Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:48 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:49 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:49 --> Total execution time: 0.8386
DEBUG - 2011-04-18 05:43:58 --> Config Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:43:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:43:58 --> URI Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Router Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Output Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Input Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:43:58 --> Language Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Loader Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Controller Class Initialized
ERROR - 2011-04-18 05:43:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:43:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:43:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:58 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Model Class Initialized
DEBUG - 2011-04-18 05:43:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:43:58 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:43:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:43:58 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:43:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:43:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:43:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:43:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:43:58 --> Final output sent to browser
DEBUG - 2011-04-18 05:43:58 --> Total execution time: 0.0323
DEBUG - 2011-04-18 05:44:02 --> Config Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:44:02 --> URI Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Router Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Output Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Input Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:44:02 --> Language Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Loader Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Controller Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Model Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Model Class Initialized
DEBUG - 2011-04-18 05:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:44:02 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:44:03 --> Final output sent to browser
DEBUG - 2011-04-18 05:44:03 --> Total execution time: 0.5839
DEBUG - 2011-04-18 05:44:49 --> Config Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:44:49 --> URI Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Router Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Output Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Input Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:44:49 --> Language Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Loader Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Controller Class Initialized
ERROR - 2011-04-18 05:44:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:44:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:44:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:44:49 --> Model Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Model Class Initialized
DEBUG - 2011-04-18 05:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:44:49 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:44:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:44:49 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:44:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:44:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:44:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:44:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:44:49 --> Final output sent to browser
DEBUG - 2011-04-18 05:44:49 --> Total execution time: 0.0374
DEBUG - 2011-04-18 05:44:52 --> Config Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:44:52 --> URI Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Router Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Output Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Input Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:44:52 --> Language Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Loader Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Controller Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Model Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Model Class Initialized
DEBUG - 2011-04-18 05:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:44:52 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:44:53 --> Final output sent to browser
DEBUG - 2011-04-18 05:44:53 --> Total execution time: 1.3194
DEBUG - 2011-04-18 05:45:00 --> Config Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:45:00 --> URI Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Router Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Output Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Input Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:45:00 --> Language Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Loader Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Controller Class Initialized
ERROR - 2011-04-18 05:45:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 05:45:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 05:45:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:45:00 --> Model Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Model Class Initialized
DEBUG - 2011-04-18 05:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:45:00 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:45:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 05:45:00 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:45:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:45:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:45:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:45:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:45:00 --> Final output sent to browser
DEBUG - 2011-04-18 05:45:00 --> Total execution time: 0.0343
DEBUG - 2011-04-18 05:45:02 --> Config Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:45:02 --> URI Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Router Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Output Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Input Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:45:02 --> Language Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Loader Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Controller Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Model Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Model Class Initialized
DEBUG - 2011-04-18 05:45:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:45:02 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:45:07 --> Final output sent to browser
DEBUG - 2011-04-18 05:45:07 --> Total execution time: 5.1328
DEBUG - 2011-04-18 05:46:22 --> Config Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Hooks Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Utf8 Class Initialized
DEBUG - 2011-04-18 05:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 05:46:22 --> URI Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Router Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Output Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Input Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 05:46:22 --> Language Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Loader Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Controller Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Model Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Model Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Model Class Initialized
DEBUG - 2011-04-18 05:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 05:46:22 --> Database Driver Class Initialized
DEBUG - 2011-04-18 05:46:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 05:46:22 --> Helper loaded: url_helper
DEBUG - 2011-04-18 05:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 05:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 05:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 05:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 05:46:22 --> Final output sent to browser
DEBUG - 2011-04-18 05:46:22 --> Total execution time: 0.1123
DEBUG - 2011-04-18 06:09:32 --> Config Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Hooks Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Utf8 Class Initialized
DEBUG - 2011-04-18 06:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 06:09:32 --> URI Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Router Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Output Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Input Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 06:09:32 --> Language Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Loader Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Controller Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Model Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Model Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Model Class Initialized
DEBUG - 2011-04-18 06:09:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 06:09:32 --> Database Driver Class Initialized
DEBUG - 2011-04-18 06:09:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 06:09:33 --> Helper loaded: url_helper
DEBUG - 2011-04-18 06:09:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 06:09:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 06:09:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 06:09:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 06:09:33 --> Final output sent to browser
DEBUG - 2011-04-18 06:09:33 --> Total execution time: 0.9556
DEBUG - 2011-04-18 06:11:07 --> Config Class Initialized
DEBUG - 2011-04-18 06:11:07 --> Hooks Class Initialized
DEBUG - 2011-04-18 06:11:07 --> Utf8 Class Initialized
DEBUG - 2011-04-18 06:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 06:11:07 --> URI Class Initialized
DEBUG - 2011-04-18 06:11:07 --> Router Class Initialized
DEBUG - 2011-04-18 06:11:07 --> No URI present. Default controller set.
DEBUG - 2011-04-18 06:11:07 --> Output Class Initialized
DEBUG - 2011-04-18 06:11:07 --> Input Class Initialized
DEBUG - 2011-04-18 06:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 06:11:07 --> Language Class Initialized
DEBUG - 2011-04-18 06:11:07 --> Loader Class Initialized
DEBUG - 2011-04-18 06:11:07 --> Controller Class Initialized
DEBUG - 2011-04-18 06:11:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 06:11:07 --> Helper loaded: url_helper
DEBUG - 2011-04-18 06:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 06:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 06:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 06:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 06:11:07 --> Final output sent to browser
DEBUG - 2011-04-18 06:11:07 --> Total execution time: 0.0961
DEBUG - 2011-04-18 07:34:53 --> Config Class Initialized
DEBUG - 2011-04-18 07:34:53 --> Hooks Class Initialized
DEBUG - 2011-04-18 07:34:53 --> Utf8 Class Initialized
DEBUG - 2011-04-18 07:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 07:34:53 --> URI Class Initialized
DEBUG - 2011-04-18 07:34:53 --> Router Class Initialized
ERROR - 2011-04-18 07:34:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-18 07:34:56 --> Config Class Initialized
DEBUG - 2011-04-18 07:34:56 --> Hooks Class Initialized
DEBUG - 2011-04-18 07:34:56 --> Utf8 Class Initialized
DEBUG - 2011-04-18 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 07:34:56 --> URI Class Initialized
DEBUG - 2011-04-18 07:34:56 --> Router Class Initialized
DEBUG - 2011-04-18 07:34:57 --> Output Class Initialized
DEBUG - 2011-04-18 07:34:57 --> Input Class Initialized
DEBUG - 2011-04-18 07:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 07:34:57 --> Language Class Initialized
DEBUG - 2011-04-18 07:34:58 --> Loader Class Initialized
DEBUG - 2011-04-18 07:34:58 --> Controller Class Initialized
ERROR - 2011-04-18 07:34:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 07:34:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 07:34:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 07:34:59 --> Model Class Initialized
DEBUG - 2011-04-18 07:34:59 --> Model Class Initialized
DEBUG - 2011-04-18 07:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 07:34:59 --> Database Driver Class Initialized
DEBUG - 2011-04-18 07:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 07:34:59 --> Helper loaded: url_helper
DEBUG - 2011-04-18 07:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 07:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 07:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 07:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 07:34:59 --> Final output sent to browser
DEBUG - 2011-04-18 07:34:59 --> Total execution time: 2.7741
DEBUG - 2011-04-18 07:54:02 --> Config Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Hooks Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Utf8 Class Initialized
DEBUG - 2011-04-18 07:54:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 07:54:02 --> URI Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Router Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Output Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Input Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 07:54:02 --> Language Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Loader Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Controller Class Initialized
ERROR - 2011-04-18 07:54:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 07:54:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 07:54:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 07:54:02 --> Model Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Model Class Initialized
DEBUG - 2011-04-18 07:54:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 07:54:02 --> Database Driver Class Initialized
DEBUG - 2011-04-18 07:54:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 07:54:03 --> Helper loaded: url_helper
DEBUG - 2011-04-18 07:54:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 07:54:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 07:54:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 07:54:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 07:54:03 --> Final output sent to browser
DEBUG - 2011-04-18 07:54:03 --> Total execution time: 0.3654
DEBUG - 2011-04-18 07:54:08 --> Config Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Hooks Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Utf8 Class Initialized
DEBUG - 2011-04-18 07:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 07:54:08 --> URI Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Router Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Output Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Input Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 07:54:08 --> Language Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Loader Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Controller Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Model Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Model Class Initialized
DEBUG - 2011-04-18 07:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 07:54:08 --> Database Driver Class Initialized
DEBUG - 2011-04-18 07:54:09 --> Final output sent to browser
DEBUG - 2011-04-18 07:54:09 --> Total execution time: 1.1973
DEBUG - 2011-04-18 07:54:11 --> Config Class Initialized
DEBUG - 2011-04-18 07:54:11 --> Hooks Class Initialized
DEBUG - 2011-04-18 07:54:11 --> Utf8 Class Initialized
DEBUG - 2011-04-18 07:54:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 07:54:11 --> URI Class Initialized
DEBUG - 2011-04-18 07:54:11 --> Router Class Initialized
ERROR - 2011-04-18 07:54:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 07:54:12 --> Config Class Initialized
DEBUG - 2011-04-18 07:54:12 --> Hooks Class Initialized
DEBUG - 2011-04-18 07:54:12 --> Utf8 Class Initialized
DEBUG - 2011-04-18 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 07:54:12 --> URI Class Initialized
DEBUG - 2011-04-18 07:54:12 --> Router Class Initialized
ERROR - 2011-04-18 07:54:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 07:54:14 --> Config Class Initialized
DEBUG - 2011-04-18 07:54:14 --> Hooks Class Initialized
DEBUG - 2011-04-18 07:54:14 --> Utf8 Class Initialized
DEBUG - 2011-04-18 07:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 07:54:14 --> URI Class Initialized
DEBUG - 2011-04-18 07:54:14 --> Router Class Initialized
ERROR - 2011-04-18 07:54:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 08:30:51 --> Config Class Initialized
DEBUG - 2011-04-18 08:30:51 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:30:51 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:30:51 --> URI Class Initialized
DEBUG - 2011-04-18 08:30:51 --> Router Class Initialized
DEBUG - 2011-04-18 08:30:51 --> No URI present. Default controller set.
DEBUG - 2011-04-18 08:30:51 --> Output Class Initialized
DEBUG - 2011-04-18 08:30:51 --> Input Class Initialized
DEBUG - 2011-04-18 08:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:30:51 --> Language Class Initialized
DEBUG - 2011-04-18 08:30:51 --> Loader Class Initialized
DEBUG - 2011-04-18 08:30:51 --> Controller Class Initialized
DEBUG - 2011-04-18 08:30:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 08:30:51 --> Helper loaded: url_helper
DEBUG - 2011-04-18 08:30:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 08:30:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 08:30:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 08:30:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 08:30:51 --> Final output sent to browser
DEBUG - 2011-04-18 08:30:51 --> Total execution time: 0.3214
DEBUG - 2011-04-18 08:30:58 --> Config Class Initialized
DEBUG - 2011-04-18 08:30:58 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:30:58 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:30:58 --> URI Class Initialized
DEBUG - 2011-04-18 08:30:58 --> Router Class Initialized
DEBUG - 2011-04-18 08:30:58 --> No URI present. Default controller set.
DEBUG - 2011-04-18 08:30:58 --> Output Class Initialized
DEBUG - 2011-04-18 08:30:58 --> Input Class Initialized
DEBUG - 2011-04-18 08:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:30:58 --> Language Class Initialized
DEBUG - 2011-04-18 08:30:58 --> Loader Class Initialized
DEBUG - 2011-04-18 08:30:58 --> Controller Class Initialized
DEBUG - 2011-04-18 08:30:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 08:30:58 --> Helper loaded: url_helper
DEBUG - 2011-04-18 08:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 08:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 08:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 08:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 08:30:58 --> Final output sent to browser
DEBUG - 2011-04-18 08:30:58 --> Total execution time: 0.0419
DEBUG - 2011-04-18 08:31:00 --> Config Class Initialized
DEBUG - 2011-04-18 08:31:00 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:31:00 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:31:00 --> URI Class Initialized
DEBUG - 2011-04-18 08:31:00 --> Router Class Initialized
ERROR - 2011-04-18 08:31:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 08:31:11 --> Config Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:31:11 --> URI Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Router Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Output Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Input Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:31:11 --> Language Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Loader Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Controller Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Model Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Model Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Model Class Initialized
DEBUG - 2011-04-18 08:31:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:31:11 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:31:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 08:31:12 --> Helper loaded: url_helper
DEBUG - 2011-04-18 08:31:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 08:31:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 08:31:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 08:31:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 08:31:12 --> Final output sent to browser
DEBUG - 2011-04-18 08:31:12 --> Total execution time: 1.0981
DEBUG - 2011-04-18 08:37:58 --> Config Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:37:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:37:58 --> URI Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Router Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Output Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Input Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:37:58 --> Language Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Loader Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Controller Class Initialized
ERROR - 2011-04-18 08:37:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 08:37:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 08:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 08:37:58 --> Model Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Model Class Initialized
DEBUG - 2011-04-18 08:37:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:37:58 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 08:37:58 --> Helper loaded: url_helper
DEBUG - 2011-04-18 08:37:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 08:37:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 08:37:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 08:37:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 08:37:58 --> Final output sent to browser
DEBUG - 2011-04-18 08:37:58 --> Total execution time: 0.1899
DEBUG - 2011-04-18 08:38:00 --> Config Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:38:00 --> URI Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Router Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Output Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Input Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:38:00 --> Language Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Loader Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Controller Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Model Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Model Class Initialized
DEBUG - 2011-04-18 08:38:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:38:00 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:38:01 --> Final output sent to browser
DEBUG - 2011-04-18 08:38:01 --> Total execution time: 0.9572
DEBUG - 2011-04-18 08:38:03 --> Config Class Initialized
DEBUG - 2011-04-18 08:38:03 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:38:03 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:38:03 --> URI Class Initialized
DEBUG - 2011-04-18 08:38:03 --> Router Class Initialized
ERROR - 2011-04-18 08:38:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 08:38:04 --> Config Class Initialized
DEBUG - 2011-04-18 08:38:04 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:38:04 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:38:04 --> URI Class Initialized
DEBUG - 2011-04-18 08:38:04 --> Router Class Initialized
ERROR - 2011-04-18 08:38:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 08:38:36 --> Config Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:38:36 --> URI Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Router Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Output Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Input Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:38:36 --> Language Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Loader Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Controller Class Initialized
ERROR - 2011-04-18 08:38:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 08:38:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 08:38:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 08:38:36 --> Model Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Model Class Initialized
DEBUG - 2011-04-18 08:38:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:38:36 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:38:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 08:38:36 --> Helper loaded: url_helper
DEBUG - 2011-04-18 08:38:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 08:38:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 08:38:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 08:38:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 08:38:36 --> Final output sent to browser
DEBUG - 2011-04-18 08:38:36 --> Total execution time: 0.0729
DEBUG - 2011-04-18 08:38:37 --> Config Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:38:37 --> URI Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Router Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Output Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Input Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:38:37 --> Language Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Loader Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Controller Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Model Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Model Class Initialized
DEBUG - 2011-04-18 08:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:38:37 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:38:38 --> Final output sent to browser
DEBUG - 2011-04-18 08:38:38 --> Total execution time: 0.9867
DEBUG - 2011-04-18 08:39:03 --> Config Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:39:03 --> URI Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Router Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Output Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Input Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:39:03 --> Language Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Loader Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Controller Class Initialized
ERROR - 2011-04-18 08:39:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 08:39:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 08:39:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 08:39:03 --> Model Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Model Class Initialized
DEBUG - 2011-04-18 08:39:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:39:03 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:39:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 08:39:03 --> Helper loaded: url_helper
DEBUG - 2011-04-18 08:39:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 08:39:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 08:39:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 08:39:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 08:39:03 --> Final output sent to browser
DEBUG - 2011-04-18 08:39:03 --> Total execution time: 0.0331
DEBUG - 2011-04-18 08:39:04 --> Config Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:39:04 --> URI Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Router Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Output Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Input Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:39:04 --> Language Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Loader Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Controller Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Model Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Model Class Initialized
DEBUG - 2011-04-18 08:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:39:04 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:39:05 --> Final output sent to browser
DEBUG - 2011-04-18 08:39:05 --> Total execution time: 0.7356
DEBUG - 2011-04-18 08:39:28 --> Config Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:39:28 --> URI Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Router Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Output Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Input Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:39:28 --> Language Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Loader Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Controller Class Initialized
ERROR - 2011-04-18 08:39:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 08:39:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 08:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 08:39:28 --> Model Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Model Class Initialized
DEBUG - 2011-04-18 08:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:39:28 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 08:39:28 --> Helper loaded: url_helper
DEBUG - 2011-04-18 08:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 08:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 08:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 08:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 08:39:28 --> Final output sent to browser
DEBUG - 2011-04-18 08:39:28 --> Total execution time: 0.1314
DEBUG - 2011-04-18 08:39:29 --> Config Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Hooks Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Utf8 Class Initialized
DEBUG - 2011-04-18 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 08:39:29 --> URI Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Router Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Output Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Input Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 08:39:29 --> Language Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Loader Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Controller Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Model Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Model Class Initialized
DEBUG - 2011-04-18 08:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 08:39:29 --> Database Driver Class Initialized
DEBUG - 2011-04-18 08:39:30 --> Final output sent to browser
DEBUG - 2011-04-18 08:39:30 --> Total execution time: 0.8368
DEBUG - 2011-04-18 09:10:50 --> Config Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:10:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:10:50 --> URI Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Router Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Output Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Input Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:10:50 --> Language Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Loader Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Controller Class Initialized
ERROR - 2011-04-18 09:10:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 09:10:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 09:10:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 09:10:50 --> Model Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Model Class Initialized
DEBUG - 2011-04-18 09:10:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:10:50 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:10:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 09:10:50 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:10:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:10:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:10:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:10:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:10:50 --> Final output sent to browser
DEBUG - 2011-04-18 09:10:50 --> Total execution time: 0.3399
DEBUG - 2011-04-18 09:36:43 --> Config Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:36:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:36:43 --> URI Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Router Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Output Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Input Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:36:43 --> Language Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Loader Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Controller Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Model Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Model Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Model Class Initialized
DEBUG - 2011-04-18 09:36:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:36:43 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:36:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:36:44 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:36:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:36:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:36:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:36:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:36:44 --> Final output sent to browser
DEBUG - 2011-04-18 09:36:44 --> Total execution time: 0.4967
DEBUG - 2011-04-18 09:36:44 --> Config Class Initialized
DEBUG - 2011-04-18 09:36:44 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:36:44 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:36:44 --> URI Class Initialized
DEBUG - 2011-04-18 09:36:44 --> Router Class Initialized
DEBUG - 2011-04-18 09:36:44 --> Output Class Initialized
DEBUG - 2011-04-18 09:36:44 --> Input Class Initialized
DEBUG - 2011-04-18 09:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:36:44 --> Language Class Initialized
DEBUG - 2011-04-18 09:36:44 --> Loader Class Initialized
DEBUG - 2011-04-18 09:36:44 --> Controller Class Initialized
ERROR - 2011-04-18 09:36:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 09:36:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 09:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 09:36:45 --> Model Class Initialized
DEBUG - 2011-04-18 09:36:45 --> Model Class Initialized
DEBUG - 2011-04-18 09:36:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:36:45 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 09:36:45 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:36:45 --> Final output sent to browser
DEBUG - 2011-04-18 09:36:45 --> Total execution time: 0.1652
DEBUG - 2011-04-18 09:38:58 --> Config Class Initialized
DEBUG - 2011-04-18 09:38:58 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:38:58 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:38:58 --> URI Class Initialized
DEBUG - 2011-04-18 09:38:58 --> Router Class Initialized
DEBUG - 2011-04-18 09:38:58 --> No URI present. Default controller set.
DEBUG - 2011-04-18 09:38:58 --> Output Class Initialized
DEBUG - 2011-04-18 09:38:58 --> Input Class Initialized
DEBUG - 2011-04-18 09:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:38:58 --> Language Class Initialized
DEBUG - 2011-04-18 09:38:59 --> Loader Class Initialized
DEBUG - 2011-04-18 09:38:59 --> Controller Class Initialized
DEBUG - 2011-04-18 09:38:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 09:38:59 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:38:59 --> Final output sent to browser
DEBUG - 2011-04-18 09:38:59 --> Total execution time: 0.2443
DEBUG - 2011-04-18 09:39:10 --> Config Class Initialized
DEBUG - 2011-04-18 09:39:10 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:39:10 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:39:10 --> URI Class Initialized
DEBUG - 2011-04-18 09:39:10 --> Router Class Initialized
ERROR - 2011-04-18 09:39:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 09:40:05 --> Config Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:40:05 --> URI Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Router Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Output Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Input Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:40:05 --> Language Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Loader Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Controller Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:40:05 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:40:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:40:05 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:40:05 --> Final output sent to browser
DEBUG - 2011-04-18 09:40:05 --> Total execution time: 0.0985
DEBUG - 2011-04-18 09:40:26 --> Config Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:40:26 --> URI Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Router Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Output Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Input Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:40:26 --> Language Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Loader Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Controller Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:40:26 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:40:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:40:27 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:40:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:40:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:40:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:40:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:40:27 --> Final output sent to browser
DEBUG - 2011-04-18 09:40:27 --> Total execution time: 0.5576
DEBUG - 2011-04-18 09:40:32 --> Config Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:40:32 --> URI Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Router Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Output Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Input Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:40:32 --> Language Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Loader Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Controller Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:40:32 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:40:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:40:32 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:40:32 --> Final output sent to browser
DEBUG - 2011-04-18 09:40:32 --> Total execution time: 0.0953
DEBUG - 2011-04-18 09:40:37 --> Config Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:40:37 --> URI Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Router Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Output Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Input Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:40:37 --> Language Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Loader Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Controller Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:40:37 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:40:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:40:38 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:40:38 --> Final output sent to browser
DEBUG - 2011-04-18 09:40:38 --> Total execution time: 0.7013
DEBUG - 2011-04-18 09:40:41 --> Config Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:40:41 --> URI Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Router Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Output Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Input Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:40:41 --> Language Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Loader Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Controller Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:40:41 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:40:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:40:41 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:40:41 --> Final output sent to browser
DEBUG - 2011-04-18 09:40:41 --> Total execution time: 0.1299
DEBUG - 2011-04-18 09:40:42 --> Config Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:40:42 --> URI Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Router Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Output Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Input Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:40:42 --> Language Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Loader Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Controller Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Model Class Initialized
DEBUG - 2011-04-18 09:40:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:40:42 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:40:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:40:42 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:40:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:40:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:40:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:40:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:40:42 --> Final output sent to browser
DEBUG - 2011-04-18 09:40:42 --> Total execution time: 0.0834
DEBUG - 2011-04-18 09:41:07 --> Config Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:41:07 --> URI Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Router Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Output Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Input Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:41:07 --> Language Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Loader Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Controller Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Model Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Model Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Model Class Initialized
DEBUG - 2011-04-18 09:41:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:41:07 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:41:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:41:07 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:41:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:41:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:41:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:41:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:41:07 --> Final output sent to browser
DEBUG - 2011-04-18 09:41:07 --> Total execution time: 0.3260
DEBUG - 2011-04-18 09:41:10 --> Config Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Hooks Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Utf8 Class Initialized
DEBUG - 2011-04-18 09:41:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 09:41:10 --> URI Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Router Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Output Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Input Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 09:41:10 --> Language Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Loader Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Controller Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Model Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Model Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Model Class Initialized
DEBUG - 2011-04-18 09:41:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 09:41:10 --> Database Driver Class Initialized
DEBUG - 2011-04-18 09:41:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 09:41:10 --> Helper loaded: url_helper
DEBUG - 2011-04-18 09:41:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 09:41:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 09:41:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 09:41:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 09:41:10 --> Final output sent to browser
DEBUG - 2011-04-18 09:41:10 --> Total execution time: 0.0501
DEBUG - 2011-04-18 10:49:36 --> Config Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Hooks Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Utf8 Class Initialized
DEBUG - 2011-04-18 10:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 10:49:36 --> URI Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Router Class Initialized
ERROR - 2011-04-18 10:49:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-18 10:49:36 --> Config Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Hooks Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Utf8 Class Initialized
DEBUG - 2011-04-18 10:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 10:49:36 --> URI Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Router Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Output Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Input Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 10:49:36 --> Language Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Loader Class Initialized
DEBUG - 2011-04-18 10:49:36 --> Controller Class Initialized
DEBUG - 2011-04-18 10:49:37 --> Model Class Initialized
DEBUG - 2011-04-18 10:49:37 --> Model Class Initialized
DEBUG - 2011-04-18 10:49:37 --> Model Class Initialized
DEBUG - 2011-04-18 10:49:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 10:49:37 --> Database Driver Class Initialized
DEBUG - 2011-04-18 10:49:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 10:49:37 --> Helper loaded: url_helper
DEBUG - 2011-04-18 10:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 10:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 10:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 10:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 10:49:37 --> Final output sent to browser
DEBUG - 2011-04-18 10:49:37 --> Total execution time: 0.4692
DEBUG - 2011-04-18 10:50:07 --> Config Class Initialized
DEBUG - 2011-04-18 10:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-18 10:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-18 10:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 10:50:07 --> URI Class Initialized
DEBUG - 2011-04-18 10:50:07 --> Router Class Initialized
DEBUG - 2011-04-18 10:50:07 --> Output Class Initialized
DEBUG - 2011-04-18 10:50:08 --> Input Class Initialized
DEBUG - 2011-04-18 10:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 10:50:08 --> Language Class Initialized
DEBUG - 2011-04-18 10:50:08 --> Loader Class Initialized
DEBUG - 2011-04-18 10:50:08 --> Controller Class Initialized
ERROR - 2011-04-18 10:50:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 10:50:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 10:50:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 10:50:08 --> Model Class Initialized
DEBUG - 2011-04-18 10:50:08 --> Model Class Initialized
DEBUG - 2011-04-18 10:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 10:50:08 --> Database Driver Class Initialized
DEBUG - 2011-04-18 10:50:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 10:50:08 --> Helper loaded: url_helper
DEBUG - 2011-04-18 10:50:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 10:50:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 10:50:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 10:50:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 10:50:08 --> Final output sent to browser
DEBUG - 2011-04-18 10:50:08 --> Total execution time: 0.3090
DEBUG - 2011-04-18 11:17:53 --> Config Class Initialized
DEBUG - 2011-04-18 11:17:53 --> Hooks Class Initialized
DEBUG - 2011-04-18 11:17:53 --> Utf8 Class Initialized
DEBUG - 2011-04-18 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 11:17:53 --> URI Class Initialized
DEBUG - 2011-04-18 11:17:53 --> Router Class Initialized
DEBUG - 2011-04-18 11:17:53 --> No URI present. Default controller set.
DEBUG - 2011-04-18 11:17:53 --> Output Class Initialized
DEBUG - 2011-04-18 11:17:53 --> Input Class Initialized
DEBUG - 2011-04-18 11:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 11:17:53 --> Language Class Initialized
DEBUG - 2011-04-18 11:17:53 --> Loader Class Initialized
DEBUG - 2011-04-18 11:17:53 --> Controller Class Initialized
DEBUG - 2011-04-18 11:17:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 11:17:53 --> Helper loaded: url_helper
DEBUG - 2011-04-18 11:17:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 11:17:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 11:17:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 11:17:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 11:17:53 --> Final output sent to browser
DEBUG - 2011-04-18 11:17:53 --> Total execution time: 0.2805
DEBUG - 2011-04-18 11:41:53 --> Config Class Initialized
DEBUG - 2011-04-18 11:41:53 --> Hooks Class Initialized
DEBUG - 2011-04-18 11:41:53 --> Utf8 Class Initialized
DEBUG - 2011-04-18 11:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 11:41:53 --> URI Class Initialized
DEBUG - 2011-04-18 11:41:53 --> Router Class Initialized
DEBUG - 2011-04-18 11:41:53 --> No URI present. Default controller set.
DEBUG - 2011-04-18 11:41:53 --> Output Class Initialized
DEBUG - 2011-04-18 11:41:53 --> Input Class Initialized
DEBUG - 2011-04-18 11:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 11:41:53 --> Language Class Initialized
DEBUG - 2011-04-18 11:41:53 --> Loader Class Initialized
DEBUG - 2011-04-18 11:41:53 --> Controller Class Initialized
DEBUG - 2011-04-18 11:41:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 11:41:53 --> Helper loaded: url_helper
DEBUG - 2011-04-18 11:41:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 11:41:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 11:41:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 11:41:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 11:41:53 --> Final output sent to browser
DEBUG - 2011-04-18 11:41:53 --> Total execution time: 0.2865
DEBUG - 2011-04-18 12:29:23 --> Config Class Initialized
DEBUG - 2011-04-18 12:29:23 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:29:23 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:29:23 --> URI Class Initialized
DEBUG - 2011-04-18 12:29:23 --> Router Class Initialized
DEBUG - 2011-04-18 12:29:23 --> No URI present. Default controller set.
DEBUG - 2011-04-18 12:29:23 --> Output Class Initialized
DEBUG - 2011-04-18 12:29:23 --> Input Class Initialized
DEBUG - 2011-04-18 12:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:29:23 --> Language Class Initialized
DEBUG - 2011-04-18 12:29:23 --> Loader Class Initialized
DEBUG - 2011-04-18 12:29:23 --> Controller Class Initialized
DEBUG - 2011-04-18 12:29:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 12:29:24 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:29:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:29:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:29:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:29:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:29:24 --> Final output sent to browser
DEBUG - 2011-04-18 12:29:24 --> Total execution time: 0.2727
DEBUG - 2011-04-18 12:29:26 --> Config Class Initialized
DEBUG - 2011-04-18 12:29:26 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:29:26 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:29:26 --> URI Class Initialized
DEBUG - 2011-04-18 12:29:26 --> Router Class Initialized
ERROR - 2011-04-18 12:29:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 12:29:28 --> Config Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:29:28 --> URI Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Router Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Output Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Input Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:29:28 --> Language Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Loader Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Controller Class Initialized
DEBUG - 2011-04-18 12:29:28 --> Model Class Initialized
DEBUG - 2011-04-18 12:29:29 --> Model Class Initialized
DEBUG - 2011-04-18 12:29:29 --> Model Class Initialized
DEBUG - 2011-04-18 12:29:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 12:29:29 --> Database Driver Class Initialized
DEBUG - 2011-04-18 12:29:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 12:29:29 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:29:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:29:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:29:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:29:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:29:29 --> Final output sent to browser
DEBUG - 2011-04-18 12:29:29 --> Total execution time: 0.6886
DEBUG - 2011-04-18 12:29:31 --> Config Class Initialized
DEBUG - 2011-04-18 12:29:31 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:29:31 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:29:31 --> URI Class Initialized
DEBUG - 2011-04-18 12:29:31 --> Router Class Initialized
ERROR - 2011-04-18 12:29:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 12:29:51 --> Config Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:29:51 --> URI Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Router Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Output Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Input Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:29:51 --> Language Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Loader Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Controller Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Model Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Model Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Model Class Initialized
DEBUG - 2011-04-18 12:29:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 12:29:51 --> Database Driver Class Initialized
DEBUG - 2011-04-18 12:29:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 12:29:52 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:29:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:29:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:29:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:29:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:29:52 --> Final output sent to browser
DEBUG - 2011-04-18 12:29:52 --> Total execution time: 0.3156
DEBUG - 2011-04-18 12:29:54 --> Config Class Initialized
DEBUG - 2011-04-18 12:29:54 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:29:54 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:29:54 --> URI Class Initialized
DEBUG - 2011-04-18 12:29:54 --> Router Class Initialized
ERROR - 2011-04-18 12:29:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 12:30:03 --> Config Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:30:03 --> URI Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Router Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Output Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Input Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:30:03 --> Language Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Loader Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Controller Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 12:30:03 --> Database Driver Class Initialized
DEBUG - 2011-04-18 12:30:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 12:30:03 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:30:03 --> Final output sent to browser
DEBUG - 2011-04-18 12:30:03 --> Total execution time: 0.2386
DEBUG - 2011-04-18 12:30:48 --> Config Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:30:48 --> URI Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Router Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Output Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Input Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:30:48 --> Language Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Loader Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Controller Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 12:30:48 --> Database Driver Class Initialized
DEBUG - 2011-04-18 12:30:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 12:30:49 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:30:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:30:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:30:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:30:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:30:49 --> Final output sent to browser
DEBUG - 2011-04-18 12:30:49 --> Total execution time: 0.1981
DEBUG - 2011-04-18 12:30:50 --> Config Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:30:50 --> URI Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Router Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Output Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Input Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:30:50 --> Language Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Loader Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Controller Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-18 12:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 12:30:50 --> Database Driver Class Initialized
DEBUG - 2011-04-18 12:30:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 12:30:50 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:30:50 --> Final output sent to browser
DEBUG - 2011-04-18 12:30:50 --> Total execution time: 0.0555
DEBUG - 2011-04-18 12:30:51 --> Config Class Initialized
DEBUG - 2011-04-18 12:30:51 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:30:51 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:30:51 --> URI Class Initialized
DEBUG - 2011-04-18 12:30:51 --> Router Class Initialized
ERROR - 2011-04-18 12:30:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 12:32:27 --> Config Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:32:27 --> URI Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Router Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Output Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Input Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:32:27 --> Language Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Loader Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Controller Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 12:32:27 --> Database Driver Class Initialized
DEBUG - 2011-04-18 12:32:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 12:32:28 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:32:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:32:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:32:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:32:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:32:28 --> Final output sent to browser
DEBUG - 2011-04-18 12:32:28 --> Total execution time: 0.3953
DEBUG - 2011-04-18 12:32:30 --> Config Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Config Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:32:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:32:30 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:32:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:32:30 --> URI Class Initialized
DEBUG - 2011-04-18 12:32:30 --> URI Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Router Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Router Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Output Class Initialized
ERROR - 2011-04-18 12:32:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 12:32:30 --> Input Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:32:30 --> Language Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Loader Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Controller Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 12:32:30 --> Database Driver Class Initialized
DEBUG - 2011-04-18 12:32:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 12:32:30 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:32:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:32:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:32:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:32:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:32:30 --> Final output sent to browser
DEBUG - 2011-04-18 12:32:30 --> Total execution time: 0.2096
DEBUG - 2011-04-18 12:32:41 --> Config Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:32:41 --> URI Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Router Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Output Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Input Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 12:32:41 --> Language Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Loader Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Controller Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Model Class Initialized
DEBUG - 2011-04-18 12:32:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 12:32:41 --> Database Driver Class Initialized
DEBUG - 2011-04-18 12:32:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 12:32:41 --> Helper loaded: url_helper
DEBUG - 2011-04-18 12:32:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 12:32:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 12:32:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 12:32:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 12:32:41 --> Final output sent to browser
DEBUG - 2011-04-18 12:32:41 --> Total execution time: 0.2097
DEBUG - 2011-04-18 12:32:44 --> Config Class Initialized
DEBUG - 2011-04-18 12:32:44 --> Hooks Class Initialized
DEBUG - 2011-04-18 12:32:44 --> Utf8 Class Initialized
DEBUG - 2011-04-18 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 12:32:44 --> URI Class Initialized
DEBUG - 2011-04-18 12:32:44 --> Router Class Initialized
ERROR - 2011-04-18 12:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 13:06:38 --> Config Class Initialized
DEBUG - 2011-04-18 13:06:38 --> Hooks Class Initialized
DEBUG - 2011-04-18 13:06:38 --> Utf8 Class Initialized
DEBUG - 2011-04-18 13:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 13:06:38 --> URI Class Initialized
DEBUG - 2011-04-18 13:06:38 --> Router Class Initialized
DEBUG - 2011-04-18 13:06:38 --> No URI present. Default controller set.
DEBUG - 2011-04-18 13:06:38 --> Output Class Initialized
DEBUG - 2011-04-18 13:06:38 --> Input Class Initialized
DEBUG - 2011-04-18 13:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 13:06:38 --> Language Class Initialized
DEBUG - 2011-04-18 13:06:38 --> Loader Class Initialized
DEBUG - 2011-04-18 13:06:38 --> Controller Class Initialized
DEBUG - 2011-04-18 13:06:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 13:06:38 --> Helper loaded: url_helper
DEBUG - 2011-04-18 13:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 13:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 13:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 13:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 13:06:38 --> Final output sent to browser
DEBUG - 2011-04-18 13:06:38 --> Total execution time: 0.3554
DEBUG - 2011-04-18 13:06:39 --> Config Class Initialized
DEBUG - 2011-04-18 13:06:39 --> Hooks Class Initialized
DEBUG - 2011-04-18 13:06:39 --> Utf8 Class Initialized
DEBUG - 2011-04-18 13:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 13:06:39 --> URI Class Initialized
DEBUG - 2011-04-18 13:06:39 --> Router Class Initialized
ERROR - 2011-04-18 13:06:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 13:15:46 --> Config Class Initialized
DEBUG - 2011-04-18 13:15:46 --> Hooks Class Initialized
DEBUG - 2011-04-18 13:15:46 --> Utf8 Class Initialized
DEBUG - 2011-04-18 13:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 13:15:46 --> URI Class Initialized
DEBUG - 2011-04-18 13:15:46 --> Router Class Initialized
DEBUG - 2011-04-18 13:15:46 --> Output Class Initialized
DEBUG - 2011-04-18 13:15:47 --> Input Class Initialized
DEBUG - 2011-04-18 13:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 13:15:47 --> Language Class Initialized
DEBUG - 2011-04-18 13:15:47 --> Loader Class Initialized
DEBUG - 2011-04-18 13:15:47 --> Controller Class Initialized
ERROR - 2011-04-18 13:15:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 13:15:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 13:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 13:15:47 --> Model Class Initialized
DEBUG - 2011-04-18 13:15:47 --> Model Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 13:15:48 --> Database Driver Class Initialized
DEBUG - 2011-04-18 13:15:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 13:15:48 --> Helper loaded: url_helper
DEBUG - 2011-04-18 13:15:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 13:15:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 13:15:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 13:15:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 13:15:48 --> Final output sent to browser
DEBUG - 2011-04-18 13:15:48 --> Total execution time: 1.4350
DEBUG - 2011-04-18 13:15:48 --> Config Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 13:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 13:15:48 --> URI Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Router Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Output Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Input Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 13:15:48 --> Language Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Loader Class Initialized
DEBUG - 2011-04-18 13:15:48 --> Controller Class Initialized
DEBUG - 2011-04-18 13:15:49 --> Model Class Initialized
DEBUG - 2011-04-18 13:15:49 --> Model Class Initialized
DEBUG - 2011-04-18 13:15:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 13:15:49 --> Database Driver Class Initialized
DEBUG - 2011-04-18 13:15:49 --> Final output sent to browser
DEBUG - 2011-04-18 13:15:49 --> Total execution time: 0.9467
DEBUG - 2011-04-18 13:15:50 --> Config Class Initialized
DEBUG - 2011-04-18 13:15:50 --> Hooks Class Initialized
DEBUG - 2011-04-18 13:15:50 --> Utf8 Class Initialized
DEBUG - 2011-04-18 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 13:15:50 --> URI Class Initialized
DEBUG - 2011-04-18 13:15:50 --> Router Class Initialized
ERROR - 2011-04-18 13:15:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 14:42:20 --> Config Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Hooks Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Utf8 Class Initialized
DEBUG - 2011-04-18 14:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 14:42:20 --> URI Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Router Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Output Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Input Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 14:42:20 --> Language Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Loader Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Controller Class Initialized
ERROR - 2011-04-18 14:42:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 14:42:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 14:42:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 14:42:20 --> Model Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Model Class Initialized
DEBUG - 2011-04-18 14:42:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 14:42:20 --> Database Driver Class Initialized
DEBUG - 2011-04-18 14:42:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 14:42:20 --> Helper loaded: url_helper
DEBUG - 2011-04-18 14:42:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 14:42:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 14:42:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 14:42:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 14:42:20 --> Final output sent to browser
DEBUG - 2011-04-18 14:42:20 --> Total execution time: 0.3899
DEBUG - 2011-04-18 14:42:23 --> Config Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Hooks Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Utf8 Class Initialized
DEBUG - 2011-04-18 14:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 14:42:23 --> URI Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Router Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Output Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Input Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 14:42:23 --> Language Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Loader Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Controller Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Model Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Model Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 14:42:23 --> Database Driver Class Initialized
DEBUG - 2011-04-18 14:42:23 --> Final output sent to browser
DEBUG - 2011-04-18 14:42:23 --> Total execution time: 0.5794
DEBUG - 2011-04-18 14:42:26 --> Config Class Initialized
DEBUG - 2011-04-18 14:42:26 --> Hooks Class Initialized
DEBUG - 2011-04-18 14:42:26 --> Utf8 Class Initialized
DEBUG - 2011-04-18 14:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 14:42:26 --> URI Class Initialized
DEBUG - 2011-04-18 14:42:26 --> Router Class Initialized
ERROR - 2011-04-18 14:42:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 14:43:16 --> Config Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Hooks Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Utf8 Class Initialized
DEBUG - 2011-04-18 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 14:43:16 --> URI Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Router Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Output Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Input Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 14:43:16 --> Language Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Loader Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Controller Class Initialized
ERROR - 2011-04-18 14:43:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 14:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 14:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 14:43:16 --> Model Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Model Class Initialized
DEBUG - 2011-04-18 14:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 14:43:16 --> Database Driver Class Initialized
DEBUG - 2011-04-18 14:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 14:43:16 --> Helper loaded: url_helper
DEBUG - 2011-04-18 14:43:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 14:43:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 14:43:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 14:43:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 14:43:16 --> Final output sent to browser
DEBUG - 2011-04-18 14:43:16 --> Total execution time: 0.0368
DEBUG - 2011-04-18 14:43:17 --> Config Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Hooks Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Utf8 Class Initialized
DEBUG - 2011-04-18 14:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 14:43:17 --> URI Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Router Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Output Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Input Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 14:43:17 --> Language Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Loader Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Controller Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Model Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Model Class Initialized
DEBUG - 2011-04-18 14:43:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 14:43:17 --> Database Driver Class Initialized
DEBUG - 2011-04-18 14:43:18 --> Final output sent to browser
DEBUG - 2011-04-18 14:43:18 --> Total execution time: 0.6834
DEBUG - 2011-04-18 15:13:11 --> Config Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:13:11 --> URI Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Router Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Output Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Input Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:13:11 --> Language Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Loader Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Controller Class Initialized
ERROR - 2011-04-18 15:13:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:13:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:13:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:13:11 --> Model Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Model Class Initialized
DEBUG - 2011-04-18 15:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:13:11 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:13:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:13:11 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:13:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:13:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:13:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:13:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:13:11 --> Final output sent to browser
DEBUG - 2011-04-18 15:13:11 --> Total execution time: 0.3575
DEBUG - 2011-04-18 15:13:12 --> Config Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:13:12 --> URI Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Router Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Output Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Input Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:13:12 --> Language Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Loader Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Controller Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Model Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Model Class Initialized
DEBUG - 2011-04-18 15:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:13:12 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:13:13 --> Final output sent to browser
DEBUG - 2011-04-18 15:13:13 --> Total execution time: 1.0569
DEBUG - 2011-04-18 15:13:14 --> Config Class Initialized
DEBUG - 2011-04-18 15:13:14 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:13:14 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:13:14 --> URI Class Initialized
DEBUG - 2011-04-18 15:13:14 --> Router Class Initialized
ERROR - 2011-04-18 15:13:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 15:14:42 --> Config Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:14:42 --> URI Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Router Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Output Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Input Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:14:42 --> Language Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Loader Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Controller Class Initialized
ERROR - 2011-04-18 15:14:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:14:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:14:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:14:42 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:14:42 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:14:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:14:42 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:14:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:14:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:14:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:14:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:14:42 --> Final output sent to browser
DEBUG - 2011-04-18 15:14:42 --> Total execution time: 0.0309
DEBUG - 2011-04-18 15:14:42 --> Config Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:14:42 --> URI Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Router Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Output Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Input Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:14:42 --> Language Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Loader Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Controller Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:14:43 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:14:43 --> Final output sent to browser
DEBUG - 2011-04-18 15:14:43 --> Total execution time: 0.9263
DEBUG - 2011-04-18 15:14:44 --> Config Class Initialized
DEBUG - 2011-04-18 15:14:44 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:14:44 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:14:44 --> URI Class Initialized
DEBUG - 2011-04-18 15:14:44 --> Router Class Initialized
ERROR - 2011-04-18 15:14:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 15:14:57 --> Config Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:14:57 --> URI Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Router Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Output Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Input Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:14:57 --> Language Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Loader Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Controller Class Initialized
ERROR - 2011-04-18 15:14:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:14:57 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:14:57 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:14:57 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:14:57 --> Final output sent to browser
DEBUG - 2011-04-18 15:14:57 --> Total execution time: 0.0301
DEBUG - 2011-04-18 15:14:57 --> Config Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:14:57 --> URI Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Router Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Output Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Input Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:14:57 --> Language Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Loader Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Controller Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:14:57 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Config Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:14:58 --> URI Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Router Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Output Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Input Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:14:58 --> Language Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Loader Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Controller Class Initialized
ERROR - 2011-04-18 15:14:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:14:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:14:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:14:58 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Model Class Initialized
DEBUG - 2011-04-18 15:14:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:14:58 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:14:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:14:58 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:14:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:14:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:14:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:14:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:14:58 --> Final output sent to browser
DEBUG - 2011-04-18 15:14:58 --> Total execution time: 0.0295
DEBUG - 2011-04-18 15:14:58 --> Final output sent to browser
DEBUG - 2011-04-18 15:14:58 --> Total execution time: 0.7022
DEBUG - 2011-04-18 15:14:59 --> Config Class Initialized
DEBUG - 2011-04-18 15:14:59 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:14:59 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:14:59 --> URI Class Initialized
DEBUG - 2011-04-18 15:14:59 --> Router Class Initialized
ERROR - 2011-04-18 15:14:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 15:16:45 --> Config Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:16:45 --> URI Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Router Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Output Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Input Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:16:45 --> Language Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Loader Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Controller Class Initialized
ERROR - 2011-04-18 15:16:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:16:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:16:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:16:45 --> Model Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Model Class Initialized
DEBUG - 2011-04-18 15:16:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:16:45 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:16:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:16:45 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:16:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:16:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:16:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:16:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:16:45 --> Final output sent to browser
DEBUG - 2011-04-18 15:16:45 --> Total execution time: 0.0430
DEBUG - 2011-04-18 15:16:46 --> Config Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:16:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:16:46 --> URI Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Router Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Output Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Input Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:16:46 --> Language Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Loader Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Controller Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Model Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Model Class Initialized
DEBUG - 2011-04-18 15:16:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:16:46 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:16:47 --> Final output sent to browser
DEBUG - 2011-04-18 15:16:47 --> Total execution time: 1.1118
DEBUG - 2011-04-18 15:16:48 --> Config Class Initialized
DEBUG - 2011-04-18 15:16:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:16:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:16:48 --> URI Class Initialized
DEBUG - 2011-04-18 15:16:48 --> Router Class Initialized
ERROR - 2011-04-18 15:16:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 15:16:49 --> Config Class Initialized
DEBUG - 2011-04-18 15:16:49 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:16:49 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:16:49 --> URI Class Initialized
DEBUG - 2011-04-18 15:16:49 --> Router Class Initialized
ERROR - 2011-04-18 15:16:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 15:16:50 --> Config Class Initialized
DEBUG - 2011-04-18 15:16:50 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:16:50 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:16:50 --> URI Class Initialized
DEBUG - 2011-04-18 15:16:50 --> Router Class Initialized
ERROR - 2011-04-18 15:16:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 15:18:18 --> Config Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:18:18 --> URI Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Router Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Output Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Input Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:18:18 --> Language Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Loader Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Controller Class Initialized
ERROR - 2011-04-18 15:18:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:18:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:18:18 --> Model Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Model Class Initialized
DEBUG - 2011-04-18 15:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:18:18 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:18:18 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:18:18 --> Final output sent to browser
DEBUG - 2011-04-18 15:18:18 --> Total execution time: 0.0284
DEBUG - 2011-04-18 15:18:19 --> Config Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:18:19 --> URI Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Router Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Output Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Input Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:18:19 --> Language Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Loader Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Controller Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Model Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Model Class Initialized
DEBUG - 2011-04-18 15:18:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:18:19 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:18:20 --> Final output sent to browser
DEBUG - 2011-04-18 15:18:20 --> Total execution time: 0.8375
DEBUG - 2011-04-18 15:18:48 --> Config Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:18:48 --> URI Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Router Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Output Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Input Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:18:48 --> Language Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Loader Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Controller Class Initialized
ERROR - 2011-04-18 15:18:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:18:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:18:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:18:48 --> Model Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Model Class Initialized
DEBUG - 2011-04-18 15:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:18:48 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:18:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:18:48 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:18:48 --> Final output sent to browser
DEBUG - 2011-04-18 15:18:48 --> Total execution time: 0.0381
DEBUG - 2011-04-18 15:18:49 --> Config Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:18:49 --> URI Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Router Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Output Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Input Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:18:49 --> Language Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Loader Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Controller Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Model Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Model Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:18:49 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:18:49 --> Final output sent to browser
DEBUG - 2011-04-18 15:18:49 --> Total execution time: 0.6533
DEBUG - 2011-04-18 15:19:11 --> Config Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:19:11 --> URI Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Router Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Output Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Input Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:19:11 --> Language Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Loader Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Controller Class Initialized
ERROR - 2011-04-18 15:19:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:19:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:19:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:19:11 --> Model Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Model Class Initialized
DEBUG - 2011-04-18 15:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:19:11 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:19:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:19:11 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:19:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:19:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:19:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:19:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:19:11 --> Final output sent to browser
DEBUG - 2011-04-18 15:19:11 --> Total execution time: 0.0389
DEBUG - 2011-04-18 15:19:12 --> Config Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:19:12 --> URI Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Router Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Output Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Input Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:19:12 --> Language Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Loader Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Controller Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Model Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Model Class Initialized
DEBUG - 2011-04-18 15:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:19:12 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:19:13 --> Final output sent to browser
DEBUG - 2011-04-18 15:19:13 --> Total execution time: 0.5736
DEBUG - 2011-04-18 15:19:53 --> Config Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:19:53 --> URI Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Router Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Output Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Input Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:19:53 --> Language Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Loader Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Controller Class Initialized
ERROR - 2011-04-18 15:19:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:19:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:19:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:19:53 --> Model Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Model Class Initialized
DEBUG - 2011-04-18 15:19:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:19:53 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:19:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:19:53 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:19:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:19:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:19:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:19:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:19:53 --> Final output sent to browser
DEBUG - 2011-04-18 15:19:53 --> Total execution time: 0.0298
DEBUG - 2011-04-18 15:19:54 --> Config Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:19:54 --> URI Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Router Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Output Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Input Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:19:54 --> Language Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Loader Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Controller Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Model Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Model Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:19:54 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:19:54 --> Final output sent to browser
DEBUG - 2011-04-18 15:19:54 --> Total execution time: 0.6041
DEBUG - 2011-04-18 15:46:19 --> Config Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:46:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:46:19 --> URI Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Router Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Output Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Input Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:46:19 --> Language Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Loader Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Controller Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:46:19 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:46:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 15:46:19 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:46:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:46:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:46:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:46:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:46:19 --> Final output sent to browser
DEBUG - 2011-04-18 15:46:19 --> Total execution time: 0.4160
DEBUG - 2011-04-18 15:46:23 --> Config Class Initialized
DEBUG - 2011-04-18 15:46:23 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:46:23 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:46:23 --> URI Class Initialized
DEBUG - 2011-04-18 15:46:23 --> Router Class Initialized
ERROR - 2011-04-18 15:46:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 15:46:57 --> Config Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:46:57 --> URI Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Router Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Output Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Input Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:46:57 --> Language Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Loader Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Controller Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:46:57 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:46:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 15:46:58 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:46:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:46:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:46:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:46:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:46:58 --> Final output sent to browser
DEBUG - 2011-04-18 15:46:58 --> Total execution time: 0.1843
DEBUG - 2011-04-18 15:46:59 --> Config Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:46:59 --> URI Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Router Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Output Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Input Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:46:59 --> Language Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Loader Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Controller Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Model Class Initialized
DEBUG - 2011-04-18 15:46:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:46:59 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:46:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 15:46:59 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:46:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:46:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:46:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:46:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:46:59 --> Final output sent to browser
DEBUG - 2011-04-18 15:46:59 --> Total execution time: 0.0414
DEBUG - 2011-04-18 15:47:25 --> Config Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:47:25 --> URI Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Router Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Output Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Input Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:47:25 --> Language Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Loader Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Controller Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:47:25 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:47:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 15:47:26 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:47:26 --> Final output sent to browser
DEBUG - 2011-04-18 15:47:26 --> Total execution time: 0.1754
DEBUG - 2011-04-18 15:47:26 --> Config Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:47:26 --> URI Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Router Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Output Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Input Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:47:26 --> Language Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Loader Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Controller Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:47:26 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:47:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 15:47:27 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:47:27 --> Final output sent to browser
DEBUG - 2011-04-18 15:47:27 --> Total execution time: 0.0493
DEBUG - 2011-04-18 15:47:53 --> Config Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:47:53 --> URI Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Router Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Output Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Input Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:47:53 --> Language Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Loader Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Controller Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:47:53 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:47:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 15:47:53 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:47:53 --> Final output sent to browser
DEBUG - 2011-04-18 15:47:53 --> Total execution time: 0.2477
DEBUG - 2011-04-18 15:47:54 --> Config Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:47:54 --> URI Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Router Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Output Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Input Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:47:54 --> Language Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Loader Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Controller Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Model Class Initialized
DEBUG - 2011-04-18 15:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:47:54 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:47:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 15:47:54 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:47:54 --> Final output sent to browser
DEBUG - 2011-04-18 15:47:54 --> Total execution time: 0.0473
DEBUG - 2011-04-18 15:53:08 --> Config Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:53:08 --> URI Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Router Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Output Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Input Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:53:08 --> Language Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Loader Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Controller Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Model Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Model Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Model Class Initialized
DEBUG - 2011-04-18 15:53:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:53:08 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:53:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 15:53:08 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:53:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:53:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:53:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:53:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:53:08 --> Final output sent to browser
DEBUG - 2011-04-18 15:53:08 --> Total execution time: 0.0499
DEBUG - 2011-04-18 15:53:09 --> Config Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:53:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:53:09 --> URI Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Router Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Output Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Input Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:53:09 --> Language Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Loader Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Controller Class Initialized
ERROR - 2011-04-18 15:53:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 15:53:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 15:53:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:53:09 --> Model Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Model Class Initialized
DEBUG - 2011-04-18 15:53:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:53:09 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:53:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 15:53:09 --> Helper loaded: url_helper
DEBUG - 2011-04-18 15:53:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 15:53:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 15:53:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 15:53:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 15:53:09 --> Final output sent to browser
DEBUG - 2011-04-18 15:53:09 --> Total execution time: 0.0707
DEBUG - 2011-04-18 15:53:10 --> Config Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:53:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:53:10 --> URI Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Router Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Output Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Input Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 15:53:10 --> Language Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Loader Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Controller Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Model Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Model Class Initialized
DEBUG - 2011-04-18 15:53:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 15:53:10 --> Database Driver Class Initialized
DEBUG - 2011-04-18 15:53:11 --> Config Class Initialized
DEBUG - 2011-04-18 15:53:11 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:53:11 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:53:11 --> URI Class Initialized
DEBUG - 2011-04-18 15:53:11 --> Router Class Initialized
ERROR - 2011-04-18 15:53:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 15:53:11 --> Final output sent to browser
DEBUG - 2011-04-18 15:53:11 --> Total execution time: 0.9150
DEBUG - 2011-04-18 15:53:12 --> Config Class Initialized
DEBUG - 2011-04-18 15:53:12 --> Hooks Class Initialized
DEBUG - 2011-04-18 15:53:12 --> Utf8 Class Initialized
DEBUG - 2011-04-18 15:53:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 15:53:12 --> URI Class Initialized
DEBUG - 2011-04-18 15:53:12 --> Router Class Initialized
ERROR - 2011-04-18 15:53:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 16:15:48 --> Config Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 16:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 16:15:48 --> URI Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Router Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Output Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Input Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 16:15:48 --> Language Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Loader Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Controller Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Model Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Model Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Model Class Initialized
DEBUG - 2011-04-18 16:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 16:15:48 --> Database Driver Class Initialized
DEBUG - 2011-04-18 16:15:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 16:15:48 --> Helper loaded: url_helper
DEBUG - 2011-04-18 16:15:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 16:15:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 16:15:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 16:15:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 16:15:48 --> Final output sent to browser
DEBUG - 2011-04-18 16:15:48 --> Total execution time: 0.2855
DEBUG - 2011-04-18 16:26:27 --> Config Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Hooks Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Utf8 Class Initialized
DEBUG - 2011-04-18 16:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 16:26:27 --> URI Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Router Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Output Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Input Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 16:26:27 --> Language Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Loader Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Controller Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Model Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Model Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Model Class Initialized
DEBUG - 2011-04-18 16:26:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 16:26:27 --> Database Driver Class Initialized
DEBUG - 2011-04-18 16:26:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 16:26:27 --> Helper loaded: url_helper
DEBUG - 2011-04-18 16:26:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 16:26:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 16:26:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 16:26:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 16:26:27 --> Final output sent to browser
DEBUG - 2011-04-18 16:26:27 --> Total execution time: 0.2057
DEBUG - 2011-04-18 16:26:29 --> Config Class Initialized
DEBUG - 2011-04-18 16:26:29 --> Hooks Class Initialized
DEBUG - 2011-04-18 16:26:29 --> Utf8 Class Initialized
DEBUG - 2011-04-18 16:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 16:26:29 --> URI Class Initialized
DEBUG - 2011-04-18 16:26:29 --> Router Class Initialized
ERROR - 2011-04-18 16:26:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 16:26:30 --> Config Class Initialized
DEBUG - 2011-04-18 16:26:30 --> Hooks Class Initialized
DEBUG - 2011-04-18 16:26:30 --> Utf8 Class Initialized
DEBUG - 2011-04-18 16:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 16:26:30 --> URI Class Initialized
DEBUG - 2011-04-18 16:26:30 --> Router Class Initialized
ERROR - 2011-04-18 16:26:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 16:28:39 --> Config Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Hooks Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Utf8 Class Initialized
DEBUG - 2011-04-18 16:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 16:28:39 --> URI Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Router Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Output Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Input Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 16:28:39 --> Language Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Loader Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Controller Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Model Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Model Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Model Class Initialized
DEBUG - 2011-04-18 16:28:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 16:28:39 --> Database Driver Class Initialized
DEBUG - 2011-04-18 16:28:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 16:28:39 --> Helper loaded: url_helper
DEBUG - 2011-04-18 16:28:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 16:28:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 16:28:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 16:28:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 16:28:39 --> Final output sent to browser
DEBUG - 2011-04-18 16:28:39 --> Total execution time: 0.0469
DEBUG - 2011-04-18 16:29:04 --> Config Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Hooks Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Utf8 Class Initialized
DEBUG - 2011-04-18 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 16:29:04 --> URI Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Router Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Output Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Input Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 16:29:04 --> Language Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Loader Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Controller Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Model Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Model Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Model Class Initialized
DEBUG - 2011-04-18 16:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 16:29:04 --> Database Driver Class Initialized
DEBUG - 2011-04-18 16:29:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 16:29:04 --> Helper loaded: url_helper
DEBUG - 2011-04-18 16:29:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 16:29:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 16:29:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 16:29:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 16:29:04 --> Final output sent to browser
DEBUG - 2011-04-18 16:29:04 --> Total execution time: 0.0563
DEBUG - 2011-04-18 16:33:58 --> Config Class Initialized
DEBUG - 2011-04-18 16:33:58 --> Hooks Class Initialized
DEBUG - 2011-04-18 16:33:58 --> Utf8 Class Initialized
DEBUG - 2011-04-18 16:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 16:33:58 --> URI Class Initialized
DEBUG - 2011-04-18 16:33:58 --> Router Class Initialized
DEBUG - 2011-04-18 16:33:58 --> No URI present. Default controller set.
DEBUG - 2011-04-18 16:33:58 --> Output Class Initialized
DEBUG - 2011-04-18 16:33:58 --> Input Class Initialized
DEBUG - 2011-04-18 16:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 16:33:58 --> Language Class Initialized
DEBUG - 2011-04-18 16:33:58 --> Loader Class Initialized
DEBUG - 2011-04-18 16:33:58 --> Controller Class Initialized
DEBUG - 2011-04-18 16:33:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 16:33:58 --> Helper loaded: url_helper
DEBUG - 2011-04-18 16:33:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 16:33:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 16:33:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 16:33:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 16:33:58 --> Final output sent to browser
DEBUG - 2011-04-18 16:33:58 --> Total execution time: 0.0795
DEBUG - 2011-04-18 17:20:03 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:03 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:03 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:03 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:03 --> Router Class Initialized
DEBUG - 2011-04-18 17:20:03 --> No URI present. Default controller set.
DEBUG - 2011-04-18 17:20:03 --> Output Class Initialized
DEBUG - 2011-04-18 17:20:03 --> Input Class Initialized
DEBUG - 2011-04-18 17:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:20:03 --> Language Class Initialized
DEBUG - 2011-04-18 17:20:04 --> Loader Class Initialized
DEBUG - 2011-04-18 17:20:04 --> Controller Class Initialized
DEBUG - 2011-04-18 17:20:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 17:20:04 --> Helper loaded: url_helper
DEBUG - 2011-04-18 17:20:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 17:20:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 17:20:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 17:20:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 17:20:04 --> Final output sent to browser
DEBUG - 2011-04-18 17:20:04 --> Total execution time: 0.2144
DEBUG - 2011-04-18 17:20:04 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:04 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:04 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:04 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:04 --> Router Class Initialized
ERROR - 2011-04-18 17:20:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 17:20:05 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:05 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:05 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:05 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:05 --> Router Class Initialized
ERROR - 2011-04-18 17:20:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 17:20:09 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:09 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Router Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Output Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Input Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:20:09 --> Language Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Loader Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Controller Class Initialized
ERROR - 2011-04-18 17:20:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 17:20:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 17:20:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:20:09 --> Model Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Model Class Initialized
DEBUG - 2011-04-18 17:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:20:09 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:20:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:20:09 --> Helper loaded: url_helper
DEBUG - 2011-04-18 17:20:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 17:20:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 17:20:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 17:20:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 17:20:09 --> Final output sent to browser
DEBUG - 2011-04-18 17:20:09 --> Total execution time: 0.5629
DEBUG - 2011-04-18 17:20:10 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:10 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Router Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Output Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Input Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:20:10 --> Language Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Loader Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Controller Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Model Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Model Class Initialized
DEBUG - 2011-04-18 17:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:20:10 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:20:11 --> Final output sent to browser
DEBUG - 2011-04-18 17:20:11 --> Total execution time: 1.0325
DEBUG - 2011-04-18 17:20:11 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:11 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:11 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:12 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:12 --> Router Class Initialized
ERROR - 2011-04-18 17:20:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 17:20:27 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:27 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Router Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Output Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Input Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:20:27 --> Language Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Loader Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Controller Class Initialized
ERROR - 2011-04-18 17:20:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 17:20:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 17:20:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:20:27 --> Model Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Model Class Initialized
DEBUG - 2011-04-18 17:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:20:27 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:20:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:20:27 --> Helper loaded: url_helper
DEBUG - 2011-04-18 17:20:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 17:20:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 17:20:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 17:20:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 17:20:27 --> Final output sent to browser
DEBUG - 2011-04-18 17:20:27 --> Total execution time: 0.0283
DEBUG - 2011-04-18 17:20:28 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:28 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Router Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Output Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Input Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:20:28 --> Language Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Loader Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Controller Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Model Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Model Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:20:28 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:20:28 --> Final output sent to browser
DEBUG - 2011-04-18 17:20:28 --> Total execution time: 0.6925
DEBUG - 2011-04-18 17:20:29 --> Config Class Initialized
DEBUG - 2011-04-18 17:20:29 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:20:29 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:20:29 --> URI Class Initialized
DEBUG - 2011-04-18 17:20:29 --> Router Class Initialized
ERROR - 2011-04-18 17:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 17:27:03 --> Config Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:27:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:27:03 --> URI Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Router Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Output Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Input Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:27:03 --> Language Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Loader Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Controller Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Model Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Model Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Model Class Initialized
DEBUG - 2011-04-18 17:27:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:27:03 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:27:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 17:27:04 --> Helper loaded: url_helper
DEBUG - 2011-04-18 17:27:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 17:27:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 17:27:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 17:27:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 17:27:04 --> Final output sent to browser
DEBUG - 2011-04-18 17:27:04 --> Total execution time: 0.6090
DEBUG - 2011-04-18 17:33:32 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:32 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Router Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Output Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Input Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:33:32 --> Language Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Loader Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Controller Class Initialized
ERROR - 2011-04-18 17:33:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 17:33:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 17:33:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:33:32 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:33:32 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:33:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:33:32 --> Helper loaded: url_helper
DEBUG - 2011-04-18 17:33:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 17:33:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 17:33:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 17:33:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 17:33:32 --> Final output sent to browser
DEBUG - 2011-04-18 17:33:32 --> Total execution time: 0.0271
DEBUG - 2011-04-18 17:33:33 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:33 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Router Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Output Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Input Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:33:33 --> Language Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Loader Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Controller Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:33:33 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:33:33 --> Final output sent to browser
DEBUG - 2011-04-18 17:33:33 --> Total execution time: 0.7517
DEBUG - 2011-04-18 17:33:35 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:35 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:35 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:35 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:35 --> Router Class Initialized
ERROR - 2011-04-18 17:33:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 17:33:46 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:46 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Router Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Output Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Input Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:33:46 --> Language Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Loader Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Controller Class Initialized
ERROR - 2011-04-18 17:33:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 17:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 17:33:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:33:46 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:33:46 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:33:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:33:46 --> Helper loaded: url_helper
DEBUG - 2011-04-18 17:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 17:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 17:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 17:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 17:33:46 --> Final output sent to browser
DEBUG - 2011-04-18 17:33:46 --> Total execution time: 0.0283
DEBUG - 2011-04-18 17:33:46 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:46 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Router Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Output Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Input Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:33:46 --> Language Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Loader Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Controller Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:33:46 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:33:47 --> Final output sent to browser
DEBUG - 2011-04-18 17:33:47 --> Total execution time: 0.5462
DEBUG - 2011-04-18 17:33:48 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:48 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:48 --> Router Class Initialized
ERROR - 2011-04-18 17:33:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 17:33:51 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:51 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Router Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Output Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Input Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:33:51 --> Language Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Loader Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Controller Class Initialized
ERROR - 2011-04-18 17:33:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 17:33:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 17:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:33:51 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:33:51 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:33:51 --> Helper loaded: url_helper
DEBUG - 2011-04-18 17:33:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 17:33:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 17:33:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 17:33:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 17:33:51 --> Final output sent to browser
DEBUG - 2011-04-18 17:33:51 --> Total execution time: 0.0359
DEBUG - 2011-04-18 17:33:51 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:51 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Router Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Output Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Input Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:33:51 --> Language Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Loader Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Controller Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Model Class Initialized
DEBUG - 2011-04-18 17:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:33:51 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:33:52 --> Final output sent to browser
DEBUG - 2011-04-18 17:33:52 --> Total execution time: 0.6319
DEBUG - 2011-04-18 17:33:53 --> Config Class Initialized
DEBUG - 2011-04-18 17:33:53 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:33:53 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:33:53 --> URI Class Initialized
DEBUG - 2011-04-18 17:33:53 --> Router Class Initialized
ERROR - 2011-04-18 17:33:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 17:34:16 --> Config Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:34:16 --> URI Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Router Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Output Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Input Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:34:16 --> Language Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Loader Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Controller Class Initialized
ERROR - 2011-04-18 17:34:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 17:34:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 17:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:34:16 --> Model Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Model Class Initialized
DEBUG - 2011-04-18 17:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:34:16 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 17:34:16 --> Helper loaded: url_helper
DEBUG - 2011-04-18 17:34:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 17:34:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 17:34:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 17:34:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 17:34:16 --> Final output sent to browser
DEBUG - 2011-04-18 17:34:16 --> Total execution time: 0.0453
DEBUG - 2011-04-18 17:34:17 --> Config Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:34:17 --> URI Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Router Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Output Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Input Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 17:34:17 --> Language Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Loader Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Controller Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Model Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Model Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 17:34:17 --> Database Driver Class Initialized
DEBUG - 2011-04-18 17:34:17 --> Final output sent to browser
DEBUG - 2011-04-18 17:34:17 --> Total execution time: 0.5510
DEBUG - 2011-04-18 17:34:19 --> Config Class Initialized
DEBUG - 2011-04-18 17:34:19 --> Hooks Class Initialized
DEBUG - 2011-04-18 17:34:19 --> Utf8 Class Initialized
DEBUG - 2011-04-18 17:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 17:34:19 --> URI Class Initialized
DEBUG - 2011-04-18 17:34:19 --> Router Class Initialized
ERROR - 2011-04-18 17:34:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 18:14:56 --> Config Class Initialized
DEBUG - 2011-04-18 18:14:56 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:14:56 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:14:56 --> URI Class Initialized
DEBUG - 2011-04-18 18:14:56 --> Router Class Initialized
DEBUG - 2011-04-18 18:14:56 --> Output Class Initialized
DEBUG - 2011-04-18 18:14:56 --> Input Class Initialized
DEBUG - 2011-04-18 18:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:14:56 --> Language Class Initialized
DEBUG - 2011-04-18 18:14:56 --> Loader Class Initialized
DEBUG - 2011-04-18 18:14:56 --> Controller Class Initialized
ERROR - 2011-04-18 18:14:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 18:14:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 18:14:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:14:57 --> Model Class Initialized
DEBUG - 2011-04-18 18:14:57 --> Model Class Initialized
DEBUG - 2011-04-18 18:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:14:57 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:14:57 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:14:57 --> Final output sent to browser
DEBUG - 2011-04-18 18:14:57 --> Total execution time: 0.3845
DEBUG - 2011-04-18 18:14:58 --> Config Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:14:58 --> URI Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Router Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Output Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Input Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:14:58 --> Language Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Loader Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Controller Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Model Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Model Class Initialized
DEBUG - 2011-04-18 18:14:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:14:58 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:14:59 --> Final output sent to browser
DEBUG - 2011-04-18 18:14:59 --> Total execution time: 0.7696
DEBUG - 2011-04-18 18:15:01 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:01 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:01 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:01 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:01 --> Router Class Initialized
ERROR - 2011-04-18 18:15:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 18:15:02 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:02 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:02 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:02 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:02 --> Router Class Initialized
ERROR - 2011-04-18 18:15:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 18:15:03 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:03 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:03 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:03 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:03 --> Router Class Initialized
ERROR - 2011-04-18 18:15:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 18:15:08 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:08 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:08 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:08 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:08 --> Router Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Output Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Input Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:15:09 --> Language Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Loader Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Controller Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:15:09 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:15:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:15:09 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:15:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:15:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:15:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:15:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:15:09 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:09 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:09 --> Router Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:10 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Router Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Output Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Input Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:15:10 --> Language Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Loader Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Controller Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Output Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Input Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:15:10 --> Language Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Loader Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Controller Class Initialized
ERROR - 2011-04-18 18:15:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 18:15:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:15:10 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:15:10 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:15:10 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:15:10 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:15:10 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:15:10 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:15:10 --> Final output sent to browser
DEBUG - 2011-04-18 18:15:10 --> Total execution time: 0.1309
DEBUG - 2011-04-18 18:15:45 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:45 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Router Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Output Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Input Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:15:45 --> Language Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Loader Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Controller Class Initialized
ERROR - 2011-04-18 18:15:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 18:15:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 18:15:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:15:45 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:15:45 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:15:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:15:45 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:15:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:15:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:15:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:15:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:15:45 --> Final output sent to browser
DEBUG - 2011-04-18 18:15:45 --> Total execution time: 0.0520
DEBUG - 2011-04-18 18:15:45 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:45 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Router Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Output Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Input Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:15:45 --> Language Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Loader Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Controller Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:15:45 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Final output sent to browser
DEBUG - 2011-04-18 18:15:46 --> Total execution time: 0.5905
DEBUG - 2011-04-18 18:15:46 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:46 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Router Class Initialized
ERROR - 2011-04-18 18:15:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-18 18:15:46 --> Config Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:15:46 --> URI Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Router Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Output Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Input Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:15:46 --> Language Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Loader Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Controller Class Initialized
ERROR - 2011-04-18 18:15:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 18:15:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 18:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:15:46 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Model Class Initialized
DEBUG - 2011-04-18 18:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:15:46 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:15:46 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:15:46 --> Final output sent to browser
DEBUG - 2011-04-18 18:15:46 --> Total execution time: 0.0301
DEBUG - 2011-04-18 18:16:01 --> Config Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:16:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:16:01 --> URI Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Router Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Output Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Input Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:16:01 --> Language Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Loader Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Controller Class Initialized
ERROR - 2011-04-18 18:16:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 18:16:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 18:16:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:16:01 --> Model Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Model Class Initialized
DEBUG - 2011-04-18 18:16:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:16:01 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:16:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:16:01 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:16:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:16:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:16:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:16:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:16:01 --> Final output sent to browser
DEBUG - 2011-04-18 18:16:01 --> Total execution time: 0.0401
DEBUG - 2011-04-18 18:16:04 --> Config Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:16:04 --> URI Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Router Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Output Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Input Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:16:04 --> Language Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Loader Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Controller Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Model Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Model Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:16:04 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:16:04 --> Final output sent to browser
DEBUG - 2011-04-18 18:16:04 --> Total execution time: 0.7443
DEBUG - 2011-04-18 18:16:48 --> Config Class Initialized
DEBUG - 2011-04-18 18:16:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:16:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:16:48 --> URI Class Initialized
DEBUG - 2011-04-18 18:16:48 --> Router Class Initialized
DEBUG - 2011-04-18 18:16:48 --> No URI present. Default controller set.
DEBUG - 2011-04-18 18:16:48 --> Output Class Initialized
DEBUG - 2011-04-18 18:16:48 --> Input Class Initialized
DEBUG - 2011-04-18 18:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:16:48 --> Language Class Initialized
DEBUG - 2011-04-18 18:16:48 --> Loader Class Initialized
DEBUG - 2011-04-18 18:16:48 --> Controller Class Initialized
DEBUG - 2011-04-18 18:16:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-18 18:16:48 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:16:48 --> Final output sent to browser
DEBUG - 2011-04-18 18:16:48 --> Total execution time: 0.0485
DEBUG - 2011-04-18 18:17:19 --> Config Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:17:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:17:19 --> URI Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Router Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Output Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Input Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:17:19 --> Language Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Loader Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Controller Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:17:19 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:17:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:17:19 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:17:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:17:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:17:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:17:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:17:19 --> Final output sent to browser
DEBUG - 2011-04-18 18:17:19 --> Total execution time: 0.0480
DEBUG - 2011-04-18 18:17:20 --> Config Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:17:20 --> URI Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Router Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Output Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Input Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:17:20 --> Language Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Loader Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Controller Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:17:20 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:17:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:17:20 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:17:20 --> Final output sent to browser
DEBUG - 2011-04-18 18:17:20 --> Total execution time: 0.0876
DEBUG - 2011-04-18 18:17:35 --> Config Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:17:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:17:35 --> URI Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Router Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Output Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Input Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:17:35 --> Language Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Loader Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Controller Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:17:35 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:17:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:17:36 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:17:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:17:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:17:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:17:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:17:36 --> Final output sent to browser
DEBUG - 2011-04-18 18:17:36 --> Total execution time: 0.5057
DEBUG - 2011-04-18 18:17:37 --> Config Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:17:37 --> URI Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Router Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Output Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Input Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:17:37 --> Language Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Loader Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Controller Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:17:37 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:17:37 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:17:37 --> Final output sent to browser
DEBUG - 2011-04-18 18:17:37 --> Total execution time: 0.0729
DEBUG - 2011-04-18 18:17:37 --> Config Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:17:37 --> URI Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Router Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Output Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Input Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:17:37 --> Language Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Loader Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Controller Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Model Class Initialized
DEBUG - 2011-04-18 18:17:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:17:37 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:17:37 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:17:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:17:37 --> Final output sent to browser
DEBUG - 2011-04-18 18:17:37 --> Total execution time: 0.0811
DEBUG - 2011-04-18 18:18:11 --> Config Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:18:11 --> URI Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Router Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Output Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Input Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:18:11 --> Language Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Loader Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Controller Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:18:11 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:18:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:18:12 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:18:12 --> Final output sent to browser
DEBUG - 2011-04-18 18:18:12 --> Total execution time: 0.3361
DEBUG - 2011-04-18 18:18:14 --> Config Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:18:14 --> URI Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Router Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Output Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Input Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:18:14 --> Language Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Loader Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Controller Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:18:14 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:18:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:18:14 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:18:14 --> Final output sent to browser
DEBUG - 2011-04-18 18:18:14 --> Total execution time: 0.0486
DEBUG - 2011-04-18 18:18:31 --> Config Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:18:31 --> URI Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Router Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Output Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Input Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:18:31 --> Language Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Loader Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Controller Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:18:31 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:18:32 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:18:32 --> Final output sent to browser
DEBUG - 2011-04-18 18:18:32 --> Total execution time: 0.5354
DEBUG - 2011-04-18 18:18:36 --> Config Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:18:36 --> URI Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Router Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Output Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Input Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:18:36 --> Language Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Loader Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Controller Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:18:36 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:18:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:18:36 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:18:36 --> Final output sent to browser
DEBUG - 2011-04-18 18:18:36 --> Total execution time: 0.0792
DEBUG - 2011-04-18 18:18:58 --> Config Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:18:58 --> URI Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Router Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Output Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Input Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:18:58 --> Language Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Loader Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Controller Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Model Class Initialized
DEBUG - 2011-04-18 18:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:18:58 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:18:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 18:18:58 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:18:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:18:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:18:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:18:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:18:58 --> Final output sent to browser
DEBUG - 2011-04-18 18:18:58 --> Total execution time: 0.2107
DEBUG - 2011-04-18 18:41:43 --> Config Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:41:43 --> URI Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Router Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Output Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Input Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:41:43 --> Language Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Loader Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Controller Class Initialized
ERROR - 2011-04-18 18:41:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 18:41:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 18:41:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:41:43 --> Model Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Model Class Initialized
DEBUG - 2011-04-18 18:41:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:41:43 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:41:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 18:41:44 --> Helper loaded: url_helper
DEBUG - 2011-04-18 18:41:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 18:41:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 18:41:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 18:41:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 18:41:44 --> Final output sent to browser
DEBUG - 2011-04-18 18:41:44 --> Total execution time: 0.0477
DEBUG - 2011-04-18 18:42:02 --> Config Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Hooks Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Utf8 Class Initialized
DEBUG - 2011-04-18 18:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 18:42:02 --> URI Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Router Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Output Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Input Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 18:42:02 --> Language Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Loader Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Controller Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Model Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Model Class Initialized
DEBUG - 2011-04-18 18:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 18:42:02 --> Database Driver Class Initialized
DEBUG - 2011-04-18 18:42:03 --> Final output sent to browser
DEBUG - 2011-04-18 18:42:03 --> Total execution time: 0.7569
DEBUG - 2011-04-18 20:55:23 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:23 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:23 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:23 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:23 --> Router Class Initialized
DEBUG - 2011-04-18 20:55:23 --> Output Class Initialized
DEBUG - 2011-04-18 20:55:23 --> Input Class Initialized
DEBUG - 2011-04-18 20:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:55:23 --> Language Class Initialized
DEBUG - 2011-04-18 20:55:24 --> Loader Class Initialized
DEBUG - 2011-04-18 20:55:24 --> Controller Class Initialized
DEBUG - 2011-04-18 20:55:24 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:24 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:24 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:55:24 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:55:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:55:24 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:55:24 --> Final output sent to browser
DEBUG - 2011-04-18 20:55:24 --> Total execution time: 1.1481
DEBUG - 2011-04-18 20:55:27 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:27 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:27 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:27 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:27 --> Router Class Initialized
ERROR - 2011-04-18 20:55:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:55:43 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:43 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Router Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Output Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Input Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:55:43 --> Language Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Loader Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Controller Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:55:43 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:55:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:55:43 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:55:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:55:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:55:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:55:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:55:43 --> Final output sent to browser
DEBUG - 2011-04-18 20:55:43 --> Total execution time: 0.5223
DEBUG - 2011-04-18 20:55:44 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:44 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:44 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:44 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:44 --> Router Class Initialized
ERROR - 2011-04-18 20:55:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:55:46 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:46 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:46 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:46 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:46 --> Router Class Initialized
ERROR - 2011-04-18 20:55:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:55:47 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:47 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Router Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Output Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Input Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:55:47 --> Language Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Loader Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Controller Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:55:47 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:55:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:55:47 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:55:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:55:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:55:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:55:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:55:47 --> Final output sent to browser
DEBUG - 2011-04-18 20:55:47 --> Total execution time: 0.0492
DEBUG - 2011-04-18 20:55:48 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:48 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Router Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Output Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Input Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:55:48 --> Language Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Loader Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Controller Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:55:48 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:55:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:55:49 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:55:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:55:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:55:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:55:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:55:49 --> Final output sent to browser
DEBUG - 2011-04-18 20:55:49 --> Total execution time: 0.2839
DEBUG - 2011-04-18 20:55:50 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:50 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:50 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:50 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:50 --> Router Class Initialized
ERROR - 2011-04-18 20:55:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:55:55 --> Config Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:55:55 --> URI Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Router Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Output Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Input Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:55:55 --> Language Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Loader Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Controller Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Model Class Initialized
DEBUG - 2011-04-18 20:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:55:55 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:55:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:55:56 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:55:56 --> Final output sent to browser
DEBUG - 2011-04-18 20:55:56 --> Total execution time: 0.3756
DEBUG - 2011-04-18 20:56:03 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:03 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:03 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:03 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:03 --> Router Class Initialized
ERROR - 2011-04-18 20:56:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:56:06 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:06 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:06 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:06 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:06 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:06 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:06 --> Total execution time: 0.4019
DEBUG - 2011-04-18 20:56:07 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:07 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:07 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:07 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:08 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:08 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:08 --> Total execution time: 0.0529
DEBUG - 2011-04-18 20:56:08 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:08 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:08 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:08 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:08 --> Router Class Initialized
ERROR - 2011-04-18 20:56:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:56:14 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:14 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:14 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:14 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:14 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:14 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:14 --> Total execution time: 0.5530
DEBUG - 2011-04-18 20:56:16 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:16 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:16 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:16 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:16 --> Router Class Initialized
ERROR - 2011-04-18 20:56:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:56:19 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:19 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:19 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:19 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:19 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:19 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:19 --> Total execution time: 0.0851
DEBUG - 2011-04-18 20:56:31 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:31 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:31 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:31 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:31 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:31 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:31 --> Total execution time: 0.3908
DEBUG - 2011-04-18 20:56:33 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:33 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:33 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:33 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:33 --> Router Class Initialized
ERROR - 2011-04-18 20:56:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:56:36 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:36 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:36 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:36 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:36 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:36 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:36 --> Total execution time: 0.0462
DEBUG - 2011-04-18 20:56:38 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:38 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:38 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:38 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:39 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:39 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:39 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:39 --> Total execution time: 0.6129
DEBUG - 2011-04-18 20:56:42 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:42 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:42 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:42 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:42 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:42 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:42 --> Total execution time: 0.1339
DEBUG - 2011-04-18 20:56:45 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:45 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:45 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:45 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:45 --> Router Class Initialized
ERROR - 2011-04-18 20:56:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:56:54 --> Config Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:56:54 --> URI Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Router Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Output Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Input Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:56:54 --> Language Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Loader Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Controller Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Model Class Initialized
DEBUG - 2011-04-18 20:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:56:54 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:56:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:56:54 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:56:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:56:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:56:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:56:54 --> Final output sent to browser
DEBUG - 2011-04-18 20:56:54 --> Total execution time: 0.2123
DEBUG - 2011-04-18 20:57:00 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:00 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:00 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:00 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:00 --> Router Class Initialized
ERROR - 2011-04-18 20:57:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:57:02 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:02 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:02 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:02 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:03 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:03 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:03 --> Total execution time: 0.8277
DEBUG - 2011-04-18 20:57:06 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:06 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:06 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:06 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:06 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:06 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:06 --> Total execution time: 0.0726
DEBUG - 2011-04-18 20:57:13 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:13 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:13 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Router Class Initialized
ERROR - 2011-04-18 20:57:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:57:13 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:13 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:13 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:13 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:13 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:13 --> Total execution time: 0.1969
DEBUG - 2011-04-18 20:57:14 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:14 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:14 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:14 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:14 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:14 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:14 --> Total execution time: 0.0442
DEBUG - 2011-04-18 20:57:15 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:15 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:15 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:15 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:15 --> Router Class Initialized
ERROR - 2011-04-18 20:57:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:57:21 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:21 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:21 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:21 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:21 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:21 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:21 --> Total execution time: 0.2932
DEBUG - 2011-04-18 20:57:28 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:28 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:28 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:28 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:28 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:28 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:28 --> Total execution time: 0.0450
DEBUG - 2011-04-18 20:57:29 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:29 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Router Class Initialized
ERROR - 2011-04-18 20:57:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:57:29 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:29 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:29 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:29 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:29 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:29 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:29 --> Total execution time: 0.3380
DEBUG - 2011-04-18 20:57:30 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:30 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:30 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:30 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:30 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:30 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:30 --> Total execution time: 0.0512
DEBUG - 2011-04-18 20:57:31 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:31 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:31 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:31 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:31 --> Router Class Initialized
ERROR - 2011-04-18 20:57:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 20:57:42 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:42 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Router Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Output Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Input Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 20:57:42 --> Language Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Loader Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Controller Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Model Class Initialized
DEBUG - 2011-04-18 20:57:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 20:57:42 --> Database Driver Class Initialized
DEBUG - 2011-04-18 20:57:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 20:57:42 --> Helper loaded: url_helper
DEBUG - 2011-04-18 20:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 20:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 20:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 20:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 20:57:42 --> Final output sent to browser
DEBUG - 2011-04-18 20:57:42 --> Total execution time: 0.0448
DEBUG - 2011-04-18 20:57:43 --> Config Class Initialized
DEBUG - 2011-04-18 20:57:43 --> Hooks Class Initialized
DEBUG - 2011-04-18 20:57:43 --> Utf8 Class Initialized
DEBUG - 2011-04-18 20:57:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 20:57:43 --> URI Class Initialized
DEBUG - 2011-04-18 20:57:43 --> Router Class Initialized
ERROR - 2011-04-18 20:57:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:13:26 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:26 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:26 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:26 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:26 --> Router Class Initialized
ERROR - 2011-04-18 21:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:13:26 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:26 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:26 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:26 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:26 --> Router Class Initialized
ERROR - 2011-04-18 21:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:13:29 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:29 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Router Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Output Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Input Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:13:29 --> Language Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Loader Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Controller Class Initialized
ERROR - 2011-04-18 21:13:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:13:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:13:29 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:13:29 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:13:29 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:13:29 --> Final output sent to browser
DEBUG - 2011-04-18 21:13:29 --> Total execution time: 0.1188
DEBUG - 2011-04-18 21:13:30 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:30 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Router Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Output Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Input Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:13:30 --> Language Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Loader Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Controller Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:13:30 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:13:31 --> Final output sent to browser
DEBUG - 2011-04-18 21:13:31 --> Total execution time: 0.6990
DEBUG - 2011-04-18 21:13:32 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:32 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:32 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:32 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:32 --> Router Class Initialized
ERROR - 2011-04-18 21:13:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:13:41 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:41 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Router Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Output Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Input Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:13:41 --> Language Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Loader Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Controller Class Initialized
ERROR - 2011-04-18 21:13:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:13:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:13:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:13:41 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:13:41 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:13:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:13:41 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:13:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:13:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:13:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:13:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:13:41 --> Final output sent to browser
DEBUG - 2011-04-18 21:13:41 --> Total execution time: 0.0331
DEBUG - 2011-04-18 21:13:42 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:42 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Router Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Output Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Input Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:13:42 --> Language Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Loader Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Controller Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:13:42 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:13:42 --> Final output sent to browser
DEBUG - 2011-04-18 21:13:42 --> Total execution time: 0.6181
DEBUG - 2011-04-18 21:13:54 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:54 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Router Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Output Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Input Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:13:54 --> Language Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Loader Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Controller Class Initialized
ERROR - 2011-04-18 21:13:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:13:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:13:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:13:54 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:13:54 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:13:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:13:54 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:13:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:13:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:13:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:13:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:13:54 --> Final output sent to browser
DEBUG - 2011-04-18 21:13:54 --> Total execution time: 0.0294
DEBUG - 2011-04-18 21:13:55 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:55 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Router Class Initialized
ERROR - 2011-04-18 21:13:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:13:55 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:55 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Router Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Output Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Input Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:13:55 --> Language Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Loader Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Controller Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Model Class Initialized
DEBUG - 2011-04-18 21:13:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:13:55 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:13:56 --> Final output sent to browser
DEBUG - 2011-04-18 21:13:56 --> Total execution time: 0.7038
DEBUG - 2011-04-18 21:13:57 --> Config Class Initialized
DEBUG - 2011-04-18 21:13:57 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:13:57 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:13:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:13:57 --> URI Class Initialized
DEBUG - 2011-04-18 21:13:57 --> Router Class Initialized
ERROR - 2011-04-18 21:13:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:14:00 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:00 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:00 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Controller Class Initialized
ERROR - 2011-04-18 21:14:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:14:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:14:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:00 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:00 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:00 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:14:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:14:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:14:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:14:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:14:00 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:00 --> Total execution time: 0.0317
DEBUG - 2011-04-18 21:14:01 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:01 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:01 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Controller Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:01 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:02 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:02 --> Total execution time: 0.5817
DEBUG - 2011-04-18 21:14:04 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:04 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:04 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:04 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:04 --> Router Class Initialized
ERROR - 2011-04-18 21:14:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:14:07 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:07 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:07 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Controller Class Initialized
ERROR - 2011-04-18 21:14:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:14:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:14:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:07 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:07 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:07 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:14:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:14:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:14:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:14:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:14:07 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:07 --> Total execution time: 0.0304
DEBUG - 2011-04-18 21:14:08 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:08 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:08 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Controller Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:08 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:08 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:08 --> Total execution time: 0.5054
DEBUG - 2011-04-18 21:14:09 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:09 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:09 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:09 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:09 --> Router Class Initialized
ERROR - 2011-04-18 21:14:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:14:21 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:21 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:21 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Controller Class Initialized
ERROR - 2011-04-18 21:14:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:14:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:14:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:21 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:21 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:21 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:14:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:14:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:14:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:14:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:14:21 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:21 --> Total execution time: 0.0292
DEBUG - 2011-04-18 21:14:22 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:22 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:22 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Controller Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:22 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:22 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:22 --> Total execution time: 0.5511
DEBUG - 2011-04-18 21:14:23 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:23 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:23 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:23 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:23 --> Router Class Initialized
ERROR - 2011-04-18 21:14:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:14:36 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:36 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:36 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Controller Class Initialized
ERROR - 2011-04-18 21:14:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:14:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:14:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:36 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:36 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:36 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:14:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:14:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:14:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:14:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:14:36 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:36 --> Total execution time: 0.0294
DEBUG - 2011-04-18 21:14:37 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:37 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:37 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Controller Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:37 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:37 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:37 --> Total execution time: 0.5065
DEBUG - 2011-04-18 21:14:38 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:38 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:38 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:38 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:38 --> Router Class Initialized
ERROR - 2011-04-18 21:14:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:14:48 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:48 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:48 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Controller Class Initialized
ERROR - 2011-04-18 21:14:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:14:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:14:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:48 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:48 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:48 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:14:48 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:48 --> Total execution time: 0.0336
DEBUG - 2011-04-18 21:14:49 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:49 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:49 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Controller Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:49 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:49 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:49 --> Total execution time: 0.7637
DEBUG - 2011-04-18 21:14:50 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:50 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:50 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:50 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:50 --> Router Class Initialized
ERROR - 2011-04-18 21:14:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:14:59 --> Config Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:14:59 --> URI Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Router Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Output Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Input Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:14:59 --> Language Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Loader Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Controller Class Initialized
ERROR - 2011-04-18 21:14:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:14:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:59 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Model Class Initialized
DEBUG - 2011-04-18 21:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:14:59 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:14:59 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:14:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:14:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:14:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:14:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:14:59 --> Final output sent to browser
DEBUG - 2011-04-18 21:14:59 --> Total execution time: 0.0354
DEBUG - 2011-04-18 21:15:18 --> Config Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:15:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:15:18 --> URI Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Router Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Output Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Input Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:15:18 --> Language Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Loader Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Controller Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Model Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Model Class Initialized
DEBUG - 2011-04-18 21:15:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:15:18 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Config Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:15:20 --> URI Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Router Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Output Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Input Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:15:20 --> Language Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Loader Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Controller Class Initialized
ERROR - 2011-04-18 21:15:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-18 21:15:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-18 21:15:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:15:20 --> Model Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Model Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:15:20 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:15:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-18 21:15:20 --> Helper loaded: url_helper
DEBUG - 2011-04-18 21:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 21:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 21:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 21:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 21:15:20 --> Final output sent to browser
DEBUG - 2011-04-18 21:15:20 --> Total execution time: 0.0281
DEBUG - 2011-04-18 21:15:20 --> Config Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:15:20 --> URI Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Router Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Output Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Input Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 21:15:20 --> Language Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Loader Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Controller Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Model Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Model Class Initialized
DEBUG - 2011-04-18 21:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 21:15:20 --> Database Driver Class Initialized
DEBUG - 2011-04-18 21:15:21 --> Final output sent to browser
DEBUG - 2011-04-18 21:15:21 --> Total execution time: 0.5417
DEBUG - 2011-04-18 21:15:22 --> Config Class Initialized
DEBUG - 2011-04-18 21:15:22 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:15:22 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:15:22 --> URI Class Initialized
DEBUG - 2011-04-18 21:15:22 --> Router Class Initialized
ERROR - 2011-04-18 21:15:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-18 21:42:50 --> Config Class Initialized
DEBUG - 2011-04-18 21:42:50 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:42:50 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:42:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:42:50 --> URI Class Initialized
DEBUG - 2011-04-18 21:42:50 --> Router Class Initialized
ERROR - 2011-04-18 21:42:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-18 21:42:51 --> Config Class Initialized
DEBUG - 2011-04-18 21:42:51 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:42:51 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:42:51 --> URI Class Initialized
DEBUG - 2011-04-18 21:42:51 --> Router Class Initialized
ERROR - 2011-04-18 21:42:51 --> 404 Page Not Found --> sitemap.xml
DEBUG - 2011-04-18 21:42:51 --> Config Class Initialized
DEBUG - 2011-04-18 21:42:51 --> Hooks Class Initialized
DEBUG - 2011-04-18 21:42:51 --> Utf8 Class Initialized
DEBUG - 2011-04-18 21:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 21:42:51 --> URI Class Initialized
DEBUG - 2011-04-18 21:42:51 --> Router Class Initialized
ERROR - 2011-04-18 21:42:51 --> 404 Page Not Found --> sitemap.xml.gz
DEBUG - 2011-04-18 22:30:29 --> Config Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Hooks Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Utf8 Class Initialized
DEBUG - 2011-04-18 22:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-18 22:30:29 --> URI Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Router Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Output Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Input Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-18 22:30:29 --> Language Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Loader Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Controller Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Model Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Model Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Model Class Initialized
DEBUG - 2011-04-18 22:30:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-18 22:30:29 --> Database Driver Class Initialized
DEBUG - 2011-04-18 22:30:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-18 22:30:29 --> Helper loaded: url_helper
DEBUG - 2011-04-18 22:30:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-18 22:30:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-18 22:30:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-18 22:30:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-18 22:30:29 --> Final output sent to browser
DEBUG - 2011-04-18 22:30:29 --> Total execution time: 0.6151

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-09 01:39:29 --> Config Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Hooks Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Utf8 Class Initialized
DEBUG - 2011-07-09 01:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 01:39:29 --> URI Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Router Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Output Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Input Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 01:39:29 --> Language Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Loader Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Controller Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Model Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Model Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Model Class Initialized
DEBUG - 2011-07-09 01:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 01:39:29 --> Database Driver Class Initialized
DEBUG - 2011-07-09 01:39:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-09 01:39:30 --> Helper loaded: url_helper
DEBUG - 2011-07-09 01:39:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 01:39:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 01:39:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 01:39:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 01:39:31 --> Final output sent to browser
DEBUG - 2011-07-09 01:39:31 --> Total execution time: 2.1222
DEBUG - 2011-07-09 01:39:34 --> Config Class Initialized
DEBUG - 2011-07-09 01:39:34 --> Hooks Class Initialized
DEBUG - 2011-07-09 01:39:34 --> Utf8 Class Initialized
DEBUG - 2011-07-09 01:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 01:39:34 --> URI Class Initialized
DEBUG - 2011-07-09 01:39:34 --> Router Class Initialized
DEBUG - 2011-07-09 01:39:34 --> Output Class Initialized
DEBUG - 2011-07-09 01:39:34 --> Input Class Initialized
DEBUG - 2011-07-09 01:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 01:39:34 --> Language Class Initialized
DEBUG - 2011-07-09 01:39:34 --> Loader Class Initialized
DEBUG - 2011-07-09 01:39:34 --> Controller Class Initialized
ERROR - 2011-07-09 01:39:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 01:39:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 01:39:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 01:39:35 --> Model Class Initialized
DEBUG - 2011-07-09 01:39:35 --> Model Class Initialized
DEBUG - 2011-07-09 01:39:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 01:39:35 --> Database Driver Class Initialized
DEBUG - 2011-07-09 01:39:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 01:39:35 --> Helper loaded: url_helper
DEBUG - 2011-07-09 01:39:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 01:39:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 01:39:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 01:39:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 01:39:35 --> Final output sent to browser
DEBUG - 2011-07-09 01:39:35 --> Total execution time: 1.1460
DEBUG - 2011-07-09 02:24:41 --> Config Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Hooks Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Utf8 Class Initialized
DEBUG - 2011-07-09 02:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 02:24:41 --> URI Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Router Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Output Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Input Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 02:24:41 --> Language Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Loader Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Controller Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Model Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Model Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Model Class Initialized
DEBUG - 2011-07-09 02:24:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 02:24:41 --> Database Driver Class Initialized
DEBUG - 2011-07-09 02:24:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-09 02:24:44 --> Helper loaded: url_helper
DEBUG - 2011-07-09 02:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 02:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 02:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 02:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 02:24:44 --> Final output sent to browser
DEBUG - 2011-07-09 02:24:44 --> Total execution time: 3.1990
DEBUG - 2011-07-09 02:25:09 --> Config Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Hooks Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Utf8 Class Initialized
DEBUG - 2011-07-09 02:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 02:25:09 --> URI Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Router Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Output Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Input Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 02:25:09 --> Language Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Loader Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Controller Class Initialized
ERROR - 2011-07-09 02:25:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 02:25:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 02:25:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 02:25:09 --> Model Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Model Class Initialized
DEBUG - 2011-07-09 02:25:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 02:25:09 --> Database Driver Class Initialized
DEBUG - 2011-07-09 02:25:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 02:25:09 --> Helper loaded: url_helper
DEBUG - 2011-07-09 02:25:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 02:25:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 02:25:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 02:25:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 02:25:09 --> Final output sent to browser
DEBUG - 2011-07-09 02:25:09 --> Total execution time: 0.2620
DEBUG - 2011-07-09 04:07:16 --> Config Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Hooks Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Utf8 Class Initialized
DEBUG - 2011-07-09 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 04:07:16 --> URI Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Router Class Initialized
ERROR - 2011-07-09 04:07:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-09 04:07:16 --> Config Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Hooks Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Utf8 Class Initialized
DEBUG - 2011-07-09 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 04:07:16 --> URI Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Router Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Output Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Input Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 04:07:16 --> Language Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Loader Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Controller Class Initialized
ERROR - 2011-07-09 04:07:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 04:07:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 04:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 04:07:16 --> Model Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Model Class Initialized
DEBUG - 2011-07-09 04:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 04:07:16 --> Database Driver Class Initialized
DEBUG - 2011-07-09 04:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 04:07:17 --> Helper loaded: url_helper
DEBUG - 2011-07-09 04:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 04:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 04:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 04:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 04:07:17 --> Final output sent to browser
DEBUG - 2011-07-09 04:07:17 --> Total execution time: 0.7833
DEBUG - 2011-07-09 06:50:31 --> Config Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Hooks Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Utf8 Class Initialized
DEBUG - 2011-07-09 06:50:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 06:50:31 --> URI Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Router Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Output Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Input Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 06:50:31 --> Language Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Loader Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Controller Class Initialized
ERROR - 2011-07-09 06:50:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 06:50:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 06:50:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 06:50:31 --> Model Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Model Class Initialized
DEBUG - 2011-07-09 06:50:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 06:50:31 --> Database Driver Class Initialized
DEBUG - 2011-07-09 06:50:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 06:50:31 --> Helper loaded: url_helper
DEBUG - 2011-07-09 06:50:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 06:50:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 06:50:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 06:50:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 06:50:32 --> Final output sent to browser
DEBUG - 2011-07-09 06:50:32 --> Total execution time: 0.6838
DEBUG - 2011-07-09 09:35:25 --> Config Class Initialized
DEBUG - 2011-07-09 09:35:25 --> Hooks Class Initialized
DEBUG - 2011-07-09 09:35:25 --> Utf8 Class Initialized
DEBUG - 2011-07-09 09:35:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 09:35:25 --> URI Class Initialized
DEBUG - 2011-07-09 09:35:25 --> Router Class Initialized
ERROR - 2011-07-09 09:35:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-09 11:04:33 --> Config Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Hooks Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Utf8 Class Initialized
DEBUG - 2011-07-09 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 11:04:34 --> URI Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Router Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Output Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Input Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 11:04:34 --> Language Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Loader Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Controller Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Model Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Model Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Model Class Initialized
DEBUG - 2011-07-09 11:04:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 11:04:34 --> Database Driver Class Initialized
DEBUG - 2011-07-09 11:04:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-09 11:04:34 --> Helper loaded: url_helper
DEBUG - 2011-07-09 11:04:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 11:04:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 11:04:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 11:04:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 11:04:34 --> Final output sent to browser
DEBUG - 2011-07-09 11:04:34 --> Total execution time: 0.9146
DEBUG - 2011-07-09 11:04:37 --> Config Class Initialized
DEBUG - 2011-07-09 11:04:37 --> Hooks Class Initialized
DEBUG - 2011-07-09 11:04:37 --> Utf8 Class Initialized
DEBUG - 2011-07-09 11:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 11:04:37 --> URI Class Initialized
DEBUG - 2011-07-09 11:04:37 --> Router Class Initialized
ERROR - 2011-07-09 11:04:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-09 11:04:53 --> Config Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Hooks Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Utf8 Class Initialized
DEBUG - 2011-07-09 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 11:04:53 --> URI Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Router Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Output Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Input Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 11:04:53 --> Language Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Loader Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Controller Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Model Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Model Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Model Class Initialized
DEBUG - 2011-07-09 11:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 11:04:53 --> Database Driver Class Initialized
DEBUG - 2011-07-09 11:04:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-09 11:04:53 --> Helper loaded: url_helper
DEBUG - 2011-07-09 11:04:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 11:04:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 11:04:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 11:04:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 11:04:53 --> Final output sent to browser
DEBUG - 2011-07-09 11:04:53 --> Total execution time: 0.4988
DEBUG - 2011-07-09 11:05:53 --> Config Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Hooks Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Utf8 Class Initialized
DEBUG - 2011-07-09 11:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 11:05:53 --> URI Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Router Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Output Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Input Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 11:05:53 --> Language Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Loader Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Controller Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Model Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Model Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Model Class Initialized
DEBUG - 2011-07-09 11:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 11:05:53 --> Database Driver Class Initialized
DEBUG - 2011-07-09 11:05:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-09 11:05:54 --> Helper loaded: url_helper
DEBUG - 2011-07-09 11:05:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 11:05:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 11:05:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 11:05:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 11:05:54 --> Final output sent to browser
DEBUG - 2011-07-09 11:05:54 --> Total execution time: 0.0458
DEBUG - 2011-07-09 15:40:39 --> Config Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Hooks Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Utf8 Class Initialized
DEBUG - 2011-07-09 15:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 15:40:39 --> URI Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Router Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Output Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Input Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 15:40:39 --> Language Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Loader Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Controller Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Model Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Model Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Model Class Initialized
DEBUG - 2011-07-09 15:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 15:40:39 --> Database Driver Class Initialized
DEBUG - 2011-07-09 15:40:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-09 15:40:40 --> Helper loaded: url_helper
DEBUG - 2011-07-09 15:40:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 15:40:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 15:40:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 15:40:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 15:40:40 --> Final output sent to browser
DEBUG - 2011-07-09 15:40:40 --> Total execution time: 0.5235
DEBUG - 2011-07-09 17:43:33 --> Config Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Hooks Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Utf8 Class Initialized
DEBUG - 2011-07-09 17:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 17:43:33 --> URI Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Router Class Initialized
ERROR - 2011-07-09 17:43:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-09 17:43:33 --> Config Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Hooks Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Utf8 Class Initialized
DEBUG - 2011-07-09 17:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 17:43:33 --> URI Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Router Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Output Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Input Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 17:43:33 --> Language Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Loader Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Controller Class Initialized
ERROR - 2011-07-09 17:43:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 17:43:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 17:43:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 17:43:33 --> Model Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Model Class Initialized
DEBUG - 2011-07-09 17:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 17:43:33 --> Database Driver Class Initialized
DEBUG - 2011-07-09 17:43:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 17:43:34 --> Helper loaded: url_helper
DEBUG - 2011-07-09 17:43:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 17:43:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 17:43:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 17:43:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 17:43:34 --> Final output sent to browser
DEBUG - 2011-07-09 17:43:34 --> Total execution time: 0.2476
DEBUG - 2011-07-09 19:05:24 --> Config Class Initialized
DEBUG - 2011-07-09 19:05:24 --> Hooks Class Initialized
DEBUG - 2011-07-09 19:05:24 --> Utf8 Class Initialized
DEBUG - 2011-07-09 19:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 19:05:24 --> URI Class Initialized
DEBUG - 2011-07-09 19:05:24 --> Router Class Initialized
DEBUG - 2011-07-09 19:05:24 --> No URI present. Default controller set.
DEBUG - 2011-07-09 19:05:24 --> Output Class Initialized
DEBUG - 2011-07-09 19:05:24 --> Input Class Initialized
DEBUG - 2011-07-09 19:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 19:05:24 --> Language Class Initialized
DEBUG - 2011-07-09 19:05:25 --> Loader Class Initialized
DEBUG - 2011-07-09 19:05:25 --> Controller Class Initialized
DEBUG - 2011-07-09 19:05:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-09 19:05:25 --> Helper loaded: url_helper
DEBUG - 2011-07-09 19:05:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 19:05:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 19:05:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 19:05:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 19:05:25 --> Final output sent to browser
DEBUG - 2011-07-09 19:05:25 --> Total execution time: 0.2556
DEBUG - 2011-07-09 20:57:01 --> Config Class Initialized
DEBUG - 2011-07-09 20:57:01 --> Hooks Class Initialized
DEBUG - 2011-07-09 20:57:01 --> Utf8 Class Initialized
DEBUG - 2011-07-09 20:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 20:57:01 --> URI Class Initialized
DEBUG - 2011-07-09 20:57:01 --> Router Class Initialized
ERROR - 2011-07-09 20:57:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-09 20:57:03 --> Config Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Hooks Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Utf8 Class Initialized
DEBUG - 2011-07-09 20:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 20:57:03 --> URI Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Router Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Output Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Input Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 20:57:03 --> Language Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Loader Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Controller Class Initialized
ERROR - 2011-07-09 20:57:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 20:57:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 20:57:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 20:57:03 --> Model Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Model Class Initialized
DEBUG - 2011-07-09 20:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 20:57:03 --> Database Driver Class Initialized
DEBUG - 2011-07-09 20:57:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 20:57:03 --> Helper loaded: url_helper
DEBUG - 2011-07-09 20:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 20:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 20:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 20:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 20:57:03 --> Final output sent to browser
DEBUG - 2011-07-09 20:57:03 --> Total execution time: 0.2535
DEBUG - 2011-07-09 21:33:10 --> Config Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Hooks Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Utf8 Class Initialized
DEBUG - 2011-07-09 21:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 21:33:10 --> URI Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Router Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Output Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Input Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 21:33:10 --> Language Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Loader Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Controller Class Initialized
ERROR - 2011-07-09 21:33:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 21:33:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 21:33:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 21:33:10 --> Model Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Model Class Initialized
DEBUG - 2011-07-09 21:33:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 21:33:10 --> Database Driver Class Initialized
DEBUG - 2011-07-09 21:33:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 21:33:10 --> Helper loaded: url_helper
DEBUG - 2011-07-09 21:33:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 21:33:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 21:33:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 21:33:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 21:33:10 --> Final output sent to browser
DEBUG - 2011-07-09 21:33:10 --> Total execution time: 0.2489
DEBUG - 2011-07-09 22:15:03 --> Config Class Initialized
DEBUG - 2011-07-09 22:15:03 --> Hooks Class Initialized
DEBUG - 2011-07-09 22:15:03 --> Utf8 Class Initialized
DEBUG - 2011-07-09 22:15:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 22:15:03 --> URI Class Initialized
DEBUG - 2011-07-09 22:15:03 --> Router Class Initialized
DEBUG - 2011-07-09 22:15:03 --> No URI present. Default controller set.
DEBUG - 2011-07-09 22:15:03 --> Output Class Initialized
DEBUG - 2011-07-09 22:15:03 --> Input Class Initialized
DEBUG - 2011-07-09 22:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 22:15:03 --> Language Class Initialized
DEBUG - 2011-07-09 22:15:03 --> Loader Class Initialized
DEBUG - 2011-07-09 22:15:03 --> Controller Class Initialized
DEBUG - 2011-07-09 22:15:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-09 22:15:03 --> Helper loaded: url_helper
DEBUG - 2011-07-09 22:15:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 22:15:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 22:15:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 22:15:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 22:15:03 --> Final output sent to browser
DEBUG - 2011-07-09 22:15:03 --> Total execution time: 0.2183
DEBUG - 2011-07-09 23:11:38 --> Config Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Hooks Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Utf8 Class Initialized
DEBUG - 2011-07-09 23:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 23:11:38 --> URI Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Router Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Output Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Input Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 23:11:38 --> Language Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Loader Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Controller Class Initialized
ERROR - 2011-07-09 23:11:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 23:11:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 23:11:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 23:11:38 --> Model Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Model Class Initialized
DEBUG - 2011-07-09 23:11:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 23:11:38 --> Database Driver Class Initialized
DEBUG - 2011-07-09 23:11:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 23:11:38 --> Helper loaded: url_helper
DEBUG - 2011-07-09 23:11:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 23:11:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 23:11:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 23:11:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 23:11:38 --> Final output sent to browser
DEBUG - 2011-07-09 23:11:38 --> Total execution time: 0.3484
DEBUG - 2011-07-09 23:11:40 --> Config Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Hooks Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Utf8 Class Initialized
DEBUG - 2011-07-09 23:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 23:11:40 --> URI Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Router Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Output Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Input Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 23:11:40 --> Language Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Loader Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Controller Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Model Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Model Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 23:11:40 --> Database Driver Class Initialized
DEBUG - 2011-07-09 23:11:40 --> Final output sent to browser
DEBUG - 2011-07-09 23:11:40 --> Total execution time: 0.6478
DEBUG - 2011-07-09 23:11:42 --> Config Class Initialized
DEBUG - 2011-07-09 23:11:42 --> Hooks Class Initialized
DEBUG - 2011-07-09 23:11:42 --> Utf8 Class Initialized
DEBUG - 2011-07-09 23:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 23:11:42 --> URI Class Initialized
DEBUG - 2011-07-09 23:11:42 --> Router Class Initialized
ERROR - 2011-07-09 23:11:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-09 23:49:07 --> Config Class Initialized
DEBUG - 2011-07-09 23:49:07 --> Hooks Class Initialized
DEBUG - 2011-07-09 23:49:07 --> Utf8 Class Initialized
DEBUG - 2011-07-09 23:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 23:49:07 --> URI Class Initialized
DEBUG - 2011-07-09 23:49:07 --> Router Class Initialized
ERROR - 2011-07-09 23:49:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-09 23:49:07 --> Config Class Initialized
DEBUG - 2011-07-09 23:49:07 --> Hooks Class Initialized
DEBUG - 2011-07-09 23:49:07 --> Utf8 Class Initialized
DEBUG - 2011-07-09 23:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-09 23:49:07 --> URI Class Initialized
DEBUG - 2011-07-09 23:49:07 --> Router Class Initialized
DEBUG - 2011-07-09 23:49:07 --> Output Class Initialized
DEBUG - 2011-07-09 23:49:08 --> Input Class Initialized
DEBUG - 2011-07-09 23:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-09 23:49:08 --> Language Class Initialized
DEBUG - 2011-07-09 23:49:08 --> Loader Class Initialized
DEBUG - 2011-07-09 23:49:08 --> Controller Class Initialized
ERROR - 2011-07-09 23:49:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-09 23:49:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-09 23:49:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 23:49:08 --> Model Class Initialized
DEBUG - 2011-07-09 23:49:08 --> Model Class Initialized
DEBUG - 2011-07-09 23:49:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-09 23:49:08 --> Database Driver Class Initialized
DEBUG - 2011-07-09 23:49:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-09 23:49:08 --> Helper loaded: url_helper
DEBUG - 2011-07-09 23:49:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-09 23:49:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-09 23:49:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-09 23:49:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-09 23:49:08 --> Final output sent to browser
DEBUG - 2011-07-09 23:49:08 --> Total execution time: 0.3853

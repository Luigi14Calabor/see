<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-18 01:36:33 --> Config Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:36:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:36:33 --> URI Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Router Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Output Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Input Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:36:33 --> Language Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Loader Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Controller Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Model Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Model Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Model Class Initialized
DEBUG - 2011-08-18 01:36:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:36:33 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:36:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:36:35 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:36:35 --> Final output sent to browser
DEBUG - 2011-08-18 01:36:35 --> Total execution time: 1.6612
DEBUG - 2011-08-18 01:36:36 --> Config Class Initialized
DEBUG - 2011-08-18 01:36:36 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:36:36 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:36:36 --> URI Class Initialized
DEBUG - 2011-08-18 01:36:36 --> Router Class Initialized
ERROR - 2011-08-18 01:36:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 01:36:47 --> Config Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:36:47 --> URI Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Router Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Output Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Input Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:36:47 --> Language Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Loader Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Controller Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Model Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Model Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Model Class Initialized
DEBUG - 2011-08-18 01:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:36:47 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:36:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:36:49 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:36:49 --> Final output sent to browser
DEBUG - 2011-08-18 01:36:49 --> Total execution time: 2.0702
DEBUG - 2011-08-18 01:37:25 --> Config Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:37:25 --> URI Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Router Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Output Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Input Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:37:25 --> Language Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Loader Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Controller Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Model Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Model Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Model Class Initialized
DEBUG - 2011-08-18 01:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:37:25 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:37:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:37:26 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:37:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:37:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:37:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:37:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:37:26 --> Final output sent to browser
DEBUG - 2011-08-18 01:37:26 --> Total execution time: 0.8571
DEBUG - 2011-08-18 01:37:51 --> Config Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:37:51 --> URI Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Router Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Output Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Input Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:37:51 --> Language Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Loader Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Controller Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Model Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Model Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Model Class Initialized
DEBUG - 2011-08-18 01:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:37:51 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:37:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:37:52 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:37:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:37:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:37:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:37:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:37:52 --> Final output sent to browser
DEBUG - 2011-08-18 01:37:52 --> Total execution time: 0.8265
DEBUG - 2011-08-18 01:38:06 --> Config Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:38:06 --> URI Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Router Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Output Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Input Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:38:06 --> Language Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Loader Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Controller Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:38:06 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:38:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:38:06 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:38:06 --> Final output sent to browser
DEBUG - 2011-08-18 01:38:06 --> Total execution time: 0.6486
DEBUG - 2011-08-18 01:38:18 --> Config Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:38:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:38:18 --> URI Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Router Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Output Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Input Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:38:18 --> Language Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Loader Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Controller Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:38:18 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:38:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:38:19 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:38:19 --> Final output sent to browser
DEBUG - 2011-08-18 01:38:19 --> Total execution time: 1.4565
DEBUG - 2011-08-18 01:38:50 --> Config Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:38:50 --> URI Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Router Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Output Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Input Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:38:50 --> Language Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Loader Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Controller Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Model Class Initialized
DEBUG - 2011-08-18 01:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:38:50 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:38:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:38:51 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:38:51 --> Final output sent to browser
DEBUG - 2011-08-18 01:38:51 --> Total execution time: 1.2589
DEBUG - 2011-08-18 01:39:02 --> Config Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:39:02 --> URI Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Router Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Output Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Input Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:39:02 --> Language Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Loader Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Controller Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:39:02 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:39:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:39:04 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:39:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:39:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:39:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:39:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:39:04 --> Final output sent to browser
DEBUG - 2011-08-18 01:39:04 --> Total execution time: 2.6127
DEBUG - 2011-08-18 01:39:23 --> Config Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:39:23 --> URI Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Router Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Output Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Input Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:39:23 --> Language Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Loader Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Controller Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:39:23 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:39:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:39:27 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:39:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:39:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:39:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:39:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:39:27 --> Final output sent to browser
DEBUG - 2011-08-18 01:39:27 --> Total execution time: 4.0092
DEBUG - 2011-08-18 01:39:40 --> Config Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:39:40 --> URI Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Router Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Output Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Input Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:39:40 --> Language Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Loader Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Controller Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:39:40 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:39:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:39:40 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:39:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:39:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:39:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:39:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:39:40 --> Final output sent to browser
DEBUG - 2011-08-18 01:39:40 --> Total execution time: 0.3418
DEBUG - 2011-08-18 01:39:58 --> Config Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Hooks Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Utf8 Class Initialized
DEBUG - 2011-08-18 01:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 01:39:58 --> URI Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Router Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Output Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Input Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 01:39:58 --> Language Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Loader Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Controller Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Model Class Initialized
DEBUG - 2011-08-18 01:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 01:39:58 --> Database Driver Class Initialized
DEBUG - 2011-08-18 01:40:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 01:40:01 --> Helper loaded: url_helper
DEBUG - 2011-08-18 01:40:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 01:40:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 01:40:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 01:40:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 01:40:01 --> Final output sent to browser
DEBUG - 2011-08-18 01:40:01 --> Total execution time: 3.5337
DEBUG - 2011-08-18 02:42:33 --> Config Class Initialized
DEBUG - 2011-08-18 02:42:34 --> Hooks Class Initialized
DEBUG - 2011-08-18 02:42:34 --> Utf8 Class Initialized
DEBUG - 2011-08-18 02:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 02:42:34 --> URI Class Initialized
DEBUG - 2011-08-18 02:42:34 --> Router Class Initialized
DEBUG - 2011-08-18 02:42:34 --> Output Class Initialized
DEBUG - 2011-08-18 02:42:34 --> Input Class Initialized
DEBUG - 2011-08-18 02:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 02:42:34 --> Language Class Initialized
DEBUG - 2011-08-18 02:42:35 --> Loader Class Initialized
DEBUG - 2011-08-18 02:42:35 --> Controller Class Initialized
ERROR - 2011-08-18 02:42:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 02:42:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 02:42:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 02:42:36 --> Model Class Initialized
DEBUG - 2011-08-18 02:42:36 --> Model Class Initialized
DEBUG - 2011-08-18 02:42:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 02:42:36 --> Database Driver Class Initialized
DEBUG - 2011-08-18 02:42:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 02:42:39 --> Helper loaded: url_helper
DEBUG - 2011-08-18 02:42:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 02:42:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 02:42:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 02:42:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 02:42:39 --> Final output sent to browser
DEBUG - 2011-08-18 02:42:39 --> Total execution time: 6.1473
DEBUG - 2011-08-18 02:42:40 --> Config Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Hooks Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Utf8 Class Initialized
DEBUG - 2011-08-18 02:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 02:42:40 --> URI Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Router Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Output Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Input Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 02:42:40 --> Language Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Loader Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Controller Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Model Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Model Class Initialized
DEBUG - 2011-08-18 02:42:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 02:42:40 --> Database Driver Class Initialized
DEBUG - 2011-08-18 02:42:42 --> Final output sent to browser
DEBUG - 2011-08-18 02:42:42 --> Total execution time: 1.7407
DEBUG - 2011-08-18 02:44:17 --> Config Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Hooks Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Utf8 Class Initialized
DEBUG - 2011-08-18 02:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 02:44:17 --> URI Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Router Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Output Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Input Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 02:44:17 --> Language Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Loader Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Controller Class Initialized
ERROR - 2011-08-18 02:44:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 02:44:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 02:44:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 02:44:17 --> Model Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Model Class Initialized
DEBUG - 2011-08-18 02:44:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 02:44:17 --> Database Driver Class Initialized
DEBUG - 2011-08-18 02:44:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 02:44:17 --> Helper loaded: url_helper
DEBUG - 2011-08-18 02:44:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 02:44:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 02:44:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 02:44:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 02:44:17 --> Final output sent to browser
DEBUG - 2011-08-18 02:44:17 --> Total execution time: 0.0805
DEBUG - 2011-08-18 02:44:18 --> Config Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Hooks Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Utf8 Class Initialized
DEBUG - 2011-08-18 02:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 02:44:18 --> URI Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Router Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Output Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Input Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 02:44:18 --> Language Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Loader Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Controller Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Model Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Model Class Initialized
DEBUG - 2011-08-18 02:44:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 02:44:18 --> Database Driver Class Initialized
DEBUG - 2011-08-18 02:44:19 --> Final output sent to browser
DEBUG - 2011-08-18 02:44:19 --> Total execution time: 1.1920
DEBUG - 2011-08-18 02:44:46 --> Config Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Hooks Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Utf8 Class Initialized
DEBUG - 2011-08-18 02:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 02:44:46 --> URI Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Router Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Output Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Input Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 02:44:46 --> Language Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Loader Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Controller Class Initialized
ERROR - 2011-08-18 02:44:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 02:44:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 02:44:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 02:44:46 --> Model Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Model Class Initialized
DEBUG - 2011-08-18 02:44:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 02:44:46 --> Database Driver Class Initialized
DEBUG - 2011-08-18 02:44:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 02:44:46 --> Helper loaded: url_helper
DEBUG - 2011-08-18 02:44:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 02:44:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 02:44:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 02:44:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 02:44:46 --> Final output sent to browser
DEBUG - 2011-08-18 02:44:46 --> Total execution time: 0.0706
DEBUG - 2011-08-18 02:44:47 --> Config Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Hooks Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Utf8 Class Initialized
DEBUG - 2011-08-18 02:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 02:44:47 --> URI Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Router Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Output Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Input Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 02:44:47 --> Language Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Loader Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Controller Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Model Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Model Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 02:44:47 --> Database Driver Class Initialized
DEBUG - 2011-08-18 02:44:47 --> Final output sent to browser
DEBUG - 2011-08-18 02:44:47 --> Total execution time: 0.6225
DEBUG - 2011-08-18 03:30:22 --> Config Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Hooks Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Utf8 Class Initialized
DEBUG - 2011-08-18 03:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 03:30:22 --> URI Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Router Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Output Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Input Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 03:30:22 --> Language Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Loader Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Controller Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Model Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Model Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Model Class Initialized
DEBUG - 2011-08-18 03:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 03:30:22 --> Database Driver Class Initialized
DEBUG - 2011-08-18 03:30:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 03:30:25 --> Helper loaded: url_helper
DEBUG - 2011-08-18 03:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 03:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 03:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 03:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 03:30:25 --> Final output sent to browser
DEBUG - 2011-08-18 03:30:25 --> Total execution time: 2.9707
DEBUG - 2011-08-18 03:30:27 --> Config Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Hooks Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Utf8 Class Initialized
DEBUG - 2011-08-18 03:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 03:30:27 --> URI Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Router Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Output Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Input Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 03:30:27 --> Language Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Loader Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Controller Class Initialized
ERROR - 2011-08-18 03:30:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 03:30:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 03:30:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 03:30:27 --> Model Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Model Class Initialized
DEBUG - 2011-08-18 03:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 03:30:27 --> Database Driver Class Initialized
DEBUG - 2011-08-18 03:30:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 03:30:27 --> Helper loaded: url_helper
DEBUG - 2011-08-18 03:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 03:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 03:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 03:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 03:30:27 --> Final output sent to browser
DEBUG - 2011-08-18 03:30:27 --> Total execution time: 0.0905
DEBUG - 2011-08-18 03:31:02 --> Config Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Hooks Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Utf8 Class Initialized
DEBUG - 2011-08-18 03:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 03:31:02 --> URI Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Router Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Output Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Input Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 03:31:02 --> Language Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Loader Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Controller Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Model Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Model Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Model Class Initialized
DEBUG - 2011-08-18 03:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 03:31:02 --> Database Driver Class Initialized
DEBUG - 2011-08-18 03:31:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 03:31:02 --> Helper loaded: url_helper
DEBUG - 2011-08-18 03:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 03:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 03:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 03:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 03:31:02 --> Final output sent to browser
DEBUG - 2011-08-18 03:31:02 --> Total execution time: 0.1158
DEBUG - 2011-08-18 03:31:04 --> Config Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Hooks Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Utf8 Class Initialized
DEBUG - 2011-08-18 03:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 03:31:04 --> URI Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Router Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Output Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Input Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 03:31:04 --> Language Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Loader Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Controller Class Initialized
ERROR - 2011-08-18 03:31:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 03:31:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 03:31:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 03:31:04 --> Model Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Model Class Initialized
DEBUG - 2011-08-18 03:31:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 03:31:04 --> Database Driver Class Initialized
DEBUG - 2011-08-18 03:31:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 03:31:04 --> Helper loaded: url_helper
DEBUG - 2011-08-18 03:31:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 03:31:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 03:31:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 03:31:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 03:31:04 --> Final output sent to browser
DEBUG - 2011-08-18 03:31:04 --> Total execution time: 0.0294
DEBUG - 2011-08-18 04:22:26 --> Config Class Initialized
DEBUG - 2011-08-18 04:22:26 --> Hooks Class Initialized
DEBUG - 2011-08-18 04:22:26 --> Utf8 Class Initialized
DEBUG - 2011-08-18 04:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 04:22:26 --> URI Class Initialized
DEBUG - 2011-08-18 04:22:26 --> Router Class Initialized
DEBUG - 2011-08-18 04:22:26 --> Output Class Initialized
DEBUG - 2011-08-18 04:22:26 --> Input Class Initialized
DEBUG - 2011-08-18 04:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 04:22:27 --> Language Class Initialized
DEBUG - 2011-08-18 04:22:27 --> Loader Class Initialized
DEBUG - 2011-08-18 04:22:27 --> Controller Class Initialized
DEBUG - 2011-08-18 04:22:27 --> Model Class Initialized
DEBUG - 2011-08-18 04:22:27 --> Model Class Initialized
DEBUG - 2011-08-18 04:22:27 --> Model Class Initialized
DEBUG - 2011-08-18 04:22:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 04:22:30 --> Database Driver Class Initialized
DEBUG - 2011-08-18 04:22:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 04:22:35 --> Helper loaded: url_helper
DEBUG - 2011-08-18 04:22:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 04:22:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 04:22:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 04:22:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 04:22:35 --> Final output sent to browser
DEBUG - 2011-08-18 04:22:35 --> Total execution time: 9.5540
DEBUG - 2011-08-18 04:36:35 --> Config Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Hooks Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Utf8 Class Initialized
DEBUG - 2011-08-18 04:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 04:36:35 --> URI Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Router Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Output Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Input Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 04:36:35 --> Language Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Loader Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Controller Class Initialized
ERROR - 2011-08-18 04:36:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 04:36:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 04:36:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 04:36:35 --> Model Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Model Class Initialized
DEBUG - 2011-08-18 04:36:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 04:36:35 --> Database Driver Class Initialized
DEBUG - 2011-08-18 04:36:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 04:36:35 --> Helper loaded: url_helper
DEBUG - 2011-08-18 04:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 04:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 04:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 04:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 04:36:35 --> Final output sent to browser
DEBUG - 2011-08-18 04:36:35 --> Total execution time: 0.1035
DEBUG - 2011-08-18 05:29:13 --> Config Class Initialized
DEBUG - 2011-08-18 05:29:13 --> Hooks Class Initialized
DEBUG - 2011-08-18 05:29:13 --> Utf8 Class Initialized
DEBUG - 2011-08-18 05:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 05:29:13 --> URI Class Initialized
DEBUG - 2011-08-18 05:29:13 --> Router Class Initialized
DEBUG - 2011-08-18 05:29:13 --> No URI present. Default controller set.
DEBUG - 2011-08-18 05:29:13 --> Output Class Initialized
DEBUG - 2011-08-18 05:29:13 --> Input Class Initialized
DEBUG - 2011-08-18 05:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 05:29:13 --> Language Class Initialized
DEBUG - 2011-08-18 05:29:14 --> Loader Class Initialized
DEBUG - 2011-08-18 05:29:14 --> Controller Class Initialized
DEBUG - 2011-08-18 05:29:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-18 05:29:14 --> Helper loaded: url_helper
DEBUG - 2011-08-18 05:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 05:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 05:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 05:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 05:29:14 --> Final output sent to browser
DEBUG - 2011-08-18 05:29:14 --> Total execution time: 0.2337
DEBUG - 2011-08-18 06:03:37 --> Config Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Hooks Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Utf8 Class Initialized
DEBUG - 2011-08-18 06:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 06:03:37 --> URI Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Router Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Output Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Input Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 06:03:37 --> Language Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Loader Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Controller Class Initialized
ERROR - 2011-08-18 06:03:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 06:03:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 06:03:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 06:03:37 --> Model Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Model Class Initialized
DEBUG - 2011-08-18 06:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 06:03:37 --> Database Driver Class Initialized
DEBUG - 2011-08-18 06:03:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 06:03:37 --> Helper loaded: url_helper
DEBUG - 2011-08-18 06:03:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 06:03:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 06:03:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 06:03:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 06:03:37 --> Final output sent to browser
DEBUG - 2011-08-18 06:03:37 --> Total execution time: 0.2240
DEBUG - 2011-08-18 06:03:39 --> Config Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Hooks Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Utf8 Class Initialized
DEBUG - 2011-08-18 06:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 06:03:39 --> URI Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Router Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Output Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Input Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 06:03:39 --> Language Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Loader Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Controller Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Model Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Model Class Initialized
DEBUG - 2011-08-18 06:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 06:03:39 --> Database Driver Class Initialized
DEBUG - 2011-08-18 06:03:40 --> Final output sent to browser
DEBUG - 2011-08-18 06:03:40 --> Total execution time: 0.7163
DEBUG - 2011-08-18 06:03:44 --> Config Class Initialized
DEBUG - 2011-08-18 06:03:44 --> Hooks Class Initialized
DEBUG - 2011-08-18 06:03:44 --> Utf8 Class Initialized
DEBUG - 2011-08-18 06:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 06:03:44 --> URI Class Initialized
DEBUG - 2011-08-18 06:03:44 --> Router Class Initialized
ERROR - 2011-08-18 06:03:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 06:03:47 --> Config Class Initialized
DEBUG - 2011-08-18 06:03:47 --> Hooks Class Initialized
DEBUG - 2011-08-18 06:03:47 --> Utf8 Class Initialized
DEBUG - 2011-08-18 06:03:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 06:03:47 --> URI Class Initialized
DEBUG - 2011-08-18 06:03:47 --> Router Class Initialized
ERROR - 2011-08-18 06:03:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 06:04:17 --> Config Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Hooks Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Utf8 Class Initialized
DEBUG - 2011-08-18 06:04:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 06:04:17 --> URI Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Router Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Output Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Input Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 06:04:17 --> Language Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Loader Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Controller Class Initialized
ERROR - 2011-08-18 06:04:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 06:04:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 06:04:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 06:04:17 --> Model Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Model Class Initialized
DEBUG - 2011-08-18 06:04:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 06:04:17 --> Database Driver Class Initialized
DEBUG - 2011-08-18 06:04:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 06:04:17 --> Helper loaded: url_helper
DEBUG - 2011-08-18 06:04:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 06:04:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 06:04:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 06:04:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 06:04:17 --> Final output sent to browser
DEBUG - 2011-08-18 06:04:17 --> Total execution time: 0.0616
DEBUG - 2011-08-18 06:04:18 --> Config Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Hooks Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Utf8 Class Initialized
DEBUG - 2011-08-18 06:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 06:04:18 --> URI Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Router Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Output Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Input Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 06:04:18 --> Language Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Loader Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Controller Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Model Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Model Class Initialized
DEBUG - 2011-08-18 06:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 06:04:19 --> Database Driver Class Initialized
DEBUG - 2011-08-18 06:04:19 --> Final output sent to browser
DEBUG - 2011-08-18 06:04:19 --> Total execution time: 0.4279
DEBUG - 2011-08-18 07:29:30 --> Config Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:29:30 --> URI Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Router Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Output Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Input Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 07:29:30 --> Language Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Loader Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Controller Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Model Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Model Class Initialized
DEBUG - 2011-08-18 07:29:30 --> Model Class Initialized
DEBUG - 2011-08-18 07:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 07:29:31 --> Database Driver Class Initialized
DEBUG - 2011-08-18 07:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 07:29:31 --> Helper loaded: url_helper
DEBUG - 2011-08-18 07:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 07:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 07:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 07:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 07:29:31 --> Final output sent to browser
DEBUG - 2011-08-18 07:29:31 --> Total execution time: 0.5907
DEBUG - 2011-08-18 07:29:52 --> Config Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:29:52 --> URI Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Router Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Output Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Input Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 07:29:52 --> Language Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Loader Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Controller Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Model Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Model Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Model Class Initialized
DEBUG - 2011-08-18 07:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 07:29:52 --> Database Driver Class Initialized
DEBUG - 2011-08-18 07:29:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 07:29:53 --> Helper loaded: url_helper
DEBUG - 2011-08-18 07:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 07:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 07:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 07:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 07:29:53 --> Final output sent to browser
DEBUG - 2011-08-18 07:29:53 --> Total execution time: 0.5099
DEBUG - 2011-08-18 07:30:05 --> Config Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:30:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:30:05 --> URI Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Router Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Output Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Input Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 07:30:05 --> Language Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Loader Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Controller Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Model Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Model Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Model Class Initialized
DEBUG - 2011-08-18 07:30:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 07:30:05 --> Database Driver Class Initialized
DEBUG - 2011-08-18 07:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 07:30:05 --> Helper loaded: url_helper
DEBUG - 2011-08-18 07:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 07:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 07:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 07:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 07:30:05 --> Final output sent to browser
DEBUG - 2011-08-18 07:30:05 --> Total execution time: 0.2922
DEBUG - 2011-08-18 07:30:39 --> Config Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:30:39 --> URI Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Router Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Output Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Input Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 07:30:39 --> Language Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Loader Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Controller Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Model Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Model Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Model Class Initialized
DEBUG - 2011-08-18 07:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 07:30:39 --> Database Driver Class Initialized
DEBUG - 2011-08-18 07:30:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 07:30:40 --> Helper loaded: url_helper
DEBUG - 2011-08-18 07:30:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 07:30:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 07:30:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 07:30:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 07:30:40 --> Final output sent to browser
DEBUG - 2011-08-18 07:30:40 --> Total execution time: 0.9170
DEBUG - 2011-08-18 07:33:21 --> Config Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:33:21 --> URI Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Router Class Initialized
ERROR - 2011-08-18 07:33:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-18 07:33:21 --> Config Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:33:21 --> URI Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Router Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Output Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Input Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 07:33:21 --> Language Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Loader Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Controller Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Model Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Model Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Model Class Initialized
DEBUG - 2011-08-18 07:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 07:33:21 --> Database Driver Class Initialized
DEBUG - 2011-08-18 07:33:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 07:33:21 --> Helper loaded: url_helper
DEBUG - 2011-08-18 07:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 07:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 07:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 07:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 07:33:21 --> Final output sent to browser
DEBUG - 2011-08-18 07:33:21 --> Total execution time: 0.0742
DEBUG - 2011-08-18 07:33:46 --> Config Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:33:46 --> URI Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Router Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Output Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Input Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 07:33:46 --> Language Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Loader Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Controller Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Model Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Model Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Model Class Initialized
DEBUG - 2011-08-18 07:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 07:33:46 --> Database Driver Class Initialized
DEBUG - 2011-08-18 07:33:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 07:33:46 --> Helper loaded: url_helper
DEBUG - 2011-08-18 07:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 07:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 07:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 07:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 07:33:46 --> Final output sent to browser
DEBUG - 2011-08-18 07:33:46 --> Total execution time: 0.0889
DEBUG - 2011-08-18 07:36:52 --> Config Class Initialized
DEBUG - 2011-08-18 07:36:52 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:36:52 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:36:52 --> URI Class Initialized
DEBUG - 2011-08-18 07:36:52 --> Router Class Initialized
DEBUG - 2011-08-18 07:36:52 --> Output Class Initialized
DEBUG - 2011-08-18 07:36:52 --> Input Class Initialized
DEBUG - 2011-08-18 07:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 07:36:52 --> Language Class Initialized
DEBUG - 2011-08-18 07:36:52 --> Loader Class Initialized
DEBUG - 2011-08-18 07:36:52 --> Controller Class Initialized
ERROR - 2011-08-18 07:36:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 07:36:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 07:36:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 07:36:53 --> Model Class Initialized
DEBUG - 2011-08-18 07:36:53 --> Model Class Initialized
DEBUG - 2011-08-18 07:36:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 07:36:53 --> Database Driver Class Initialized
DEBUG - 2011-08-18 07:36:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 07:36:53 --> Helper loaded: url_helper
DEBUG - 2011-08-18 07:36:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 07:36:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 07:36:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 07:36:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 07:36:53 --> Final output sent to browser
DEBUG - 2011-08-18 07:36:53 --> Total execution time: 0.1026
DEBUG - 2011-08-18 07:36:55 --> Config Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:36:55 --> URI Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Router Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Output Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Input Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 07:36:55 --> Language Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Loader Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Controller Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Model Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Model Class Initialized
DEBUG - 2011-08-18 07:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 07:36:55 --> Database Driver Class Initialized
DEBUG - 2011-08-18 07:36:56 --> Final output sent to browser
DEBUG - 2011-08-18 07:36:56 --> Total execution time: 0.7226
DEBUG - 2011-08-18 07:37:09 --> Config Class Initialized
DEBUG - 2011-08-18 07:37:09 --> Hooks Class Initialized
DEBUG - 2011-08-18 07:37:09 --> Utf8 Class Initialized
DEBUG - 2011-08-18 07:37:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 07:37:09 --> URI Class Initialized
DEBUG - 2011-08-18 07:37:09 --> Router Class Initialized
ERROR - 2011-08-18 07:37:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 08:05:40 --> Config Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Hooks Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Utf8 Class Initialized
DEBUG - 2011-08-18 08:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 08:05:40 --> URI Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Router Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Output Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Input Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 08:05:40 --> Language Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Loader Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Controller Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Model Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Model Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Model Class Initialized
DEBUG - 2011-08-18 08:05:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 08:05:40 --> Database Driver Class Initialized
DEBUG - 2011-08-18 08:05:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 08:05:41 --> Helper loaded: url_helper
DEBUG - 2011-08-18 08:05:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 08:05:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 08:05:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 08:05:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 08:05:41 --> Final output sent to browser
DEBUG - 2011-08-18 08:05:41 --> Total execution time: 0.2548
DEBUG - 2011-08-18 08:05:43 --> Config Class Initialized
DEBUG - 2011-08-18 08:05:43 --> Hooks Class Initialized
DEBUG - 2011-08-18 08:05:43 --> Utf8 Class Initialized
DEBUG - 2011-08-18 08:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 08:05:43 --> URI Class Initialized
DEBUG - 2011-08-18 08:05:43 --> Router Class Initialized
ERROR - 2011-08-18 08:05:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 08:05:43 --> Config Class Initialized
DEBUG - 2011-08-18 08:05:43 --> Hooks Class Initialized
DEBUG - 2011-08-18 08:05:43 --> Utf8 Class Initialized
DEBUG - 2011-08-18 08:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 08:05:43 --> URI Class Initialized
DEBUG - 2011-08-18 08:05:43 --> Router Class Initialized
ERROR - 2011-08-18 08:05:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 11:29:05 --> Config Class Initialized
DEBUG - 2011-08-18 11:29:05 --> Hooks Class Initialized
DEBUG - 2011-08-18 11:29:05 --> Utf8 Class Initialized
DEBUG - 2011-08-18 11:29:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 11:29:06 --> URI Class Initialized
DEBUG - 2011-08-18 11:29:06 --> Router Class Initialized
ERROR - 2011-08-18 11:29:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-18 11:57:27 --> Config Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Hooks Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Utf8 Class Initialized
DEBUG - 2011-08-18 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 11:57:27 --> URI Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Router Class Initialized
ERROR - 2011-08-18 11:57:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-18 11:57:27 --> Config Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Hooks Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Utf8 Class Initialized
DEBUG - 2011-08-18 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 11:57:27 --> URI Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Router Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Output Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Input Class Initialized
DEBUG - 2011-08-18 11:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 11:57:27 --> Language Class Initialized
DEBUG - 2011-08-18 11:57:28 --> Loader Class Initialized
DEBUG - 2011-08-18 11:57:28 --> Controller Class Initialized
DEBUG - 2011-08-18 11:57:28 --> Model Class Initialized
DEBUG - 2011-08-18 11:57:28 --> Model Class Initialized
DEBUG - 2011-08-18 11:57:28 --> Model Class Initialized
DEBUG - 2011-08-18 11:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 11:57:29 --> Database Driver Class Initialized
DEBUG - 2011-08-18 11:57:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 11:57:31 --> Helper loaded: url_helper
DEBUG - 2011-08-18 11:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 11:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 11:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 11:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 11:57:31 --> Final output sent to browser
DEBUG - 2011-08-18 11:57:31 --> Total execution time: 3.9325
DEBUG - 2011-08-18 12:39:06 --> Config Class Initialized
DEBUG - 2011-08-18 12:39:06 --> Hooks Class Initialized
DEBUG - 2011-08-18 12:39:06 --> Utf8 Class Initialized
DEBUG - 2011-08-18 12:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 12:39:06 --> URI Class Initialized
DEBUG - 2011-08-18 12:39:06 --> Router Class Initialized
DEBUG - 2011-08-18 12:39:06 --> No URI present. Default controller set.
DEBUG - 2011-08-18 12:39:06 --> Output Class Initialized
DEBUG - 2011-08-18 12:39:06 --> Input Class Initialized
DEBUG - 2011-08-18 12:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 12:39:06 --> Language Class Initialized
DEBUG - 2011-08-18 12:39:06 --> Loader Class Initialized
DEBUG - 2011-08-18 12:39:06 --> Controller Class Initialized
DEBUG - 2011-08-18 12:39:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-18 12:39:06 --> Helper loaded: url_helper
DEBUG - 2011-08-18 12:39:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 12:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 12:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 12:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 12:39:06 --> Final output sent to browser
DEBUG - 2011-08-18 12:39:06 --> Total execution time: 0.1033
DEBUG - 2011-08-18 12:57:14 --> Config Class Initialized
DEBUG - 2011-08-18 12:57:14 --> Hooks Class Initialized
DEBUG - 2011-08-18 12:57:14 --> Utf8 Class Initialized
DEBUG - 2011-08-18 12:57:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 12:57:14 --> URI Class Initialized
DEBUG - 2011-08-18 12:57:14 --> Router Class Initialized
ERROR - 2011-08-18 12:57:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-18 15:41:52 --> Config Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Hooks Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Utf8 Class Initialized
DEBUG - 2011-08-18 15:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 15:41:52 --> URI Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Router Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Output Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Input Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 15:41:52 --> Language Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Loader Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Controller Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Model Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Model Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Model Class Initialized
DEBUG - 2011-08-18 15:41:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 15:41:52 --> Database Driver Class Initialized
DEBUG - 2011-08-18 15:41:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 15:41:53 --> Helper loaded: url_helper
DEBUG - 2011-08-18 15:41:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 15:41:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 15:41:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 15:41:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 15:41:53 --> Final output sent to browser
DEBUG - 2011-08-18 15:41:53 --> Total execution time: 0.6424
DEBUG - 2011-08-18 15:41:54 --> Config Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Hooks Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Utf8 Class Initialized
DEBUG - 2011-08-18 15:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 15:41:54 --> URI Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Router Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Output Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Input Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 15:41:54 --> Language Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Loader Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Controller Class Initialized
ERROR - 2011-08-18 15:41:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 15:41:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 15:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 15:41:54 --> Model Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Model Class Initialized
DEBUG - 2011-08-18 15:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 15:41:54 --> Database Driver Class Initialized
DEBUG - 2011-08-18 15:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 15:41:54 --> Helper loaded: url_helper
DEBUG - 2011-08-18 15:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 15:41:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 15:41:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 15:41:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 15:41:54 --> Final output sent to browser
DEBUG - 2011-08-18 15:41:54 --> Total execution time: 0.1151
DEBUG - 2011-08-18 16:01:45 --> Config Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Hooks Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Utf8 Class Initialized
DEBUG - 2011-08-18 16:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 16:01:45 --> URI Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Router Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Output Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Input Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 16:01:45 --> Language Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Loader Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Controller Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Model Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Model Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Model Class Initialized
DEBUG - 2011-08-18 16:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 16:01:45 --> Database Driver Class Initialized
DEBUG - 2011-08-18 16:01:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 16:01:45 --> Helper loaded: url_helper
DEBUG - 2011-08-18 16:01:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 16:01:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 16:01:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 16:01:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 16:01:45 --> Final output sent to browser
DEBUG - 2011-08-18 16:01:45 --> Total execution time: 0.4083
DEBUG - 2011-08-18 16:01:46 --> Config Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Hooks Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Utf8 Class Initialized
DEBUG - 2011-08-18 16:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 16:01:46 --> URI Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Router Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Output Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Input Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 16:01:46 --> Language Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Loader Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Controller Class Initialized
ERROR - 2011-08-18 16:01:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 16:01:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 16:01:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 16:01:46 --> Model Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Model Class Initialized
DEBUG - 2011-08-18 16:01:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 16:01:46 --> Database Driver Class Initialized
DEBUG - 2011-08-18 16:01:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 16:01:46 --> Helper loaded: url_helper
DEBUG - 2011-08-18 16:01:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 16:01:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 16:01:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 16:01:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 16:01:46 --> Final output sent to browser
DEBUG - 2011-08-18 16:01:46 --> Total execution time: 0.0320
DEBUG - 2011-08-18 16:11:27 --> Config Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Hooks Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Utf8 Class Initialized
DEBUG - 2011-08-18 16:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 16:11:27 --> URI Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Router Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Output Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Input Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 16:11:27 --> Language Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Loader Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Controller Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Config Class Initialized
ERROR - 2011-08-18 16:11:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 16:11:27 --> Hooks Class Initialized
ERROR - 2011-08-18 16:11:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 16:11:27 --> Utf8 Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Model Class Initialized
DEBUG - 2011-08-18 16:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 16:11:27 --> Model Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 16:11:27 --> URI Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Router Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Output Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Input Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 16:11:27 --> Language Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Database Driver Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Loader Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Controller Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Model Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Model Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Model Class Initialized
DEBUG - 2011-08-18 16:11:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 16:11:27 --> Helper loaded: url_helper
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 16:11:27 --> Database Driver Class Initialized
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 16:11:27 --> Final output sent to browser
DEBUG - 2011-08-18 16:11:27 --> Total execution time: 0.0280
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 16:11:27 --> Helper loaded: url_helper
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 16:11:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 16:11:27 --> Final output sent to browser
DEBUG - 2011-08-18 16:11:27 --> Total execution time: 0.0442
DEBUG - 2011-08-18 16:44:12 --> Config Class Initialized
DEBUG - 2011-08-18 16:44:12 --> Hooks Class Initialized
DEBUG - 2011-08-18 16:44:12 --> Utf8 Class Initialized
DEBUG - 2011-08-18 16:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 16:44:12 --> URI Class Initialized
DEBUG - 2011-08-18 16:44:12 --> Router Class Initialized
DEBUG - 2011-08-18 16:44:12 --> No URI present. Default controller set.
DEBUG - 2011-08-18 16:44:12 --> Output Class Initialized
DEBUG - 2011-08-18 16:44:12 --> Input Class Initialized
DEBUG - 2011-08-18 16:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 16:44:12 --> Language Class Initialized
DEBUG - 2011-08-18 16:44:12 --> Loader Class Initialized
DEBUG - 2011-08-18 16:44:12 --> Controller Class Initialized
DEBUG - 2011-08-18 16:44:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-18 16:44:12 --> Helper loaded: url_helper
DEBUG - 2011-08-18 16:44:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 16:44:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 16:44:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 16:44:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 16:44:12 --> Final output sent to browser
DEBUG - 2011-08-18 16:44:12 --> Total execution time: 0.0719
DEBUG - 2011-08-18 18:01:06 --> Config Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Hooks Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Utf8 Class Initialized
DEBUG - 2011-08-18 18:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 18:01:06 --> URI Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Router Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Output Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Input Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 18:01:06 --> Language Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Loader Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Controller Class Initialized
ERROR - 2011-08-18 18:01:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 18:01:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 18:01:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 18:01:06 --> Model Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Model Class Initialized
DEBUG - 2011-08-18 18:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 18:01:06 --> Database Driver Class Initialized
DEBUG - 2011-08-18 18:01:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 18:01:06 --> Helper loaded: url_helper
DEBUG - 2011-08-18 18:01:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 18:01:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 18:01:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 18:01:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 18:01:06 --> Final output sent to browser
DEBUG - 2011-08-18 18:01:06 --> Total execution time: 0.0682
DEBUG - 2011-08-18 18:01:08 --> Config Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Hooks Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Utf8 Class Initialized
DEBUG - 2011-08-18 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 18:01:08 --> URI Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Router Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Output Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Input Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 18:01:08 --> Language Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Loader Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Controller Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Model Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Model Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 18:01:08 --> Database Driver Class Initialized
DEBUG - 2011-08-18 18:01:08 --> Final output sent to browser
DEBUG - 2011-08-18 18:01:08 --> Total execution time: 0.6707
DEBUG - 2011-08-18 18:01:10 --> Config Class Initialized
DEBUG - 2011-08-18 18:01:10 --> Hooks Class Initialized
DEBUG - 2011-08-18 18:01:10 --> Utf8 Class Initialized
DEBUG - 2011-08-18 18:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 18:01:10 --> URI Class Initialized
DEBUG - 2011-08-18 18:01:10 --> Router Class Initialized
ERROR - 2011-08-18 18:01:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 19:14:23 --> Config Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:14:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:14:23 --> URI Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Router Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Output Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Input Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 19:14:23 --> Language Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Loader Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Controller Class Initialized
ERROR - 2011-08-18 19:14:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 19:14:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 19:14:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 19:14:23 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 19:14:23 --> Database Driver Class Initialized
DEBUG - 2011-08-18 19:14:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 19:14:23 --> Helper loaded: url_helper
DEBUG - 2011-08-18 19:14:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 19:14:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 19:14:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 19:14:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 19:14:23 --> Final output sent to browser
DEBUG - 2011-08-18 19:14:23 --> Total execution time: 0.1006
DEBUG - 2011-08-18 19:14:27 --> Config Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:14:27 --> URI Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Router Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Output Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Input Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 19:14:27 --> Language Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Loader Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Controller Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 19:14:27 --> Database Driver Class Initialized
DEBUG - 2011-08-18 19:14:27 --> Final output sent to browser
DEBUG - 2011-08-18 19:14:27 --> Total execution time: 0.6194
DEBUG - 2011-08-18 19:14:31 --> Config Class Initialized
DEBUG - 2011-08-18 19:14:31 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:14:31 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:14:31 --> URI Class Initialized
DEBUG - 2011-08-18 19:14:31 --> Router Class Initialized
ERROR - 2011-08-18 19:14:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 19:14:34 --> Config Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:14:34 --> URI Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Router Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Output Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Input Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 19:14:34 --> Language Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Loader Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Controller Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 19:14:34 --> Database Driver Class Initialized
DEBUG - 2011-08-18 19:14:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 19:14:34 --> Helper loaded: url_helper
DEBUG - 2011-08-18 19:14:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 19:14:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 19:14:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 19:14:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 19:14:34 --> Final output sent to browser
DEBUG - 2011-08-18 19:14:34 --> Total execution time: 0.8538
DEBUG - 2011-08-18 19:14:36 --> Config Class Initialized
DEBUG - 2011-08-18 19:14:36 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:14:36 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:14:36 --> URI Class Initialized
DEBUG - 2011-08-18 19:14:36 --> Router Class Initialized
ERROR - 2011-08-18 19:14:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 19:14:59 --> Config Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:14:59 --> URI Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Router Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Output Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Input Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 19:14:59 --> Language Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Loader Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Controller Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Model Class Initialized
DEBUG - 2011-08-18 19:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 19:14:59 --> Database Driver Class Initialized
DEBUG - 2011-08-18 19:14:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 19:14:59 --> Helper loaded: url_helper
DEBUG - 2011-08-18 19:14:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 19:14:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 19:14:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 19:14:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 19:14:59 --> Final output sent to browser
DEBUG - 2011-08-18 19:14:59 --> Total execution time: 0.0576
DEBUG - 2011-08-18 19:15:00 --> Config Class Initialized
DEBUG - 2011-08-18 19:15:00 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:15:00 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:15:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:15:00 --> URI Class Initialized
DEBUG - 2011-08-18 19:15:00 --> Router Class Initialized
ERROR - 2011-08-18 19:15:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 19:16:56 --> Config Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:16:56 --> URI Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Router Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Output Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Input Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 19:16:56 --> Language Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Loader Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Controller Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Model Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Model Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Model Class Initialized
DEBUG - 2011-08-18 19:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 19:16:56 --> Database Driver Class Initialized
DEBUG - 2011-08-18 19:16:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 19:16:56 --> Helper loaded: url_helper
DEBUG - 2011-08-18 19:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 19:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 19:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 19:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 19:16:56 --> Final output sent to browser
DEBUG - 2011-08-18 19:16:56 --> Total execution time: 0.0742
DEBUG - 2011-08-18 19:16:57 --> Config Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:16:57 --> URI Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Router Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Output Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Input Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 19:16:57 --> Language Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Loader Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Controller Class Initialized
ERROR - 2011-08-18 19:16:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 19:16:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 19:16:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 19:16:57 --> Model Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Model Class Initialized
DEBUG - 2011-08-18 19:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 19:16:57 --> Database Driver Class Initialized
DEBUG - 2011-08-18 19:16:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 19:16:57 --> Helper loaded: url_helper
DEBUG - 2011-08-18 19:16:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 19:16:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 19:16:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 19:16:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 19:16:57 --> Final output sent to browser
DEBUG - 2011-08-18 19:16:57 --> Total execution time: 0.0292
DEBUG - 2011-08-18 19:21:39 --> Config Class Initialized
DEBUG - 2011-08-18 19:21:39 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:21:39 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:21:39 --> URI Class Initialized
DEBUG - 2011-08-18 19:21:39 --> Router Class Initialized
ERROR - 2011-08-18 19:21:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-18 19:40:09 --> Config Class Initialized
DEBUG - 2011-08-18 19:40:09 --> Hooks Class Initialized
DEBUG - 2011-08-18 19:40:09 --> Utf8 Class Initialized
DEBUG - 2011-08-18 19:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 19:40:09 --> URI Class Initialized
DEBUG - 2011-08-18 19:40:09 --> Router Class Initialized
DEBUG - 2011-08-18 19:40:09 --> No URI present. Default controller set.
DEBUG - 2011-08-18 19:40:09 --> Output Class Initialized
DEBUG - 2011-08-18 19:40:09 --> Input Class Initialized
DEBUG - 2011-08-18 19:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 19:40:09 --> Language Class Initialized
DEBUG - 2011-08-18 19:40:09 --> Loader Class Initialized
DEBUG - 2011-08-18 19:40:09 --> Controller Class Initialized
DEBUG - 2011-08-18 19:40:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-18 19:40:09 --> Helper loaded: url_helper
DEBUG - 2011-08-18 19:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 19:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 19:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 19:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 19:40:09 --> Final output sent to browser
DEBUG - 2011-08-18 19:40:09 --> Total execution time: 0.0420
DEBUG - 2011-08-18 20:15:32 --> Config Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Hooks Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Utf8 Class Initialized
DEBUG - 2011-08-18 20:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 20:15:32 --> URI Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Router Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Output Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Input Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 20:15:32 --> Language Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Loader Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Controller Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Model Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Model Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Model Class Initialized
DEBUG - 2011-08-18 20:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 20:15:32 --> Database Driver Class Initialized
DEBUG - 2011-08-18 20:15:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-18 20:15:33 --> Helper loaded: url_helper
DEBUG - 2011-08-18 20:15:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 20:15:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 20:15:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 20:15:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 20:15:33 --> Final output sent to browser
DEBUG - 2011-08-18 20:15:33 --> Total execution time: 0.3894
DEBUG - 2011-08-18 20:15:34 --> Config Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Hooks Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Utf8 Class Initialized
DEBUG - 2011-08-18 20:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 20:15:34 --> URI Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Router Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Output Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Input Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 20:15:34 --> Language Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Loader Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Controller Class Initialized
ERROR - 2011-08-18 20:15:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-18 20:15:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-18 20:15:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 20:15:34 --> Model Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Model Class Initialized
DEBUG - 2011-08-18 20:15:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-18 20:15:34 --> Database Driver Class Initialized
DEBUG - 2011-08-18 20:15:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-18 20:15:34 --> Helper loaded: url_helper
DEBUG - 2011-08-18 20:15:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 20:15:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 20:15:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 20:15:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 20:15:34 --> Final output sent to browser
DEBUG - 2011-08-18 20:15:34 --> Total execution time: 0.0365
DEBUG - 2011-08-18 23:02:38 --> Config Class Initialized
DEBUG - 2011-08-18 23:02:38 --> Hooks Class Initialized
DEBUG - 2011-08-18 23:02:38 --> Utf8 Class Initialized
DEBUG - 2011-08-18 23:02:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 23:02:38 --> URI Class Initialized
DEBUG - 2011-08-18 23:02:38 --> Router Class Initialized
DEBUG - 2011-08-18 23:02:38 --> No URI present. Default controller set.
DEBUG - 2011-08-18 23:02:38 --> Output Class Initialized
DEBUG - 2011-08-18 23:02:38 --> Input Class Initialized
DEBUG - 2011-08-18 23:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 23:02:38 --> Language Class Initialized
DEBUG - 2011-08-18 23:02:38 --> Loader Class Initialized
DEBUG - 2011-08-18 23:02:38 --> Controller Class Initialized
DEBUG - 2011-08-18 23:02:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-18 23:02:38 --> Helper loaded: url_helper
DEBUG - 2011-08-18 23:02:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 23:02:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 23:02:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 23:02:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 23:02:38 --> Final output sent to browser
DEBUG - 2011-08-18 23:02:38 --> Total execution time: 0.1999
DEBUG - 2011-08-18 23:24:16 --> Config Class Initialized
DEBUG - 2011-08-18 23:24:16 --> Hooks Class Initialized
DEBUG - 2011-08-18 23:24:16 --> Utf8 Class Initialized
DEBUG - 2011-08-18 23:24:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 23:24:16 --> URI Class Initialized
DEBUG - 2011-08-18 23:24:16 --> Router Class Initialized
DEBUG - 2011-08-18 23:24:16 --> No URI present. Default controller set.
DEBUG - 2011-08-18 23:24:16 --> Output Class Initialized
DEBUG - 2011-08-18 23:24:16 --> Input Class Initialized
DEBUG - 2011-08-18 23:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 23:24:16 --> Language Class Initialized
DEBUG - 2011-08-18 23:24:16 --> Loader Class Initialized
DEBUG - 2011-08-18 23:24:16 --> Controller Class Initialized
DEBUG - 2011-08-18 23:24:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-18 23:24:16 --> Helper loaded: url_helper
DEBUG - 2011-08-18 23:24:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 23:24:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 23:24:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 23:24:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 23:24:16 --> Final output sent to browser
DEBUG - 2011-08-18 23:24:16 --> Total execution time: 0.0119
DEBUG - 2011-08-18 23:24:17 --> Config Class Initialized
DEBUG - 2011-08-18 23:24:17 --> Hooks Class Initialized
DEBUG - 2011-08-18 23:24:17 --> Utf8 Class Initialized
DEBUG - 2011-08-18 23:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 23:24:17 --> URI Class Initialized
DEBUG - 2011-08-18 23:24:17 --> Router Class Initialized
ERROR - 2011-08-18 23:24:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-18 23:39:10 --> Config Class Initialized
DEBUG - 2011-08-18 23:39:10 --> Hooks Class Initialized
DEBUG - 2011-08-18 23:39:10 --> Utf8 Class Initialized
DEBUG - 2011-08-18 23:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-18 23:39:10 --> URI Class Initialized
DEBUG - 2011-08-18 23:39:10 --> Router Class Initialized
DEBUG - 2011-08-18 23:39:10 --> No URI present. Default controller set.
DEBUG - 2011-08-18 23:39:10 --> Output Class Initialized
DEBUG - 2011-08-18 23:39:10 --> Input Class Initialized
DEBUG - 2011-08-18 23:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-18 23:39:10 --> Language Class Initialized
DEBUG - 2011-08-18 23:39:10 --> Loader Class Initialized
DEBUG - 2011-08-18 23:39:10 --> Controller Class Initialized
DEBUG - 2011-08-18 23:39:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-18 23:39:10 --> Helper loaded: url_helper
DEBUG - 2011-08-18 23:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-18 23:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-18 23:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-18 23:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-18 23:39:10 --> Final output sent to browser
DEBUG - 2011-08-18 23:39:10 --> Total execution time: 0.0459

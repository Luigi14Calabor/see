<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-05 00:05:38 --> Config Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Hooks Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Utf8 Class Initialized
DEBUG - 2011-09-05 00:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 00:05:38 --> URI Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Router Class Initialized
ERROR - 2011-09-05 00:05:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 00:05:38 --> Config Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Hooks Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Utf8 Class Initialized
DEBUG - 2011-09-05 00:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 00:05:38 --> URI Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Router Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Output Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Input Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 00:05:38 --> Language Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Loader Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Controller Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Model Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Model Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Model Class Initialized
DEBUG - 2011-09-05 00:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 00:05:38 --> Database Driver Class Initialized
DEBUG - 2011-09-05 00:05:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 00:05:38 --> Helper loaded: url_helper
DEBUG - 2011-09-05 00:05:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 00:05:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 00:05:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 00:05:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 00:05:38 --> Final output sent to browser
DEBUG - 2011-09-05 00:05:38 --> Total execution time: 0.2399
DEBUG - 2011-09-05 01:06:11 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:11 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:11 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:11 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:11 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:11 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:11 --> Total execution time: 0.2417
DEBUG - 2011-09-05 01:06:14 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:14 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:14 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:14 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:14 --> Router Class Initialized
ERROR - 2011-09-05 01:06:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 01:06:28 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:28 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:28 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:28 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:28 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:28 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:28 --> Total execution time: 0.2201
DEBUG - 2011-09-05 01:06:31 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:31 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:31 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:31 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:31 --> Router Class Initialized
ERROR - 2011-09-05 01:06:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 01:06:36 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:36 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:36 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:36 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:36 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:36 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:36 --> Total execution time: 0.2274
DEBUG - 2011-09-05 01:06:39 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:39 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:39 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:39 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:39 --> Router Class Initialized
ERROR - 2011-09-05 01:06:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 01:06:42 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:42 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:42 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:42 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:42 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:42 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:42 --> Total execution time: 0.2042
DEBUG - 2011-09-05 01:06:44 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:44 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:44 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:44 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:44 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:44 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:44 --> Total execution time: 0.0642
DEBUG - 2011-09-05 01:06:45 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:45 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:45 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:45 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:45 --> Router Class Initialized
ERROR - 2011-09-05 01:06:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 01:06:46 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:46 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:46 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:46 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:46 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:46 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:46 --> Total execution time: 0.0434
DEBUG - 2011-09-05 01:06:47 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:47 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:47 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:47 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:47 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:47 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:47 --> Total execution time: 0.0539
DEBUG - 2011-09-05 01:06:49 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:49 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:49 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:49 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:50 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:50 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:50 --> Total execution time: 0.2722
DEBUG - 2011-09-05 01:06:51 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:51 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Router Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Output Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Input Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:06:51 --> Language Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Loader Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Controller Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Model Class Initialized
DEBUG - 2011-09-05 01:06:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:06:51 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:06:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:06:51 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:06:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:06:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:06:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:06:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:06:51 --> Final output sent to browser
DEBUG - 2011-09-05 01:06:51 --> Total execution time: 0.0443
DEBUG - 2011-09-05 01:06:52 --> Config Class Initialized
DEBUG - 2011-09-05 01:06:52 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:06:52 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:06:52 --> URI Class Initialized
DEBUG - 2011-09-05 01:06:52 --> Router Class Initialized
ERROR - 2011-09-05 01:06:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 01:42:51 --> Config Class Initialized
DEBUG - 2011-09-05 01:42:51 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:42:51 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:42:51 --> URI Class Initialized
DEBUG - 2011-09-05 01:42:51 --> Router Class Initialized
DEBUG - 2011-09-05 01:42:51 --> Output Class Initialized
DEBUG - 2011-09-05 01:42:52 --> Input Class Initialized
DEBUG - 2011-09-05 01:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:42:52 --> Language Class Initialized
DEBUG - 2011-09-05 01:42:52 --> Loader Class Initialized
DEBUG - 2011-09-05 01:42:52 --> Controller Class Initialized
ERROR - 2011-09-05 01:42:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 01:42:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 01:42:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 01:42:52 --> Model Class Initialized
DEBUG - 2011-09-05 01:42:52 --> Model Class Initialized
DEBUG - 2011-09-05 01:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:42:52 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:42:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 01:42:53 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:42:53 --> Final output sent to browser
DEBUG - 2011-09-05 01:42:53 --> Total execution time: 1.2407
DEBUG - 2011-09-05 01:49:08 --> Config Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:49:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:49:08 --> URI Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Router Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Output Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Input Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:49:08 --> Language Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Loader Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Controller Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:49:08 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:49:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:49:12 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:49:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:49:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:49:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:49:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:49:12 --> Final output sent to browser
DEBUG - 2011-09-05 01:49:12 --> Total execution time: 3.7237
DEBUG - 2011-09-05 01:49:14 --> Config Class Initialized
DEBUG - 2011-09-05 01:49:14 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:49:14 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:49:14 --> URI Class Initialized
DEBUG - 2011-09-05 01:49:14 --> Router Class Initialized
ERROR - 2011-09-05 01:49:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 01:49:14 --> Config Class Initialized
DEBUG - 2011-09-05 01:49:14 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:49:14 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:49:14 --> URI Class Initialized
DEBUG - 2011-09-05 01:49:14 --> Router Class Initialized
ERROR - 2011-09-05 01:49:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 01:49:22 --> Config Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:49:22 --> URI Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Router Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Output Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Input Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:49:22 --> Language Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Loader Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Controller Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:49:22 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:49:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:49:23 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:49:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:49:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:49:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:49:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:49:23 --> Final output sent to browser
DEBUG - 2011-09-05 01:49:23 --> Total execution time: 0.6964
DEBUG - 2011-09-05 01:49:57 --> Config Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:49:57 --> URI Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Router Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Output Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Input Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:49:57 --> Language Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Loader Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Controller Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Model Class Initialized
DEBUG - 2011-09-05 01:49:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:49:57 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:49:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:49:58 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:49:58 --> Final output sent to browser
DEBUG - 2011-09-05 01:49:58 --> Total execution time: 1.4027
DEBUG - 2011-09-05 01:50:24 --> Config Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Hooks Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Utf8 Class Initialized
DEBUG - 2011-09-05 01:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 01:50:24 --> URI Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Router Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Output Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Input Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 01:50:24 --> Language Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Loader Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Controller Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Model Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Model Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Model Class Initialized
DEBUG - 2011-09-05 01:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 01:50:24 --> Database Driver Class Initialized
DEBUG - 2011-09-05 01:50:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 01:50:24 --> Helper loaded: url_helper
DEBUG - 2011-09-05 01:50:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 01:50:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 01:50:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 01:50:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 01:50:24 --> Final output sent to browser
DEBUG - 2011-09-05 01:50:24 --> Total execution time: 0.1641
DEBUG - 2011-09-05 02:51:10 --> Config Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Hooks Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Utf8 Class Initialized
DEBUG - 2011-09-05 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 02:51:10 --> URI Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Router Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Output Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Input Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 02:51:10 --> Language Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Loader Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Controller Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Model Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Model Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Model Class Initialized
DEBUG - 2011-09-05 02:51:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 02:51:10 --> Database Driver Class Initialized
DEBUG - 2011-09-05 02:51:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 02:51:13 --> Helper loaded: url_helper
DEBUG - 2011-09-05 02:51:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 02:51:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 02:51:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 02:51:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 02:51:13 --> Final output sent to browser
DEBUG - 2011-09-05 02:51:13 --> Total execution time: 2.9824
DEBUG - 2011-09-05 02:51:16 --> Config Class Initialized
DEBUG - 2011-09-05 02:51:16 --> Hooks Class Initialized
DEBUG - 2011-09-05 02:51:16 --> Utf8 Class Initialized
DEBUG - 2011-09-05 02:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 02:51:16 --> URI Class Initialized
DEBUG - 2011-09-05 02:51:16 --> Router Class Initialized
ERROR - 2011-09-05 02:51:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 02:51:16 --> Config Class Initialized
DEBUG - 2011-09-05 02:51:16 --> Hooks Class Initialized
DEBUG - 2011-09-05 02:51:16 --> Utf8 Class Initialized
DEBUG - 2011-09-05 02:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 02:51:16 --> URI Class Initialized
DEBUG - 2011-09-05 02:51:16 --> Router Class Initialized
ERROR - 2011-09-05 02:51:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 02:56:31 --> Config Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Hooks Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Utf8 Class Initialized
DEBUG - 2011-09-05 02:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 02:56:31 --> URI Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Router Class Initialized
ERROR - 2011-09-05 02:56:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 02:56:31 --> Config Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Hooks Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Utf8 Class Initialized
DEBUG - 2011-09-05 02:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 02:56:31 --> URI Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Router Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Output Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Input Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 02:56:31 --> Language Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Loader Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Controller Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Model Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Model Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Model Class Initialized
DEBUG - 2011-09-05 02:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 02:56:31 --> Database Driver Class Initialized
DEBUG - 2011-09-05 02:56:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 02:56:31 --> Helper loaded: url_helper
DEBUG - 2011-09-05 02:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 02:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 02:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 02:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 02:56:31 --> Final output sent to browser
DEBUG - 2011-09-05 02:56:31 --> Total execution time: 0.1557
DEBUG - 2011-09-05 03:20:15 --> Config Class Initialized
DEBUG - 2011-09-05 03:20:15 --> Hooks Class Initialized
DEBUG - 2011-09-05 03:20:15 --> Utf8 Class Initialized
DEBUG - 2011-09-05 03:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 03:20:15 --> URI Class Initialized
DEBUG - 2011-09-05 03:20:15 --> Router Class Initialized
DEBUG - 2011-09-05 03:20:15 --> Output Class Initialized
DEBUG - 2011-09-05 03:20:15 --> Input Class Initialized
DEBUG - 2011-09-05 03:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 03:20:15 --> Language Class Initialized
DEBUG - 2011-09-05 03:20:16 --> Loader Class Initialized
DEBUG - 2011-09-05 03:20:16 --> Controller Class Initialized
DEBUG - 2011-09-05 03:20:16 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:16 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:16 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 03:20:16 --> Database Driver Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Config Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Hooks Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Utf8 Class Initialized
DEBUG - 2011-09-05 03:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 03:20:27 --> URI Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Router Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Output Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Input Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 03:20:27 --> Language Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Loader Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Controller Class Initialized
ERROR - 2011-09-05 03:20:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 03:20:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 03:20:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 03:20:27 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 03:20:27 --> Database Driver Class Initialized
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 03:20:28 --> Helper loaded: url_helper
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 03:20:28 --> Final output sent to browser
DEBUG - 2011-09-05 03:20:28 --> Total execution time: 1.0990
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 03:20:28 --> Helper loaded: url_helper
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 03:20:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 03:20:28 --> Final output sent to browser
DEBUG - 2011-09-05 03:20:28 --> Total execution time: 14.3306
DEBUG - 2011-09-05 03:20:29 --> Config Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Hooks Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Utf8 Class Initialized
DEBUG - 2011-09-05 03:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 03:20:29 --> URI Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Router Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Output Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Input Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 03:20:29 --> Language Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Loader Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Controller Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 03:20:29 --> Database Driver Class Initialized
DEBUG - 2011-09-05 03:20:31 --> Final output sent to browser
DEBUG - 2011-09-05 03:20:31 --> Total execution time: 1.0986
DEBUG - 2011-09-05 03:20:31 --> Config Class Initialized
DEBUG - 2011-09-05 03:20:31 --> Hooks Class Initialized
DEBUG - 2011-09-05 03:20:31 --> Utf8 Class Initialized
DEBUG - 2011-09-05 03:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 03:20:31 --> URI Class Initialized
DEBUG - 2011-09-05 03:20:31 --> Router Class Initialized
ERROR - 2011-09-05 03:20:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 03:20:32 --> Config Class Initialized
DEBUG - 2011-09-05 03:20:32 --> Hooks Class Initialized
DEBUG - 2011-09-05 03:20:32 --> Utf8 Class Initialized
DEBUG - 2011-09-05 03:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 03:20:32 --> URI Class Initialized
DEBUG - 2011-09-05 03:20:32 --> Router Class Initialized
ERROR - 2011-09-05 03:20:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 03:20:32 --> Config Class Initialized
DEBUG - 2011-09-05 03:20:32 --> Hooks Class Initialized
DEBUG - 2011-09-05 03:20:32 --> Utf8 Class Initialized
DEBUG - 2011-09-05 03:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 03:20:32 --> URI Class Initialized
DEBUG - 2011-09-05 03:20:32 --> Router Class Initialized
ERROR - 2011-09-05 03:20:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 03:20:42 --> Config Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Hooks Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Utf8 Class Initialized
DEBUG - 2011-09-05 03:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 03:20:42 --> URI Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Router Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Output Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Input Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 03:20:42 --> Language Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Loader Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Controller Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Model Class Initialized
DEBUG - 2011-09-05 03:20:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 03:20:42 --> Database Driver Class Initialized
DEBUG - 2011-09-05 03:20:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 03:20:42 --> Helper loaded: url_helper
DEBUG - 2011-09-05 03:20:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 03:20:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 03:20:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 03:20:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 03:20:42 --> Final output sent to browser
DEBUG - 2011-09-05 03:20:42 --> Total execution time: 0.0512
DEBUG - 2011-09-05 04:21:37 --> Config Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Hooks Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Utf8 Class Initialized
DEBUG - 2011-09-05 04:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 04:21:37 --> URI Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Router Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Output Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Input Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 04:21:37 --> Language Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Loader Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Controller Class Initialized
ERROR - 2011-09-05 04:21:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 04:21:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 04:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 04:21:37 --> Model Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Model Class Initialized
DEBUG - 2011-09-05 04:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 04:21:37 --> Database Driver Class Initialized
DEBUG - 2011-09-05 04:21:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 04:21:38 --> Helper loaded: url_helper
DEBUG - 2011-09-05 04:21:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 04:21:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 04:21:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 04:21:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 04:21:38 --> Final output sent to browser
DEBUG - 2011-09-05 04:21:38 --> Total execution time: 0.7414
DEBUG - 2011-09-05 04:21:41 --> Config Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Hooks Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Utf8 Class Initialized
DEBUG - 2011-09-05 04:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 04:21:41 --> URI Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Router Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Output Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Input Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 04:21:41 --> Language Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Loader Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Controller Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Model Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Model Class Initialized
DEBUG - 2011-09-05 04:21:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 04:21:41 --> Database Driver Class Initialized
DEBUG - 2011-09-05 04:21:43 --> Final output sent to browser
DEBUG - 2011-09-05 04:21:43 --> Total execution time: 1.8208
DEBUG - 2011-09-05 04:50:24 --> Config Class Initialized
DEBUG - 2011-09-05 04:50:24 --> Hooks Class Initialized
DEBUG - 2011-09-05 04:50:24 --> Utf8 Class Initialized
DEBUG - 2011-09-05 04:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 04:50:24 --> URI Class Initialized
DEBUG - 2011-09-05 04:50:24 --> Router Class Initialized
DEBUG - 2011-09-05 04:50:24 --> No URI present. Default controller set.
DEBUG - 2011-09-05 04:50:24 --> Output Class Initialized
DEBUG - 2011-09-05 04:50:24 --> Input Class Initialized
DEBUG - 2011-09-05 04:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 04:50:24 --> Language Class Initialized
DEBUG - 2011-09-05 04:50:24 --> Loader Class Initialized
DEBUG - 2011-09-05 04:50:24 --> Controller Class Initialized
DEBUG - 2011-09-05 04:50:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-05 04:50:24 --> Helper loaded: url_helper
DEBUG - 2011-09-05 04:50:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 04:50:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 04:50:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 04:50:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 04:50:24 --> Final output sent to browser
DEBUG - 2011-09-05 04:50:24 --> Total execution time: 0.0549
DEBUG - 2011-09-05 05:39:17 --> Config Class Initialized
DEBUG - 2011-09-05 05:39:17 --> Hooks Class Initialized
DEBUG - 2011-09-05 05:39:17 --> Utf8 Class Initialized
DEBUG - 2011-09-05 05:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 05:39:17 --> URI Class Initialized
DEBUG - 2011-09-05 05:39:17 --> Router Class Initialized
ERROR - 2011-09-05 05:39:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 06:22:03 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:03 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Router Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Output Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Input Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:22:03 --> Language Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Loader Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Controller Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:22:03 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:22:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 06:22:04 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:22:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:22:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:22:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:22:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:22:04 --> Final output sent to browser
DEBUG - 2011-09-05 06:22:04 --> Total execution time: 1.1379
DEBUG - 2011-09-05 06:22:06 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:06 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Router Class Initialized
ERROR - 2011-09-05 06:22:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 06:22:06 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:06 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Router Class Initialized
ERROR - 2011-09-05 06:22:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 06:22:06 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:06 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:06 --> Router Class Initialized
ERROR - 2011-09-05 06:22:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 06:22:13 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:13 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Router Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Output Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Input Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:22:13 --> Language Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Loader Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Controller Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:22:13 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:22:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 06:22:14 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:22:14 --> Final output sent to browser
DEBUG - 2011-09-05 06:22:14 --> Total execution time: 0.3908
DEBUG - 2011-09-05 06:22:17 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:17 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Router Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Output Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Input Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:22:17 --> Language Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Loader Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Controller Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:22:17 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:22:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 06:22:18 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:22:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:22:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:22:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:22:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:22:18 --> Final output sent to browser
DEBUG - 2011-09-05 06:22:18 --> Total execution time: 0.2755
DEBUG - 2011-09-05 06:22:23 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:23 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Router Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Output Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Input Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:22:23 --> Language Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Loader Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Controller Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:22:23 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:22:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 06:22:24 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:22:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:22:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:22:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:22:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:22:24 --> Final output sent to browser
DEBUG - 2011-09-05 06:22:24 --> Total execution time: 0.2792
DEBUG - 2011-09-05 06:22:29 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:29 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Router Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Output Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Input Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:22:29 --> Language Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Loader Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Controller Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:22:29 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:22:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 06:22:29 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:22:29 --> Final output sent to browser
DEBUG - 2011-09-05 06:22:29 --> Total execution time: 0.3645
DEBUG - 2011-09-05 06:22:33 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:33 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Router Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Output Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Input Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:22:33 --> Language Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Loader Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Controller Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:22:33 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:22:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 06:22:33 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:22:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:22:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:22:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:22:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:22:33 --> Final output sent to browser
DEBUG - 2011-09-05 06:22:33 --> Total execution time: 0.2183
DEBUG - 2011-09-05 06:22:50 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:50 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Router Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Output Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Input Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:22:50 --> Language Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Loader Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Controller Class Initialized
ERROR - 2011-09-05 06:22:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:22:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:22:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:22:50 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:22:50 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:22:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:22:50 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:22:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:22:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:22:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:22:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:22:50 --> Final output sent to browser
DEBUG - 2011-09-05 06:22:50 --> Total execution time: 0.2686
DEBUG - 2011-09-05 06:22:50 --> Config Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:22:50 --> URI Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Router Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Output Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Input Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:22:50 --> Language Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Loader Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Controller Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Model Class Initialized
DEBUG - 2011-09-05 06:22:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:22:50 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:22:51 --> Final output sent to browser
DEBUG - 2011-09-05 06:22:51 --> Total execution time: 0.7299
DEBUG - 2011-09-05 06:49:58 --> Config Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:49:58 --> URI Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Router Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Output Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Input Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:49:58 --> Language Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Loader Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Controller Class Initialized
ERROR - 2011-09-05 06:49:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:49:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:49:58 --> Model Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Model Class Initialized
DEBUG - 2011-09-05 06:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:49:58 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:49:58 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:49:58 --> Final output sent to browser
DEBUG - 2011-09-05 06:49:58 --> Total execution time: 0.9384
DEBUG - 2011-09-05 06:49:59 --> Config Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:49:59 --> URI Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Router Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Output Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Input Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:49:59 --> Language Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Loader Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Controller Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Model Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Model Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:49:59 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:49:59 --> Final output sent to browser
DEBUG - 2011-09-05 06:49:59 --> Total execution time: 0.7350
DEBUG - 2011-09-05 06:50:00 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:00 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Router Class Initialized
ERROR - 2011-09-05 06:50:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 06:50:00 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:00 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Router Class Initialized
ERROR - 2011-09-05 06:50:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 06:50:00 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:00 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Router Class Initialized
ERROR - 2011-09-05 06:50:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 06:50:00 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:00 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:00 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Controller Class Initialized
ERROR - 2011-09-05 06:50:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:50:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:00 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:00 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:00 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:50:00 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:00 --> Total execution time: 0.0320
DEBUG - 2011-09-05 06:50:01 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:01 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:01 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:01 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:01 --> Router Class Initialized
ERROR - 2011-09-05 06:50:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 06:50:05 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:05 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:05 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Controller Class Initialized
ERROR - 2011-09-05 06:50:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:50:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:05 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:05 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:05 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:50:05 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:05 --> Total execution time: 0.0804
DEBUG - 2011-09-05 06:50:06 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:06 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:06 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Controller Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:06 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:06 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:06 --> Total execution time: 0.8968
DEBUG - 2011-09-05 06:50:16 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:16 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:16 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Controller Class Initialized
ERROR - 2011-09-05 06:50:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:50:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:50:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:16 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:16 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:16 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:50:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:50:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:50:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:50:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:50:16 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:16 --> Total execution time: 0.0319
DEBUG - 2011-09-05 06:50:16 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:16 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:16 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Controller Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:16 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:17 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:17 --> Total execution time: 0.5034
DEBUG - 2011-09-05 06:50:22 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:22 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:22 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Controller Class Initialized
ERROR - 2011-09-05 06:50:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:50:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:50:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:22 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:22 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:22 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:50:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:50:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:50:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:50:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:50:22 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:22 --> Total execution time: 0.0303
DEBUG - 2011-09-05 06:50:23 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:23 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:23 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Controller Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:23 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:23 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:23 --> Total execution time: 0.5661
DEBUG - 2011-09-05 06:50:33 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:33 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:33 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Controller Class Initialized
ERROR - 2011-09-05 06:50:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:50:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:50:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:33 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:33 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:33 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:50:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:50:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:50:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:50:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:50:33 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:33 --> Total execution time: 0.0632
DEBUG - 2011-09-05 06:50:33 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:33 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:33 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Controller Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:33 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:34 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:34 --> Total execution time: 0.5910
DEBUG - 2011-09-05 06:50:34 --> Config Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:50:34 --> URI Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Router Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Output Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Input Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:50:34 --> Language Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Loader Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Controller Class Initialized
ERROR - 2011-09-05 06:50:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:50:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:34 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Model Class Initialized
DEBUG - 2011-09-05 06:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:50:34 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:50:34 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:50:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:50:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:50:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:50:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:50:34 --> Final output sent to browser
DEBUG - 2011-09-05 06:50:34 --> Total execution time: 0.0277
DEBUG - 2011-09-05 06:57:51 --> Config Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:57:51 --> URI Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Router Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Output Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Input Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:57:51 --> Language Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Loader Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Controller Class Initialized
ERROR - 2011-09-05 06:57:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 06:57:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 06:57:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:57:51 --> Model Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Model Class Initialized
DEBUG - 2011-09-05 06:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:57:51 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:57:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 06:57:51 --> Helper loaded: url_helper
DEBUG - 2011-09-05 06:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 06:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 06:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 06:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 06:57:51 --> Final output sent to browser
DEBUG - 2011-09-05 06:57:51 --> Total execution time: 0.0698
DEBUG - 2011-09-05 06:57:53 --> Config Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:57:53 --> URI Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Router Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Output Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Input Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 06:57:53 --> Language Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Loader Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Controller Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Model Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Model Class Initialized
DEBUG - 2011-09-05 06:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 06:57:53 --> Database Driver Class Initialized
DEBUG - 2011-09-05 06:57:54 --> Final output sent to browser
DEBUG - 2011-09-05 06:57:54 --> Total execution time: 0.8794
DEBUG - 2011-09-05 06:57:55 --> Config Class Initialized
DEBUG - 2011-09-05 06:57:55 --> Hooks Class Initialized
DEBUG - 2011-09-05 06:57:55 --> Utf8 Class Initialized
DEBUG - 2011-09-05 06:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 06:57:55 --> URI Class Initialized
DEBUG - 2011-09-05 06:57:55 --> Router Class Initialized
ERROR - 2011-09-05 06:57:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 07:13:01 --> Config Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Hooks Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Utf8 Class Initialized
DEBUG - 2011-09-05 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 07:13:01 --> URI Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Router Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Output Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Input Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 07:13:01 --> Language Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Loader Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Controller Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Model Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Model Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Model Class Initialized
DEBUG - 2011-09-05 07:13:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 07:13:01 --> Database Driver Class Initialized
DEBUG - 2011-09-05 07:13:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 07:13:02 --> Helper loaded: url_helper
DEBUG - 2011-09-05 07:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 07:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 07:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 07:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 07:13:02 --> Final output sent to browser
DEBUG - 2011-09-05 07:13:02 --> Total execution time: 0.6314
DEBUG - 2011-09-05 07:13:04 --> Config Class Initialized
DEBUG - 2011-09-05 07:13:04 --> Hooks Class Initialized
DEBUG - 2011-09-05 07:13:04 --> Utf8 Class Initialized
DEBUG - 2011-09-05 07:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 07:13:04 --> URI Class Initialized
DEBUG - 2011-09-05 07:13:04 --> Router Class Initialized
ERROR - 2011-09-05 07:13:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 07:17:01 --> Config Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Hooks Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Utf8 Class Initialized
DEBUG - 2011-09-05 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 07:17:01 --> URI Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Router Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Output Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Input Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 07:17:01 --> Language Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Loader Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Controller Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Model Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Model Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Model Class Initialized
DEBUG - 2011-09-05 07:17:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 07:17:01 --> Database Driver Class Initialized
DEBUG - 2011-09-05 07:17:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 07:17:01 --> Helper loaded: url_helper
DEBUG - 2011-09-05 07:17:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 07:17:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 07:17:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 07:17:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 07:17:01 --> Final output sent to browser
DEBUG - 2011-09-05 07:17:01 --> Total execution time: 0.0557
DEBUG - 2011-09-05 07:17:02 --> Config Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Hooks Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Utf8 Class Initialized
DEBUG - 2011-09-05 07:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 07:17:02 --> URI Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Router Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Output Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Input Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 07:17:02 --> Language Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Loader Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Controller Class Initialized
ERROR - 2011-09-05 07:17:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 07:17:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 07:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 07:17:02 --> Model Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Model Class Initialized
DEBUG - 2011-09-05 07:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 07:17:02 --> Database Driver Class Initialized
DEBUG - 2011-09-05 07:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 07:17:02 --> Helper loaded: url_helper
DEBUG - 2011-09-05 07:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 07:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 07:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 07:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 07:17:02 --> Final output sent to browser
DEBUG - 2011-09-05 07:17:02 --> Total execution time: 0.0378
DEBUG - 2011-09-05 07:53:34 --> Config Class Initialized
DEBUG - 2011-09-05 07:53:34 --> Hooks Class Initialized
DEBUG - 2011-09-05 07:53:34 --> Utf8 Class Initialized
DEBUG - 2011-09-05 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 07:53:34 --> URI Class Initialized
DEBUG - 2011-09-05 07:53:34 --> Router Class Initialized
DEBUG - 2011-09-05 07:53:34 --> Output Class Initialized
DEBUG - 2011-09-05 07:53:34 --> Input Class Initialized
DEBUG - 2011-09-05 07:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 07:53:34 --> Language Class Initialized
DEBUG - 2011-09-05 07:53:34 --> Loader Class Initialized
DEBUG - 2011-09-05 07:53:34 --> Controller Class Initialized
ERROR - 2011-09-05 07:53:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 07:53:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 07:53:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 07:53:35 --> Model Class Initialized
DEBUG - 2011-09-05 07:53:35 --> Model Class Initialized
DEBUG - 2011-09-05 07:53:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 07:53:35 --> Database Driver Class Initialized
DEBUG - 2011-09-05 07:53:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 07:53:35 --> Helper loaded: url_helper
DEBUG - 2011-09-05 07:53:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 07:53:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 07:53:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 07:53:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 07:53:35 --> Final output sent to browser
DEBUG - 2011-09-05 07:53:35 --> Total execution time: 0.3393
DEBUG - 2011-09-05 07:53:38 --> Config Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Hooks Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Utf8 Class Initialized
DEBUG - 2011-09-05 07:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 07:53:38 --> URI Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Router Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Output Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Input Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 07:53:38 --> Language Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Loader Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Controller Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Model Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Model Class Initialized
DEBUG - 2011-09-05 07:53:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 07:53:38 --> Database Driver Class Initialized
DEBUG - 2011-09-05 07:53:39 --> Final output sent to browser
DEBUG - 2011-09-05 07:53:39 --> Total execution time: 0.6063
DEBUG - 2011-09-05 08:10:36 --> Config Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Hooks Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Utf8 Class Initialized
DEBUG - 2011-09-05 08:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 08:10:36 --> URI Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Router Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Output Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Input Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 08:10:36 --> Language Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Loader Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Controller Class Initialized
ERROR - 2011-09-05 08:10:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 08:10:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 08:10:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 08:10:36 --> Model Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Model Class Initialized
DEBUG - 2011-09-05 08:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 08:10:36 --> Database Driver Class Initialized
DEBUG - 2011-09-05 08:10:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 08:10:36 --> Helper loaded: url_helper
DEBUG - 2011-09-05 08:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 08:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 08:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 08:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 08:10:36 --> Final output sent to browser
DEBUG - 2011-09-05 08:10:36 --> Total execution time: 0.0967
DEBUG - 2011-09-05 08:10:39 --> Config Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Hooks Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Utf8 Class Initialized
DEBUG - 2011-09-05 08:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 08:10:39 --> URI Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Router Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Output Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Input Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 08:10:39 --> Language Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Loader Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Controller Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Model Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Model Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 08:10:39 --> Database Driver Class Initialized
DEBUG - 2011-09-05 08:10:39 --> Final output sent to browser
DEBUG - 2011-09-05 08:10:39 --> Total execution time: 0.5657
DEBUG - 2011-09-05 08:11:39 --> Config Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Hooks Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Utf8 Class Initialized
DEBUG - 2011-09-05 08:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 08:11:39 --> URI Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Router Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Output Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Input Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 08:11:39 --> Language Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Loader Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Controller Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Model Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Model Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Model Class Initialized
DEBUG - 2011-09-05 08:11:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 08:11:39 --> Database Driver Class Initialized
DEBUG - 2011-09-05 08:11:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 08:11:40 --> Helper loaded: url_helper
DEBUG - 2011-09-05 08:11:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 08:11:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 08:11:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 08:11:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 08:11:40 --> Final output sent to browser
DEBUG - 2011-09-05 08:11:40 --> Total execution time: 0.4048
DEBUG - 2011-09-05 08:11:43 --> Config Class Initialized
DEBUG - 2011-09-05 08:11:43 --> Hooks Class Initialized
DEBUG - 2011-09-05 08:11:43 --> Utf8 Class Initialized
DEBUG - 2011-09-05 08:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 08:11:43 --> URI Class Initialized
DEBUG - 2011-09-05 08:11:43 --> Router Class Initialized
ERROR - 2011-09-05 08:11:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 08:17:19 --> Config Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Hooks Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Utf8 Class Initialized
DEBUG - 2011-09-05 08:17:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 08:17:19 --> URI Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Router Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Output Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Input Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 08:17:19 --> Language Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Loader Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Controller Class Initialized
ERROR - 2011-09-05 08:17:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 08:17:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 08:17:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 08:17:19 --> Model Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Model Class Initialized
DEBUG - 2011-09-05 08:17:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 08:17:19 --> Database Driver Class Initialized
DEBUG - 2011-09-05 08:17:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 08:17:19 --> Helper loaded: url_helper
DEBUG - 2011-09-05 08:17:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 08:17:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 08:17:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 08:17:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 08:17:19 --> Final output sent to browser
DEBUG - 2011-09-05 08:17:19 --> Total execution time: 0.0375
DEBUG - 2011-09-05 08:59:52 --> Config Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Hooks Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Utf8 Class Initialized
DEBUG - 2011-09-05 08:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 08:59:52 --> URI Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Router Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Output Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Input Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 08:59:52 --> Language Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Loader Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Controller Class Initialized
ERROR - 2011-09-05 08:59:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 08:59:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 08:59:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 08:59:52 --> Model Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Model Class Initialized
DEBUG - 2011-09-05 08:59:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 08:59:52 --> Database Driver Class Initialized
DEBUG - 2011-09-05 08:59:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 08:59:52 --> Helper loaded: url_helper
DEBUG - 2011-09-05 08:59:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 08:59:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 08:59:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 08:59:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 08:59:52 --> Final output sent to browser
DEBUG - 2011-09-05 08:59:52 --> Total execution time: 0.3977
DEBUG - 2011-09-05 08:59:53 --> Config Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Hooks Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Utf8 Class Initialized
DEBUG - 2011-09-05 08:59:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 08:59:53 --> URI Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Router Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Output Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Input Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 08:59:53 --> Language Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Loader Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Controller Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Model Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Model Class Initialized
DEBUG - 2011-09-05 08:59:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 08:59:53 --> Database Driver Class Initialized
DEBUG - 2011-09-05 08:59:54 --> Final output sent to browser
DEBUG - 2011-09-05 08:59:54 --> Total execution time: 0.7358
DEBUG - 2011-09-05 10:23:04 --> Config Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:23:04 --> URI Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Router Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Output Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Input Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 10:23:04 --> Language Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Loader Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Controller Class Initialized
ERROR - 2011-09-05 10:23:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 10:23:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 10:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 10:23:04 --> Model Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Model Class Initialized
DEBUG - 2011-09-05 10:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 10:23:04 --> Database Driver Class Initialized
DEBUG - 2011-09-05 10:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 10:23:04 --> Helper loaded: url_helper
DEBUG - 2011-09-05 10:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 10:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 10:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 10:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 10:23:04 --> Final output sent to browser
DEBUG - 2011-09-05 10:23:04 --> Total execution time: 0.1605
DEBUG - 2011-09-05 10:23:05 --> Config Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:23:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:23:05 --> URI Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Router Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Output Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Input Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 10:23:05 --> Language Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Loader Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Controller Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Model Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Model Class Initialized
DEBUG - 2011-09-05 10:23:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 10:23:05 --> Database Driver Class Initialized
DEBUG - 2011-09-05 10:23:06 --> Final output sent to browser
DEBUG - 2011-09-05 10:23:06 --> Total execution time: 1.3398
DEBUG - 2011-09-05 10:23:07 --> Config Class Initialized
DEBUG - 2011-09-05 10:23:07 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:23:07 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:23:07 --> URI Class Initialized
DEBUG - 2011-09-05 10:23:07 --> Router Class Initialized
ERROR - 2011-09-05 10:23:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 10:23:07 --> Config Class Initialized
DEBUG - 2011-09-05 10:23:07 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:23:07 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:23:07 --> URI Class Initialized
DEBUG - 2011-09-05 10:23:07 --> Router Class Initialized
ERROR - 2011-09-05 10:23:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 10:23:08 --> Config Class Initialized
DEBUG - 2011-09-05 10:23:08 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:23:08 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:23:08 --> URI Class Initialized
DEBUG - 2011-09-05 10:23:08 --> Router Class Initialized
ERROR - 2011-09-05 10:23:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 10:23:18 --> Config Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:23:18 --> URI Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Router Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Output Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Input Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 10:23:18 --> Language Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Loader Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Controller Class Initialized
ERROR - 2011-09-05 10:23:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 10:23:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 10:23:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 10:23:18 --> Model Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Model Class Initialized
DEBUG - 2011-09-05 10:23:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 10:23:18 --> Database Driver Class Initialized
DEBUG - 2011-09-05 10:23:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 10:23:18 --> Helper loaded: url_helper
DEBUG - 2011-09-05 10:23:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 10:23:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 10:23:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 10:23:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 10:23:18 --> Final output sent to browser
DEBUG - 2011-09-05 10:23:18 --> Total execution time: 0.0314
DEBUG - 2011-09-05 10:23:19 --> Config Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:23:19 --> URI Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Router Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Output Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Input Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 10:23:19 --> Language Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Loader Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Controller Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Model Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Model Class Initialized
DEBUG - 2011-09-05 10:23:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 10:23:19 --> Database Driver Class Initialized
DEBUG - 2011-09-05 10:23:20 --> Final output sent to browser
DEBUG - 2011-09-05 10:23:20 --> Total execution time: 0.6415
DEBUG - 2011-09-05 10:48:02 --> Config Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:48:02 --> URI Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Router Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Output Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Input Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 10:48:02 --> Language Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Loader Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Controller Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 10:48:02 --> Database Driver Class Initialized
DEBUG - 2011-09-05 10:48:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 10:48:03 --> Helper loaded: url_helper
DEBUG - 2011-09-05 10:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 10:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 10:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 10:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 10:48:03 --> Final output sent to browser
DEBUG - 2011-09-05 10:48:03 --> Total execution time: 0.8179
DEBUG - 2011-09-05 10:48:05 --> Config Class Initialized
DEBUG - 2011-09-05 10:48:05 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:48:05 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:48:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:48:05 --> URI Class Initialized
DEBUG - 2011-09-05 10:48:05 --> Router Class Initialized
ERROR - 2011-09-05 10:48:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 10:48:30 --> Config Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:48:30 --> URI Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Router Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Output Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Input Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 10:48:30 --> Language Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Loader Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Controller Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 10:48:30 --> Database Driver Class Initialized
DEBUG - 2011-09-05 10:48:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 10:48:31 --> Helper loaded: url_helper
DEBUG - 2011-09-05 10:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 10:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 10:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 10:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 10:48:31 --> Final output sent to browser
DEBUG - 2011-09-05 10:48:31 --> Total execution time: 0.8776
DEBUG - 2011-09-05 10:48:33 --> Config Class Initialized
DEBUG - 2011-09-05 10:48:33 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:48:33 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:48:33 --> URI Class Initialized
DEBUG - 2011-09-05 10:48:33 --> Router Class Initialized
ERROR - 2011-09-05 10:48:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 10:48:34 --> Config Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Hooks Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Utf8 Class Initialized
DEBUG - 2011-09-05 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 10:48:34 --> URI Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Router Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Output Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Input Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 10:48:34 --> Language Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Loader Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Controller Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Model Class Initialized
DEBUG - 2011-09-05 10:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 10:48:34 --> Database Driver Class Initialized
DEBUG - 2011-09-05 10:48:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 10:48:34 --> Helper loaded: url_helper
DEBUG - 2011-09-05 10:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 10:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 10:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 10:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 10:48:34 --> Final output sent to browser
DEBUG - 2011-09-05 10:48:34 --> Total execution time: 0.0441
DEBUG - 2011-09-05 11:18:45 --> Config Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:18:45 --> URI Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Router Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Output Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Input Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:18:45 --> Language Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Loader Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Controller Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:18:45 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:18:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 11:18:45 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:18:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:18:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:18:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:18:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:18:45 --> Final output sent to browser
DEBUG - 2011-09-05 11:18:45 --> Total execution time: 0.4268
DEBUG - 2011-09-05 11:18:47 --> Config Class Initialized
DEBUG - 2011-09-05 11:18:47 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:18:47 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:18:47 --> URI Class Initialized
DEBUG - 2011-09-05 11:18:47 --> Router Class Initialized
ERROR - 2011-09-05 11:18:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 11:18:47 --> Config Class Initialized
DEBUG - 2011-09-05 11:18:47 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:18:47 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:18:47 --> URI Class Initialized
DEBUG - 2011-09-05 11:18:47 --> Router Class Initialized
ERROR - 2011-09-05 11:18:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 11:18:53 --> Config Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:18:53 --> URI Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Router Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Output Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Input Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:18:53 --> Language Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Loader Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Controller Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:18:53 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:18:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 11:18:53 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:18:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:18:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:18:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:18:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:18:53 --> Final output sent to browser
DEBUG - 2011-09-05 11:18:53 --> Total execution time: 0.2363
DEBUG - 2011-09-05 11:18:55 --> Config Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:18:55 --> URI Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Router Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Output Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Input Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:18:55 --> Language Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Loader Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Controller Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Model Class Initialized
DEBUG - 2011-09-05 11:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:18:55 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:18:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 11:18:55 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:18:55 --> Final output sent to browser
DEBUG - 2011-09-05 11:18:55 --> Total execution time: 0.1012
DEBUG - 2011-09-05 11:19:04 --> Config Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:19:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:19:04 --> URI Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Router Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Output Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Input Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:19:04 --> Language Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Loader Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Controller Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Model Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Model Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Model Class Initialized
DEBUG - 2011-09-05 11:19:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:19:04 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:19:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 11:19:05 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:19:05 --> Final output sent to browser
DEBUG - 2011-09-05 11:19:05 --> Total execution time: 0.8201
DEBUG - 2011-09-05 11:19:07 --> Config Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:19:07 --> URI Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Router Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Output Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Input Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:19:07 --> Language Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Loader Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Controller Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Model Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Model Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Model Class Initialized
DEBUG - 2011-09-05 11:19:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:19:07 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:19:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 11:19:07 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:19:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:19:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:19:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:19:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:19:07 --> Final output sent to browser
DEBUG - 2011-09-05 11:19:07 --> Total execution time: 0.0718
DEBUG - 2011-09-05 11:20:22 --> Config Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:20:22 --> URI Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Router Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Output Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Input Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:20:22 --> Language Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Loader Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Controller Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Model Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Model Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Model Class Initialized
DEBUG - 2011-09-05 11:20:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:20:22 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:20:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 11:20:22 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:20:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:20:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:20:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:20:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:20:22 --> Final output sent to browser
DEBUG - 2011-09-05 11:20:22 --> Total execution time: 0.0650
DEBUG - 2011-09-05 11:20:31 --> Config Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:20:31 --> URI Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Router Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Output Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Input Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:20:31 --> Language Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Loader Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Controller Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Model Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Model Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Model Class Initialized
DEBUG - 2011-09-05 11:20:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:20:31 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:20:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 11:20:32 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:20:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:20:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:20:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:20:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:20:32 --> Final output sent to browser
DEBUG - 2011-09-05 11:20:32 --> Total execution time: 0.6586
DEBUG - 2011-09-05 11:22:58 --> Config Class Initialized
DEBUG - 2011-09-05 11:22:58 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:22:58 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:22:58 --> URI Class Initialized
DEBUG - 2011-09-05 11:22:58 --> Router Class Initialized
DEBUG - 2011-09-05 11:22:58 --> No URI present. Default controller set.
DEBUG - 2011-09-05 11:22:58 --> Output Class Initialized
DEBUG - 2011-09-05 11:22:58 --> Input Class Initialized
DEBUG - 2011-09-05 11:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:22:58 --> Language Class Initialized
DEBUG - 2011-09-05 11:22:58 --> Loader Class Initialized
DEBUG - 2011-09-05 11:22:58 --> Controller Class Initialized
DEBUG - 2011-09-05 11:22:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-05 11:22:58 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:22:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:22:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:22:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:22:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:22:58 --> Final output sent to browser
DEBUG - 2011-09-05 11:22:58 --> Total execution time: 0.0899
DEBUG - 2011-09-05 11:42:21 --> Config Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:42:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:42:21 --> URI Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Router Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Output Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Input Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:42:21 --> Language Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Loader Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Controller Class Initialized
ERROR - 2011-09-05 11:42:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 11:42:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 11:42:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:42:21 --> Model Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Model Class Initialized
DEBUG - 2011-09-05 11:42:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:42:21 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:42:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:42:21 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:42:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:42:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:42:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:42:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:42:21 --> Final output sent to browser
DEBUG - 2011-09-05 11:42:21 --> Total execution time: 0.0950
DEBUG - 2011-09-05 11:42:24 --> Config Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:42:24 --> URI Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Router Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Output Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Input Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:42:24 --> Language Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Loader Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Controller Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Model Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Model Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:42:24 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:42:24 --> Final output sent to browser
DEBUG - 2011-09-05 11:42:24 --> Total execution time: 0.7911
DEBUG - 2011-09-05 11:42:27 --> Config Class Initialized
DEBUG - 2011-09-05 11:42:27 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:42:27 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:42:27 --> URI Class Initialized
DEBUG - 2011-09-05 11:42:27 --> Router Class Initialized
ERROR - 2011-09-05 11:42:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 11:43:31 --> Config Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:43:31 --> URI Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Router Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Output Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Input Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:43:31 --> Language Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Loader Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Controller Class Initialized
ERROR - 2011-09-05 11:43:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 11:43:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 11:43:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:43:31 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:43:31 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:43:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:43:31 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:43:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:43:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:43:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:43:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:43:31 --> Final output sent to browser
DEBUG - 2011-09-05 11:43:31 --> Total execution time: 0.0470
DEBUG - 2011-09-05 11:43:33 --> Config Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:43:33 --> URI Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Router Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Output Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Input Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:43:33 --> Language Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Loader Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Controller Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:43:33 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:43:33 --> Final output sent to browser
DEBUG - 2011-09-05 11:43:33 --> Total execution time: 0.5238
DEBUG - 2011-09-05 11:43:42 --> Config Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:43:42 --> URI Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Router Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Output Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Input Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:43:42 --> Language Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Loader Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Controller Class Initialized
ERROR - 2011-09-05 11:43:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 11:43:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 11:43:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:43:42 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:43:42 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:43:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:43:42 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:43:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:43:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:43:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:43:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:43:42 --> Final output sent to browser
DEBUG - 2011-09-05 11:43:42 --> Total execution time: 0.0405
DEBUG - 2011-09-05 11:43:43 --> Config Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:43:43 --> URI Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Router Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Output Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Input Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:43:43 --> Language Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Loader Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Controller Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:43:43 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:43:43 --> Final output sent to browser
DEBUG - 2011-09-05 11:43:43 --> Total execution time: 0.6668
DEBUG - 2011-09-05 11:43:49 --> Config Class Initialized
DEBUG - 2011-09-05 11:43:49 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:43:49 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:43:49 --> URI Class Initialized
DEBUG - 2011-09-05 11:43:49 --> Router Class Initialized
DEBUG - 2011-09-05 11:43:50 --> Output Class Initialized
DEBUG - 2011-09-05 11:43:50 --> Input Class Initialized
DEBUG - 2011-09-05 11:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:43:50 --> Language Class Initialized
DEBUG - 2011-09-05 11:43:50 --> Loader Class Initialized
DEBUG - 2011-09-05 11:43:50 --> Controller Class Initialized
ERROR - 2011-09-05 11:43:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 11:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 11:43:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:43:50 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:50 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:43:50 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:43:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:43:50 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:43:50 --> Final output sent to browser
DEBUG - 2011-09-05 11:43:50 --> Total execution time: 0.0289
DEBUG - 2011-09-05 11:43:51 --> Config Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:43:51 --> URI Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Router Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Output Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Input Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:43:51 --> Language Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Loader Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Controller Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Model Class Initialized
DEBUG - 2011-09-05 11:43:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:43:51 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:43:52 --> Final output sent to browser
DEBUG - 2011-09-05 11:43:52 --> Total execution time: 0.5633
DEBUG - 2011-09-05 11:44:00 --> Config Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:44:00 --> URI Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Router Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Output Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Input Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:44:00 --> Language Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Loader Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Controller Class Initialized
ERROR - 2011-09-05 11:44:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 11:44:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 11:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:44:00 --> Model Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Model Class Initialized
DEBUG - 2011-09-05 11:44:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:44:00 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 11:44:00 --> Helper loaded: url_helper
DEBUG - 2011-09-05 11:44:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 11:44:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 11:44:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 11:44:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 11:44:00 --> Final output sent to browser
DEBUG - 2011-09-05 11:44:00 --> Total execution time: 0.0639
DEBUG - 2011-09-05 11:44:02 --> Config Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Hooks Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Utf8 Class Initialized
DEBUG - 2011-09-05 11:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 11:44:02 --> URI Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Router Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Output Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Input Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 11:44:02 --> Language Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Loader Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Controller Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Model Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Model Class Initialized
DEBUG - 2011-09-05 11:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 11:44:02 --> Database Driver Class Initialized
DEBUG - 2011-09-05 11:44:03 --> Final output sent to browser
DEBUG - 2011-09-05 11:44:03 --> Total execution time: 0.9654
DEBUG - 2011-09-05 13:07:52 --> Config Class Initialized
DEBUG - 2011-09-05 13:07:52 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:07:52 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:07:52 --> URI Class Initialized
DEBUG - 2011-09-05 13:07:52 --> Router Class Initialized
ERROR - 2011-09-05 13:07:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 13:09:34 --> Config Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:09:34 --> URI Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Router Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Output Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Input Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:09:34 --> Language Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Loader Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Controller Class Initialized
ERROR - 2011-09-05 13:09:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:09:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:09:34 --> Model Class Initialized
DEBUG - 2011-09-05 13:09:34 --> Model Class Initialized
DEBUG - 2011-09-05 13:09:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:09:35 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:09:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:09:35 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:09:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:09:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:09:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:09:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:09:35 --> Final output sent to browser
DEBUG - 2011-09-05 13:09:35 --> Total execution time: 0.3495
DEBUG - 2011-09-05 13:09:37 --> Config Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:09:37 --> URI Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Router Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Output Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Input Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:09:37 --> Language Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Loader Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Controller Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Model Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Model Class Initialized
DEBUG - 2011-09-05 13:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:09:37 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:09:38 --> Final output sent to browser
DEBUG - 2011-09-05 13:09:38 --> Total execution time: 1.2980
DEBUG - 2011-09-05 13:09:41 --> Config Class Initialized
DEBUG - 2011-09-05 13:09:41 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:09:41 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:09:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:09:41 --> URI Class Initialized
DEBUG - 2011-09-05 13:09:41 --> Router Class Initialized
ERROR - 2011-09-05 13:09:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:24:04 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:04 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Router Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Output Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Input Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:24:04 --> Language Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Loader Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Controller Class Initialized
ERROR - 2011-09-05 13:24:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:24:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:24:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:24:04 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:24:04 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:24:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:24:04 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:24:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:24:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:24:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:24:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:24:04 --> Final output sent to browser
DEBUG - 2011-09-05 13:24:04 --> Total execution time: 0.0323
DEBUG - 2011-09-05 13:24:06 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:06 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:06 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:06 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:06 --> Router Class Initialized
DEBUG - 2011-09-05 13:24:07 --> Output Class Initialized
DEBUG - 2011-09-05 13:24:07 --> Input Class Initialized
DEBUG - 2011-09-05 13:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:24:07 --> Language Class Initialized
DEBUG - 2011-09-05 13:24:07 --> Loader Class Initialized
DEBUG - 2011-09-05 13:24:07 --> Controller Class Initialized
DEBUG - 2011-09-05 13:24:07 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:07 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:24:07 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:24:08 --> Final output sent to browser
DEBUG - 2011-09-05 13:24:08 --> Total execution time: 1.3936
DEBUG - 2011-09-05 13:24:34 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:34 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:34 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:34 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:34 --> Router Class Initialized
ERROR - 2011-09-05 13:24:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 13:24:35 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:35 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Router Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Output Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Input Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:24:35 --> Language Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Loader Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Controller Class Initialized
ERROR - 2011-09-05 13:24:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:24:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:24:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:24:35 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:24:35 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:24:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:24:35 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:24:35 --> Final output sent to browser
DEBUG - 2011-09-05 13:24:35 --> Total execution time: 0.0504
DEBUG - 2011-09-05 13:24:38 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:38 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Router Class Initialized
ERROR - 2011-09-05 13:24:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 13:24:38 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:38 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Router Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Output Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Input Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:24:38 --> Language Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Loader Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Controller Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:24:38 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:24:38 --> Final output sent to browser
DEBUG - 2011-09-05 13:24:38 --> Total execution time: 0.3219
DEBUG - 2011-09-05 13:24:44 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:44 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Router Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Output Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Input Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:24:44 --> Language Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Loader Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Controller Class Initialized
ERROR - 2011-09-05 13:24:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:24:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:24:44 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:24:44 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:24:44 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:24:44 --> Final output sent to browser
DEBUG - 2011-09-05 13:24:44 --> Total execution time: 0.0281
DEBUG - 2011-09-05 13:24:45 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:45 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Router Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Output Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Input Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:24:45 --> Language Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Loader Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Controller Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Model Class Initialized
DEBUG - 2011-09-05 13:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:24:45 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:24:46 --> Final output sent to browser
DEBUG - 2011-09-05 13:24:46 --> Total execution time: 0.5042
DEBUG - 2011-09-05 13:24:53 --> Config Class Initialized
DEBUG - 2011-09-05 13:24:53 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:24:53 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:24:53 --> URI Class Initialized
DEBUG - 2011-09-05 13:24:53 --> Router Class Initialized
ERROR - 2011-09-05 13:24:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:25:22 --> Config Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:25:22 --> URI Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Router Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Output Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Input Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:25:22 --> Language Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Loader Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Controller Class Initialized
ERROR - 2011-09-05 13:25:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:25:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:25:22 --> Model Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Model Class Initialized
DEBUG - 2011-09-05 13:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:25:22 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:25:22 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:25:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:25:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:25:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:25:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:25:22 --> Final output sent to browser
DEBUG - 2011-09-05 13:25:22 --> Total execution time: 0.0345
DEBUG - 2011-09-05 13:25:23 --> Config Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:25:23 --> URI Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Router Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Output Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Input Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:25:23 --> Language Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Loader Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Controller Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Model Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Model Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:25:23 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:25:23 --> Final output sent to browser
DEBUG - 2011-09-05 13:25:23 --> Total execution time: 0.5023
DEBUG - 2011-09-05 13:29:52 --> Config Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:29:52 --> URI Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Router Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Output Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Input Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:29:52 --> Language Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Loader Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Controller Class Initialized
ERROR - 2011-09-05 13:29:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:29:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:29:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:29:52 --> Model Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Model Class Initialized
DEBUG - 2011-09-05 13:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:29:52 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:29:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:29:52 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:29:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:29:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:29:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:29:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:29:52 --> Final output sent to browser
DEBUG - 2011-09-05 13:29:52 --> Total execution time: 0.0359
DEBUG - 2011-09-05 13:29:53 --> Config Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:29:53 --> URI Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Router Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Output Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Input Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:29:53 --> Language Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Loader Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Controller Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Model Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Model Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:29:53 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:29:53 --> Final output sent to browser
DEBUG - 2011-09-05 13:29:53 --> Total execution time: 0.4658
DEBUG - 2011-09-05 13:29:54 --> Config Class Initialized
DEBUG - 2011-09-05 13:29:54 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:29:54 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:29:54 --> URI Class Initialized
DEBUG - 2011-09-05 13:29:54 --> Router Class Initialized
ERROR - 2011-09-05 13:29:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:30:11 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:11 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Router Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Output Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Input Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:30:11 --> Language Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Loader Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Controller Class Initialized
ERROR - 2011-09-05 13:30:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:30:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:30:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:30:11 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:30:11 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:30:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:30:11 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:30:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:30:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:30:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:30:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:30:11 --> Final output sent to browser
DEBUG - 2011-09-05 13:30:11 --> Total execution time: 0.0297
DEBUG - 2011-09-05 13:30:12 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:12 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Router Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Output Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Input Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:30:12 --> Language Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Loader Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Controller Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:30:12 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:30:12 --> Final output sent to browser
DEBUG - 2011-09-05 13:30:12 --> Total execution time: 0.5235
DEBUG - 2011-09-05 13:30:13 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:13 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Router Class Initialized
ERROR - 2011-09-05 13:30:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:30:13 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:13 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Router Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Output Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Input Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:30:13 --> Language Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Loader Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Controller Class Initialized
ERROR - 2011-09-05 13:30:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:30:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:30:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:30:13 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:30:13 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:30:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:30:13 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:30:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:30:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:30:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:30:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:30:13 --> Final output sent to browser
DEBUG - 2011-09-05 13:30:13 --> Total execution time: 0.0273
DEBUG - 2011-09-05 13:30:26 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:26 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Router Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Output Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Input Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:30:26 --> Language Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Loader Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Controller Class Initialized
ERROR - 2011-09-05 13:30:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:30:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:30:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:30:26 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:30:26 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:30:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:30:26 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:30:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:30:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:30:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:30:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:30:26 --> Final output sent to browser
DEBUG - 2011-09-05 13:30:26 --> Total execution time: 0.0406
DEBUG - 2011-09-05 13:30:27 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:27 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Router Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Output Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Input Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:30:27 --> Language Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Loader Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Controller Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:30:27 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:30:27 --> Final output sent to browser
DEBUG - 2011-09-05 13:30:27 --> Total execution time: 0.5144
DEBUG - 2011-09-05 13:30:28 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:28 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:28 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:28 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:28 --> Router Class Initialized
ERROR - 2011-09-05 13:30:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:30:37 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:37 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:37 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:37 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Router Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Output Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Input Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:30:38 --> Language Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Loader Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Controller Class Initialized
ERROR - 2011-09-05 13:30:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:30:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:30:38 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:30:38 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:30:38 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:30:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:30:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:30:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:30:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:30:38 --> Final output sent to browser
DEBUG - 2011-09-05 13:30:38 --> Total execution time: 0.0302
DEBUG - 2011-09-05 13:30:38 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:38 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Router Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Output Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Input Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:30:38 --> Language Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Loader Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Controller Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Model Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:30:38 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:30:38 --> Final output sent to browser
DEBUG - 2011-09-05 13:30:38 --> Total execution time: 0.4337
DEBUG - 2011-09-05 13:30:39 --> Config Class Initialized
DEBUG - 2011-09-05 13:30:39 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:30:39 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:30:39 --> URI Class Initialized
DEBUG - 2011-09-05 13:30:39 --> Router Class Initialized
ERROR - 2011-09-05 13:30:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:31:02 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:02 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:02 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Controller Class Initialized
ERROR - 2011-09-05 13:31:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:31:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:31:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:02 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:02 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:02 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:31:02 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:02 --> Total execution time: 0.0596
DEBUG - 2011-09-05 13:31:02 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:02 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:02 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Controller Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:02 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:03 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:03 --> Total execution time: 0.6003
DEBUG - 2011-09-05 13:31:04 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:04 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:04 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:04 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:04 --> Router Class Initialized
ERROR - 2011-09-05 13:31:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:31:12 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:12 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:12 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Controller Class Initialized
ERROR - 2011-09-05 13:31:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:31:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:31:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:12 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:12 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:12 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:31:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:31:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:31:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:31:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:31:12 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:12 --> Total execution time: 0.0278
DEBUG - 2011-09-05 13:31:13 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:13 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:13 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Controller Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:13 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:13 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:13 --> Total execution time: 0.5040
DEBUG - 2011-09-05 13:31:14 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:14 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:14 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:14 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:14 --> Router Class Initialized
ERROR - 2011-09-05 13:31:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:31:26 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:26 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:26 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Controller Class Initialized
ERROR - 2011-09-05 13:31:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:31:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:31:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:26 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:27 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:27 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:31:27 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:27 --> Total execution time: 0.2795
DEBUG - 2011-09-05 13:31:27 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:27 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:27 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:27 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:27 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:27 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:27 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:28 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:28 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:28 --> Controller Class Initialized
DEBUG - 2011-09-05 13:31:28 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:28 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:28 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:28 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:28 --> Total execution time: 0.7887
DEBUG - 2011-09-05 13:31:29 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:29 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:29 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:29 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:29 --> Router Class Initialized
ERROR - 2011-09-05 13:31:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:31:49 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:49 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:49 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Controller Class Initialized
ERROR - 2011-09-05 13:31:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:31:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:31:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:49 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:49 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:49 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:31:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:31:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:31:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:31:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:31:49 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:49 --> Total execution time: 0.0297
DEBUG - 2011-09-05 13:31:50 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:50 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:50 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Controller Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:50 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:50 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:50 --> Total execution time: 0.3830
DEBUG - 2011-09-05 13:31:51 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:51 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:51 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:51 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:51 --> Router Class Initialized
ERROR - 2011-09-05 13:31:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 13:31:56 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:56 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:56 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Controller Class Initialized
ERROR - 2011-09-05 13:31:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 13:31:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 13:31:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:56 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:56 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 13:31:56 --> Helper loaded: url_helper
DEBUG - 2011-09-05 13:31:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 13:31:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 13:31:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 13:31:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 13:31:56 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:56 --> Total execution time: 0.0284
DEBUG - 2011-09-05 13:31:57 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:57 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Router Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Output Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Input Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 13:31:57 --> Language Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Loader Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Controller Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Model Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 13:31:57 --> Database Driver Class Initialized
DEBUG - 2011-09-05 13:31:57 --> Final output sent to browser
DEBUG - 2011-09-05 13:31:57 --> Total execution time: 0.5650
DEBUG - 2011-09-05 13:31:58 --> Config Class Initialized
DEBUG - 2011-09-05 13:31:58 --> Hooks Class Initialized
DEBUG - 2011-09-05 13:31:58 --> Utf8 Class Initialized
DEBUG - 2011-09-05 13:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 13:31:58 --> URI Class Initialized
DEBUG - 2011-09-05 13:31:58 --> Router Class Initialized
ERROR - 2011-09-05 13:31:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 14:48:06 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:06 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Router Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Output Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Input Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:48:06 --> Language Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Loader Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Controller Class Initialized
ERROR - 2011-09-05 14:48:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:48:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:48:06 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:48:06 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:48:06 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:48:06 --> Final output sent to browser
DEBUG - 2011-09-05 14:48:06 --> Total execution time: 0.0661
DEBUG - 2011-09-05 14:48:07 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:07 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Router Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Output Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Input Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:48:07 --> Language Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Loader Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Controller Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:48:07 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:48:07 --> Final output sent to browser
DEBUG - 2011-09-05 14:48:07 --> Total execution time: 0.6435
DEBUG - 2011-09-05 14:48:08 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:08 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Router Class Initialized
ERROR - 2011-09-05 14:48:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 14:48:08 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:08 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Router Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Output Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Input Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:48:08 --> Language Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Loader Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Controller Class Initialized
ERROR - 2011-09-05 14:48:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:48:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:48:08 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:48:08 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:48:08 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:48:08 --> Final output sent to browser
DEBUG - 2011-09-05 14:48:08 --> Total execution time: 0.0271
DEBUG - 2011-09-05 14:48:09 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:09 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Router Class Initialized
ERROR - 2011-09-05 14:48:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 14:48:09 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:09 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Router Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Output Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Input Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:48:09 --> Language Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Loader Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Controller Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:48:09 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:09 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:09 --> Router Class Initialized
ERROR - 2011-09-05 14:48:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 14:48:10 --> Final output sent to browser
DEBUG - 2011-09-05 14:48:10 --> Total execution time: 0.5434
DEBUG - 2011-09-05 14:48:26 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:26 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Router Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Output Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Input Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:48:26 --> Language Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Loader Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Controller Class Initialized
ERROR - 2011-09-05 14:48:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:48:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:48:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:48:26 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:48:26 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:48:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:48:26 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:48:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:48:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:48:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:48:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:48:26 --> Final output sent to browser
DEBUG - 2011-09-05 14:48:26 --> Total execution time: 0.0425
DEBUG - 2011-09-05 14:48:27 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:27 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Router Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Output Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Input Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:48:27 --> Language Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Loader Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Controller Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:48:27 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:48:28 --> Final output sent to browser
DEBUG - 2011-09-05 14:48:28 --> Total execution time: 0.8493
DEBUG - 2011-09-05 14:48:38 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:38 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Router Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Output Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Input Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:48:38 --> Language Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Loader Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Controller Class Initialized
ERROR - 2011-09-05 14:48:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:48:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:48:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:48:38 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:48:38 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:48:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:48:38 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:48:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:48:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:48:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:48:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:48:38 --> Final output sent to browser
DEBUG - 2011-09-05 14:48:38 --> Total execution time: 0.0290
DEBUG - 2011-09-05 14:48:39 --> Config Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:48:39 --> URI Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Router Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Output Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Input Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:48:39 --> Language Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Loader Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Controller Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Model Class Initialized
DEBUG - 2011-09-05 14:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:48:39 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:48:40 --> Final output sent to browser
DEBUG - 2011-09-05 14:48:40 --> Total execution time: 0.6787
DEBUG - 2011-09-05 14:49:25 --> Config Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:49:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:49:25 --> URI Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Router Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Output Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Input Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:49:25 --> Language Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Loader Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Controller Class Initialized
ERROR - 2011-09-05 14:49:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:49:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:49:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:49:25 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:49:25 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:49:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:49:25 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:49:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:49:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:49:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:49:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:49:25 --> Final output sent to browser
DEBUG - 2011-09-05 14:49:25 --> Total execution time: 0.0300
DEBUG - 2011-09-05 14:49:26 --> Config Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:49:26 --> URI Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Router Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Output Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Input Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:49:26 --> Language Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Loader Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Controller Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:49:26 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:49:26 --> Final output sent to browser
DEBUG - 2011-09-05 14:49:26 --> Total execution time: 0.7247
DEBUG - 2011-09-05 14:49:39 --> Config Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:49:39 --> URI Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Router Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Output Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Input Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:49:39 --> Language Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Loader Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Controller Class Initialized
ERROR - 2011-09-05 14:49:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:49:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:49:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:49:39 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:49:39 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:49:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:49:39 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:49:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:49:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:49:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:49:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:49:39 --> Final output sent to browser
DEBUG - 2011-09-05 14:49:39 --> Total execution time: 0.1120
DEBUG - 2011-09-05 14:49:40 --> Config Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:49:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:49:40 --> URI Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Router Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Output Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Input Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:49:40 --> Language Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Loader Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Controller Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:49:40 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:49:41 --> Final output sent to browser
DEBUG - 2011-09-05 14:49:41 --> Total execution time: 0.9876
DEBUG - 2011-09-05 14:49:49 --> Config Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:49:49 --> URI Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Router Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Output Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Input Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:49:49 --> Language Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Loader Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Controller Class Initialized
ERROR - 2011-09-05 14:49:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:49:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:49:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:49:49 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:49:49 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:49:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:49:49 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:49:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:49:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:49:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:49:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:49:49 --> Final output sent to browser
DEBUG - 2011-09-05 14:49:49 --> Total execution time: 0.0300
DEBUG - 2011-09-05 14:49:50 --> Config Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:49:50 --> URI Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Router Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Output Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Input Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:49:50 --> Language Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Loader Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Controller Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Model Class Initialized
DEBUG - 2011-09-05 14:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:49:50 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:49:51 --> Final output sent to browser
DEBUG - 2011-09-05 14:49:51 --> Total execution time: 0.5469
DEBUG - 2011-09-05 14:50:22 --> Config Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:50:22 --> URI Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Router Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Output Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Input Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:50:22 --> Language Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Loader Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Controller Class Initialized
ERROR - 2011-09-05 14:50:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:50:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:50:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:50:22 --> Model Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Model Class Initialized
DEBUG - 2011-09-05 14:50:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:50:22 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:50:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:50:22 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:50:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:50:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:50:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:50:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:50:22 --> Final output sent to browser
DEBUG - 2011-09-05 14:50:22 --> Total execution time: 0.0611
DEBUG - 2011-09-05 14:50:23 --> Config Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:50:23 --> URI Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Router Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Output Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Input Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:50:23 --> Language Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Loader Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Controller Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Model Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Model Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:50:23 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:50:23 --> Final output sent to browser
DEBUG - 2011-09-05 14:50:23 --> Total execution time: 0.5680
DEBUG - 2011-09-05 14:50:50 --> Config Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:50:50 --> URI Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Router Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Output Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Input Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:50:50 --> Language Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Loader Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Controller Class Initialized
ERROR - 2011-09-05 14:50:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:50:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:50:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:50:50 --> Model Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Model Class Initialized
DEBUG - 2011-09-05 14:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:50:50 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:50:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:50:50 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:50:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:50:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:50:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:50:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:50:50 --> Final output sent to browser
DEBUG - 2011-09-05 14:50:50 --> Total execution time: 0.0302
DEBUG - 2011-09-05 14:50:51 --> Config Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:50:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:50:51 --> URI Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Router Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Output Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Input Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:50:51 --> Language Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Loader Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Controller Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Model Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Model Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:50:51 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:50:51 --> Final output sent to browser
DEBUG - 2011-09-05 14:50:51 --> Total execution time: 0.5381
DEBUG - 2011-09-05 14:51:16 --> Config Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:51:16 --> URI Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Router Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Output Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Input Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:51:16 --> Language Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Loader Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Controller Class Initialized
ERROR - 2011-09-05 14:51:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 14:51:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 14:51:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:51:16 --> Model Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Model Class Initialized
DEBUG - 2011-09-05 14:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:51:16 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:51:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 14:51:16 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:51:16 --> Final output sent to browser
DEBUG - 2011-09-05 14:51:16 --> Total execution time: 0.0643
DEBUG - 2011-09-05 14:51:17 --> Config Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:51:17 --> URI Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Router Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Output Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Input Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:51:17 --> Language Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Loader Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Controller Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Model Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Model Class Initialized
DEBUG - 2011-09-05 14:51:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:51:18 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:51:18 --> Final output sent to browser
DEBUG - 2011-09-05 14:51:18 --> Total execution time: 0.5051
DEBUG - 2011-09-05 14:52:21 --> Config Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:52:21 --> URI Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Router Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Output Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Input Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:52:21 --> Language Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Loader Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Controller Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:52:21 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:52:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 14:52:21 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:52:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:52:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:52:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:52:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:52:21 --> Final output sent to browser
DEBUG - 2011-09-05 14:52:21 --> Total execution time: 0.3542
DEBUG - 2011-09-05 14:52:54 --> Config Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:52:54 --> URI Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Router Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Output Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Input Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:52:54 --> Language Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Loader Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Controller Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:52:54 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:52:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 14:52:55 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:52:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:52:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:52:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:52:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:52:55 --> Final output sent to browser
DEBUG - 2011-09-05 14:52:55 --> Total execution time: 0.8448
DEBUG - 2011-09-05 14:52:58 --> Config Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:52:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:52:58 --> URI Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Router Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Output Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Input Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:52:58 --> Language Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Loader Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Controller Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Model Class Initialized
DEBUG - 2011-09-05 14:52:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:52:58 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:52:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 14:52:58 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:52:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:52:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:52:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:52:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:52:58 --> Final output sent to browser
DEBUG - 2011-09-05 14:52:58 --> Total execution time: 0.0463
DEBUG - 2011-09-05 14:53:07 --> Config Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:53:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:53:07 --> URI Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Router Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Output Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Input Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:53:07 --> Language Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Loader Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Controller Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Model Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Model Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Model Class Initialized
DEBUG - 2011-09-05 14:53:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:53:07 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:53:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 14:53:09 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:53:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:53:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:53:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:53:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:53:09 --> Final output sent to browser
DEBUG - 2011-09-05 14:53:09 --> Total execution time: 1.5795
DEBUG - 2011-09-05 14:53:12 --> Config Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Hooks Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Utf8 Class Initialized
DEBUG - 2011-09-05 14:53:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 14:53:12 --> URI Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Router Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Output Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Input Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 14:53:12 --> Language Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Loader Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Controller Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Model Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Model Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Model Class Initialized
DEBUG - 2011-09-05 14:53:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 14:53:12 --> Database Driver Class Initialized
DEBUG - 2011-09-05 14:53:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 14:53:12 --> Helper loaded: url_helper
DEBUG - 2011-09-05 14:53:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 14:53:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 14:53:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 14:53:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 14:53:12 --> Final output sent to browser
DEBUG - 2011-09-05 14:53:12 --> Total execution time: 0.0482
DEBUG - 2011-09-05 15:16:52 --> Config Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:16:52 --> URI Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Router Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Output Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Input Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:16:52 --> Language Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Loader Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Controller Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Model Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Model Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Model Class Initialized
DEBUG - 2011-09-05 15:16:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:16:52 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:16:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 15:16:53 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:16:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:16:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:16:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:16:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:16:53 --> Final output sent to browser
DEBUG - 2011-09-05 15:16:53 --> Total execution time: 0.3053
DEBUG - 2011-09-05 15:16:54 --> Config Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:16:54 --> URI Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Router Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Output Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Input Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:16:54 --> Language Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Loader Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Controller Class Initialized
ERROR - 2011-09-05 15:16:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 15:16:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 15:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:16:54 --> Model Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Model Class Initialized
DEBUG - 2011-09-05 15:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:16:54 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:16:54 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:16:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:16:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:16:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:16:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:16:54 --> Final output sent to browser
DEBUG - 2011-09-05 15:16:54 --> Total execution time: 0.0757
DEBUG - 2011-09-05 15:31:26 --> Config Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:31:26 --> URI Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Router Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Output Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Input Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:31:26 --> Language Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Loader Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Controller Class Initialized
ERROR - 2011-09-05 15:31:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 15:31:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 15:31:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:31:26 --> Model Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Model Class Initialized
DEBUG - 2011-09-05 15:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:31:26 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:31:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:31:26 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:31:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:31:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:31:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:31:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:31:26 --> Final output sent to browser
DEBUG - 2011-09-05 15:31:26 --> Total execution time: 0.0897
DEBUG - 2011-09-05 15:31:28 --> Config Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:31:28 --> URI Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Router Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Output Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Input Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:31:28 --> Language Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Loader Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Controller Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Model Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Model Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:31:28 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:31:28 --> Final output sent to browser
DEBUG - 2011-09-05 15:31:28 --> Total execution time: 0.5915
DEBUG - 2011-09-05 15:31:30 --> Config Class Initialized
DEBUG - 2011-09-05 15:31:30 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:31:30 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:31:30 --> URI Class Initialized
DEBUG - 2011-09-05 15:31:30 --> Router Class Initialized
ERROR - 2011-09-05 15:31:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 15:32:27 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:27 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Router Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Output Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Input Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:32:27 --> Language Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Loader Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Controller Class Initialized
ERROR - 2011-09-05 15:32:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 15:32:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 15:32:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:32:27 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:32:27 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:32:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:32:27 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:32:27 --> Final output sent to browser
DEBUG - 2011-09-05 15:32:27 --> Total execution time: 0.0295
DEBUG - 2011-09-05 15:32:28 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:28 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Router Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Output Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Input Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:32:28 --> Language Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Loader Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Controller Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:32:28 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:32:28 --> Final output sent to browser
DEBUG - 2011-09-05 15:32:28 --> Total execution time: 0.5283
DEBUG - 2011-09-05 15:32:29 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:29 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:29 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:29 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:29 --> Router Class Initialized
ERROR - 2011-09-05 15:32:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 15:32:44 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:44 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Router Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Output Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Input Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:32:44 --> Language Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Loader Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Controller Class Initialized
ERROR - 2011-09-05 15:32:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 15:32:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 15:32:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:32:44 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:32:45 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:32:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:32:45 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:32:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:32:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:32:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:32:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:32:45 --> Final output sent to browser
DEBUG - 2011-09-05 15:32:45 --> Total execution time: 0.0324
DEBUG - 2011-09-05 15:32:45 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:45 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Router Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Output Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Input Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:32:45 --> Language Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Loader Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Controller Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:32:45 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:32:46 --> Final output sent to browser
DEBUG - 2011-09-05 15:32:46 --> Total execution time: 0.6163
DEBUG - 2011-09-05 15:32:47 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:47 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:47 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:47 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:47 --> Router Class Initialized
ERROR - 2011-09-05 15:32:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 15:32:54 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:54 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Router Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Output Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Input Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:32:54 --> Language Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Loader Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Controller Class Initialized
ERROR - 2011-09-05 15:32:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 15:32:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 15:32:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:32:54 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:32:54 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:32:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:32:54 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:32:54 --> Final output sent to browser
DEBUG - 2011-09-05 15:32:54 --> Total execution time: 0.0294
DEBUG - 2011-09-05 15:32:55 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:55 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Router Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Output Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Input Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:32:55 --> Language Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Loader Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Controller Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Model Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:32:55 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:32:55 --> Final output sent to browser
DEBUG - 2011-09-05 15:32:55 --> Total execution time: 0.7413
DEBUG - 2011-09-05 15:32:56 --> Config Class Initialized
DEBUG - 2011-09-05 15:32:56 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:32:56 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:32:56 --> URI Class Initialized
DEBUG - 2011-09-05 15:32:56 --> Router Class Initialized
ERROR - 2011-09-05 15:32:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 15:33:03 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:03 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Router Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Output Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Input Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:33:03 --> Language Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Loader Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Controller Class Initialized
ERROR - 2011-09-05 15:33:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 15:33:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 15:33:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:33:03 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:33:03 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:33:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:33:03 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:33:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:33:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:33:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:33:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:33:03 --> Final output sent to browser
DEBUG - 2011-09-05 15:33:03 --> Total execution time: 0.0336
DEBUG - 2011-09-05 15:33:04 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:04 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Router Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Output Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Input Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:33:04 --> Language Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Loader Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Controller Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:33:04 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:33:04 --> Final output sent to browser
DEBUG - 2011-09-05 15:33:04 --> Total execution time: 0.7007
DEBUG - 2011-09-05 15:33:05 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:05 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:05 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:05 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:05 --> Router Class Initialized
ERROR - 2011-09-05 15:33:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 15:33:12 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:12 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Router Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Output Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Input Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:33:12 --> Language Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Loader Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Controller Class Initialized
ERROR - 2011-09-05 15:33:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 15:33:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 15:33:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:33:12 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:33:12 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:33:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:33:12 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:33:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:33:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:33:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:33:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:33:12 --> Final output sent to browser
DEBUG - 2011-09-05 15:33:12 --> Total execution time: 0.1170
DEBUG - 2011-09-05 15:33:13 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:13 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Router Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Output Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Input Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:33:13 --> Language Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Loader Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Controller Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:33:13 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:33:14 --> Final output sent to browser
DEBUG - 2011-09-05 15:33:14 --> Total execution time: 0.7872
DEBUG - 2011-09-05 15:33:15 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:15 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:15 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:15 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:15 --> Router Class Initialized
ERROR - 2011-09-05 15:33:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 15:33:20 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:20 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Router Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Output Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Input Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:33:20 --> Language Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Loader Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Controller Class Initialized
ERROR - 2011-09-05 15:33:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 15:33:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 15:33:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:33:20 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:33:20 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:33:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 15:33:20 --> Helper loaded: url_helper
DEBUG - 2011-09-05 15:33:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 15:33:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 15:33:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 15:33:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 15:33:20 --> Final output sent to browser
DEBUG - 2011-09-05 15:33:20 --> Total execution time: 0.0466
DEBUG - 2011-09-05 15:33:21 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:21 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Router Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Output Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Input Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 15:33:21 --> Language Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Loader Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Controller Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Model Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 15:33:21 --> Database Driver Class Initialized
DEBUG - 2011-09-05 15:33:21 --> Final output sent to browser
DEBUG - 2011-09-05 15:33:21 --> Total execution time: 0.6070
DEBUG - 2011-09-05 15:33:22 --> Config Class Initialized
DEBUG - 2011-09-05 15:33:22 --> Hooks Class Initialized
DEBUG - 2011-09-05 15:33:22 --> Utf8 Class Initialized
DEBUG - 2011-09-05 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 15:33:22 --> URI Class Initialized
DEBUG - 2011-09-05 15:33:22 --> Router Class Initialized
ERROR - 2011-09-05 15:33:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 16:18:53 --> Config Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Hooks Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Utf8 Class Initialized
DEBUG - 2011-09-05 16:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 16:18:53 --> URI Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Router Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Output Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Input Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 16:18:53 --> Language Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Loader Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Controller Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Model Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Model Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Model Class Initialized
DEBUG - 2011-09-05 16:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 16:18:53 --> Database Driver Class Initialized
DEBUG - 2011-09-05 16:18:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 16:18:55 --> Helper loaded: url_helper
DEBUG - 2011-09-05 16:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 16:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 16:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 16:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 16:18:55 --> Final output sent to browser
DEBUG - 2011-09-05 16:18:55 --> Total execution time: 2.0640
DEBUG - 2011-09-05 17:24:43 --> Config Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Hooks Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Utf8 Class Initialized
DEBUG - 2011-09-05 17:24:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 17:24:43 --> URI Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Router Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Output Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Input Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 17:24:43 --> Language Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Loader Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Controller Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Model Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Model Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Model Class Initialized
DEBUG - 2011-09-05 17:24:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 17:24:43 --> Database Driver Class Initialized
DEBUG - 2011-09-05 17:24:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 17:24:44 --> Helper loaded: url_helper
DEBUG - 2011-09-05 17:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 17:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 17:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 17:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 17:24:44 --> Final output sent to browser
DEBUG - 2011-09-05 17:24:44 --> Total execution time: 0.3113
DEBUG - 2011-09-05 17:24:49 --> Config Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Hooks Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Utf8 Class Initialized
DEBUG - 2011-09-05 17:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 17:24:49 --> URI Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Router Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Output Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Input Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 17:24:49 --> Language Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Loader Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Controller Class Initialized
ERROR - 2011-09-05 17:24:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 17:24:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 17:24:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 17:24:49 --> Model Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Model Class Initialized
DEBUG - 2011-09-05 17:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 17:24:49 --> Database Driver Class Initialized
DEBUG - 2011-09-05 17:24:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 17:24:49 --> Helper loaded: url_helper
DEBUG - 2011-09-05 17:24:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 17:24:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 17:24:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 17:24:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 17:24:49 --> Final output sent to browser
DEBUG - 2011-09-05 17:24:49 --> Total execution time: 0.0724
DEBUG - 2011-09-05 17:24:51 --> Config Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Hooks Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Utf8 Class Initialized
DEBUG - 2011-09-05 17:24:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 17:24:51 --> URI Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Router Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Output Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Input Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 17:24:51 --> Language Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Loader Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Controller Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Model Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Model Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 17:24:51 --> Database Driver Class Initialized
DEBUG - 2011-09-05 17:24:51 --> Final output sent to browser
DEBUG - 2011-09-05 17:24:51 --> Total execution time: 0.7516
DEBUG - 2011-09-05 17:24:52 --> Config Class Initialized
DEBUG - 2011-09-05 17:24:52 --> Hooks Class Initialized
DEBUG - 2011-09-05 17:24:52 --> Utf8 Class Initialized
DEBUG - 2011-09-05 17:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 17:24:52 --> URI Class Initialized
DEBUG - 2011-09-05 17:24:52 --> Router Class Initialized
ERROR - 2011-09-05 17:24:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 17:24:56 --> Config Class Initialized
DEBUG - 2011-09-05 17:24:56 --> Hooks Class Initialized
DEBUG - 2011-09-05 17:24:56 --> Utf8 Class Initialized
DEBUG - 2011-09-05 17:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 17:24:56 --> URI Class Initialized
DEBUG - 2011-09-05 17:24:56 --> Router Class Initialized
ERROR - 2011-09-05 17:24:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 18:21:05 --> Config Class Initialized
DEBUG - 2011-09-05 18:21:05 --> Hooks Class Initialized
DEBUG - 2011-09-05 18:21:05 --> Utf8 Class Initialized
DEBUG - 2011-09-05 18:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 18:21:05 --> URI Class Initialized
DEBUG - 2011-09-05 18:21:05 --> Router Class Initialized
DEBUG - 2011-09-05 18:21:05 --> No URI present. Default controller set.
DEBUG - 2011-09-05 18:21:05 --> Output Class Initialized
DEBUG - 2011-09-05 18:21:05 --> Input Class Initialized
DEBUG - 2011-09-05 18:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 18:21:05 --> Language Class Initialized
DEBUG - 2011-09-05 18:21:05 --> Loader Class Initialized
DEBUG - 2011-09-05 18:21:05 --> Controller Class Initialized
DEBUG - 2011-09-05 18:21:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-05 18:21:05 --> Helper loaded: url_helper
DEBUG - 2011-09-05 18:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 18:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 18:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 18:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 18:21:05 --> Final output sent to browser
DEBUG - 2011-09-05 18:21:05 --> Total execution time: 0.1247
DEBUG - 2011-09-05 18:36:01 --> Config Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Hooks Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Utf8 Class Initialized
DEBUG - 2011-09-05 18:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 18:36:01 --> URI Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Router Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Output Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Input Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 18:36:01 --> Language Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Loader Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Controller Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Model Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Model Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Model Class Initialized
DEBUG - 2011-09-05 18:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 18:36:01 --> Database Driver Class Initialized
DEBUG - 2011-09-05 18:36:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 18:36:02 --> Helper loaded: url_helper
DEBUG - 2011-09-05 18:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 18:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 18:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 18:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 18:36:02 --> Final output sent to browser
DEBUG - 2011-09-05 18:36:02 --> Total execution time: 0.8350
DEBUG - 2011-09-05 18:36:07 --> Config Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Hooks Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Utf8 Class Initialized
DEBUG - 2011-09-05 18:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 18:36:07 --> URI Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Router Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Output Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Input Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 18:36:07 --> Language Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Loader Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Controller Class Initialized
ERROR - 2011-09-05 18:36:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 18:36:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 18:36:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 18:36:07 --> Model Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Model Class Initialized
DEBUG - 2011-09-05 18:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 18:36:07 --> Database Driver Class Initialized
DEBUG - 2011-09-05 18:36:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 18:36:07 --> Helper loaded: url_helper
DEBUG - 2011-09-05 18:36:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 18:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 18:36:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 18:36:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 18:36:07 --> Final output sent to browser
DEBUG - 2011-09-05 18:36:07 --> Total execution time: 0.0280
DEBUG - 2011-09-05 18:56:24 --> Config Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Hooks Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Utf8 Class Initialized
DEBUG - 2011-09-05 18:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 18:56:24 --> URI Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Router Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Output Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Input Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 18:56:24 --> Language Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Loader Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Controller Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Model Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Model Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Model Class Initialized
DEBUG - 2011-09-05 18:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 18:56:24 --> Database Driver Class Initialized
DEBUG - 2011-09-05 18:56:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 18:56:24 --> Helper loaded: url_helper
DEBUG - 2011-09-05 18:56:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 18:56:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 18:56:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 18:56:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 18:56:24 --> Final output sent to browser
DEBUG - 2011-09-05 18:56:24 --> Total execution time: 0.0460
DEBUG - 2011-09-05 18:56:26 --> Config Class Initialized
DEBUG - 2011-09-05 18:56:26 --> Hooks Class Initialized
DEBUG - 2011-09-05 18:56:26 --> Utf8 Class Initialized
DEBUG - 2011-09-05 18:56:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 18:56:26 --> URI Class Initialized
DEBUG - 2011-09-05 18:56:26 --> Router Class Initialized
ERROR - 2011-09-05 18:56:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 18:56:26 --> Config Class Initialized
DEBUG - 2011-09-05 18:56:26 --> Hooks Class Initialized
DEBUG - 2011-09-05 18:56:26 --> Utf8 Class Initialized
DEBUG - 2011-09-05 18:56:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 18:56:26 --> URI Class Initialized
DEBUG - 2011-09-05 18:56:26 --> Router Class Initialized
ERROR - 2011-09-05 18:56:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 19:23:58 --> Config Class Initialized
DEBUG - 2011-09-05 19:23:58 --> Hooks Class Initialized
DEBUG - 2011-09-05 19:23:58 --> Utf8 Class Initialized
DEBUG - 2011-09-05 19:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 19:23:58 --> URI Class Initialized
DEBUG - 2011-09-05 19:23:58 --> Router Class Initialized
ERROR - 2011-09-05 19:23:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 19:51:25 --> Config Class Initialized
DEBUG - 2011-09-05 19:51:25 --> Hooks Class Initialized
DEBUG - 2011-09-05 19:51:25 --> Utf8 Class Initialized
DEBUG - 2011-09-05 19:51:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 19:51:25 --> URI Class Initialized
DEBUG - 2011-09-05 19:51:25 --> Router Class Initialized
DEBUG - 2011-09-05 19:51:25 --> No URI present. Default controller set.
DEBUG - 2011-09-05 19:51:25 --> Output Class Initialized
DEBUG - 2011-09-05 19:51:25 --> Input Class Initialized
DEBUG - 2011-09-05 19:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 19:51:25 --> Language Class Initialized
DEBUG - 2011-09-05 19:51:25 --> Loader Class Initialized
DEBUG - 2011-09-05 19:51:25 --> Controller Class Initialized
DEBUG - 2011-09-05 19:51:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-05 19:51:25 --> Helper loaded: url_helper
DEBUG - 2011-09-05 19:51:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 19:51:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 19:51:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 19:51:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 19:51:25 --> Final output sent to browser
DEBUG - 2011-09-05 19:51:25 --> Total execution time: 0.0334
DEBUG - 2011-09-05 20:58:46 --> Config Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Hooks Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Utf8 Class Initialized
DEBUG - 2011-09-05 20:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 20:58:46 --> URI Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Router Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Output Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Input Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 20:58:46 --> Language Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Loader Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Controller Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Model Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Model Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Model Class Initialized
DEBUG - 2011-09-05 20:58:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 20:58:46 --> Database Driver Class Initialized
DEBUG - 2011-09-05 20:58:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 20:58:47 --> Helper loaded: url_helper
DEBUG - 2011-09-05 20:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 20:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 20:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 20:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 20:58:47 --> Final output sent to browser
DEBUG - 2011-09-05 20:58:47 --> Total execution time: 0.6994
DEBUG - 2011-09-05 20:58:50 --> Config Class Initialized
DEBUG - 2011-09-05 20:58:50 --> Hooks Class Initialized
DEBUG - 2011-09-05 20:58:50 --> Utf8 Class Initialized
DEBUG - 2011-09-05 20:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 20:58:50 --> URI Class Initialized
DEBUG - 2011-09-05 20:58:50 --> Router Class Initialized
ERROR - 2011-09-05 20:58:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 20:58:52 --> Config Class Initialized
DEBUG - 2011-09-05 20:58:52 --> Hooks Class Initialized
DEBUG - 2011-09-05 20:58:52 --> Utf8 Class Initialized
DEBUG - 2011-09-05 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 20:58:52 --> URI Class Initialized
DEBUG - 2011-09-05 20:58:52 --> Router Class Initialized
ERROR - 2011-09-05 20:58:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 21:14:10 --> Config Class Initialized
DEBUG - 2011-09-05 21:14:10 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:14:10 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:14:10 --> URI Class Initialized
DEBUG - 2011-09-05 21:14:10 --> Router Class Initialized
ERROR - 2011-09-05 21:14:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 21:15:01 --> Config Class Initialized
DEBUG - 2011-09-05 21:15:01 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:15:01 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:15:01 --> URI Class Initialized
DEBUG - 2011-09-05 21:15:01 --> Router Class Initialized
DEBUG - 2011-09-05 21:15:01 --> Output Class Initialized
DEBUG - 2011-09-05 21:15:01 --> Input Class Initialized
DEBUG - 2011-09-05 21:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 21:15:01 --> Language Class Initialized
DEBUG - 2011-09-05 21:15:01 --> Loader Class Initialized
DEBUG - 2011-09-05 21:15:01 --> Controller Class Initialized
ERROR - 2011-09-05 21:15:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 21:15:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 21:15:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 21:15:02 --> Model Class Initialized
DEBUG - 2011-09-05 21:15:02 --> Model Class Initialized
DEBUG - 2011-09-05 21:15:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 21:15:02 --> Database Driver Class Initialized
DEBUG - 2011-09-05 21:15:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 21:15:02 --> Helper loaded: url_helper
DEBUG - 2011-09-05 21:15:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 21:15:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 21:15:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 21:15:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 21:15:02 --> Final output sent to browser
DEBUG - 2011-09-05 21:15:02 --> Total execution time: 0.3242
DEBUG - 2011-09-05 21:30:58 --> Config Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:30:58 --> URI Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Router Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Output Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Input Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 21:30:58 --> Language Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Loader Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Controller Class Initialized
ERROR - 2011-09-05 21:30:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 21:30:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 21:30:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 21:30:58 --> Model Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Model Class Initialized
DEBUG - 2011-09-05 21:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 21:30:58 --> Database Driver Class Initialized
DEBUG - 2011-09-05 21:30:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 21:30:58 --> Helper loaded: url_helper
DEBUG - 2011-09-05 21:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 21:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 21:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 21:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 21:30:58 --> Final output sent to browser
DEBUG - 2011-09-05 21:30:58 --> Total execution time: 0.0563
DEBUG - 2011-09-05 21:31:00 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:00 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Router Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Output Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Input Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 21:31:00 --> Language Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Loader Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Controller Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Model Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Model Class Initialized
DEBUG - 2011-09-05 21:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 21:31:00 --> Database Driver Class Initialized
DEBUG - 2011-09-05 21:31:01 --> Final output sent to browser
DEBUG - 2011-09-05 21:31:01 --> Total execution time: 0.9929
DEBUG - 2011-09-05 21:31:05 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:05 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:05 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:05 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:05 --> Router Class Initialized
ERROR - 2011-09-05 21:31:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 21:31:06 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:06 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:06 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:06 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:06 --> Router Class Initialized
ERROR - 2011-09-05 21:31:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 21:31:07 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:07 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:07 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:07 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:07 --> Router Class Initialized
ERROR - 2011-09-05 21:31:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 21:31:21 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:21 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Router Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Output Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Input Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 21:31:21 --> Language Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Loader Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Controller Class Initialized
ERROR - 2011-09-05 21:31:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 21:31:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 21:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 21:31:21 --> Model Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Model Class Initialized
DEBUG - 2011-09-05 21:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 21:31:21 --> Database Driver Class Initialized
DEBUG - 2011-09-05 21:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 21:31:21 --> Helper loaded: url_helper
DEBUG - 2011-09-05 21:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 21:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 21:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 21:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 21:31:21 --> Final output sent to browser
DEBUG - 2011-09-05 21:31:21 --> Total execution time: 0.1593
DEBUG - 2011-09-05 21:31:22 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:22 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Router Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Output Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Input Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 21:31:22 --> Language Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Loader Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Controller Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Model Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Model Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 21:31:22 --> Database Driver Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:22 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:22 --> Router Class Initialized
ERROR - 2011-09-05 21:31:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-05 21:31:23 --> Final output sent to browser
DEBUG - 2011-09-05 21:31:23 --> Total execution time: 0.4677
DEBUG - 2011-09-05 21:31:23 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:23 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Router Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Output Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Input Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 21:31:23 --> Language Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Loader Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Controller Class Initialized
ERROR - 2011-09-05 21:31:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 21:31:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 21:31:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 21:31:23 --> Model Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Model Class Initialized
DEBUG - 2011-09-05 21:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 21:31:23 --> Database Driver Class Initialized
DEBUG - 2011-09-05 21:31:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 21:31:23 --> Helper loaded: url_helper
DEBUG - 2011-09-05 21:31:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 21:31:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 21:31:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 21:31:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 21:31:23 --> Final output sent to browser
DEBUG - 2011-09-05 21:31:23 --> Total execution time: 0.0618
DEBUG - 2011-09-05 21:31:27 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:27 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:27 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:27 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:27 --> Router Class Initialized
ERROR - 2011-09-05 21:31:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 21:31:29 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:29 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:29 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:29 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:29 --> Router Class Initialized
ERROR - 2011-09-05 21:31:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 21:31:29 --> Config Class Initialized
DEBUG - 2011-09-05 21:31:29 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:31:29 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:31:29 --> URI Class Initialized
DEBUG - 2011-09-05 21:31:29 --> Router Class Initialized
ERROR - 2011-09-05 21:31:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-05 21:37:15 --> Config Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Hooks Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Utf8 Class Initialized
DEBUG - 2011-09-05 21:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 21:37:15 --> URI Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Router Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Output Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Input Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 21:37:15 --> Language Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Loader Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Controller Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Model Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Model Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Model Class Initialized
DEBUG - 2011-09-05 21:37:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 21:37:15 --> Database Driver Class Initialized
DEBUG - 2011-09-05 21:37:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 21:37:16 --> Helper loaded: url_helper
DEBUG - 2011-09-05 21:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 21:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 21:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 21:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 21:37:16 --> Final output sent to browser
DEBUG - 2011-09-05 21:37:16 --> Total execution time: 1.2441
DEBUG - 2011-09-05 22:23:39 --> Config Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Hooks Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Utf8 Class Initialized
DEBUG - 2011-09-05 22:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 22:23:39 --> URI Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Router Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Output Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Input Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 22:23:39 --> Language Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Loader Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Controller Class Initialized
ERROR - 2011-09-05 22:23:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 22:23:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 22:23:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 22:23:39 --> Model Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Model Class Initialized
DEBUG - 2011-09-05 22:23:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 22:23:39 --> Database Driver Class Initialized
DEBUG - 2011-09-05 22:23:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 22:23:39 --> Helper loaded: url_helper
DEBUG - 2011-09-05 22:23:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 22:23:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 22:23:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 22:23:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 22:23:39 --> Final output sent to browser
DEBUG - 2011-09-05 22:23:39 --> Total execution time: 0.0874
DEBUG - 2011-09-05 23:51:07 --> Config Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Hooks Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Utf8 Class Initialized
DEBUG - 2011-09-05 23:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 23:51:07 --> URI Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Router Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Output Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Input Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 23:51:07 --> Language Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Loader Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Controller Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Model Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Model Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Model Class Initialized
DEBUG - 2011-09-05 23:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 23:51:07 --> Database Driver Class Initialized
DEBUG - 2011-09-05 23:51:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-05 23:51:08 --> Helper loaded: url_helper
DEBUG - 2011-09-05 23:51:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 23:51:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 23:51:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 23:51:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 23:51:08 --> Final output sent to browser
DEBUG - 2011-09-05 23:51:08 --> Total execution time: 0.3102
DEBUG - 2011-09-05 23:51:09 --> Config Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Hooks Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Utf8 Class Initialized
DEBUG - 2011-09-05 23:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-05 23:51:09 --> URI Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Router Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Output Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Input Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-05 23:51:09 --> Language Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Loader Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Controller Class Initialized
ERROR - 2011-09-05 23:51:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-05 23:51:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-05 23:51:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 23:51:09 --> Model Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Model Class Initialized
DEBUG - 2011-09-05 23:51:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-05 23:51:09 --> Database Driver Class Initialized
DEBUG - 2011-09-05 23:51:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-05 23:51:09 --> Helper loaded: url_helper
DEBUG - 2011-09-05 23:51:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-05 23:51:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-05 23:51:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-05 23:51:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-05 23:51:09 --> Final output sent to browser
DEBUG - 2011-09-05 23:51:09 --> Total execution time: 0.0320

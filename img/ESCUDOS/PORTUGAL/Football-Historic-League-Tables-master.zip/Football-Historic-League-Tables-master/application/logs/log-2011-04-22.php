<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-22 03:24:20 --> Config Class Initialized
DEBUG - 2011-04-22 03:24:20 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:24:20 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:24:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:24:20 --> URI Class Initialized
DEBUG - 2011-04-22 03:24:20 --> Router Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Output Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Input Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:24:21 --> Language Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Loader Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Controller Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Model Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Model Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Model Class Initialized
DEBUG - 2011-04-22 03:24:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:24:21 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:24:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 03:24:23 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:24:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:24:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:24:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:24:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:24:23 --> Final output sent to browser
DEBUG - 2011-04-22 03:24:23 --> Total execution time: 2.4170
DEBUG - 2011-04-22 03:24:24 --> Config Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:24:24 --> URI Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Router Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Output Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Input Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:24:24 --> Language Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Loader Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Controller Class Initialized
ERROR - 2011-04-22 03:24:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:24:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:24:24 --> Model Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Model Class Initialized
DEBUG - 2011-04-22 03:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:24:24 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:24:24 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:24:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:24:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:24:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:24:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:24:24 --> Final output sent to browser
DEBUG - 2011-04-22 03:24:24 --> Total execution time: 0.1189
DEBUG - 2011-04-22 03:47:36 --> Config Class Initialized
DEBUG - 2011-04-22 03:47:36 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:47:36 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:47:36 --> URI Class Initialized
DEBUG - 2011-04-22 03:47:36 --> Router Class Initialized
DEBUG - 2011-04-22 03:47:36 --> Output Class Initialized
DEBUG - 2011-04-22 03:47:37 --> Input Class Initialized
DEBUG - 2011-04-22 03:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:47:37 --> Language Class Initialized
DEBUG - 2011-04-22 03:47:37 --> Loader Class Initialized
DEBUG - 2011-04-22 03:47:37 --> Controller Class Initialized
ERROR - 2011-04-22 03:47:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:47:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:47:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:47:37 --> Model Class Initialized
DEBUG - 2011-04-22 03:47:37 --> Model Class Initialized
DEBUG - 2011-04-22 03:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:47:38 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:47:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:47:38 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:47:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:47:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:47:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:47:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:47:38 --> Final output sent to browser
DEBUG - 2011-04-22 03:47:38 --> Total execution time: 2.5225
DEBUG - 2011-04-22 03:47:41 --> Config Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:47:41 --> URI Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Router Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Output Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Input Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:47:41 --> Language Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Loader Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Controller Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Model Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Model Class Initialized
DEBUG - 2011-04-22 03:47:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:47:41 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:47:42 --> Final output sent to browser
DEBUG - 2011-04-22 03:47:42 --> Total execution time: 0.7881
DEBUG - 2011-04-22 03:47:45 --> Config Class Initialized
DEBUG - 2011-04-22 03:47:45 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:47:45 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:47:45 --> URI Class Initialized
DEBUG - 2011-04-22 03:47:45 --> Router Class Initialized
ERROR - 2011-04-22 03:47:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 03:47:47 --> Config Class Initialized
DEBUG - 2011-04-22 03:47:47 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:47:47 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:47:47 --> URI Class Initialized
DEBUG - 2011-04-22 03:47:47 --> Router Class Initialized
ERROR - 2011-04-22 03:47:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 03:48:07 --> Config Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:48:07 --> URI Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Router Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Output Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Input Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:48:07 --> Language Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Loader Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Controller Class Initialized
ERROR - 2011-04-22 03:48:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:48:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:48:07 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:48:07 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:48:07 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:48:07 --> Final output sent to browser
DEBUG - 2011-04-22 03:48:07 --> Total execution time: 0.0637
DEBUG - 2011-04-22 03:48:09 --> Config Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:48:09 --> URI Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Router Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Output Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Input Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:48:09 --> Language Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Loader Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Controller Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:48:09 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:48:11 --> Final output sent to browser
DEBUG - 2011-04-22 03:48:11 --> Total execution time: 1.7953
DEBUG - 2011-04-22 03:48:50 --> Config Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:48:50 --> URI Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Router Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Output Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Input Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:48:50 --> Language Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Loader Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Controller Class Initialized
ERROR - 2011-04-22 03:48:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:48:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:48:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:48:50 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:48:50 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:48:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:48:50 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:48:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:48:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:48:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:48:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:48:50 --> Final output sent to browser
DEBUG - 2011-04-22 03:48:50 --> Total execution time: 0.0348
DEBUG - 2011-04-22 03:48:52 --> Config Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:48:52 --> URI Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Router Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Output Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Input Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:48:52 --> Language Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Loader Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Controller Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:48:52 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Config Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:48:55 --> URI Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Router Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Output Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Input Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:48:55 --> Language Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Loader Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Controller Class Initialized
ERROR - 2011-04-22 03:48:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:48:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:48:55 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Model Class Initialized
DEBUG - 2011-04-22 03:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:48:55 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:48:55 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:48:55 --> Final output sent to browser
DEBUG - 2011-04-22 03:48:55 --> Total execution time: 0.0296
DEBUG - 2011-04-22 03:48:55 --> Final output sent to browser
DEBUG - 2011-04-22 03:48:55 --> Total execution time: 2.6735
DEBUG - 2011-04-22 03:49:05 --> Config Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:49:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:49:05 --> URI Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Router Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Output Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Input Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:49:05 --> Language Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Loader Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Controller Class Initialized
ERROR - 2011-04-22 03:49:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:49:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:49:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:49:05 --> Model Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Model Class Initialized
DEBUG - 2011-04-22 03:49:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:49:05 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:49:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:49:05 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:49:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:49:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:49:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:49:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:49:05 --> Final output sent to browser
DEBUG - 2011-04-22 03:49:05 --> Total execution time: 0.0312
DEBUG - 2011-04-22 03:49:08 --> Config Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:49:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:49:08 --> URI Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Router Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Output Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Input Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:49:08 --> Language Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Loader Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Controller Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Model Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Model Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:49:08 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Config Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:49:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:49:08 --> URI Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Router Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Output Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Input Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:49:08 --> Language Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Loader Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Controller Class Initialized
ERROR - 2011-04-22 03:49:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:49:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:49:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:49:08 --> Model Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Model Class Initialized
DEBUG - 2011-04-22 03:49:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:49:08 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:49:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:49:08 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:49:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:49:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:49:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:49:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:49:08 --> Final output sent to browser
DEBUG - 2011-04-22 03:49:08 --> Total execution time: 0.0352
DEBUG - 2011-04-22 03:49:08 --> Final output sent to browser
DEBUG - 2011-04-22 03:49:08 --> Total execution time: 0.7395
DEBUG - 2011-04-22 03:55:21 --> Config Class Initialized
DEBUG - 2011-04-22 03:55:21 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:55:21 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:55:21 --> URI Class Initialized
DEBUG - 2011-04-22 03:55:21 --> Router Class Initialized
ERROR - 2011-04-22 03:55:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 03:55:21 --> Config Class Initialized
DEBUG - 2011-04-22 03:55:21 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:55:21 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:55:21 --> URI Class Initialized
DEBUG - 2011-04-22 03:55:21 --> Router Class Initialized
ERROR - 2011-04-22 03:55:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 03:55:22 --> Config Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:55:22 --> URI Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Router Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Output Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Input Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:55:22 --> Language Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Loader Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Controller Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Config Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:55:22 --> URI Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Router Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Output Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Input Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:55:22 --> Language Class Initialized
ERROR - 2011-04-22 03:55:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:55:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:55:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:55:22 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Loader Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Controller Class Initialized
DEBUG - 2011-04-22 03:55:22 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:23 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:23 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:55:23 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:55:23 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:55:23 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:55:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:55:23 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:55:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:55:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:55:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:55:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:55:30 --> Config Class Initialized
DEBUG - 2011-04-22 03:55:30 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:55:30 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:55:30 --> URI Class Initialized
DEBUG - 2011-04-22 03:55:30 --> Router Class Initialized
DEBUG - 2011-04-22 03:55:30 --> Output Class Initialized
DEBUG - 2011-04-22 03:55:30 --> Input Class Initialized
DEBUG - 2011-04-22 03:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:55:30 --> Language Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Loader Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Controller Class Initialized
ERROR - 2011-04-22 03:55:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 03:55:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 03:55:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:55:31 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:55:31 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:55:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 03:55:31 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:55:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:55:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:55:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:55:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 03:55:31 --> Final output sent to browser
DEBUG - 2011-04-22 03:55:31 --> Total execution time: 0.0437
DEBUG - 2011-04-22 03:55:31 --> Config Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Hooks Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Utf8 Class Initialized
DEBUG - 2011-04-22 03:55:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 03:55:31 --> URI Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Router Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Output Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Input Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 03:55:31 --> Language Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Loader Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Controller Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Model Class Initialized
DEBUG - 2011-04-22 03:55:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 03:55:31 --> Database Driver Class Initialized
DEBUG - 2011-04-22 03:55:33 --> Final output sent to browser
DEBUG - 2011-04-22 03:55:33 --> Total execution time: 1.8406
DEBUG - 2011-04-22 03:55:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 03:55:34 --> Helper loaded: url_helper
DEBUG - 2011-04-22 03:55:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 03:55:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 03:55:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 03:55:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:22:27 --> Config Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:22:27 --> URI Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Router Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Output Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Input Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:22:27 --> Language Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Loader Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Controller Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Model Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Model Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Model Class Initialized
DEBUG - 2011-04-22 06:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:22:27 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:22:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:22:31 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:22:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:22:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:22:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:22:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:22:31 --> Final output sent to browser
DEBUG - 2011-04-22 06:22:31 --> Total execution time: 4.7792
DEBUG - 2011-04-22 06:22:35 --> Config Class Initialized
DEBUG - 2011-04-22 06:22:35 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:22:35 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:22:35 --> URI Class Initialized
DEBUG - 2011-04-22 06:22:35 --> Router Class Initialized
ERROR - 2011-04-22 06:22:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 06:30:53 --> Config Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:30:53 --> URI Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Router Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Output Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Input Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:30:53 --> Language Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Loader Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Controller Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Model Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Model Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Model Class Initialized
DEBUG - 2011-04-22 06:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:30:53 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:30:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:30:54 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:30:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:30:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:30:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:30:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:30:54 --> Final output sent to browser
DEBUG - 2011-04-22 06:30:54 --> Total execution time: 1.3939
DEBUG - 2011-04-22 06:31:34 --> Config Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:31:34 --> URI Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Router Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Output Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Input Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:31:34 --> Language Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Loader Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Controller Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Model Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Model Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Model Class Initialized
DEBUG - 2011-04-22 06:31:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:31:34 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:31:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:31:34 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:31:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:31:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:31:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:31:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:31:34 --> Final output sent to browser
DEBUG - 2011-04-22 06:31:34 --> Total execution time: 0.2767
DEBUG - 2011-04-22 06:31:37 --> Config Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:31:37 --> URI Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Router Class Initialized
ERROR - 2011-04-22 06:31:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 06:31:37 --> Config Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:31:37 --> URI Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Router Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Output Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Input Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:31:37 --> Language Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Loader Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Controller Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Model Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Model Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Model Class Initialized
DEBUG - 2011-04-22 06:31:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:31:37 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:31:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:31:37 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:31:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:31:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:31:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:31:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:31:37 --> Final output sent to browser
DEBUG - 2011-04-22 06:31:37 --> Total execution time: 0.0593
DEBUG - 2011-04-22 06:32:00 --> Config Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:32:00 --> URI Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Router Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Output Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Input Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:32:00 --> Language Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Loader Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Controller Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:32:00 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:32:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:32:00 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:32:00 --> Final output sent to browser
DEBUG - 2011-04-22 06:32:00 --> Total execution time: 0.5067
DEBUG - 2011-04-22 06:32:06 --> Config Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:32:06 --> URI Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Router Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Output Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Input Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:32:06 --> Language Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Loader Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Controller Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:32:06 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:32:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:32:06 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:32:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:32:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:32:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:32:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:32:06 --> Final output sent to browser
DEBUG - 2011-04-22 06:32:06 --> Total execution time: 0.0463
DEBUG - 2011-04-22 06:32:21 --> Config Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:32:21 --> URI Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Router Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Output Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Input Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:32:21 --> Language Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Loader Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Controller Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:32:21 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:32:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:32:21 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:32:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:32:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:32:22 --> Final output sent to browser
DEBUG - 2011-04-22 06:32:22 --> Total execution time: 0.2863
DEBUG - 2011-04-22 06:32:25 --> Config Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:32:25 --> URI Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Router Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Output Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Input Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:32:25 --> Language Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Loader Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Controller Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Model Class Initialized
DEBUG - 2011-04-22 06:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:32:25 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:32:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:32:25 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:32:25 --> Final output sent to browser
DEBUG - 2011-04-22 06:32:25 --> Total execution time: 0.0484
DEBUG - 2011-04-22 06:33:01 --> Config Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:33:01 --> URI Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Router Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Output Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Input Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:33:01 --> Language Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Loader Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Controller Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Model Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Model Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Model Class Initialized
DEBUG - 2011-04-22 06:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:33:01 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:33:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:33:01 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:33:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:33:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:33:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:33:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:33:01 --> Final output sent to browser
DEBUG - 2011-04-22 06:33:01 --> Total execution time: 0.5336
DEBUG - 2011-04-22 06:33:04 --> Config Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Hooks Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Utf8 Class Initialized
DEBUG - 2011-04-22 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 06:33:04 --> URI Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Router Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Output Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Input Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 06:33:04 --> Language Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Loader Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Controller Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Model Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Model Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Model Class Initialized
DEBUG - 2011-04-22 06:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 06:33:04 --> Database Driver Class Initialized
DEBUG - 2011-04-22 06:33:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 06:33:04 --> Helper loaded: url_helper
DEBUG - 2011-04-22 06:33:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 06:33:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 06:33:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 06:33:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 06:33:04 --> Final output sent to browser
DEBUG - 2011-04-22 06:33:04 --> Total execution time: 0.1532
DEBUG - 2011-04-22 07:08:47 --> Config Class Initialized
DEBUG - 2011-04-22 07:08:47 --> Hooks Class Initialized
DEBUG - 2011-04-22 07:08:47 --> Utf8 Class Initialized
DEBUG - 2011-04-22 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 07:08:47 --> URI Class Initialized
DEBUG - 2011-04-22 07:08:47 --> Router Class Initialized
ERROR - 2011-04-22 07:08:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 07:10:24 --> Config Class Initialized
DEBUG - 2011-04-22 07:10:24 --> Hooks Class Initialized
DEBUG - 2011-04-22 07:10:24 --> Utf8 Class Initialized
DEBUG - 2011-04-22 07:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 07:10:24 --> URI Class Initialized
DEBUG - 2011-04-22 07:10:24 --> Router Class Initialized
DEBUG - 2011-04-22 07:10:24 --> No URI present. Default controller set.
DEBUG - 2011-04-22 07:10:24 --> Output Class Initialized
DEBUG - 2011-04-22 07:10:24 --> Input Class Initialized
DEBUG - 2011-04-22 07:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 07:10:24 --> Language Class Initialized
DEBUG - 2011-04-22 07:10:24 --> Loader Class Initialized
DEBUG - 2011-04-22 07:10:24 --> Controller Class Initialized
DEBUG - 2011-04-22 07:10:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-22 07:10:25 --> Helper loaded: url_helper
DEBUG - 2011-04-22 07:10:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 07:10:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 07:10:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 07:10:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 07:10:25 --> Final output sent to browser
DEBUG - 2011-04-22 07:10:25 --> Total execution time: 0.7981
DEBUG - 2011-04-22 07:23:06 --> Config Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Hooks Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Utf8 Class Initialized
DEBUG - 2011-04-22 07:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 07:23:06 --> URI Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Router Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Output Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Input Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 07:23:06 --> Language Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Loader Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Controller Class Initialized
ERROR - 2011-04-22 07:23:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 07:23:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 07:23:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 07:23:06 --> Model Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Model Class Initialized
DEBUG - 2011-04-22 07:23:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 07:23:06 --> Database Driver Class Initialized
DEBUG - 2011-04-22 07:23:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 07:23:06 --> Helper loaded: url_helper
DEBUG - 2011-04-22 07:23:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 07:23:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 07:23:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 07:23:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 07:23:06 --> Final output sent to browser
DEBUG - 2011-04-22 07:23:06 --> Total execution time: 0.2952
DEBUG - 2011-04-22 07:23:08 --> Config Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Hooks Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Utf8 Class Initialized
DEBUG - 2011-04-22 07:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 07:23:08 --> URI Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Router Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Output Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Input Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 07:23:08 --> Language Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Loader Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Controller Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Model Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Model Class Initialized
DEBUG - 2011-04-22 07:23:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 07:23:08 --> Database Driver Class Initialized
DEBUG - 2011-04-22 07:23:09 --> Final output sent to browser
DEBUG - 2011-04-22 07:23:09 --> Total execution time: 0.6640
DEBUG - 2011-04-22 08:28:02 --> Config Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:28:02 --> URI Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Router Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Output Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Input Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:28:02 --> Language Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Loader Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Controller Class Initialized
ERROR - 2011-04-22 08:28:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 08:28:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 08:28:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 08:28:02 --> Model Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Model Class Initialized
DEBUG - 2011-04-22 08:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:28:02 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:28:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 08:28:02 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:28:02 --> Final output sent to browser
DEBUG - 2011-04-22 08:28:02 --> Total execution time: 0.3079
DEBUG - 2011-04-22 08:28:03 --> Config Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:28:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:28:03 --> URI Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Router Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Output Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Input Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:28:03 --> Language Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Loader Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Controller Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Model Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Model Class Initialized
DEBUG - 2011-04-22 08:28:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:28:03 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:28:04 --> Final output sent to browser
DEBUG - 2011-04-22 08:28:04 --> Total execution time: 0.8098
DEBUG - 2011-04-22 08:28:05 --> Config Class Initialized
DEBUG - 2011-04-22 08:28:05 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:28:05 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:28:05 --> URI Class Initialized
DEBUG - 2011-04-22 08:28:05 --> Router Class Initialized
ERROR - 2011-04-22 08:28:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 08:28:05 --> Config Class Initialized
DEBUG - 2011-04-22 08:28:05 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:28:05 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:28:05 --> URI Class Initialized
DEBUG - 2011-04-22 08:28:05 --> Router Class Initialized
ERROR - 2011-04-22 08:28:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 08:28:06 --> Config Class Initialized
DEBUG - 2011-04-22 08:28:06 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:28:06 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:28:06 --> URI Class Initialized
DEBUG - 2011-04-22 08:28:06 --> Router Class Initialized
ERROR - 2011-04-22 08:28:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 08:28:37 --> Config Class Initialized
DEBUG - 2011-04-22 08:28:37 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:28:37 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:28:37 --> URI Class Initialized
DEBUG - 2011-04-22 08:28:37 --> Router Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Output Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Input Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:28:38 --> Language Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Loader Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Controller Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Model Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Model Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Model Class Initialized
DEBUG - 2011-04-22 08:28:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:28:38 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:28:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:28:39 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:28:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:28:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:28:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:28:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:28:39 --> Final output sent to browser
DEBUG - 2011-04-22 08:28:39 --> Total execution time: 1.3228
DEBUG - 2011-04-22 08:29:01 --> Config Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:29:01 --> URI Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Router Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Output Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Input Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:29:01 --> Language Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Loader Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Controller Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:29:01 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:29:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:29:02 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:29:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:29:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:29:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:29:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:29:02 --> Final output sent to browser
DEBUG - 2011-04-22 08:29:02 --> Total execution time: 0.4990
DEBUG - 2011-04-22 08:29:33 --> Config Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:29:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:29:33 --> URI Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Router Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Output Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Input Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:29:33 --> Language Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Loader Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Controller Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:29:33 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:29:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:29:33 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:29:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:29:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:29:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:29:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:29:33 --> Final output sent to browser
DEBUG - 2011-04-22 08:29:33 --> Total execution time: 0.2788
DEBUG - 2011-04-22 08:29:54 --> Config Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:29:54 --> URI Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Router Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Output Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Input Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:29:54 --> Language Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Loader Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Controller Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Model Class Initialized
DEBUG - 2011-04-22 08:29:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:29:54 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:29:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:29:55 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:29:55 --> Final output sent to browser
DEBUG - 2011-04-22 08:29:55 --> Total execution time: 1.0429
DEBUG - 2011-04-22 08:30:08 --> Config Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:30:08 --> URI Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Router Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Output Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Input Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:30:08 --> Language Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Loader Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Controller Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:30:08 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:30:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:30:08 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:30:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:30:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:30:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:30:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:30:08 --> Final output sent to browser
DEBUG - 2011-04-22 08:30:08 --> Total execution time: 0.0462
DEBUG - 2011-04-22 08:30:19 --> Config Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:30:19 --> URI Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Router Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Output Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Input Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:30:19 --> Language Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Loader Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Controller Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:30:19 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:30:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:30:20 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:30:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:30:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:30:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:30:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:30:20 --> Final output sent to browser
DEBUG - 2011-04-22 08:30:20 --> Total execution time: 0.5461
DEBUG - 2011-04-22 08:30:41 --> Config Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:30:41 --> URI Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Router Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Output Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Input Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:30:41 --> Language Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Loader Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Controller Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:30:41 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:30:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:30:41 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:30:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:30:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:30:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:30:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:30:41 --> Final output sent to browser
DEBUG - 2011-04-22 08:30:41 --> Total execution time: 0.2839
DEBUG - 2011-04-22 08:30:57 --> Config Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:30:57 --> URI Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Router Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Output Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Input Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:30:57 --> Language Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Loader Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Controller Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Model Class Initialized
DEBUG - 2011-04-22 08:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:30:57 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:30:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:30:58 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:30:58 --> Final output sent to browser
DEBUG - 2011-04-22 08:30:58 --> Total execution time: 1.4177
DEBUG - 2011-04-22 08:31:13 --> Config Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:31:13 --> URI Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Router Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Output Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Input Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:31:13 --> Language Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Loader Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Controller Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:31:13 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:31:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:31:13 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:31:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:31:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:31:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:31:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:31:13 --> Final output sent to browser
DEBUG - 2011-04-22 08:31:13 --> Total execution time: 0.2898
DEBUG - 2011-04-22 08:31:30 --> Config Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:31:30 --> URI Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Router Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Output Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Input Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:31:30 --> Language Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Loader Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Controller Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:31:30 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:31:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:31:30 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:31:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:31:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:31:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:31:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:31:30 --> Final output sent to browser
DEBUG - 2011-04-22 08:31:30 --> Total execution time: 0.2317
DEBUG - 2011-04-22 08:31:56 --> Config Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:31:56 --> URI Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Router Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Output Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Input Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:31:56 --> Language Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Loader Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Controller Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Model Class Initialized
DEBUG - 2011-04-22 08:31:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:31:56 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:31:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:31:56 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:31:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:31:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:31:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:31:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:31:56 --> Final output sent to browser
DEBUG - 2011-04-22 08:31:56 --> Total execution time: 0.1890
DEBUG - 2011-04-22 08:32:09 --> Config Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:32:09 --> URI Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Router Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Output Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Input Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:32:09 --> Language Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Loader Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Controller Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Model Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Model Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Model Class Initialized
DEBUG - 2011-04-22 08:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:32:10 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:32:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 08:32:10 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:32:10 --> Final output sent to browser
DEBUG - 2011-04-22 08:32:10 --> Total execution time: 0.2799
DEBUG - 2011-04-22 08:40:54 --> Config Class Initialized
DEBUG - 2011-04-22 08:40:54 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:40:54 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:40:54 --> URI Class Initialized
DEBUG - 2011-04-22 08:40:54 --> Router Class Initialized
DEBUG - 2011-04-22 08:40:54 --> Output Class Initialized
DEBUG - 2011-04-22 08:40:54 --> Input Class Initialized
DEBUG - 2011-04-22 08:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:40:54 --> Language Class Initialized
DEBUG - 2011-04-22 08:40:54 --> Loader Class Initialized
DEBUG - 2011-04-22 08:40:54 --> Controller Class Initialized
ERROR - 2011-04-22 08:40:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 08:40:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 08:40:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 08:40:55 --> Model Class Initialized
DEBUG - 2011-04-22 08:40:55 --> Model Class Initialized
DEBUG - 2011-04-22 08:40:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:40:55 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:40:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 08:40:55 --> Helper loaded: url_helper
DEBUG - 2011-04-22 08:40:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 08:40:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 08:40:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 08:40:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 08:40:55 --> Final output sent to browser
DEBUG - 2011-04-22 08:40:55 --> Total execution time: 0.3367
DEBUG - 2011-04-22 08:40:57 --> Config Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:40:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:40:57 --> URI Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Router Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Output Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Input Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 08:40:57 --> Language Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Loader Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Controller Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Model Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Model Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 08:40:57 --> Database Driver Class Initialized
DEBUG - 2011-04-22 08:40:57 --> Final output sent to browser
DEBUG - 2011-04-22 08:40:57 --> Total execution time: 0.6469
DEBUG - 2011-04-22 08:40:59 --> Config Class Initialized
DEBUG - 2011-04-22 08:40:59 --> Hooks Class Initialized
DEBUG - 2011-04-22 08:40:59 --> Utf8 Class Initialized
DEBUG - 2011-04-22 08:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 08:40:59 --> URI Class Initialized
DEBUG - 2011-04-22 08:40:59 --> Router Class Initialized
ERROR - 2011-04-22 08:40:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 09:35:37 --> Config Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Config Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:35:37 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:35:37 --> URI Class Initialized
DEBUG - 2011-04-22 09:35:37 --> URI Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Router Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Router Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Output Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Output Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Input Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:35:37 --> Input Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:35:37 --> Language Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Language Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Loader Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Loader Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Controller Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Controller Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:37 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:38 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:38 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:38 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:38 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:35:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:35:38 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:35:38 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:35:39 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:35:39 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:35:39 --> Final output sent to browser
DEBUG - 2011-04-22 09:35:39 --> Total execution time: 2.5839
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:35:39 --> Final output sent to browser
DEBUG - 2011-04-22 09:35:39 --> Total execution time: 2.5890
DEBUG - 2011-04-22 09:35:42 --> Config Class Initialized
DEBUG - 2011-04-22 09:35:42 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:35:42 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:35:42 --> URI Class Initialized
DEBUG - 2011-04-22 09:35:42 --> Router Class Initialized
ERROR - 2011-04-22 09:35:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 09:35:54 --> Config Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:35:54 --> URI Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Router Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Output Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Input Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:35:54 --> Language Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Loader Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Controller Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Model Class Initialized
DEBUG - 2011-04-22 09:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:35:54 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:35:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:35:55 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:35:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:35:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:35:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:35:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:35:55 --> Final output sent to browser
DEBUG - 2011-04-22 09:35:55 --> Total execution time: 0.5866
DEBUG - 2011-04-22 09:35:56 --> Config Class Initialized
DEBUG - 2011-04-22 09:35:56 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:35:56 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:35:56 --> URI Class Initialized
DEBUG - 2011-04-22 09:35:56 --> Router Class Initialized
ERROR - 2011-04-22 09:35:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 09:36:09 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:09 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Router Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Output Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Input Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:36:09 --> Language Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Loader Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Controller Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:36:09 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:36:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:36:10 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:36:10 --> Final output sent to browser
DEBUG - 2011-04-22 09:36:10 --> Total execution time: 0.2426
DEBUG - 2011-04-22 09:36:11 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:11 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:11 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:11 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:11 --> Router Class Initialized
ERROR - 2011-04-22 09:36:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 09:36:12 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:12 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Router Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Output Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Input Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:36:12 --> Language Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Loader Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Controller Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:36:12 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:36:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:36:12 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:36:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:36:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:36:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:36:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:36:12 --> Final output sent to browser
DEBUG - 2011-04-22 09:36:12 --> Total execution time: 0.1714
DEBUG - 2011-04-22 09:36:15 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:15 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Router Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Output Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Input Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:36:15 --> Language Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Loader Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Controller Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:36:15 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:36:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:36:16 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:36:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:36:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:36:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:36:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:36:16 --> Final output sent to browser
DEBUG - 2011-04-22 09:36:16 --> Total execution time: 0.3182
DEBUG - 2011-04-22 09:36:17 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:17 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:17 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:17 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:17 --> Router Class Initialized
ERROR - 2011-04-22 09:36:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 09:36:20 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:20 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Router Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Output Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Input Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:36:20 --> Language Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Loader Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Controller Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:36:20 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:36:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:36:20 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:36:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:36:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:36:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:36:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:36:20 --> Final output sent to browser
DEBUG - 2011-04-22 09:36:20 --> Total execution time: 0.2351
DEBUG - 2011-04-22 09:36:22 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:22 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:22 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:22 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:22 --> Router Class Initialized
ERROR - 2011-04-22 09:36:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 09:36:25 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:25 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Router Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Output Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Input Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:36:25 --> Language Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Loader Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Controller Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:36:25 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:36:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:36:25 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:36:25 --> Final output sent to browser
DEBUG - 2011-04-22 09:36:25 --> Total execution time: 0.0976
DEBUG - 2011-04-22 09:36:26 --> Config Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Hooks Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Utf8 Class Initialized
DEBUG - 2011-04-22 09:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 09:36:26 --> URI Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Router Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Output Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Input Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 09:36:26 --> Language Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Loader Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Controller Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Model Class Initialized
DEBUG - 2011-04-22 09:36:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 09:36:26 --> Database Driver Class Initialized
DEBUG - 2011-04-22 09:36:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 09:36:26 --> Helper loaded: url_helper
DEBUG - 2011-04-22 09:36:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 09:36:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 09:36:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 09:36:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 09:36:26 --> Final output sent to browser
DEBUG - 2011-04-22 09:36:26 --> Total execution time: 0.0631
DEBUG - 2011-04-22 10:22:17 --> Config Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Hooks Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Utf8 Class Initialized
DEBUG - 2011-04-22 10:22:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 10:22:17 --> URI Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Router Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Output Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Input Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 10:22:17 --> Language Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Loader Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Controller Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Model Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Model Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Model Class Initialized
DEBUG - 2011-04-22 10:22:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 10:22:17 --> Database Driver Class Initialized
DEBUG - 2011-04-22 10:22:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 10:22:17 --> Helper loaded: url_helper
DEBUG - 2011-04-22 10:22:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 10:22:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 10:22:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 10:22:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 10:22:17 --> Final output sent to browser
DEBUG - 2011-04-22 10:22:17 --> Total execution time: 0.5758
DEBUG - 2011-04-22 10:22:18 --> Config Class Initialized
DEBUG - 2011-04-22 10:22:18 --> Hooks Class Initialized
DEBUG - 2011-04-22 10:22:18 --> Utf8 Class Initialized
DEBUG - 2011-04-22 10:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 10:22:18 --> URI Class Initialized
DEBUG - 2011-04-22 10:22:18 --> Router Class Initialized
DEBUG - 2011-04-22 10:22:19 --> Output Class Initialized
DEBUG - 2011-04-22 10:22:19 --> Input Class Initialized
DEBUG - 2011-04-22 10:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 10:22:19 --> Language Class Initialized
DEBUG - 2011-04-22 10:22:19 --> Loader Class Initialized
DEBUG - 2011-04-22 10:22:19 --> Controller Class Initialized
ERROR - 2011-04-22 10:22:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 10:22:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 10:22:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 10:22:19 --> Model Class Initialized
DEBUG - 2011-04-22 10:22:19 --> Model Class Initialized
DEBUG - 2011-04-22 10:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 10:22:19 --> Database Driver Class Initialized
DEBUG - 2011-04-22 10:22:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 10:22:19 --> Helper loaded: url_helper
DEBUG - 2011-04-22 10:22:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 10:22:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 10:22:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 10:22:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 10:22:19 --> Final output sent to browser
DEBUG - 2011-04-22 10:22:19 --> Total execution time: 0.2085
DEBUG - 2011-04-22 11:00:47 --> Config Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Hooks Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Utf8 Class Initialized
DEBUG - 2011-04-22 11:00:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 11:00:47 --> URI Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Router Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Output Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Input Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 11:00:47 --> Language Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Loader Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Controller Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Model Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Model Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Model Class Initialized
DEBUG - 2011-04-22 11:00:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 11:00:48 --> Database Driver Class Initialized
DEBUG - 2011-04-22 11:00:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 11:00:48 --> Helper loaded: url_helper
DEBUG - 2011-04-22 11:00:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 11:00:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 11:00:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 11:00:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 11:00:48 --> Final output sent to browser
DEBUG - 2011-04-22 11:00:48 --> Total execution time: 0.5729
DEBUG - 2011-04-22 11:01:19 --> Config Class Initialized
DEBUG - 2011-04-22 11:01:19 --> Hooks Class Initialized
DEBUG - 2011-04-22 11:01:19 --> Utf8 Class Initialized
DEBUG - 2011-04-22 11:01:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 11:01:19 --> URI Class Initialized
DEBUG - 2011-04-22 11:01:19 --> Router Class Initialized
ERROR - 2011-04-22 11:01:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 11:01:43 --> Config Class Initialized
DEBUG - 2011-04-22 11:01:43 --> Hooks Class Initialized
DEBUG - 2011-04-22 11:01:43 --> Utf8 Class Initialized
DEBUG - 2011-04-22 11:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 11:01:43 --> URI Class Initialized
DEBUG - 2011-04-22 11:01:43 --> Router Class Initialized
ERROR - 2011-04-22 11:01:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-22 11:56:48 --> Config Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Hooks Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Utf8 Class Initialized
DEBUG - 2011-04-22 11:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 11:56:48 --> URI Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Router Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Output Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Input Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 11:56:48 --> Language Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Loader Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Controller Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Model Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Model Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Model Class Initialized
DEBUG - 2011-04-22 11:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 11:56:48 --> Database Driver Class Initialized
DEBUG - 2011-04-22 11:56:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 11:56:49 --> Helper loaded: url_helper
DEBUG - 2011-04-22 11:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 11:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 11:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 11:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 11:56:49 --> Final output sent to browser
DEBUG - 2011-04-22 11:56:49 --> Total execution time: 0.8174
DEBUG - 2011-04-22 11:58:50 --> Config Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Hooks Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Utf8 Class Initialized
DEBUG - 2011-04-22 11:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 11:58:50 --> URI Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Router Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Output Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Input Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 11:58:50 --> Language Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Loader Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Controller Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Model Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Model Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Model Class Initialized
DEBUG - 2011-04-22 11:58:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 11:58:50 --> Database Driver Class Initialized
DEBUG - 2011-04-22 11:58:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 11:58:51 --> Helper loaded: url_helper
DEBUG - 2011-04-22 11:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 11:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 11:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 11:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 11:58:51 --> Final output sent to browser
DEBUG - 2011-04-22 11:58:51 --> Total execution time: 0.0581
DEBUG - 2011-04-22 11:58:52 --> Config Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Hooks Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Utf8 Class Initialized
DEBUG - 2011-04-22 11:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 11:58:52 --> URI Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Router Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Output Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Input Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 11:58:52 --> Language Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Loader Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Controller Class Initialized
ERROR - 2011-04-22 11:58:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 11:58:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 11:58:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 11:58:52 --> Model Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Model Class Initialized
DEBUG - 2011-04-22 11:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 11:58:52 --> Database Driver Class Initialized
DEBUG - 2011-04-22 11:58:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 11:58:52 --> Helper loaded: url_helper
DEBUG - 2011-04-22 11:58:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 11:58:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 11:58:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 11:58:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 11:58:52 --> Final output sent to browser
DEBUG - 2011-04-22 11:58:52 --> Total execution time: 0.1006
DEBUG - 2011-04-22 13:29:14 --> Config Class Initialized
DEBUG - 2011-04-22 13:29:14 --> Hooks Class Initialized
DEBUG - 2011-04-22 13:29:14 --> Utf8 Class Initialized
DEBUG - 2011-04-22 13:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 13:29:14 --> URI Class Initialized
DEBUG - 2011-04-22 13:29:14 --> Router Class Initialized
ERROR - 2011-04-22 13:29:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 13:29:15 --> Config Class Initialized
DEBUG - 2011-04-22 13:29:15 --> Hooks Class Initialized
DEBUG - 2011-04-22 13:29:15 --> Utf8 Class Initialized
DEBUG - 2011-04-22 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 13:29:15 --> URI Class Initialized
DEBUG - 2011-04-22 13:29:15 --> Router Class Initialized
DEBUG - 2011-04-22 13:29:15 --> No URI present. Default controller set.
DEBUG - 2011-04-22 13:29:15 --> Output Class Initialized
DEBUG - 2011-04-22 13:29:15 --> Input Class Initialized
DEBUG - 2011-04-22 13:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 13:29:15 --> Language Class Initialized
DEBUG - 2011-04-22 13:29:15 --> Loader Class Initialized
DEBUG - 2011-04-22 13:29:15 --> Controller Class Initialized
DEBUG - 2011-04-22 13:29:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-22 13:29:15 --> Helper loaded: url_helper
DEBUG - 2011-04-22 13:29:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 13:29:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 13:29:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 13:29:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 13:29:15 --> Final output sent to browser
DEBUG - 2011-04-22 13:29:15 --> Total execution time: 0.1957
DEBUG - 2011-04-22 13:32:09 --> Config Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Hooks Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Utf8 Class Initialized
DEBUG - 2011-04-22 13:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 13:32:09 --> URI Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Router Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Output Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Input Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 13:32:09 --> Language Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Loader Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Controller Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Model Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Model Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Model Class Initialized
DEBUG - 2011-04-22 13:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 13:32:09 --> Database Driver Class Initialized
DEBUG - 2011-04-22 13:32:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 13:32:09 --> Helper loaded: url_helper
DEBUG - 2011-04-22 13:32:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 13:32:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 13:32:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 13:32:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 13:32:09 --> Final output sent to browser
DEBUG - 2011-04-22 13:32:09 --> Total execution time: 0.3830
DEBUG - 2011-04-22 13:32:10 --> Config Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Hooks Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Utf8 Class Initialized
DEBUG - 2011-04-22 13:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 13:32:10 --> URI Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Router Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Output Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Input Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 13:32:10 --> Language Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Loader Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Controller Class Initialized
ERROR - 2011-04-22 13:32:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 13:32:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 13:32:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 13:32:10 --> Model Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Model Class Initialized
DEBUG - 2011-04-22 13:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 13:32:10 --> Database Driver Class Initialized
DEBUG - 2011-04-22 13:32:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 13:32:10 --> Helper loaded: url_helper
DEBUG - 2011-04-22 13:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 13:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 13:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 13:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 13:32:10 --> Final output sent to browser
DEBUG - 2011-04-22 13:32:10 --> Total execution time: 0.0804
DEBUG - 2011-04-22 14:44:17 --> Config Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Hooks Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Utf8 Class Initialized
DEBUG - 2011-04-22 14:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 14:44:17 --> URI Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Router Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Output Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Input Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 14:44:17 --> Language Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Loader Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Controller Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Model Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Model Class Initialized
DEBUG - 2011-04-22 14:44:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 14:44:17 --> Database Driver Class Initialized
DEBUG - 2011-04-22 14:44:18 --> Final output sent to browser
DEBUG - 2011-04-22 14:44:18 --> Total execution time: 0.9553
DEBUG - 2011-04-22 14:50:55 --> Config Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Hooks Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Utf8 Class Initialized
DEBUG - 2011-04-22 14:50:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 14:50:55 --> URI Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Router Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Output Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Input Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 14:50:55 --> Language Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Loader Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Controller Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Model Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Model Class Initialized
DEBUG - 2011-04-22 14:50:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 14:50:55 --> Database Driver Class Initialized
DEBUG - 2011-04-22 14:50:56 --> Final output sent to browser
DEBUG - 2011-04-22 14:50:56 --> Total execution time: 0.6308
DEBUG - 2011-04-22 15:17:14 --> Config Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Hooks Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Utf8 Class Initialized
DEBUG - 2011-04-22 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 15:17:14 --> URI Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Router Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Output Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Input Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 15:17:14 --> Language Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Loader Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Controller Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Model Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Model Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Model Class Initialized
DEBUG - 2011-04-22 15:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 15:17:14 --> Database Driver Class Initialized
DEBUG - 2011-04-22 15:17:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 15:17:14 --> Helper loaded: url_helper
DEBUG - 2011-04-22 15:17:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 15:17:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 15:17:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 15:17:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 15:17:14 --> Final output sent to browser
DEBUG - 2011-04-22 15:17:14 --> Total execution time: 0.4105
DEBUG - 2011-04-22 15:17:16 --> Config Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Hooks Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Utf8 Class Initialized
DEBUG - 2011-04-22 15:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 15:17:16 --> URI Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Router Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Output Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Input Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 15:17:16 --> Language Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Loader Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Controller Class Initialized
ERROR - 2011-04-22 15:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 15:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 15:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 15:17:16 --> Model Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Model Class Initialized
DEBUG - 2011-04-22 15:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 15:17:16 --> Database Driver Class Initialized
DEBUG - 2011-04-22 15:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 15:17:16 --> Helper loaded: url_helper
DEBUG - 2011-04-22 15:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 15:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 15:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 15:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 15:17:16 --> Final output sent to browser
DEBUG - 2011-04-22 15:17:16 --> Total execution time: 0.1149
DEBUG - 2011-04-22 16:48:53 --> Config Class Initialized
DEBUG - 2011-04-22 16:48:53 --> Hooks Class Initialized
DEBUG - 2011-04-22 16:48:53 --> Utf8 Class Initialized
DEBUG - 2011-04-22 16:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 16:48:53 --> URI Class Initialized
DEBUG - 2011-04-22 16:48:53 --> Router Class Initialized
DEBUG - 2011-04-22 16:48:53 --> Output Class Initialized
DEBUG - 2011-04-22 16:48:53 --> Input Class Initialized
DEBUG - 2011-04-22 16:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 16:48:53 --> Language Class Initialized
DEBUG - 2011-04-22 16:48:54 --> Loader Class Initialized
DEBUG - 2011-04-22 16:48:54 --> Controller Class Initialized
DEBUG - 2011-04-22 16:48:54 --> Model Class Initialized
DEBUG - 2011-04-22 16:48:54 --> Model Class Initialized
DEBUG - 2011-04-22 16:48:54 --> Model Class Initialized
DEBUG - 2011-04-22 16:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 16:48:55 --> Database Driver Class Initialized
DEBUG - 2011-04-22 16:48:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 16:48:56 --> Helper loaded: url_helper
DEBUG - 2011-04-22 16:48:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 16:48:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 16:48:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 16:48:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 16:48:56 --> Final output sent to browser
DEBUG - 2011-04-22 16:48:56 --> Total execution time: 3.5707
DEBUG - 2011-04-22 16:48:57 --> Config Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Hooks Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Utf8 Class Initialized
DEBUG - 2011-04-22 16:48:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 16:48:57 --> URI Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Router Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Output Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Input Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 16:48:57 --> Language Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Loader Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Controller Class Initialized
ERROR - 2011-04-22 16:48:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 16:48:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 16:48:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 16:48:57 --> Model Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Model Class Initialized
DEBUG - 2011-04-22 16:48:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 16:48:57 --> Database Driver Class Initialized
DEBUG - 2011-04-22 16:48:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 16:48:57 --> Helper loaded: url_helper
DEBUG - 2011-04-22 16:48:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 16:48:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 16:48:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 16:48:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 16:48:57 --> Final output sent to browser
DEBUG - 2011-04-22 16:48:57 --> Total execution time: 0.4852
DEBUG - 2011-04-22 17:25:50 --> Config Class Initialized
DEBUG - 2011-04-22 17:25:50 --> Hooks Class Initialized
DEBUG - 2011-04-22 17:25:50 --> Utf8 Class Initialized
DEBUG - 2011-04-22 17:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 17:25:50 --> URI Class Initialized
DEBUG - 2011-04-22 17:25:50 --> Router Class Initialized
ERROR - 2011-04-22 17:25:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 17:48:22 --> Config Class Initialized
DEBUG - 2011-04-22 17:48:22 --> Hooks Class Initialized
DEBUG - 2011-04-22 17:48:22 --> Utf8 Class Initialized
DEBUG - 2011-04-22 17:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 17:48:22 --> URI Class Initialized
DEBUG - 2011-04-22 17:48:22 --> Router Class Initialized
DEBUG - 2011-04-22 17:48:23 --> Output Class Initialized
DEBUG - 2011-04-22 17:48:23 --> Input Class Initialized
DEBUG - 2011-04-22 17:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 17:48:23 --> Language Class Initialized
DEBUG - 2011-04-22 17:48:23 --> Loader Class Initialized
DEBUG - 2011-04-22 17:48:23 --> Controller Class Initialized
ERROR - 2011-04-22 17:48:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 17:48:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 17:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 17:48:23 --> Model Class Initialized
DEBUG - 2011-04-22 17:48:23 --> Model Class Initialized
DEBUG - 2011-04-22 17:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 17:48:23 --> Database Driver Class Initialized
DEBUG - 2011-04-22 17:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 17:48:23 --> Helper loaded: url_helper
DEBUG - 2011-04-22 17:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 17:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 17:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 17:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 17:48:23 --> Final output sent to browser
DEBUG - 2011-04-22 17:48:23 --> Total execution time: 0.3252
DEBUG - 2011-04-22 18:31:27 --> Config Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Hooks Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Utf8 Class Initialized
DEBUG - 2011-04-22 18:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 18:31:27 --> URI Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Router Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Output Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Input Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 18:31:27 --> Language Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Loader Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Controller Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Model Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Model Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Model Class Initialized
DEBUG - 2011-04-22 18:31:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 18:31:27 --> Database Driver Class Initialized
DEBUG - 2011-04-22 18:31:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 18:31:27 --> Helper loaded: url_helper
DEBUG - 2011-04-22 18:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 18:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 18:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 18:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 18:31:27 --> Final output sent to browser
DEBUG - 2011-04-22 18:31:27 --> Total execution time: 0.5980
DEBUG - 2011-04-22 18:31:30 --> Config Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Hooks Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Utf8 Class Initialized
DEBUG - 2011-04-22 18:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 18:31:30 --> URI Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Router Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Output Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Input Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 18:31:30 --> Language Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Loader Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Controller Class Initialized
ERROR - 2011-04-22 18:31:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 18:31:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 18:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 18:31:30 --> Model Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Model Class Initialized
DEBUG - 2011-04-22 18:31:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 18:31:30 --> Database Driver Class Initialized
DEBUG - 2011-04-22 18:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 18:31:30 --> Helper loaded: url_helper
DEBUG - 2011-04-22 18:31:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 18:31:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 18:31:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 18:31:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 18:31:30 --> Final output sent to browser
DEBUG - 2011-04-22 18:31:30 --> Total execution time: 0.0861
DEBUG - 2011-04-22 19:58:36 --> Config Class Initialized
DEBUG - 2011-04-22 19:58:36 --> Hooks Class Initialized
DEBUG - 2011-04-22 19:58:36 --> Utf8 Class Initialized
DEBUG - 2011-04-22 19:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 19:58:36 --> URI Class Initialized
DEBUG - 2011-04-22 19:58:36 --> Router Class Initialized
DEBUG - 2011-04-22 19:58:36 --> Output Class Initialized
DEBUG - 2011-04-22 19:58:36 --> Input Class Initialized
DEBUG - 2011-04-22 19:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 19:58:36 --> Language Class Initialized
DEBUG - 2011-04-22 19:58:37 --> Loader Class Initialized
DEBUG - 2011-04-22 19:58:37 --> Controller Class Initialized
DEBUG - 2011-04-22 19:58:37 --> Model Class Initialized
DEBUG - 2011-04-22 19:58:37 --> Model Class Initialized
DEBUG - 2011-04-22 19:58:37 --> Model Class Initialized
DEBUG - 2011-04-22 19:58:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 19:58:37 --> Database Driver Class Initialized
DEBUG - 2011-04-22 19:58:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 19:58:37 --> Helper loaded: url_helper
DEBUG - 2011-04-22 19:58:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 19:58:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 19:58:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 19:58:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 19:58:37 --> Final output sent to browser
DEBUG - 2011-04-22 19:58:37 --> Total execution time: 0.5163
DEBUG - 2011-04-22 20:25:30 --> Config Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Hooks Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Utf8 Class Initialized
DEBUG - 2011-04-22 20:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 20:25:30 --> URI Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Router Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Output Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Input Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 20:25:30 --> Language Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Loader Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Controller Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Model Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Model Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Model Class Initialized
DEBUG - 2011-04-22 20:25:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 20:25:30 --> Database Driver Class Initialized
DEBUG - 2011-04-22 20:25:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 20:25:30 --> Helper loaded: url_helper
DEBUG - 2011-04-22 20:25:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 20:25:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 20:25:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 20:25:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 20:25:30 --> Final output sent to browser
DEBUG - 2011-04-22 20:25:30 --> Total execution time: 0.5085
DEBUG - 2011-04-22 20:25:33 --> Config Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Hooks Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Utf8 Class Initialized
DEBUG - 2011-04-22 20:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 20:25:33 --> URI Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Router Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Output Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Input Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 20:25:33 --> Language Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Loader Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Controller Class Initialized
ERROR - 2011-04-22 20:25:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 20:25:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 20:25:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 20:25:33 --> Model Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Model Class Initialized
DEBUG - 2011-04-22 20:25:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 20:25:33 --> Database Driver Class Initialized
DEBUG - 2011-04-22 20:25:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 20:25:33 --> Helper loaded: url_helper
DEBUG - 2011-04-22 20:25:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 20:25:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 20:25:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 20:25:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 20:25:33 --> Final output sent to browser
DEBUG - 2011-04-22 20:25:33 --> Total execution time: 0.1235
DEBUG - 2011-04-22 21:23:55 --> Config Class Initialized
DEBUG - 2011-04-22 21:23:55 --> Hooks Class Initialized
DEBUG - 2011-04-22 21:23:55 --> Utf8 Class Initialized
DEBUG - 2011-04-22 21:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 21:23:55 --> URI Class Initialized
DEBUG - 2011-04-22 21:23:55 --> Router Class Initialized
ERROR - 2011-04-22 21:23:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 21:23:57 --> Config Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Hooks Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Utf8 Class Initialized
DEBUG - 2011-04-22 21:23:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 21:23:57 --> URI Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Router Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Output Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Input Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 21:23:57 --> Language Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Loader Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Controller Class Initialized
ERROR - 2011-04-22 21:23:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-22 21:23:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-22 21:23:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 21:23:57 --> Model Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Model Class Initialized
DEBUG - 2011-04-22 21:23:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 21:23:57 --> Database Driver Class Initialized
DEBUG - 2011-04-22 21:23:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-22 21:23:57 --> Helper loaded: url_helper
DEBUG - 2011-04-22 21:23:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 21:23:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 21:23:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 21:23:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 21:23:57 --> Final output sent to browser
DEBUG - 2011-04-22 21:23:57 --> Total execution time: 0.2698
DEBUG - 2011-04-22 21:27:58 --> Config Class Initialized
DEBUG - 2011-04-22 21:27:58 --> Hooks Class Initialized
DEBUG - 2011-04-22 21:27:58 --> Utf8 Class Initialized
DEBUG - 2011-04-22 21:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 21:27:58 --> URI Class Initialized
DEBUG - 2011-04-22 21:27:58 --> Router Class Initialized
ERROR - 2011-04-22 21:27:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 21:27:59 --> Config Class Initialized
DEBUG - 2011-04-22 21:27:59 --> Hooks Class Initialized
DEBUG - 2011-04-22 21:27:59 --> Utf8 Class Initialized
DEBUG - 2011-04-22 21:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 21:27:59 --> URI Class Initialized
DEBUG - 2011-04-22 21:27:59 --> Router Class Initialized
DEBUG - 2011-04-22 21:27:59 --> No URI present. Default controller set.
DEBUG - 2011-04-22 21:27:59 --> Output Class Initialized
DEBUG - 2011-04-22 21:27:59 --> Input Class Initialized
DEBUG - 2011-04-22 21:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 21:27:59 --> Language Class Initialized
DEBUG - 2011-04-22 21:27:59 --> Loader Class Initialized
DEBUG - 2011-04-22 21:27:59 --> Controller Class Initialized
DEBUG - 2011-04-22 21:27:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-22 21:27:59 --> Helper loaded: url_helper
DEBUG - 2011-04-22 21:27:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 21:27:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 21:27:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 21:27:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 21:27:59 --> Final output sent to browser
DEBUG - 2011-04-22 21:27:59 --> Total execution time: 0.0664
DEBUG - 2011-04-22 21:50:28 --> Config Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Hooks Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Utf8 Class Initialized
DEBUG - 2011-04-22 21:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 21:50:29 --> URI Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Router Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Output Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Input Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 21:50:29 --> Language Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Loader Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Controller Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Model Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Model Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Model Class Initialized
DEBUG - 2011-04-22 21:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 21:50:29 --> Database Driver Class Initialized
DEBUG - 2011-04-22 21:50:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 21:50:29 --> Helper loaded: url_helper
DEBUG - 2011-04-22 21:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 21:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 21:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 21:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 21:50:29 --> Final output sent to browser
DEBUG - 2011-04-22 21:50:29 --> Total execution time: 0.8680
DEBUG - 2011-04-22 22:40:27 --> Config Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Hooks Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Utf8 Class Initialized
DEBUG - 2011-04-22 22:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 22:40:27 --> URI Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Router Class Initialized
ERROR - 2011-04-22 22:40:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-22 22:40:27 --> Config Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Hooks Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Utf8 Class Initialized
DEBUG - 2011-04-22 22:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 22:40:27 --> URI Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Router Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Output Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Input Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-22 22:40:27 --> Language Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Loader Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Controller Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Model Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Model Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Model Class Initialized
DEBUG - 2011-04-22 22:40:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-22 22:40:28 --> Database Driver Class Initialized
DEBUG - 2011-04-22 22:40:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-22 22:40:28 --> Helper loaded: url_helper
DEBUG - 2011-04-22 22:40:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-22 22:40:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-22 22:40:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-22 22:40:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-22 22:40:28 --> Final output sent to browser
DEBUG - 2011-04-22 22:40:28 --> Total execution time: 0.6575
DEBUG - 2011-04-22 23:39:57 --> Config Class Initialized
DEBUG - 2011-04-22 23:39:57 --> Hooks Class Initialized
DEBUG - 2011-04-22 23:39:57 --> Utf8 Class Initialized
DEBUG - 2011-04-22 23:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-22 23:39:57 --> URI Class Initialized
DEBUG - 2011-04-22 23:39:57 --> Router Class Initialized
ERROR - 2011-04-22 23:39:57 --> 404 Page Not Found --> robots.txt

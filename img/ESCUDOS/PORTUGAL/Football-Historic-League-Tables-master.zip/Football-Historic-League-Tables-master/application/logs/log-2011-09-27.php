<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-27 01:19:54 --> Config Class Initialized
DEBUG - 2011-09-27 01:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:19:54 --> URI Class Initialized
DEBUG - 2011-09-27 01:19:54 --> Router Class Initialized
ERROR - 2011-09-27 01:19:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-27 01:26:00 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:00 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Router Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Output Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Input Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:26:00 --> Language Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Loader Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Controller Class Initialized
ERROR - 2011-09-27 01:26:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:26:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:26:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:26:00 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:26:00 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:26:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:26:00 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:26:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:26:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:26:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:26:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:26:00 --> Final output sent to browser
DEBUG - 2011-09-27 01:26:00 --> Total execution time: 0.6019
DEBUG - 2011-09-27 01:26:02 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:02 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Router Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Output Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Input Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:26:02 --> Language Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Loader Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Controller Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:26:02 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:26:03 --> Final output sent to browser
DEBUG - 2011-09-27 01:26:03 --> Total execution time: 0.9663
DEBUG - 2011-09-27 01:26:06 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:06 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:06 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:06 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:06 --> Router Class Initialized
ERROR - 2011-09-27 01:26:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 01:26:07 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:07 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:07 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:07 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:07 --> Router Class Initialized
ERROR - 2011-09-27 01:26:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 01:26:33 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:33 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Router Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Output Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Input Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:26:33 --> Language Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Loader Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Controller Class Initialized
ERROR - 2011-09-27 01:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:26:33 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:26:33 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:26:33 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:26:33 --> Final output sent to browser
DEBUG - 2011-09-27 01:26:33 --> Total execution time: 0.1250
DEBUG - 2011-09-27 01:26:34 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:34 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:34 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:34 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:34 --> Router Class Initialized
DEBUG - 2011-09-27 01:26:34 --> Output Class Initialized
DEBUG - 2011-09-27 01:26:34 --> Input Class Initialized
DEBUG - 2011-09-27 01:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:26:34 --> Language Class Initialized
DEBUG - 2011-09-27 01:26:34 --> Loader Class Initialized
DEBUG - 2011-09-27 01:26:35 --> Controller Class Initialized
DEBUG - 2011-09-27 01:26:35 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:35 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:26:35 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:26:36 --> Final output sent to browser
DEBUG - 2011-09-27 01:26:36 --> Total execution time: 1.0893
DEBUG - 2011-09-27 01:26:42 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:42 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Router Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Output Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Input Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:26:42 --> Language Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Loader Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Controller Class Initialized
ERROR - 2011-09-27 01:26:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:26:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:26:42 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:26:42 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:26:42 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:26:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:26:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:26:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:26:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:26:42 --> Final output sent to browser
DEBUG - 2011-09-27 01:26:42 --> Total execution time: 0.1864
DEBUG - 2011-09-27 01:26:44 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:44 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Router Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Output Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Input Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:26:44 --> Language Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Loader Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Controller Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:26:44 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:26:45 --> Final output sent to browser
DEBUG - 2011-09-27 01:26:45 --> Total execution time: 0.9119
DEBUG - 2011-09-27 01:26:52 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:52 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Router Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Output Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Input Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:26:52 --> Language Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Loader Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Controller Class Initialized
ERROR - 2011-09-27 01:26:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:26:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:26:52 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:26:52 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:26:52 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:26:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:26:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:26:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:26:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:26:52 --> Final output sent to browser
DEBUG - 2011-09-27 01:26:52 --> Total execution time: 0.0461
DEBUG - 2011-09-27 01:26:55 --> Config Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:26:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:26:55 --> URI Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Router Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Output Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Input Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:26:55 --> Language Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Loader Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Controller Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Model Class Initialized
DEBUG - 2011-09-27 01:26:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:26:55 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:26:57 --> Final output sent to browser
DEBUG - 2011-09-27 01:26:57 --> Total execution time: 1.9005
DEBUG - 2011-09-27 01:27:09 --> Config Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:27:09 --> URI Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Router Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Output Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Input Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:27:09 --> Language Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Loader Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Controller Class Initialized
ERROR - 2011-09-27 01:27:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:27:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:27:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:27:09 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:27:09 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:27:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:27:09 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:27:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:27:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:27:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:27:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:27:09 --> Final output sent to browser
DEBUG - 2011-09-27 01:27:09 --> Total execution time: 0.1596
DEBUG - 2011-09-27 01:27:15 --> Config Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:27:15 --> URI Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Router Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Output Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Input Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:27:15 --> Language Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Loader Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Controller Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:27:15 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:27:17 --> Final output sent to browser
DEBUG - 2011-09-27 01:27:17 --> Total execution time: 1.9135
DEBUG - 2011-09-27 01:27:21 --> Config Class Initialized
DEBUG - 2011-09-27 01:27:21 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:27:21 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:27:21 --> URI Class Initialized
DEBUG - 2011-09-27 01:27:21 --> Router Class Initialized
DEBUG - 2011-09-27 01:27:21 --> No URI present. Default controller set.
DEBUG - 2011-09-27 01:27:21 --> Output Class Initialized
DEBUG - 2011-09-27 01:27:21 --> Input Class Initialized
DEBUG - 2011-09-27 01:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:27:21 --> Language Class Initialized
DEBUG - 2011-09-27 01:27:21 --> Loader Class Initialized
DEBUG - 2011-09-27 01:27:21 --> Controller Class Initialized
DEBUG - 2011-09-27 01:27:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-27 01:27:21 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:27:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:27:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:27:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:27:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:27:21 --> Final output sent to browser
DEBUG - 2011-09-27 01:27:21 --> Total execution time: 0.0493
DEBUG - 2011-09-27 01:27:30 --> Config Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:27:30 --> URI Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Router Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Output Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Input Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:27:30 --> Language Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Loader Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Controller Class Initialized
ERROR - 2011-09-27 01:27:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:27:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:27:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:27:30 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:27:30 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:27:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:27:30 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:27:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:27:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:27:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:27:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:27:30 --> Final output sent to browser
DEBUG - 2011-09-27 01:27:30 --> Total execution time: 0.1343
DEBUG - 2011-09-27 01:27:33 --> Config Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:27:33 --> URI Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Router Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Output Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Input Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:27:33 --> Language Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Loader Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Controller Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:27:33 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:27:34 --> Final output sent to browser
DEBUG - 2011-09-27 01:27:34 --> Total execution time: 0.9649
DEBUG - 2011-09-27 01:27:40 --> Config Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:27:40 --> URI Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Router Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Output Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Input Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:27:40 --> Language Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Loader Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Controller Class Initialized
ERROR - 2011-09-27 01:27:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:27:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:27:40 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:27:40 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:27:40 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:27:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:27:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:27:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:27:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:27:40 --> Final output sent to browser
DEBUG - 2011-09-27 01:27:40 --> Total execution time: 0.1003
DEBUG - 2011-09-27 01:27:42 --> Config Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:27:42 --> URI Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Router Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Output Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Input Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:27:42 --> Language Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Loader Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Controller Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:27:42 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:27:43 --> Final output sent to browser
DEBUG - 2011-09-27 01:27:43 --> Total execution time: 0.6240
DEBUG - 2011-09-27 01:27:58 --> Config Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:27:58 --> URI Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Router Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Output Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Input Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:27:58 --> Language Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Loader Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Controller Class Initialized
ERROR - 2011-09-27 01:27:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:27:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:27:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:27:58 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Model Class Initialized
DEBUG - 2011-09-27 01:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:27:58 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:27:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:27:58 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:27:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:27:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:27:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:27:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:27:58 --> Final output sent to browser
DEBUG - 2011-09-27 01:27:58 --> Total execution time: 0.1593
DEBUG - 2011-09-27 01:28:02 --> Config Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:28:02 --> URI Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Router Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Output Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Input Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:28:02 --> Language Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Loader Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Controller Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:28:02 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:28:03 --> Final output sent to browser
DEBUG - 2011-09-27 01:28:03 --> Total execution time: 0.9507
DEBUG - 2011-09-27 01:28:20 --> Config Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:28:20 --> URI Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Router Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Output Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Input Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:28:20 --> Language Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Loader Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Controller Class Initialized
ERROR - 2011-09-27 01:28:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:28:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:28:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:28:20 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:28:20 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:28:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:28:20 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:28:20 --> Final output sent to browser
DEBUG - 2011-09-27 01:28:20 --> Total execution time: 0.1502
DEBUG - 2011-09-27 01:28:32 --> Config Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:28:32 --> URI Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Router Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Output Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Input Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:28:32 --> Language Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Loader Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Controller Class Initialized
ERROR - 2011-09-27 01:28:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:28:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:28:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:28:32 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:28:32 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:28:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:28:32 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:28:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:28:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:28:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:28:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:28:32 --> Final output sent to browser
DEBUG - 2011-09-27 01:28:32 --> Total execution time: 0.2654
DEBUG - 2011-09-27 01:28:35 --> Config Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:28:35 --> URI Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Router Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Output Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Input Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:28:35 --> Language Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Loader Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Controller Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:28:35 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:28:36 --> Final output sent to browser
DEBUG - 2011-09-27 01:28:36 --> Total execution time: 1.1114
DEBUG - 2011-09-27 01:28:52 --> Config Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:28:52 --> URI Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Router Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Output Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Input Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:28:52 --> Language Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Loader Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Controller Class Initialized
ERROR - 2011-09-27 01:28:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 01:28:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 01:28:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:28:52 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Model Class Initialized
DEBUG - 2011-09-27 01:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:28:52 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:28:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 01:28:52 --> Helper loaded: url_helper
DEBUG - 2011-09-27 01:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 01:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 01:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 01:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 01:28:52 --> Final output sent to browser
DEBUG - 2011-09-27 01:28:52 --> Total execution time: 0.2575
DEBUG - 2011-09-27 01:29:09 --> Config Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Hooks Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Utf8 Class Initialized
DEBUG - 2011-09-27 01:29:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 01:29:09 --> URI Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Router Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Output Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Input Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 01:29:09 --> Language Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Loader Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Controller Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Model Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Model Class Initialized
DEBUG - 2011-09-27 01:29:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 01:29:09 --> Database Driver Class Initialized
DEBUG - 2011-09-27 01:29:10 --> Final output sent to browser
DEBUG - 2011-09-27 01:29:10 --> Total execution time: 0.6844
DEBUG - 2011-09-27 02:14:40 --> Config Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Hooks Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Utf8 Class Initialized
DEBUG - 2011-09-27 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 02:14:40 --> URI Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Router Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Output Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Input Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 02:14:40 --> Language Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Loader Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Controller Class Initialized
ERROR - 2011-09-27 02:14:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 02:14:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 02:14:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 02:14:40 --> Model Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Model Class Initialized
DEBUG - 2011-09-27 02:14:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 02:14:40 --> Database Driver Class Initialized
DEBUG - 2011-09-27 02:14:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 02:14:40 --> Helper loaded: url_helper
DEBUG - 2011-09-27 02:14:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 02:14:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 02:14:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 02:14:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 02:14:40 --> Final output sent to browser
DEBUG - 2011-09-27 02:14:40 --> Total execution time: 0.7568
DEBUG - 2011-09-27 02:15:30 --> Config Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Hooks Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Utf8 Class Initialized
DEBUG - 2011-09-27 02:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 02:15:30 --> URI Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Router Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Output Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Input Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 02:15:30 --> Language Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Loader Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Controller Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Model Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Model Class Initialized
DEBUG - 2011-09-27 02:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 02:15:30 --> Database Driver Class Initialized
DEBUG - 2011-09-27 02:15:31 --> Final output sent to browser
DEBUG - 2011-09-27 02:15:31 --> Total execution time: 0.9603
DEBUG - 2011-09-27 02:15:43 --> Config Class Initialized
DEBUG - 2011-09-27 02:15:43 --> Hooks Class Initialized
DEBUG - 2011-09-27 02:15:43 --> Utf8 Class Initialized
DEBUG - 2011-09-27 02:15:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 02:15:43 --> URI Class Initialized
DEBUG - 2011-09-27 02:15:43 --> Router Class Initialized
ERROR - 2011-09-27 02:15:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 03:32:26 --> Config Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Hooks Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Utf8 Class Initialized
DEBUG - 2011-09-27 03:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 03:32:26 --> URI Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Router Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Output Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Input Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 03:32:26 --> Language Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Loader Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Controller Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 03:32:26 --> Database Driver Class Initialized
DEBUG - 2011-09-27 03:32:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 03:32:27 --> Helper loaded: url_helper
DEBUG - 2011-09-27 03:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 03:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 03:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 03:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 03:32:27 --> Final output sent to browser
DEBUG - 2011-09-27 03:32:27 --> Total execution time: 1.8396
DEBUG - 2011-09-27 03:32:32 --> Config Class Initialized
DEBUG - 2011-09-27 03:32:32 --> Hooks Class Initialized
DEBUG - 2011-09-27 03:32:32 --> Utf8 Class Initialized
DEBUG - 2011-09-27 03:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 03:32:32 --> URI Class Initialized
DEBUG - 2011-09-27 03:32:32 --> Router Class Initialized
ERROR - 2011-09-27 03:32:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 03:32:43 --> Config Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Hooks Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Utf8 Class Initialized
DEBUG - 2011-09-27 03:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 03:32:43 --> URI Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Router Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Output Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Input Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 03:32:43 --> Language Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Loader Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Controller Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 03:32:43 --> Database Driver Class Initialized
DEBUG - 2011-09-27 03:32:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 03:32:43 --> Helper loaded: url_helper
DEBUG - 2011-09-27 03:32:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 03:32:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 03:32:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 03:32:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 03:32:43 --> Final output sent to browser
DEBUG - 2011-09-27 03:32:43 --> Total execution time: 0.2691
DEBUG - 2011-09-27 03:32:44 --> Config Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Hooks Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Utf8 Class Initialized
DEBUG - 2011-09-27 03:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 03:32:44 --> URI Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Router Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Output Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Input Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 03:32:44 --> Language Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Loader Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Controller Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Model Class Initialized
DEBUG - 2011-09-27 03:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 03:32:44 --> Database Driver Class Initialized
DEBUG - 2011-09-27 03:32:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 03:32:45 --> Helper loaded: url_helper
DEBUG - 2011-09-27 03:32:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 03:32:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 03:32:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 03:32:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 03:32:45 --> Final output sent to browser
DEBUG - 2011-09-27 03:32:45 --> Total execution time: 0.0569
DEBUG - 2011-09-27 04:00:19 --> Config Class Initialized
DEBUG - 2011-09-27 04:00:19 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:00:19 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:00:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:00:19 --> URI Class Initialized
DEBUG - 2011-09-27 04:00:19 --> Router Class Initialized
ERROR - 2011-09-27 04:00:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-27 04:20:13 --> Config Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:20:13 --> URI Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Router Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Output Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Input Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:20:13 --> Language Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Loader Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Controller Class Initialized
ERROR - 2011-09-27 04:20:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 04:20:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 04:20:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:20:13 --> Model Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Model Class Initialized
DEBUG - 2011-09-27 04:20:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:20:13 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:20:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:20:14 --> Helper loaded: url_helper
DEBUG - 2011-09-27 04:20:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 04:20:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 04:20:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 04:20:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 04:20:14 --> Final output sent to browser
DEBUG - 2011-09-27 04:20:14 --> Total execution time: 1.6157
DEBUG - 2011-09-27 04:21:00 --> Config Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:21:00 --> URI Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Router Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Output Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Input Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:21:00 --> Language Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Loader Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Controller Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Model Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Model Class Initialized
DEBUG - 2011-09-27 04:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:21:00 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Config Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:21:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:21:26 --> URI Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Router Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Output Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Input Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:21:26 --> Language Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Loader Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Controller Class Initialized
ERROR - 2011-09-27 04:21:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 04:21:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 04:21:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:21:26 --> Model Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Model Class Initialized
DEBUG - 2011-09-27 04:21:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:21:26 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:21:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:21:26 --> Helper loaded: url_helper
DEBUG - 2011-09-27 04:21:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 04:21:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 04:21:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 04:21:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 04:21:26 --> Final output sent to browser
DEBUG - 2011-09-27 04:21:26 --> Total execution time: 0.0498
DEBUG - 2011-09-27 04:21:26 --> Final output sent to browser
DEBUG - 2011-09-27 04:21:26 --> Total execution time: 26.0259
DEBUG - 2011-09-27 04:21:29 --> Config Class Initialized
DEBUG - 2011-09-27 04:21:29 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:21:29 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:21:29 --> URI Class Initialized
DEBUG - 2011-09-27 04:21:29 --> Router Class Initialized
ERROR - 2011-09-27 04:21:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 04:21:33 --> Config Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:21:33 --> URI Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Router Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Output Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Input Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:21:33 --> Language Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Loader Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Controller Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Model Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Model Class Initialized
DEBUG - 2011-09-27 04:21:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:21:33 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:21:36 --> Final output sent to browser
DEBUG - 2011-09-27 04:21:36 --> Total execution time: 3.0075
DEBUG - 2011-09-27 04:21:58 --> Config Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:21:58 --> URI Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Router Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Output Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Input Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:21:58 --> Language Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Loader Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Controller Class Initialized
ERROR - 2011-09-27 04:21:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 04:21:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 04:21:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:21:58 --> Model Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Model Class Initialized
DEBUG - 2011-09-27 04:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:21:58 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:21:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:21:58 --> Helper loaded: url_helper
DEBUG - 2011-09-27 04:21:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 04:21:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 04:21:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 04:21:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 04:21:58 --> Final output sent to browser
DEBUG - 2011-09-27 04:21:58 --> Total execution time: 0.0619
DEBUG - 2011-09-27 04:22:17 --> Config Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:22:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:22:17 --> URI Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Router Class Initialized
ERROR - 2011-09-27 04:22:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 04:22:17 --> Config Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:22:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:22:17 --> URI Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Router Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Output Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Input Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:22:17 --> Language Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Loader Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Controller Class Initialized
ERROR - 2011-09-27 04:22:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 04:22:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 04:22:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:22:17 --> Model Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Model Class Initialized
DEBUG - 2011-09-27 04:22:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:22:17 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:22:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:22:17 --> Helper loaded: url_helper
DEBUG - 2011-09-27 04:22:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 04:22:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 04:22:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 04:22:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 04:22:17 --> Final output sent to browser
DEBUG - 2011-09-27 04:22:17 --> Total execution time: 0.0365
DEBUG - 2011-09-27 04:22:19 --> Config Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:22:19 --> URI Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Router Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Output Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Input Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:22:19 --> Language Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Loader Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Controller Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Model Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Model Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:22:19 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:22:19 --> Final output sent to browser
DEBUG - 2011-09-27 04:22:19 --> Total execution time: 0.7307
DEBUG - 2011-09-27 04:23:11 --> Config Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:23:11 --> URI Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Router Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Output Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Input Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:23:11 --> Language Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Loader Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Controller Class Initialized
ERROR - 2011-09-27 04:23:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 04:23:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 04:23:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:23:11 --> Model Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Model Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:23:11 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:23:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:23:11 --> Helper loaded: url_helper
DEBUG - 2011-09-27 04:23:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 04:23:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 04:23:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 04:23:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 04:23:11 --> Final output sent to browser
DEBUG - 2011-09-27 04:23:11 --> Total execution time: 0.0758
DEBUG - 2011-09-27 04:23:11 --> Config Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:23:11 --> URI Class Initialized
DEBUG - 2011-09-27 04:23:11 --> Router Class Initialized
ERROR - 2011-09-27 04:23:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 04:23:14 --> Config Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:23:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:23:14 --> URI Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Router Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Output Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Input Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:23:14 --> Language Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Loader Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Controller Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Model Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Model Class Initialized
DEBUG - 2011-09-27 04:23:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:23:14 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:23:15 --> Final output sent to browser
DEBUG - 2011-09-27 04:23:15 --> Total execution time: 1.2665
DEBUG - 2011-09-27 04:23:23 --> Config Class Initialized
DEBUG - 2011-09-27 04:23:23 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:23:23 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:23:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:23:23 --> URI Class Initialized
DEBUG - 2011-09-27 04:23:23 --> Router Class Initialized
ERROR - 2011-09-27 04:23:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 04:23:23 --> Config Class Initialized
DEBUG - 2011-09-27 04:23:23 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:23:23 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:23:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:23:23 --> URI Class Initialized
DEBUG - 2011-09-27 04:23:23 --> Router Class Initialized
ERROR - 2011-09-27 04:23:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 04:23:38 --> Config Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:23:38 --> URI Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Router Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Output Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Input Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:23:38 --> Language Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Loader Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Controller Class Initialized
ERROR - 2011-09-27 04:23:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 04:23:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 04:23:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:23:38 --> Model Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Model Class Initialized
DEBUG - 2011-09-27 04:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:23:38 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:23:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:23:38 --> Helper loaded: url_helper
DEBUG - 2011-09-27 04:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 04:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 04:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 04:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 04:23:38 --> Final output sent to browser
DEBUG - 2011-09-27 04:23:38 --> Total execution time: 0.0419
DEBUG - 2011-09-27 04:24:49 --> Config Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:24:49 --> URI Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Router Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Output Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Input Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:24:49 --> Language Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Loader Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Controller Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Model Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Model Class Initialized
DEBUG - 2011-09-27 04:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:24:49 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:24:51 --> Final output sent to browser
DEBUG - 2011-09-27 04:24:51 --> Total execution time: 1.9673
DEBUG - 2011-09-27 04:25:01 --> Config Class Initialized
DEBUG - 2011-09-27 04:25:01 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:25:01 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:25:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:25:01 --> URI Class Initialized
DEBUG - 2011-09-27 04:25:01 --> Router Class Initialized
ERROR - 2011-09-27 04:25:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 04:25:01 --> Config Class Initialized
DEBUG - 2011-09-27 04:25:01 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:25:01 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:25:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:25:01 --> URI Class Initialized
DEBUG - 2011-09-27 04:25:01 --> Router Class Initialized
ERROR - 2011-09-27 04:25:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 04:25:24 --> Config Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:25:24 --> URI Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Router Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Output Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Input Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:25:24 --> Language Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Loader Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Controller Class Initialized
ERROR - 2011-09-27 04:25:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 04:25:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 04:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:25:24 --> Model Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Model Class Initialized
DEBUG - 2011-09-27 04:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:25:24 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:25:24 --> Helper loaded: url_helper
DEBUG - 2011-09-27 04:25:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 04:25:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 04:25:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 04:25:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 04:25:24 --> Final output sent to browser
DEBUG - 2011-09-27 04:25:24 --> Total execution time: 0.0439
DEBUG - 2011-09-27 04:25:27 --> Config Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:25:27 --> URI Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Router Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Output Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Input Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:25:27 --> Language Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Loader Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Controller Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Model Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Model Class Initialized
DEBUG - 2011-09-27 04:25:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:25:27 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:25:30 --> Final output sent to browser
DEBUG - 2011-09-27 04:25:30 --> Total execution time: 2.7104
DEBUG - 2011-09-27 04:25:32 --> Config Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:25:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:25:32 --> URI Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Router Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Output Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Input Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 04:25:32 --> Language Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Loader Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Controller Class Initialized
ERROR - 2011-09-27 04:25:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 04:25:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 04:25:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:25:32 --> Model Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Model Class Initialized
DEBUG - 2011-09-27 04:25:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 04:25:32 --> Database Driver Class Initialized
DEBUG - 2011-09-27 04:25:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 04:25:32 --> Helper loaded: url_helper
DEBUG - 2011-09-27 04:25:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 04:25:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 04:25:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 04:25:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 04:25:32 --> Final output sent to browser
DEBUG - 2011-09-27 04:25:32 --> Total execution time: 0.0531
DEBUG - 2011-09-27 04:25:43 --> Config Class Initialized
DEBUG - 2011-09-27 04:25:43 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:25:43 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:25:43 --> URI Class Initialized
DEBUG - 2011-09-27 04:25:43 --> Router Class Initialized
ERROR - 2011-09-27 04:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 04:25:43 --> Config Class Initialized
DEBUG - 2011-09-27 04:25:43 --> Hooks Class Initialized
DEBUG - 2011-09-27 04:25:43 --> Utf8 Class Initialized
DEBUG - 2011-09-27 04:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 04:25:43 --> URI Class Initialized
DEBUG - 2011-09-27 04:25:43 --> Router Class Initialized
ERROR - 2011-09-27 04:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 06:33:32 --> Config Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:33:32 --> URI Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Router Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Output Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Input Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:33:32 --> Language Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Loader Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Controller Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Model Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Model Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Model Class Initialized
DEBUG - 2011-09-27 06:33:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:33:32 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:33:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:33:33 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:33:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:33:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:33:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:33:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:33:33 --> Final output sent to browser
DEBUG - 2011-09-27 06:33:33 --> Total execution time: 1.6809
DEBUG - 2011-09-27 06:33:48 --> Config Class Initialized
DEBUG - 2011-09-27 06:33:48 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:33:48 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:33:48 --> URI Class Initialized
DEBUG - 2011-09-27 06:33:48 --> Router Class Initialized
ERROR - 2011-09-27 06:33:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 06:35:06 --> Config Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:35:06 --> URI Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Router Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Output Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Input Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:35:06 --> Language Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Loader Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Controller Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:35:06 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:35:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:35:06 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:35:06 --> Final output sent to browser
DEBUG - 2011-09-27 06:35:06 --> Total execution time: 0.4573
DEBUG - 2011-09-27 06:35:09 --> Config Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:35:09 --> URI Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Router Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Output Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Input Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:35:09 --> Language Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Loader Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Controller Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:35:09 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:35:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:35:09 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:35:09 --> Final output sent to browser
DEBUG - 2011-09-27 06:35:09 --> Total execution time: 0.1758
DEBUG - 2011-09-27 06:35:44 --> Config Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:35:44 --> URI Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Router Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Output Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Input Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:35:44 --> Language Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Loader Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Controller Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:35:44 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:35:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:35:44 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:35:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:35:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:35:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:35:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:35:44 --> Final output sent to browser
DEBUG - 2011-09-27 06:35:44 --> Total execution time: 0.2848
DEBUG - 2011-09-27 06:35:47 --> Config Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:35:47 --> URI Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Router Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Output Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Input Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:35:47 --> Language Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Loader Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Controller Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Model Class Initialized
DEBUG - 2011-09-27 06:35:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:35:47 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:35:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:35:47 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:35:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:35:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:35:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:35:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:35:47 --> Final output sent to browser
DEBUG - 2011-09-27 06:35:47 --> Total execution time: 0.0848
DEBUG - 2011-09-27 06:36:03 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:03 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:03 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:03 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:03 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:04 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:04 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:04 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:04 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:04 --> Total execution time: 0.0813
DEBUG - 2011-09-27 06:36:06 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:06 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:06 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:06 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:06 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:06 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:06 --> Total execution time: 0.2994
DEBUG - 2011-09-27 06:36:08 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:08 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:08 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:08 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:08 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:08 --> Router Class Initialized
ERROR - 2011-09-27 06:36:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 06:36:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:08 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:08 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:08 --> Total execution time: 0.0664
DEBUG - 2011-09-27 06:36:19 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:19 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:19 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:19 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:20 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:20 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:20 --> Total execution time: 0.4069
DEBUG - 2011-09-27 06:36:22 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:22 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:22 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:22 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:22 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:22 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:22 --> Total execution time: 0.0796
DEBUG - 2011-09-27 06:36:39 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:39 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:39 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:39 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:40 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:40 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:40 --> Total execution time: 0.6134
DEBUG - 2011-09-27 06:36:42 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:42 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:42 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:42 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:42 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:42 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:42 --> Total execution time: 0.0608
DEBUG - 2011-09-27 06:36:42 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:42 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:42 --> Router Class Initialized
ERROR - 2011-09-27 06:36:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 06:36:46 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:46 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:46 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:46 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:47 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:47 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:47 --> Total execution time: 0.6178
DEBUG - 2011-09-27 06:36:48 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:48 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:48 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:48 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:48 --> Router Class Initialized
ERROR - 2011-09-27 06:36:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 06:36:49 --> Config Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:36:49 --> URI Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Router Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Output Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Input Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:36:49 --> Language Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Loader Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Controller Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Model Class Initialized
DEBUG - 2011-09-27 06:36:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:36:49 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:36:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 06:36:49 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:36:49 --> Final output sent to browser
DEBUG - 2011-09-27 06:36:49 --> Total execution time: 0.5740
DEBUG - 2011-09-27 06:46:06 --> Config Class Initialized
DEBUG - 2011-09-27 06:46:06 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:46:06 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:46:06 --> URI Class Initialized
DEBUG - 2011-09-27 06:46:06 --> Router Class Initialized
ERROR - 2011-09-27 06:46:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-27 06:46:07 --> Config Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:46:07 --> URI Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Router Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Output Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Input Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:46:07 --> Language Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Loader Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Controller Class Initialized
ERROR - 2011-09-27 06:46:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 06:46:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 06:46:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 06:46:07 --> Model Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Model Class Initialized
DEBUG - 2011-09-27 06:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:46:07 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:46:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 06:46:07 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:46:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:46:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:46:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:46:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:46:07 --> Final output sent to browser
DEBUG - 2011-09-27 06:46:07 --> Total execution time: 0.1151
DEBUG - 2011-09-27 06:49:15 --> Config Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:49:15 --> URI Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Router Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Output Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Input Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:49:15 --> Language Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Loader Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Controller Class Initialized
ERROR - 2011-09-27 06:49:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 06:49:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 06:49:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 06:49:15 --> Model Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Model Class Initialized
DEBUG - 2011-09-27 06:49:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:49:15 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:49:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 06:49:15 --> Helper loaded: url_helper
DEBUG - 2011-09-27 06:49:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 06:49:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 06:49:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 06:49:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 06:49:15 --> Final output sent to browser
DEBUG - 2011-09-27 06:49:15 --> Total execution time: 0.0589
DEBUG - 2011-09-27 06:49:16 --> Config Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Hooks Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Utf8 Class Initialized
DEBUG - 2011-09-27 06:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 06:49:16 --> URI Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Router Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Output Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Input Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 06:49:16 --> Language Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Loader Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Controller Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Model Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Model Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 06:49:16 --> Database Driver Class Initialized
DEBUG - 2011-09-27 06:49:16 --> Final output sent to browser
DEBUG - 2011-09-27 06:49:16 --> Total execution time: 0.7311
DEBUG - 2011-09-27 08:23:54 --> Config Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:23:54 --> URI Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Router Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Output Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Input Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:23:54 --> Language Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Loader Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Controller Class Initialized
ERROR - 2011-09-27 08:23:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 08:23:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 08:23:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 08:23:54 --> Model Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Model Class Initialized
DEBUG - 2011-09-27 08:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:23:54 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 08:23:55 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:23:55 --> Final output sent to browser
DEBUG - 2011-09-27 08:23:55 --> Total execution time: 1.3887
DEBUG - 2011-09-27 08:23:56 --> Config Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:23:56 --> URI Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Router Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Output Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Input Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:23:56 --> Language Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Loader Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Controller Class Initialized
DEBUG - 2011-09-27 08:23:56 --> Model Class Initialized
DEBUG - 2011-09-27 08:23:57 --> Model Class Initialized
DEBUG - 2011-09-27 08:23:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:23:57 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:23:58 --> Final output sent to browser
DEBUG - 2011-09-27 08:23:58 --> Total execution time: 1.4137
DEBUG - 2011-09-27 08:24:18 --> Config Class Initialized
DEBUG - 2011-09-27 08:24:18 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:24:18 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:24:18 --> URI Class Initialized
DEBUG - 2011-09-27 08:24:18 --> Router Class Initialized
ERROR - 2011-09-27 08:24:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:24:19 --> Config Class Initialized
DEBUG - 2011-09-27 08:24:19 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:24:19 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:24:19 --> URI Class Initialized
DEBUG - 2011-09-27 08:24:19 --> Router Class Initialized
ERROR - 2011-09-27 08:24:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:31:53 --> Config Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:31:53 --> URI Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Router Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Output Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Input Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:31:53 --> Language Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Loader Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Controller Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Model Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Model Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Model Class Initialized
DEBUG - 2011-09-27 08:31:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:31:53 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:31:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:31:54 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:31:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:31:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:31:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:31:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:31:54 --> Final output sent to browser
DEBUG - 2011-09-27 08:31:54 --> Total execution time: 0.6934
DEBUG - 2011-09-27 08:31:56 --> Config Class Initialized
DEBUG - 2011-09-27 08:31:56 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:31:56 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:31:56 --> URI Class Initialized
DEBUG - 2011-09-27 08:31:56 --> Router Class Initialized
ERROR - 2011-09-27 08:31:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:32:30 --> Config Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:32:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:32:30 --> URI Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Router Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Output Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Input Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:32:30 --> Language Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Loader Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Controller Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Model Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Model Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Model Class Initialized
DEBUG - 2011-09-27 08:32:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:32:30 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:32:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:32:30 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:32:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:32:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:32:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:32:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:32:30 --> Final output sent to browser
DEBUG - 2011-09-27 08:32:30 --> Total execution time: 0.6079
DEBUG - 2011-09-27 08:32:32 --> Config Class Initialized
DEBUG - 2011-09-27 08:32:32 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:32:32 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:32:32 --> URI Class Initialized
DEBUG - 2011-09-27 08:32:32 --> Router Class Initialized
ERROR - 2011-09-27 08:32:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:32:52 --> Config Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:32:52 --> URI Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Router Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Output Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Input Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:32:52 --> Language Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Loader Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Controller Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Model Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Model Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Model Class Initialized
DEBUG - 2011-09-27 08:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:32:52 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:32:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:32:53 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:32:53 --> Final output sent to browser
DEBUG - 2011-09-27 08:32:53 --> Total execution time: 0.2640
DEBUG - 2011-09-27 08:32:54 --> Config Class Initialized
DEBUG - 2011-09-27 08:32:54 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:32:54 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:32:54 --> URI Class Initialized
DEBUG - 2011-09-27 08:32:54 --> Router Class Initialized
ERROR - 2011-09-27 08:32:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:33:05 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:05 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Router Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Output Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Input Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:33:05 --> Language Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Loader Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Controller Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:33:05 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:33:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:33:05 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:33:05 --> Final output sent to browser
DEBUG - 2011-09-27 08:33:05 --> Total execution time: 0.4246
DEBUG - 2011-09-27 08:33:08 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:08 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Router Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Output Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Input Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:33:08 --> Language Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Loader Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Controller Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:33:08 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:33:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:33:08 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:33:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:33:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:33:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:33:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:33:08 --> Final output sent to browser
DEBUG - 2011-09-27 08:33:08 --> Total execution time: 0.5200
DEBUG - 2011-09-27 08:33:10 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:10 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:10 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:10 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:10 --> Router Class Initialized
ERROR - 2011-09-27 08:33:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:33:22 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:22 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Router Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Output Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Input Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:33:22 --> Language Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Loader Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Controller Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:33:22 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:33:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:33:22 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:33:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:33:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:33:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:33:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:33:22 --> Final output sent to browser
DEBUG - 2011-09-27 08:33:22 --> Total execution time: 0.0828
DEBUG - 2011-09-27 08:33:25 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:25 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Router Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Output Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Input Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:33:25 --> Language Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Loader Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Controller Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:33:25 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:33:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:33:25 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:33:25 --> Final output sent to browser
DEBUG - 2011-09-27 08:33:25 --> Total execution time: 0.0545
DEBUG - 2011-09-27 08:33:29 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:29 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Router Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Output Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Input Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:33:29 --> Language Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Loader Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Controller Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:33:29 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:33:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:33:29 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:33:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:33:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:33:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:33:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:33:29 --> Final output sent to browser
DEBUG - 2011-09-27 08:33:29 --> Total execution time: 0.4389
DEBUG - 2011-09-27 08:33:30 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:30 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Router Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Output Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Input Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:33:30 --> Language Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Loader Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Controller Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:33:30 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:33:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:33:30 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:33:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:33:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:33:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:33:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:33:30 --> Final output sent to browser
DEBUG - 2011-09-27 08:33:30 --> Total execution time: 0.0642
DEBUG - 2011-09-27 08:33:31 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:31 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:31 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:31 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:31 --> Router Class Initialized
ERROR - 2011-09-27 08:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:33:49 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:49 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Router Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Output Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Input Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:33:49 --> Language Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Loader Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Controller Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:33:49 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:33:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:33:50 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:33:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:33:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:33:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:33:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:33:50 --> Final output sent to browser
DEBUG - 2011-09-27 08:33:50 --> Total execution time: 1.4960
DEBUG - 2011-09-27 08:33:52 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:52 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:52 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:52 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:52 --> Router Class Initialized
ERROR - 2011-09-27 08:33:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:33:54 --> Config Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:33:54 --> URI Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Router Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Output Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Input Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:33:54 --> Language Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Loader Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Controller Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Model Class Initialized
DEBUG - 2011-09-27 08:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:33:54 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:33:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:33:54 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:33:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:33:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:33:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:33:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:33:54 --> Final output sent to browser
DEBUG - 2011-09-27 08:33:54 --> Total execution time: 0.0919
DEBUG - 2011-09-27 08:34:13 --> Config Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:34:13 --> URI Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Router Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Output Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Input Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:34:13 --> Language Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Loader Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Controller Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Model Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Model Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Model Class Initialized
DEBUG - 2011-09-27 08:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:34:13 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:34:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:34:14 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:34:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:34:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:34:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:34:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:34:14 --> Final output sent to browser
DEBUG - 2011-09-27 08:34:14 --> Total execution time: 0.8877
DEBUG - 2011-09-27 08:34:16 --> Config Class Initialized
DEBUG - 2011-09-27 08:34:16 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:34:16 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:34:16 --> URI Class Initialized
DEBUG - 2011-09-27 08:34:16 --> Router Class Initialized
ERROR - 2011-09-27 08:34:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 08:35:54 --> Config Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:35:54 --> URI Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Router Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Output Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Input Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:35:54 --> Language Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Loader Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Controller Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Model Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Model Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Model Class Initialized
DEBUG - 2011-09-27 08:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 08:35:54 --> Database Driver Class Initialized
DEBUG - 2011-09-27 08:35:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 08:35:54 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:35:54 --> Final output sent to browser
DEBUG - 2011-09-27 08:35:54 --> Total execution time: 0.1153
DEBUG - 2011-09-27 08:40:49 --> Config Class Initialized
DEBUG - 2011-09-27 08:40:49 --> Hooks Class Initialized
DEBUG - 2011-09-27 08:40:49 --> Utf8 Class Initialized
DEBUG - 2011-09-27 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 08:40:49 --> URI Class Initialized
DEBUG - 2011-09-27 08:40:49 --> Router Class Initialized
DEBUG - 2011-09-27 08:40:49 --> No URI present. Default controller set.
DEBUG - 2011-09-27 08:40:49 --> Output Class Initialized
DEBUG - 2011-09-27 08:40:49 --> Input Class Initialized
DEBUG - 2011-09-27 08:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 08:40:49 --> Language Class Initialized
DEBUG - 2011-09-27 08:40:49 --> Loader Class Initialized
DEBUG - 2011-09-27 08:40:49 --> Controller Class Initialized
DEBUG - 2011-09-27 08:40:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-27 08:40:49 --> Helper loaded: url_helper
DEBUG - 2011-09-27 08:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 08:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 08:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 08:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 08:40:49 --> Final output sent to browser
DEBUG - 2011-09-27 08:40:49 --> Total execution time: 0.0796
DEBUG - 2011-09-27 09:06:26 --> Config Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Hooks Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Utf8 Class Initialized
DEBUG - 2011-09-27 09:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 09:06:26 --> URI Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Router Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Output Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Input Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 09:06:26 --> Language Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Loader Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Controller Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Model Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Model Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Model Class Initialized
DEBUG - 2011-09-27 09:06:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 09:06:26 --> Database Driver Class Initialized
DEBUG - 2011-09-27 09:06:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 09:06:27 --> Helper loaded: url_helper
DEBUG - 2011-09-27 09:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 09:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 09:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 09:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 09:06:27 --> Final output sent to browser
DEBUG - 2011-09-27 09:06:27 --> Total execution time: 1.4421
DEBUG - 2011-09-27 09:06:31 --> Config Class Initialized
DEBUG - 2011-09-27 09:06:31 --> Hooks Class Initialized
DEBUG - 2011-09-27 09:06:31 --> Utf8 Class Initialized
DEBUG - 2011-09-27 09:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 09:06:31 --> URI Class Initialized
DEBUG - 2011-09-27 09:06:31 --> Router Class Initialized
ERROR - 2011-09-27 09:06:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 09:06:40 --> Config Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Hooks Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Utf8 Class Initialized
DEBUG - 2011-09-27 09:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 09:06:40 --> URI Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Router Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Output Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Input Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 09:06:40 --> Language Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Loader Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Controller Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Model Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Model Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Model Class Initialized
DEBUG - 2011-09-27 09:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 09:06:40 --> Database Driver Class Initialized
DEBUG - 2011-09-27 09:06:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 09:06:40 --> Helper loaded: url_helper
DEBUG - 2011-09-27 09:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 09:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 09:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 09:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 09:06:40 --> Final output sent to browser
DEBUG - 2011-09-27 09:06:40 --> Total execution time: 0.2873
DEBUG - 2011-09-27 09:06:42 --> Config Class Initialized
DEBUG - 2011-09-27 09:06:42 --> Hooks Class Initialized
DEBUG - 2011-09-27 09:06:42 --> Utf8 Class Initialized
DEBUG - 2011-09-27 09:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 09:06:42 --> URI Class Initialized
DEBUG - 2011-09-27 09:06:42 --> Router Class Initialized
ERROR - 2011-09-27 09:06:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 09:07:10 --> Config Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Hooks Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Utf8 Class Initialized
DEBUG - 2011-09-27 09:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 09:07:10 --> URI Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Router Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Output Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Input Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 09:07:10 --> Language Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Loader Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Controller Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Model Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Model Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Model Class Initialized
DEBUG - 2011-09-27 09:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 09:07:10 --> Database Driver Class Initialized
DEBUG - 2011-09-27 09:07:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 09:07:10 --> Helper loaded: url_helper
DEBUG - 2011-09-27 09:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 09:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 09:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 09:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 09:07:10 --> Final output sent to browser
DEBUG - 2011-09-27 09:07:10 --> Total execution time: 0.0605
DEBUG - 2011-09-27 09:48:51 --> Config Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Hooks Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Utf8 Class Initialized
DEBUG - 2011-09-27 09:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 09:48:51 --> URI Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Router Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Output Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Input Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 09:48:51 --> Language Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Loader Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Controller Class Initialized
ERROR - 2011-09-27 09:48:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 09:48:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 09:48:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 09:48:51 --> Model Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Model Class Initialized
DEBUG - 2011-09-27 09:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 09:48:51 --> Database Driver Class Initialized
DEBUG - 2011-09-27 09:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 09:48:52 --> Helper loaded: url_helper
DEBUG - 2011-09-27 09:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 09:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 09:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 09:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 09:48:52 --> Final output sent to browser
DEBUG - 2011-09-27 09:48:52 --> Total execution time: 0.9737
DEBUG - 2011-09-27 10:03:33 --> Config Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Hooks Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Utf8 Class Initialized
DEBUG - 2011-09-27 10:03:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 10:03:33 --> URI Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Router Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Output Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Input Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 10:03:33 --> Language Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Loader Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Controller Class Initialized
ERROR - 2011-09-27 10:03:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 10:03:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 10:03:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 10:03:33 --> Model Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Model Class Initialized
DEBUG - 2011-09-27 10:03:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 10:03:33 --> Database Driver Class Initialized
DEBUG - 2011-09-27 10:03:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 10:03:33 --> Helper loaded: url_helper
DEBUG - 2011-09-27 10:03:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 10:03:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 10:03:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 10:03:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 10:03:33 --> Final output sent to browser
DEBUG - 2011-09-27 10:03:33 --> Total execution time: 0.2303
DEBUG - 2011-09-27 10:03:50 --> Config Class Initialized
DEBUG - 2011-09-27 10:03:50 --> Hooks Class Initialized
DEBUG - 2011-09-27 10:03:50 --> Utf8 Class Initialized
DEBUG - 2011-09-27 10:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 10:03:51 --> URI Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Router Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Output Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Input Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 10:03:51 --> Language Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Loader Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Controller Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Model Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Model Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 10:03:51 --> Database Driver Class Initialized
DEBUG - 2011-09-27 10:03:51 --> Final output sent to browser
DEBUG - 2011-09-27 10:03:51 --> Total execution time: 0.9769
DEBUG - 2011-09-27 10:04:29 --> Config Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Hooks Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Utf8 Class Initialized
DEBUG - 2011-09-27 10:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 10:04:29 --> URI Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Router Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Output Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Input Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 10:04:29 --> Language Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Loader Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Controller Class Initialized
ERROR - 2011-09-27 10:04:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 10:04:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 10:04:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 10:04:29 --> Model Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Model Class Initialized
DEBUG - 2011-09-27 10:04:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 10:04:29 --> Database Driver Class Initialized
DEBUG - 2011-09-27 10:04:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 10:04:29 --> Helper loaded: url_helper
DEBUG - 2011-09-27 10:04:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 10:04:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 10:04:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 10:04:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 10:04:29 --> Final output sent to browser
DEBUG - 2011-09-27 10:04:29 --> Total execution time: 0.1073
DEBUG - 2011-09-27 10:04:34 --> Config Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Hooks Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Utf8 Class Initialized
DEBUG - 2011-09-27 10:04:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 10:04:34 --> URI Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Router Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Output Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Input Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 10:04:34 --> Language Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Loader Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Controller Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Model Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Model Class Initialized
DEBUG - 2011-09-27 10:04:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 10:04:34 --> Database Driver Class Initialized
DEBUG - 2011-09-27 10:04:35 --> Final output sent to browser
DEBUG - 2011-09-27 10:04:35 --> Total execution time: 0.6037
DEBUG - 2011-09-27 10:11:22 --> Config Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 10:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 10:11:22 --> URI Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Router Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Output Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Input Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 10:11:22 --> Language Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Loader Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Controller Class Initialized
ERROR - 2011-09-27 10:11:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 10:11:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 10:11:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 10:11:22 --> Model Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Model Class Initialized
DEBUG - 2011-09-27 10:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 10:11:22 --> Database Driver Class Initialized
DEBUG - 2011-09-27 10:11:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 10:11:22 --> Helper loaded: url_helper
DEBUG - 2011-09-27 10:11:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 10:11:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 10:11:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 10:11:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 10:11:22 --> Final output sent to browser
DEBUG - 2011-09-27 10:11:22 --> Total execution time: 0.0346
DEBUG - 2011-09-27 10:11:24 --> Config Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Hooks Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Utf8 Class Initialized
DEBUG - 2011-09-27 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 10:11:24 --> URI Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Router Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Output Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Input Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 10:11:24 --> Language Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Loader Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Controller Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Model Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Model Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 10:11:24 --> Database Driver Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Config Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Hooks Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Utf8 Class Initialized
DEBUG - 2011-09-27 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 10:11:24 --> URI Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Router Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Output Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Input Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 10:11:24 --> Language Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Loader Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Controller Class Initialized
ERROR - 2011-09-27 10:11:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 10:11:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 10:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 10:11:24 --> Model Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Model Class Initialized
DEBUG - 2011-09-27 10:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 10:11:24 --> Database Driver Class Initialized
DEBUG - 2011-09-27 10:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 10:11:24 --> Helper loaded: url_helper
DEBUG - 2011-09-27 10:11:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 10:11:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 10:11:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 10:11:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 10:11:24 --> Final output sent to browser
DEBUG - 2011-09-27 10:11:24 --> Total execution time: 0.0506
DEBUG - 2011-09-27 10:11:25 --> Final output sent to browser
DEBUG - 2011-09-27 10:11:25 --> Total execution time: 0.8539
DEBUG - 2011-09-27 11:11:43 --> Config Class Initialized
DEBUG - 2011-09-27 11:11:43 --> Hooks Class Initialized
DEBUG - 2011-09-27 11:11:43 --> Utf8 Class Initialized
DEBUG - 2011-09-27 11:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 11:11:43 --> URI Class Initialized
DEBUG - 2011-09-27 11:11:43 --> Router Class Initialized
DEBUG - 2011-09-27 11:11:43 --> No URI present. Default controller set.
DEBUG - 2011-09-27 11:11:43 --> Output Class Initialized
DEBUG - 2011-09-27 11:11:43 --> Input Class Initialized
DEBUG - 2011-09-27 11:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 11:11:43 --> Language Class Initialized
DEBUG - 2011-09-27 11:11:43 --> Loader Class Initialized
DEBUG - 2011-09-27 11:11:43 --> Controller Class Initialized
DEBUG - 2011-09-27 11:11:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-27 11:11:43 --> Helper loaded: url_helper
DEBUG - 2011-09-27 11:11:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 11:11:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 11:11:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 11:11:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 11:11:43 --> Final output sent to browser
DEBUG - 2011-09-27 11:11:43 --> Total execution time: 0.2151
DEBUG - 2011-09-27 13:22:43 --> Config Class Initialized
DEBUG - 2011-09-27 13:22:44 --> Hooks Class Initialized
DEBUG - 2011-09-27 13:22:44 --> Utf8 Class Initialized
DEBUG - 2011-09-27 13:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 13:22:44 --> URI Class Initialized
DEBUG - 2011-09-27 13:22:44 --> Router Class Initialized
ERROR - 2011-09-27 13:22:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-27 13:23:29 --> Config Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Hooks Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Utf8 Class Initialized
DEBUG - 2011-09-27 13:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 13:23:29 --> URI Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Router Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Output Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Input Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 13:23:29 --> Language Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Loader Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Controller Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Model Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Model Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Model Class Initialized
DEBUG - 2011-09-27 13:23:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 13:23:29 --> Database Driver Class Initialized
DEBUG - 2011-09-27 13:23:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 13:23:30 --> Helper loaded: url_helper
DEBUG - 2011-09-27 13:23:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 13:23:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 13:23:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 13:23:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 13:23:31 --> Final output sent to browser
DEBUG - 2011-09-27 13:23:31 --> Total execution time: 1.2852
DEBUG - 2011-09-27 15:27:07 --> Config Class Initialized
DEBUG - 2011-09-27 15:27:07 --> Hooks Class Initialized
DEBUG - 2011-09-27 15:27:07 --> Utf8 Class Initialized
DEBUG - 2011-09-27 15:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 15:27:07 --> URI Class Initialized
DEBUG - 2011-09-27 15:27:07 --> Router Class Initialized
ERROR - 2011-09-27 15:27:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-27 15:27:07 --> Config Class Initialized
DEBUG - 2011-09-27 15:27:07 --> Hooks Class Initialized
DEBUG - 2011-09-27 15:27:07 --> Utf8 Class Initialized
DEBUG - 2011-09-27 15:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 15:27:07 --> URI Class Initialized
DEBUG - 2011-09-27 15:27:07 --> Router Class Initialized
DEBUG - 2011-09-27 15:27:08 --> Output Class Initialized
DEBUG - 2011-09-27 15:27:08 --> Input Class Initialized
DEBUG - 2011-09-27 15:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 15:27:08 --> Language Class Initialized
DEBUG - 2011-09-27 15:27:08 --> Loader Class Initialized
DEBUG - 2011-09-27 15:27:08 --> Controller Class Initialized
ERROR - 2011-09-27 15:27:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 15:27:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 15:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 15:27:08 --> Model Class Initialized
DEBUG - 2011-09-27 15:27:08 --> Model Class Initialized
DEBUG - 2011-09-27 15:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 15:27:08 --> Database Driver Class Initialized
DEBUG - 2011-09-27 15:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 15:27:08 --> Helper loaded: url_helper
DEBUG - 2011-09-27 15:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 15:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 15:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 15:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 15:27:08 --> Final output sent to browser
DEBUG - 2011-09-27 15:27:08 --> Total execution time: 0.5944
DEBUG - 2011-09-27 15:32:22 --> Config Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 15:32:22 --> URI Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Router Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Output Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Input Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 15:32:22 --> Language Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Loader Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Controller Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Model Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Model Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Model Class Initialized
DEBUG - 2011-09-27 15:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 15:32:22 --> Database Driver Class Initialized
DEBUG - 2011-09-27 15:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 15:32:23 --> Helper loaded: url_helper
DEBUG - 2011-09-27 15:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 15:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 15:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 15:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 15:32:23 --> Final output sent to browser
DEBUG - 2011-09-27 15:32:23 --> Total execution time: 0.9242
DEBUG - 2011-09-27 15:48:22 --> Config Class Initialized
DEBUG - 2011-09-27 15:48:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 15:48:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 15:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 15:48:22 --> URI Class Initialized
DEBUG - 2011-09-27 15:48:22 --> Router Class Initialized
DEBUG - 2011-09-27 15:48:22 --> No URI present. Default controller set.
DEBUG - 2011-09-27 15:48:22 --> Output Class Initialized
DEBUG - 2011-09-27 15:48:22 --> Input Class Initialized
DEBUG - 2011-09-27 15:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 15:48:22 --> Language Class Initialized
DEBUG - 2011-09-27 15:48:22 --> Loader Class Initialized
DEBUG - 2011-09-27 15:48:22 --> Controller Class Initialized
DEBUG - 2011-09-27 15:48:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-27 15:48:22 --> Helper loaded: url_helper
DEBUG - 2011-09-27 15:48:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 15:48:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 15:48:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 15:48:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 15:48:22 --> Final output sent to browser
DEBUG - 2011-09-27 15:48:22 --> Total execution time: 0.0684
DEBUG - 2011-09-27 16:03:52 --> Config Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Hooks Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Utf8 Class Initialized
DEBUG - 2011-09-27 16:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 16:03:52 --> URI Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Router Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Output Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Input Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 16:03:52 --> Language Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Loader Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Controller Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Model Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Model Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Model Class Initialized
DEBUG - 2011-09-27 16:03:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 16:03:52 --> Database Driver Class Initialized
DEBUG - 2011-09-27 16:03:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 16:03:54 --> Helper loaded: url_helper
DEBUG - 2011-09-27 16:03:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 16:03:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 16:03:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 16:03:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 16:03:54 --> Final output sent to browser
DEBUG - 2011-09-27 16:03:54 --> Total execution time: 1.7365
DEBUG - 2011-09-27 16:29:04 --> Config Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Hooks Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Utf8 Class Initialized
DEBUG - 2011-09-27 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 16:29:04 --> URI Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Router Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Output Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Input Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 16:29:04 --> Language Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Loader Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Controller Class Initialized
ERROR - 2011-09-27 16:29:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 16:29:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 16:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 16:29:04 --> Model Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Model Class Initialized
DEBUG - 2011-09-27 16:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 16:29:04 --> Database Driver Class Initialized
DEBUG - 2011-09-27 16:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 16:29:04 --> Helper loaded: url_helper
DEBUG - 2011-09-27 16:29:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 16:29:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 16:29:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 16:29:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 16:29:04 --> Final output sent to browser
DEBUG - 2011-09-27 16:29:04 --> Total execution time: 0.1186
DEBUG - 2011-09-27 16:29:05 --> Config Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Hooks Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Utf8 Class Initialized
DEBUG - 2011-09-27 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 16:29:05 --> URI Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Router Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Output Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Input Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 16:29:05 --> Language Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Loader Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Controller Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Model Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Model Class Initialized
DEBUG - 2011-09-27 16:29:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 16:29:05 --> Database Driver Class Initialized
DEBUG - 2011-09-27 16:29:06 --> Final output sent to browser
DEBUG - 2011-09-27 16:29:06 --> Total execution time: 0.6427
DEBUG - 2011-09-27 16:29:06 --> Config Class Initialized
DEBUG - 2011-09-27 16:29:06 --> Hooks Class Initialized
DEBUG - 2011-09-27 16:29:06 --> Utf8 Class Initialized
DEBUG - 2011-09-27 16:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 16:29:06 --> URI Class Initialized
DEBUG - 2011-09-27 16:29:06 --> Router Class Initialized
ERROR - 2011-09-27 16:29:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 16:29:22 --> Config Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 16:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 16:29:22 --> URI Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Router Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Output Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Input Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 16:29:22 --> Language Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Loader Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Controller Class Initialized
ERROR - 2011-09-27 16:29:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 16:29:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 16:29:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 16:29:22 --> Model Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Model Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 16:29:22 --> Database Driver Class Initialized
DEBUG - 2011-09-27 16:29:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 16:29:22 --> Helper loaded: url_helper
DEBUG - 2011-09-27 16:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 16:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 16:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 16:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 16:29:22 --> Final output sent to browser
DEBUG - 2011-09-27 16:29:22 --> Total execution time: 0.0318
DEBUG - 2011-09-27 16:29:22 --> Config Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 16:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 16:29:22 --> URI Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Router Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Output Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Input Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 16:29:22 --> Language Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Loader Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Controller Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Model Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Model Class Initialized
DEBUG - 2011-09-27 16:29:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 16:29:22 --> Database Driver Class Initialized
DEBUG - 2011-09-27 16:29:23 --> Final output sent to browser
DEBUG - 2011-09-27 16:29:23 --> Total execution time: 0.5545
DEBUG - 2011-09-27 16:29:23 --> Config Class Initialized
DEBUG - 2011-09-27 16:29:23 --> Hooks Class Initialized
DEBUG - 2011-09-27 16:29:23 --> Utf8 Class Initialized
DEBUG - 2011-09-27 16:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 16:29:23 --> URI Class Initialized
DEBUG - 2011-09-27 16:29:23 --> Router Class Initialized
ERROR - 2011-09-27 16:29:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 17:48:41 --> Config Class Initialized
DEBUG - 2011-09-27 17:48:41 --> Hooks Class Initialized
DEBUG - 2011-09-27 17:48:41 --> Utf8 Class Initialized
DEBUG - 2011-09-27 17:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 17:48:41 --> URI Class Initialized
DEBUG - 2011-09-27 17:48:41 --> Router Class Initialized
DEBUG - 2011-09-27 17:48:41 --> No URI present. Default controller set.
DEBUG - 2011-09-27 17:48:41 --> Output Class Initialized
DEBUG - 2011-09-27 17:48:41 --> Input Class Initialized
DEBUG - 2011-09-27 17:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 17:48:41 --> Language Class Initialized
DEBUG - 2011-09-27 17:48:41 --> Loader Class Initialized
DEBUG - 2011-09-27 17:48:41 --> Controller Class Initialized
DEBUG - 2011-09-27 17:48:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-27 17:48:41 --> Helper loaded: url_helper
DEBUG - 2011-09-27 17:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 17:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 17:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 17:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 17:48:41 --> Final output sent to browser
DEBUG - 2011-09-27 17:48:41 --> Total execution time: 0.0601
DEBUG - 2011-09-27 17:52:51 --> Config Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Hooks Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Utf8 Class Initialized
DEBUG - 2011-09-27 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 17:52:51 --> URI Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Router Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Output Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Input Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 17:52:51 --> Language Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Loader Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Controller Class Initialized
ERROR - 2011-09-27 17:52:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 17:52:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 17:52:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 17:52:51 --> Model Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Model Class Initialized
DEBUG - 2011-09-27 17:52:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 17:52:51 --> Database Driver Class Initialized
DEBUG - 2011-09-27 17:52:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 17:52:52 --> Helper loaded: url_helper
DEBUG - 2011-09-27 17:52:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 17:52:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 17:52:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 17:52:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 17:52:52 --> Final output sent to browser
DEBUG - 2011-09-27 17:52:52 --> Total execution time: 0.6149
DEBUG - 2011-09-27 17:55:26 --> Config Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Hooks Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Utf8 Class Initialized
DEBUG - 2011-09-27 17:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 17:55:26 --> URI Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Router Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Output Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Input Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 17:55:26 --> Language Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Loader Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Controller Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Model Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Model Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Model Class Initialized
DEBUG - 2011-09-27 17:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 17:55:26 --> Database Driver Class Initialized
DEBUG - 2011-09-27 17:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 17:55:26 --> Helper loaded: url_helper
DEBUG - 2011-09-27 17:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 17:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 17:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 17:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 17:55:26 --> Final output sent to browser
DEBUG - 2011-09-27 17:55:26 --> Total execution time: 0.4426
DEBUG - 2011-09-27 18:22:39 --> Config Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Hooks Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Utf8 Class Initialized
DEBUG - 2011-09-27 18:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 18:22:39 --> URI Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Router Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Output Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Input Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 18:22:39 --> Language Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Loader Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Controller Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Model Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Model Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Model Class Initialized
DEBUG - 2011-09-27 18:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 18:22:39 --> Database Driver Class Initialized
DEBUG - 2011-09-27 18:22:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 18:22:40 --> Helper loaded: url_helper
DEBUG - 2011-09-27 18:22:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 18:22:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 18:22:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 18:22:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 18:22:40 --> Final output sent to browser
DEBUG - 2011-09-27 18:22:40 --> Total execution time: 0.9445
DEBUG - 2011-09-27 18:22:45 --> Config Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Hooks Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Utf8 Class Initialized
DEBUG - 2011-09-27 18:22:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 18:22:45 --> URI Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Router Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Output Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Input Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 18:22:45 --> Language Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Loader Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Controller Class Initialized
ERROR - 2011-09-27 18:22:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 18:22:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 18:22:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 18:22:45 --> Model Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Model Class Initialized
DEBUG - 2011-09-27 18:22:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 18:22:45 --> Database Driver Class Initialized
DEBUG - 2011-09-27 18:22:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 18:22:45 --> Helper loaded: url_helper
DEBUG - 2011-09-27 18:22:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 18:22:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 18:22:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 18:22:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 18:22:45 --> Final output sent to browser
DEBUG - 2011-09-27 18:22:45 --> Total execution time: 0.0861
DEBUG - 2011-09-27 18:23:56 --> Config Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Hooks Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Utf8 Class Initialized
DEBUG - 2011-09-27 18:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 18:23:56 --> URI Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Router Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Output Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Input Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 18:23:56 --> Language Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Loader Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Controller Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Model Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Model Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Model Class Initialized
DEBUG - 2011-09-27 18:23:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 18:23:56 --> Database Driver Class Initialized
DEBUG - 2011-09-27 18:23:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 18:23:56 --> Helper loaded: url_helper
DEBUG - 2011-09-27 18:23:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 18:23:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 18:23:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 18:23:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 18:23:56 --> Final output sent to browser
DEBUG - 2011-09-27 18:23:56 --> Total execution time: 0.0471
DEBUG - 2011-09-27 18:24:10 --> Config Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Hooks Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Utf8 Class Initialized
DEBUG - 2011-09-27 18:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 18:24:10 --> URI Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Router Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Output Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Input Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 18:24:10 --> Language Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Loader Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Controller Class Initialized
ERROR - 2011-09-27 18:24:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 18:24:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 18:24:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 18:24:10 --> Model Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Model Class Initialized
DEBUG - 2011-09-27 18:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 18:24:10 --> Database Driver Class Initialized
DEBUG - 2011-09-27 18:24:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 18:24:10 --> Helper loaded: url_helper
DEBUG - 2011-09-27 18:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 18:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 18:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 18:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 18:24:10 --> Final output sent to browser
DEBUG - 2011-09-27 18:24:10 --> Total execution time: 0.0673
DEBUG - 2011-09-27 20:51:20 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:20 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Router Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Output Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Input Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 20:51:20 --> Language Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Loader Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Controller Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 20:51:20 --> Database Driver Class Initialized
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 20:51:21 --> Helper loaded: url_helper
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 20:51:21 --> Final output sent to browser
DEBUG - 2011-09-27 20:51:21 --> Total execution time: 1.1254
DEBUG - 2011-09-27 20:51:21 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:21 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Router Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Output Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Input Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 20:51:21 --> Language Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Loader Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Controller Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:21 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Router Class Initialized
ERROR - 2011-09-27 20:51:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 20:51:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 20:51:21 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:21 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-09-27 20:51:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 20:51:21 --> Database Driver Class Initialized
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 20:51:21 --> Helper loaded: url_helper
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 20:51:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 20:51:21 --> Final output sent to browser
DEBUG - 2011-09-27 20:51:21 --> Total execution time: 0.0928
DEBUG - 2011-09-27 20:51:22 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:22 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Router Class Initialized
ERROR - 2011-09-27 20:51:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 20:51:22 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:22 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Router Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Output Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Input Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 20:51:22 --> Language Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Loader Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Controller Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 20:51:22 --> Database Driver Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:22 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:22 --> Router Class Initialized
ERROR - 2011-09-27 20:51:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 20:51:23 --> Final output sent to browser
DEBUG - 2011-09-27 20:51:23 --> Total execution time: 0.7655
DEBUG - 2011-09-27 20:51:27 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:27 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Router Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Output Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Input Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 20:51:27 --> Language Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Loader Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Controller Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 20:51:27 --> Database Driver Class Initialized
DEBUG - 2011-09-27 20:51:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 20:51:27 --> Helper loaded: url_helper
DEBUG - 2011-09-27 20:51:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 20:51:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 20:51:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 20:51:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 20:51:27 --> Final output sent to browser
DEBUG - 2011-09-27 20:51:27 --> Total execution time: 0.0492
DEBUG - 2011-09-27 20:51:31 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:31 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Router Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Output Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Input Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 20:51:31 --> Language Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Loader Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Controller Class Initialized
ERROR - 2011-09-27 20:51:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 20:51:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 20:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 20:51:31 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 20:51:31 --> Database Driver Class Initialized
DEBUG - 2011-09-27 20:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 20:51:31 --> Helper loaded: url_helper
DEBUG - 2011-09-27 20:51:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 20:51:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 20:51:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 20:51:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 20:51:31 --> Final output sent to browser
DEBUG - 2011-09-27 20:51:31 --> Total execution time: 0.0455
DEBUG - 2011-09-27 20:51:32 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:32 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Router Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Output Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Input Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 20:51:32 --> Language Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Loader Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Controller Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 20:51:32 --> Database Driver Class Initialized
DEBUG - 2011-09-27 20:51:32 --> Final output sent to browser
DEBUG - 2011-09-27 20:51:32 --> Total execution time: 0.6401
DEBUG - 2011-09-27 20:51:39 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:39 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Router Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Output Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Input Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 20:51:39 --> Language Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Loader Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Controller Class Initialized
ERROR - 2011-09-27 20:51:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 20:51:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 20:51:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 20:51:39 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 20:51:39 --> Database Driver Class Initialized
DEBUG - 2011-09-27 20:51:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 20:51:39 --> Helper loaded: url_helper
DEBUG - 2011-09-27 20:51:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 20:51:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 20:51:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 20:51:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 20:51:39 --> Final output sent to browser
DEBUG - 2011-09-27 20:51:39 --> Total execution time: 0.0735
DEBUG - 2011-09-27 20:51:39 --> Config Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Hooks Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Utf8 Class Initialized
DEBUG - 2011-09-27 20:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 20:51:39 --> URI Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Router Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Output Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Input Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 20:51:39 --> Language Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Loader Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Controller Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Model Class Initialized
DEBUG - 2011-09-27 20:51:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 20:51:39 --> Database Driver Class Initialized
DEBUG - 2011-09-27 20:51:40 --> Final output sent to browser
DEBUG - 2011-09-27 20:51:40 --> Total execution time: 0.8418
DEBUG - 2011-09-27 21:07:36 --> Config Class Initialized
DEBUG - 2011-09-27 21:07:36 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:07:36 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:07:37 --> URI Class Initialized
DEBUG - 2011-09-27 21:07:37 --> Router Class Initialized
DEBUG - 2011-09-27 21:07:37 --> Output Class Initialized
DEBUG - 2011-09-27 21:07:37 --> Input Class Initialized
DEBUG - 2011-09-27 21:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 21:07:37 --> Language Class Initialized
DEBUG - 2011-09-27 21:07:37 --> Loader Class Initialized
DEBUG - 2011-09-27 21:07:37 --> Controller Class Initialized
ERROR - 2011-09-27 21:07:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 21:07:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 21:07:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 21:07:37 --> Model Class Initialized
DEBUG - 2011-09-27 21:07:37 --> Model Class Initialized
DEBUG - 2011-09-27 21:07:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 21:07:37 --> Database Driver Class Initialized
DEBUG - 2011-09-27 21:07:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 21:07:37 --> Helper loaded: url_helper
DEBUG - 2011-09-27 21:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 21:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 21:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 21:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 21:07:37 --> Final output sent to browser
DEBUG - 2011-09-27 21:07:37 --> Total execution time: 0.0958
DEBUG - 2011-09-27 21:07:38 --> Config Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:07:38 --> URI Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Router Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Output Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Input Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 21:07:38 --> Language Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Loader Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Controller Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Model Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Model Class Initialized
DEBUG - 2011-09-27 21:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 21:07:38 --> Database Driver Class Initialized
DEBUG - 2011-09-27 21:07:39 --> Final output sent to browser
DEBUG - 2011-09-27 21:07:39 --> Total execution time: 1.0046
DEBUG - 2011-09-27 21:07:40 --> Config Class Initialized
DEBUG - 2011-09-27 21:07:40 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:07:40 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:07:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:07:40 --> URI Class Initialized
DEBUG - 2011-09-27 21:07:40 --> Router Class Initialized
ERROR - 2011-09-27 21:07:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 21:07:41 --> Config Class Initialized
DEBUG - 2011-09-27 21:07:41 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:07:41 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:07:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:07:41 --> URI Class Initialized
DEBUG - 2011-09-27 21:07:41 --> Router Class Initialized
ERROR - 2011-09-27 21:07:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 21:08:02 --> Config Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:08:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:08:02 --> URI Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Router Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Output Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Input Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 21:08:02 --> Language Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Loader Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Controller Class Initialized
ERROR - 2011-09-27 21:08:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 21:08:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 21:08:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 21:08:02 --> Model Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Model Class Initialized
DEBUG - 2011-09-27 21:08:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 21:08:02 --> Database Driver Class Initialized
DEBUG - 2011-09-27 21:08:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 21:08:02 --> Helper loaded: url_helper
DEBUG - 2011-09-27 21:08:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 21:08:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 21:08:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 21:08:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 21:08:02 --> Final output sent to browser
DEBUG - 2011-09-27 21:08:02 --> Total execution time: 0.0562
DEBUG - 2011-09-27 21:08:03 --> Config Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:08:03 --> URI Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Router Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Output Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Input Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 21:08:03 --> Language Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Loader Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Controller Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Model Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Model Class Initialized
DEBUG - 2011-09-27 21:08:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 21:08:03 --> Database Driver Class Initialized
DEBUG - 2011-09-27 21:08:04 --> Final output sent to browser
DEBUG - 2011-09-27 21:08:04 --> Total execution time: 0.7791
DEBUG - 2011-09-27 21:08:05 --> Config Class Initialized
DEBUG - 2011-09-27 21:08:05 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:08:05 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:08:05 --> URI Class Initialized
DEBUG - 2011-09-27 21:08:05 --> Router Class Initialized
ERROR - 2011-09-27 21:08:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 21:32:06 --> Config Class Initialized
DEBUG - 2011-09-27 21:32:06 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:32:06 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:32:06 --> URI Class Initialized
DEBUG - 2011-09-27 21:32:06 --> Router Class Initialized
DEBUG - 2011-09-27 21:32:06 --> No URI present. Default controller set.
DEBUG - 2011-09-27 21:32:06 --> Output Class Initialized
DEBUG - 2011-09-27 21:32:06 --> Input Class Initialized
DEBUG - 2011-09-27 21:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 21:32:06 --> Language Class Initialized
DEBUG - 2011-09-27 21:32:06 --> Loader Class Initialized
DEBUG - 2011-09-27 21:32:06 --> Controller Class Initialized
DEBUG - 2011-09-27 21:32:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-27 21:32:06 --> Helper loaded: url_helper
DEBUG - 2011-09-27 21:32:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 21:32:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 21:32:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 21:32:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 21:32:06 --> Final output sent to browser
DEBUG - 2011-09-27 21:32:06 --> Total execution time: 0.0734
DEBUG - 2011-09-27 21:59:16 --> Config Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:59:16 --> URI Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Router Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Output Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Input Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 21:59:16 --> Language Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Loader Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Controller Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Model Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Model Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Model Class Initialized
DEBUG - 2011-09-27 21:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 21:59:16 --> Database Driver Class Initialized
DEBUG - 2011-09-27 21:59:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 21:59:17 --> Helper loaded: url_helper
DEBUG - 2011-09-27 21:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 21:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 21:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 21:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 21:59:17 --> Final output sent to browser
DEBUG - 2011-09-27 21:59:17 --> Total execution time: 1.0429
DEBUG - 2011-09-27 21:59:18 --> Config Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Hooks Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Utf8 Class Initialized
DEBUG - 2011-09-27 21:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 21:59:18 --> URI Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Router Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Output Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Input Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 21:59:18 --> Language Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Loader Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Controller Class Initialized
ERROR - 2011-09-27 21:59:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 21:59:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 21:59:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 21:59:18 --> Model Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Model Class Initialized
DEBUG - 2011-09-27 21:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 21:59:18 --> Database Driver Class Initialized
DEBUG - 2011-09-27 21:59:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 21:59:18 --> Helper loaded: url_helper
DEBUG - 2011-09-27 21:59:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 21:59:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 21:59:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 21:59:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 21:59:18 --> Final output sent to browser
DEBUG - 2011-09-27 21:59:18 --> Total execution time: 0.0529
DEBUG - 2011-09-27 22:18:32 --> Config Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:18:32 --> URI Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Router Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Output Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Input Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 22:18:32 --> Language Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Loader Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Controller Class Initialized
ERROR - 2011-09-27 22:18:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 22:18:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 22:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 22:18:32 --> Model Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Model Class Initialized
DEBUG - 2011-09-27 22:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 22:18:32 --> Database Driver Class Initialized
DEBUG - 2011-09-27 22:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 22:18:32 --> Helper loaded: url_helper
DEBUG - 2011-09-27 22:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 22:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 22:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 22:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 22:18:32 --> Final output sent to browser
DEBUG - 2011-09-27 22:18:32 --> Total execution time: 0.0356
DEBUG - 2011-09-27 22:18:34 --> Config Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:18:34 --> URI Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Router Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Output Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Input Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 22:18:34 --> Language Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Loader Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Controller Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Model Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Model Class Initialized
DEBUG - 2011-09-27 22:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 22:18:34 --> Database Driver Class Initialized
DEBUG - 2011-09-27 22:18:35 --> Final output sent to browser
DEBUG - 2011-09-27 22:18:35 --> Total execution time: 0.7341
DEBUG - 2011-09-27 22:18:38 --> Config Class Initialized
DEBUG - 2011-09-27 22:18:38 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:18:38 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:18:38 --> URI Class Initialized
DEBUG - 2011-09-27 22:18:38 --> Router Class Initialized
ERROR - 2011-09-27 22:18:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 22:18:39 --> Config Class Initialized
DEBUG - 2011-09-27 22:18:39 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:18:39 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:18:39 --> URI Class Initialized
DEBUG - 2011-09-27 22:18:39 --> Router Class Initialized
ERROR - 2011-09-27 22:18:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 22:19:11 --> Config Class Initialized
DEBUG - 2011-09-27 22:19:11 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:19:11 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:19:11 --> URI Class Initialized
DEBUG - 2011-09-27 22:19:11 --> Router Class Initialized
DEBUG - 2011-09-27 22:19:11 --> Output Class Initialized
DEBUG - 2011-09-27 22:19:12 --> Input Class Initialized
DEBUG - 2011-09-27 22:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 22:19:12 --> Language Class Initialized
DEBUG - 2011-09-27 22:19:12 --> Loader Class Initialized
DEBUG - 2011-09-27 22:19:12 --> Controller Class Initialized
ERROR - 2011-09-27 22:19:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 22:19:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 22:19:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 22:19:12 --> Model Class Initialized
DEBUG - 2011-09-27 22:19:12 --> Model Class Initialized
DEBUG - 2011-09-27 22:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 22:19:12 --> Database Driver Class Initialized
DEBUG - 2011-09-27 22:19:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 22:19:12 --> Helper loaded: url_helper
DEBUG - 2011-09-27 22:19:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 22:19:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 22:19:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 22:19:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 22:19:12 --> Final output sent to browser
DEBUG - 2011-09-27 22:19:12 --> Total execution time: 0.0357
DEBUG - 2011-09-27 22:19:13 --> Config Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:19:13 --> URI Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Router Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Output Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Input Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 22:19:13 --> Language Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Loader Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Controller Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Model Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Model Class Initialized
DEBUG - 2011-09-27 22:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 22:19:13 --> Database Driver Class Initialized
DEBUG - 2011-09-27 22:19:14 --> Final output sent to browser
DEBUG - 2011-09-27 22:19:14 --> Total execution time: 0.5589
DEBUG - 2011-09-27 22:19:15 --> Config Class Initialized
DEBUG - 2011-09-27 22:19:15 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:19:15 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:19:15 --> URI Class Initialized
DEBUG - 2011-09-27 22:19:15 --> Router Class Initialized
ERROR - 2011-09-27 22:19:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 22:20:08 --> Config Class Initialized
DEBUG - 2011-09-27 22:20:08 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:20:08 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:20:08 --> URI Class Initialized
DEBUG - 2011-09-27 22:20:08 --> Router Class Initialized
ERROR - 2011-09-27 22:20:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 22:48:50 --> Config Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:48:50 --> URI Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Router Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Output Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Input Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 22:48:50 --> Language Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Loader Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Controller Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Model Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Model Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Model Class Initialized
DEBUG - 2011-09-27 22:48:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 22:48:50 --> Database Driver Class Initialized
DEBUG - 2011-09-27 22:48:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 22:48:50 --> Helper loaded: url_helper
DEBUG - 2011-09-27 22:48:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 22:48:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 22:48:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 22:48:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 22:48:50 --> Final output sent to browser
DEBUG - 2011-09-27 22:48:50 --> Total execution time: 0.5086
DEBUG - 2011-09-27 22:51:05 --> Config Class Initialized
DEBUG - 2011-09-27 22:51:05 --> Hooks Class Initialized
DEBUG - 2011-09-27 22:51:05 --> Utf8 Class Initialized
DEBUG - 2011-09-27 22:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 22:51:05 --> URI Class Initialized
DEBUG - 2011-09-27 22:51:05 --> Router Class Initialized
DEBUG - 2011-09-27 22:51:05 --> No URI present. Default controller set.
DEBUG - 2011-09-27 22:51:05 --> Output Class Initialized
DEBUG - 2011-09-27 22:51:05 --> Input Class Initialized
DEBUG - 2011-09-27 22:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 22:51:05 --> Language Class Initialized
DEBUG - 2011-09-27 22:51:05 --> Loader Class Initialized
DEBUG - 2011-09-27 22:51:05 --> Controller Class Initialized
DEBUG - 2011-09-27 22:51:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-27 22:51:05 --> Helper loaded: url_helper
DEBUG - 2011-09-27 22:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 22:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 22:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 22:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 22:51:05 --> Final output sent to browser
DEBUG - 2011-09-27 22:51:05 --> Total execution time: 0.0165
DEBUG - 2011-09-27 23:04:27 --> Config Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:04:27 --> URI Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Router Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Output Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Input Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:04:27 --> Language Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Loader Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Controller Class Initialized
ERROR - 2011-09-27 23:04:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 23:04:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 23:04:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:04:27 --> Model Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Model Class Initialized
DEBUG - 2011-09-27 23:04:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:04:27 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:04:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:04:27 --> Helper loaded: url_helper
DEBUG - 2011-09-27 23:04:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 23:04:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 23:04:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 23:04:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 23:04:27 --> Final output sent to browser
DEBUG - 2011-09-27 23:04:27 --> Total execution time: 0.0335
DEBUG - 2011-09-27 23:15:33 --> Config Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:15:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:15:33 --> URI Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Router Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Output Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Input Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:15:33 --> Language Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Loader Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Controller Class Initialized
ERROR - 2011-09-27 23:15:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 23:15:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 23:15:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:15:33 --> Model Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Model Class Initialized
DEBUG - 2011-09-27 23:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:15:33 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:15:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:15:33 --> Helper loaded: url_helper
DEBUG - 2011-09-27 23:15:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 23:15:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 23:15:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 23:15:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 23:15:33 --> Final output sent to browser
DEBUG - 2011-09-27 23:15:33 --> Total execution time: 0.0718
DEBUG - 2011-09-27 23:15:34 --> Config Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:15:34 --> URI Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Router Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Output Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Input Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:15:34 --> Language Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Loader Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Controller Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Model Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Model Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:15:34 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:15:34 --> Final output sent to browser
DEBUG - 2011-09-27 23:15:34 --> Total execution time: 0.6877
DEBUG - 2011-09-27 23:15:36 --> Config Class Initialized
DEBUG - 2011-09-27 23:15:36 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:15:36 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:15:36 --> URI Class Initialized
DEBUG - 2011-09-27 23:15:36 --> Router Class Initialized
ERROR - 2011-09-27 23:15:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 23:15:38 --> Config Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:15:38 --> URI Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Router Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Output Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Input Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:15:38 --> Language Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Loader Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Controller Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Model Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Model Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Model Class Initialized
DEBUG - 2011-09-27 23:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:15:38 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:15:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 23:15:39 --> Helper loaded: url_helper
DEBUG - 2011-09-27 23:15:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 23:15:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 23:15:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 23:15:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 23:15:39 --> Final output sent to browser
DEBUG - 2011-09-27 23:15:39 --> Total execution time: 0.3426
DEBUG - 2011-09-27 23:15:39 --> Config Class Initialized
DEBUG - 2011-09-27 23:15:39 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:15:39 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:15:39 --> URI Class Initialized
DEBUG - 2011-09-27 23:15:39 --> Router Class Initialized
ERROR - 2011-09-27 23:15:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 23:21:00 --> Config Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:21:00 --> URI Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Router Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Output Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Input Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:21:00 --> Language Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Loader Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Controller Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:21:00 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:21:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-27 23:21:00 --> Helper loaded: url_helper
DEBUG - 2011-09-27 23:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 23:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 23:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 23:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 23:21:00 --> Final output sent to browser
DEBUG - 2011-09-27 23:21:00 --> Total execution time: 0.3074
DEBUG - 2011-09-27 23:21:02 --> Config Class Initialized
DEBUG - 2011-09-27 23:21:02 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:21:02 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:21:02 --> URI Class Initialized
DEBUG - 2011-09-27 23:21:02 --> Router Class Initialized
ERROR - 2011-09-27 23:21:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 23:21:03 --> Config Class Initialized
DEBUG - 2011-09-27 23:21:03 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:21:03 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:21:03 --> URI Class Initialized
DEBUG - 2011-09-27 23:21:03 --> Router Class Initialized
ERROR - 2011-09-27 23:21:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-27 23:21:19 --> Config Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:21:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:21:19 --> URI Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Router Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Output Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Input Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:21:19 --> Language Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Loader Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Controller Class Initialized
ERROR - 2011-09-27 23:21:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 23:21:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 23:21:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:21:19 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:21:19 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:21:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:21:19 --> Helper loaded: url_helper
DEBUG - 2011-09-27 23:21:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 23:21:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 23:21:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 23:21:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 23:21:19 --> Final output sent to browser
DEBUG - 2011-09-27 23:21:19 --> Total execution time: 0.0341
DEBUG - 2011-09-27 23:21:20 --> Config Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:21:20 --> URI Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Router Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Output Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Input Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:21:20 --> Language Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Loader Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Controller Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:21:20 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:21:21 --> Final output sent to browser
DEBUG - 2011-09-27 23:21:21 --> Total execution time: 0.5777
DEBUG - 2011-09-27 23:21:50 --> Config Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:21:50 --> URI Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Router Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Output Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Input Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:21:50 --> Language Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Loader Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Controller Class Initialized
ERROR - 2011-09-27 23:21:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 23:21:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 23:21:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:21:50 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:21:50 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:21:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:21:50 --> Helper loaded: url_helper
DEBUG - 2011-09-27 23:21:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 23:21:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 23:21:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 23:21:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 23:21:50 --> Final output sent to browser
DEBUG - 2011-09-27 23:21:50 --> Total execution time: 0.0305
DEBUG - 2011-09-27 23:21:51 --> Config Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:21:51 --> URI Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Router Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Output Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Input Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:21:51 --> Language Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Loader Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Controller Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:21:51 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:21:53 --> Final output sent to browser
DEBUG - 2011-09-27 23:21:53 --> Total execution time: 2.2865
DEBUG - 2011-09-27 23:21:59 --> Config Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:21:59 --> URI Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Router Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Output Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Input Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:21:59 --> Language Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Loader Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Controller Class Initialized
ERROR - 2011-09-27 23:21:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 23:21:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 23:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:21:59 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Model Class Initialized
DEBUG - 2011-09-27 23:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:21:59 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:21:59 --> Helper loaded: url_helper
DEBUG - 2011-09-27 23:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 23:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 23:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 23:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 23:21:59 --> Final output sent to browser
DEBUG - 2011-09-27 23:21:59 --> Total execution time: 0.0296
DEBUG - 2011-09-27 23:22:00 --> Config Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:22:00 --> URI Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Router Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Output Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Input Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:22:00 --> Language Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Loader Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Controller Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Model Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Model Class Initialized
DEBUG - 2011-09-27 23:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:22:00 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:22:01 --> Final output sent to browser
DEBUG - 2011-09-27 23:22:01 --> Total execution time: 0.6803
DEBUG - 2011-09-27 23:22:09 --> Config Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:22:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:22:09 --> URI Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Router Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Output Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Input Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:22:09 --> Language Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Loader Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Controller Class Initialized
ERROR - 2011-09-27 23:22:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-27 23:22:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-27 23:22:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:22:09 --> Model Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Model Class Initialized
DEBUG - 2011-09-27 23:22:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:22:09 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:22:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-27 23:22:09 --> Helper loaded: url_helper
DEBUG - 2011-09-27 23:22:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-27 23:22:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-27 23:22:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-27 23:22:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-27 23:22:09 --> Final output sent to browser
DEBUG - 2011-09-27 23:22:09 --> Total execution time: 0.0323
DEBUG - 2011-09-27 23:22:10 --> Config Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Hooks Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Utf8 Class Initialized
DEBUG - 2011-09-27 23:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-27 23:22:10 --> URI Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Router Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Output Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Input Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-27 23:22:10 --> Language Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Loader Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Controller Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Model Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Model Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-27 23:22:10 --> Database Driver Class Initialized
DEBUG - 2011-09-27 23:22:10 --> Final output sent to browser
DEBUG - 2011-09-27 23:22:10 --> Total execution time: 0.5885

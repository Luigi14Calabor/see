<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-20 00:13:24 --> Config Class Initialized
DEBUG - 2011-06-20 00:13:24 --> Hooks Class Initialized
DEBUG - 2011-06-20 00:13:24 --> Utf8 Class Initialized
DEBUG - 2011-06-20 00:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 00:13:24 --> URI Class Initialized
DEBUG - 2011-06-20 00:13:24 --> Router Class Initialized
ERROR - 2011-06-20 00:13:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-20 00:26:13 --> Config Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Hooks Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Utf8 Class Initialized
DEBUG - 2011-06-20 00:26:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 00:26:13 --> URI Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Router Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Output Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Input Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 00:26:13 --> Language Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Loader Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Controller Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Model Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Model Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Model Class Initialized
DEBUG - 2011-06-20 00:26:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 00:26:13 --> Database Driver Class Initialized
DEBUG - 2011-06-20 00:26:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 00:26:13 --> Helper loaded: url_helper
DEBUG - 2011-06-20 00:26:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 00:26:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 00:26:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 00:26:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 00:26:13 --> Final output sent to browser
DEBUG - 2011-06-20 00:26:13 --> Total execution time: 0.5151
DEBUG - 2011-06-20 00:27:45 --> Config Class Initialized
DEBUG - 2011-06-20 00:27:45 --> Hooks Class Initialized
DEBUG - 2011-06-20 00:27:45 --> Utf8 Class Initialized
DEBUG - 2011-06-20 00:27:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 00:27:45 --> URI Class Initialized
DEBUG - 2011-06-20 00:27:45 --> Router Class Initialized
ERROR - 2011-06-20 00:27:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-20 00:40:21 --> Config Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Hooks Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Utf8 Class Initialized
DEBUG - 2011-06-20 00:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 00:40:21 --> URI Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Router Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Output Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Input Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 00:40:21 --> Language Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Loader Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Controller Class Initialized
ERROR - 2011-06-20 00:40:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 00:40:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 00:40:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 00:40:21 --> Model Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Model Class Initialized
DEBUG - 2011-06-20 00:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 00:40:21 --> Database Driver Class Initialized
DEBUG - 2011-06-20 00:40:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 00:40:21 --> Helper loaded: url_helper
DEBUG - 2011-06-20 00:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 00:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 00:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 00:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 00:40:21 --> Final output sent to browser
DEBUG - 2011-06-20 00:40:21 --> Total execution time: 0.1133
DEBUG - 2011-06-20 04:36:01 --> Config Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Hooks Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Utf8 Class Initialized
DEBUG - 2011-06-20 04:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 04:36:01 --> URI Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Router Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Output Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Input Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 04:36:01 --> Language Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Loader Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Controller Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Model Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Model Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Model Class Initialized
DEBUG - 2011-06-20 04:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 04:36:01 --> Database Driver Class Initialized
DEBUG - 2011-06-20 04:36:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 04:36:02 --> Helper loaded: url_helper
DEBUG - 2011-06-20 04:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 04:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 04:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 04:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 04:36:02 --> Final output sent to browser
DEBUG - 2011-06-20 04:36:02 --> Total execution time: 1.3566
DEBUG - 2011-06-20 04:36:05 --> Config Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Hooks Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Utf8 Class Initialized
DEBUG - 2011-06-20 04:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 04:36:05 --> URI Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Router Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Output Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Input Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 04:36:05 --> Language Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Loader Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Controller Class Initialized
ERROR - 2011-06-20 04:36:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 04:36:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 04:36:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 04:36:05 --> Model Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Model Class Initialized
DEBUG - 2011-06-20 04:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 04:36:05 --> Database Driver Class Initialized
DEBUG - 2011-06-20 04:36:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 04:36:05 --> Helper loaded: url_helper
DEBUG - 2011-06-20 04:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 04:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 04:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 04:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 04:36:05 --> Final output sent to browser
DEBUG - 2011-06-20 04:36:05 --> Total execution time: 0.0926
DEBUG - 2011-06-20 06:00:45 --> Config Class Initialized
DEBUG - 2011-06-20 06:00:45 --> Hooks Class Initialized
DEBUG - 2011-06-20 06:00:45 --> Utf8 Class Initialized
DEBUG - 2011-06-20 06:00:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 06:00:45 --> URI Class Initialized
DEBUG - 2011-06-20 06:00:45 --> Router Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Output Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Input Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 06:00:46 --> Language Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Loader Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Controller Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Model Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Model Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Model Class Initialized
DEBUG - 2011-06-20 06:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 06:00:46 --> Database Driver Class Initialized
DEBUG - 2011-06-20 06:00:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 06:00:49 --> Helper loaded: url_helper
DEBUG - 2011-06-20 06:00:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 06:00:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 06:00:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 06:00:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 06:00:49 --> Final output sent to browser
DEBUG - 2011-06-20 06:00:49 --> Total execution time: 3.2897
DEBUG - 2011-06-20 06:00:49 --> Config Class Initialized
DEBUG - 2011-06-20 06:00:49 --> Hooks Class Initialized
DEBUG - 2011-06-20 06:00:49 --> Utf8 Class Initialized
DEBUG - 2011-06-20 06:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 06:00:49 --> URI Class Initialized
DEBUG - 2011-06-20 06:00:49 --> Router Class Initialized
DEBUG - 2011-06-20 06:00:49 --> Output Class Initialized
DEBUG - 2011-06-20 06:00:49 --> Input Class Initialized
DEBUG - 2011-06-20 06:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 06:00:49 --> Language Class Initialized
DEBUG - 2011-06-20 06:00:49 --> Loader Class Initialized
DEBUG - 2011-06-20 06:00:49 --> Controller Class Initialized
ERROR - 2011-06-20 06:00:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 06:00:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 06:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 06:00:50 --> Model Class Initialized
DEBUG - 2011-06-20 06:00:50 --> Model Class Initialized
DEBUG - 2011-06-20 06:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 06:00:50 --> Database Driver Class Initialized
DEBUG - 2011-06-20 06:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 06:00:50 --> Helper loaded: url_helper
DEBUG - 2011-06-20 06:00:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 06:00:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 06:00:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 06:00:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 06:00:50 --> Final output sent to browser
DEBUG - 2011-06-20 06:00:50 --> Total execution time: 0.0819
DEBUG - 2011-06-20 07:21:16 --> Config Class Initialized
DEBUG - 2011-06-20 07:21:16 --> Hooks Class Initialized
DEBUG - 2011-06-20 07:21:16 --> Utf8 Class Initialized
DEBUG - 2011-06-20 07:21:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 07:21:16 --> URI Class Initialized
DEBUG - 2011-06-20 07:21:16 --> Router Class Initialized
ERROR - 2011-06-20 07:21:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-20 07:22:44 --> Config Class Initialized
DEBUG - 2011-06-20 07:22:44 --> Hooks Class Initialized
DEBUG - 2011-06-20 07:22:44 --> Utf8 Class Initialized
DEBUG - 2011-06-20 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 07:22:44 --> URI Class Initialized
DEBUG - 2011-06-20 07:22:44 --> Router Class Initialized
DEBUG - 2011-06-20 07:22:44 --> No URI present. Default controller set.
DEBUG - 2011-06-20 07:22:44 --> Output Class Initialized
DEBUG - 2011-06-20 07:22:44 --> Input Class Initialized
DEBUG - 2011-06-20 07:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 07:22:44 --> Language Class Initialized
DEBUG - 2011-06-20 07:22:44 --> Loader Class Initialized
DEBUG - 2011-06-20 07:22:44 --> Controller Class Initialized
DEBUG - 2011-06-20 07:22:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-20 07:22:44 --> Helper loaded: url_helper
DEBUG - 2011-06-20 07:22:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 07:22:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 07:22:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 07:22:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 07:22:44 --> Final output sent to browser
DEBUG - 2011-06-20 07:22:44 --> Total execution time: 0.2382
DEBUG - 2011-06-20 07:23:22 --> Config Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Hooks Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Utf8 Class Initialized
DEBUG - 2011-06-20 07:23:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 07:23:22 --> URI Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Router Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Output Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Input Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 07:23:22 --> Language Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Loader Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Controller Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Model Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Model Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Model Class Initialized
DEBUG - 2011-06-20 07:23:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 07:23:22 --> Database Driver Class Initialized
DEBUG - 2011-06-20 07:23:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 07:23:23 --> Helper loaded: url_helper
DEBUG - 2011-06-20 07:23:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 07:23:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 07:23:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 07:23:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 07:23:23 --> Final output sent to browser
DEBUG - 2011-06-20 07:23:23 --> Total execution time: 1.1624
DEBUG - 2011-06-20 07:23:24 --> Config Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Hooks Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Utf8 Class Initialized
DEBUG - 2011-06-20 07:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 07:23:24 --> URI Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Router Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Output Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Input Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 07:23:24 --> Language Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Loader Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Controller Class Initialized
ERROR - 2011-06-20 07:23:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 07:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 07:23:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 07:23:24 --> Model Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Model Class Initialized
DEBUG - 2011-06-20 07:23:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 07:23:24 --> Database Driver Class Initialized
DEBUG - 2011-06-20 07:23:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 07:23:24 --> Helper loaded: url_helper
DEBUG - 2011-06-20 07:23:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 07:23:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 07:23:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 07:23:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 07:23:24 --> Final output sent to browser
DEBUG - 2011-06-20 07:23:24 --> Total execution time: 0.0855
DEBUG - 2011-06-20 07:34:26 --> Config Class Initialized
DEBUG - 2011-06-20 07:34:26 --> Hooks Class Initialized
DEBUG - 2011-06-20 07:34:26 --> Utf8 Class Initialized
DEBUG - 2011-06-20 07:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 07:34:26 --> URI Class Initialized
DEBUG - 2011-06-20 07:34:26 --> Router Class Initialized
ERROR - 2011-06-20 07:34:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-20 10:09:44 --> Config Class Initialized
DEBUG - 2011-06-20 10:09:44 --> Hooks Class Initialized
DEBUG - 2011-06-20 10:09:44 --> Utf8 Class Initialized
DEBUG - 2011-06-20 10:09:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 10:09:44 --> URI Class Initialized
DEBUG - 2011-06-20 10:09:45 --> Router Class Initialized
DEBUG - 2011-06-20 10:09:45 --> Output Class Initialized
DEBUG - 2011-06-20 10:09:45 --> Input Class Initialized
DEBUG - 2011-06-20 10:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 10:09:46 --> Language Class Initialized
DEBUG - 2011-06-20 10:09:46 --> Loader Class Initialized
DEBUG - 2011-06-20 10:09:46 --> Controller Class Initialized
DEBUG - 2011-06-20 10:09:46 --> Model Class Initialized
DEBUG - 2011-06-20 10:09:46 --> Model Class Initialized
DEBUG - 2011-06-20 10:09:47 --> Model Class Initialized
DEBUG - 2011-06-20 10:09:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 10:09:48 --> Database Driver Class Initialized
DEBUG - 2011-06-20 10:09:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 10:09:50 --> Helper loaded: url_helper
DEBUG - 2011-06-20 10:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 10:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 10:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 10:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 10:09:50 --> Final output sent to browser
DEBUG - 2011-06-20 10:09:50 --> Total execution time: 6.7880
DEBUG - 2011-06-20 10:09:52 --> Config Class Initialized
DEBUG - 2011-06-20 10:09:52 --> Hooks Class Initialized
DEBUG - 2011-06-20 10:09:52 --> Utf8 Class Initialized
DEBUG - 2011-06-20 10:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 10:09:52 --> URI Class Initialized
DEBUG - 2011-06-20 10:09:52 --> Router Class Initialized
DEBUG - 2011-06-20 10:09:53 --> Output Class Initialized
DEBUG - 2011-06-20 10:09:53 --> Input Class Initialized
DEBUG - 2011-06-20 10:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 10:09:53 --> Language Class Initialized
DEBUG - 2011-06-20 10:09:53 --> Loader Class Initialized
DEBUG - 2011-06-20 10:09:53 --> Controller Class Initialized
ERROR - 2011-06-20 10:09:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 10:09:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 10:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 10:09:54 --> Model Class Initialized
DEBUG - 2011-06-20 10:09:54 --> Model Class Initialized
DEBUG - 2011-06-20 10:09:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 10:09:54 --> Database Driver Class Initialized
DEBUG - 2011-06-20 10:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 10:09:54 --> Helper loaded: url_helper
DEBUG - 2011-06-20 10:09:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 10:09:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 10:09:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 10:09:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 10:09:54 --> Final output sent to browser
DEBUG - 2011-06-20 10:09:54 --> Total execution time: 1.4905
DEBUG - 2011-06-20 11:50:47 --> Config Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Hooks Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Utf8 Class Initialized
DEBUG - 2011-06-20 11:50:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 11:50:47 --> URI Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Router Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Output Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Input Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 11:50:47 --> Language Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Loader Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Controller Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Model Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Model Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Model Class Initialized
DEBUG - 2011-06-20 11:50:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 11:50:47 --> Database Driver Class Initialized
DEBUG - 2011-06-20 11:50:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 11:50:47 --> Helper loaded: url_helper
DEBUG - 2011-06-20 11:50:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 11:50:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 11:50:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 11:50:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 11:50:47 --> Final output sent to browser
DEBUG - 2011-06-20 11:50:47 --> Total execution time: 0.7399
DEBUG - 2011-06-20 11:50:54 --> Config Class Initialized
DEBUG - 2011-06-20 11:50:54 --> Hooks Class Initialized
DEBUG - 2011-06-20 11:50:54 --> Utf8 Class Initialized
DEBUG - 2011-06-20 11:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 11:50:54 --> URI Class Initialized
DEBUG - 2011-06-20 11:50:54 --> Router Class Initialized
ERROR - 2011-06-20 11:50:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 11:51:44 --> Config Class Initialized
DEBUG - 2011-06-20 11:51:44 --> Hooks Class Initialized
DEBUG - 2011-06-20 11:51:44 --> Utf8 Class Initialized
DEBUG - 2011-06-20 11:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 11:51:44 --> URI Class Initialized
DEBUG - 2011-06-20 11:51:44 --> Router Class Initialized
DEBUG - 2011-06-20 11:51:45 --> Output Class Initialized
DEBUG - 2011-06-20 11:51:45 --> Input Class Initialized
DEBUG - 2011-06-20 11:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 11:51:45 --> Language Class Initialized
DEBUG - 2011-06-20 11:51:45 --> Loader Class Initialized
DEBUG - 2011-06-20 11:51:45 --> Controller Class Initialized
ERROR - 2011-06-20 11:51:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 11:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 11:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 11:51:46 --> Model Class Initialized
DEBUG - 2011-06-20 11:51:46 --> Model Class Initialized
DEBUG - 2011-06-20 11:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 11:51:46 --> Database Driver Class Initialized
DEBUG - 2011-06-20 11:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 11:51:46 --> Helper loaded: url_helper
DEBUG - 2011-06-20 11:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 11:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 11:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 11:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 11:51:46 --> Final output sent to browser
DEBUG - 2011-06-20 11:51:46 --> Total execution time: 1.7826
DEBUG - 2011-06-20 11:51:49 --> Config Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Hooks Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Utf8 Class Initialized
DEBUG - 2011-06-20 11:51:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 11:51:49 --> URI Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Router Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Output Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Input Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 11:51:49 --> Language Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Loader Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Controller Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Model Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Model Class Initialized
DEBUG - 2011-06-20 11:51:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 11:51:49 --> Database Driver Class Initialized
DEBUG - 2011-06-20 11:51:50 --> Final output sent to browser
DEBUG - 2011-06-20 11:51:50 --> Total execution time: 0.9717
DEBUG - 2011-06-20 11:51:54 --> Config Class Initialized
DEBUG - 2011-06-20 11:51:54 --> Hooks Class Initialized
DEBUG - 2011-06-20 11:51:54 --> Utf8 Class Initialized
DEBUG - 2011-06-20 11:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 11:51:54 --> URI Class Initialized
DEBUG - 2011-06-20 11:51:54 --> Router Class Initialized
ERROR - 2011-06-20 11:51:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 12:12:39 --> Config Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Hooks Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Utf8 Class Initialized
DEBUG - 2011-06-20 12:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 12:12:39 --> URI Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Router Class Initialized
ERROR - 2011-06-20 12:12:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-20 12:12:39 --> Config Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Hooks Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Utf8 Class Initialized
DEBUG - 2011-06-20 12:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 12:12:39 --> URI Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Router Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Output Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Input Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 12:12:39 --> Language Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Loader Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Controller Class Initialized
ERROR - 2011-06-20 12:12:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 12:12:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 12:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 12:12:39 --> Model Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Model Class Initialized
DEBUG - 2011-06-20 12:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 12:12:39 --> Database Driver Class Initialized
DEBUG - 2011-06-20 12:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 12:12:40 --> Helper loaded: url_helper
DEBUG - 2011-06-20 12:12:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 12:12:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 12:12:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 12:12:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 12:12:40 --> Final output sent to browser
DEBUG - 2011-06-20 12:12:40 --> Total execution time: 0.1310
DEBUG - 2011-06-20 12:57:02 --> Config Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Hooks Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Utf8 Class Initialized
DEBUG - 2011-06-20 12:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 12:57:02 --> URI Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Router Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Output Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Input Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 12:57:02 --> Language Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Loader Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Controller Class Initialized
DEBUG - 2011-06-20 12:57:02 --> Model Class Initialized
DEBUG - 2011-06-20 12:57:03 --> Model Class Initialized
DEBUG - 2011-06-20 12:57:03 --> Model Class Initialized
DEBUG - 2011-06-20 12:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 12:57:03 --> Database Driver Class Initialized
DEBUG - 2011-06-20 12:57:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 12:57:03 --> Helper loaded: url_helper
DEBUG - 2011-06-20 12:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 12:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 12:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 12:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 12:57:03 --> Final output sent to browser
DEBUG - 2011-06-20 12:57:03 --> Total execution time: 0.9871
DEBUG - 2011-06-20 12:57:06 --> Config Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Hooks Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Utf8 Class Initialized
DEBUG - 2011-06-20 12:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 12:57:06 --> URI Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Router Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Output Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Input Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 12:57:06 --> Language Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Loader Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Controller Class Initialized
ERROR - 2011-06-20 12:57:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 12:57:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 12:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 12:57:06 --> Model Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Model Class Initialized
DEBUG - 2011-06-20 12:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 12:57:06 --> Database Driver Class Initialized
DEBUG - 2011-06-20 12:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 12:57:06 --> Helper loaded: url_helper
DEBUG - 2011-06-20 12:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 12:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 12:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 12:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 12:57:06 --> Final output sent to browser
DEBUG - 2011-06-20 12:57:06 --> Total execution time: 0.2145
DEBUG - 2011-06-20 13:20:10 --> Config Class Initialized
DEBUG - 2011-06-20 13:20:10 --> Hooks Class Initialized
DEBUG - 2011-06-20 13:20:10 --> Utf8 Class Initialized
DEBUG - 2011-06-20 13:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 13:20:10 --> URI Class Initialized
DEBUG - 2011-06-20 13:20:10 --> Router Class Initialized
DEBUG - 2011-06-20 13:20:10 --> No URI present. Default controller set.
DEBUG - 2011-06-20 13:20:10 --> Output Class Initialized
DEBUG - 2011-06-20 13:20:10 --> Input Class Initialized
DEBUG - 2011-06-20 13:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 13:20:10 --> Language Class Initialized
DEBUG - 2011-06-20 13:20:10 --> Loader Class Initialized
DEBUG - 2011-06-20 13:20:10 --> Controller Class Initialized
DEBUG - 2011-06-20 13:20:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-20 13:20:10 --> Helper loaded: url_helper
DEBUG - 2011-06-20 13:20:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 13:20:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 13:20:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 13:20:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 13:20:10 --> Final output sent to browser
DEBUG - 2011-06-20 13:20:10 --> Total execution time: 0.1167
DEBUG - 2011-06-20 15:15:54 --> Config Class Initialized
DEBUG - 2011-06-20 15:15:54 --> Hooks Class Initialized
DEBUG - 2011-06-20 15:15:54 --> Utf8 Class Initialized
DEBUG - 2011-06-20 15:15:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 15:15:54 --> URI Class Initialized
DEBUG - 2011-06-20 15:15:54 --> Router Class Initialized
ERROR - 2011-06-20 15:15:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-20 15:15:56 --> Config Class Initialized
DEBUG - 2011-06-20 15:15:56 --> Hooks Class Initialized
DEBUG - 2011-06-20 15:15:56 --> Utf8 Class Initialized
DEBUG - 2011-06-20 15:15:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 15:15:56 --> URI Class Initialized
DEBUG - 2011-06-20 15:15:56 --> Router Class Initialized
DEBUG - 2011-06-20 15:15:56 --> No URI present. Default controller set.
DEBUG - 2011-06-20 15:15:56 --> Output Class Initialized
DEBUG - 2011-06-20 15:15:56 --> Input Class Initialized
DEBUG - 2011-06-20 15:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 15:15:56 --> Language Class Initialized
DEBUG - 2011-06-20 15:15:57 --> Loader Class Initialized
DEBUG - 2011-06-20 15:15:57 --> Controller Class Initialized
DEBUG - 2011-06-20 15:15:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-20 15:15:57 --> Helper loaded: url_helper
DEBUG - 2011-06-20 15:15:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 15:15:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 15:15:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 15:15:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 15:15:57 --> Final output sent to browser
DEBUG - 2011-06-20 15:15:57 --> Total execution time: 0.4264
DEBUG - 2011-06-20 15:35:15 --> Config Class Initialized
DEBUG - 2011-06-20 15:35:15 --> Hooks Class Initialized
DEBUG - 2011-06-20 15:35:15 --> Utf8 Class Initialized
DEBUG - 2011-06-20 15:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 15:35:15 --> URI Class Initialized
DEBUG - 2011-06-20 15:35:15 --> Router Class Initialized
DEBUG - 2011-06-20 15:35:15 --> No URI present. Default controller set.
DEBUG - 2011-06-20 15:35:15 --> Output Class Initialized
DEBUG - 2011-06-20 15:35:15 --> Input Class Initialized
DEBUG - 2011-06-20 15:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 15:35:15 --> Language Class Initialized
DEBUG - 2011-06-20 15:35:15 --> Loader Class Initialized
DEBUG - 2011-06-20 15:35:15 --> Controller Class Initialized
DEBUG - 2011-06-20 15:35:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-20 15:35:15 --> Helper loaded: url_helper
DEBUG - 2011-06-20 15:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 15:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 15:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 15:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 15:35:15 --> Final output sent to browser
DEBUG - 2011-06-20 15:35:15 --> Total execution time: 0.1722
DEBUG - 2011-06-20 15:48:50 --> Config Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Hooks Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Utf8 Class Initialized
DEBUG - 2011-06-20 15:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 15:48:50 --> URI Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Router Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Output Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Input Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 15:48:50 --> Language Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Loader Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Controller Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Model Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Model Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Model Class Initialized
DEBUG - 2011-06-20 15:48:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 15:48:50 --> Database Driver Class Initialized
DEBUG - 2011-06-20 15:48:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 15:48:51 --> Helper loaded: url_helper
DEBUG - 2011-06-20 15:48:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 15:48:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 15:48:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 15:48:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 15:48:51 --> Final output sent to browser
DEBUG - 2011-06-20 15:48:51 --> Total execution time: 0.7387
DEBUG - 2011-06-20 15:48:51 --> Config Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Hooks Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Utf8 Class Initialized
DEBUG - 2011-06-20 15:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 15:48:51 --> URI Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Router Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Output Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Input Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 15:48:51 --> Language Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Loader Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Controller Class Initialized
ERROR - 2011-06-20 15:48:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 15:48:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 15:48:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 15:48:51 --> Model Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Model Class Initialized
DEBUG - 2011-06-20 15:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 15:48:51 --> Database Driver Class Initialized
DEBUG - 2011-06-20 15:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 15:48:52 --> Helper loaded: url_helper
DEBUG - 2011-06-20 15:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 15:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 15:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 15:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 15:48:52 --> Final output sent to browser
DEBUG - 2011-06-20 15:48:52 --> Total execution time: 0.0747
DEBUG - 2011-06-20 16:02:47 --> Config Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:02:47 --> URI Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Router Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Output Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Input Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:02:47 --> Language Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Loader Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Controller Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Model Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Model Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Model Class Initialized
DEBUG - 2011-06-20 16:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:02:47 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:02:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 16:02:48 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:02:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:02:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:02:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:02:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:02:48 --> Final output sent to browser
DEBUG - 2011-06-20 16:02:48 --> Total execution time: 0.1263
DEBUG - 2011-06-20 16:02:50 --> Config Class Initialized
DEBUG - 2011-06-20 16:02:50 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:02:50 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:02:50 --> URI Class Initialized
DEBUG - 2011-06-20 16:02:50 --> Router Class Initialized
ERROR - 2011-06-20 16:02:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 16:02:50 --> Config Class Initialized
DEBUG - 2011-06-20 16:02:50 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:02:50 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:02:50 --> URI Class Initialized
DEBUG - 2011-06-20 16:02:50 --> Router Class Initialized
ERROR - 2011-06-20 16:02:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 16:02:51 --> Config Class Initialized
DEBUG - 2011-06-20 16:02:51 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:02:51 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:02:51 --> URI Class Initialized
DEBUG - 2011-06-20 16:02:51 --> Router Class Initialized
ERROR - 2011-06-20 16:02:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 16:02:56 --> Config Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:02:56 --> URI Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Router Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Output Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Input Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:02:56 --> Language Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Loader Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Controller Class Initialized
ERROR - 2011-06-20 16:02:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:02:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:02:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:02:56 --> Model Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Model Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:02:56 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:02:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:02:56 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:02:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:02:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:02:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:02:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:02:56 --> Final output sent to browser
DEBUG - 2011-06-20 16:02:56 --> Total execution time: 0.1952
DEBUG - 2011-06-20 16:02:56 --> Config Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:02:56 --> URI Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Router Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Output Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Input Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:02:56 --> Language Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Loader Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Controller Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Model Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Model Class Initialized
DEBUG - 2011-06-20 16:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:02:56 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:02:57 --> Final output sent to browser
DEBUG - 2011-06-20 16:02:57 --> Total execution time: 0.7198
DEBUG - 2011-06-20 16:03:13 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:13 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:13 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Controller Class Initialized
ERROR - 2011-06-20 16:03:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:03:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:13 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:13 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:13 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:13 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:13 --> Total execution time: 0.0294
DEBUG - 2011-06-20 16:03:14 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:14 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:14 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Controller Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:14 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:14 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:14 --> Total execution time: 0.6422
DEBUG - 2011-06-20 16:03:18 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:18 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:18 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:18 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:18 --> Router Class Initialized
ERROR - 2011-06-20 16:03:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-20 16:03:19 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:19 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:19 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Controller Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:19 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 16:03:19 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:19 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:19 --> Total execution time: 0.0425
DEBUG - 2011-06-20 16:03:27 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:27 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:27 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Controller Class Initialized
ERROR - 2011-06-20 16:03:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:03:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:27 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:27 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:27 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:27 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:27 --> Total execution time: 0.0300
DEBUG - 2011-06-20 16:03:27 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:27 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:27 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Controller Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:27 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:27 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:27 --> Total execution time: 0.6086
DEBUG - 2011-06-20 16:03:40 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:40 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:40 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Controller Class Initialized
ERROR - 2011-06-20 16:03:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:03:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:03:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:40 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:40 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:40 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:40 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:40 --> Total execution time: 0.0371
DEBUG - 2011-06-20 16:03:40 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:40 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:40 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Controller Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:40 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:41 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:41 --> Total execution time: 0.5178
DEBUG - 2011-06-20 16:03:42 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:42 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:42 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Controller Class Initialized
ERROR - 2011-06-20 16:03:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:03:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:03:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:42 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:42 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:42 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:42 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:42 --> Total execution time: 0.0272
DEBUG - 2011-06-20 16:03:44 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:44 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:44 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Controller Class Initialized
ERROR - 2011-06-20 16:03:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:03:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:03:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:44 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:44 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:44 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:44 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:44 --> Total execution time: 0.0282
DEBUG - 2011-06-20 16:03:46 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:46 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:46 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Controller Class Initialized
ERROR - 2011-06-20 16:03:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:03:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:03:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:46 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:46 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:46 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:46 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:46 --> Total execution time: 0.0284
DEBUG - 2011-06-20 16:03:53 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:53 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:53 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Controller Class Initialized
ERROR - 2011-06-20 16:03:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:03:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:53 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:53 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:53 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:53 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:53 --> Total execution time: 0.0272
DEBUG - 2011-06-20 16:03:53 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:53 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:53 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Controller Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:53 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:54 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:54 --> Total execution time: 0.5385
DEBUG - 2011-06-20 16:03:55 --> Config Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:03:55 --> URI Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Router Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Output Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Input Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:03:55 --> Language Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Loader Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Controller Class Initialized
ERROR - 2011-06-20 16:03:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:03:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:03:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:55 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Model Class Initialized
DEBUG - 2011-06-20 16:03:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:03:55 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:03:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:03:55 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:03:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:03:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:03:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:03:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:03:55 --> Final output sent to browser
DEBUG - 2011-06-20 16:03:55 --> Total execution time: 0.0333
DEBUG - 2011-06-20 16:04:05 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:05 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:05 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Controller Class Initialized
ERROR - 2011-06-20 16:04:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:04:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:05 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:05 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:05 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:04:05 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:05 --> Total execution time: 0.0265
DEBUG - 2011-06-20 16:04:05 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:05 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:05 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Controller Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:05 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:05 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:05 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Controller Class Initialized
ERROR - 2011-06-20 16:04:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:04:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:05 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:05 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:05 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:04:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:04:05 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:05 --> Total execution time: 0.0272
DEBUG - 2011-06-20 16:04:05 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:05 --> Total execution time: 0.5387
DEBUG - 2011-06-20 16:04:06 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:06 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:06 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Controller Class Initialized
ERROR - 2011-06-20 16:04:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:04:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:04:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:06 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:06 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:06 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:04:06 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:06 --> Total execution time: 0.0290
DEBUG - 2011-06-20 16:04:25 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:25 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:25 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Controller Class Initialized
ERROR - 2011-06-20 16:04:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:04:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:25 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:25 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:25 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:04:25 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:25 --> Total execution time: 0.0282
DEBUG - 2011-06-20 16:04:25 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:25 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:25 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Controller Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:25 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:26 --> Total execution time: 0.5950
DEBUG - 2011-06-20 16:04:26 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:26 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:26 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Controller Class Initialized
ERROR - 2011-06-20 16:04:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:04:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:04:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:26 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:26 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:26 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:04:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:04:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:04:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:04:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:04:26 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:26 --> Total execution time: 0.0268
DEBUG - 2011-06-20 16:04:33 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:33 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:33 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Controller Class Initialized
ERROR - 2011-06-20 16:04:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:04:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:04:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:33 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:33 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:33 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:04:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:04:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:04:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:04:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:04:33 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:33 --> Total execution time: 0.0268
DEBUG - 2011-06-20 16:04:34 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:34 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:34 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Controller Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:34 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:39 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:39 --> Total execution time: 5.4699
DEBUG - 2011-06-20 16:04:40 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:40 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:40 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Controller Class Initialized
ERROR - 2011-06-20 16:04:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:04:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:04:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:40 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:40 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:04:40 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:04:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:04:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:04:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:04:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:04:40 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:40 --> Total execution time: 0.0679
DEBUG - 2011-06-20 16:04:41 --> Config Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:04:41 --> URI Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Router Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Output Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Input Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:04:41 --> Language Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Loader Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Controller Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Model Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:04:41 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:04:41 --> Final output sent to browser
DEBUG - 2011-06-20 16:04:41 --> Total execution time: 0.5533
DEBUG - 2011-06-20 16:05:08 --> Config Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:05:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:05:08 --> URI Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Router Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Output Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Input Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:05:08 --> Language Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Loader Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Controller Class Initialized
ERROR - 2011-06-20 16:05:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:05:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:05:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:05:08 --> Model Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Model Class Initialized
DEBUG - 2011-06-20 16:05:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:05:08 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:05:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:05:08 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:05:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:05:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:05:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:05:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:05:08 --> Final output sent to browser
DEBUG - 2011-06-20 16:05:08 --> Total execution time: 0.0287
DEBUG - 2011-06-20 16:05:24 --> Config Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:05:24 --> URI Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Router Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Output Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Input Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:05:24 --> Language Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Loader Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Controller Class Initialized
ERROR - 2011-06-20 16:05:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:05:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:05:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:05:24 --> Model Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Model Class Initialized
DEBUG - 2011-06-20 16:05:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:05:24 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:05:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:05:24 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:05:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:05:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:05:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:05:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:05:24 --> Final output sent to browser
DEBUG - 2011-06-20 16:05:24 --> Total execution time: 0.0271
DEBUG - 2011-06-20 16:05:52 --> Config Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:05:52 --> URI Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Router Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Output Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Input Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:05:52 --> Language Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Loader Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Controller Class Initialized
ERROR - 2011-06-20 16:05:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:05:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:05:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:05:52 --> Model Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Model Class Initialized
DEBUG - 2011-06-20 16:05:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:05:52 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:05:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:05:52 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:05:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:05:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:05:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:05:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:05:52 --> Final output sent to browser
DEBUG - 2011-06-20 16:05:52 --> Total execution time: 0.0311
DEBUG - 2011-06-20 16:05:53 --> Config Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:05:53 --> URI Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Router Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Output Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Input Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:05:53 --> Language Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Loader Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Controller Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Model Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Model Class Initialized
DEBUG - 2011-06-20 16:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:05:53 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:05:54 --> Final output sent to browser
DEBUG - 2011-06-20 16:05:54 --> Total execution time: 0.5040
DEBUG - 2011-06-20 16:05:55 --> Config Class Initialized
DEBUG - 2011-06-20 16:05:55 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:05:55 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:05:55 --> URI Class Initialized
DEBUG - 2011-06-20 16:05:55 --> Router Class Initialized
ERROR - 2011-06-20 16:05:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 16:58:59 --> Config Class Initialized
DEBUG - 2011-06-20 16:58:59 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:58:59 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:58:59 --> URI Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Router Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Output Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Input Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:59:00 --> Language Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Loader Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Controller Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Model Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Model Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Model Class Initialized
DEBUG - 2011-06-20 16:59:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:59:00 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:59:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 16:59:01 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:59:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:59:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:59:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:59:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:59:01 --> Final output sent to browser
DEBUG - 2011-06-20 16:59:01 --> Total execution time: 2.3155
DEBUG - 2011-06-20 16:59:02 --> Config Class Initialized
DEBUG - 2011-06-20 16:59:02 --> Hooks Class Initialized
DEBUG - 2011-06-20 16:59:02 --> Utf8 Class Initialized
DEBUG - 2011-06-20 16:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 16:59:02 --> URI Class Initialized
DEBUG - 2011-06-20 16:59:02 --> Router Class Initialized
DEBUG - 2011-06-20 16:59:02 --> Output Class Initialized
DEBUG - 2011-06-20 16:59:02 --> Input Class Initialized
DEBUG - 2011-06-20 16:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 16:59:02 --> Language Class Initialized
DEBUG - 2011-06-20 16:59:02 --> Loader Class Initialized
DEBUG - 2011-06-20 16:59:02 --> Controller Class Initialized
ERROR - 2011-06-20 16:59:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 16:59:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 16:59:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:59:03 --> Model Class Initialized
DEBUG - 2011-06-20 16:59:03 --> Model Class Initialized
DEBUG - 2011-06-20 16:59:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 16:59:03 --> Database Driver Class Initialized
DEBUG - 2011-06-20 16:59:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 16:59:03 --> Helper loaded: url_helper
DEBUG - 2011-06-20 16:59:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 16:59:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 16:59:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 16:59:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 16:59:03 --> Final output sent to browser
DEBUG - 2011-06-20 16:59:03 --> Total execution time: 0.5435
DEBUG - 2011-06-20 18:15:50 --> Config Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Hooks Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Utf8 Class Initialized
DEBUG - 2011-06-20 18:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 18:15:50 --> URI Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Router Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Output Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Input Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 18:15:50 --> Language Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Loader Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Controller Class Initialized
ERROR - 2011-06-20 18:15:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 18:15:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 18:15:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 18:15:50 --> Model Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Model Class Initialized
DEBUG - 2011-06-20 18:15:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 18:15:50 --> Database Driver Class Initialized
DEBUG - 2011-06-20 18:15:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 18:15:50 --> Helper loaded: url_helper
DEBUG - 2011-06-20 18:15:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 18:15:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 18:15:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 18:15:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 18:15:50 --> Final output sent to browser
DEBUG - 2011-06-20 18:15:50 --> Total execution time: 0.3150
DEBUG - 2011-06-20 18:46:12 --> Config Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Hooks Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Utf8 Class Initialized
DEBUG - 2011-06-20 18:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 18:46:12 --> URI Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Router Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Output Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Input Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 18:46:12 --> Language Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Loader Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Controller Class Initialized
ERROR - 2011-06-20 18:46:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 18:46:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 18:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 18:46:12 --> Model Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Model Class Initialized
DEBUG - 2011-06-20 18:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 18:46:12 --> Database Driver Class Initialized
DEBUG - 2011-06-20 18:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 18:46:12 --> Helper loaded: url_helper
DEBUG - 2011-06-20 18:46:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 18:46:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 18:46:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 18:46:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 18:46:12 --> Final output sent to browser
DEBUG - 2011-06-20 18:46:12 --> Total execution time: 0.2169
DEBUG - 2011-06-20 18:46:13 --> Config Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Hooks Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Utf8 Class Initialized
DEBUG - 2011-06-20 18:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 18:46:13 --> URI Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Router Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Output Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Input Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 18:46:13 --> Language Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Loader Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Controller Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Model Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Model Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 18:46:13 --> Database Driver Class Initialized
DEBUG - 2011-06-20 18:46:13 --> Final output sent to browser
DEBUG - 2011-06-20 18:46:13 --> Total execution time: 0.6032
DEBUG - 2011-06-20 18:46:16 --> Config Class Initialized
DEBUG - 2011-06-20 18:46:16 --> Hooks Class Initialized
DEBUG - 2011-06-20 18:46:16 --> Utf8 Class Initialized
DEBUG - 2011-06-20 18:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 18:46:16 --> URI Class Initialized
DEBUG - 2011-06-20 18:46:16 --> Router Class Initialized
ERROR - 2011-06-20 18:46:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 18:46:16 --> Config Class Initialized
DEBUG - 2011-06-20 18:46:16 --> Hooks Class Initialized
DEBUG - 2011-06-20 18:46:16 --> Utf8 Class Initialized
DEBUG - 2011-06-20 18:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 18:46:16 --> URI Class Initialized
DEBUG - 2011-06-20 18:46:16 --> Router Class Initialized
ERROR - 2011-06-20 18:46:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 19:25:49 --> Config Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Hooks Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Utf8 Class Initialized
DEBUG - 2011-06-20 19:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 19:25:49 --> URI Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Router Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Output Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Input Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 19:25:49 --> Language Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Loader Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Controller Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Model Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Model Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Model Class Initialized
DEBUG - 2011-06-20 19:25:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 19:25:49 --> Database Driver Class Initialized
DEBUG - 2011-06-20 19:25:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 19:25:49 --> Helper loaded: url_helper
DEBUG - 2011-06-20 19:25:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 19:25:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 19:25:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 19:25:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 19:25:49 --> Final output sent to browser
DEBUG - 2011-06-20 19:25:49 --> Total execution time: 0.4697
DEBUG - 2011-06-20 19:25:53 --> Config Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Hooks Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Utf8 Class Initialized
DEBUG - 2011-06-20 19:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 19:25:53 --> URI Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Router Class Initialized
ERROR - 2011-06-20 19:25:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 19:25:53 --> Config Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Hooks Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Utf8 Class Initialized
DEBUG - 2011-06-20 19:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 19:25:53 --> URI Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Router Class Initialized
ERROR - 2011-06-20 19:25:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 19:25:53 --> Config Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Hooks Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Utf8 Class Initialized
DEBUG - 2011-06-20 19:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 19:25:53 --> URI Class Initialized
DEBUG - 2011-06-20 19:25:53 --> Router Class Initialized
ERROR - 2011-06-20 19:25:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 21:09:10 --> Config Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:09:10 --> URI Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Router Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Output Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Input Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 21:09:10 --> Language Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Loader Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Controller Class Initialized
ERROR - 2011-06-20 21:09:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 21:09:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 21:09:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 21:09:10 --> Model Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Model Class Initialized
DEBUG - 2011-06-20 21:09:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 21:09:10 --> Database Driver Class Initialized
DEBUG - 2011-06-20 21:09:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 21:09:10 --> Helper loaded: url_helper
DEBUG - 2011-06-20 21:09:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 21:09:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 21:09:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 21:09:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 21:09:10 --> Final output sent to browser
DEBUG - 2011-06-20 21:09:10 --> Total execution time: 0.3314
DEBUG - 2011-06-20 21:09:11 --> Config Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:09:11 --> URI Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Router Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Output Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Input Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 21:09:11 --> Language Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Loader Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Controller Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Model Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Model Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 21:09:11 --> Database Driver Class Initialized
DEBUG - 2011-06-20 21:09:11 --> Final output sent to browser
DEBUG - 2011-06-20 21:09:11 --> Total execution time: 0.7584
DEBUG - 2011-06-20 21:09:13 --> Config Class Initialized
DEBUG - 2011-06-20 21:09:13 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:09:13 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:09:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:09:13 --> URI Class Initialized
DEBUG - 2011-06-20 21:09:13 --> Router Class Initialized
ERROR - 2011-06-20 21:09:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 21:09:13 --> Config Class Initialized
DEBUG - 2011-06-20 21:09:13 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:09:13 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:09:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:09:13 --> URI Class Initialized
DEBUG - 2011-06-20 21:09:13 --> Router Class Initialized
ERROR - 2011-06-20 21:09:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 21:09:14 --> Config Class Initialized
DEBUG - 2011-06-20 21:09:14 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:09:14 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:09:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:09:14 --> URI Class Initialized
DEBUG - 2011-06-20 21:09:14 --> Router Class Initialized
ERROR - 2011-06-20 21:09:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 21:09:34 --> Config Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:09:34 --> URI Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Router Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Output Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Input Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 21:09:34 --> Language Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Loader Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Controller Class Initialized
ERROR - 2011-06-20 21:09:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 21:09:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 21:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 21:09:34 --> Model Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Model Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 21:09:34 --> Database Driver Class Initialized
DEBUG - 2011-06-20 21:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 21:09:34 --> Helper loaded: url_helper
DEBUG - 2011-06-20 21:09:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 21:09:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 21:09:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 21:09:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 21:09:34 --> Final output sent to browser
DEBUG - 2011-06-20 21:09:34 --> Total execution time: 0.0368
DEBUG - 2011-06-20 21:09:34 --> Config Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:09:34 --> URI Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Router Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Output Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Input Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 21:09:34 --> Language Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Loader Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Controller Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Model Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Model Class Initialized
DEBUG - 2011-06-20 21:09:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 21:09:34 --> Database Driver Class Initialized
DEBUG - 2011-06-20 21:09:35 --> Final output sent to browser
DEBUG - 2011-06-20 21:09:35 --> Total execution time: 0.6125
DEBUG - 2011-06-20 21:44:10 --> Config Class Initialized
DEBUG - 2011-06-20 21:44:10 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:44:10 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:44:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:44:10 --> URI Class Initialized
DEBUG - 2011-06-20 21:44:10 --> Router Class Initialized
ERROR - 2011-06-20 21:44:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-20 21:45:10 --> Config Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Hooks Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Utf8 Class Initialized
DEBUG - 2011-06-20 21:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 21:45:10 --> URI Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Router Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Output Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Input Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 21:45:10 --> Language Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Loader Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Controller Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Model Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Model Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Model Class Initialized
DEBUG - 2011-06-20 21:45:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 21:45:10 --> Database Driver Class Initialized
DEBUG - 2011-06-20 21:45:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-20 21:45:11 --> Helper loaded: url_helper
DEBUG - 2011-06-20 21:45:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 21:45:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 21:45:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 21:45:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 21:45:11 --> Final output sent to browser
DEBUG - 2011-06-20 21:45:11 --> Total execution time: 0.4409
DEBUG - 2011-06-20 23:42:06 --> Config Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:42:06 --> URI Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Router Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Output Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Input Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:42:06 --> Language Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Loader Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Controller Class Initialized
ERROR - 2011-06-20 23:42:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:42:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:42:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:42:06 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:42:06 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:42:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:42:06 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:42:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:42:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:42:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:42:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:42:06 --> Final output sent to browser
DEBUG - 2011-06-20 23:42:06 --> Total execution time: 0.3312
DEBUG - 2011-06-20 23:42:13 --> Config Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:42:13 --> URI Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Router Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Output Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Input Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:42:13 --> Language Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Loader Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Controller Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:42:13 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:42:14 --> Final output sent to browser
DEBUG - 2011-06-20 23:42:14 --> Total execution time: 0.7122
DEBUG - 2011-06-20 23:42:16 --> Config Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:42:16 --> URI Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Router Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Output Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Input Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:42:16 --> Language Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Loader Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Controller Class Initialized
ERROR - 2011-06-20 23:42:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:42:16 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:42:16 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:42:16 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:42:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:42:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:42:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:42:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:42:16 --> Final output sent to browser
DEBUG - 2011-06-20 23:42:16 --> Total execution time: 0.0266
DEBUG - 2011-06-20 23:42:21 --> Config Class Initialized
DEBUG - 2011-06-20 23:42:21 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:42:21 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:42:21 --> URI Class Initialized
DEBUG - 2011-06-20 23:42:21 --> Router Class Initialized
ERROR - 2011-06-20 23:42:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 23:42:45 --> Config Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:42:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:42:45 --> URI Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Router Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Output Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Input Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:42:45 --> Language Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Loader Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Controller Class Initialized
ERROR - 2011-06-20 23:42:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:42:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:42:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:42:45 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:42:45 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:42:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:42:45 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:42:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:42:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:42:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:42:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:42:45 --> Final output sent to browser
DEBUG - 2011-06-20 23:42:45 --> Total execution time: 0.1188
DEBUG - 2011-06-20 23:42:46 --> Config Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:42:46 --> URI Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Router Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Output Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Input Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:42:46 --> Language Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Loader Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Controller Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Model Class Initialized
DEBUG - 2011-06-20 23:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:42:46 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:42:47 --> Final output sent to browser
DEBUG - 2011-06-20 23:42:47 --> Total execution time: 0.9995
DEBUG - 2011-06-20 23:42:53 --> Config Class Initialized
DEBUG - 2011-06-20 23:42:53 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:42:53 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:42:53 --> URI Class Initialized
DEBUG - 2011-06-20 23:42:53 --> Router Class Initialized
ERROR - 2011-06-20 23:42:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 23:43:28 --> Config Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:43:28 --> URI Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Router Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Output Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Input Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:43:28 --> Language Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Loader Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Controller Class Initialized
ERROR - 2011-06-20 23:43:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:43:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:43:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:43:28 --> Model Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Model Class Initialized
DEBUG - 2011-06-20 23:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:43:28 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:43:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:43:29 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:43:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:43:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:43:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:43:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:43:29 --> Final output sent to browser
DEBUG - 2011-06-20 23:43:29 --> Total execution time: 0.2922
DEBUG - 2011-06-20 23:43:30 --> Config Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:43:30 --> URI Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Router Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Output Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Input Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:43:30 --> Language Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Loader Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Controller Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Model Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Model Class Initialized
DEBUG - 2011-06-20 23:43:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:43:30 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:43:31 --> Final output sent to browser
DEBUG - 2011-06-20 23:43:31 --> Total execution time: 0.7235
DEBUG - 2011-06-20 23:43:37 --> Config Class Initialized
DEBUG - 2011-06-20 23:43:37 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:43:37 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:43:37 --> URI Class Initialized
DEBUG - 2011-06-20 23:43:37 --> Router Class Initialized
ERROR - 2011-06-20 23:43:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 23:53:39 --> Config Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:53:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:53:39 --> URI Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Router Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Output Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Input Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:53:39 --> Language Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Loader Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Controller Class Initialized
ERROR - 2011-06-20 23:53:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:53:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:53:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:53:39 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:53:39 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:53:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:53:39 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:53:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:53:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:53:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:53:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:53:39 --> Final output sent to browser
DEBUG - 2011-06-20 23:53:39 --> Total execution time: 0.0315
DEBUG - 2011-06-20 23:53:40 --> Config Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:53:40 --> URI Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Router Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Output Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Input Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:53:40 --> Language Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Loader Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Controller Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:53:40 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:53:40 --> Final output sent to browser
DEBUG - 2011-06-20 23:53:40 --> Total execution time: 0.4635
DEBUG - 2011-06-20 23:53:43 --> Config Class Initialized
DEBUG - 2011-06-20 23:53:43 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:53:43 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:53:43 --> URI Class Initialized
DEBUG - 2011-06-20 23:53:43 --> Router Class Initialized
ERROR - 2011-06-20 23:53:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 23:53:43 --> Config Class Initialized
DEBUG - 2011-06-20 23:53:43 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:53:43 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:53:43 --> URI Class Initialized
DEBUG - 2011-06-20 23:53:43 --> Router Class Initialized
ERROR - 2011-06-20 23:53:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-20 23:53:55 --> Config Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:53:55 --> URI Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Router Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Output Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Input Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:53:55 --> Language Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Loader Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Controller Class Initialized
ERROR - 2011-06-20 23:53:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:53:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:53:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:53:55 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:53:55 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:53:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:53:55 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:53:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:53:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:53:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:53:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:53:55 --> Final output sent to browser
DEBUG - 2011-06-20 23:53:55 --> Total execution time: 0.0287
DEBUG - 2011-06-20 23:53:56 --> Config Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:53:56 --> URI Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Router Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Output Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Input Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:53:56 --> Language Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Loader Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Controller Class Initialized
ERROR - 2011-06-20 23:53:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:53:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:53:56 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:53:56 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:53:56 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:53:56 --> Final output sent to browser
DEBUG - 2011-06-20 23:53:56 --> Total execution time: 0.0297
DEBUG - 2011-06-20 23:53:56 --> Config Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:53:56 --> URI Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Router Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Output Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Input Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:53:56 --> Language Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Loader Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Controller Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Model Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:53:56 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:53:56 --> Final output sent to browser
DEBUG - 2011-06-20 23:53:56 --> Total execution time: 0.4993
DEBUG - 2011-06-20 23:54:06 --> Config Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:54:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:54:06 --> URI Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Router Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Output Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Input Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:54:06 --> Language Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Loader Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Controller Class Initialized
ERROR - 2011-06-20 23:54:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:54:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:54:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:54:06 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:54:06 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:54:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:54:06 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:54:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:54:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:54:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:54:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:54:06 --> Final output sent to browser
DEBUG - 2011-06-20 23:54:06 --> Total execution time: 0.0286
DEBUG - 2011-06-20 23:54:07 --> Config Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:54:07 --> URI Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Router Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Output Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Input Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:54:07 --> Language Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Loader Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Controller Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:54:07 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:54:07 --> Final output sent to browser
DEBUG - 2011-06-20 23:54:07 --> Total execution time: 0.5559
DEBUG - 2011-06-20 23:54:17 --> Config Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:54:17 --> URI Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Router Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Output Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Input Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:54:17 --> Language Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Loader Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Controller Class Initialized
ERROR - 2011-06-20 23:54:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:54:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:54:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:54:17 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:54:17 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:54:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:54:17 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:54:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:54:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:54:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:54:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:54:17 --> Final output sent to browser
DEBUG - 2011-06-20 23:54:17 --> Total execution time: 0.0325
DEBUG - 2011-06-20 23:54:18 --> Config Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:54:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:54:18 --> URI Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Router Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Output Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Input Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:54:18 --> Language Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Loader Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Controller Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:54:18 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:54:18 --> Final output sent to browser
DEBUG - 2011-06-20 23:54:18 --> Total execution time: 0.5315
DEBUG - 2011-06-20 23:54:31 --> Config Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:54:31 --> URI Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Router Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Output Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Input Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:54:31 --> Language Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Loader Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Controller Class Initialized
ERROR - 2011-06-20 23:54:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:54:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:54:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:54:31 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:54:31 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:54:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:54:31 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:54:31 --> Final output sent to browser
DEBUG - 2011-06-20 23:54:31 --> Total execution time: 0.0288
DEBUG - 2011-06-20 23:54:32 --> Config Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:54:32 --> URI Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Router Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Output Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Input Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:54:32 --> Language Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Loader Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Controller Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Model Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:54:32 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:54:32 --> Final output sent to browser
DEBUG - 2011-06-20 23:54:32 --> Total execution time: 0.5112
DEBUG - 2011-06-20 23:55:46 --> Config Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:55:46 --> URI Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Router Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Output Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Input Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:55:46 --> Language Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Loader Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Controller Class Initialized
ERROR - 2011-06-20 23:55:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:55:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:55:46 --> Model Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Model Class Initialized
DEBUG - 2011-06-20 23:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:55:46 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:55:46 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:55:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:55:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:55:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:55:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:55:46 --> Final output sent to browser
DEBUG - 2011-06-20 23:55:46 --> Total execution time: 0.0301
DEBUG - 2011-06-20 23:55:47 --> Config Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:55:47 --> URI Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Router Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Output Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Input Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:55:47 --> Language Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Loader Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Controller Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Model Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Model Class Initialized
DEBUG - 2011-06-20 23:55:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:55:47 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:55:48 --> Final output sent to browser
DEBUG - 2011-06-20 23:55:48 --> Total execution time: 0.5325
DEBUG - 2011-06-20 23:56:01 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:01 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:01 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Controller Class Initialized
ERROR - 2011-06-20 23:56:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:56:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:01 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:01 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:01 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:56:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:56:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:56:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:56:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:56:01 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:01 --> Total execution time: 0.0348
DEBUG - 2011-06-20 23:56:01 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:01 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:01 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Controller Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:01 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:02 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:02 --> Total execution time: 0.5636
DEBUG - 2011-06-20 23:56:24 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:24 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:24 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Controller Class Initialized
ERROR - 2011-06-20 23:56:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:56:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:56:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:24 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:24 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:24 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:56:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:56:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:56:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:56:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:56:24 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:24 --> Total execution time: 0.0283
DEBUG - 2011-06-20 23:56:24 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:24 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:24 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Controller Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:24 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:25 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:25 --> Total execution time: 0.5256
DEBUG - 2011-06-20 23:56:35 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:35 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:35 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Controller Class Initialized
ERROR - 2011-06-20 23:56:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:56:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:56:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:35 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:35 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:35 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:56:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:56:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:56:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:56:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:56:35 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:35 --> Total execution time: 0.0276
DEBUG - 2011-06-20 23:56:35 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:35 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:35 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Controller Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:35 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:36 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:36 --> Total execution time: 0.5232
DEBUG - 2011-06-20 23:56:51 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:51 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:51 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Controller Class Initialized
ERROR - 2011-06-20 23:56:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:56:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:56:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:51 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:51 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:51 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:56:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:56:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:56:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:56:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:56:51 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:51 --> Total execution time: 0.0266
DEBUG - 2011-06-20 23:56:52 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:52 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:52 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Controller Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:52 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:52 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:52 --> Total execution time: 0.4676
DEBUG - 2011-06-20 23:56:58 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:58 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:58 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Controller Class Initialized
ERROR - 2011-06-20 23:56:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:56:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:56:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:58 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:58 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:56:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:56:58 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:56:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:56:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:56:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:56:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:56:58 --> Final output sent to browser
DEBUG - 2011-06-20 23:56:58 --> Total execution time: 0.0363
DEBUG - 2011-06-20 23:56:59 --> Config Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:56:59 --> URI Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Router Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Output Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Input Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:56:59 --> Language Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Loader Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Controller Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Model Class Initialized
DEBUG - 2011-06-20 23:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:56:59 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:57:00 --> Final output sent to browser
DEBUG - 2011-06-20 23:57:00 --> Total execution time: 0.4665
DEBUG - 2011-06-20 23:58:40 --> Config Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:58:40 --> URI Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Router Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Output Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Input Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:58:40 --> Language Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Loader Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Controller Class Initialized
ERROR - 2011-06-20 23:58:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:58:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:58:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:58:40 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:58:40 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:58:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:58:40 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:58:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:58:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:58:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:58:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:58:40 --> Final output sent to browser
DEBUG - 2011-06-20 23:58:40 --> Total execution time: 0.0292
DEBUG - 2011-06-20 23:58:41 --> Config Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:58:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:58:41 --> URI Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Router Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Output Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Input Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:58:41 --> Language Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Loader Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Controller Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:58:41 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:58:42 --> Final output sent to browser
DEBUG - 2011-06-20 23:58:42 --> Total execution time: 0.5625
DEBUG - 2011-06-20 23:58:48 --> Config Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:58:48 --> URI Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Router Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Output Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Input Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:58:48 --> Language Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Loader Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Controller Class Initialized
ERROR - 2011-06-20 23:58:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:58:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:58:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:58:48 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:58:48 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:58:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:58:48 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:58:48 --> Final output sent to browser
DEBUG - 2011-06-20 23:58:48 --> Total execution time: 0.0284
DEBUG - 2011-06-20 23:58:48 --> Config Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:58:48 --> URI Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Router Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Output Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Input Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:58:48 --> Language Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Loader Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Controller Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:58:48 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:58:49 --> Final output sent to browser
DEBUG - 2011-06-20 23:58:49 --> Total execution time: 0.6022
DEBUG - 2011-06-20 23:58:52 --> Config Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:58:52 --> URI Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Router Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Output Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Input Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:58:52 --> Language Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Loader Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Controller Class Initialized
ERROR - 2011-06-20 23:58:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:58:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:58:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:58:52 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:58:52 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:58:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:58:52 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:58:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:58:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:58:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:58:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:58:52 --> Final output sent to browser
DEBUG - 2011-06-20 23:58:52 --> Total execution time: 0.0307
DEBUG - 2011-06-20 23:58:53 --> Config Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:58:53 --> URI Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Router Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Output Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Input Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:58:53 --> Language Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Loader Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Controller Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Model Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:58:53 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:58:53 --> Final output sent to browser
DEBUG - 2011-06-20 23:58:53 --> Total execution time: 0.5732
DEBUG - 2011-06-20 23:59:10 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:10 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:10 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Controller Class Initialized
ERROR - 2011-06-20 23:59:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:59:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:10 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:10 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:10 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:59:10 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:10 --> Total execution time: 0.0321
DEBUG - 2011-06-20 23:59:10 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:10 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:10 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Controller Class Initialized
ERROR - 2011-06-20 23:59:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:59:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:10 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:10 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:10 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:59:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:59:10 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:10 --> Total execution time: 0.0283
DEBUG - 2011-06-20 23:59:11 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:11 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:11 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Controller Class Initialized
ERROR - 2011-06-20 23:59:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:59:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:59:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:11 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:11 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:11 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:11 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Controller Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:11 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:59:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:59:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:59:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:59:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:59:11 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:11 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:11 --> Total execution time: 0.0294
DEBUG - 2011-06-20 23:59:11 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:11 --> Total execution time: 0.5588
DEBUG - 2011-06-20 23:59:16 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:16 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:16 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Controller Class Initialized
ERROR - 2011-06-20 23:59:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:59:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:59:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:16 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:16 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:16 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:59:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:59:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:59:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:59:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:59:16 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:16 --> Total execution time: 0.0280
DEBUG - 2011-06-20 23:59:18 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:18 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:18 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Controller Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:18 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:18 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:18 --> Total execution time: 0.5685
DEBUG - 2011-06-20 23:59:27 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:27 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:27 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Controller Class Initialized
ERROR - 2011-06-20 23:59:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:59:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:59:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:27 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:27 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:27 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:59:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:59:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:59:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:59:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:59:27 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:27 --> Total execution time: 0.0337
DEBUG - 2011-06-20 23:59:28 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:28 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:28 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Controller Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:28 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:28 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:28 --> Total execution time: 0.5743
DEBUG - 2011-06-20 23:59:32 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:32 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:32 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Controller Class Initialized
ERROR - 2011-06-20 23:59:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:59:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:59:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:32 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:32 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:32 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:59:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:59:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:59:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:59:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:59:32 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:32 --> Total execution time: 0.0294
DEBUG - 2011-06-20 23:59:40 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:40 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:40 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Controller Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:40 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:41 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:41 --> Total execution time: 0.6079
DEBUG - 2011-06-20 23:59:42 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:42 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:42 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Controller Class Initialized
ERROR - 2011-06-20 23:59:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:59:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:59:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:42 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:42 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:42 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:59:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:59:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:59:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:59:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:59:42 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:42 --> Total execution time: 0.1051
DEBUG - 2011-06-20 23:59:43 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:43 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:43 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Controller Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:43 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:44 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:44 --> Total execution time: 0.5403
DEBUG - 2011-06-20 23:59:49 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:49 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:49 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Controller Class Initialized
ERROR - 2011-06-20 23:59:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-20 23:59:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-20 23:59:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:49 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:49 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-20 23:59:49 --> Helper loaded: url_helper
DEBUG - 2011-06-20 23:59:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-20 23:59:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-20 23:59:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-20 23:59:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-20 23:59:49 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:49 --> Total execution time: 0.0294
DEBUG - 2011-06-20 23:59:50 --> Config Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Hooks Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Utf8 Class Initialized
DEBUG - 2011-06-20 23:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-20 23:59:50 --> URI Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Router Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Output Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Input Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-20 23:59:50 --> Language Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Loader Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Controller Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Model Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-20 23:59:50 --> Database Driver Class Initialized
DEBUG - 2011-06-20 23:59:50 --> Final output sent to browser
DEBUG - 2011-06-20 23:59:50 --> Total execution time: 0.5688

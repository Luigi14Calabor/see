<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-28 01:06:01 --> Config Class Initialized
DEBUG - 2011-05-28 01:06:01 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:06:01 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:06:01 --> URI Class Initialized
DEBUG - 2011-05-28 01:06:01 --> Router Class Initialized
ERROR - 2011-05-28 01:06:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-28 01:06:02 --> Config Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:06:02 --> URI Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Router Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Output Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Input Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 01:06:02 --> Language Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Loader Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Controller Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Model Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Model Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Model Class Initialized
DEBUG - 2011-05-28 01:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 01:06:02 --> Database Driver Class Initialized
DEBUG - 2011-05-28 01:06:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 01:06:03 --> Helper loaded: url_helper
DEBUG - 2011-05-28 01:06:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 01:06:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 01:06:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 01:06:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 01:06:03 --> Final output sent to browser
DEBUG - 2011-05-28 01:06:03 --> Total execution time: 1.1773
DEBUG - 2011-05-28 01:06:33 --> Config Class Initialized
DEBUG - 2011-05-28 01:06:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:06:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:06:33 --> URI Class Initialized
DEBUG - 2011-05-28 01:06:33 --> Router Class Initialized
DEBUG - 2011-05-28 01:06:33 --> Output Class Initialized
DEBUG - 2011-05-28 01:06:33 --> Input Class Initialized
DEBUG - 2011-05-28 01:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 01:06:33 --> Language Class Initialized
DEBUG - 2011-05-28 01:06:33 --> Loader Class Initialized
DEBUG - 2011-05-28 01:06:33 --> Controller Class Initialized
ERROR - 2011-05-28 01:06:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 01:06:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 01:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 01:06:34 --> Model Class Initialized
DEBUG - 2011-05-28 01:06:34 --> Model Class Initialized
DEBUG - 2011-05-28 01:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 01:06:34 --> Database Driver Class Initialized
DEBUG - 2011-05-28 01:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 01:06:34 --> Helper loaded: url_helper
DEBUG - 2011-05-28 01:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 01:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 01:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 01:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 01:06:34 --> Final output sent to browser
DEBUG - 2011-05-28 01:06:34 --> Total execution time: 0.3976
DEBUG - 2011-05-28 01:17:40 --> Config Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:17:40 --> URI Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Router Class Initialized
ERROR - 2011-05-28 01:17:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-28 01:17:40 --> Config Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:17:40 --> URI Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Router Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Output Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Input Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 01:17:40 --> Language Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Loader Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Controller Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Model Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Model Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Model Class Initialized
DEBUG - 2011-05-28 01:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 01:17:40 --> Database Driver Class Initialized
DEBUG - 2011-05-28 01:17:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 01:17:41 --> Helper loaded: url_helper
DEBUG - 2011-05-28 01:17:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 01:17:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 01:17:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 01:17:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 01:17:41 --> Final output sent to browser
DEBUG - 2011-05-28 01:17:41 --> Total execution time: 0.4918
DEBUG - 2011-05-28 01:18:11 --> Config Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:18:11 --> URI Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Router Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Output Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Input Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 01:18:11 --> Language Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Loader Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Controller Class Initialized
ERROR - 2011-05-28 01:18:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 01:18:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 01:18:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 01:18:11 --> Model Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Model Class Initialized
DEBUG - 2011-05-28 01:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 01:18:11 --> Database Driver Class Initialized
DEBUG - 2011-05-28 01:18:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 01:18:11 --> Helper loaded: url_helper
DEBUG - 2011-05-28 01:18:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 01:18:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 01:18:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 01:18:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 01:18:11 --> Final output sent to browser
DEBUG - 2011-05-28 01:18:11 --> Total execution time: 0.0356
DEBUG - 2011-05-28 02:25:37 --> Config Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:25:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:25:37 --> URI Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Router Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Output Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Input Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:25:37 --> Language Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Loader Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Controller Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Model Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Model Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Model Class Initialized
DEBUG - 2011-05-28 02:25:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:25:38 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:25:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:25:43 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:25:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:25:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:25:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:25:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:25:43 --> Final output sent to browser
DEBUG - 2011-05-28 02:25:43 --> Total execution time: 6.1493
DEBUG - 2011-05-28 02:25:46 --> Config Class Initialized
DEBUG - 2011-05-28 02:25:46 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:25:46 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:25:46 --> URI Class Initialized
DEBUG - 2011-05-28 02:25:46 --> Router Class Initialized
ERROR - 2011-05-28 02:25:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:27:37 --> Config Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:27:37 --> URI Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Router Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Output Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Input Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:27:37 --> Language Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Loader Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Controller Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Model Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Model Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Model Class Initialized
DEBUG - 2011-05-28 02:27:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:27:37 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:27:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:27:38 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:27:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:27:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:27:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:27:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:27:38 --> Final output sent to browser
DEBUG - 2011-05-28 02:27:38 --> Total execution time: 0.6686
DEBUG - 2011-05-28 02:27:39 --> Config Class Initialized
DEBUG - 2011-05-28 02:27:39 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:27:39 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:27:39 --> URI Class Initialized
DEBUG - 2011-05-28 02:27:39 --> Router Class Initialized
ERROR - 2011-05-28 02:27:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:28:08 --> Config Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:28:08 --> URI Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Router Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Output Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Input Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:28:08 --> Language Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Loader Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Controller Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:28:08 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:28:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:28:11 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:28:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:28:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:28:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:28:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:28:11 --> Final output sent to browser
DEBUG - 2011-05-28 02:28:11 --> Total execution time: 2.7628
DEBUG - 2011-05-28 02:28:13 --> Config Class Initialized
DEBUG - 2011-05-28 02:28:13 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:28:13 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:28:13 --> URI Class Initialized
DEBUG - 2011-05-28 02:28:13 --> Router Class Initialized
ERROR - 2011-05-28 02:28:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:28:17 --> Config Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:28:17 --> URI Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Router Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Output Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Input Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:28:17 --> Language Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Loader Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Controller Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:28:17 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Config Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:28:24 --> URI Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Router Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Output Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Input Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:28:24 --> Language Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Loader Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Controller Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Model Class Initialized
DEBUG - 2011-05-28 02:28:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:28:24 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:28:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:28:42 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:28:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:28:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:28:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:28:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:28:42 --> Final output sent to browser
DEBUG - 2011-05-28 02:28:42 --> Total execution time: 17.8084
DEBUG - 2011-05-28 02:28:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:28:56 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:28:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:28:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:28:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:28:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:28:56 --> Final output sent to browser
DEBUG - 2011-05-28 02:28:56 --> Total execution time: 39.0022
DEBUG - 2011-05-28 02:28:58 --> Config Class Initialized
DEBUG - 2011-05-28 02:28:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:28:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:28:58 --> URI Class Initialized
DEBUG - 2011-05-28 02:28:58 --> Router Class Initialized
ERROR - 2011-05-28 02:28:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:29:10 --> Config Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:29:10 --> URI Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Router Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Output Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Input Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:29:10 --> Language Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Loader Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Controller Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Model Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Model Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Model Class Initialized
DEBUG - 2011-05-28 02:29:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:29:10 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:29:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:29:10 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:29:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:29:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:29:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:29:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:29:10 --> Final output sent to browser
DEBUG - 2011-05-28 02:29:10 --> Total execution time: 0.0632
DEBUG - 2011-05-28 02:34:33 --> Config Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:34:33 --> URI Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Router Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Output Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Input Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:34:33 --> Language Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Loader Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Controller Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:34:34 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:34:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:34:39 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:34:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:34:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:34:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:34:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:34:39 --> Final output sent to browser
DEBUG - 2011-05-28 02:34:39 --> Total execution time: 5.6844
DEBUG - 2011-05-28 02:34:40 --> Config Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:34:40 --> URI Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Router Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Output Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Input Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:34:40 --> Language Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Loader Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Controller Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:34:40 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:34:40 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:34:40 --> Final output sent to browser
DEBUG - 2011-05-28 02:34:40 --> Total execution time: 0.0511
DEBUG - 2011-05-28 02:34:40 --> Config Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:34:40 --> URI Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Router Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Output Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Input Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:34:40 --> Language Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Loader Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Controller Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Model Class Initialized
DEBUG - 2011-05-28 02:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:34:40 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:34:40 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:34:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:34:40 --> Final output sent to browser
DEBUG - 2011-05-28 02:34:40 --> Total execution time: 0.0457
DEBUG - 2011-05-28 02:34:41 --> Config Class Initialized
DEBUG - 2011-05-28 02:34:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:34:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:34:41 --> URI Class Initialized
DEBUG - 2011-05-28 02:34:41 --> Router Class Initialized
ERROR - 2011-05-28 02:34:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:51:21 --> Config Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:51:21 --> URI Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Router Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Output Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Input Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:51:21 --> Language Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Loader Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Controller Class Initialized
DEBUG - 2011-05-28 02:51:21 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:22 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:22 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:51:22 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:51:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:51:27 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:51:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:51:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:51:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:51:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:51:27 --> Final output sent to browser
DEBUG - 2011-05-28 02:51:27 --> Total execution time: 5.6841
DEBUG - 2011-05-28 02:51:29 --> Config Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:51:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:51:29 --> URI Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Router Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Output Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Input Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:51:29 --> Language Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Loader Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Controller Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:51:29 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:51:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:51:29 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:51:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:51:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:51:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:51:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:51:29 --> Final output sent to browser
DEBUG - 2011-05-28 02:51:29 --> Total execution time: 0.0844
DEBUG - 2011-05-28 02:51:33 --> Config Class Initialized
DEBUG - 2011-05-28 02:51:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:51:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:51:33 --> URI Class Initialized
DEBUG - 2011-05-28 02:51:33 --> Router Class Initialized
ERROR - 2011-05-28 02:51:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:51:41 --> Config Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:51:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:51:41 --> URI Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Router Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Output Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Input Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:51:41 --> Language Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Loader Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Controller Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:51:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:51:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:51:56 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:51:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:51:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:51:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:51:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:51:56 --> Final output sent to browser
DEBUG - 2011-05-28 02:51:56 --> Total execution time: 15.3509
DEBUG - 2011-05-28 02:51:58 --> Config Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:51:58 --> URI Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Router Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Output Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Input Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:51:58 --> Language Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Loader Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Controller Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Model Class Initialized
DEBUG - 2011-05-28 02:51:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:51:58 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:51:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:51:58 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:51:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:51:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:51:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:51:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:51:58 --> Final output sent to browser
DEBUG - 2011-05-28 02:51:58 --> Total execution time: 0.0508
DEBUG - 2011-05-28 02:52:01 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:01 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:01 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:01 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:01 --> Router Class Initialized
ERROR - 2011-05-28 02:52:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:52:13 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:13 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Router Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Output Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Input Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:52:13 --> Language Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Loader Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Controller Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:52:13 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:52:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:52:14 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:52:14 --> Final output sent to browser
DEBUG - 2011-05-28 02:52:14 --> Total execution time: 0.8324
DEBUG - 2011-05-28 02:52:15 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:15 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Router Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Output Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Input Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:52:15 --> Language Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Loader Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Controller Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:52:15 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:52:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:52:15 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:52:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:52:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:52:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:52:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:52:15 --> Final output sent to browser
DEBUG - 2011-05-28 02:52:15 --> Total execution time: 0.0642
DEBUG - 2011-05-28 02:52:16 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:16 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Router Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Output Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Input Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:52:16 --> Language Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Loader Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Controller Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:52:16 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:52:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:52:16 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:52:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:52:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:52:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:52:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:52:16 --> Final output sent to browser
DEBUG - 2011-05-28 02:52:16 --> Total execution time: 0.1051
DEBUG - 2011-05-28 02:52:19 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:19 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:19 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:19 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:19 --> Router Class Initialized
ERROR - 2011-05-28 02:52:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:52:40 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:40 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:40 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:40 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:40 --> Router Class Initialized
ERROR - 2011-05-28 02:52:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:52:49 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:49 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Router Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Output Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Input Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:52:49 --> Language Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Loader Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Controller Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:52:49 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:52:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:52:49 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:52:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:52:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:52:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:52:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:52:49 --> Final output sent to browser
DEBUG - 2011-05-28 02:52:49 --> Total execution time: 0.6832
DEBUG - 2011-05-28 02:52:50 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:50 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Router Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Output Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Input Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:52:50 --> Language Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Loader Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Controller Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Model Class Initialized
DEBUG - 2011-05-28 02:52:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:52:50 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:52:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:52:50 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:52:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:52:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:52:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:52:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:52:50 --> Final output sent to browser
DEBUG - 2011-05-28 02:52:50 --> Total execution time: 0.0472
DEBUG - 2011-05-28 02:52:54 --> Config Class Initialized
DEBUG - 2011-05-28 02:52:54 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:52:54 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:52:54 --> URI Class Initialized
DEBUG - 2011-05-28 02:52:54 --> Router Class Initialized
ERROR - 2011-05-28 02:52:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:53:04 --> Config Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:53:04 --> URI Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Router Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Output Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Input Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:53:04 --> Language Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Loader Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Controller Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:53:04 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:53:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:53:06 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:53:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:53:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:53:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:53:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:53:06 --> Final output sent to browser
DEBUG - 2011-05-28 02:53:06 --> Total execution time: 1.7324
DEBUG - 2011-05-28 02:53:07 --> Config Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:53:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:53:07 --> URI Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Router Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Output Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Input Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:53:07 --> Language Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Loader Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Controller Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:53:07 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:53:07 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:53:07 --> Final output sent to browser
DEBUG - 2011-05-28 02:53:07 --> Total execution time: 0.0594
DEBUG - 2011-05-28 02:53:07 --> Config Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:53:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:53:07 --> URI Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Router Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Output Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Input Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:53:07 --> Language Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Loader Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Controller Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Model Class Initialized
DEBUG - 2011-05-28 02:53:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 02:53:07 --> Database Driver Class Initialized
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 02:53:07 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:53:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:53:07 --> Final output sent to browser
DEBUG - 2011-05-28 02:53:07 --> Total execution time: 0.0623
DEBUG - 2011-05-28 02:53:11 --> Config Class Initialized
DEBUG - 2011-05-28 02:53:11 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:53:11 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:53:11 --> URI Class Initialized
DEBUG - 2011-05-28 02:53:11 --> Router Class Initialized
ERROR - 2011-05-28 02:53:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:53:32 --> Config Class Initialized
DEBUG - 2011-05-28 02:53:32 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:53:32 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:53:32 --> URI Class Initialized
DEBUG - 2011-05-28 02:53:32 --> Router Class Initialized
ERROR - 2011-05-28 02:53:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:54:09 --> Config Class Initialized
DEBUG - 2011-05-28 02:54:09 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:54:09 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:54:09 --> URI Class Initialized
DEBUG - 2011-05-28 02:54:09 --> Router Class Initialized
DEBUG - 2011-05-28 02:54:09 --> No URI present. Default controller set.
DEBUG - 2011-05-28 02:54:09 --> Output Class Initialized
DEBUG - 2011-05-28 02:54:09 --> Input Class Initialized
DEBUG - 2011-05-28 02:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 02:54:09 --> Language Class Initialized
DEBUG - 2011-05-28 02:54:09 --> Loader Class Initialized
DEBUG - 2011-05-28 02:54:09 --> Controller Class Initialized
DEBUG - 2011-05-28 02:54:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 02:54:09 --> Helper loaded: url_helper
DEBUG - 2011-05-28 02:54:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 02:54:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 02:54:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 02:54:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 02:54:09 --> Final output sent to browser
DEBUG - 2011-05-28 02:54:09 --> Total execution time: 0.1264
DEBUG - 2011-05-28 02:54:53 --> Config Class Initialized
DEBUG - 2011-05-28 02:54:53 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:54:53 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:54:53 --> URI Class Initialized
DEBUG - 2011-05-28 02:54:53 --> Router Class Initialized
ERROR - 2011-05-28 02:54:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 02:56:14 --> Config Class Initialized
DEBUG - 2011-05-28 02:56:14 --> Hooks Class Initialized
DEBUG - 2011-05-28 02:56:14 --> Utf8 Class Initialized
DEBUG - 2011-05-28 02:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 02:56:14 --> URI Class Initialized
DEBUG - 2011-05-28 02:56:14 --> Router Class Initialized
ERROR - 2011-05-28 02:56:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:01:23 --> Config Class Initialized
DEBUG - 2011-05-28 03:01:23 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:01:23 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:01:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:01:23 --> URI Class Initialized
DEBUG - 2011-05-28 03:01:23 --> Router Class Initialized
DEBUG - 2011-05-28 03:01:23 --> No URI present. Default controller set.
DEBUG - 2011-05-28 03:01:23 --> Output Class Initialized
DEBUG - 2011-05-28 03:01:23 --> Input Class Initialized
DEBUG - 2011-05-28 03:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:01:23 --> Language Class Initialized
DEBUG - 2011-05-28 03:01:24 --> Loader Class Initialized
DEBUG - 2011-05-28 03:01:24 --> Controller Class Initialized
DEBUG - 2011-05-28 03:01:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 03:01:25 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:01:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:01:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:01:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:01:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:01:26 --> Final output sent to browser
DEBUG - 2011-05-28 03:01:26 --> Total execution time: 3.5167
DEBUG - 2011-05-28 03:12:26 --> Config Class Initialized
DEBUG - 2011-05-28 03:12:26 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:12:26 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:12:26 --> URI Class Initialized
DEBUG - 2011-05-28 03:12:26 --> Router Class Initialized
DEBUG - 2011-05-28 03:12:26 --> No URI present. Default controller set.
DEBUG - 2011-05-28 03:12:26 --> Output Class Initialized
DEBUG - 2011-05-28 03:12:26 --> Input Class Initialized
DEBUG - 2011-05-28 03:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:12:26 --> Language Class Initialized
DEBUG - 2011-05-28 03:12:26 --> Loader Class Initialized
DEBUG - 2011-05-28 03:12:27 --> Controller Class Initialized
DEBUG - 2011-05-28 03:12:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 03:12:27 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:12:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:12:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:12:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:12:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:12:27 --> Final output sent to browser
DEBUG - 2011-05-28 03:12:27 --> Total execution time: 1.5552
DEBUG - 2011-05-28 03:53:25 --> Config Class Initialized
DEBUG - 2011-05-28 03:53:25 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:53:25 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:53:25 --> URI Class Initialized
DEBUG - 2011-05-28 03:53:25 --> Router Class Initialized
DEBUG - 2011-05-28 03:53:25 --> No URI present. Default controller set.
DEBUG - 2011-05-28 03:53:25 --> Output Class Initialized
DEBUG - 2011-05-28 03:53:25 --> Input Class Initialized
DEBUG - 2011-05-28 03:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:53:25 --> Language Class Initialized
DEBUG - 2011-05-28 03:53:26 --> Loader Class Initialized
DEBUG - 2011-05-28 03:53:26 --> Controller Class Initialized
DEBUG - 2011-05-28 03:53:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 03:53:26 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:53:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:53:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:53:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:53:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:53:26 --> Final output sent to browser
DEBUG - 2011-05-28 03:53:26 --> Total execution time: 0.1833
DEBUG - 2011-05-28 03:53:29 --> Config Class Initialized
DEBUG - 2011-05-28 03:53:29 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:53:29 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:53:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:53:30 --> URI Class Initialized
DEBUG - 2011-05-28 03:53:30 --> Router Class Initialized
ERROR - 2011-05-28 03:53:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:54:04 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:04 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Router Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Output Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Input Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:54:04 --> Language Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Loader Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Controller Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Model Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Model Class Initialized
DEBUG - 2011-05-28 03:54:04 --> Model Class Initialized
DEBUG - 2011-05-28 03:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:54:05 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:54:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:54:14 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:54:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:54:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:54:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:54:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:54:14 --> Final output sent to browser
DEBUG - 2011-05-28 03:54:14 --> Total execution time: 9.3633
DEBUG - 2011-05-28 03:54:16 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:16 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Router Class Initialized
ERROR - 2011-05-28 03:54:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:54:16 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:16 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Router Class Initialized
ERROR - 2011-05-28 03:54:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:54:16 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:16 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:16 --> Router Class Initialized
ERROR - 2011-05-28 03:54:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:54:18 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:18 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:18 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:18 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:18 --> Router Class Initialized
ERROR - 2011-05-28 03:54:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:54:45 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:45 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Router Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Output Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Input Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:54:45 --> Language Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Loader Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Controller Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Model Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Model Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Model Class Initialized
DEBUG - 2011-05-28 03:54:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:54:45 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:54:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:54:47 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:54:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:54:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:54:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:54:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:54:47 --> Final output sent to browser
DEBUG - 2011-05-28 03:54:47 --> Total execution time: 1.7615
DEBUG - 2011-05-28 03:54:49 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:49 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:49 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:49 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:49 --> Router Class Initialized
ERROR - 2011-05-28 03:54:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:54:49 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:49 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:49 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:49 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:49 --> Router Class Initialized
ERROR - 2011-05-28 03:54:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:54:50 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:50 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:50 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:50 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:50 --> Router Class Initialized
ERROR - 2011-05-28 03:54:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:54:52 --> Config Class Initialized
DEBUG - 2011-05-28 03:54:52 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:54:52 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:54:52 --> URI Class Initialized
DEBUG - 2011-05-28 03:54:52 --> Router Class Initialized
ERROR - 2011-05-28 03:54:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:55:55 --> Config Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:55:55 --> URI Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Router Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Output Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Input Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:55:55 --> Language Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Loader Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Controller Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Model Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Model Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Model Class Initialized
DEBUG - 2011-05-28 03:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:55:55 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:55:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:55:55 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:55:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:55:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:55:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:55:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:55:55 --> Final output sent to browser
DEBUG - 2011-05-28 03:55:55 --> Total execution time: 0.2001
DEBUG - 2011-05-28 03:55:57 --> Config Class Initialized
DEBUG - 2011-05-28 03:55:57 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:55:57 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:55:57 --> URI Class Initialized
DEBUG - 2011-05-28 03:55:57 --> Router Class Initialized
ERROR - 2011-05-28 03:55:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:55:58 --> Config Class Initialized
DEBUG - 2011-05-28 03:55:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:55:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:55:58 --> URI Class Initialized
DEBUG - 2011-05-28 03:55:58 --> Router Class Initialized
ERROR - 2011-05-28 03:55:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:55:58 --> Config Class Initialized
DEBUG - 2011-05-28 03:55:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:55:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:55:58 --> URI Class Initialized
DEBUG - 2011-05-28 03:55:58 --> Router Class Initialized
ERROR - 2011-05-28 03:55:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:55:59 --> Config Class Initialized
DEBUG - 2011-05-28 03:55:59 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:55:59 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:55:59 --> URI Class Initialized
DEBUG - 2011-05-28 03:55:59 --> Router Class Initialized
ERROR - 2011-05-28 03:55:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:56:29 --> Config Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:56:29 --> URI Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Router Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Output Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Input Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:56:29 --> Language Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Loader Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Controller Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Model Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Model Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Model Class Initialized
DEBUG - 2011-05-28 03:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:56:29 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:56:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:56:31 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:56:31 --> Final output sent to browser
DEBUG - 2011-05-28 03:56:31 --> Total execution time: 1.5593
DEBUG - 2011-05-28 03:56:33 --> Config Class Initialized
DEBUG - 2011-05-28 03:56:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:56:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:56:33 --> URI Class Initialized
DEBUG - 2011-05-28 03:56:33 --> Router Class Initialized
ERROR - 2011-05-28 03:56:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:56:35 --> Config Class Initialized
DEBUG - 2011-05-28 03:56:35 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:56:35 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:56:35 --> URI Class Initialized
DEBUG - 2011-05-28 03:56:35 --> Router Class Initialized
ERROR - 2011-05-28 03:56:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:57:20 --> Config Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:57:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:57:20 --> URI Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Router Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Output Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Input Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:57:20 --> Language Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Loader Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Controller Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Model Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Model Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Model Class Initialized
DEBUG - 2011-05-28 03:57:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:57:20 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Config Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:57:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:57:31 --> URI Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Router Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Output Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Input Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:57:31 --> Language Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Loader Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Controller Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Model Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Model Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Model Class Initialized
DEBUG - 2011-05-28 03:57:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:57:31 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:57:31 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:57:31 --> Final output sent to browser
DEBUG - 2011-05-28 03:57:31 --> Total execution time: 10.4500
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:57:31 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:57:31 --> Final output sent to browser
DEBUG - 2011-05-28 03:57:31 --> Total execution time: 0.2551
DEBUG - 2011-05-28 03:57:33 --> Config Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:57:33 --> URI Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Router Class Initialized
ERROR - 2011-05-28 03:57:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:57:33 --> Config Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:57:33 --> URI Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Router Class Initialized
ERROR - 2011-05-28 03:57:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:57:33 --> Config Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:57:33 --> URI Class Initialized
DEBUG - 2011-05-28 03:57:33 --> Router Class Initialized
ERROR - 2011-05-28 03:57:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:57:35 --> Config Class Initialized
DEBUG - 2011-05-28 03:57:35 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:57:35 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:57:35 --> URI Class Initialized
DEBUG - 2011-05-28 03:57:35 --> Router Class Initialized
ERROR - 2011-05-28 03:57:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:58:21 --> Config Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:58:21 --> URI Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Router Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Output Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Input Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:58:21 --> Language Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Loader Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Controller Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Model Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Model Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Model Class Initialized
DEBUG - 2011-05-28 03:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:58:21 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:58:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:58:25 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:58:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:58:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:58:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:58:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:58:25 --> Final output sent to browser
DEBUG - 2011-05-28 03:58:25 --> Total execution time: 4.4923
DEBUG - 2011-05-28 03:58:29 --> Config Class Initialized
DEBUG - 2011-05-28 03:58:29 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:58:29 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:58:29 --> URI Class Initialized
DEBUG - 2011-05-28 03:58:29 --> Router Class Initialized
ERROR - 2011-05-28 03:58:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:58:54 --> Config Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:58:54 --> URI Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Router Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Output Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Input Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:58:54 --> Language Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Loader Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Controller Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Model Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Model Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Model Class Initialized
DEBUG - 2011-05-28 03:58:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:58:54 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:58:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:58:54 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:58:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:58:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:58:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:58:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:58:54 --> Final output sent to browser
DEBUG - 2011-05-28 03:58:54 --> Total execution time: 0.6737
DEBUG - 2011-05-28 03:58:58 --> Config Class Initialized
DEBUG - 2011-05-28 03:58:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:58:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:58:58 --> URI Class Initialized
DEBUG - 2011-05-28 03:58:58 --> Router Class Initialized
ERROR - 2011-05-28 03:58:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 03:59:11 --> Config Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:59:11 --> URI Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Router Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Output Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Input Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 03:59:11 --> Language Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Loader Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Controller Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Model Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Model Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Model Class Initialized
DEBUG - 2011-05-28 03:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 03:59:11 --> Database Driver Class Initialized
DEBUG - 2011-05-28 03:59:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 03:59:11 --> Helper loaded: url_helper
DEBUG - 2011-05-28 03:59:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 03:59:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 03:59:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 03:59:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 03:59:11 --> Final output sent to browser
DEBUG - 2011-05-28 03:59:11 --> Total execution time: 0.6175
DEBUG - 2011-05-28 03:59:15 --> Config Class Initialized
DEBUG - 2011-05-28 03:59:15 --> Hooks Class Initialized
DEBUG - 2011-05-28 03:59:15 --> Utf8 Class Initialized
DEBUG - 2011-05-28 03:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 03:59:15 --> URI Class Initialized
DEBUG - 2011-05-28 03:59:15 --> Router Class Initialized
ERROR - 2011-05-28 03:59:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 04:01:04 --> Config Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Hooks Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Utf8 Class Initialized
DEBUG - 2011-05-28 04:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 04:01:04 --> URI Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Router Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Output Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Input Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 04:01:04 --> Language Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Loader Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Controller Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Model Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Model Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Model Class Initialized
DEBUG - 2011-05-28 04:01:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 04:01:04 --> Database Driver Class Initialized
DEBUG - 2011-05-28 04:01:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 04:01:04 --> Helper loaded: url_helper
DEBUG - 2011-05-28 04:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 04:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 04:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 04:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 04:01:04 --> Final output sent to browser
DEBUG - 2011-05-28 04:01:04 --> Total execution time: 0.1139
DEBUG - 2011-05-28 04:01:05 --> Config Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Hooks Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Utf8 Class Initialized
DEBUG - 2011-05-28 04:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 04:01:05 --> URI Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Router Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Output Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Input Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 04:01:05 --> Language Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Loader Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Controller Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Model Class Initialized
DEBUG - 2011-05-28 04:01:05 --> Model Class Initialized
DEBUG - 2011-05-28 04:01:06 --> Model Class Initialized
DEBUG - 2011-05-28 04:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 04:01:06 --> Database Driver Class Initialized
DEBUG - 2011-05-28 04:01:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 04:01:06 --> Helper loaded: url_helper
DEBUG - 2011-05-28 04:01:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 04:01:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 04:01:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 04:01:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 04:01:06 --> Final output sent to browser
DEBUG - 2011-05-28 04:01:06 --> Total execution time: 0.1751
DEBUG - 2011-05-28 04:01:08 --> Config Class Initialized
DEBUG - 2011-05-28 04:01:08 --> Hooks Class Initialized
DEBUG - 2011-05-28 04:01:08 --> Utf8 Class Initialized
DEBUG - 2011-05-28 04:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 04:01:08 --> URI Class Initialized
DEBUG - 2011-05-28 04:01:08 --> Router Class Initialized
ERROR - 2011-05-28 04:01:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 06:01:01 --> Config Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Hooks Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Utf8 Class Initialized
DEBUG - 2011-05-28 06:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 06:01:01 --> URI Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Router Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Output Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Input Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 06:01:01 --> Language Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Loader Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Controller Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Model Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Model Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Model Class Initialized
DEBUG - 2011-05-28 06:01:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 06:01:01 --> Database Driver Class Initialized
DEBUG - 2011-05-28 06:01:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 06:01:03 --> Helper loaded: url_helper
DEBUG - 2011-05-28 06:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 06:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 06:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 06:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 06:01:03 --> Final output sent to browser
DEBUG - 2011-05-28 06:01:03 --> Total execution time: 1.7911
DEBUG - 2011-05-28 06:01:04 --> Config Class Initialized
DEBUG - 2011-05-28 06:01:04 --> Hooks Class Initialized
DEBUG - 2011-05-28 06:01:04 --> Utf8 Class Initialized
DEBUG - 2011-05-28 06:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 06:01:04 --> URI Class Initialized
DEBUG - 2011-05-28 06:01:04 --> Router Class Initialized
ERROR - 2011-05-28 06:01:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 06:01:05 --> Config Class Initialized
DEBUG - 2011-05-28 06:01:05 --> Hooks Class Initialized
DEBUG - 2011-05-28 06:01:05 --> Utf8 Class Initialized
DEBUG - 2011-05-28 06:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 06:01:05 --> URI Class Initialized
DEBUG - 2011-05-28 06:01:05 --> Router Class Initialized
ERROR - 2011-05-28 06:01:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 06:02:20 --> Config Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Hooks Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Utf8 Class Initialized
DEBUG - 2011-05-28 06:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 06:02:20 --> URI Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Router Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Output Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Input Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 06:02:20 --> Language Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Loader Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Controller Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Model Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Model Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Model Class Initialized
DEBUG - 2011-05-28 06:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 06:02:20 --> Database Driver Class Initialized
DEBUG - 2011-05-28 06:02:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 06:02:20 --> Helper loaded: url_helper
DEBUG - 2011-05-28 06:02:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 06:02:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 06:02:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 06:02:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 06:02:20 --> Final output sent to browser
DEBUG - 2011-05-28 06:02:20 --> Total execution time: 0.2262
DEBUG - 2011-05-28 08:39:15 --> Config Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:39:15 --> URI Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Router Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Output Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Input Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:39:15 --> Language Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Loader Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Controller Class Initialized
ERROR - 2011-05-28 08:39:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 08:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 08:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 08:39:15 --> Model Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Model Class Initialized
DEBUG - 2011-05-28 08:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:39:15 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:39:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 08:39:16 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:39:16 --> Final output sent to browser
DEBUG - 2011-05-28 08:39:16 --> Total execution time: 1.0729
DEBUG - 2011-05-28 08:39:18 --> Config Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:39:18 --> URI Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Router Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Output Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Input Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:39:18 --> Language Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Loader Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Controller Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Model Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Model Class Initialized
DEBUG - 2011-05-28 08:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:39:18 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:39:19 --> Final output sent to browser
DEBUG - 2011-05-28 08:39:19 --> Total execution time: 0.9494
DEBUG - 2011-05-28 08:39:20 --> Config Class Initialized
DEBUG - 2011-05-28 08:39:20 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:39:20 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:39:20 --> URI Class Initialized
DEBUG - 2011-05-28 08:39:20 --> Router Class Initialized
ERROR - 2011-05-28 08:39:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 08:39:21 --> Config Class Initialized
DEBUG - 2011-05-28 08:39:21 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:39:21 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:39:21 --> URI Class Initialized
DEBUG - 2011-05-28 08:39:21 --> Router Class Initialized
ERROR - 2011-05-28 08:39:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 08:40:34 --> Config Class Initialized
DEBUG - 2011-05-28 08:40:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:40:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:40:34 --> URI Class Initialized
DEBUG - 2011-05-28 08:40:34 --> Router Class Initialized
DEBUG - 2011-05-28 08:40:34 --> No URI present. Default controller set.
DEBUG - 2011-05-28 08:40:34 --> Output Class Initialized
DEBUG - 2011-05-28 08:40:34 --> Input Class Initialized
DEBUG - 2011-05-28 08:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:40:34 --> Language Class Initialized
DEBUG - 2011-05-28 08:40:34 --> Loader Class Initialized
DEBUG - 2011-05-28 08:40:34 --> Controller Class Initialized
DEBUG - 2011-05-28 08:40:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 08:40:34 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:40:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:40:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:40:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:40:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:40:34 --> Final output sent to browser
DEBUG - 2011-05-28 08:40:34 --> Total execution time: 0.0828
DEBUG - 2011-05-28 08:40:41 --> Config Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:40:41 --> URI Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Router Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Output Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Input Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:40:41 --> Language Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Loader Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Controller Class Initialized
ERROR - 2011-05-28 08:40:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 08:40:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 08:40:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 08:40:41 --> Model Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Model Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:40:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:40:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 08:40:41 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:40:41 --> Final output sent to browser
DEBUG - 2011-05-28 08:40:41 --> Total execution time: 0.0313
DEBUG - 2011-05-28 08:40:41 --> Config Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:40:41 --> URI Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Router Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Output Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Input Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:40:41 --> Language Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Loader Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Controller Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Model Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Model Class Initialized
DEBUG - 2011-05-28 08:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:40:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:40:42 --> Final output sent to browser
DEBUG - 2011-05-28 08:40:42 --> Total execution time: 0.7122
DEBUG - 2011-05-28 08:40:47 --> Config Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:40:47 --> URI Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Router Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Output Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Input Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:40:47 --> Language Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Loader Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Controller Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Model Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Model Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Model Class Initialized
DEBUG - 2011-05-28 08:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:40:47 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:40:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:40:47 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:40:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:40:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:40:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:40:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:40:47 --> Final output sent to browser
DEBUG - 2011-05-28 08:40:47 --> Total execution time: 0.4841
DEBUG - 2011-05-28 08:41:03 --> Config Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:41:03 --> URI Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Router Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Output Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Input Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:41:03 --> Language Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Loader Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Controller Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:41:03 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:41:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:41:07 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:41:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:41:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:41:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:41:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:41:07 --> Final output sent to browser
DEBUG - 2011-05-28 08:41:07 --> Total execution time: 3.7258
DEBUG - 2011-05-28 08:41:09 --> Config Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:41:09 --> URI Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Router Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Output Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Input Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:41:09 --> Language Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Loader Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Controller Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:41:09 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:41:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:41:09 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:41:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:41:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:41:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:41:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:41:09 --> Final output sent to browser
DEBUG - 2011-05-28 08:41:09 --> Total execution time: 0.0933
DEBUG - 2011-05-28 08:41:31 --> Config Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:41:31 --> URI Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Router Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Output Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Input Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:41:31 --> Language Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Loader Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Controller Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:41:31 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:41:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:41:32 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:41:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:41:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:41:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:41:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:41:32 --> Final output sent to browser
DEBUG - 2011-05-28 08:41:32 --> Total execution time: 1.1231
DEBUG - 2011-05-28 08:41:47 --> Config Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:41:47 --> URI Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Router Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Output Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Input Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:41:47 --> Language Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Loader Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Controller Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:41:47 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:41:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:41:47 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:41:47 --> Final output sent to browser
DEBUG - 2011-05-28 08:41:47 --> Total execution time: 0.2326
DEBUG - 2011-05-28 08:41:49 --> Config Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:41:49 --> URI Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Router Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Output Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Input Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:41:49 --> Language Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Loader Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Controller Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:41:49 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:41:49 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:41:49 --> Final output sent to browser
DEBUG - 2011-05-28 08:41:49 --> Total execution time: 0.0566
DEBUG - 2011-05-28 08:41:49 --> Config Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:41:49 --> URI Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Router Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Output Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Input Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:41:49 --> Language Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Loader Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Controller Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Model Class Initialized
DEBUG - 2011-05-28 08:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:41:49 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:41:49 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:41:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:41:49 --> Final output sent to browser
DEBUG - 2011-05-28 08:41:49 --> Total execution time: 0.1145
DEBUG - 2011-05-28 08:42:05 --> Config Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:42:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:42:05 --> URI Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Router Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Output Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Input Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:42:05 --> Language Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Loader Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Controller Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:42:05 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:42:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:42:05 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:42:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:42:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:42:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:42:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:42:05 --> Final output sent to browser
DEBUG - 2011-05-28 08:42:05 --> Total execution time: 0.0432
DEBUG - 2011-05-28 08:42:23 --> Config Class Initialized
DEBUG - 2011-05-28 08:42:23 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:42:23 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:42:23 --> URI Class Initialized
DEBUG - 2011-05-28 08:42:23 --> Router Class Initialized
DEBUG - 2011-05-28 08:42:23 --> No URI present. Default controller set.
DEBUG - 2011-05-28 08:42:23 --> Output Class Initialized
DEBUG - 2011-05-28 08:42:23 --> Input Class Initialized
DEBUG - 2011-05-28 08:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:42:23 --> Language Class Initialized
DEBUG - 2011-05-28 08:42:23 --> Loader Class Initialized
DEBUG - 2011-05-28 08:42:23 --> Controller Class Initialized
DEBUG - 2011-05-28 08:42:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 08:42:23 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:42:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:42:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:42:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:42:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:42:23 --> Final output sent to browser
DEBUG - 2011-05-28 08:42:23 --> Total execution time: 0.0242
DEBUG - 2011-05-28 08:42:26 --> Config Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:42:26 --> URI Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Router Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Output Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Input Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:42:26 --> Language Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Loader Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Controller Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:42:26 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:42:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:42:26 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:42:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:42:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:42:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:42:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:42:26 --> Final output sent to browser
DEBUG - 2011-05-28 08:42:26 --> Total execution time: 0.0769
DEBUG - 2011-05-28 08:42:34 --> Config Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:42:34 --> URI Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Router Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Output Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Input Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:42:34 --> Language Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Loader Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Controller Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:42:34 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:42:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:42:34 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:42:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:42:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:42:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:42:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:42:34 --> Final output sent to browser
DEBUG - 2011-05-28 08:42:34 --> Total execution time: 0.0538
DEBUG - 2011-05-28 08:42:42 --> Config Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:42:42 --> URI Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Router Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Output Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Input Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:42:42 --> Language Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Loader Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Controller Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:42:42 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:42:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:42:42 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:42:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:42:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:42:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:42:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:42:42 --> Final output sent to browser
DEBUG - 2011-05-28 08:42:42 --> Total execution time: 0.3681
DEBUG - 2011-05-28 08:42:46 --> Config Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:42:46 --> URI Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Router Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Output Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Input Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:42:46 --> Language Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Loader Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Controller Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:42:46 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:42:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:42:46 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:42:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:42:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:42:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:42:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:42:46 --> Final output sent to browser
DEBUG - 2011-05-28 08:42:46 --> Total execution time: 0.0464
DEBUG - 2011-05-28 08:42:55 --> Config Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:42:55 --> URI Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Router Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Output Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Input Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:42:55 --> Language Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Loader Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Controller Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Model Class Initialized
DEBUG - 2011-05-28 08:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:42:55 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:42:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:42:55 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:42:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:42:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:42:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:42:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:42:55 --> Final output sent to browser
DEBUG - 2011-05-28 08:42:55 --> Total execution time: 0.4397
DEBUG - 2011-05-28 08:43:10 --> Config Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:43:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:43:10 --> URI Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Router Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Output Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Input Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:43:10 --> Language Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Loader Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Controller Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Model Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Model Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Model Class Initialized
DEBUG - 2011-05-28 08:43:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:43:10 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:43:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:43:10 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:43:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:43:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:43:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:43:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:43:10 --> Final output sent to browser
DEBUG - 2011-05-28 08:43:10 --> Total execution time: 0.5023
DEBUG - 2011-05-28 08:43:28 --> Config Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:43:28 --> URI Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Router Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Output Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Input Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:43:28 --> Language Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Loader Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Controller Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Model Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Model Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Model Class Initialized
DEBUG - 2011-05-28 08:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:43:28 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:43:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:43:28 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:43:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:43:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:43:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:43:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:43:28 --> Final output sent to browser
DEBUG - 2011-05-28 08:43:28 --> Total execution time: 0.1049
DEBUG - 2011-05-28 08:52:41 --> Config Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:52:41 --> URI Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Router Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Output Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Input Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:52:41 --> Language Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Loader Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Controller Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Model Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Model Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Model Class Initialized
DEBUG - 2011-05-28 08:52:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:52:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:52:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:52:42 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:52:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:52:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:52:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:52:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:52:42 --> Final output sent to browser
DEBUG - 2011-05-28 08:52:42 --> Total execution time: 0.3738
DEBUG - 2011-05-28 08:52:54 --> Config Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:52:54 --> URI Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Router Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Output Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Input Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:52:54 --> Language Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Loader Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Controller Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Model Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Model Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Model Class Initialized
DEBUG - 2011-05-28 08:52:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:52:54 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:52:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:52:54 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:52:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:52:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:52:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:52:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:52:54 --> Final output sent to browser
DEBUG - 2011-05-28 08:52:54 --> Total execution time: 0.0557
DEBUG - 2011-05-28 08:53:02 --> Config Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:53:02 --> URI Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Router Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Output Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Input Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:53:02 --> Language Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Loader Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Controller Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:53:02 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:53:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:53:02 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:53:02 --> Final output sent to browser
DEBUG - 2011-05-28 08:53:02 --> Total execution time: 0.1915
DEBUG - 2011-05-28 08:53:03 --> Config Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:53:03 --> URI Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Router Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Output Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Input Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:53:03 --> Language Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Loader Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Controller Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:53:03 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:53:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:53:03 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:53:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:53:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:53:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:53:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:53:03 --> Final output sent to browser
DEBUG - 2011-05-28 08:53:03 --> Total execution time: 0.0514
DEBUG - 2011-05-28 08:53:04 --> Config Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:53:04 --> URI Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Router Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Output Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Input Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:53:04 --> Language Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Loader Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Controller Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:53:04 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:53:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:53:04 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:53:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:53:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:53:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:53:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:53:04 --> Final output sent to browser
DEBUG - 2011-05-28 08:53:04 --> Total execution time: 0.0440
DEBUG - 2011-05-28 08:53:26 --> Config Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:53:26 --> URI Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Router Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Output Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Input Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:53:26 --> Language Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Loader Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Controller Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:53:26 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:53:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:53:26 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:53:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:53:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:53:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:53:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:53:26 --> Final output sent to browser
DEBUG - 2011-05-28 08:53:26 --> Total execution time: 0.2567
DEBUG - 2011-05-28 08:53:30 --> Config Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:53:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:53:30 --> URI Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Router Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Output Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Input Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:53:30 --> Language Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Loader Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Controller Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:53:30 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:53:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:53:30 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:53:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:53:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:53:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:53:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:53:30 --> Final output sent to browser
DEBUG - 2011-05-28 08:53:30 --> Total execution time: 0.0507
DEBUG - 2011-05-28 08:53:51 --> Config Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:53:51 --> URI Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Router Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Output Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Input Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:53:51 --> Language Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Loader Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Controller Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:53:51 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:53:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:53:51 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:53:51 --> Final output sent to browser
DEBUG - 2011-05-28 08:53:51 --> Total execution time: 0.2137
DEBUG - 2011-05-28 08:53:53 --> Config Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:53:53 --> URI Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Router Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Output Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Input Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:53:53 --> Language Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Loader Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Controller Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Model Class Initialized
DEBUG - 2011-05-28 08:53:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:53:53 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:53:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:53:53 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:53:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:53:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:53:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:53:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:53:53 --> Final output sent to browser
DEBUG - 2011-05-28 08:53:53 --> Total execution time: 0.0474
DEBUG - 2011-05-28 08:54:07 --> Config Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:54:07 --> URI Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Router Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Output Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Input Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:54:07 --> Language Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Loader Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Controller Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:54:07 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:54:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:54:07 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:54:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:54:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:54:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:54:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:54:07 --> Final output sent to browser
DEBUG - 2011-05-28 08:54:07 --> Total execution time: 0.2985
DEBUG - 2011-05-28 08:54:08 --> Config Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:54:08 --> URI Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Router Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Output Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Input Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:54:08 --> Language Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Loader Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Controller Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:54:08 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:54:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:54:08 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:54:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:54:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:54:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:54:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:54:08 --> Final output sent to browser
DEBUG - 2011-05-28 08:54:08 --> Total execution time: 0.0632
DEBUG - 2011-05-28 08:54:09 --> Config Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:54:09 --> URI Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Router Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Output Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Input Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:54:09 --> Language Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Loader Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Controller Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Model Class Initialized
DEBUG - 2011-05-28 08:54:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:54:09 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:54:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:54:09 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:54:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:54:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:54:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:54:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:54:09 --> Final output sent to browser
DEBUG - 2011-05-28 08:54:09 --> Total execution time: 0.0443
DEBUG - 2011-05-28 08:55:00 --> Config Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:55:00 --> URI Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Router Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Output Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Input Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:55:00 --> Language Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Loader Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Controller Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:55:00 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:55:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:55:00 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:55:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:55:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:55:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:55:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:55:00 --> Final output sent to browser
DEBUG - 2011-05-28 08:55:00 --> Total execution time: 0.1896
DEBUG - 2011-05-28 08:55:56 --> Config Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:55:56 --> URI Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Router Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Output Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Input Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:55:56 --> Language Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Loader Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Controller Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:55:56 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:55:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:55:57 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:55:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:55:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:55:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:55:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:55:57 --> Final output sent to browser
DEBUG - 2011-05-28 08:55:57 --> Total execution time: 0.3122
DEBUG - 2011-05-28 08:55:58 --> Config Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:55:58 --> URI Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Router Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Output Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Input Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:55:58 --> Language Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Loader Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Controller Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Model Class Initialized
DEBUG - 2011-05-28 08:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:55:58 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:55:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:55:58 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:55:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:55:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:55:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:55:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:55:58 --> Final output sent to browser
DEBUG - 2011-05-28 08:55:58 --> Total execution time: 0.0429
DEBUG - 2011-05-28 08:56:17 --> Config Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:56:17 --> URI Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Router Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Output Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Input Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:56:17 --> Language Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Loader Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Controller Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:56:17 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:56:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:56:18 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:56:18 --> Final output sent to browser
DEBUG - 2011-05-28 08:56:18 --> Total execution time: 0.2251
DEBUG - 2011-05-28 08:56:19 --> Config Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:56:19 --> URI Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Router Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Output Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Input Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:56:19 --> Language Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Loader Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Controller Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:56:19 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:56:19 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:56:19 --> Final output sent to browser
DEBUG - 2011-05-28 08:56:19 --> Total execution time: 0.0488
DEBUG - 2011-05-28 08:56:19 --> Config Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Hooks Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Utf8 Class Initialized
DEBUG - 2011-05-28 08:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 08:56:19 --> URI Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Router Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Output Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Input Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 08:56:19 --> Language Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Loader Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Controller Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Model Class Initialized
DEBUG - 2011-05-28 08:56:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 08:56:19 --> Database Driver Class Initialized
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 08:56:19 --> Helper loaded: url_helper
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 08:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 08:56:19 --> Final output sent to browser
DEBUG - 2011-05-28 08:56:19 --> Total execution time: 0.0448
DEBUG - 2011-05-28 09:29:59 --> Config Class Initialized
DEBUG - 2011-05-28 09:29:59 --> Hooks Class Initialized
DEBUG - 2011-05-28 09:30:00 --> Utf8 Class Initialized
DEBUG - 2011-05-28 09:30:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 09:30:00 --> URI Class Initialized
DEBUG - 2011-05-28 09:30:00 --> Router Class Initialized
DEBUG - 2011-05-28 09:30:00 --> Output Class Initialized
DEBUG - 2011-05-28 09:30:00 --> Input Class Initialized
DEBUG - 2011-05-28 09:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 09:30:00 --> Language Class Initialized
DEBUG - 2011-05-28 09:30:00 --> Loader Class Initialized
DEBUG - 2011-05-28 09:30:00 --> Controller Class Initialized
DEBUG - 2011-05-28 09:30:01 --> Model Class Initialized
DEBUG - 2011-05-28 09:30:01 --> Model Class Initialized
DEBUG - 2011-05-28 09:30:01 --> Model Class Initialized
DEBUG - 2011-05-28 09:30:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 09:30:02 --> Database Driver Class Initialized
DEBUG - 2011-05-28 09:30:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 09:30:03 --> Helper loaded: url_helper
DEBUG - 2011-05-28 09:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 09:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 09:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 09:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 09:30:03 --> Final output sent to browser
DEBUG - 2011-05-28 09:30:03 --> Total execution time: 4.5434
DEBUG - 2011-05-28 09:30:19 --> Config Class Initialized
DEBUG - 2011-05-28 09:30:19 --> Hooks Class Initialized
DEBUG - 2011-05-28 09:30:19 --> Utf8 Class Initialized
DEBUG - 2011-05-28 09:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 09:30:19 --> URI Class Initialized
DEBUG - 2011-05-28 09:30:19 --> Router Class Initialized
ERROR - 2011-05-28 09:30:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 12:49:41 --> Config Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 12:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 12:49:41 --> URI Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Router Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Output Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Input Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 12:49:41 --> Language Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Loader Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Controller Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Model Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Model Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Model Class Initialized
DEBUG - 2011-05-28 12:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 12:49:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 12:49:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 12:49:41 --> Helper loaded: url_helper
DEBUG - 2011-05-28 12:49:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 12:49:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 12:49:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 12:49:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 12:49:41 --> Final output sent to browser
DEBUG - 2011-05-28 12:49:41 --> Total execution time: 0.7971
DEBUG - 2011-05-28 12:49:42 --> Config Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Hooks Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Utf8 Class Initialized
DEBUG - 2011-05-28 12:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 12:49:42 --> URI Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Router Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Output Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Input Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 12:49:42 --> Language Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Loader Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Controller Class Initialized
ERROR - 2011-05-28 12:49:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 12:49:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 12:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 12:49:42 --> Model Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Model Class Initialized
DEBUG - 2011-05-28 12:49:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 12:49:42 --> Database Driver Class Initialized
DEBUG - 2011-05-28 12:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 12:49:42 --> Helper loaded: url_helper
DEBUG - 2011-05-28 12:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 12:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 12:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 12:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 12:49:42 --> Final output sent to browser
DEBUG - 2011-05-28 12:49:42 --> Total execution time: 0.0960
DEBUG - 2011-05-28 13:09:10 --> Config Class Initialized
DEBUG - 2011-05-28 13:09:10 --> Hooks Class Initialized
DEBUG - 2011-05-28 13:09:10 --> Utf8 Class Initialized
DEBUG - 2011-05-28 13:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 13:09:10 --> URI Class Initialized
DEBUG - 2011-05-28 13:09:10 --> Router Class Initialized
ERROR - 2011-05-28 13:09:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-28 13:10:58 --> Config Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 13:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 13:10:58 --> URI Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Router Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Output Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Input Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 13:10:58 --> Language Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Loader Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Controller Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Model Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Model Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Model Class Initialized
DEBUG - 2011-05-28 13:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 13:10:58 --> Database Driver Class Initialized
DEBUG - 2011-05-28 13:10:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 13:10:58 --> Helper loaded: url_helper
DEBUG - 2011-05-28 13:10:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 13:10:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 13:10:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 13:10:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 13:10:58 --> Final output sent to browser
DEBUG - 2011-05-28 13:10:58 --> Total execution time: 0.4903
DEBUG - 2011-05-28 14:27:37 --> Config Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:27:37 --> URI Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Router Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Output Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Input Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 14:27:37 --> Language Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Loader Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Controller Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 14:27:37 --> Database Driver Class Initialized
DEBUG - 2011-05-28 14:27:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 14:27:38 --> Helper loaded: url_helper
DEBUG - 2011-05-28 14:27:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 14:27:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 14:27:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 14:27:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 14:27:38 --> Final output sent to browser
DEBUG - 2011-05-28 14:27:38 --> Total execution time: 0.8470
DEBUG - 2011-05-28 14:27:39 --> Config Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:27:39 --> URI Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Router Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Output Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Input Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 14:27:39 --> Language Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Loader Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Controller Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 14:27:40 --> Config Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:27:40 --> Database Driver Class Initialized
DEBUG - 2011-05-28 14:27:40 --> URI Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Router Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Output Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Input Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 14:27:40 --> Language Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Loader Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Controller Class Initialized
ERROR - 2011-05-28 14:27:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 14:27:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 14:27:40 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 14:27:40 --> Database Driver Class Initialized
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 14:27:40 --> Helper loaded: url_helper
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 14:27:40 --> Helper loaded: url_helper
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 14:27:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 14:27:40 --> Config Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:27:40 --> URI Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Router Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Output Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Input Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 14:27:40 --> Language Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Loader Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Controller Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 14:27:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 14:27:41 --> Helper loaded: url_helper
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 14:27:41 --> Final output sent to browser
DEBUG - 2011-05-28 14:27:41 --> Total execution time: 0.0598
DEBUG - 2011-05-28 14:27:41 --> Config Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:27:41 --> URI Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Router Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Output Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Input Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 14:27:41 --> Language Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Loader Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Controller Class Initialized
ERROR - 2011-05-28 14:27:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 14:27:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 14:27:41 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Model Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 14:27:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 14:27:41 --> Helper loaded: url_helper
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 14:27:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 14:27:41 --> Final output sent to browser
DEBUG - 2011-05-28 14:27:41 --> Total execution time: 0.0448
DEBUG - 2011-05-28 14:27:41 --> Config Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:27:41 --> URI Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Router Class Initialized
ERROR - 2011-05-28 14:27:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 14:27:41 --> Config Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:27:41 --> URI Class Initialized
DEBUG - 2011-05-28 14:27:41 --> Router Class Initialized
ERROR - 2011-05-28 14:27:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 14:27:43 --> Config Class Initialized
DEBUG - 2011-05-28 14:27:43 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:27:43 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:27:43 --> URI Class Initialized
DEBUG - 2011-05-28 14:27:43 --> Router Class Initialized
ERROR - 2011-05-28 14:27:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 14:42:00 --> Config Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:42:00 --> URI Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Router Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Output Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Input Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 14:42:00 --> Language Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Loader Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Controller Class Initialized
ERROR - 2011-05-28 14:42:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 14:42:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 14:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 14:42:00 --> Model Class Initialized
DEBUG - 2011-05-28 14:42:00 --> Model Class Initialized
DEBUG - 2011-05-28 14:42:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 14:42:01 --> Database Driver Class Initialized
DEBUG - 2011-05-28 14:42:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 14:42:01 --> Helper loaded: url_helper
DEBUG - 2011-05-28 14:42:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 14:42:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 14:42:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 14:42:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 14:42:01 --> Final output sent to browser
DEBUG - 2011-05-28 14:42:01 --> Total execution time: 0.8824
DEBUG - 2011-05-28 14:42:02 --> Config Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:42:02 --> URI Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Router Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Output Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Input Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 14:42:02 --> Language Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Loader Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Controller Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Model Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Model Class Initialized
DEBUG - 2011-05-28 14:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 14:42:02 --> Database Driver Class Initialized
DEBUG - 2011-05-28 14:42:03 --> Final output sent to browser
DEBUG - 2011-05-28 14:42:03 --> Total execution time: 0.7092
DEBUG - 2011-05-28 14:42:05 --> Config Class Initialized
DEBUG - 2011-05-28 14:42:05 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:42:05 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:42:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:42:05 --> URI Class Initialized
DEBUG - 2011-05-28 14:42:05 --> Router Class Initialized
ERROR - 2011-05-28 14:42:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 15:52:30 --> Config Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Hooks Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Utf8 Class Initialized
DEBUG - 2011-05-28 15:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 15:52:30 --> URI Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Router Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Output Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Input Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 15:52:30 --> Language Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Loader Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Controller Class Initialized
ERROR - 2011-05-28 15:52:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 15:52:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 15:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 15:52:30 --> Model Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Model Class Initialized
DEBUG - 2011-05-28 15:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 15:52:30 --> Database Driver Class Initialized
DEBUG - 2011-05-28 15:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 15:52:30 --> Helper loaded: url_helper
DEBUG - 2011-05-28 15:52:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 15:52:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 15:52:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 15:52:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 15:52:30 --> Final output sent to browser
DEBUG - 2011-05-28 15:52:30 --> Total execution time: 0.3828
DEBUG - 2011-05-28 15:52:31 --> Config Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Hooks Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Utf8 Class Initialized
DEBUG - 2011-05-28 15:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 15:52:31 --> URI Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Router Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Output Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Input Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 15:52:31 --> Language Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Loader Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Controller Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Model Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Model Class Initialized
DEBUG - 2011-05-28 15:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 15:52:31 --> Database Driver Class Initialized
DEBUG - 2011-05-28 15:52:32 --> Final output sent to browser
DEBUG - 2011-05-28 15:52:32 --> Total execution time: 1.1517
DEBUG - 2011-05-28 15:52:33 --> Config Class Initialized
DEBUG - 2011-05-28 15:52:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 15:52:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 15:52:33 --> URI Class Initialized
DEBUG - 2011-05-28 15:52:33 --> Router Class Initialized
ERROR - 2011-05-28 15:52:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 17:23:22 --> Config Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Hooks Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Utf8 Class Initialized
DEBUG - 2011-05-28 17:23:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 17:23:22 --> URI Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Router Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Output Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Input Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 17:23:22 --> Language Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Loader Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Controller Class Initialized
ERROR - 2011-05-28 17:23:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 17:23:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 17:23:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 17:23:22 --> Model Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Model Class Initialized
DEBUG - 2011-05-28 17:23:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 17:23:22 --> Database Driver Class Initialized
DEBUG - 2011-05-28 17:23:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 17:23:22 --> Helper loaded: url_helper
DEBUG - 2011-05-28 17:23:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 17:23:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 17:23:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 17:23:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 17:23:22 --> Final output sent to browser
DEBUG - 2011-05-28 17:23:22 --> Total execution time: 0.3756
DEBUG - 2011-05-28 17:23:23 --> Config Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Hooks Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Utf8 Class Initialized
DEBUG - 2011-05-28 17:23:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 17:23:23 --> URI Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Router Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Output Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Input Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 17:23:23 --> Language Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Loader Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Controller Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Model Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Model Class Initialized
DEBUG - 2011-05-28 17:23:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 17:23:23 --> Database Driver Class Initialized
DEBUG - 2011-05-28 17:23:24 --> Final output sent to browser
DEBUG - 2011-05-28 17:23:24 --> Total execution time: 0.7366
DEBUG - 2011-05-28 17:23:25 --> Config Class Initialized
DEBUG - 2011-05-28 17:23:25 --> Hooks Class Initialized
DEBUG - 2011-05-28 17:23:25 --> Utf8 Class Initialized
DEBUG - 2011-05-28 17:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 17:23:25 --> URI Class Initialized
DEBUG - 2011-05-28 17:23:25 --> Router Class Initialized
ERROR - 2011-05-28 17:23:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 17:23:27 --> Config Class Initialized
DEBUG - 2011-05-28 17:23:27 --> Hooks Class Initialized
DEBUG - 2011-05-28 17:23:27 --> Utf8 Class Initialized
DEBUG - 2011-05-28 17:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 17:23:27 --> URI Class Initialized
DEBUG - 2011-05-28 17:23:27 --> Router Class Initialized
ERROR - 2011-05-28 17:23:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:17:29 --> Config Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:17:29 --> URI Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Router Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Output Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Input Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:17:29 --> Language Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Loader Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Controller Class Initialized
ERROR - 2011-05-28 18:17:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:17:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:17:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:17:29 --> Model Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Model Class Initialized
DEBUG - 2011-05-28 18:17:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:17:29 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:17:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:17:29 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:17:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:17:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:17:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:17:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:17:29 --> Final output sent to browser
DEBUG - 2011-05-28 18:17:29 --> Total execution time: 0.4392
DEBUG - 2011-05-28 18:17:32 --> Config Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:17:32 --> URI Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Router Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Output Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Input Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:17:32 --> Language Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Loader Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Controller Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Model Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Model Class Initialized
DEBUG - 2011-05-28 18:17:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:17:32 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:17:33 --> Final output sent to browser
DEBUG - 2011-05-28 18:17:33 --> Total execution time: 1.0554
DEBUG - 2011-05-28 18:45:31 --> Config Class Initialized
DEBUG - 2011-05-28 18:45:31 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:45:31 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:45:31 --> URI Class Initialized
DEBUG - 2011-05-28 18:45:31 --> Router Class Initialized
DEBUG - 2011-05-28 18:45:31 --> No URI present. Default controller set.
DEBUG - 2011-05-28 18:45:31 --> Output Class Initialized
DEBUG - 2011-05-28 18:45:31 --> Input Class Initialized
DEBUG - 2011-05-28 18:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:45:31 --> Language Class Initialized
DEBUG - 2011-05-28 18:45:31 --> Loader Class Initialized
DEBUG - 2011-05-28 18:45:31 --> Controller Class Initialized
DEBUG - 2011-05-28 18:45:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 18:45:31 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:45:31 --> Final output sent to browser
DEBUG - 2011-05-28 18:45:31 --> Total execution time: 0.2830
DEBUG - 2011-05-28 18:45:32 --> Config Class Initialized
DEBUG - 2011-05-28 18:45:32 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:45:32 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:45:32 --> URI Class Initialized
DEBUG - 2011-05-28 18:45:32 --> Router Class Initialized
ERROR - 2011-05-28 18:45:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:46:10 --> Config Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:46:10 --> URI Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Router Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Output Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Input Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:46:10 --> Language Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Loader Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Controller Class Initialized
ERROR - 2011-05-28 18:46:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:46:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:46:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:46:10 --> Model Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Model Class Initialized
DEBUG - 2011-05-28 18:46:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:46:10 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:46:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:46:10 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:46:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:46:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:46:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:46:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:46:10 --> Final output sent to browser
DEBUG - 2011-05-28 18:46:10 --> Total execution time: 0.1734
DEBUG - 2011-05-28 18:46:11 --> Config Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:46:11 --> URI Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Router Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Output Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Input Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:46:11 --> Language Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Loader Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Controller Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Model Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Model Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:46:11 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:46:11 --> Final output sent to browser
DEBUG - 2011-05-28 18:46:11 --> Total execution time: 0.6869
DEBUG - 2011-05-28 18:46:12 --> Config Class Initialized
DEBUG - 2011-05-28 18:46:12 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:46:12 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:46:12 --> URI Class Initialized
DEBUG - 2011-05-28 18:46:12 --> Router Class Initialized
ERROR - 2011-05-28 18:46:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:48:31 --> Config Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:48:31 --> URI Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Router Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Output Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Input Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:48:31 --> Language Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Loader Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Controller Class Initialized
ERROR - 2011-05-28 18:48:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:48:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:48:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:48:31 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:48:31 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:48:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:48:31 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:48:31 --> Final output sent to browser
DEBUG - 2011-05-28 18:48:31 --> Total execution time: 0.0531
DEBUG - 2011-05-28 18:48:32 --> Config Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:48:32 --> URI Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Router Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Output Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Input Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:48:32 --> Language Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Loader Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Controller Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:48:32 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:48:32 --> Final output sent to browser
DEBUG - 2011-05-28 18:48:32 --> Total execution time: 0.5223
DEBUG - 2011-05-28 18:48:33 --> Config Class Initialized
DEBUG - 2011-05-28 18:48:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:48:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:48:33 --> URI Class Initialized
DEBUG - 2011-05-28 18:48:33 --> Router Class Initialized
ERROR - 2011-05-28 18:48:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:48:44 --> Config Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:48:44 --> URI Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Router Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Output Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Input Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:48:44 --> Language Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Loader Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Controller Class Initialized
ERROR - 2011-05-28 18:48:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:48:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:48:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:48:44 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:48:44 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:48:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:48:44 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:48:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:48:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:48:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:48:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:48:44 --> Final output sent to browser
DEBUG - 2011-05-28 18:48:44 --> Total execution time: 0.0308
DEBUG - 2011-05-28 18:48:45 --> Config Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:48:45 --> URI Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Router Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Output Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Input Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:48:45 --> Language Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Loader Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Controller Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:48:45 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Final output sent to browser
DEBUG - 2011-05-28 18:48:46 --> Total execution time: 0.5333
DEBUG - 2011-05-28 18:48:46 --> Config Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:48:46 --> URI Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Router Class Initialized
ERROR - 2011-05-28 18:48:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-28 18:48:46 --> Config Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:48:46 --> URI Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Router Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Output Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Input Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:48:46 --> Language Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Loader Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Controller Class Initialized
ERROR - 2011-05-28 18:48:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:48:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:48:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:48:46 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Model Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:48:46 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:48:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:48:46 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:48:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:48:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:48:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:48:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:48:46 --> Final output sent to browser
DEBUG - 2011-05-28 18:48:46 --> Total execution time: 0.0296
DEBUG - 2011-05-28 18:48:46 --> Config Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:48:46 --> URI Class Initialized
DEBUG - 2011-05-28 18:48:46 --> Router Class Initialized
ERROR - 2011-05-28 18:48:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:49:02 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:02 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:02 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Controller Class Initialized
ERROR - 2011-05-28 18:49:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:49:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:49:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:02 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:02 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:02 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:49:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:49:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:49:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:49:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:49:02 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:02 --> Total execution time: 0.0291
DEBUG - 2011-05-28 18:49:02 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:02 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:02 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Controller Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:02 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:03 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:03 --> Total execution time: 0.6279
DEBUG - 2011-05-28 18:49:04 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:04 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:04 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:04 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:04 --> Router Class Initialized
ERROR - 2011-05-28 18:49:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:49:17 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:17 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:17 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Controller Class Initialized
ERROR - 2011-05-28 18:49:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:49:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:17 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:17 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:17 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:49:17 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:17 --> Total execution time: 0.0417
DEBUG - 2011-05-28 18:49:17 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:17 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:17 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Controller Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:17 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:18 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:18 --> Total execution time: 0.6127
DEBUG - 2011-05-28 18:49:19 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:19 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:19 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:19 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:19 --> Router Class Initialized
ERROR - 2011-05-28 18:49:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:49:28 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:28 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:28 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Controller Class Initialized
ERROR - 2011-05-28 18:49:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:49:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:28 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:28 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:28 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:49:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:49:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:49:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:49:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:49:28 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:28 --> Total execution time: 0.0329
DEBUG - 2011-05-28 18:49:29 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:29 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:29 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Controller Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:29 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:29 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:29 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Controller Class Initialized
ERROR - 2011-05-28 18:49:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:49:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:29 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:29 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:29 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:49:29 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:29 --> Total execution time: 0.0407
DEBUG - 2011-05-28 18:49:29 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:29 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:29 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Controller Class Initialized
ERROR - 2011-05-28 18:49:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:49:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:29 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:29 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:29 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:49:29 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:29 --> Total execution time: 0.0300
DEBUG - 2011-05-28 18:49:29 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:29 --> Total execution time: 0.7127
DEBUG - 2011-05-28 18:49:30 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:30 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:30 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:30 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:30 --> Router Class Initialized
ERROR - 2011-05-28 18:49:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:49:40 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:40 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:40 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Controller Class Initialized
ERROR - 2011-05-28 18:49:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:49:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:49:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:40 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:40 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:40 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:49:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:49:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:49:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:49:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:49:40 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:40 --> Total execution time: 0.0516
DEBUG - 2011-05-28 18:49:41 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:41 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:41 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Controller Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:41 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Router Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Output Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Input Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:49:41 --> Language Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Loader Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Controller Class Initialized
ERROR - 2011-05-28 18:49:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:49:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:41 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Model Class Initialized
DEBUG - 2011-05-28 18:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:49:41 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:49:41 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:49:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:49:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:49:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:49:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:49:41 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:41 --> Total execution time: 0.0447
DEBUG - 2011-05-28 18:49:41 --> Final output sent to browser
DEBUG - 2011-05-28 18:49:41 --> Total execution time: 0.6258
DEBUG - 2011-05-28 18:49:42 --> Config Class Initialized
DEBUG - 2011-05-28 18:49:42 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:49:42 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:49:42 --> URI Class Initialized
DEBUG - 2011-05-28 18:49:42 --> Router Class Initialized
ERROR - 2011-05-28 18:49:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:52:13 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:13 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Router Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Output Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Input Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:52:13 --> Language Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Loader Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Controller Class Initialized
ERROR - 2011-05-28 18:52:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:52:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:52:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:52:13 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:52:13 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:52:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:52:13 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:52:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:52:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:52:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:52:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:52:13 --> Final output sent to browser
DEBUG - 2011-05-28 18:52:13 --> Total execution time: 0.0294
DEBUG - 2011-05-28 18:52:13 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:13 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Router Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Output Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Input Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:52:13 --> Language Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Loader Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Controller Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:52:13 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Final output sent to browser
DEBUG - 2011-05-28 18:52:14 --> Total execution time: 0.5127
DEBUG - 2011-05-28 18:52:14 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:14 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Router Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Output Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Input Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:52:14 --> Language Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Loader Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Controller Class Initialized
ERROR - 2011-05-28 18:52:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:52:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:52:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:52:14 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:52:14 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:52:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:52:14 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:52:14 --> Final output sent to browser
DEBUG - 2011-05-28 18:52:14 --> Total execution time: 0.0305
DEBUG - 2011-05-28 18:52:15 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:15 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:15 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:15 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:15 --> Router Class Initialized
ERROR - 2011-05-28 18:52:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:52:31 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:31 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Router Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Output Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Input Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:52:31 --> Language Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Loader Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Controller Class Initialized
ERROR - 2011-05-28 18:52:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:52:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:52:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:52:31 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:52:31 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:52:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:52:31 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:52:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:52:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:52:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:52:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:52:31 --> Final output sent to browser
DEBUG - 2011-05-28 18:52:31 --> Total execution time: 0.0417
DEBUG - 2011-05-28 18:52:32 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:32 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Router Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Output Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Input Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:52:32 --> Language Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Loader Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Controller Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:52:32 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:52:32 --> Final output sent to browser
DEBUG - 2011-05-28 18:52:32 --> Total execution time: 0.5182
DEBUG - 2011-05-28 18:52:33 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:33 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:33 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:33 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:33 --> Router Class Initialized
ERROR - 2011-05-28 18:52:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:52:52 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:52 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Router Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Output Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Input Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:52:52 --> Language Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Loader Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Controller Class Initialized
ERROR - 2011-05-28 18:52:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:52:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:52:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:52:52 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:52:52 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:52:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:52:52 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:52:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:52:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:52:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:52:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:52:52 --> Final output sent to browser
DEBUG - 2011-05-28 18:52:52 --> Total execution time: 0.0301
DEBUG - 2011-05-28 18:52:53 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:53 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Router Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Output Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Input Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:52:53 --> Language Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Loader Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Controller Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Model Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:52:53 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:52:53 --> Final output sent to browser
DEBUG - 2011-05-28 18:52:53 --> Total execution time: 0.5265
DEBUG - 2011-05-28 18:52:54 --> Config Class Initialized
DEBUG - 2011-05-28 18:52:54 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:52:54 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:52:54 --> URI Class Initialized
DEBUG - 2011-05-28 18:52:54 --> Router Class Initialized
ERROR - 2011-05-28 18:52:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:53:09 --> Config Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:53:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:53:09 --> URI Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Router Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Output Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Input Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:53:09 --> Language Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Loader Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Controller Class Initialized
ERROR - 2011-05-28 18:53:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:53:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:53:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:53:09 --> Model Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Model Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:53:09 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:53:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:53:09 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:53:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:53:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:53:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:53:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:53:09 --> Final output sent to browser
DEBUG - 2011-05-28 18:53:09 --> Total execution time: 0.0277
DEBUG - 2011-05-28 18:53:09 --> Config Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:53:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:53:09 --> URI Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Router Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Output Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Input Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:53:09 --> Language Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Loader Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Controller Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Model Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Model Class Initialized
DEBUG - 2011-05-28 18:53:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:53:09 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:53:10 --> Final output sent to browser
DEBUG - 2011-05-28 18:53:10 --> Total execution time: 0.5185
DEBUG - 2011-05-28 18:53:11 --> Config Class Initialized
DEBUG - 2011-05-28 18:53:11 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:53:11 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:53:11 --> URI Class Initialized
DEBUG - 2011-05-28 18:53:11 --> Router Class Initialized
ERROR - 2011-05-28 18:53:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 18:53:18 --> Config Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:53:18 --> URI Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Router Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Output Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Input Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:53:18 --> Language Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Loader Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Controller Class Initialized
ERROR - 2011-05-28 18:53:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 18:53:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 18:53:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:53:18 --> Model Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Model Class Initialized
DEBUG - 2011-05-28 18:53:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:53:18 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:53:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 18:53:18 --> Helper loaded: url_helper
DEBUG - 2011-05-28 18:53:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 18:53:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 18:53:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 18:53:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 18:53:18 --> Final output sent to browser
DEBUG - 2011-05-28 18:53:18 --> Total execution time: 0.0291
DEBUG - 2011-05-28 18:53:19 --> Config Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:53:19 --> URI Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Router Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Output Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Input Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 18:53:19 --> Language Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Loader Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Controller Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Model Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Model Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 18:53:19 --> Database Driver Class Initialized
DEBUG - 2011-05-28 18:53:19 --> Final output sent to browser
DEBUG - 2011-05-28 18:53:19 --> Total execution time: 0.5014
DEBUG - 2011-05-28 18:53:20 --> Config Class Initialized
DEBUG - 2011-05-28 18:53:20 --> Hooks Class Initialized
DEBUG - 2011-05-28 18:53:20 --> Utf8 Class Initialized
DEBUG - 2011-05-28 18:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 18:53:20 --> URI Class Initialized
DEBUG - 2011-05-28 18:53:20 --> Router Class Initialized
ERROR - 2011-05-28 18:53:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 19:07:28 --> Config Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 19:07:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 19:07:28 --> URI Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Router Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Output Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Input Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 19:07:28 --> Language Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Loader Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Controller Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Model Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Model Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Model Class Initialized
DEBUG - 2011-05-28 19:07:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 19:07:28 --> Database Driver Class Initialized
DEBUG - 2011-05-28 19:07:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 19:07:28 --> Helper loaded: url_helper
DEBUG - 2011-05-28 19:07:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 19:07:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 19:07:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 19:07:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 19:07:28 --> Final output sent to browser
DEBUG - 2011-05-28 19:07:28 --> Total execution time: 0.3640
DEBUG - 2011-05-28 19:15:06 --> Config Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Hooks Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Utf8 Class Initialized
DEBUG - 2011-05-28 19:15:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 19:15:06 --> URI Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Router Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Output Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Input Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 19:15:06 --> Language Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Loader Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Controller Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Model Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Model Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Model Class Initialized
DEBUG - 2011-05-28 19:15:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 19:15:06 --> Database Driver Class Initialized
DEBUG - 2011-05-28 19:15:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 19:15:06 --> Helper loaded: url_helper
DEBUG - 2011-05-28 19:15:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 19:15:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 19:15:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 19:15:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 19:15:06 --> Final output sent to browser
DEBUG - 2011-05-28 19:15:06 --> Total execution time: 0.2763
DEBUG - 2011-05-28 19:15:07 --> Config Class Initialized
DEBUG - 2011-05-28 19:15:07 --> Hooks Class Initialized
DEBUG - 2011-05-28 19:15:07 --> Utf8 Class Initialized
DEBUG - 2011-05-28 19:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 19:15:07 --> URI Class Initialized
DEBUG - 2011-05-28 19:15:07 --> Router Class Initialized
ERROR - 2011-05-28 19:15:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 19:15:12 --> Config Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Hooks Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Utf8 Class Initialized
DEBUG - 2011-05-28 19:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 19:15:12 --> URI Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Router Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Output Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Input Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 19:15:12 --> Language Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Loader Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Controller Class Initialized
ERROR - 2011-05-28 19:15:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-28 19:15:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-28 19:15:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 19:15:12 --> Model Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Model Class Initialized
DEBUG - 2011-05-28 19:15:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 19:15:12 --> Database Driver Class Initialized
DEBUG - 2011-05-28 19:15:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-28 19:15:12 --> Helper loaded: url_helper
DEBUG - 2011-05-28 19:15:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 19:15:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 19:15:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 19:15:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 19:15:12 --> Final output sent to browser
DEBUG - 2011-05-28 19:15:12 --> Total execution time: 0.0400
DEBUG - 2011-05-28 19:15:13 --> Config Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Hooks Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Utf8 Class Initialized
DEBUG - 2011-05-28 19:15:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 19:15:13 --> URI Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Router Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Output Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Input Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 19:15:13 --> Language Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Loader Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Controller Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Model Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Model Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 19:15:13 --> Database Driver Class Initialized
DEBUG - 2011-05-28 19:15:13 --> Final output sent to browser
DEBUG - 2011-05-28 19:15:13 --> Total execution time: 0.4556
DEBUG - 2011-05-28 19:15:14 --> Config Class Initialized
DEBUG - 2011-05-28 19:15:14 --> Hooks Class Initialized
DEBUG - 2011-05-28 19:15:14 --> Utf8 Class Initialized
DEBUG - 2011-05-28 19:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 19:15:14 --> URI Class Initialized
DEBUG - 2011-05-28 19:15:14 --> Router Class Initialized
ERROR - 2011-05-28 19:15:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 20:03:59 --> Config Class Initialized
DEBUG - 2011-05-28 20:03:59 --> Hooks Class Initialized
DEBUG - 2011-05-28 20:03:59 --> Utf8 Class Initialized
DEBUG - 2011-05-28 20:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 20:03:59 --> URI Class Initialized
DEBUG - 2011-05-28 20:03:59 --> Router Class Initialized
DEBUG - 2011-05-28 20:03:59 --> No URI present. Default controller set.
DEBUG - 2011-05-28 20:03:59 --> Output Class Initialized
DEBUG - 2011-05-28 20:03:59 --> Input Class Initialized
DEBUG - 2011-05-28 20:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 20:03:59 --> Language Class Initialized
DEBUG - 2011-05-28 20:03:59 --> Loader Class Initialized
DEBUG - 2011-05-28 20:04:00 --> Controller Class Initialized
DEBUG - 2011-05-28 20:04:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 20:04:02 --> Helper loaded: url_helper
DEBUG - 2011-05-28 20:04:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 20:04:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 20:04:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 20:04:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 20:04:03 --> Final output sent to browser
DEBUG - 2011-05-28 20:04:03 --> Total execution time: 5.3183
DEBUG - 2011-05-28 20:04:15 --> Config Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Hooks Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Utf8 Class Initialized
DEBUG - 2011-05-28 20:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 20:04:15 --> URI Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Router Class Initialized
DEBUG - 2011-05-28 20:04:15 --> No URI present. Default controller set.
DEBUG - 2011-05-28 20:04:15 --> Output Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Input Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 20:04:15 --> Language Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Loader Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Controller Class Initialized
DEBUG - 2011-05-28 20:04:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 20:04:15 --> Helper loaded: url_helper
DEBUG - 2011-05-28 20:04:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 20:04:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 20:04:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 20:04:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 20:04:15 --> Final output sent to browser
DEBUG - 2011-05-28 20:04:15 --> Total execution time: 0.0230
DEBUG - 2011-05-28 20:04:15 --> Config Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Hooks Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Utf8 Class Initialized
DEBUG - 2011-05-28 20:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 20:04:15 --> URI Class Initialized
DEBUG - 2011-05-28 20:04:15 --> Router Class Initialized
ERROR - 2011-05-28 20:04:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 22:14:02 --> Config Class Initialized
DEBUG - 2011-05-28 22:14:02 --> Hooks Class Initialized
DEBUG - 2011-05-28 22:14:02 --> Utf8 Class Initialized
DEBUG - 2011-05-28 22:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 22:14:02 --> URI Class Initialized
DEBUG - 2011-05-28 22:14:02 --> Router Class Initialized
DEBUG - 2011-05-28 22:14:02 --> Output Class Initialized
DEBUG - 2011-05-28 22:14:02 --> Input Class Initialized
DEBUG - 2011-05-28 22:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 22:14:02 --> Language Class Initialized
DEBUG - 2011-05-28 22:14:03 --> Loader Class Initialized
DEBUG - 2011-05-28 22:14:03 --> Controller Class Initialized
DEBUG - 2011-05-28 22:14:03 --> Model Class Initialized
DEBUG - 2011-05-28 22:14:03 --> Model Class Initialized
DEBUG - 2011-05-28 22:14:03 --> Model Class Initialized
DEBUG - 2011-05-28 22:14:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 22:14:03 --> Database Driver Class Initialized
DEBUG - 2011-05-28 22:14:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 22:14:03 --> Helper loaded: url_helper
DEBUG - 2011-05-28 22:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 22:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 22:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 22:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 22:14:03 --> Final output sent to browser
DEBUG - 2011-05-28 22:14:03 --> Total execution time: 0.9376
DEBUG - 2011-05-28 22:14:05 --> Config Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Hooks Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Utf8 Class Initialized
DEBUG - 2011-05-28 22:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 22:14:05 --> URI Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Router Class Initialized
ERROR - 2011-05-28 22:14:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-28 22:14:05 --> Config Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Hooks Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Utf8 Class Initialized
DEBUG - 2011-05-28 22:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 22:14:05 --> URI Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Router Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Output Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Input Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 22:14:05 --> Language Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Loader Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Controller Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Model Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Model Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Model Class Initialized
DEBUG - 2011-05-28 22:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 22:14:05 --> Database Driver Class Initialized
DEBUG - 2011-05-28 22:14:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 22:14:05 --> Helper loaded: url_helper
DEBUG - 2011-05-28 22:14:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 22:14:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 22:14:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 22:14:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 22:14:05 --> Final output sent to browser
DEBUG - 2011-05-28 22:14:05 --> Total execution time: 0.0455
DEBUG - 2011-05-28 22:19:10 --> Config Class Initialized
DEBUG - 2011-05-28 22:19:10 --> Hooks Class Initialized
DEBUG - 2011-05-28 22:19:10 --> Utf8 Class Initialized
DEBUG - 2011-05-28 22:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 22:19:10 --> URI Class Initialized
DEBUG - 2011-05-28 22:19:10 --> Router Class Initialized
DEBUG - 2011-05-28 22:19:10 --> No URI present. Default controller set.
DEBUG - 2011-05-28 22:19:10 --> Output Class Initialized
DEBUG - 2011-05-28 22:19:10 --> Input Class Initialized
DEBUG - 2011-05-28 22:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 22:19:10 --> Language Class Initialized
DEBUG - 2011-05-28 22:19:10 --> Loader Class Initialized
DEBUG - 2011-05-28 22:19:10 --> Controller Class Initialized
DEBUG - 2011-05-28 22:19:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-28 22:19:10 --> Helper loaded: url_helper
DEBUG - 2011-05-28 22:19:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 22:19:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 22:19:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 22:19:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 22:19:10 --> Final output sent to browser
DEBUG - 2011-05-28 22:19:10 --> Total execution time: 0.0644
DEBUG - 2011-05-28 23:29:38 --> Config Class Initialized
DEBUG - 2011-05-28 23:29:38 --> Hooks Class Initialized
DEBUG - 2011-05-28 23:29:38 --> Utf8 Class Initialized
DEBUG - 2011-05-28 23:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 23:29:38 --> URI Class Initialized
DEBUG - 2011-05-28 23:29:38 --> Router Class Initialized
ERROR - 2011-05-28 23:29:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-28 23:29:39 --> Config Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Hooks Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Utf8 Class Initialized
DEBUG - 2011-05-28 23:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 23:29:39 --> URI Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Router Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Output Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Input Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 23:29:39 --> Language Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Loader Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Controller Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Model Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Model Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Model Class Initialized
DEBUG - 2011-05-28 23:29:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 23:29:39 --> Database Driver Class Initialized
DEBUG - 2011-05-28 23:29:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 23:29:40 --> Helper loaded: url_helper
DEBUG - 2011-05-28 23:29:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 23:29:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 23:29:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 23:29:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 23:29:40 --> Final output sent to browser
DEBUG - 2011-05-28 23:29:40 --> Total execution time: 0.7051
DEBUG - 2011-05-28 23:40:22 --> Config Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Hooks Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Utf8 Class Initialized
DEBUG - 2011-05-28 23:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 23:40:22 --> URI Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Router Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Output Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Input Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 23:40:22 --> Language Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Loader Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Controller Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Model Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Model Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Model Class Initialized
DEBUG - 2011-05-28 23:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-28 23:40:22 --> Database Driver Class Initialized
DEBUG - 2011-05-28 23:40:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-28 23:40:22 --> Helper loaded: url_helper
DEBUG - 2011-05-28 23:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-28 23:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-28 23:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-28 23:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-28 23:40:22 --> Final output sent to browser
DEBUG - 2011-05-28 23:40:22 --> Total execution time: 0.5219

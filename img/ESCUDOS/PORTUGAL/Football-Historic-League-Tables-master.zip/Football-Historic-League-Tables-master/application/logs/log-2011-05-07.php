<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-07 01:12:54 --> Config Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Hooks Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Utf8 Class Initialized
DEBUG - 2011-05-07 01:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 01:12:54 --> URI Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Router Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Output Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Input Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 01:12:54 --> Language Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Loader Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Controller Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Model Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Model Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Model Class Initialized
DEBUG - 2011-05-07 01:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 01:12:54 --> Database Driver Class Initialized
DEBUG - 2011-05-07 01:12:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 01:12:54 --> Helper loaded: url_helper
DEBUG - 2011-05-07 01:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 01:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 01:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 01:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 01:12:54 --> Final output sent to browser
DEBUG - 2011-05-07 01:12:54 --> Total execution time: 0.7514
DEBUG - 2011-05-07 01:12:56 --> Config Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Hooks Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Utf8 Class Initialized
DEBUG - 2011-05-07 01:12:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 01:12:56 --> URI Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Router Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Output Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Input Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 01:12:56 --> Language Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Loader Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Controller Class Initialized
ERROR - 2011-05-07 01:12:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 01:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 01:12:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 01:12:56 --> Model Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Model Class Initialized
DEBUG - 2011-05-07 01:12:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 01:12:56 --> Database Driver Class Initialized
DEBUG - 2011-05-07 01:12:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 01:12:56 --> Helper loaded: url_helper
DEBUG - 2011-05-07 01:12:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 01:12:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 01:12:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 01:12:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 01:12:56 --> Final output sent to browser
DEBUG - 2011-05-07 01:12:56 --> Total execution time: 0.1038
DEBUG - 2011-05-07 02:49:36 --> Config Class Initialized
DEBUG - 2011-05-07 02:49:36 --> Hooks Class Initialized
DEBUG - 2011-05-07 02:49:36 --> Utf8 Class Initialized
DEBUG - 2011-05-07 02:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 02:49:36 --> URI Class Initialized
DEBUG - 2011-05-07 02:49:36 --> Router Class Initialized
ERROR - 2011-05-07 02:49:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-07 02:51:38 --> Config Class Initialized
DEBUG - 2011-05-07 02:51:38 --> Hooks Class Initialized
DEBUG - 2011-05-07 02:51:38 --> Utf8 Class Initialized
DEBUG - 2011-05-07 02:51:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 02:51:38 --> URI Class Initialized
DEBUG - 2011-05-07 02:51:38 --> Router Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Output Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Input Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 02:51:39 --> Language Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Loader Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Controller Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Model Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Model Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Model Class Initialized
DEBUG - 2011-05-07 02:51:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 02:51:39 --> Database Driver Class Initialized
DEBUG - 2011-05-07 02:51:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 02:51:44 --> Helper loaded: url_helper
DEBUG - 2011-05-07 02:51:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 02:51:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 02:51:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 02:51:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 02:51:44 --> Final output sent to browser
DEBUG - 2011-05-07 02:51:44 --> Total execution time: 5.0367
DEBUG - 2011-05-07 02:51:45 --> Config Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Hooks Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Utf8 Class Initialized
DEBUG - 2011-05-07 02:51:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 02:51:45 --> URI Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Router Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Output Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Input Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 02:51:45 --> Language Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Loader Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Controller Class Initialized
ERROR - 2011-05-07 02:51:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 02:51:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 02:51:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 02:51:45 --> Model Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Model Class Initialized
DEBUG - 2011-05-07 02:51:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 02:51:45 --> Database Driver Class Initialized
DEBUG - 2011-05-07 02:51:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 02:51:45 --> Helper loaded: url_helper
DEBUG - 2011-05-07 02:51:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 02:51:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 02:51:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 02:51:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 02:51:45 --> Final output sent to browser
DEBUG - 2011-05-07 02:51:45 --> Total execution time: 0.1061
DEBUG - 2011-05-07 03:07:39 --> Config Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Hooks Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Utf8 Class Initialized
DEBUG - 2011-05-07 03:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 03:07:39 --> URI Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Router Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Output Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Input Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 03:07:39 --> Language Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Loader Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Controller Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Model Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Model Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Model Class Initialized
DEBUG - 2011-05-07 03:07:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 03:07:39 --> Database Driver Class Initialized
DEBUG - 2011-05-07 03:07:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 03:07:40 --> Helper loaded: url_helper
DEBUG - 2011-05-07 03:07:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 03:07:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 03:07:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 03:07:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 03:07:40 --> Final output sent to browser
DEBUG - 2011-05-07 03:07:40 --> Total execution time: 0.4482
DEBUG - 2011-05-07 03:29:04 --> Config Class Initialized
DEBUG - 2011-05-07 03:29:04 --> Hooks Class Initialized
DEBUG - 2011-05-07 03:29:04 --> Utf8 Class Initialized
DEBUG - 2011-05-07 03:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 03:29:04 --> URI Class Initialized
DEBUG - 2011-05-07 03:29:04 --> Router Class Initialized
DEBUG - 2011-05-07 03:29:04 --> Output Class Initialized
DEBUG - 2011-05-07 03:29:04 --> Input Class Initialized
DEBUG - 2011-05-07 03:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 03:29:04 --> Language Class Initialized
DEBUG - 2011-05-07 03:29:04 --> Loader Class Initialized
DEBUG - 2011-05-07 03:29:04 --> Controller Class Initialized
ERROR - 2011-05-07 03:29:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 03:29:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 03:29:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 03:29:05 --> Model Class Initialized
DEBUG - 2011-05-07 03:29:05 --> Model Class Initialized
DEBUG - 2011-05-07 03:29:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 03:29:05 --> Database Driver Class Initialized
DEBUG - 2011-05-07 03:29:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 03:29:05 --> Helper loaded: url_helper
DEBUG - 2011-05-07 03:29:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 03:29:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 03:29:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 03:29:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 03:29:05 --> Final output sent to browser
DEBUG - 2011-05-07 03:29:05 --> Total execution time: 0.4332
DEBUG - 2011-05-07 03:29:06 --> Config Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Hooks Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Utf8 Class Initialized
DEBUG - 2011-05-07 03:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 03:29:06 --> URI Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Router Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Output Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Input Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 03:29:06 --> Language Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Loader Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Controller Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Model Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Model Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 03:29:06 --> Database Driver Class Initialized
DEBUG - 2011-05-07 03:29:06 --> Final output sent to browser
DEBUG - 2011-05-07 03:29:06 --> Total execution time: 0.6801
DEBUG - 2011-05-07 03:30:35 --> Config Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Hooks Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Utf8 Class Initialized
DEBUG - 2011-05-07 03:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 03:30:35 --> URI Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Router Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Output Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Input Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 03:30:35 --> Language Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Loader Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Controller Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Model Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Model Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Model Class Initialized
DEBUG - 2011-05-07 03:30:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 03:30:35 --> Database Driver Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Config Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Hooks Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Utf8 Class Initialized
DEBUG - 2011-05-07 03:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 03:30:45 --> URI Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Router Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Output Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Input Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 03:30:45 --> Language Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Loader Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Controller Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Model Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Model Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Model Class Initialized
DEBUG - 2011-05-07 03:30:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 03:30:45 --> Database Driver Class Initialized
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 03:31:05 --> Helper loaded: url_helper
DEBUG - 2011-05-07 03:31:05 --> Helper loaded: url_helper
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 03:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 03:31:05 --> Final output sent to browser
DEBUG - 2011-05-07 03:31:05 --> Total execution time: 20.2438
DEBUG - 2011-05-07 03:31:05 --> Final output sent to browser
DEBUG - 2011-05-07 03:31:05 --> Total execution time: 30.1899
DEBUG - 2011-05-07 04:29:29 --> Config Class Initialized
DEBUG - 2011-05-07 04:29:29 --> Hooks Class Initialized
DEBUG - 2011-05-07 04:29:29 --> Utf8 Class Initialized
DEBUG - 2011-05-07 04:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 04:29:29 --> URI Class Initialized
DEBUG - 2011-05-07 04:29:29 --> Router Class Initialized
DEBUG - 2011-05-07 04:29:29 --> Output Class Initialized
DEBUG - 2011-05-07 04:29:29 --> Input Class Initialized
DEBUG - 2011-05-07 04:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 04:29:29 --> Language Class Initialized
DEBUG - 2011-05-07 04:29:30 --> Loader Class Initialized
DEBUG - 2011-05-07 04:29:30 --> Controller Class Initialized
DEBUG - 2011-05-07 04:29:30 --> Model Class Initialized
DEBUG - 2011-05-07 04:29:30 --> Model Class Initialized
DEBUG - 2011-05-07 04:29:30 --> Model Class Initialized
DEBUG - 2011-05-07 04:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 04:29:30 --> Database Driver Class Initialized
DEBUG - 2011-05-07 04:29:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 04:29:30 --> Helper loaded: url_helper
DEBUG - 2011-05-07 04:29:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 04:29:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 04:29:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 04:29:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 04:29:30 --> Final output sent to browser
DEBUG - 2011-05-07 04:29:30 --> Total execution time: 0.7337
DEBUG - 2011-05-07 04:29:31 --> Config Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Hooks Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Utf8 Class Initialized
DEBUG - 2011-05-07 04:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 04:29:31 --> URI Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Router Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Output Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Input Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 04:29:31 --> Language Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Loader Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Controller Class Initialized
ERROR - 2011-05-07 04:29:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 04:29:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 04:29:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 04:29:31 --> Model Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Model Class Initialized
DEBUG - 2011-05-07 04:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 04:29:31 --> Database Driver Class Initialized
DEBUG - 2011-05-07 04:29:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 04:29:31 --> Helper loaded: url_helper
DEBUG - 2011-05-07 04:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 04:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 04:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 04:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 04:29:31 --> Final output sent to browser
DEBUG - 2011-05-07 04:29:31 --> Total execution time: 0.1061
DEBUG - 2011-05-07 05:15:58 --> Config Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Hooks Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Utf8 Class Initialized
DEBUG - 2011-05-07 05:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 05:15:58 --> URI Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Router Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Output Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Input Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 05:15:58 --> Language Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Loader Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Controller Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Model Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Model Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Model Class Initialized
DEBUG - 2011-05-07 05:15:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 05:15:58 --> Database Driver Class Initialized
DEBUG - 2011-05-07 05:15:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 05:15:58 --> Helper loaded: url_helper
DEBUG - 2011-05-07 05:15:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 05:15:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 05:15:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 05:15:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 05:15:58 --> Final output sent to browser
DEBUG - 2011-05-07 05:15:58 --> Total execution time: 0.5934
DEBUG - 2011-05-07 05:16:02 --> Config Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Hooks Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Utf8 Class Initialized
DEBUG - 2011-05-07 05:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 05:16:02 --> URI Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Router Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Output Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Input Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 05:16:02 --> Language Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Loader Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Controller Class Initialized
ERROR - 2011-05-07 05:16:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 05:16:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 05:16:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 05:16:02 --> Model Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Model Class Initialized
DEBUG - 2011-05-07 05:16:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 05:16:02 --> Database Driver Class Initialized
DEBUG - 2011-05-07 05:16:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 05:16:02 --> Helper loaded: url_helper
DEBUG - 2011-05-07 05:16:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 05:16:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 05:16:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 05:16:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 05:16:02 --> Final output sent to browser
DEBUG - 2011-05-07 05:16:02 --> Total execution time: 0.0933
DEBUG - 2011-05-07 06:07:30 --> Config Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Hooks Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Utf8 Class Initialized
DEBUG - 2011-05-07 06:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 06:07:30 --> URI Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Router Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Output Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Input Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 06:07:30 --> Language Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Loader Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Controller Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Model Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Model Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Model Class Initialized
DEBUG - 2011-05-07 06:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 06:07:30 --> Database Driver Class Initialized
DEBUG - 2011-05-07 06:07:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 06:07:30 --> Helper loaded: url_helper
DEBUG - 2011-05-07 06:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 06:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 06:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 06:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 06:07:30 --> Final output sent to browser
DEBUG - 2011-05-07 06:07:30 --> Total execution time: 0.5149
DEBUG - 2011-05-07 06:07:31 --> Config Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Hooks Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Utf8 Class Initialized
DEBUG - 2011-05-07 06:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 06:07:31 --> URI Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Router Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Output Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Input Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 06:07:31 --> Language Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Loader Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Controller Class Initialized
ERROR - 2011-05-07 06:07:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 06:07:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 06:07:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 06:07:31 --> Model Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Model Class Initialized
DEBUG - 2011-05-07 06:07:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 06:07:31 --> Database Driver Class Initialized
DEBUG - 2011-05-07 06:07:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 06:07:31 --> Helper loaded: url_helper
DEBUG - 2011-05-07 06:07:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 06:07:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 06:07:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 06:07:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 06:07:31 --> Final output sent to browser
DEBUG - 2011-05-07 06:07:31 --> Total execution time: 0.1038
DEBUG - 2011-05-07 06:54:30 --> Config Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Hooks Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Utf8 Class Initialized
DEBUG - 2011-05-07 06:54:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 06:54:30 --> URI Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Router Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Output Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Input Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 06:54:30 --> Language Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Loader Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Controller Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Model Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Model Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Model Class Initialized
DEBUG - 2011-05-07 06:54:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 06:54:30 --> Database Driver Class Initialized
DEBUG - 2011-05-07 06:54:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 06:54:31 --> Helper loaded: url_helper
DEBUG - 2011-05-07 06:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 06:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 06:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 06:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 06:54:31 --> Final output sent to browser
DEBUG - 2011-05-07 06:54:31 --> Total execution time: 0.7359
DEBUG - 2011-05-07 06:54:32 --> Config Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Hooks Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Utf8 Class Initialized
DEBUG - 2011-05-07 06:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 06:54:32 --> URI Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Router Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Output Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Input Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 06:54:32 --> Language Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Loader Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Controller Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Model Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Model Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Model Class Initialized
DEBUG - 2011-05-07 06:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 06:54:32 --> Database Driver Class Initialized
DEBUG - 2011-05-07 06:54:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 06:54:32 --> Helper loaded: url_helper
DEBUG - 2011-05-07 06:54:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 06:54:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 06:54:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 06:54:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 06:54:32 --> Final output sent to browser
DEBUG - 2011-05-07 06:54:32 --> Total execution time: 0.0556
DEBUG - 2011-05-07 07:02:03 --> Config Class Initialized
DEBUG - 2011-05-07 07:02:03 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:02:03 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:02:03 --> URI Class Initialized
DEBUG - 2011-05-07 07:02:03 --> Router Class Initialized
DEBUG - 2011-05-07 07:02:03 --> No URI present. Default controller set.
DEBUG - 2011-05-07 07:02:03 --> Output Class Initialized
DEBUG - 2011-05-07 07:02:03 --> Input Class Initialized
DEBUG - 2011-05-07 07:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:02:03 --> Language Class Initialized
DEBUG - 2011-05-07 07:02:03 --> Loader Class Initialized
DEBUG - 2011-05-07 07:02:03 --> Controller Class Initialized
DEBUG - 2011-05-07 07:02:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-07 07:02:03 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:02:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:02:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:02:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:02:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:02:03 --> Final output sent to browser
DEBUG - 2011-05-07 07:02:03 --> Total execution time: 0.8831
DEBUG - 2011-05-07 07:10:49 --> Config Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:10:49 --> URI Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Router Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Output Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Input Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:10:49 --> Language Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Loader Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Controller Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Model Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Model Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Model Class Initialized
DEBUG - 2011-05-07 07:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:10:49 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:10:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:10:50 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:10:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:10:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:10:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:10:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:10:50 --> Final output sent to browser
DEBUG - 2011-05-07 07:10:50 --> Total execution time: 0.6581
DEBUG - 2011-05-07 07:10:53 --> Config Class Initialized
DEBUG - 2011-05-07 07:10:53 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:10:53 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:10:53 --> URI Class Initialized
DEBUG - 2011-05-07 07:10:53 --> Router Class Initialized
ERROR - 2011-05-07 07:10:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 07:16:29 --> Config Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:16:29 --> URI Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Router Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Output Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Input Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:16:29 --> Language Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Loader Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Controller Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:16:29 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:16:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:16:30 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:16:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:16:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:16:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:16:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:16:30 --> Final output sent to browser
DEBUG - 2011-05-07 07:16:30 --> Total execution time: 0.9784
DEBUG - 2011-05-07 07:16:40 --> Config Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:16:40 --> URI Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Router Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Output Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Input Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:16:40 --> Language Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Loader Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Controller Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:16:40 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:16:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:16:40 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:16:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:16:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:16:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:16:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:16:40 --> Final output sent to browser
DEBUG - 2011-05-07 07:16:40 --> Total execution time: 0.2921
DEBUG - 2011-05-07 07:16:49 --> Config Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:16:49 --> URI Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Router Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Output Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Input Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:16:49 --> Language Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Loader Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Controller Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Model Class Initialized
DEBUG - 2011-05-07 07:16:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:16:49 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:16:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:16:49 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:16:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:16:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:16:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:16:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:16:49 --> Final output sent to browser
DEBUG - 2011-05-07 07:16:49 --> Total execution time: 0.2567
DEBUG - 2011-05-07 07:17:11 --> Config Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:17:11 --> URI Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Router Class Initialized
ERROR - 2011-05-07 07:17:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-07 07:17:11 --> Config Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:17:11 --> URI Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Router Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Output Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Input Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:17:11 --> Language Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Loader Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Controller Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:17:11 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:17:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:17:11 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:17:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:17:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:17:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:17:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:17:11 --> Final output sent to browser
DEBUG - 2011-05-07 07:17:11 --> Total execution time: 0.1451
DEBUG - 2011-05-07 07:17:12 --> Config Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:17:12 --> URI Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Router Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Output Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Input Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:17:12 --> Language Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Loader Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Controller Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:17:12 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:17:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:17:12 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:17:12 --> Final output sent to browser
DEBUG - 2011-05-07 07:17:12 --> Total execution time: 0.1656
DEBUG - 2011-05-07 07:17:14 --> Config Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:17:14 --> URI Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Router Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Output Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Input Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:17:14 --> Language Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Loader Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Controller Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Model Class Initialized
DEBUG - 2011-05-07 07:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:17:14 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:17:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:17:14 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:17:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:17:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:17:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:17:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:17:14 --> Final output sent to browser
DEBUG - 2011-05-07 07:17:14 --> Total execution time: 0.1033
DEBUG - 2011-05-07 07:42:55 --> Config Class Initialized
DEBUG - 2011-05-07 07:42:55 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:42:55 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:42:55 --> URI Class Initialized
DEBUG - 2011-05-07 07:42:55 --> Router Class Initialized
DEBUG - 2011-05-07 07:42:55 --> No URI present. Default controller set.
DEBUG - 2011-05-07 07:42:55 --> Output Class Initialized
DEBUG - 2011-05-07 07:42:55 --> Input Class Initialized
DEBUG - 2011-05-07 07:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:42:55 --> Language Class Initialized
DEBUG - 2011-05-07 07:42:55 --> Loader Class Initialized
DEBUG - 2011-05-07 07:42:55 --> Controller Class Initialized
DEBUG - 2011-05-07 07:42:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-07 07:42:55 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:42:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:42:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:42:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:42:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:42:56 --> Final output sent to browser
DEBUG - 2011-05-07 07:42:56 --> Total execution time: 0.2610
DEBUG - 2011-05-07 07:42:58 --> Config Class Initialized
DEBUG - 2011-05-07 07:42:58 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:42:58 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:42:58 --> URI Class Initialized
DEBUG - 2011-05-07 07:42:58 --> Router Class Initialized
ERROR - 2011-05-07 07:42:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 07:42:59 --> Config Class Initialized
DEBUG - 2011-05-07 07:42:59 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:42:59 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:42:59 --> URI Class Initialized
DEBUG - 2011-05-07 07:42:59 --> Router Class Initialized
ERROR - 2011-05-07 07:42:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 07:44:44 --> Config Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:44:44 --> URI Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Router Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Output Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Input Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:44:44 --> Language Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Loader Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Controller Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Model Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Model Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Model Class Initialized
DEBUG - 2011-05-07 07:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:44:45 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:44:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:44:45 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:44:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:44:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:44:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:44:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:44:45 --> Final output sent to browser
DEBUG - 2011-05-07 07:44:45 --> Total execution time: 0.3792
DEBUG - 2011-05-07 07:44:46 --> Config Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:44:46 --> URI Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Router Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Output Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Input Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:44:46 --> Language Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Loader Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Controller Class Initialized
ERROR - 2011-05-07 07:44:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 07:44:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 07:44:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 07:44:46 --> Model Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Model Class Initialized
DEBUG - 2011-05-07 07:44:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:44:46 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:44:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 07:44:46 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:44:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:44:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:44:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:44:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:44:46 --> Final output sent to browser
DEBUG - 2011-05-07 07:44:46 --> Total execution time: 0.2570
DEBUG - 2011-05-07 07:54:32 --> Config Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Hooks Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Utf8 Class Initialized
DEBUG - 2011-05-07 07:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 07:54:32 --> URI Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Router Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Output Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Input Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 07:54:32 --> Language Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Loader Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Controller Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Model Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Model Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Model Class Initialized
DEBUG - 2011-05-07 07:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 07:54:32 --> Database Driver Class Initialized
DEBUG - 2011-05-07 07:54:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 07:54:32 --> Helper loaded: url_helper
DEBUG - 2011-05-07 07:54:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 07:54:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 07:54:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 07:54:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 07:54:32 --> Final output sent to browser
DEBUG - 2011-05-07 07:54:32 --> Total execution time: 0.0973
DEBUG - 2011-05-07 09:27:45 --> Config Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:27:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:27:45 --> URI Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Router Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Output Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Input Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:27:45 --> Language Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Loader Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Controller Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Model Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Model Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Model Class Initialized
DEBUG - 2011-05-07 09:27:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:27:45 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:27:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:27:45 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:27:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:27:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:27:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:27:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:27:45 --> Final output sent to browser
DEBUG - 2011-05-07 09:27:45 --> Total execution time: 0.7217
DEBUG - 2011-05-07 09:27:59 --> Config Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:27:59 --> URI Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Router Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Output Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Input Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:27:59 --> Language Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Loader Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Controller Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Model Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Model Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Model Class Initialized
DEBUG - 2011-05-07 09:27:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:27:59 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:28:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:28:00 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:28:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:28:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:28:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:28:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:28:00 --> Final output sent to browser
DEBUG - 2011-05-07 09:28:00 --> Total execution time: 0.1860
DEBUG - 2011-05-07 09:28:04 --> Config Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:28:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:28:04 --> URI Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Router Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Output Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Input Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:28:04 --> Language Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Loader Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Controller Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:28:04 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:28:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:28:05 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:28:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:28:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:28:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:28:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:28:05 --> Final output sent to browser
DEBUG - 2011-05-07 09:28:05 --> Total execution time: 0.2736
DEBUG - 2011-05-07 09:28:52 --> Config Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:28:52 --> URI Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Router Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Output Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Input Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:28:52 --> Language Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Loader Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Controller Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:28:52 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:28:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:28:52 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:28:52 --> Final output sent to browser
DEBUG - 2011-05-07 09:28:52 --> Total execution time: 0.3405
DEBUG - 2011-05-07 09:28:53 --> Config Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:28:53 --> URI Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Router Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Output Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Input Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:28:53 --> Language Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Loader Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Controller Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:28:53 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:28:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:28:53 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:28:53 --> Final output sent to browser
DEBUG - 2011-05-07 09:28:53 --> Total execution time: 0.0990
DEBUG - 2011-05-07 09:28:53 --> Config Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:28:53 --> URI Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Router Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Output Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Input Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:28:53 --> Language Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Loader Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Controller Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:28:53 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:28:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:28:54 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:28:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:28:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:28:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:28:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:28:54 --> Final output sent to browser
DEBUG - 2011-05-07 09:28:54 --> Total execution time: 0.0723
DEBUG - 2011-05-07 09:28:59 --> Config Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:28:59 --> URI Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Router Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Output Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Input Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:28:59 --> Language Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Loader Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Controller Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Model Class Initialized
DEBUG - 2011-05-07 09:28:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:28:59 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:29:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:29:00 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:29:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:29:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:29:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:29:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:29:00 --> Final output sent to browser
DEBUG - 2011-05-07 09:29:00 --> Total execution time: 0.3001
DEBUG - 2011-05-07 09:29:02 --> Config Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:29:02 --> URI Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Router Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Output Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Input Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:29:02 --> Language Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Loader Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Controller Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:29:02 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:29:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:29:02 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:29:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:29:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:29:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:29:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:29:02 --> Final output sent to browser
DEBUG - 2011-05-07 09:29:02 --> Total execution time: 0.0497
DEBUG - 2011-05-07 09:29:15 --> Config Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:29:15 --> URI Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Router Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Output Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Input Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:29:15 --> Language Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Loader Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Controller Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:29:15 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:29:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:29:15 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:29:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:29:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:29:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:29:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:29:15 --> Final output sent to browser
DEBUG - 2011-05-07 09:29:15 --> Total execution time: 0.2270
DEBUG - 2011-05-07 09:29:16 --> Config Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:29:16 --> URI Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Router Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Output Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Input Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:29:16 --> Language Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Loader Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Controller Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:29:16 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:29:16 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:29:16 --> Final output sent to browser
DEBUG - 2011-05-07 09:29:16 --> Total execution time: 0.0472
DEBUG - 2011-05-07 09:29:16 --> Config Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Hooks Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Utf8 Class Initialized
DEBUG - 2011-05-07 09:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 09:29:16 --> URI Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Router Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Output Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Input Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 09:29:16 --> Language Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Loader Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Controller Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Model Class Initialized
DEBUG - 2011-05-07 09:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 09:29:16 --> Database Driver Class Initialized
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 09:29:16 --> Helper loaded: url_helper
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 09:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 09:29:16 --> Final output sent to browser
DEBUG - 2011-05-07 09:29:16 --> Total execution time: 0.0544
DEBUG - 2011-05-07 10:14:06 --> Config Class Initialized
DEBUG - 2011-05-07 10:14:06 --> Hooks Class Initialized
DEBUG - 2011-05-07 10:14:06 --> Utf8 Class Initialized
DEBUG - 2011-05-07 10:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 10:14:06 --> URI Class Initialized
DEBUG - 2011-05-07 10:14:06 --> Router Class Initialized
DEBUG - 2011-05-07 10:14:06 --> Output Class Initialized
DEBUG - 2011-05-07 10:14:06 --> Input Class Initialized
DEBUG - 2011-05-07 10:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 10:14:06 --> Language Class Initialized
DEBUG - 2011-05-07 10:14:06 --> Loader Class Initialized
DEBUG - 2011-05-07 10:14:06 --> Controller Class Initialized
DEBUG - 2011-05-07 10:14:07 --> Model Class Initialized
DEBUG - 2011-05-07 10:14:07 --> Model Class Initialized
DEBUG - 2011-05-07 10:14:07 --> Model Class Initialized
DEBUG - 2011-05-07 10:14:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 10:14:07 --> Database Driver Class Initialized
DEBUG - 2011-05-07 10:14:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 10:14:07 --> Helper loaded: url_helper
DEBUG - 2011-05-07 10:14:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 10:14:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 10:14:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 10:14:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 10:14:07 --> Final output sent to browser
DEBUG - 2011-05-07 10:14:07 --> Total execution time: 0.5304
DEBUG - 2011-05-07 10:14:10 --> Config Class Initialized
DEBUG - 2011-05-07 10:14:10 --> Hooks Class Initialized
DEBUG - 2011-05-07 10:14:10 --> Utf8 Class Initialized
DEBUG - 2011-05-07 10:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 10:14:10 --> URI Class Initialized
DEBUG - 2011-05-07 10:14:10 --> Router Class Initialized
ERROR - 2011-05-07 10:14:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 10:14:11 --> Config Class Initialized
DEBUG - 2011-05-07 10:14:11 --> Hooks Class Initialized
DEBUG - 2011-05-07 10:14:11 --> Utf8 Class Initialized
DEBUG - 2011-05-07 10:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 10:14:11 --> URI Class Initialized
DEBUG - 2011-05-07 10:14:11 --> Router Class Initialized
ERROR - 2011-05-07 10:14:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 10:16:14 --> Config Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Hooks Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Utf8 Class Initialized
DEBUG - 2011-05-07 10:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 10:16:14 --> URI Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Router Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Output Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Input Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 10:16:14 --> Language Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Loader Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Controller Class Initialized
ERROR - 2011-05-07 10:16:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 10:16:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 10:16:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 10:16:14 --> Model Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Model Class Initialized
DEBUG - 2011-05-07 10:16:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 10:16:14 --> Database Driver Class Initialized
DEBUG - 2011-05-07 10:16:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 10:16:14 --> Helper loaded: url_helper
DEBUG - 2011-05-07 10:16:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 10:16:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 10:16:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 10:16:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 10:16:14 --> Final output sent to browser
DEBUG - 2011-05-07 10:16:14 --> Total execution time: 0.1748
DEBUG - 2011-05-07 10:16:17 --> Config Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Hooks Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Utf8 Class Initialized
DEBUG - 2011-05-07 10:16:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 10:16:17 --> URI Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Router Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Output Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Input Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 10:16:17 --> Language Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Loader Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Controller Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Model Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Model Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 10:16:17 --> Database Driver Class Initialized
DEBUG - 2011-05-07 10:16:17 --> Final output sent to browser
DEBUG - 2011-05-07 10:16:17 --> Total execution time: 0.6117
DEBUG - 2011-05-07 10:16:20 --> Config Class Initialized
DEBUG - 2011-05-07 10:16:20 --> Hooks Class Initialized
DEBUG - 2011-05-07 10:16:20 --> Utf8 Class Initialized
DEBUG - 2011-05-07 10:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 10:16:20 --> URI Class Initialized
DEBUG - 2011-05-07 10:16:20 --> Router Class Initialized
ERROR - 2011-05-07 10:16:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 10:16:21 --> Config Class Initialized
DEBUG - 2011-05-07 10:16:21 --> Hooks Class Initialized
DEBUG - 2011-05-07 10:16:21 --> Utf8 Class Initialized
DEBUG - 2011-05-07 10:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 10:16:21 --> URI Class Initialized
DEBUG - 2011-05-07 10:16:21 --> Router Class Initialized
ERROR - 2011-05-07 10:16:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 11:04:55 --> Config Class Initialized
DEBUG - 2011-05-07 11:04:55 --> Hooks Class Initialized
DEBUG - 2011-05-07 11:04:55 --> Utf8 Class Initialized
DEBUG - 2011-05-07 11:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 11:04:55 --> URI Class Initialized
DEBUG - 2011-05-07 11:04:55 --> Router Class Initialized
DEBUG - 2011-05-07 11:04:55 --> Output Class Initialized
DEBUG - 2011-05-07 11:04:55 --> Input Class Initialized
DEBUG - 2011-05-07 11:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 11:04:55 --> Language Class Initialized
DEBUG - 2011-05-07 11:04:55 --> Loader Class Initialized
DEBUG - 2011-05-07 11:04:56 --> Controller Class Initialized
DEBUG - 2011-05-07 11:04:56 --> Model Class Initialized
DEBUG - 2011-05-07 11:04:56 --> Model Class Initialized
DEBUG - 2011-05-07 11:04:56 --> Model Class Initialized
DEBUG - 2011-05-07 11:04:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 11:04:56 --> Database Driver Class Initialized
DEBUG - 2011-05-07 11:04:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 11:04:56 --> Helper loaded: url_helper
DEBUG - 2011-05-07 11:04:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 11:04:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 11:04:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 11:04:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 11:04:56 --> Final output sent to browser
DEBUG - 2011-05-07 11:04:56 --> Total execution time: 1.0419
DEBUG - 2011-05-07 11:04:58 --> Config Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Hooks Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Utf8 Class Initialized
DEBUG - 2011-05-07 11:04:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 11:04:58 --> URI Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Router Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Output Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Input Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 11:04:58 --> Language Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Loader Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Controller Class Initialized
ERROR - 2011-05-07 11:04:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 11:04:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 11:04:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 11:04:58 --> Model Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Model Class Initialized
DEBUG - 2011-05-07 11:04:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 11:04:58 --> Database Driver Class Initialized
DEBUG - 2011-05-07 11:04:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 11:04:58 --> Helper loaded: url_helper
DEBUG - 2011-05-07 11:04:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 11:04:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 11:04:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 11:04:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 11:04:58 --> Final output sent to browser
DEBUG - 2011-05-07 11:04:58 --> Total execution time: 0.1316
DEBUG - 2011-05-07 12:41:30 --> Config Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Hooks Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Utf8 Class Initialized
DEBUG - 2011-05-07 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 12:41:30 --> URI Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Router Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Output Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Input Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 12:41:30 --> Language Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Loader Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Controller Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Model Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Model Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Model Class Initialized
DEBUG - 2011-05-07 12:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 12:41:30 --> Database Driver Class Initialized
DEBUG - 2011-05-07 12:41:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 12:41:31 --> Helper loaded: url_helper
DEBUG - 2011-05-07 12:41:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 12:41:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 12:41:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 12:41:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 12:41:31 --> Final output sent to browser
DEBUG - 2011-05-07 12:41:31 --> Total execution time: 1.0321
DEBUG - 2011-05-07 12:41:32 --> Config Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Hooks Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Utf8 Class Initialized
DEBUG - 2011-05-07 12:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 12:41:32 --> URI Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Router Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Output Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Input Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 12:41:32 --> Language Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Loader Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Controller Class Initialized
ERROR - 2011-05-07 12:41:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 12:41:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 12:41:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 12:41:32 --> Model Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Model Class Initialized
DEBUG - 2011-05-07 12:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 12:41:32 --> Database Driver Class Initialized
DEBUG - 2011-05-07 12:41:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 12:41:32 --> Helper loaded: url_helper
DEBUG - 2011-05-07 12:41:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 12:41:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 12:41:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 12:41:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 12:41:32 --> Final output sent to browser
DEBUG - 2011-05-07 12:41:32 --> Total execution time: 0.1021
DEBUG - 2011-05-07 14:07:10 --> Config Class Initialized
DEBUG - 2011-05-07 14:07:10 --> Hooks Class Initialized
DEBUG - 2011-05-07 14:07:10 --> Utf8 Class Initialized
DEBUG - 2011-05-07 14:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 14:07:10 --> URI Class Initialized
DEBUG - 2011-05-07 14:07:10 --> Router Class Initialized
DEBUG - 2011-05-07 14:07:10 --> Output Class Initialized
DEBUG - 2011-05-07 14:07:10 --> Input Class Initialized
DEBUG - 2011-05-07 14:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 14:07:10 --> Language Class Initialized
DEBUG - 2011-05-07 14:07:10 --> Loader Class Initialized
DEBUG - 2011-05-07 14:07:10 --> Controller Class Initialized
DEBUG - 2011-05-07 14:07:11 --> Model Class Initialized
DEBUG - 2011-05-07 14:07:11 --> Model Class Initialized
DEBUG - 2011-05-07 14:07:11 --> Model Class Initialized
DEBUG - 2011-05-07 14:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 14:07:11 --> Database Driver Class Initialized
DEBUG - 2011-05-07 14:07:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 14:07:12 --> Helper loaded: url_helper
DEBUG - 2011-05-07 14:07:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 14:07:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 14:07:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 14:07:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 14:07:12 --> Final output sent to browser
DEBUG - 2011-05-07 14:07:12 --> Total execution time: 2.7823
DEBUG - 2011-05-07 14:07:15 --> Config Class Initialized
DEBUG - 2011-05-07 14:07:15 --> Hooks Class Initialized
DEBUG - 2011-05-07 14:07:15 --> Utf8 Class Initialized
DEBUG - 2011-05-07 14:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 14:07:15 --> URI Class Initialized
DEBUG - 2011-05-07 14:07:15 --> Router Class Initialized
ERROR - 2011-05-07 14:07:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 14:07:15 --> Config Class Initialized
DEBUG - 2011-05-07 14:07:15 --> Hooks Class Initialized
DEBUG - 2011-05-07 14:07:15 --> Utf8 Class Initialized
DEBUG - 2011-05-07 14:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 14:07:15 --> URI Class Initialized
DEBUG - 2011-05-07 14:07:15 --> Router Class Initialized
ERROR - 2011-05-07 14:07:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 14:07:17 --> Config Class Initialized
DEBUG - 2011-05-07 14:07:17 --> Hooks Class Initialized
DEBUG - 2011-05-07 14:07:17 --> Utf8 Class Initialized
DEBUG - 2011-05-07 14:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 14:07:17 --> URI Class Initialized
DEBUG - 2011-05-07 14:07:17 --> Router Class Initialized
ERROR - 2011-05-07 14:07:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 14:18:15 --> Config Class Initialized
DEBUG - 2011-05-07 14:18:15 --> Hooks Class Initialized
DEBUG - 2011-05-07 14:18:15 --> Utf8 Class Initialized
DEBUG - 2011-05-07 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 14:18:15 --> URI Class Initialized
DEBUG - 2011-05-07 14:18:15 --> Router Class Initialized
DEBUG - 2011-05-07 14:18:16 --> Output Class Initialized
DEBUG - 2011-05-07 14:18:16 --> Input Class Initialized
DEBUG - 2011-05-07 14:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 14:18:16 --> Language Class Initialized
DEBUG - 2011-05-07 14:18:16 --> Loader Class Initialized
DEBUG - 2011-05-07 14:18:16 --> Controller Class Initialized
DEBUG - 2011-05-07 14:18:16 --> Model Class Initialized
DEBUG - 2011-05-07 14:18:16 --> Model Class Initialized
DEBUG - 2011-05-07 14:18:17 --> Model Class Initialized
DEBUG - 2011-05-07 14:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 14:18:17 --> Database Driver Class Initialized
DEBUG - 2011-05-07 14:18:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 14:18:18 --> Helper loaded: url_helper
DEBUG - 2011-05-07 14:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 14:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 14:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 14:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 14:18:18 --> Final output sent to browser
DEBUG - 2011-05-07 14:18:18 --> Total execution time: 2.5034
DEBUG - 2011-05-07 14:18:20 --> Config Class Initialized
DEBUG - 2011-05-07 14:18:20 --> Hooks Class Initialized
DEBUG - 2011-05-07 14:18:20 --> Utf8 Class Initialized
DEBUG - 2011-05-07 14:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 14:18:20 --> URI Class Initialized
DEBUG - 2011-05-07 14:18:20 --> Router Class Initialized
DEBUG - 2011-05-07 14:18:21 --> Output Class Initialized
DEBUG - 2011-05-07 14:18:21 --> Input Class Initialized
DEBUG - 2011-05-07 14:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 14:18:21 --> Language Class Initialized
DEBUG - 2011-05-07 14:18:21 --> Loader Class Initialized
DEBUG - 2011-05-07 14:18:21 --> Controller Class Initialized
ERROR - 2011-05-07 14:18:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 14:18:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 14:18:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 14:18:21 --> Model Class Initialized
DEBUG - 2011-05-07 14:18:21 --> Model Class Initialized
DEBUG - 2011-05-07 14:18:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 14:18:21 --> Database Driver Class Initialized
DEBUG - 2011-05-07 14:18:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 14:18:21 --> Helper loaded: url_helper
DEBUG - 2011-05-07 14:18:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 14:18:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 14:18:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 14:18:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 14:18:21 --> Final output sent to browser
DEBUG - 2011-05-07 14:18:21 --> Total execution time: 0.3757
DEBUG - 2011-05-07 20:30:03 --> Config Class Initialized
DEBUG - 2011-05-07 20:30:03 --> Hooks Class Initialized
DEBUG - 2011-05-07 20:30:03 --> Utf8 Class Initialized
DEBUG - 2011-05-07 20:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 20:30:03 --> URI Class Initialized
DEBUG - 2011-05-07 20:30:03 --> Router Class Initialized
DEBUG - 2011-05-07 20:30:03 --> No URI present. Default controller set.
DEBUG - 2011-05-07 20:30:03 --> Output Class Initialized
DEBUG - 2011-05-07 20:30:03 --> Input Class Initialized
DEBUG - 2011-05-07 20:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 20:30:03 --> Language Class Initialized
DEBUG - 2011-05-07 20:30:03 --> Loader Class Initialized
DEBUG - 2011-05-07 20:30:03 --> Controller Class Initialized
DEBUG - 2011-05-07 20:30:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-07 20:30:03 --> Helper loaded: url_helper
DEBUG - 2011-05-07 20:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 20:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 20:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 20:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 20:30:03 --> Final output sent to browser
DEBUG - 2011-05-07 20:30:03 --> Total execution time: 0.4437
DEBUG - 2011-05-07 21:25:26 --> Config Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Config Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Hooks Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Hooks Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Utf8 Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Utf8 Class Initialized
DEBUG - 2011-05-07 21:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 21:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 21:25:26 --> URI Class Initialized
DEBUG - 2011-05-07 21:25:26 --> URI Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Router Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Router Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Output Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Output Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Input Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 21:25:26 --> Input Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 21:25:26 --> Language Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Language Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Loader Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Loader Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Controller Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Controller Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Model Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Model Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Model Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Model Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Model Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Model Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 21:25:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 21:25:26 --> Database Driver Class Initialized
DEBUG - 2011-05-07 21:25:26 --> Database Driver Class Initialized
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-07 21:25:27 --> Helper loaded: url_helper
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 21:25:27 --> Helper loaded: url_helper
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 21:25:27 --> Final output sent to browser
DEBUG - 2011-05-07 21:25:27 --> Total execution time: 1.1790
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 21:25:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 21:25:27 --> Final output sent to browser
DEBUG - 2011-05-07 21:25:27 --> Total execution time: 1.1840
DEBUG - 2011-05-07 23:32:14 --> Config Class Initialized
DEBUG - 2011-05-07 23:32:14 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:32:14 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:32:14 --> URI Class Initialized
DEBUG - 2011-05-07 23:32:14 --> Router Class Initialized
DEBUG - 2011-05-07 23:32:14 --> Output Class Initialized
DEBUG - 2011-05-07 23:32:14 --> Input Class Initialized
DEBUG - 2011-05-07 23:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 23:32:14 --> Language Class Initialized
DEBUG - 2011-05-07 23:32:14 --> Loader Class Initialized
DEBUG - 2011-05-07 23:32:14 --> Controller Class Initialized
ERROR - 2011-05-07 23:32:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 23:32:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 23:32:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:32:15 --> Model Class Initialized
DEBUG - 2011-05-07 23:32:15 --> Model Class Initialized
DEBUG - 2011-05-07 23:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 23:32:15 --> Database Driver Class Initialized
DEBUG - 2011-05-07 23:32:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:32:15 --> Helper loaded: url_helper
DEBUG - 2011-05-07 23:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 23:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 23:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 23:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 23:32:15 --> Final output sent to browser
DEBUG - 2011-05-07 23:32:15 --> Total execution time: 0.3233
DEBUG - 2011-05-07 23:32:17 --> Config Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:32:17 --> URI Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Router Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Output Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Input Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 23:32:17 --> Language Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Loader Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Controller Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Model Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Model Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 23:32:17 --> Database Driver Class Initialized
DEBUG - 2011-05-07 23:32:17 --> Final output sent to browser
DEBUG - 2011-05-07 23:32:17 --> Total execution time: 0.6137
DEBUG - 2011-05-07 23:32:21 --> Config Class Initialized
DEBUG - 2011-05-07 23:32:21 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:32:21 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:32:21 --> URI Class Initialized
DEBUG - 2011-05-07 23:32:21 --> Router Class Initialized
ERROR - 2011-05-07 23:32:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 23:32:44 --> Config Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:32:44 --> URI Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Router Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Output Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Input Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 23:32:44 --> Language Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Loader Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Controller Class Initialized
ERROR - 2011-05-07 23:32:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 23:32:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 23:32:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:32:44 --> Model Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Model Class Initialized
DEBUG - 2011-05-07 23:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 23:32:44 --> Database Driver Class Initialized
DEBUG - 2011-05-07 23:32:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:32:44 --> Helper loaded: url_helper
DEBUG - 2011-05-07 23:32:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 23:32:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 23:32:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 23:32:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 23:32:44 --> Final output sent to browser
DEBUG - 2011-05-07 23:32:44 --> Total execution time: 0.0817
DEBUG - 2011-05-07 23:32:46 --> Config Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:32:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:32:46 --> URI Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Router Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Output Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Input Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 23:32:46 --> Language Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Loader Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Controller Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Model Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Model Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 23:32:46 --> Database Driver Class Initialized
DEBUG - 2011-05-07 23:32:46 --> Final output sent to browser
DEBUG - 2011-05-07 23:32:46 --> Total execution time: 0.5569
DEBUG - 2011-05-07 23:32:51 --> Config Class Initialized
DEBUG - 2011-05-07 23:32:51 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:32:51 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:32:51 --> URI Class Initialized
DEBUG - 2011-05-07 23:32:51 --> Router Class Initialized
ERROR - 2011-05-07 23:32:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 23:33:05 --> Config Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:33:05 --> URI Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Router Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Output Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Input Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 23:33:05 --> Language Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Loader Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Controller Class Initialized
ERROR - 2011-05-07 23:33:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 23:33:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 23:33:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:33:05 --> Model Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Model Class Initialized
DEBUG - 2011-05-07 23:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 23:33:05 --> Database Driver Class Initialized
DEBUG - 2011-05-07 23:33:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:33:05 --> Helper loaded: url_helper
DEBUG - 2011-05-07 23:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 23:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 23:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 23:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 23:33:05 --> Final output sent to browser
DEBUG - 2011-05-07 23:33:05 --> Total execution time: 0.0297
DEBUG - 2011-05-07 23:33:06 --> Config Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:33:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:33:06 --> URI Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Router Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Output Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Input Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 23:33:06 --> Language Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Loader Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Controller Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Model Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Model Class Initialized
DEBUG - 2011-05-07 23:33:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 23:33:06 --> Database Driver Class Initialized
DEBUG - 2011-05-07 23:33:07 --> Final output sent to browser
DEBUG - 2011-05-07 23:33:07 --> Total execution time: 0.6961
DEBUG - 2011-05-07 23:33:11 --> Config Class Initialized
DEBUG - 2011-05-07 23:33:11 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:33:11 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:33:11 --> URI Class Initialized
DEBUG - 2011-05-07 23:33:11 --> Router Class Initialized
ERROR - 2011-05-07 23:33:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-07 23:33:34 --> Config Class Initialized
DEBUG - 2011-05-07 23:33:34 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:33:34 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:33:34 --> URI Class Initialized
DEBUG - 2011-05-07 23:33:34 --> Router Class Initialized
ERROR - 2011-05-07 23:33:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-07 23:33:35 --> Config Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:33:35 --> URI Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Router Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Output Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Input Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 23:33:35 --> Language Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Loader Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Controller Class Initialized
ERROR - 2011-05-07 23:33:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 23:33:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:33:35 --> Model Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Model Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 23:33:35 --> Database Driver Class Initialized
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:33:35 --> Helper loaded: url_helper
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 23:33:35 --> Final output sent to browser
DEBUG - 2011-05-07 23:33:35 --> Total execution time: 0.0292
DEBUG - 2011-05-07 23:33:35 --> Config Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Hooks Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Utf8 Class Initialized
DEBUG - 2011-05-07 23:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-07 23:33:35 --> URI Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Router Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Output Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Input Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-07 23:33:35 --> Language Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Loader Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Controller Class Initialized
ERROR - 2011-05-07 23:33:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-07 23:33:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:33:35 --> Model Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Model Class Initialized
DEBUG - 2011-05-07 23:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-07 23:33:35 --> Database Driver Class Initialized
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-07 23:33:35 --> Helper loaded: url_helper
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-07 23:33:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-07 23:33:35 --> Final output sent to browser
DEBUG - 2011-05-07 23:33:35 --> Total execution time: 0.0344

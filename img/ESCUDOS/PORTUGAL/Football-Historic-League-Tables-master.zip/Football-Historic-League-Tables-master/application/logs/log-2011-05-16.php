<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-16 00:57:04 --> Config Class Initialized
DEBUG - 2011-05-16 00:57:04 --> Hooks Class Initialized
DEBUG - 2011-05-16 00:57:04 --> Utf8 Class Initialized
DEBUG - 2011-05-16 00:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 00:57:04 --> URI Class Initialized
DEBUG - 2011-05-16 00:57:04 --> Router Class Initialized
ERROR - 2011-05-16 00:57:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-16 00:58:10 --> Config Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Hooks Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Utf8 Class Initialized
DEBUG - 2011-05-16 00:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 00:58:10 --> URI Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Router Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Output Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Input Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 00:58:10 --> Language Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Loader Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Controller Class Initialized
DEBUG - 2011-05-16 00:58:10 --> Model Class Initialized
DEBUG - 2011-05-16 00:58:11 --> Model Class Initialized
DEBUG - 2011-05-16 00:58:11 --> Model Class Initialized
DEBUG - 2011-05-16 00:58:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 00:58:11 --> Database Driver Class Initialized
DEBUG - 2011-05-16 00:58:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 00:58:11 --> Helper loaded: url_helper
DEBUG - 2011-05-16 00:58:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 00:58:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 00:58:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 00:58:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 00:58:11 --> Final output sent to browser
DEBUG - 2011-05-16 00:58:11 --> Total execution time: 0.8036
DEBUG - 2011-05-16 02:38:24 --> Config Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Hooks Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Utf8 Class Initialized
DEBUG - 2011-05-16 02:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 02:38:24 --> URI Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Router Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Output Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Input Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 02:38:24 --> Language Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Loader Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Controller Class Initialized
ERROR - 2011-05-16 02:38:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 02:38:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 02:38:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 02:38:24 --> Model Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Model Class Initialized
DEBUG - 2011-05-16 02:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 02:38:24 --> Database Driver Class Initialized
DEBUG - 2011-05-16 02:38:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 02:38:25 --> Helper loaded: url_helper
DEBUG - 2011-05-16 02:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 02:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 02:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 02:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 02:38:25 --> Final output sent to browser
DEBUG - 2011-05-16 02:38:25 --> Total execution time: 1.0198
DEBUG - 2011-05-16 02:38:26 --> Config Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Hooks Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Utf8 Class Initialized
DEBUG - 2011-05-16 02:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 02:38:26 --> URI Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Router Class Initialized
ERROR - 2011-05-16 02:38:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 02:38:26 --> Config Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Hooks Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Utf8 Class Initialized
DEBUG - 2011-05-16 02:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 02:38:26 --> URI Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Router Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Output Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Input Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 02:38:26 --> Language Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Loader Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Controller Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Model Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Model Class Initialized
DEBUG - 2011-05-16 02:38:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 02:38:26 --> Database Driver Class Initialized
DEBUG - 2011-05-16 02:38:27 --> Final output sent to browser
DEBUG - 2011-05-16 02:38:27 --> Total execution time: 1.1674
DEBUG - 2011-05-16 03:59:34 --> Config Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Hooks Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Utf8 Class Initialized
DEBUG - 2011-05-16 03:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 03:59:34 --> URI Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Router Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Output Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Input Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 03:59:34 --> Language Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Loader Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Controller Class Initialized
ERROR - 2011-05-16 03:59:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 03:59:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 03:59:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 03:59:34 --> Model Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Model Class Initialized
DEBUG - 2011-05-16 03:59:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 03:59:34 --> Database Driver Class Initialized
DEBUG - 2011-05-16 03:59:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 03:59:34 --> Helper loaded: url_helper
DEBUG - 2011-05-16 03:59:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 03:59:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 03:59:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 03:59:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 03:59:34 --> Final output sent to browser
DEBUG - 2011-05-16 03:59:34 --> Total execution time: 0.8284
DEBUG - 2011-05-16 03:59:36 --> Config Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Hooks Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Utf8 Class Initialized
DEBUG - 2011-05-16 03:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 03:59:36 --> URI Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Router Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Output Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Input Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 03:59:36 --> Language Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Loader Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Controller Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Model Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Model Class Initialized
DEBUG - 2011-05-16 03:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 03:59:36 --> Database Driver Class Initialized
DEBUG - 2011-05-16 03:59:37 --> Final output sent to browser
DEBUG - 2011-05-16 03:59:37 --> Total execution time: 1.5023
DEBUG - 2011-05-16 03:59:39 --> Config Class Initialized
DEBUG - 2011-05-16 03:59:39 --> Hooks Class Initialized
DEBUG - 2011-05-16 03:59:39 --> Utf8 Class Initialized
DEBUG - 2011-05-16 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 03:59:39 --> URI Class Initialized
DEBUG - 2011-05-16 03:59:39 --> Router Class Initialized
ERROR - 2011-05-16 03:59:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 03:59:39 --> Config Class Initialized
DEBUG - 2011-05-16 03:59:39 --> Hooks Class Initialized
DEBUG - 2011-05-16 03:59:39 --> Utf8 Class Initialized
DEBUG - 2011-05-16 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 03:59:39 --> URI Class Initialized
DEBUG - 2011-05-16 03:59:39 --> Router Class Initialized
ERROR - 2011-05-16 03:59:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 03:59:40 --> Config Class Initialized
DEBUG - 2011-05-16 03:59:40 --> Hooks Class Initialized
DEBUG - 2011-05-16 03:59:40 --> Utf8 Class Initialized
DEBUG - 2011-05-16 03:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 03:59:40 --> URI Class Initialized
DEBUG - 2011-05-16 03:59:40 --> Router Class Initialized
ERROR - 2011-05-16 03:59:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 06:32:15 --> Config Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Hooks Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Utf8 Class Initialized
DEBUG - 2011-05-16 06:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 06:32:15 --> URI Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Router Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Output Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Input Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 06:32:15 --> Language Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Loader Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Controller Class Initialized
ERROR - 2011-05-16 06:32:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 06:32:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 06:32:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 06:32:15 --> Model Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Model Class Initialized
DEBUG - 2011-05-16 06:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 06:32:15 --> Database Driver Class Initialized
DEBUG - 2011-05-16 06:32:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 06:32:16 --> Helper loaded: url_helper
DEBUG - 2011-05-16 06:32:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 06:32:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 06:32:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 06:32:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 06:32:16 --> Final output sent to browser
DEBUG - 2011-05-16 06:32:16 --> Total execution time: 1.4307
DEBUG - 2011-05-16 06:32:21 --> Config Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Hooks Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Utf8 Class Initialized
DEBUG - 2011-05-16 06:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 06:32:21 --> URI Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Router Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Output Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Input Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 06:32:21 --> Language Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Loader Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Controller Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Model Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Model Class Initialized
DEBUG - 2011-05-16 06:32:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 06:32:21 --> Database Driver Class Initialized
DEBUG - 2011-05-16 06:32:22 --> Final output sent to browser
DEBUG - 2011-05-16 06:32:22 --> Total execution time: 1.4063
DEBUG - 2011-05-16 08:57:00 --> Config Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Hooks Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Utf8 Class Initialized
DEBUG - 2011-05-16 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 08:57:00 --> URI Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Router Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Output Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Input Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 08:57:00 --> Language Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Loader Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Controller Class Initialized
ERROR - 2011-05-16 08:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 08:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 08:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 08:57:00 --> Model Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Model Class Initialized
DEBUG - 2011-05-16 08:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 08:57:00 --> Database Driver Class Initialized
DEBUG - 2011-05-16 08:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 08:57:00 --> Helper loaded: url_helper
DEBUG - 2011-05-16 08:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 08:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 08:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 08:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 08:57:00 --> Final output sent to browser
DEBUG - 2011-05-16 08:57:00 --> Total execution time: 0.3620
DEBUG - 2011-05-16 08:57:01 --> Config Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Hooks Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Utf8 Class Initialized
DEBUG - 2011-05-16 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 08:57:01 --> URI Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Router Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Output Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Input Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 08:57:01 --> Language Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Loader Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Controller Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Model Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Model Class Initialized
DEBUG - 2011-05-16 08:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 08:57:01 --> Database Driver Class Initialized
DEBUG - 2011-05-16 08:57:02 --> Final output sent to browser
DEBUG - 2011-05-16 08:57:02 --> Total execution time: 0.9114
DEBUG - 2011-05-16 09:09:56 --> Config Class Initialized
DEBUG - 2011-05-16 09:09:56 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:09:56 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:09:56 --> URI Class Initialized
DEBUG - 2011-05-16 09:09:56 --> Router Class Initialized
ERROR - 2011-05-16 09:09:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-16 09:10:11 --> Config Class Initialized
DEBUG - 2011-05-16 09:10:11 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:10:11 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:10:11 --> URI Class Initialized
DEBUG - 2011-05-16 09:10:11 --> Router Class Initialized
DEBUG - 2011-05-16 09:10:11 --> Output Class Initialized
DEBUG - 2011-05-16 09:10:11 --> Input Class Initialized
DEBUG - 2011-05-16 09:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:10:12 --> Language Class Initialized
DEBUG - 2011-05-16 09:10:12 --> Loader Class Initialized
DEBUG - 2011-05-16 09:10:13 --> Controller Class Initialized
DEBUG - 2011-05-16 09:10:13 --> Model Class Initialized
DEBUG - 2011-05-16 09:10:13 --> Model Class Initialized
DEBUG - 2011-05-16 09:10:14 --> Model Class Initialized
DEBUG - 2011-05-16 09:10:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:10:15 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:10:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:10:31 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:10:31 --> Final output sent to browser
DEBUG - 2011-05-16 09:10:31 --> Total execution time: 20.1540
DEBUG - 2011-05-16 09:32:27 --> Config Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:32:27 --> URI Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Router Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Output Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Input Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:32:27 --> Language Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Loader Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Controller Class Initialized
ERROR - 2011-05-16 09:32:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 09:32:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 09:32:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 09:32:27 --> Model Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Model Class Initialized
DEBUG - 2011-05-16 09:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:32:27 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:32:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 09:32:27 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:32:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:32:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:32:28 --> Final output sent to browser
DEBUG - 2011-05-16 09:32:28 --> Total execution time: 0.6746
DEBUG - 2011-05-16 09:32:29 --> Config Class Initialized
DEBUG - 2011-05-16 09:32:29 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:32:29 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:32:29 --> URI Class Initialized
DEBUG - 2011-05-16 09:32:29 --> Router Class Initialized
DEBUG - 2011-05-16 09:32:29 --> Output Class Initialized
DEBUG - 2011-05-16 09:32:29 --> Input Class Initialized
DEBUG - 2011-05-16 09:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:32:29 --> Language Class Initialized
DEBUG - 2011-05-16 09:32:29 --> Loader Class Initialized
DEBUG - 2011-05-16 09:32:29 --> Controller Class Initialized
DEBUG - 2011-05-16 09:32:30 --> Model Class Initialized
DEBUG - 2011-05-16 09:32:30 --> Model Class Initialized
DEBUG - 2011-05-16 09:32:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:32:30 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:32:31 --> Final output sent to browser
DEBUG - 2011-05-16 09:32:31 --> Total execution time: 1.5209
DEBUG - 2011-05-16 09:32:32 --> Config Class Initialized
DEBUG - 2011-05-16 09:32:32 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:32:32 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:32:32 --> URI Class Initialized
DEBUG - 2011-05-16 09:32:32 --> Router Class Initialized
ERROR - 2011-05-16 09:32:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 09:45:27 --> Config Class Initialized
DEBUG - 2011-05-16 09:45:27 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:45:27 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:45:28 --> URI Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Router Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Output Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Input Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:45:28 --> Language Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Loader Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Controller Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Model Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Model Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Model Class Initialized
DEBUG - 2011-05-16 09:45:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:45:28 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:45:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:45:30 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:45:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:45:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:45:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:45:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:45:30 --> Final output sent to browser
DEBUG - 2011-05-16 09:45:30 --> Total execution time: 2.3187
DEBUG - 2011-05-16 09:45:52 --> Config Class Initialized
DEBUG - 2011-05-16 09:45:52 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:45:52 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:45:52 --> URI Class Initialized
DEBUG - 2011-05-16 09:45:52 --> Router Class Initialized
ERROR - 2011-05-16 09:45:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 09:46:23 --> Config Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:46:23 --> URI Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Router Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Output Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Input Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:46:23 --> Language Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Loader Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Controller Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:46:23 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:46:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:46:24 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:46:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:46:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:46:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:46:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:46:24 --> Final output sent to browser
DEBUG - 2011-05-16 09:46:24 --> Total execution time: 0.5207
DEBUG - 2011-05-16 09:46:26 --> Config Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:46:26 --> URI Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Router Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Output Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Input Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:46:26 --> Language Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Loader Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Controller Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:46:26 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:46:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:46:26 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:46:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:46:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:46:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:46:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:46:26 --> Final output sent to browser
DEBUG - 2011-05-16 09:46:26 --> Total execution time: 0.0466
DEBUG - 2011-05-16 09:46:57 --> Config Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:46:57 --> URI Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Router Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Output Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Input Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:46:57 --> Language Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Loader Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Controller Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:46:57 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:46:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:46:57 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:46:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:46:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:46:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:46:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:46:57 --> Final output sent to browser
DEBUG - 2011-05-16 09:46:57 --> Total execution time: 0.4671
DEBUG - 2011-05-16 09:46:59 --> Config Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:46:59 --> URI Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Router Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Output Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Input Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:46:59 --> Language Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Loader Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Controller Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Model Class Initialized
DEBUG - 2011-05-16 09:46:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:46:59 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:46:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:46:59 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:46:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:46:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:46:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:46:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:46:59 --> Final output sent to browser
DEBUG - 2011-05-16 09:46:59 --> Total execution time: 0.0528
DEBUG - 2011-05-16 09:47:44 --> Config Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:47:44 --> URI Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Router Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Output Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Input Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:47:44 --> Language Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Loader Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Controller Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Model Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Model Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Model Class Initialized
DEBUG - 2011-05-16 09:47:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:47:44 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:47:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:47:44 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:47:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:47:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:47:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:47:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:47:44 --> Final output sent to browser
DEBUG - 2011-05-16 09:47:44 --> Total execution time: 0.3889
DEBUG - 2011-05-16 09:47:47 --> Config Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:47:47 --> URI Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Router Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Output Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Input Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:47:47 --> Language Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Loader Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Controller Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Model Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Model Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Model Class Initialized
DEBUG - 2011-05-16 09:47:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:47:47 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:47:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:47:47 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:47:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:47:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:47:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:47:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:47:47 --> Final output sent to browser
DEBUG - 2011-05-16 09:47:47 --> Total execution time: 0.0548
DEBUG - 2011-05-16 09:48:09 --> Config Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:48:09 --> URI Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Router Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Output Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Input Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:48:09 --> Language Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Loader Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Controller Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Model Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Model Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Model Class Initialized
DEBUG - 2011-05-16 09:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:48:09 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:48:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:48:09 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:48:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:48:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:48:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:48:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:48:09 --> Final output sent to browser
DEBUG - 2011-05-16 09:48:09 --> Total execution time: 0.2879
DEBUG - 2011-05-16 09:48:12 --> Config Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:48:12 --> URI Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Router Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Output Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Input Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:48:12 --> Language Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Loader Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Controller Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Model Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Model Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Model Class Initialized
DEBUG - 2011-05-16 09:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:48:12 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:48:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:48:12 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:48:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:48:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:48:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:48:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:48:12 --> Final output sent to browser
DEBUG - 2011-05-16 09:48:12 --> Total execution time: 0.0444
DEBUG - 2011-05-16 09:48:14 --> Config Class Initialized
DEBUG - 2011-05-16 09:48:14 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:48:14 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:48:14 --> URI Class Initialized
DEBUG - 2011-05-16 09:48:14 --> Router Class Initialized
ERROR - 2011-05-16 09:48:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 09:49:20 --> Config Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:49:20 --> URI Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Router Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Output Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Input Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:49:20 --> Language Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Loader Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Controller Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Model Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Model Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Model Class Initialized
DEBUG - 2011-05-16 09:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:49:20 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:49:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:49:20 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:49:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:49:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:49:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:49:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:49:20 --> Final output sent to browser
DEBUG - 2011-05-16 09:49:20 --> Total execution time: 0.2700
DEBUG - 2011-05-16 09:49:22 --> Config Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:49:22 --> URI Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Router Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Output Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Input Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:49:22 --> Language Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Loader Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Controller Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Model Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Model Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Model Class Initialized
DEBUG - 2011-05-16 09:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 09:49:22 --> Database Driver Class Initialized
DEBUG - 2011-05-16 09:49:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 09:49:22 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:49:22 --> Final output sent to browser
DEBUG - 2011-05-16 09:49:22 --> Total execution time: 0.0432
DEBUG - 2011-05-16 09:49:27 --> Config Class Initialized
DEBUG - 2011-05-16 09:49:27 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:49:27 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:49:27 --> URI Class Initialized
DEBUG - 2011-05-16 09:49:27 --> Router Class Initialized
ERROR - 2011-05-16 09:49:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 09:49:29 --> Config Class Initialized
DEBUG - 2011-05-16 09:49:29 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:49:29 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:49:29 --> URI Class Initialized
DEBUG - 2011-05-16 09:49:29 --> Router Class Initialized
DEBUG - 2011-05-16 09:49:29 --> No URI present. Default controller set.
DEBUG - 2011-05-16 09:49:29 --> Output Class Initialized
DEBUG - 2011-05-16 09:49:29 --> Input Class Initialized
DEBUG - 2011-05-16 09:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 09:49:29 --> Language Class Initialized
DEBUG - 2011-05-16 09:49:29 --> Loader Class Initialized
DEBUG - 2011-05-16 09:49:29 --> Controller Class Initialized
DEBUG - 2011-05-16 09:49:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-16 09:49:29 --> Helper loaded: url_helper
DEBUG - 2011-05-16 09:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 09:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 09:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 09:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 09:49:29 --> Final output sent to browser
DEBUG - 2011-05-16 09:49:29 --> Total execution time: 0.6330
DEBUG - 2011-05-16 09:49:31 --> Config Class Initialized
DEBUG - 2011-05-16 09:49:31 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:49:31 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:49:31 --> URI Class Initialized
DEBUG - 2011-05-16 09:49:31 --> Router Class Initialized
ERROR - 2011-05-16 09:49:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 09:49:33 --> Config Class Initialized
DEBUG - 2011-05-16 09:49:33 --> Hooks Class Initialized
DEBUG - 2011-05-16 09:49:33 --> Utf8 Class Initialized
DEBUG - 2011-05-16 09:49:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 09:49:33 --> URI Class Initialized
DEBUG - 2011-05-16 09:49:33 --> Router Class Initialized
ERROR - 2011-05-16 09:49:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 10:52:01 --> Config Class Initialized
DEBUG - 2011-05-16 10:52:01 --> Hooks Class Initialized
DEBUG - 2011-05-16 10:52:01 --> Utf8 Class Initialized
DEBUG - 2011-05-16 10:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 10:52:01 --> URI Class Initialized
DEBUG - 2011-05-16 10:52:01 --> Router Class Initialized
ERROR - 2011-05-16 10:52:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-16 10:52:39 --> Config Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Hooks Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Utf8 Class Initialized
DEBUG - 2011-05-16 10:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 10:52:39 --> URI Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Router Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Output Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Input Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 10:52:39 --> Language Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Loader Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Controller Class Initialized
ERROR - 2011-05-16 10:52:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 10:52:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 10:52:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 10:52:39 --> Model Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Model Class Initialized
DEBUG - 2011-05-16 10:52:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 10:52:40 --> Database Driver Class Initialized
DEBUG - 2011-05-16 10:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 10:52:40 --> Helper loaded: url_helper
DEBUG - 2011-05-16 10:52:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 10:52:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 10:52:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 10:52:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 10:52:40 --> Final output sent to browser
DEBUG - 2011-05-16 10:52:40 --> Total execution time: 0.6650
DEBUG - 2011-05-16 11:53:05 --> Config Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:53:05 --> URI Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Router Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Output Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Input Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:53:05 --> Language Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Loader Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Controller Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:53:05 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:53:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 11:53:06 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:53:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:53:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:53:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:53:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:53:06 --> Final output sent to browser
DEBUG - 2011-05-16 11:53:06 --> Total execution time: 1.0091
DEBUG - 2011-05-16 11:53:07 --> Config Class Initialized
DEBUG - 2011-05-16 11:53:07 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:53:07 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:53:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:53:07 --> URI Class Initialized
DEBUG - 2011-05-16 11:53:07 --> Router Class Initialized
ERROR - 2011-05-16 11:53:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 11:53:10 --> Config Class Initialized
DEBUG - 2011-05-16 11:53:10 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:53:10 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:53:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:53:10 --> URI Class Initialized
DEBUG - 2011-05-16 11:53:10 --> Router Class Initialized
ERROR - 2011-05-16 11:53:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 11:53:20 --> Config Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:53:20 --> URI Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Router Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Output Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Input Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:53:20 --> Language Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Loader Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Controller Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:53:20 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:53:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 11:53:20 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:53:20 --> Final output sent to browser
DEBUG - 2011-05-16 11:53:20 --> Total execution time: 0.2523
DEBUG - 2011-05-16 11:53:41 --> Config Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:53:41 --> URI Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Router Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Output Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Input Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:53:41 --> Language Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Loader Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Controller Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:53:41 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:53:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 11:53:41 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:53:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:53:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:53:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:53:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:53:41 --> Final output sent to browser
DEBUG - 2011-05-16 11:53:41 --> Total execution time: 0.2311
DEBUG - 2011-05-16 11:53:56 --> Config Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:53:56 --> URI Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Router Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Output Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Input Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:53:56 --> Language Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Loader Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Controller Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Model Class Initialized
DEBUG - 2011-05-16 11:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:53:56 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:53:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 11:53:56 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:53:56 --> Final output sent to browser
DEBUG - 2011-05-16 11:53:56 --> Total execution time: 0.2162
DEBUG - 2011-05-16 11:54:04 --> Config Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:54:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:54:04 --> URI Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Router Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Output Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Input Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:54:04 --> Language Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Loader Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Controller Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Model Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Model Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Model Class Initialized
DEBUG - 2011-05-16 11:54:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:54:04 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:54:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 11:54:04 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:54:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:54:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:54:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:54:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:54:04 --> Final output sent to browser
DEBUG - 2011-05-16 11:54:04 --> Total execution time: 0.3049
DEBUG - 2011-05-16 11:56:01 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:01 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Router Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Output Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Input Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:56:01 --> Language Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Loader Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Controller Class Initialized
ERROR - 2011-05-16 11:56:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 11:56:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 11:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:56:01 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:56:01 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:56:01 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:56:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:56:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:56:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:56:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:56:01 --> Final output sent to browser
DEBUG - 2011-05-16 11:56:01 --> Total execution time: 0.1005
DEBUG - 2011-05-16 11:56:04 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:04 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Router Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Output Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Input Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:56:04 --> Language Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Loader Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Controller Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:56:04 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:56:05 --> Final output sent to browser
DEBUG - 2011-05-16 11:56:05 --> Total execution time: 1.5566
DEBUG - 2011-05-16 11:56:07 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:07 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:07 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:07 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:07 --> Router Class Initialized
ERROR - 2011-05-16 11:56:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 11:56:28 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:28 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Router Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Output Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Input Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:56:28 --> Language Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Loader Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Controller Class Initialized
ERROR - 2011-05-16 11:56:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 11:56:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 11:56:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:56:28 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:56:28 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:56:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:56:28 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:56:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:56:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:56:28 --> Final output sent to browser
DEBUG - 2011-05-16 11:56:28 --> Total execution time: 0.0281
DEBUG - 2011-05-16 11:56:30 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:30 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Router Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Output Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Input Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:56:30 --> Language Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Loader Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Controller Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:56:30 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:56:31 --> Final output sent to browser
DEBUG - 2011-05-16 11:56:31 --> Total execution time: 0.8400
DEBUG - 2011-05-16 11:56:33 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:33 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:33 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:33 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:33 --> Router Class Initialized
ERROR - 2011-05-16 11:56:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 11:56:42 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:42 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Router Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Output Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Input Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:56:42 --> Language Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Loader Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Controller Class Initialized
ERROR - 2011-05-16 11:56:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 11:56:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 11:56:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:56:42 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:56:42 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:56:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:56:42 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:56:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:56:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:56:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:56:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:56:42 --> Final output sent to browser
DEBUG - 2011-05-16 11:56:42 --> Total execution time: 0.0301
DEBUG - 2011-05-16 11:56:44 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:44 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Router Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Output Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Input Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:56:44 --> Language Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Loader Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Controller Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Model Class Initialized
DEBUG - 2011-05-16 11:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:56:44 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:56:45 --> Final output sent to browser
DEBUG - 2011-05-16 11:56:45 --> Total execution time: 1.3509
DEBUG - 2011-05-16 11:56:47 --> Config Class Initialized
DEBUG - 2011-05-16 11:56:47 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:56:47 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:56:47 --> URI Class Initialized
DEBUG - 2011-05-16 11:56:47 --> Router Class Initialized
ERROR - 2011-05-16 11:56:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 11:57:00 --> Config Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:57:00 --> URI Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Router Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Output Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Input Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:57:00 --> Language Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Loader Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Controller Class Initialized
ERROR - 2011-05-16 11:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 11:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 11:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:57:00 --> Model Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Model Class Initialized
DEBUG - 2011-05-16 11:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:57:00 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:57:00 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:57:00 --> Final output sent to browser
DEBUG - 2011-05-16 11:57:00 --> Total execution time: 0.0277
DEBUG - 2011-05-16 11:57:01 --> Config Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:57:01 --> URI Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Router Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Output Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Input Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:57:01 --> Language Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Loader Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Controller Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Model Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Model Class Initialized
DEBUG - 2011-05-16 11:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:57:01 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:57:02 --> Final output sent to browser
DEBUG - 2011-05-16 11:57:02 --> Total execution time: 0.7684
DEBUG - 2011-05-16 11:57:05 --> Config Class Initialized
DEBUG - 2011-05-16 11:57:05 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:57:05 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:57:05 --> URI Class Initialized
DEBUG - 2011-05-16 11:57:05 --> Router Class Initialized
ERROR - 2011-05-16 11:57:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 11:57:12 --> Config Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:57:12 --> URI Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Router Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Output Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Input Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:57:12 --> Language Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Loader Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Controller Class Initialized
ERROR - 2011-05-16 11:57:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 11:57:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 11:57:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:57:12 --> Model Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Model Class Initialized
DEBUG - 2011-05-16 11:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:57:12 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:57:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 11:57:12 --> Helper loaded: url_helper
DEBUG - 2011-05-16 11:57:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 11:57:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 11:57:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 11:57:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 11:57:12 --> Final output sent to browser
DEBUG - 2011-05-16 11:57:12 --> Total execution time: 0.0292
DEBUG - 2011-05-16 11:57:13 --> Config Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:57:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:57:13 --> URI Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Router Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Output Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Input Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 11:57:13 --> Language Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Loader Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Controller Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Model Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Model Class Initialized
DEBUG - 2011-05-16 11:57:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 11:57:13 --> Database Driver Class Initialized
DEBUG - 2011-05-16 11:57:14 --> Final output sent to browser
DEBUG - 2011-05-16 11:57:14 --> Total execution time: 0.6240
DEBUG - 2011-05-16 11:57:16 --> Config Class Initialized
DEBUG - 2011-05-16 11:57:16 --> Hooks Class Initialized
DEBUG - 2011-05-16 11:57:16 --> Utf8 Class Initialized
DEBUG - 2011-05-16 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 11:57:16 --> URI Class Initialized
DEBUG - 2011-05-16 11:57:16 --> Router Class Initialized
ERROR - 2011-05-16 11:57:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 12:01:00 --> Config Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Hooks Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Utf8 Class Initialized
DEBUG - 2011-05-16 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 12:01:00 --> URI Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Router Class Initialized
ERROR - 2011-05-16 12:01:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-16 12:01:00 --> Config Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Hooks Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Utf8 Class Initialized
DEBUG - 2011-05-16 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 12:01:00 --> URI Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Router Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Output Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Input Class Initialized
DEBUG - 2011-05-16 12:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 12:01:01 --> Language Class Initialized
DEBUG - 2011-05-16 12:01:01 --> Loader Class Initialized
DEBUG - 2011-05-16 12:01:01 --> Controller Class Initialized
DEBUG - 2011-05-16 12:01:01 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:01 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:01 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 12:01:01 --> Database Driver Class Initialized
DEBUG - 2011-05-16 12:01:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 12:01:01 --> Helper loaded: url_helper
DEBUG - 2011-05-16 12:01:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 12:01:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 12:01:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 12:01:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 12:01:01 --> Final output sent to browser
DEBUG - 2011-05-16 12:01:01 --> Total execution time: 0.5680
DEBUG - 2011-05-16 12:01:02 --> Config Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Hooks Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Utf8 Class Initialized
DEBUG - 2011-05-16 12:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 12:01:02 --> URI Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Router Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Output Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Input Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 12:01:02 --> Language Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Loader Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Controller Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 12:01:02 --> Database Driver Class Initialized
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 12:01:03 --> Helper loaded: url_helper
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 12:01:03 --> Final output sent to browser
DEBUG - 2011-05-16 12:01:03 --> Total execution time: 0.2659
DEBUG - 2011-05-16 12:01:03 --> Config Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Hooks Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Utf8 Class Initialized
DEBUG - 2011-05-16 12:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 12:01:03 --> URI Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Router Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Output Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Input Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 12:01:03 --> Language Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Loader Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Controller Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 12:01:03 --> Database Driver Class Initialized
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 12:01:03 --> Helper loaded: url_helper
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 12:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 12:01:03 --> Final output sent to browser
DEBUG - 2011-05-16 12:01:03 --> Total execution time: 0.2064
DEBUG - 2011-05-16 12:01:05 --> Config Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Hooks Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Utf8 Class Initialized
DEBUG - 2011-05-16 12:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 12:01:05 --> URI Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Router Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Output Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Input Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 12:01:05 --> Language Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Loader Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Controller Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Model Class Initialized
DEBUG - 2011-05-16 12:01:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 12:01:05 --> Database Driver Class Initialized
DEBUG - 2011-05-16 12:01:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 12:01:05 --> Helper loaded: url_helper
DEBUG - 2011-05-16 12:01:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 12:01:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 12:01:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 12:01:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 12:01:05 --> Final output sent to browser
DEBUG - 2011-05-16 12:01:05 --> Total execution time: 0.0535
DEBUG - 2011-05-16 14:43:38 --> Config Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:43:38 --> URI Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Router Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Output Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Input Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:43:38 --> Language Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Loader Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Controller Class Initialized
ERROR - 2011-05-16 14:43:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:43:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:43:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:43:38 --> Model Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Model Class Initialized
DEBUG - 2011-05-16 14:43:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:43:38 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:43:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:43:38 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:43:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:43:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:43:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:43:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:43:38 --> Final output sent to browser
DEBUG - 2011-05-16 14:43:38 --> Total execution time: 0.4370
DEBUG - 2011-05-16 14:43:39 --> Config Class Initialized
DEBUG - 2011-05-16 14:43:39 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:43:40 --> URI Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Router Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Output Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Input Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:43:40 --> Language Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Loader Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Controller Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Model Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Model Class Initialized
DEBUG - 2011-05-16 14:43:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:43:40 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:43:41 --> Final output sent to browser
DEBUG - 2011-05-16 14:43:41 --> Total execution time: 1.2926
DEBUG - 2011-05-16 14:43:43 --> Config Class Initialized
DEBUG - 2011-05-16 14:43:43 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:43:43 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:43:43 --> URI Class Initialized
DEBUG - 2011-05-16 14:43:43 --> Router Class Initialized
ERROR - 2011-05-16 14:43:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:44:11 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:11 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Router Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Output Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Input Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:44:11 --> Language Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Loader Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Controller Class Initialized
ERROR - 2011-05-16 14:44:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:44:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:44:11 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:44:11 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:44:11 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:44:11 --> Final output sent to browser
DEBUG - 2011-05-16 14:44:11 --> Total execution time: 0.0294
DEBUG - 2011-05-16 14:44:12 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:12 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Router Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Output Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Input Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:44:12 --> Language Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Loader Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Controller Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:44:12 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:13 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Router Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Output Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Input Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:44:13 --> Language Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Loader Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Controller Class Initialized
ERROR - 2011-05-16 14:44:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:44:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:44:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:44:13 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:44:13 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:44:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:44:13 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:44:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:44:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:44:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:44:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:44:13 --> Final output sent to browser
DEBUG - 2011-05-16 14:44:13 --> Total execution time: 0.0295
DEBUG - 2011-05-16 14:44:13 --> Final output sent to browser
DEBUG - 2011-05-16 14:44:13 --> Total execution time: 0.9571
DEBUG - 2011-05-16 14:44:18 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:18 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:18 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:18 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:18 --> Router Class Initialized
ERROR - 2011-05-16 14:44:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:44:19 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:19 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Router Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Output Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Input Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:44:19 --> Language Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Loader Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Controller Class Initialized
ERROR - 2011-05-16 14:44:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:44:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:44:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:44:19 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:44:19 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:44:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:44:19 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:44:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:44:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:44:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:44:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:44:19 --> Final output sent to browser
DEBUG - 2011-05-16 14:44:19 --> Total execution time: 0.0293
DEBUG - 2011-05-16 14:44:20 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:20 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Router Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Output Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Input Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:44:20 --> Language Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Loader Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Controller Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:44:20 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:44:22 --> Final output sent to browser
DEBUG - 2011-05-16 14:44:22 --> Total execution time: 1.5546
DEBUG - 2011-05-16 14:44:24 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:24 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:24 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:24 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:24 --> Router Class Initialized
ERROR - 2011-05-16 14:44:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:44:52 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:52 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Router Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Output Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Input Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:44:52 --> Language Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Loader Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Controller Class Initialized
ERROR - 2011-05-16 14:44:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:44:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:44:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:44:52 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:44:52 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:44:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:44:52 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:44:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:44:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:44:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:44:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:44:52 --> Final output sent to browser
DEBUG - 2011-05-16 14:44:52 --> Total execution time: 0.0410
DEBUG - 2011-05-16 14:44:53 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:53 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Router Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Output Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Input Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:44:53 --> Language Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Loader Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Controller Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Model Class Initialized
DEBUG - 2011-05-16 14:44:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:44:53 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:44:56 --> Final output sent to browser
DEBUG - 2011-05-16 14:44:56 --> Total execution time: 2.5287
DEBUG - 2011-05-16 14:44:57 --> Config Class Initialized
DEBUG - 2011-05-16 14:44:57 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:44:57 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:44:57 --> URI Class Initialized
DEBUG - 2011-05-16 14:44:57 --> Router Class Initialized
ERROR - 2011-05-16 14:44:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:45:07 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:07 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:07 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Controller Class Initialized
ERROR - 2011-05-16 14:45:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:45:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:07 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:07 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:07 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:45:07 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:07 --> Total execution time: 0.1323
DEBUG - 2011-05-16 14:45:17 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:17 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:17 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Controller Class Initialized
ERROR - 2011-05-16 14:45:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:45:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:45:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:17 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:17 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:17 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:45:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:45:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:45:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:45:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:45:17 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:17 --> Total execution time: 0.0354
DEBUG - 2011-05-16 14:45:18 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:18 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:18 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Controller Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:18 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:18 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:18 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Controller Class Initialized
ERROR - 2011-05-16 14:45:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:45:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:45:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:18 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:18 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:18 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:45:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:45:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:45:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:45:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:45:18 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:18 --> Total execution time: 0.1038
DEBUG - 2011-05-16 14:45:20 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:20 --> Total execution time: 1.7196
DEBUG - 2011-05-16 14:45:21 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:21 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:21 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:21 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:21 --> Router Class Initialized
ERROR - 2011-05-16 14:45:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:45:35 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:35 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:35 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Controller Class Initialized
ERROR - 2011-05-16 14:45:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:45:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:45:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:35 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:35 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:35 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:45:35 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:35 --> Total execution time: 0.0291
DEBUG - 2011-05-16 14:45:36 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:36 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:36 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Controller Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:36 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:37 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:37 --> Total execution time: 1.3714
DEBUG - 2011-05-16 14:45:39 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:39 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:39 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Controller Class Initialized
ERROR - 2011-05-16 14:45:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:45:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:45:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:39 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:39 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:39 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:45:39 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:39 --> Total execution time: 0.0306
DEBUG - 2011-05-16 14:45:39 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:39 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:39 --> Router Class Initialized
ERROR - 2011-05-16 14:45:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:45:49 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:49 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:49 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Controller Class Initialized
ERROR - 2011-05-16 14:45:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:45:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:45:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:49 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:49 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:45:49 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:45:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:45:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:45:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:45:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:45:49 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:49 --> Total execution time: 0.0347
DEBUG - 2011-05-16 14:45:49 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:49 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Router Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Output Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Input Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:45:49 --> Language Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Loader Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Controller Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Model Class Initialized
DEBUG - 2011-05-16 14:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:45:49 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:45:50 --> Final output sent to browser
DEBUG - 2011-05-16 14:45:50 --> Total execution time: 0.8649
DEBUG - 2011-05-16 14:45:52 --> Config Class Initialized
DEBUG - 2011-05-16 14:45:52 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:45:52 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:45:52 --> URI Class Initialized
DEBUG - 2011-05-16 14:45:52 --> Router Class Initialized
ERROR - 2011-05-16 14:45:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:46:08 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:08 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:08 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Controller Class Initialized
ERROR - 2011-05-16 14:46:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:46:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:46:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:08 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:08 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:08 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:46:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:46:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:46:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:46:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:46:08 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:08 --> Total execution time: 0.0340
DEBUG - 2011-05-16 14:46:09 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:09 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:09 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Controller Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:09 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:10 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:10 --> Total execution time: 0.7341
DEBUG - 2011-05-16 14:46:12 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:12 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:12 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Controller Class Initialized
ERROR - 2011-05-16 14:46:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:46:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:12 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:12 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:12 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:46:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:46:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:46:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:46:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:46:12 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:12 --> Total execution time: 0.0341
DEBUG - 2011-05-16 14:46:12 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:12 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:12 --> Router Class Initialized
ERROR - 2011-05-16 14:46:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:46:21 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:21 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:21 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Controller Class Initialized
ERROR - 2011-05-16 14:46:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:46:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:46:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:21 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:21 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:21 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:46:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:46:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:46:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:46:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:46:21 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:21 --> Total execution time: 0.0306
DEBUG - 2011-05-16 14:46:22 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:22 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:22 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Controller Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:22 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:22 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:22 --> Total execution time: 0.5928
DEBUG - 2011-05-16 14:46:23 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:23 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:23 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Controller Class Initialized
ERROR - 2011-05-16 14:46:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:46:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:23 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:23 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:23 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:46:23 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:23 --> Total execution time: 0.0288
DEBUG - 2011-05-16 14:46:24 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:24 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:24 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:24 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:24 --> Router Class Initialized
ERROR - 2011-05-16 14:46:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:46:41 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:41 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:41 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Controller Class Initialized
ERROR - 2011-05-16 14:46:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:46:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:41 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:41 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:41 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:46:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:46:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:46:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:46:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:46:41 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:41 --> Total execution time: 0.0411
DEBUG - 2011-05-16 14:46:42 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:42 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:42 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Controller Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:42 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:43 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:43 --> Total execution time: 0.8289
DEBUG - 2011-05-16 14:46:46 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:46 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:46 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:46 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:46 --> Router Class Initialized
ERROR - 2011-05-16 14:46:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:46:57 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:57 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:57 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Controller Class Initialized
ERROR - 2011-05-16 14:46:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:46:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:46:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:57 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:57 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:46:57 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:46:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:46:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:46:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:46:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:46:57 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:57 --> Total execution time: 0.0300
DEBUG - 2011-05-16 14:46:58 --> Config Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:46:58 --> URI Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Router Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Output Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Input Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:46:58 --> Language Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Loader Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Controller Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Model Class Initialized
DEBUG - 2011-05-16 14:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:46:58 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:46:59 --> Final output sent to browser
DEBUG - 2011-05-16 14:46:59 --> Total execution time: 0.8960
DEBUG - 2011-05-16 14:47:03 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:03 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:03 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:03 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:03 --> Router Class Initialized
ERROR - 2011-05-16 14:47:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:47:16 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:16 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Router Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Output Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Input Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:47:16 --> Language Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Loader Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Controller Class Initialized
ERROR - 2011-05-16 14:47:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:47:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:47:16 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:47:16 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:47:16 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:47:16 --> Final output sent to browser
DEBUG - 2011-05-16 14:47:16 --> Total execution time: 0.0414
DEBUG - 2011-05-16 14:47:17 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:17 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Router Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Output Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Input Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:47:17 --> Language Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Loader Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Controller Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:47:17 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:47:18 --> Final output sent to browser
DEBUG - 2011-05-16 14:47:18 --> Total execution time: 1.0858
DEBUG - 2011-05-16 14:47:21 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:21 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:21 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:21 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:21 --> Router Class Initialized
ERROR - 2011-05-16 14:47:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:47:36 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:36 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Router Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Output Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Input Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:47:36 --> Language Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Loader Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Controller Class Initialized
ERROR - 2011-05-16 14:47:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:47:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:47:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:47:36 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:47:36 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:47:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:47:36 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:47:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:47:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:47:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:47:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:47:36 --> Final output sent to browser
DEBUG - 2011-05-16 14:47:36 --> Total execution time: 0.1335
DEBUG - 2011-05-16 14:47:37 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:37 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Router Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Output Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Input Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:47:37 --> Language Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Loader Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Controller Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:47:37 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:47:38 --> Final output sent to browser
DEBUG - 2011-05-16 14:47:38 --> Total execution time: 0.5773
DEBUG - 2011-05-16 14:47:40 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:40 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:40 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:40 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:40 --> Router Class Initialized
ERROR - 2011-05-16 14:47:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:47:55 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:55 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Router Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Output Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Input Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:47:55 --> Language Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Loader Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Controller Class Initialized
ERROR - 2011-05-16 14:47:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:47:55 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:47:55 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:47:55 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:47:55 --> Final output sent to browser
DEBUG - 2011-05-16 14:47:55 --> Total execution time: 0.0653
DEBUG - 2011-05-16 14:47:56 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:56 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Router Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Output Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Input Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:47:56 --> Language Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Loader Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Controller Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Model Class Initialized
DEBUG - 2011-05-16 14:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:47:56 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:47:57 --> Final output sent to browser
DEBUG - 2011-05-16 14:47:57 --> Total execution time: 0.8715
DEBUG - 2011-05-16 14:47:58 --> Config Class Initialized
DEBUG - 2011-05-16 14:47:58 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:47:58 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:47:58 --> URI Class Initialized
DEBUG - 2011-05-16 14:47:58 --> Router Class Initialized
ERROR - 2011-05-16 14:47:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:48:06 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:06 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:06 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Controller Class Initialized
ERROR - 2011-05-16 14:48:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:48:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:06 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:06 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:06 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:48:06 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:06 --> Total execution time: 0.0667
DEBUG - 2011-05-16 14:48:07 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:07 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:07 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Controller Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:07 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:08 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:08 --> Total execution time: 0.6583
DEBUG - 2011-05-16 14:48:09 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:09 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:09 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:09 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:09 --> Router Class Initialized
ERROR - 2011-05-16 14:48:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:48:17 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:17 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:17 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Controller Class Initialized
ERROR - 2011-05-16 14:48:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:48:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:48:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:17 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:17 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:17 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:48:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:48:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:48:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:48:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:48:17 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:17 --> Total execution time: 0.0305
DEBUG - 2011-05-16 14:48:18 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:18 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:18 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Controller Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:18 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:19 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:19 --> Total execution time: 0.7170
DEBUG - 2011-05-16 14:48:22 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:22 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:22 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:22 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:22 --> Router Class Initialized
ERROR - 2011-05-16 14:48:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:48:27 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:27 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:27 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Controller Class Initialized
ERROR - 2011-05-16 14:48:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:48:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:48:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:27 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:27 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:27 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:48:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:48:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:48:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:48:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:48:27 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:27 --> Total execution time: 0.0308
DEBUG - 2011-05-16 14:48:28 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:28 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:28 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Controller Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:28 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:29 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:29 --> Total execution time: 0.7466
DEBUG - 2011-05-16 14:48:33 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:33 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:33 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:33 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:33 --> Router Class Initialized
ERROR - 2011-05-16 14:48:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:48:38 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:38 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:38 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Controller Class Initialized
ERROR - 2011-05-16 14:48:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:48:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:48:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:38 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:38 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:38 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:48:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:48:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:48:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:48:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:48:38 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:38 --> Total execution time: 0.0552
DEBUG - 2011-05-16 14:48:39 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:39 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:39 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Controller Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:39 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:39 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:39 --> Total execution time: 0.7196
DEBUG - 2011-05-16 14:48:42 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:42 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:42 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:42 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:42 --> Router Class Initialized
ERROR - 2011-05-16 14:48:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:48:47 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:47 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:47 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Controller Class Initialized
ERROR - 2011-05-16 14:48:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:48:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:47 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:47 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:47 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:48:47 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:47 --> Total execution time: 0.0435
DEBUG - 2011-05-16 14:48:48 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:48 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:48 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Controller Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:48 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:49 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:49 --> Total execution time: 0.7232
DEBUG - 2011-05-16 14:48:51 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:51 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:51 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:51 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:51 --> Router Class Initialized
ERROR - 2011-05-16 14:48:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 14:48:59 --> Config Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:48:59 --> URI Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Router Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Output Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Input Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:48:59 --> Language Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Loader Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Controller Class Initialized
ERROR - 2011-05-16 14:48:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 14:48:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 14:48:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:59 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Model Class Initialized
DEBUG - 2011-05-16 14:48:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:48:59 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:48:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 14:48:59 --> Helper loaded: url_helper
DEBUG - 2011-05-16 14:48:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 14:48:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 14:48:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 14:48:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 14:48:59 --> Final output sent to browser
DEBUG - 2011-05-16 14:48:59 --> Total execution time: 0.0308
DEBUG - 2011-05-16 14:49:00 --> Config Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:49:00 --> URI Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Router Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Output Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Input Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 14:49:00 --> Language Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Loader Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Controller Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Model Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Model Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 14:49:00 --> Database Driver Class Initialized
DEBUG - 2011-05-16 14:49:00 --> Final output sent to browser
DEBUG - 2011-05-16 14:49:00 --> Total execution time: 0.5021
DEBUG - 2011-05-16 14:49:04 --> Config Class Initialized
DEBUG - 2011-05-16 14:49:04 --> Hooks Class Initialized
DEBUG - 2011-05-16 14:49:04 --> Utf8 Class Initialized
DEBUG - 2011-05-16 14:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 14:49:04 --> URI Class Initialized
DEBUG - 2011-05-16 14:49:04 --> Router Class Initialized
ERROR - 2011-05-16 14:49:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 16:30:25 --> Config Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Hooks Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Utf8 Class Initialized
DEBUG - 2011-05-16 16:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 16:30:25 --> URI Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Router Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Output Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Input Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 16:30:25 --> Language Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Loader Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Controller Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Model Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Model Class Initialized
DEBUG - 2011-05-16 16:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 16:30:25 --> Database Driver Class Initialized
DEBUG - 2011-05-16 16:30:26 --> Final output sent to browser
DEBUG - 2011-05-16 16:30:26 --> Total execution time: 1.2530
DEBUG - 2011-05-16 16:43:49 --> Config Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Hooks Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Utf8 Class Initialized
DEBUG - 2011-05-16 16:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 16:43:49 --> URI Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Router Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Output Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Input Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 16:43:49 --> Language Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Loader Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Controller Class Initialized
ERROR - 2011-05-16 16:43:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-16 16:43:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-16 16:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 16:43:49 --> Model Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Model Class Initialized
DEBUG - 2011-05-16 16:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 16:43:49 --> Database Driver Class Initialized
DEBUG - 2011-05-16 16:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-16 16:43:50 --> Helper loaded: url_helper
DEBUG - 2011-05-16 16:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 16:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 16:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 16:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 16:43:50 --> Final output sent to browser
DEBUG - 2011-05-16 16:43:50 --> Total execution time: 0.4941
DEBUG - 2011-05-16 16:43:50 --> Config Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Hooks Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Utf8 Class Initialized
DEBUG - 2011-05-16 16:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 16:43:50 --> URI Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Router Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Output Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Input Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 16:43:50 --> Language Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Loader Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Controller Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Model Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Model Class Initialized
DEBUG - 2011-05-16 16:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 16:43:50 --> Database Driver Class Initialized
DEBUG - 2011-05-16 16:43:51 --> Final output sent to browser
DEBUG - 2011-05-16 16:43:51 --> Total execution time: 0.7464
DEBUG - 2011-05-16 16:43:58 --> Config Class Initialized
DEBUG - 2011-05-16 16:43:58 --> Hooks Class Initialized
DEBUG - 2011-05-16 16:43:58 --> Utf8 Class Initialized
DEBUG - 2011-05-16 16:43:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 16:43:58 --> URI Class Initialized
DEBUG - 2011-05-16 16:43:58 --> Router Class Initialized
ERROR - 2011-05-16 16:43:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 16:43:58 --> Config Class Initialized
DEBUG - 2011-05-16 16:43:58 --> Hooks Class Initialized
DEBUG - 2011-05-16 16:43:58 --> Utf8 Class Initialized
DEBUG - 2011-05-16 16:43:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 16:43:58 --> URI Class Initialized
DEBUG - 2011-05-16 16:43:58 --> Router Class Initialized
ERROR - 2011-05-16 16:43:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 19:19:14 --> Config Class Initialized
DEBUG - 2011-05-16 19:19:14 --> Hooks Class Initialized
DEBUG - 2011-05-16 19:19:14 --> Utf8 Class Initialized
DEBUG - 2011-05-16 19:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 19:19:14 --> URI Class Initialized
DEBUG - 2011-05-16 19:19:14 --> Router Class Initialized
DEBUG - 2011-05-16 19:19:14 --> No URI present. Default controller set.
DEBUG - 2011-05-16 19:19:14 --> Output Class Initialized
DEBUG - 2011-05-16 19:19:14 --> Input Class Initialized
DEBUG - 2011-05-16 19:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 19:19:14 --> Language Class Initialized
DEBUG - 2011-05-16 19:19:15 --> Loader Class Initialized
DEBUG - 2011-05-16 19:19:15 --> Controller Class Initialized
DEBUG - 2011-05-16 19:19:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-16 19:19:15 --> Helper loaded: url_helper
DEBUG - 2011-05-16 19:19:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 19:19:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 19:19:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 19:19:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 19:19:15 --> Final output sent to browser
DEBUG - 2011-05-16 19:19:15 --> Total execution time: 0.3541
DEBUG - 2011-05-16 23:30:30 --> Config Class Initialized
DEBUG - 2011-05-16 23:30:30 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:30:30 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:30:30 --> URI Class Initialized
DEBUG - 2011-05-16 23:30:30 --> Router Class Initialized
DEBUG - 2011-05-16 23:30:30 --> Output Class Initialized
DEBUG - 2011-05-16 23:30:30 --> Input Class Initialized
DEBUG - 2011-05-16 23:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:30:30 --> Language Class Initialized
DEBUG - 2011-05-16 23:30:30 --> Loader Class Initialized
DEBUG - 2011-05-16 23:30:31 --> Controller Class Initialized
DEBUG - 2011-05-16 23:30:31 --> Model Class Initialized
DEBUG - 2011-05-16 23:30:31 --> Model Class Initialized
DEBUG - 2011-05-16 23:30:31 --> Model Class Initialized
DEBUG - 2011-05-16 23:30:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:30:31 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:30:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:30:31 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:30:31 --> Final output sent to browser
DEBUG - 2011-05-16 23:30:31 --> Total execution time: 0.6899
DEBUG - 2011-05-16 23:55:02 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:02 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Router Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Output Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Input Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:55:02 --> Language Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Loader Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Controller Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:55:02 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:55:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:55:03 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:55:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:55:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:55:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:55:03 --> Final output sent to browser
DEBUG - 2011-05-16 23:55:03 --> Total execution time: 0.9881
DEBUG - 2011-05-16 23:55:05 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:05 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:05 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:05 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:05 --> Router Class Initialized
ERROR - 2011-05-16 23:55:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 23:55:06 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:06 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:06 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:06 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:06 --> Router Class Initialized
ERROR - 2011-05-16 23:55:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 23:55:06 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:06 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:06 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:06 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:06 --> Router Class Initialized
ERROR - 2011-05-16 23:55:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-16 23:55:10 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:10 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Router Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Output Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Input Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:55:10 --> Language Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Loader Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Controller Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:55:10 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:55:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:55:11 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:55:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:55:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:55:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:55:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:55:11 --> Final output sent to browser
DEBUG - 2011-05-16 23:55:11 --> Total execution time: 0.4324
DEBUG - 2011-05-16 23:55:13 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:13 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Router Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Output Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Input Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:55:13 --> Language Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Loader Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Controller Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:55:13 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:55:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:55:13 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:55:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:55:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:55:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:55:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:55:13 --> Final output sent to browser
DEBUG - 2011-05-16 23:55:13 --> Total execution time: 0.0467
DEBUG - 2011-05-16 23:55:22 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:22 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Router Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Output Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Input Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:55:22 --> Language Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Loader Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Controller Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:55:22 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:55:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:55:22 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:55:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:55:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:55:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:55:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:55:22 --> Final output sent to browser
DEBUG - 2011-05-16 23:55:22 --> Total execution time: 0.2109
DEBUG - 2011-05-16 23:55:26 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:26 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Router Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Output Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Input Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:55:26 --> Language Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Loader Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Controller Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:55:26 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:55:26 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:55:26 --> Final output sent to browser
DEBUG - 2011-05-16 23:55:26 --> Total execution time: 0.1249
DEBUG - 2011-05-16 23:55:33 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:33 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Router Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Output Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Input Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:55:33 --> Language Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Loader Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Controller Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:55:33 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:55:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:55:33 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:55:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:55:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:55:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:55:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:55:33 --> Final output sent to browser
DEBUG - 2011-05-16 23:55:33 --> Total execution time: 0.2519
DEBUG - 2011-05-16 23:55:51 --> Config Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:55:51 --> URI Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Router Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Output Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Input Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:55:51 --> Language Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Loader Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Controller Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Model Class Initialized
DEBUG - 2011-05-16 23:55:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:55:51 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:55:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:55:51 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:55:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:55:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:55:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:55:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:55:51 --> Final output sent to browser
DEBUG - 2011-05-16 23:55:51 --> Total execution time: 0.2474
DEBUG - 2011-05-16 23:56:04 --> Config Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:56:04 --> URI Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Router Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Output Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Input Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:56:04 --> Language Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Loader Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Controller Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:56:04 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:56:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:56:05 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:56:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:56:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:56:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:56:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:56:05 --> Final output sent to browser
DEBUG - 2011-05-16 23:56:05 --> Total execution time: 0.3719
DEBUG - 2011-05-16 23:56:14 --> Config Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:56:14 --> URI Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Router Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Output Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Input Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:56:14 --> Language Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Loader Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Controller Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:56:14 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:56:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:56:15 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:56:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:56:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:56:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:56:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:56:15 --> Final output sent to browser
DEBUG - 2011-05-16 23:56:15 --> Total execution time: 0.4276
DEBUG - 2011-05-16 23:56:16 --> Config Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Hooks Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Utf8 Class Initialized
DEBUG - 2011-05-16 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-16 23:56:16 --> URI Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Router Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Output Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Input Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-16 23:56:16 --> Language Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Loader Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Controller Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Model Class Initialized
DEBUG - 2011-05-16 23:56:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-16 23:56:16 --> Database Driver Class Initialized
DEBUG - 2011-05-16 23:56:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-16 23:56:16 --> Helper loaded: url_helper
DEBUG - 2011-05-16 23:56:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-16 23:56:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-16 23:56:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-16 23:56:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-16 23:56:16 --> Final output sent to browser
DEBUG - 2011-05-16 23:56:16 --> Total execution time: 0.0466

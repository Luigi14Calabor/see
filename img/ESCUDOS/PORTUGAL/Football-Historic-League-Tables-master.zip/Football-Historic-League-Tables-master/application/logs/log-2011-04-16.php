<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-16 00:16:38 --> Config Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Hooks Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Utf8 Class Initialized
DEBUG - 2011-04-16 00:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 00:16:38 --> URI Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Router Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Output Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Input Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 00:16:38 --> Language Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Loader Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Controller Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Model Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Model Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Model Class Initialized
DEBUG - 2011-04-16 00:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 00:16:38 --> Database Driver Class Initialized
DEBUG - 2011-04-16 00:16:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 00:16:38 --> Helper loaded: url_helper
DEBUG - 2011-04-16 00:16:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 00:16:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 00:16:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 00:16:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 00:16:38 --> Final output sent to browser
DEBUG - 2011-04-16 00:16:38 --> Total execution time: 0.4194
DEBUG - 2011-04-16 00:16:40 --> Config Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 00:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 00:16:40 --> URI Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Router Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Output Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Input Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 00:16:40 --> Language Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Loader Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Controller Class Initialized
ERROR - 2011-04-16 00:16:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 00:16:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 00:16:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 00:16:40 --> Model Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Model Class Initialized
DEBUG - 2011-04-16 00:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 00:16:40 --> Database Driver Class Initialized
DEBUG - 2011-04-16 00:16:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 00:16:40 --> Helper loaded: url_helper
DEBUG - 2011-04-16 00:16:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 00:16:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 00:16:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 00:16:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 00:16:40 --> Final output sent to browser
DEBUG - 2011-04-16 00:16:40 --> Total execution time: 0.1725
DEBUG - 2011-04-16 01:38:55 --> Config Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:38:55 --> URI Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Router Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Output Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Input Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:38:55 --> Language Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Loader Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Controller Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Model Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Model Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Model Class Initialized
DEBUG - 2011-04-16 01:38:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:38:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:38:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 01:38:56 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:38:56 --> Final output sent to browser
DEBUG - 2011-04-16 01:38:56 --> Total execution time: 1.0755
DEBUG - 2011-04-16 01:38:58 --> Config Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:38:58 --> URI Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Router Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Output Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Input Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:38:58 --> Language Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Loader Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Controller Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Model Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Model Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Model Class Initialized
DEBUG - 2011-04-16 01:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:38:58 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:38:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 01:38:58 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:38:58 --> Final output sent to browser
DEBUG - 2011-04-16 01:38:58 --> Total execution time: 0.0495
DEBUG - 2011-04-16 01:38:59 --> Config Class Initialized
DEBUG - 2011-04-16 01:38:59 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:38:59 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:38:59 --> URI Class Initialized
DEBUG - 2011-04-16 01:38:59 --> Router Class Initialized
ERROR - 2011-04-16 01:38:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 01:39:07 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:07 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:07 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Controller Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 01:39:26 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:39:26 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:26 --> Total execution time: 18.9479
DEBUG - 2011-04-16 01:39:26 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:26 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:26 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Controller Class Initialized
ERROR - 2011-04-16 01:39:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:26 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:26 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:26 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:39:26 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:26 --> Total execution time: 0.1176
DEBUG - 2011-04-16 01:39:28 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:28 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:28 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Controller Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:28 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:29 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:29 --> Total execution time: 1.1478
DEBUG - 2011-04-16 01:39:36 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:36 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:36 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Controller Class Initialized
ERROR - 2011-04-16 01:39:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:39:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:39:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:36 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:36 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:36 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:39:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:39:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:39:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:39:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:39:36 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:36 --> Total execution time: 0.0418
DEBUG - 2011-04-16 01:39:37 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:37 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:37 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Controller Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:37 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:37 --> Total execution time: 0.7418
DEBUG - 2011-04-16 01:39:40 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:40 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:40 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Controller Class Initialized
ERROR - 2011-04-16 01:39:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:39:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:40 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:40 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:40 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:39:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:39:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:39:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:39:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:39:40 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:40 --> Total execution time: 0.0358
DEBUG - 2011-04-16 01:39:41 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:41 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:41 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Controller Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:41 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:41 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:41 --> Total execution time: 0.5794
DEBUG - 2011-04-16 01:39:45 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:45 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:45 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Controller Class Initialized
ERROR - 2011-04-16 01:39:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:39:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:45 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:45 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:45 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:39:45 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:45 --> Total execution time: 0.0333
DEBUG - 2011-04-16 01:39:45 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:45 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:45 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Controller Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:45 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:46 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:46 --> Total execution time: 0.8625
DEBUG - 2011-04-16 01:39:50 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:50 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:50 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Controller Class Initialized
ERROR - 2011-04-16 01:39:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:39:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:39:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:50 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:50 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:39:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:39:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:39:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:39:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:39:50 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:50 --> Total execution time: 0.0283
DEBUG - 2011-04-16 01:39:50 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:50 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:50 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Controller Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:51 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:51 --> Total execution time: 0.6146
DEBUG - 2011-04-16 01:39:53 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:53 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:53 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Controller Class Initialized
ERROR - 2011-04-16 01:39:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:39:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:39:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:53 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:53 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:39:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:39:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:39:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:39:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:39:53 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:53 --> Total execution time: 0.0306
DEBUG - 2011-04-16 01:39:54 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:54 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:54 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Controller Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:55 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:55 --> Total execution time: 0.7813
DEBUG - 2011-04-16 01:39:58 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:58 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:58 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Controller Class Initialized
ERROR - 2011-04-16 01:39:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:39:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:39:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:58 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:58 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:39:58 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:39:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:39:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:39:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:39:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:39:58 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:58 --> Total execution time: 0.0414
DEBUG - 2011-04-16 01:39:58 --> Config Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:39:58 --> URI Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Router Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Output Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Input Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:39:58 --> Language Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Loader Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Controller Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Model Class Initialized
DEBUG - 2011-04-16 01:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:39:58 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:39:59 --> Final output sent to browser
DEBUG - 2011-04-16 01:39:59 --> Total execution time: 0.7621
DEBUG - 2011-04-16 01:46:28 --> Config Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:46:28 --> URI Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Router Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Output Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Input Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:46:28 --> Language Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Loader Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Controller Class Initialized
ERROR - 2011-04-16 01:46:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:46:28 --> Model Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Model Class Initialized
DEBUG - 2011-04-16 01:46:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:46:28 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:46:28 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:46:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:46:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:46:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:46:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:46:28 --> Final output sent to browser
DEBUG - 2011-04-16 01:46:28 --> Total execution time: 0.0917
DEBUG - 2011-04-16 01:46:30 --> Config Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:46:30 --> URI Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Router Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Output Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Input Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:46:30 --> Language Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Loader Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Controller Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Model Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Model Class Initialized
DEBUG - 2011-04-16 01:46:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:46:30 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:46:31 --> Final output sent to browser
DEBUG - 2011-04-16 01:46:31 --> Total execution time: 0.5129
DEBUG - 2011-04-16 01:46:32 --> Config Class Initialized
DEBUG - 2011-04-16 01:46:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:46:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:46:32 --> URI Class Initialized
DEBUG - 2011-04-16 01:46:32 --> Router Class Initialized
ERROR - 2011-04-16 01:46:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 01:52:38 --> Config Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:52:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:52:38 --> URI Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Router Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Output Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Input Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:52:38 --> Language Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Loader Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Controller Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Model Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Model Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Model Class Initialized
DEBUG - 2011-04-16 01:52:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:52:38 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:52:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 01:52:39 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:52:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:52:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:52:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:52:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:52:39 --> Final output sent to browser
DEBUG - 2011-04-16 01:52:39 --> Total execution time: 0.3876
DEBUG - 2011-04-16 01:52:42 --> Config Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 01:52:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 01:52:42 --> URI Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Router Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Output Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Input Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 01:52:42 --> Language Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Loader Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Controller Class Initialized
ERROR - 2011-04-16 01:52:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 01:52:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 01:52:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:52:42 --> Model Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Model Class Initialized
DEBUG - 2011-04-16 01:52:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 01:52:42 --> Database Driver Class Initialized
DEBUG - 2011-04-16 01:52:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 01:52:42 --> Helper loaded: url_helper
DEBUG - 2011-04-16 01:52:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 01:52:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 01:52:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 01:52:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 01:52:42 --> Final output sent to browser
DEBUG - 2011-04-16 01:52:42 --> Total execution time: 0.0368
DEBUG - 2011-04-16 02:27:33 --> Config Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:27:33 --> URI Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Router Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Output Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Input Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:27:33 --> Language Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Loader Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Controller Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:27:33 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Config Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:27:37 --> URI Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Router Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Output Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Input Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:27:37 --> Language Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Loader Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Controller Class Initialized
ERROR - 2011-04-16 02:27:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:27:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:27:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:27:37 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:27:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:27:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:27:38 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:27:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:27:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:27:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:27:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:27:38 --> Final output sent to browser
DEBUG - 2011-04-16 02:27:38 --> Total execution time: 0.6269
DEBUG - 2011-04-16 02:27:39 --> Config Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:27:39 --> URI Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Router Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Output Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Input Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:27:39 --> Language Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Loader Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Controller Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:27:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:27:41 --> Final output sent to browser
DEBUG - 2011-04-16 02:27:41 --> Total execution time: 2.2713
DEBUG - 2011-04-16 02:27:43 --> Config Class Initialized
DEBUG - 2011-04-16 02:27:43 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:27:43 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:27:43 --> URI Class Initialized
DEBUG - 2011-04-16 02:27:43 --> Router Class Initialized
ERROR - 2011-04-16 02:27:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 02:27:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 02:27:45 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:27:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:27:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:27:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:27:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:27:45 --> Final output sent to browser
DEBUG - 2011-04-16 02:27:45 --> Total execution time: 11.8095
DEBUG - 2011-04-16 02:27:54 --> Config Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:27:54 --> URI Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Router Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Output Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Input Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:27:54 --> Language Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Loader Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Controller Class Initialized
ERROR - 2011-04-16 02:27:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:27:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:27:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:27:54 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:27:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:27:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:27:54 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:27:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:27:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:27:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:27:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:27:54 --> Final output sent to browser
DEBUG - 2011-04-16 02:27:54 --> Total execution time: 0.0281
DEBUG - 2011-04-16 02:27:55 --> Config Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:27:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:27:55 --> URI Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Router Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Output Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Input Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:27:55 --> Language Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Loader Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Controller Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Model Class Initialized
DEBUG - 2011-04-16 02:27:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:27:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:27:59 --> Final output sent to browser
DEBUG - 2011-04-16 02:27:59 --> Total execution time: 3.5200
DEBUG - 2011-04-16 02:28:15 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:15 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:15 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Controller Class Initialized
ERROR - 2011-04-16 02:28:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:28:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:28:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:15 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:15 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:15 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:28:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:28:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:28:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:28:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:28:15 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:15 --> Total execution time: 0.0321
DEBUG - 2011-04-16 02:28:16 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:16 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:16 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Controller Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:18 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:18 --> Total execution time: 1.6811
DEBUG - 2011-04-16 02:28:24 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:24 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:24 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Controller Class Initialized
ERROR - 2011-04-16 02:28:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:28:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:28:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:24 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:24 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:24 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:28:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:28:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:28:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:28:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:28:24 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:24 --> Total execution time: 0.0307
DEBUG - 2011-04-16 02:28:25 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:25 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:25 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Controller Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:25 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:28 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:28 --> Total execution time: 3.5010
DEBUG - 2011-04-16 02:28:31 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:31 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:31 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Controller Class Initialized
ERROR - 2011-04-16 02:28:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:28:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:28:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:31 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:31 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:31 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:28:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:28:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:28:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:28:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:28:31 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:31 --> Total execution time: 0.0278
DEBUG - 2011-04-16 02:28:32 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:32 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:32 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Controller Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:33 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:33 --> Total execution time: 0.8705
DEBUG - 2011-04-16 02:28:34 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:34 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Router Class Initialized
ERROR - 2011-04-16 02:28:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 02:28:34 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:34 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Router Class Initialized
ERROR - 2011-04-16 02:28:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 02:28:34 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:34 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:34 --> Router Class Initialized
ERROR - 2011-04-16 02:28:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 02:28:37 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:37 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:37 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Controller Class Initialized
ERROR - 2011-04-16 02:28:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:28:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:28:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:37 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:37 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:28:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:28:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:28:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:28:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:28:37 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:37 --> Total execution time: 0.0334
DEBUG - 2011-04-16 02:28:37 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:37 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:37 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Controller Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:40 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:40 --> Total execution time: 2.8626
DEBUG - 2011-04-16 02:28:51 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:51 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:51 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Controller Class Initialized
ERROR - 2011-04-16 02:28:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:28:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:28:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:51 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:51 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:28:51 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:28:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:28:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:28:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:28:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:28:51 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:51 --> Total execution time: 0.0329
DEBUG - 2011-04-16 02:28:52 --> Config Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:28:52 --> URI Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Router Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Output Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Input Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:28:52 --> Language Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Loader Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Controller Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Model Class Initialized
DEBUG - 2011-04-16 02:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:28:52 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:28:53 --> Final output sent to browser
DEBUG - 2011-04-16 02:28:53 --> Total execution time: 1.3441
DEBUG - 2011-04-16 02:29:03 --> Config Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:29:03 --> URI Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Router Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Output Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Input Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:29:03 --> Language Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Loader Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Controller Class Initialized
ERROR - 2011-04-16 02:29:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:29:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:29:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:29:03 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:29:03 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:29:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:29:03 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:29:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:29:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:29:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:29:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:29:03 --> Final output sent to browser
DEBUG - 2011-04-16 02:29:03 --> Total execution time: 0.0271
DEBUG - 2011-04-16 02:29:03 --> Config Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:29:03 --> URI Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Router Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Output Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Input Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:29:03 --> Language Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Loader Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Controller Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:29:03 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:29:04 --> Final output sent to browser
DEBUG - 2011-04-16 02:29:04 --> Total execution time: 0.6317
DEBUG - 2011-04-16 02:29:06 --> Config Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:29:06 --> URI Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Router Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Output Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Input Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:29:06 --> Language Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Loader Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Controller Class Initialized
ERROR - 2011-04-16 02:29:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:29:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:29:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:29:06 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:29:06 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:29:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:29:06 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:29:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:29:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:29:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:29:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:29:06 --> Final output sent to browser
DEBUG - 2011-04-16 02:29:06 --> Total execution time: 0.0305
DEBUG - 2011-04-16 02:29:07 --> Config Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:29:07 --> URI Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Router Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Output Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Input Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:29:07 --> Language Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Loader Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Controller Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:29:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:29:10 --> Final output sent to browser
DEBUG - 2011-04-16 02:29:10 --> Total execution time: 2.9428
DEBUG - 2011-04-16 02:29:18 --> Config Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:29:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:29:18 --> URI Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Router Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Output Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Input Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:29:18 --> Language Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Loader Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Controller Class Initialized
ERROR - 2011-04-16 02:29:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 02:29:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 02:29:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:29:18 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:29:18 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:29:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 02:29:18 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:29:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:29:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:29:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:29:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:29:18 --> Final output sent to browser
DEBUG - 2011-04-16 02:29:18 --> Total execution time: 0.0280
DEBUG - 2011-04-16 02:29:19 --> Config Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:29:19 --> URI Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Router Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Output Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Input Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:29:19 --> Language Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Loader Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Controller Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Model Class Initialized
DEBUG - 2011-04-16 02:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 02:29:19 --> Database Driver Class Initialized
DEBUG - 2011-04-16 02:29:36 --> Final output sent to browser
DEBUG - 2011-04-16 02:29:36 --> Total execution time: 16.6154
DEBUG - 2011-04-16 02:47:53 --> Config Class Initialized
DEBUG - 2011-04-16 02:47:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:47:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:47:53 --> URI Class Initialized
DEBUG - 2011-04-16 02:47:53 --> Router Class Initialized
DEBUG - 2011-04-16 02:47:53 --> No URI present. Default controller set.
DEBUG - 2011-04-16 02:47:53 --> Output Class Initialized
DEBUG - 2011-04-16 02:47:53 --> Input Class Initialized
DEBUG - 2011-04-16 02:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 02:47:53 --> Language Class Initialized
DEBUG - 2011-04-16 02:47:53 --> Loader Class Initialized
DEBUG - 2011-04-16 02:47:53 --> Controller Class Initialized
DEBUG - 2011-04-16 02:47:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 02:47:53 --> Helper loaded: url_helper
DEBUG - 2011-04-16 02:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 02:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 02:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 02:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 02:47:53 --> Final output sent to browser
DEBUG - 2011-04-16 02:47:53 --> Total execution time: 0.5081
DEBUG - 2011-04-16 02:47:55 --> Config Class Initialized
DEBUG - 2011-04-16 02:47:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:47:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:47:55 --> URI Class Initialized
DEBUG - 2011-04-16 02:47:55 --> Router Class Initialized
ERROR - 2011-04-16 02:47:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 02:47:55 --> Config Class Initialized
DEBUG - 2011-04-16 02:47:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 02:47:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 02:47:55 --> URI Class Initialized
DEBUG - 2011-04-16 02:47:55 --> Router Class Initialized
ERROR - 2011-04-16 02:47:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 03:14:02 --> Config Class Initialized
DEBUG - 2011-04-16 03:14:02 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:14:02 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:14:02 --> URI Class Initialized
DEBUG - 2011-04-16 03:14:02 --> Router Class Initialized
DEBUG - 2011-04-16 03:14:02 --> No URI present. Default controller set.
DEBUG - 2011-04-16 03:14:02 --> Output Class Initialized
DEBUG - 2011-04-16 03:14:02 --> Input Class Initialized
DEBUG - 2011-04-16 03:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:14:02 --> Language Class Initialized
DEBUG - 2011-04-16 03:14:02 --> Loader Class Initialized
DEBUG - 2011-04-16 03:14:02 --> Controller Class Initialized
DEBUG - 2011-04-16 03:14:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 03:14:03 --> Helper loaded: url_helper
DEBUG - 2011-04-16 03:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 03:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 03:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 03:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 03:14:03 --> Final output sent to browser
DEBUG - 2011-04-16 03:14:03 --> Total execution time: 0.3136
DEBUG - 2011-04-16 03:25:47 --> Config Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:25:47 --> URI Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Router Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Output Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Input Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:25:47 --> Language Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Loader Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Controller Class Initialized
ERROR - 2011-04-16 03:25:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 03:25:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 03:25:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:25:47 --> Model Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Model Class Initialized
DEBUG - 2011-04-16 03:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:25:48 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:25:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:25:48 --> Helper loaded: url_helper
DEBUG - 2011-04-16 03:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 03:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 03:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 03:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 03:25:48 --> Final output sent to browser
DEBUG - 2011-04-16 03:25:48 --> Total execution time: 0.3369
DEBUG - 2011-04-16 03:28:19 --> Config Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:28:19 --> URI Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Router Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Output Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Input Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:28:19 --> Language Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Loader Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Controller Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Model Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Model Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Model Class Initialized
DEBUG - 2011-04-16 03:28:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:28:19 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:28:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 03:28:24 --> Helper loaded: url_helper
DEBUG - 2011-04-16 03:28:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 03:28:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 03:28:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 03:28:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 03:28:24 --> Final output sent to browser
DEBUG - 2011-04-16 03:28:24 --> Total execution time: 5.3053
DEBUG - 2011-04-16 03:28:26 --> Config Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:28:26 --> URI Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Router Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Output Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Input Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:28:26 --> Language Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Loader Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Controller Class Initialized
ERROR - 2011-04-16 03:28:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 03:28:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 03:28:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:28:26 --> Model Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Model Class Initialized
DEBUG - 2011-04-16 03:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:28:26 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:28:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:28:26 --> Helper loaded: url_helper
DEBUG - 2011-04-16 03:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 03:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 03:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 03:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 03:28:26 --> Final output sent to browser
DEBUG - 2011-04-16 03:28:26 --> Total execution time: 0.0549
DEBUG - 2011-04-16 03:31:21 --> Config Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:31:21 --> URI Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Router Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Output Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Input Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:31:21 --> Language Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Loader Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Controller Class Initialized
ERROR - 2011-04-16 03:31:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 03:31:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 03:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:31:21 --> Model Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Model Class Initialized
DEBUG - 2011-04-16 03:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:31:21 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:31:21 --> Helper loaded: url_helper
DEBUG - 2011-04-16 03:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 03:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 03:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 03:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 03:31:21 --> Final output sent to browser
DEBUG - 2011-04-16 03:31:21 --> Total execution time: 0.0345
DEBUG - 2011-04-16 03:31:22 --> Config Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:31:22 --> URI Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Router Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Output Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Input Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:31:22 --> Language Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Loader Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Controller Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Model Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Model Class Initialized
DEBUG - 2011-04-16 03:31:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:31:22 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:31:24 --> Final output sent to browser
DEBUG - 2011-04-16 03:31:24 --> Total execution time: 2.2719
DEBUG - 2011-04-16 03:31:25 --> Config Class Initialized
DEBUG - 2011-04-16 03:31:25 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:31:25 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:31:25 --> URI Class Initialized
DEBUG - 2011-04-16 03:31:25 --> Router Class Initialized
ERROR - 2011-04-16 03:31:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 03:31:52 --> Config Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:31:52 --> URI Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Router Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Output Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Input Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:31:52 --> Language Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Loader Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Controller Class Initialized
ERROR - 2011-04-16 03:31:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 03:31:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 03:31:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:31:52 --> Model Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Model Class Initialized
DEBUG - 2011-04-16 03:31:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:31:52 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:31:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:31:52 --> Helper loaded: url_helper
DEBUG - 2011-04-16 03:31:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 03:31:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 03:31:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 03:31:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 03:31:52 --> Final output sent to browser
DEBUG - 2011-04-16 03:31:52 --> Total execution time: 0.1843
DEBUG - 2011-04-16 03:31:53 --> Config Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:31:53 --> URI Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Router Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Output Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Input Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:31:53 --> Language Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Loader Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Controller Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Model Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Model Class Initialized
DEBUG - 2011-04-16 03:31:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:31:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:31:56 --> Final output sent to browser
DEBUG - 2011-04-16 03:31:56 --> Total execution time: 3.1060
DEBUG - 2011-04-16 03:31:57 --> Config Class Initialized
DEBUG - 2011-04-16 03:31:57 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:31:57 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:31:57 --> URI Class Initialized
DEBUG - 2011-04-16 03:31:57 --> Router Class Initialized
ERROR - 2011-04-16 03:31:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 03:32:11 --> Config Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:32:11 --> URI Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Router Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Output Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Input Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:32:11 --> Language Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Loader Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Controller Class Initialized
ERROR - 2011-04-16 03:32:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 03:32:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 03:32:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:32:11 --> Model Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Model Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:32:11 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:32:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 03:32:11 --> Helper loaded: url_helper
DEBUG - 2011-04-16 03:32:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 03:32:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 03:32:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 03:32:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 03:32:11 --> Final output sent to browser
DEBUG - 2011-04-16 03:32:11 --> Total execution time: 0.0367
DEBUG - 2011-04-16 03:32:11 --> Config Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:32:11 --> URI Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Router Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Output Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Input Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 03:32:11 --> Language Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Loader Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Controller Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Model Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Model Class Initialized
DEBUG - 2011-04-16 03:32:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 03:32:11 --> Database Driver Class Initialized
DEBUG - 2011-04-16 03:32:12 --> Final output sent to browser
DEBUG - 2011-04-16 03:32:12 --> Total execution time: 0.8022
DEBUG - 2011-04-16 03:32:13 --> Config Class Initialized
DEBUG - 2011-04-16 03:32:13 --> Hooks Class Initialized
DEBUG - 2011-04-16 03:32:13 --> Utf8 Class Initialized
DEBUG - 2011-04-16 03:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 03:32:13 --> URI Class Initialized
DEBUG - 2011-04-16 03:32:13 --> Router Class Initialized
ERROR - 2011-04-16 03:32:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 05:07:17 --> Config Class Initialized
DEBUG - 2011-04-16 05:07:17 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:07:17 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:07:17 --> URI Class Initialized
DEBUG - 2011-04-16 05:07:17 --> Router Class Initialized
DEBUG - 2011-04-16 05:07:17 --> No URI present. Default controller set.
DEBUG - 2011-04-16 05:07:17 --> Output Class Initialized
DEBUG - 2011-04-16 05:07:17 --> Input Class Initialized
DEBUG - 2011-04-16 05:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 05:07:17 --> Language Class Initialized
DEBUG - 2011-04-16 05:07:17 --> Loader Class Initialized
DEBUG - 2011-04-16 05:07:17 --> Controller Class Initialized
DEBUG - 2011-04-16 05:07:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 05:07:17 --> Helper loaded: url_helper
DEBUG - 2011-04-16 05:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 05:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 05:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 05:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 05:07:17 --> Final output sent to browser
DEBUG - 2011-04-16 05:07:17 --> Total execution time: 0.3602
DEBUG - 2011-04-16 05:07:19 --> Config Class Initialized
DEBUG - 2011-04-16 05:07:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:07:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:07:19 --> URI Class Initialized
DEBUG - 2011-04-16 05:07:19 --> Router Class Initialized
ERROR - 2011-04-16 05:07:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 05:07:26 --> Config Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:07:26 --> URI Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Router Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Output Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Input Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 05:07:26 --> Language Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Loader Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Controller Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 05:07:26 --> Database Driver Class Initialized
DEBUG - 2011-04-16 05:07:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 05:07:28 --> Helper loaded: url_helper
DEBUG - 2011-04-16 05:07:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 05:07:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 05:07:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 05:07:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 05:07:28 --> Final output sent to browser
DEBUG - 2011-04-16 05:07:28 --> Total execution time: 2.0446
DEBUG - 2011-04-16 05:07:47 --> Config Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:07:47 --> URI Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Router Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Output Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Input Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 05:07:47 --> Language Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Loader Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Controller Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 05:07:47 --> Database Driver Class Initialized
DEBUG - 2011-04-16 05:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 05:07:47 --> Helper loaded: url_helper
DEBUG - 2011-04-16 05:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 05:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 05:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 05:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 05:07:47 --> Final output sent to browser
DEBUG - 2011-04-16 05:07:47 --> Total execution time: 0.0460
DEBUG - 2011-04-16 05:07:49 --> Config Class Initialized
DEBUG - 2011-04-16 05:07:49 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:07:49 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:07:49 --> URI Class Initialized
DEBUG - 2011-04-16 05:07:49 --> Router Class Initialized
ERROR - 2011-04-16 05:07:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-16 05:07:50 --> Config Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:07:50 --> URI Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Router Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Output Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Input Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 05:07:50 --> Language Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Loader Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Controller Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Model Class Initialized
DEBUG - 2011-04-16 05:07:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 05:07:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 05:07:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 05:07:50 --> Helper loaded: url_helper
DEBUG - 2011-04-16 05:07:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 05:07:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 05:07:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 05:07:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 05:07:50 --> Final output sent to browser
DEBUG - 2011-04-16 05:07:50 --> Total execution time: 0.0496
DEBUG - 2011-04-16 05:08:07 --> Config Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:08:07 --> URI Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Router Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Output Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Input Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 05:08:07 --> Language Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Loader Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Controller Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Model Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Model Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Model Class Initialized
DEBUG - 2011-04-16 05:08:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 05:08:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 05:08:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 05:08:07 --> Helper loaded: url_helper
DEBUG - 2011-04-16 05:08:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 05:08:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 05:08:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 05:08:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 05:08:07 --> Final output sent to browser
DEBUG - 2011-04-16 05:08:07 --> Total execution time: 0.1799
DEBUG - 2011-04-16 05:08:08 --> Config Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:08:08 --> URI Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Router Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Output Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Input Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 05:08:08 --> Language Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Loader Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Controller Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Model Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Model Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Model Class Initialized
DEBUG - 2011-04-16 05:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 05:08:08 --> Database Driver Class Initialized
DEBUG - 2011-04-16 05:08:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 05:08:08 --> Helper loaded: url_helper
DEBUG - 2011-04-16 05:08:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 05:08:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 05:08:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 05:08:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 05:08:08 --> Final output sent to browser
DEBUG - 2011-04-16 05:08:08 --> Total execution time: 0.0564
DEBUG - 2011-04-16 05:20:50 --> Config Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:20:50 --> URI Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Router Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Output Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Input Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 05:20:50 --> Language Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Loader Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Controller Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Model Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Model Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Model Class Initialized
DEBUG - 2011-04-16 05:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 05:20:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 05:20:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 05:20:53 --> Helper loaded: url_helper
DEBUG - 2011-04-16 05:20:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 05:20:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 05:20:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 05:20:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 05:20:53 --> Final output sent to browser
DEBUG - 2011-04-16 05:20:53 --> Total execution time: 3.0385
DEBUG - 2011-04-16 05:20:54 --> Config Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 05:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 05:20:54 --> URI Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Router Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Output Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Input Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 05:20:54 --> Language Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Loader Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Controller Class Initialized
ERROR - 2011-04-16 05:20:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 05:20:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 05:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 05:20:54 --> Model Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Model Class Initialized
DEBUG - 2011-04-16 05:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 05:20:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 05:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 05:20:54 --> Helper loaded: url_helper
DEBUG - 2011-04-16 05:20:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 05:20:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 05:20:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 05:20:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 05:20:54 --> Final output sent to browser
DEBUG - 2011-04-16 05:20:54 --> Total execution time: 0.0873
DEBUG - 2011-04-16 06:00:08 --> Config Class Initialized
DEBUG - 2011-04-16 06:00:08 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:00:08 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:00:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:00:08 --> URI Class Initialized
DEBUG - 2011-04-16 06:00:08 --> Router Class Initialized
DEBUG - 2011-04-16 06:00:08 --> No URI present. Default controller set.
DEBUG - 2011-04-16 06:00:08 --> Output Class Initialized
DEBUG - 2011-04-16 06:00:08 --> Input Class Initialized
DEBUG - 2011-04-16 06:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:00:08 --> Language Class Initialized
DEBUG - 2011-04-16 06:00:08 --> Loader Class Initialized
DEBUG - 2011-04-16 06:00:08 --> Controller Class Initialized
DEBUG - 2011-04-16 06:00:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 06:00:08 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:00:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:00:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:00:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:00:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:00:08 --> Final output sent to browser
DEBUG - 2011-04-16 06:00:08 --> Total execution time: 0.2575
DEBUG - 2011-04-16 06:00:12 --> Config Class Initialized
DEBUG - 2011-04-16 06:00:12 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:00:12 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:00:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:00:12 --> URI Class Initialized
DEBUG - 2011-04-16 06:00:12 --> Router Class Initialized
ERROR - 2011-04-16 06:00:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 06:00:30 --> Config Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:00:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:00:30 --> URI Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Router Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Output Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Input Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:00:30 --> Language Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Loader Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Controller Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:00:30 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Config Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:00:32 --> URI Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Router Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Output Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Input Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:00:32 --> Language Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Loader Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Controller Class Initialized
ERROR - 2011-04-16 06:00:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:00:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:00:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:00:32 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:00:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:00:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:00:33 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:00:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:00:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:00:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:00:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:00:33 --> Final output sent to browser
DEBUG - 2011-04-16 06:00:33 --> Total execution time: 0.6287
DEBUG - 2011-04-16 06:00:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 06:00:36 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:00:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:00:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:00:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:00:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:00:36 --> Final output sent to browser
DEBUG - 2011-04-16 06:00:36 --> Total execution time: 6.2933
DEBUG - 2011-04-16 06:00:39 --> Config Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:00:39 --> URI Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Router Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Output Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Input Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:00:39 --> Language Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Loader Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Controller Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:00:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:00:41 --> Final output sent to browser
DEBUG - 2011-04-16 06:00:41 --> Total execution time: 2.2068
DEBUG - 2011-04-16 06:00:53 --> Config Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:00:53 --> URI Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Router Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Output Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Input Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:00:53 --> Language Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Loader Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Controller Class Initialized
ERROR - 2011-04-16 06:00:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:00:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:00:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:00:53 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:00:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:00:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:00:53 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:00:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:00:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:00:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:00:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:00:53 --> Final output sent to browser
DEBUG - 2011-04-16 06:00:53 --> Total execution time: 0.0275
DEBUG - 2011-04-16 06:00:54 --> Config Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:00:54 --> URI Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Router Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Output Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Input Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:00:54 --> Language Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Loader Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Controller Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:00:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:00:55 --> Final output sent to browser
DEBUG - 2011-04-16 06:00:55 --> Total execution time: 1.0837
DEBUG - 2011-04-16 06:00:56 --> Config Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:00:56 --> URI Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Router Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Output Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Input Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:00:56 --> Language Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Loader Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Controller Class Initialized
ERROR - 2011-04-16 06:00:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:00:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:00:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:00:56 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Model Class Initialized
DEBUG - 2011-04-16 06:00:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:00:56 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:00:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:00:56 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:00:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:00:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:00:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:00:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:00:56 --> Final output sent to browser
DEBUG - 2011-04-16 06:00:56 --> Total execution time: 0.0322
DEBUG - 2011-04-16 06:01:57 --> Config Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:01:57 --> URI Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Router Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Output Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Input Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:01:57 --> Language Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Loader Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Controller Class Initialized
ERROR - 2011-04-16 06:01:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:01:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:01:57 --> Model Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Model Class Initialized
DEBUG - 2011-04-16 06:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:01:57 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:01:57 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:01:57 --> Final output sent to browser
DEBUG - 2011-04-16 06:01:57 --> Total execution time: 0.0371
DEBUG - 2011-04-16 06:02:16 --> Config Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:02:16 --> URI Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Router Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Output Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Input Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:02:16 --> Language Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Loader Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Controller Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Model Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Model Class Initialized
DEBUG - 2011-04-16 06:02:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:02:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Config Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:02:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:02:17 --> URI Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Router Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Output Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Input Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:02:17 --> Language Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Loader Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Controller Class Initialized
ERROR - 2011-04-16 06:02:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:02:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:02:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:02:17 --> Model Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Model Class Initialized
DEBUG - 2011-04-16 06:02:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:02:17 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:02:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:02:17 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:02:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:02:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:02:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:02:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:02:17 --> Final output sent to browser
DEBUG - 2011-04-16 06:02:17 --> Total execution time: 0.0559
DEBUG - 2011-04-16 06:02:17 --> Final output sent to browser
DEBUG - 2011-04-16 06:02:17 --> Total execution time: 0.8892
DEBUG - 2011-04-16 06:02:19 --> Config Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:02:19 --> URI Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Router Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Output Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Input Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:02:19 --> Language Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Loader Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Controller Class Initialized
ERROR - 2011-04-16 06:02:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:02:19 --> Model Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Model Class Initialized
DEBUG - 2011-04-16 06:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:02:19 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:02:19 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:02:19 --> Final output sent to browser
DEBUG - 2011-04-16 06:02:19 --> Total execution time: 0.0515
DEBUG - 2011-04-16 06:02:36 --> Config Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:02:36 --> URI Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Router Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Output Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Input Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:02:36 --> Language Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Loader Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Controller Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Model Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Model Class Initialized
DEBUG - 2011-04-16 06:02:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:02:36 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:02:37 --> Final output sent to browser
DEBUG - 2011-04-16 06:02:37 --> Total execution time: 0.6770
DEBUG - 2011-04-16 06:03:46 --> Config Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:03:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:03:46 --> URI Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Router Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Output Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Input Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:03:46 --> Language Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Loader Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Controller Class Initialized
ERROR - 2011-04-16 06:03:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:03:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:03:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:03:46 --> Model Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Model Class Initialized
DEBUG - 2011-04-16 06:03:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:03:46 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:03:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:03:46 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:03:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:03:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:03:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:03:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:03:46 --> Final output sent to browser
DEBUG - 2011-04-16 06:03:46 --> Total execution time: 0.0365
DEBUG - 2011-04-16 06:03:53 --> Config Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:03:53 --> URI Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Router Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Output Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Input Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:03:53 --> Language Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Loader Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Controller Class Initialized
ERROR - 2011-04-16 06:03:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:03:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:03:53 --> Model Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Model Class Initialized
DEBUG - 2011-04-16 06:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:03:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:03:53 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:03:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:03:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:03:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:03:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:03:53 --> Final output sent to browser
DEBUG - 2011-04-16 06:03:53 --> Total execution time: 0.1083
DEBUG - 2011-04-16 06:03:59 --> Config Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:03:59 --> URI Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Router Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Output Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Input Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:03:59 --> Language Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Loader Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Controller Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Model Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Model Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:03:59 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:03:59 --> Final output sent to browser
DEBUG - 2011-04-16 06:03:59 --> Total execution time: 0.9297
DEBUG - 2011-04-16 06:04:34 --> Config Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:04:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:04:34 --> URI Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Router Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Output Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Input Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:04:34 --> Language Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Loader Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Controller Class Initialized
ERROR - 2011-04-16 06:04:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:04:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:04:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:04:34 --> Model Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Model Class Initialized
DEBUG - 2011-04-16 06:04:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:04:34 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:04:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:04:34 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:04:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:04:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:04:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:04:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:04:34 --> Final output sent to browser
DEBUG - 2011-04-16 06:04:34 --> Total execution time: 0.0492
DEBUG - 2011-04-16 06:04:40 --> Config Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:04:40 --> URI Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Router Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Output Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Input Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:04:40 --> Language Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Loader Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Controller Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Model Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Model Class Initialized
DEBUG - 2011-04-16 06:04:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:04:40 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:04:41 --> Final output sent to browser
DEBUG - 2011-04-16 06:04:41 --> Total execution time: 0.8844
DEBUG - 2011-04-16 06:08:44 --> Config Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:08:44 --> URI Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Router Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Output Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Input Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:08:44 --> Language Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Loader Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Controller Class Initialized
ERROR - 2011-04-16 06:08:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:08:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:08:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:08:44 --> Model Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Model Class Initialized
DEBUG - 2011-04-16 06:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:08:44 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:08:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:08:44 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:08:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:08:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:08:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:08:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:08:44 --> Final output sent to browser
DEBUG - 2011-04-16 06:08:44 --> Total execution time: 0.3869
DEBUG - 2011-04-16 06:09:02 --> Config Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:09:02 --> URI Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Router Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Output Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Input Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:09:02 --> Language Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Loader Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Controller Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Model Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Model Class Initialized
DEBUG - 2011-04-16 06:09:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:09:02 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:09:33 --> Final output sent to browser
DEBUG - 2011-04-16 06:09:33 --> Total execution time: 30.5120
DEBUG - 2011-04-16 06:10:32 --> Config Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:10:32 --> URI Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Router Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Output Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Input Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:10:32 --> Language Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Loader Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Controller Class Initialized
ERROR - 2011-04-16 06:10:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:10:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:10:32 --> Model Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Model Class Initialized
DEBUG - 2011-04-16 06:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:10:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:10:33 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:10:33 --> Final output sent to browser
DEBUG - 2011-04-16 06:10:33 --> Total execution time: 0.1154
DEBUG - 2011-04-16 06:10:33 --> Config Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:10:33 --> URI Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Router Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Output Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Input Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:10:33 --> Language Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Loader Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Controller Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Model Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Model Class Initialized
DEBUG - 2011-04-16 06:10:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:10:33 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:10:35 --> Final output sent to browser
DEBUG - 2011-04-16 06:10:35 --> Total execution time: 2.0092
DEBUG - 2011-04-16 06:10:49 --> Config Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:10:49 --> URI Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Router Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Output Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Input Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:10:49 --> Language Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Loader Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Controller Class Initialized
ERROR - 2011-04-16 06:10:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:10:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:10:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:10:49 --> Model Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Model Class Initialized
DEBUG - 2011-04-16 06:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:10:49 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:10:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:10:49 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:10:49 --> Final output sent to browser
DEBUG - 2011-04-16 06:10:49 --> Total execution time: 0.1346
DEBUG - 2011-04-16 06:10:50 --> Config Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:10:50 --> URI Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Router Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Output Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Input Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:10:50 --> Language Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Loader Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Controller Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Model Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Model Class Initialized
DEBUG - 2011-04-16 06:10:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:10:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:10:52 --> Final output sent to browser
DEBUG - 2011-04-16 06:10:52 --> Total execution time: 1.4622
DEBUG - 2011-04-16 06:13:26 --> Config Class Initialized
DEBUG - 2011-04-16 06:13:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:13:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:13:26 --> URI Class Initialized
DEBUG - 2011-04-16 06:13:26 --> Router Class Initialized
ERROR - 2011-04-16 06:13:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-16 06:13:27 --> Config Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:13:27 --> URI Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Router Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Output Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Input Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:13:27 --> Language Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Loader Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Controller Class Initialized
ERROR - 2011-04-16 06:13:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:13:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:13:27 --> Model Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Model Class Initialized
DEBUG - 2011-04-16 06:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:13:27 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:13:27 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:13:27 --> Final output sent to browser
DEBUG - 2011-04-16 06:13:27 --> Total execution time: 0.0376
DEBUG - 2011-04-16 06:14:41 --> Config Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:14:41 --> URI Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Router Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Output Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Input Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:14:41 --> Language Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Loader Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Controller Class Initialized
ERROR - 2011-04-16 06:14:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:14:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:14:41 --> Model Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Model Class Initialized
DEBUG - 2011-04-16 06:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:14:41 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:14:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:14:41 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:14:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:14:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:14:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:14:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:14:41 --> Final output sent to browser
DEBUG - 2011-04-16 06:14:41 --> Total execution time: 0.1289
DEBUG - 2011-04-16 06:14:42 --> Config Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:14:42 --> URI Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Router Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Output Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Input Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:14:42 --> Language Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Loader Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Controller Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Model Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Model Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:14:42 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:14:42 --> Final output sent to browser
DEBUG - 2011-04-16 06:14:42 --> Total execution time: 0.7950
DEBUG - 2011-04-16 06:15:01 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:01 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:01 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Controller Class Initialized
ERROR - 2011-04-16 06:15:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:15:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:15:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:01 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:01 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:01 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:15:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:15:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:15:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:15:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:15:01 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:01 --> Total execution time: 0.0291
DEBUG - 2011-04-16 06:15:02 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:02 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:02 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:02 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:02 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:02 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:03 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:03 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:03 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:03 --> Controller Class Initialized
DEBUG - 2011-04-16 06:15:03 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:03 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:03 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:03 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:03 --> Total execution time: 0.7731
DEBUG - 2011-04-16 06:15:20 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:20 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:20 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Controller Class Initialized
ERROR - 2011-04-16 06:15:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:15:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:15:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:20 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:20 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:20 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:15:20 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:20 --> Total execution time: 0.0971
DEBUG - 2011-04-16 06:15:21 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:21 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:21 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Controller Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:21 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:21 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:21 --> Total execution time: 0.5471
DEBUG - 2011-04-16 06:15:22 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:22 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:22 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Controller Class Initialized
ERROR - 2011-04-16 06:15:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:15:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:22 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:22 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:22 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:15:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:15:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:15:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:15:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:15:22 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:22 --> Total execution time: 0.0706
DEBUG - 2011-04-16 06:15:46 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:46 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:46 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Controller Class Initialized
ERROR - 2011-04-16 06:15:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:15:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:46 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:46 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:46 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:15:46 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:46 --> Total execution time: 0.0438
DEBUG - 2011-04-16 06:15:47 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:47 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:47 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Controller Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:47 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:47 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:47 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Controller Class Initialized
ERROR - 2011-04-16 06:15:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:15:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:47 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:47 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:47 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:15:47 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:47 --> Total execution time: 0.0302
DEBUG - 2011-04-16 06:15:47 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:47 --> Total execution time: 0.5403
DEBUG - 2011-04-16 06:15:59 --> Config Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:15:59 --> URI Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Router Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Output Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Input Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:15:59 --> Language Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Loader Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Controller Class Initialized
ERROR - 2011-04-16 06:15:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:15:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:15:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:59 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Model Class Initialized
DEBUG - 2011-04-16 06:15:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:15:59 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:15:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:15:59 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:15:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:15:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:15:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:15:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:15:59 --> Final output sent to browser
DEBUG - 2011-04-16 06:15:59 --> Total execution time: 0.0297
DEBUG - 2011-04-16 06:16:00 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:00 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:00 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Controller Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:00 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:00 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:00 --> Total execution time: 0.5160
DEBUG - 2011-04-16 06:16:02 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:02 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:02 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Controller Class Initialized
ERROR - 2011-04-16 06:16:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:16:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:16:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:02 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:02 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:02 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:16:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:16:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:16:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:16:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:16:02 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:02 --> Total execution time: 0.1085
DEBUG - 2011-04-16 06:16:05 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:05 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:05 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Controller Class Initialized
ERROR - 2011-04-16 06:16:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:16:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:16:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:05 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:06 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:06 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:16:06 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:06 --> Total execution time: 0.0420
DEBUG - 2011-04-16 06:16:06 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:06 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:06 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Controller Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:06 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:07 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:07 --> Total execution time: 0.5090
DEBUG - 2011-04-16 06:16:15 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:15 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:15 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Controller Class Initialized
ERROR - 2011-04-16 06:16:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:16:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:16:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:15 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:15 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:15 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:16:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:16:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:16:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:16:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:16:15 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:15 --> Total execution time: 0.0290
DEBUG - 2011-04-16 06:16:16 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:16 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:16 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Controller Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:16 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:16 --> Total execution time: 0.4569
DEBUG - 2011-04-16 06:16:41 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:41 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:41 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Controller Class Initialized
ERROR - 2011-04-16 06:16:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:16:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:16:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:41 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:41 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:41 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:16:41 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:41 --> Total execution time: 0.0278
DEBUG - 2011-04-16 06:16:42 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:42 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:42 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Controller Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:42 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:42 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:42 --> Total execution time: 0.5787
DEBUG - 2011-04-16 06:16:43 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:43 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:43 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Controller Class Initialized
ERROR - 2011-04-16 06:16:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:16:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:43 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:43 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:43 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:16:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:16:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:16:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:16:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:16:43 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:43 --> Total execution time: 0.0278
DEBUG - 2011-04-16 06:16:57 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:57 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:57 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Controller Class Initialized
ERROR - 2011-04-16 06:16:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:16:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:16:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:57 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:57 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:57 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:16:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:16:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:16:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:16:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:16:57 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:57 --> Total execution time: 0.0286
DEBUG - 2011-04-16 06:16:58 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:58 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:58 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Controller Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:58 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:59 --> Total execution time: 0.7778
DEBUG - 2011-04-16 06:16:59 --> Config Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:16:59 --> URI Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Router Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Output Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Input Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:16:59 --> Language Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Loader Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Controller Class Initialized
ERROR - 2011-04-16 06:16:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:16:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:16:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:59 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Model Class Initialized
DEBUG - 2011-04-16 06:16:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:16:59 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:16:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:16:59 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:16:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:16:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:16:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:16:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:16:59 --> Final output sent to browser
DEBUG - 2011-04-16 06:16:59 --> Total execution time: 0.0315
DEBUG - 2011-04-16 06:17:55 --> Config Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:17:55 --> URI Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Router Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Output Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Input Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:17:55 --> Language Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Loader Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Controller Class Initialized
ERROR - 2011-04-16 06:17:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:17:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:17:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:17:55 --> Model Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Model Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:17:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:17:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:17:55 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:17:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:17:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:17:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:17:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:17:55 --> Final output sent to browser
DEBUG - 2011-04-16 06:17:55 --> Total execution time: 0.0320
DEBUG - 2011-04-16 06:17:55 --> Config Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:17:55 --> URI Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Router Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Output Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Input Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:17:55 --> Language Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Loader Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Controller Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Model Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Model Class Initialized
DEBUG - 2011-04-16 06:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:17:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:17:56 --> Final output sent to browser
DEBUG - 2011-04-16 06:17:56 --> Total execution time: 0.5522
DEBUG - 2011-04-16 06:18:53 --> Config Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:18:53 --> URI Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Router Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Output Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Input Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:18:53 --> Language Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Loader Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Controller Class Initialized
ERROR - 2011-04-16 06:18:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 06:18:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 06:18:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:18:53 --> Model Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Model Class Initialized
DEBUG - 2011-04-16 06:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:18:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:18:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 06:18:53 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:18:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:18:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:18:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:18:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:18:53 --> Final output sent to browser
DEBUG - 2011-04-16 06:18:53 --> Total execution time: 0.0294
DEBUG - 2011-04-16 06:18:54 --> Config Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:18:54 --> URI Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Router Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Output Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Input Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:18:54 --> Language Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Loader Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Controller Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Model Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Model Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 06:18:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 06:18:54 --> Final output sent to browser
DEBUG - 2011-04-16 06:18:54 --> Total execution time: 0.7111
DEBUG - 2011-04-16 06:47:50 --> Config Class Initialized
DEBUG - 2011-04-16 06:47:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 06:47:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 06:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 06:47:50 --> URI Class Initialized
DEBUG - 2011-04-16 06:47:50 --> Router Class Initialized
DEBUG - 2011-04-16 06:47:51 --> No URI present. Default controller set.
DEBUG - 2011-04-16 06:47:51 --> Output Class Initialized
DEBUG - 2011-04-16 06:47:51 --> Input Class Initialized
DEBUG - 2011-04-16 06:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 06:47:51 --> Language Class Initialized
DEBUG - 2011-04-16 06:47:51 --> Loader Class Initialized
DEBUG - 2011-04-16 06:47:51 --> Controller Class Initialized
DEBUG - 2011-04-16 06:47:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 06:47:51 --> Helper loaded: url_helper
DEBUG - 2011-04-16 06:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 06:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 06:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 06:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 06:47:51 --> Final output sent to browser
DEBUG - 2011-04-16 06:47:51 --> Total execution time: 0.2485
DEBUG - 2011-04-16 08:12:25 --> Config Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:12:25 --> URI Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Router Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Output Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Input Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:12:25 --> Language Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Loader Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Controller Class Initialized
ERROR - 2011-04-16 08:12:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:12:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:12:25 --> Model Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Model Class Initialized
DEBUG - 2011-04-16 08:12:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:12:26 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:12:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:12:26 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:12:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:12:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:12:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:12:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:12:26 --> Final output sent to browser
DEBUG - 2011-04-16 08:12:26 --> Total execution time: 1.6643
DEBUG - 2011-04-16 08:15:02 --> Config Class Initialized
DEBUG - 2011-04-16 08:15:02 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:15:02 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:15:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:15:02 --> URI Class Initialized
DEBUG - 2011-04-16 08:15:02 --> Router Class Initialized
DEBUG - 2011-04-16 08:15:02 --> No URI present. Default controller set.
DEBUG - 2011-04-16 08:15:02 --> Output Class Initialized
DEBUG - 2011-04-16 08:15:02 --> Input Class Initialized
DEBUG - 2011-04-16 08:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:15:02 --> Language Class Initialized
DEBUG - 2011-04-16 08:15:02 --> Loader Class Initialized
DEBUG - 2011-04-16 08:15:02 --> Controller Class Initialized
DEBUG - 2011-04-16 08:15:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 08:15:02 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:15:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:15:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:15:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:15:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:15:02 --> Final output sent to browser
DEBUG - 2011-04-16 08:15:02 --> Total execution time: 0.3637
DEBUG - 2011-04-16 08:15:04 --> Config Class Initialized
DEBUG - 2011-04-16 08:15:04 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:15:04 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:15:04 --> URI Class Initialized
DEBUG - 2011-04-16 08:15:04 --> Router Class Initialized
ERROR - 2011-04-16 08:15:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 08:15:06 --> Config Class Initialized
DEBUG - 2011-04-16 08:15:06 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:15:06 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:15:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:15:06 --> URI Class Initialized
DEBUG - 2011-04-16 08:15:06 --> Router Class Initialized
ERROR - 2011-04-16 08:15:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 08:15:29 --> Config Class Initialized
DEBUG - 2011-04-16 08:15:29 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:15:29 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:15:29 --> URI Class Initialized
DEBUG - 2011-04-16 08:15:29 --> Router Class Initialized
DEBUG - 2011-04-16 08:15:29 --> No URI present. Default controller set.
DEBUG - 2011-04-16 08:15:29 --> Output Class Initialized
DEBUG - 2011-04-16 08:15:29 --> Input Class Initialized
DEBUG - 2011-04-16 08:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:15:29 --> Language Class Initialized
DEBUG - 2011-04-16 08:15:29 --> Loader Class Initialized
DEBUG - 2011-04-16 08:15:29 --> Controller Class Initialized
DEBUG - 2011-04-16 08:15:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 08:15:29 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:15:29 --> Final output sent to browser
DEBUG - 2011-04-16 08:15:29 --> Total execution time: 0.0132
DEBUG - 2011-04-16 08:15:36 --> Config Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:15:36 --> URI Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Router Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Output Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Input Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:15:36 --> Language Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Loader Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Controller Class Initialized
ERROR - 2011-04-16 08:15:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:15:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:15:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:15:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:15:36 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:15:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:15:36 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:15:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:15:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:15:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:15:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:15:36 --> Final output sent to browser
DEBUG - 2011-04-16 08:15:36 --> Total execution time: 0.0288
DEBUG - 2011-04-16 08:15:36 --> Config Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:15:36 --> URI Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Router Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Output Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Input Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:15:36 --> Language Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Loader Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Controller Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:15:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:15:37 --> Final output sent to browser
DEBUG - 2011-04-16 08:15:37 --> Total execution time: 0.8085
DEBUG - 2011-04-16 08:16:18 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:18 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:18 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Controller Class Initialized
ERROR - 2011-04-16 08:16:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:16:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:18 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:18 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:18 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:16:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:16:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:16:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:16:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:16:18 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:18 --> Total execution time: 0.0481
DEBUG - 2011-04-16 08:16:19 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:19 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:19 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Controller Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:19 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:20 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:20 --> Total execution time: 0.8932
DEBUG - 2011-04-16 08:16:21 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:21 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:21 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Controller Class Initialized
ERROR - 2011-04-16 08:16:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:16:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:21 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:21 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:22 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:16:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:16:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:16:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:16:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:16:22 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:22 --> Total execution time: 0.0605
DEBUG - 2011-04-16 08:16:41 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:41 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:41 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Controller Class Initialized
ERROR - 2011-04-16 08:16:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:16:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:16:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:41 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:41 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:41 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:16:41 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:41 --> Total execution time: 0.0276
DEBUG - 2011-04-16 08:16:42 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:42 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:42 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Controller Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:42 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:43 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:43 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Controller Class Initialized
ERROR - 2011-04-16 08:16:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:16:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:43 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:43 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:43 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:16:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:16:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:16:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:16:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:16:43 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:43 --> Total execution time: 0.1151
DEBUG - 2011-04-16 08:16:43 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:43 --> Total execution time: 0.6396
DEBUG - 2011-04-16 08:16:55 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:55 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:55 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Controller Class Initialized
ERROR - 2011-04-16 08:16:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:16:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:16:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:55 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:55 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:16:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:16:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:16:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:16:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:16:55 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:55 --> Total execution time: 0.0396
DEBUG - 2011-04-16 08:16:55 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:55 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:55 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Controller Class Initialized
DEBUG - 2011-04-16 08:16:55 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:56 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:56 --> Total execution time: 0.7047
DEBUG - 2011-04-16 08:16:56 --> Config Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:16:56 --> URI Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Router Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Output Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Input Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:16:56 --> Language Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Loader Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Controller Class Initialized
ERROR - 2011-04-16 08:16:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:16:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:16:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:16:56 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:16:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:16:56 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:16:56 --> Final output sent to browser
DEBUG - 2011-04-16 08:16:56 --> Total execution time: 0.0306
DEBUG - 2011-04-16 08:17:04 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:04 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:04 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Controller Class Initialized
ERROR - 2011-04-16 08:17:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:17:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:17:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:04 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:04 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:04 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:17:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:17:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:17:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:17:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:17:04 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:04 --> Total execution time: 0.0271
DEBUG - 2011-04-16 08:17:06 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:06 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:06 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Controller Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:06 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:06 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:06 --> Total execution time: 0.6323
DEBUG - 2011-04-16 08:17:15 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:15 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:15 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:15 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:15 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:15 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:15 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:15 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:15 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:15 --> Controller Class Initialized
ERROR - 2011-04-16 08:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:16 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:17:16 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:16 --> Total execution time: 0.2548
DEBUG - 2011-04-16 08:17:16 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:16 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:16 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Controller Class Initialized
ERROR - 2011-04-16 08:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:17 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:17:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:17:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:17:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:17:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:17:17 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:17 --> Total execution time: 0.0561
DEBUG - 2011-04-16 08:17:17 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:17 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:17 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Controller Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:17 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:17 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:17 --> Total execution time: 0.7244
DEBUG - 2011-04-16 08:17:33 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:33 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:33 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Controller Class Initialized
ERROR - 2011-04-16 08:17:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:17:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:17:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:33 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:33 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:33 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:17:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:17:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:17:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:17:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:17:33 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:33 --> Total execution time: 0.0323
DEBUG - 2011-04-16 08:17:34 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:34 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:34 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Controller Class Initialized
ERROR - 2011-04-16 08:17:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:17:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:17:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:34 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:34 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:34 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:17:34 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:34 --> Total execution time: 0.0513
DEBUG - 2011-04-16 08:17:34 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:34 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:34 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Controller Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:34 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:35 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:35 --> Total execution time: 0.6536
DEBUG - 2011-04-16 08:17:50 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:50 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:50 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Controller Class Initialized
ERROR - 2011-04-16 08:17:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:17:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:17:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:50 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:17:50 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:17:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:17:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:17:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:17:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:17:50 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:50 --> Total execution time: 0.1331
DEBUG - 2011-04-16 08:17:51 --> Config Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:17:51 --> URI Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Router Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Output Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Input Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:17:51 --> Language Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Loader Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Controller Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Model Class Initialized
DEBUG - 2011-04-16 08:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:17:51 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:17:52 --> Final output sent to browser
DEBUG - 2011-04-16 08:17:52 --> Total execution time: 0.6087
DEBUG - 2011-04-16 08:18:27 --> Config Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:18:27 --> URI Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Router Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Output Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Input Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:18:27 --> Language Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Loader Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Controller Class Initialized
ERROR - 2011-04-16 08:18:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:18:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:18:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:18:27 --> Model Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Model Class Initialized
DEBUG - 2011-04-16 08:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:18:27 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:18:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:18:27 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:18:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:18:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:18:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:18:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:18:27 --> Final output sent to browser
DEBUG - 2011-04-16 08:18:27 --> Total execution time: 0.0353
DEBUG - 2011-04-16 08:18:28 --> Config Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:18:28 --> URI Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Router Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Output Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Input Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:18:28 --> Language Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Loader Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Controller Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Model Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Model Class Initialized
DEBUG - 2011-04-16 08:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:18:28 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Final output sent to browser
DEBUG - 2011-04-16 08:18:29 --> Total execution time: 0.6174
DEBUG - 2011-04-16 08:18:29 --> Config Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:18:29 --> URI Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Router Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Output Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Input Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:18:29 --> Language Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Loader Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Controller Class Initialized
ERROR - 2011-04-16 08:18:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:18:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:18:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:18:29 --> Model Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Model Class Initialized
DEBUG - 2011-04-16 08:18:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:18:29 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:18:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:18:29 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:18:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:18:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:18:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:18:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:18:29 --> Final output sent to browser
DEBUG - 2011-04-16 08:18:29 --> Total execution time: 0.0780
DEBUG - 2011-04-16 08:22:02 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:02 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:02 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:02 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:02 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:02 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:02 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:02 --> Total execution time: 0.0301
DEBUG - 2011-04-16 08:22:03 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:03 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:03 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Controller Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:03 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:03 --> Total execution time: 0.5797
DEBUG - 2011-04-16 08:22:03 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:03 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:03 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:03 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:03 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:03 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:03 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:03 --> Total execution time: 0.0293
DEBUG - 2011-04-16 08:22:16 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:16 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:16 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:16 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:16 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:16 --> Total execution time: 0.0422
DEBUG - 2011-04-16 08:22:17 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:17 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:17 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Controller Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:17 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:18 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:18 --> Total execution time: 0.8063
DEBUG - 2011-04-16 08:22:19 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:19 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:19 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:19 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:19 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:19 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:19 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:19 --> Total execution time: 0.0288
DEBUG - 2011-04-16 08:22:30 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:30 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:30 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:30 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:30 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:30 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:30 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:30 --> Total execution time: 0.0288
DEBUG - 2011-04-16 08:22:31 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:31 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:31 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Controller Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:33 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:33 --> Total execution time: 1.3506
DEBUG - 2011-04-16 08:22:36 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:36 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:36 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:36 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:36 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:37 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:37 --> Total execution time: 0.0312
DEBUG - 2011-04-16 08:22:37 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:37 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:37 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Controller Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:37 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:37 --> Total execution time: 0.5478
DEBUG - 2011-04-16 08:22:38 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:38 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:38 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:38 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:38 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:38 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:38 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:38 --> Total execution time: 0.0282
DEBUG - 2011-04-16 08:22:51 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:51 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:51 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:51 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:51 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:51 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:51 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:51 --> Total execution time: 0.0435
DEBUG - 2011-04-16 08:22:51 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:51 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:51 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Controller Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:51 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Config Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:22:52 --> URI Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Router Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Output Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Input Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:22:52 --> Language Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Loader Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Controller Class Initialized
ERROR - 2011-04-16 08:22:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:22:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:22:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:52 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Model Class Initialized
DEBUG - 2011-04-16 08:22:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:22:52 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:22:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:22:52 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:22:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:22:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:22:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:22:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:22:52 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:52 --> Total execution time: 0.0320
DEBUG - 2011-04-16 08:22:52 --> Final output sent to browser
DEBUG - 2011-04-16 08:22:52 --> Total execution time: 0.7354
DEBUG - 2011-04-16 08:23:06 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:06 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:06 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:06 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:06 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:06 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:06 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:06 --> Total execution time: 0.0293
DEBUG - 2011-04-16 08:23:07 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:07 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:07 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:07 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:07 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:07 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:07 --> Total execution time: 0.0280
DEBUG - 2011-04-16 08:23:07 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:07 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:07 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Controller Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:08 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:08 --> Total execution time: 0.7135
DEBUG - 2011-04-16 08:23:16 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:16 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:16 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:16 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:16 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:16 --> Total execution time: 0.0281
DEBUG - 2011-04-16 08:23:17 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:17 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:17 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Controller Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:17 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:17 --> Total execution time: 0.4949
DEBUG - 2011-04-16 08:23:17 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:17 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:17 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:17 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:17 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:17 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:17 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:17 --> Total execution time: 0.0364
DEBUG - 2011-04-16 08:23:28 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:28 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:28 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:28 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:28 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:28 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:28 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:28 --> Total execution time: 0.0289
DEBUG - 2011-04-16 08:23:28 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:28 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:28 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Controller Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:28 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:29 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:29 --> Total execution time: 0.5256
DEBUG - 2011-04-16 08:23:32 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:32 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:32 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:32 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:32 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:32 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:32 --> Total execution time: 0.0447
DEBUG - 2011-04-16 08:23:35 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:35 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:35 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:35 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:35 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:35 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:35 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:35 --> Total execution time: 0.0273
DEBUG - 2011-04-16 08:23:36 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:36 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:36 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Controller Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:36 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:37 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:37 --> Total execution time: 0.5776
DEBUG - 2011-04-16 08:23:39 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:39 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:39 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:39 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:39 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:39 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:39 --> Total execution time: 0.0683
DEBUG - 2011-04-16 08:23:52 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:52 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:52 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:52 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:52 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:52 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:52 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:52 --> Total execution time: 0.0392
DEBUG - 2011-04-16 08:23:53 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:53 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:53 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Controller Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Config Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:23:53 --> URI Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Router Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Output Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Input Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:23:53 --> Language Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Loader Class Initialized
DEBUG - 2011-04-16 08:23:53 --> Controller Class Initialized
ERROR - 2011-04-16 08:23:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:23:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:23:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:53 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:54 --> Model Class Initialized
DEBUG - 2011-04-16 08:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:23:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:23:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:23:54 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:23:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:23:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:23:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:23:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:23:54 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:54 --> Total execution time: 0.1049
DEBUG - 2011-04-16 08:23:54 --> Final output sent to browser
DEBUG - 2011-04-16 08:23:54 --> Total execution time: 0.5952
DEBUG - 2011-04-16 08:24:30 --> Config Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:24:30 --> URI Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Router Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Output Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Input Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:24:30 --> Language Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Loader Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Controller Class Initialized
ERROR - 2011-04-16 08:24:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:24:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:24:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:30 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:24:30 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:24:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:30 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:24:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:24:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:24:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:24:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:24:30 --> Final output sent to browser
DEBUG - 2011-04-16 08:24:30 --> Total execution time: 1.4016
DEBUG - 2011-04-16 08:24:32 --> Config Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:24:32 --> URI Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Router Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Output Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Input Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:24:32 --> Language Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Loader Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Controller Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:24:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Config Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:24:32 --> URI Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Router Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Output Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Input Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:24:32 --> Language Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Loader Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Controller Class Initialized
ERROR - 2011-04-16 08:24:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:24:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:24:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:32 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:24:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:24:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:32 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:24:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:24:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:24:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:24:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:24:32 --> Final output sent to browser
DEBUG - 2011-04-16 08:24:32 --> Total execution time: 0.0313
DEBUG - 2011-04-16 08:24:33 --> Final output sent to browser
DEBUG - 2011-04-16 08:24:33 --> Total execution time: 0.8824
DEBUG - 2011-04-16 08:24:45 --> Config Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:24:45 --> URI Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Router Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Output Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Input Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:24:45 --> Language Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Loader Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Controller Class Initialized
ERROR - 2011-04-16 08:24:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:24:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:24:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:45 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:24:45 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:24:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:45 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:24:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:24:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:24:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:24:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:24:45 --> Final output sent to browser
DEBUG - 2011-04-16 08:24:45 --> Total execution time: 0.0295
DEBUG - 2011-04-16 08:24:47 --> Config Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:24:47 --> URI Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Router Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Output Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Input Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:24:47 --> Language Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Loader Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Controller Class Initialized
ERROR - 2011-04-16 08:24:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:47 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:24:47 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:47 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:24:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:24:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:24:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:24:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:24:47 --> Final output sent to browser
DEBUG - 2011-04-16 08:24:47 --> Total execution time: 0.0284
DEBUG - 2011-04-16 08:24:48 --> Config Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:24:48 --> URI Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Router Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Output Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Input Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:24:48 --> Language Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Loader Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Controller Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:24:48 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:24:49 --> Final output sent to browser
DEBUG - 2011-04-16 08:24:49 --> Total execution time: 0.5673
DEBUG - 2011-04-16 08:24:59 --> Config Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:24:59 --> URI Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Router Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Output Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Input Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:24:59 --> Language Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Loader Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Controller Class Initialized
ERROR - 2011-04-16 08:24:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:24:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:24:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:59 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Model Class Initialized
DEBUG - 2011-04-16 08:24:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:24:59 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:24:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:24:59 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:24:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:24:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:24:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:24:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:24:59 --> Final output sent to browser
DEBUG - 2011-04-16 08:24:59 --> Total execution time: 0.0422
DEBUG - 2011-04-16 08:25:00 --> Config Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:25:00 --> URI Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Router Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Output Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Input Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:25:00 --> Language Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Loader Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Controller Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:25:00 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:25:01 --> Final output sent to browser
DEBUG - 2011-04-16 08:25:01 --> Total execution time: 0.6820
DEBUG - 2011-04-16 08:25:02 --> Config Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:25:02 --> URI Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Router Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Output Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Input Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:25:02 --> Language Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Loader Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Controller Class Initialized
ERROR - 2011-04-16 08:25:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:25:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:25:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:02 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:25:02 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:25:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:02 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:25:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:25:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:25:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:25:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:25:02 --> Final output sent to browser
DEBUG - 2011-04-16 08:25:02 --> Total execution time: 0.1185
DEBUG - 2011-04-16 08:25:19 --> Config Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:25:19 --> URI Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Router Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Output Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Input Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:25:19 --> Language Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Loader Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Controller Class Initialized
ERROR - 2011-04-16 08:25:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:25:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:19 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:25:19 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:19 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:25:19 --> Final output sent to browser
DEBUG - 2011-04-16 08:25:19 --> Total execution time: 0.0323
DEBUG - 2011-04-16 08:25:21 --> Config Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:25:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:25:21 --> URI Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Router Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Output Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Input Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:25:21 --> Language Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Loader Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Controller Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:25:21 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Config Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:25:22 --> URI Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Router Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Output Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Input Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:25:22 --> Language Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Loader Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Controller Class Initialized
ERROR - 2011-04-16 08:25:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:25:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:22 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:25:22 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:22 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:25:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:25:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:25:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:25:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:25:22 --> Final output sent to browser
DEBUG - 2011-04-16 08:25:22 --> Total execution time: 0.0302
DEBUG - 2011-04-16 08:25:23 --> Final output sent to browser
DEBUG - 2011-04-16 08:25:23 --> Total execution time: 2.0447
DEBUG - 2011-04-16 08:25:53 --> Config Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:25:53 --> URI Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Router Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Output Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Input Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:25:53 --> Language Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Loader Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Controller Class Initialized
ERROR - 2011-04-16 08:25:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:25:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:25:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:53 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:25:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:25:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:53 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:25:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:25:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:25:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:25:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:25:53 --> Final output sent to browser
DEBUG - 2011-04-16 08:25:53 --> Total execution time: 0.0615
DEBUG - 2011-04-16 08:25:54 --> Config Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:25:54 --> URI Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Router Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Output Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Input Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:25:54 --> Language Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Loader Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Controller Class Initialized
ERROR - 2011-04-16 08:25:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:25:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:54 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:25:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:25:54 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:25:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:25:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:25:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:25:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:25:54 --> Final output sent to browser
DEBUG - 2011-04-16 08:25:54 --> Total execution time: 0.0287
DEBUG - 2011-04-16 08:25:55 --> Config Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:25:55 --> URI Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Router Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Output Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Input Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:25:55 --> Language Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Loader Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Controller Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Model Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:25:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:25:55 --> Final output sent to browser
DEBUG - 2011-04-16 08:25:55 --> Total execution time: 0.5793
DEBUG - 2011-04-16 08:26:42 --> Config Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:26:42 --> URI Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Router Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Output Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Input Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:26:42 --> Language Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Loader Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Controller Class Initialized
ERROR - 2011-04-16 08:26:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:26:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:26:42 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:26:42 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:26:42 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:26:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:26:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:26:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:26:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:26:42 --> Final output sent to browser
DEBUG - 2011-04-16 08:26:42 --> Total execution time: 0.0896
DEBUG - 2011-04-16 08:26:43 --> Config Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:26:43 --> URI Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Router Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Output Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Input Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:26:43 --> Language Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Loader Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Controller Class Initialized
ERROR - 2011-04-16 08:26:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:26:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:26:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:26:43 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:26:43 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:26:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:26:43 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:26:43 --> Final output sent to browser
DEBUG - 2011-04-16 08:26:43 --> Total execution time: 0.0323
DEBUG - 2011-04-16 08:26:43 --> Config Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:26:43 --> URI Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Router Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Output Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Input Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:26:43 --> Language Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Loader Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Controller Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:26:43 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:26:44 --> Final output sent to browser
DEBUG - 2011-04-16 08:26:44 --> Total execution time: 0.6605
DEBUG - 2011-04-16 08:26:55 --> Config Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:26:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:26:55 --> URI Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Router Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Output Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Input Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:26:55 --> Language Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Loader Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Controller Class Initialized
ERROR - 2011-04-16 08:26:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:26:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:26:55 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:26:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:26:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:26:55 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:26:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:26:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:26:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:26:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:26:55 --> Final output sent to browser
DEBUG - 2011-04-16 08:26:55 --> Total execution time: 0.0402
DEBUG - 2011-04-16 08:26:56 --> Config Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:26:56 --> URI Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Router Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Output Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Input Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:26:56 --> Language Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Loader Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Controller Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:26:56 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Final output sent to browser
DEBUG - 2011-04-16 08:26:56 --> Total execution time: 0.5592
DEBUG - 2011-04-16 08:26:56 --> Config Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:26:56 --> URI Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Router Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Output Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Input Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:26:56 --> Language Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Loader Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Controller Class Initialized
ERROR - 2011-04-16 08:26:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:26:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:26:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:26:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:26:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:26:56 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:26:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:26:56 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:26:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:26:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:26:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:26:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:26:56 --> Final output sent to browser
DEBUG - 2011-04-16 08:26:56 --> Total execution time: 0.0314
DEBUG - 2011-04-16 08:27:05 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:05 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:05 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:05 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:05 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:06 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:06 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:06 --> Total execution time: 0.0338
DEBUG - 2011-04-16 08:27:06 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:06 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:06 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Controller Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:06 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:07 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:07 --> Total execution time: 0.5665
DEBUG - 2011-04-16 08:27:08 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:08 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:08 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:08 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:08 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:08 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:08 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:08 --> Total execution time: 0.0876
DEBUG - 2011-04-16 08:27:20 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:20 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:20 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:20 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:20 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:20 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:20 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:20 --> Total execution time: 0.0310
DEBUG - 2011-04-16 08:27:22 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:22 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:22 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Controller Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:22 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:23 --> Total execution time: 0.6061
DEBUG - 2011-04-16 08:27:23 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:23 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:23 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:23 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:23 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:23 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:23 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:23 --> Total execution time: 0.0584
DEBUG - 2011-04-16 08:27:28 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:28 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:28 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:28 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:28 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:28 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:28 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:28 --> Total execution time: 0.0333
DEBUG - 2011-04-16 08:27:29 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:29 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:29 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:29 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:29 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:29 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:29 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:29 --> Total execution time: 0.0289
DEBUG - 2011-04-16 08:27:31 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:31 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:31 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Controller Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:31 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:31 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:31 --> Total execution time: 0.6089
DEBUG - 2011-04-16 08:27:40 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:40 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:40 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:40 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:40 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:40 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:40 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:40 --> Total execution time: 0.0274
DEBUG - 2011-04-16 08:27:41 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:41 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:41 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Controller Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:41 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:41 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:41 --> Total execution time: 0.4770
DEBUG - 2011-04-16 08:27:42 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:42 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:42 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:42 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:42 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:42 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:42 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:42 --> Total execution time: 0.0307
DEBUG - 2011-04-16 08:27:46 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:46 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:46 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:46 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:46 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:46 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:46 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:46 --> Total execution time: 0.0278
DEBUG - 2011-04-16 08:27:47 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:47 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:47 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Controller Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:47 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:47 --> Total execution time: 0.4922
DEBUG - 2011-04-16 08:27:47 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:47 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:47 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:47 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:47 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:47 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:47 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:47 --> Total execution time: 0.0283
DEBUG - 2011-04-16 08:27:56 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:56 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:56 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:57 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:57 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:57 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:57 --> Total execution time: 0.0272
DEBUG - 2011-04-16 08:27:57 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:57 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:57 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Controller Class Initialized
ERROR - 2011-04-16 08:27:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:27:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:57 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:57 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:27:57 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:27:57 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:57 --> Total execution time: 0.0363
DEBUG - 2011-04-16 08:27:57 --> Config Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:27:57 --> URI Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Router Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Output Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Input Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:27:57 --> Language Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Loader Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Controller Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Model Class Initialized
DEBUG - 2011-04-16 08:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:27:57 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:27:58 --> Final output sent to browser
DEBUG - 2011-04-16 08:27:58 --> Total execution time: 0.8511
DEBUG - 2011-04-16 08:28:41 --> Config Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:28:41 --> URI Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Router Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Output Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Input Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:28:41 --> Language Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Loader Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Controller Class Initialized
ERROR - 2011-04-16 08:28:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:28:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:28:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:28:41 --> Model Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Model Class Initialized
DEBUG - 2011-04-16 08:28:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:28:41 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:28:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:28:41 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:28:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:28:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:28:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:28:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:28:41 --> Final output sent to browser
DEBUG - 2011-04-16 08:28:41 --> Total execution time: 0.0746
DEBUG - 2011-04-16 08:28:42 --> Config Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:28:42 --> URI Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Router Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Output Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Input Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:28:42 --> Language Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Loader Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Controller Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Model Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Model Class Initialized
DEBUG - 2011-04-16 08:28:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:28:42 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:28:43 --> Final output sent to browser
DEBUG - 2011-04-16 08:28:43 --> Total execution time: 0.5422
DEBUG - 2011-04-16 08:29:32 --> Config Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:29:32 --> URI Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Router Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Output Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Input Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:29:32 --> Language Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Loader Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Controller Class Initialized
ERROR - 2011-04-16 08:29:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:29:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:29:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:29:32 --> Model Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Model Class Initialized
DEBUG - 2011-04-16 08:29:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:29:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:29:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:29:32 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:29:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:29:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:29:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:29:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:29:32 --> Final output sent to browser
DEBUG - 2011-04-16 08:29:32 --> Total execution time: 0.0292
DEBUG - 2011-04-16 08:29:33 --> Config Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:29:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:29:33 --> URI Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Router Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Output Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Input Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:29:33 --> Language Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Loader Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Controller Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Model Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Model Class Initialized
DEBUG - 2011-04-16 08:29:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:29:33 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:29:34 --> Final output sent to browser
DEBUG - 2011-04-16 08:29:34 --> Total execution time: 0.6898
DEBUG - 2011-04-16 08:30:22 --> Config Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:30:22 --> URI Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Router Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Output Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Input Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:30:22 --> Language Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Loader Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Controller Class Initialized
ERROR - 2011-04-16 08:30:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:30:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:30:22 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:30:22 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:30:22 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:30:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:30:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:30:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:30:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:30:22 --> Final output sent to browser
DEBUG - 2011-04-16 08:30:22 --> Total execution time: 0.0294
DEBUG - 2011-04-16 08:30:23 --> Config Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:30:23 --> URI Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Router Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Output Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Input Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:30:23 --> Language Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Loader Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Controller Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:30:23 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:30:24 --> Final output sent to browser
DEBUG - 2011-04-16 08:30:24 --> Total execution time: 0.7170
DEBUG - 2011-04-16 08:30:45 --> Config Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:30:45 --> URI Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Router Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Output Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Input Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:30:45 --> Language Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Loader Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Controller Class Initialized
ERROR - 2011-04-16 08:30:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:30:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:30:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:30:45 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:30:45 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:30:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:30:45 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:30:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:30:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:30:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:30:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:30:45 --> Final output sent to browser
DEBUG - 2011-04-16 08:30:45 --> Total execution time: 0.0340
DEBUG - 2011-04-16 08:30:45 --> Config Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:30:45 --> URI Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Router Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Output Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Input Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:30:45 --> Language Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Loader Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Controller Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:30:45 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:30:46 --> Final output sent to browser
DEBUG - 2011-04-16 08:30:46 --> Total execution time: 0.5663
DEBUG - 2011-04-16 08:30:56 --> Config Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:30:56 --> URI Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Router Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Output Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Input Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:30:56 --> Language Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Loader Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Controller Class Initialized
ERROR - 2011-04-16 08:30:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:30:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:30:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:30:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:30:56 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:30:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:30:56 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:30:56 --> Final output sent to browser
DEBUG - 2011-04-16 08:30:56 --> Total execution time: 0.0332
DEBUG - 2011-04-16 08:30:57 --> Config Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:30:57 --> URI Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Router Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Output Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Input Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:30:57 --> Language Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Loader Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Controller Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Model Class Initialized
DEBUG - 2011-04-16 08:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:30:57 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:30:58 --> Final output sent to browser
DEBUG - 2011-04-16 08:30:58 --> Total execution time: 0.6934
DEBUG - 2011-04-16 08:31:15 --> Config Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:31:15 --> URI Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Router Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Output Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Input Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:31:15 --> Language Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Loader Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Controller Class Initialized
ERROR - 2011-04-16 08:31:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:31:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:31:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:31:15 --> Model Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Model Class Initialized
DEBUG - 2011-04-16 08:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:31:15 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:31:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:31:15 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:31:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:31:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:31:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:31:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:31:15 --> Final output sent to browser
DEBUG - 2011-04-16 08:31:15 --> Total execution time: 0.0348
DEBUG - 2011-04-16 08:31:16 --> Config Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:31:16 --> URI Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Router Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Output Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Input Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:31:16 --> Language Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Loader Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Controller Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Model Class Initialized
DEBUG - 2011-04-16 08:31:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:31:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:31:17 --> Final output sent to browser
DEBUG - 2011-04-16 08:31:17 --> Total execution time: 0.6235
DEBUG - 2011-04-16 08:31:46 --> Config Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:31:46 --> URI Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Router Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Output Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Input Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:31:46 --> Language Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Loader Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Controller Class Initialized
ERROR - 2011-04-16 08:31:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:31:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:31:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:31:46 --> Model Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Model Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:31:46 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:31:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:31:46 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:31:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:31:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:31:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:31:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:31:46 --> Final output sent to browser
DEBUG - 2011-04-16 08:31:46 --> Total execution time: 0.0298
DEBUG - 2011-04-16 08:31:46 --> Config Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:31:46 --> URI Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Router Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Output Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Input Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:31:46 --> Language Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Loader Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Controller Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Model Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Model Class Initialized
DEBUG - 2011-04-16 08:31:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:31:46 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:31:47 --> Final output sent to browser
DEBUG - 2011-04-16 08:31:47 --> Total execution time: 0.8225
DEBUG - 2011-04-16 08:32:07 --> Config Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:32:07 --> URI Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Router Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Output Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Input Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:32:07 --> Language Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Loader Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Controller Class Initialized
ERROR - 2011-04-16 08:32:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:32:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:32:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:32:07 --> Model Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Model Class Initialized
DEBUG - 2011-04-16 08:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:32:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:32:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:32:07 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:32:07 --> Final output sent to browser
DEBUG - 2011-04-16 08:32:07 --> Total execution time: 0.0449
DEBUG - 2011-04-16 08:32:09 --> Config Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:32:09 --> URI Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Router Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Output Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Input Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:32:09 --> Language Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Loader Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Controller Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Model Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Model Class Initialized
DEBUG - 2011-04-16 08:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:32:09 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:32:10 --> Final output sent to browser
DEBUG - 2011-04-16 08:32:10 --> Total execution time: 0.6294
DEBUG - 2011-04-16 08:32:21 --> Config Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:32:21 --> URI Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Router Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Output Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Input Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:32:21 --> Language Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Loader Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Controller Class Initialized
ERROR - 2011-04-16 08:32:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:32:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:32:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:32:21 --> Model Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Model Class Initialized
DEBUG - 2011-04-16 08:32:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:32:21 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:32:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:32:21 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:32:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:32:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:32:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:32:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:32:21 --> Final output sent to browser
DEBUG - 2011-04-16 08:32:21 --> Total execution time: 0.0321
DEBUG - 2011-04-16 08:32:23 --> Config Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:32:23 --> URI Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Router Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Output Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Input Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:32:23 --> Language Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Loader Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Controller Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Model Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Model Class Initialized
DEBUG - 2011-04-16 08:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:32:23 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:32:24 --> Final output sent to browser
DEBUG - 2011-04-16 08:32:24 --> Total execution time: 0.5440
DEBUG - 2011-04-16 08:33:26 --> Config Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:33:26 --> URI Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Router Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Output Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Input Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:33:26 --> Language Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Loader Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Controller Class Initialized
ERROR - 2011-04-16 08:33:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 08:33:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 08:33:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:33:26 --> Model Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Model Class Initialized
DEBUG - 2011-04-16 08:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:33:26 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:33:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 08:33:26 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:33:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:33:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:33:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:33:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:33:26 --> Final output sent to browser
DEBUG - 2011-04-16 08:33:26 --> Total execution time: 0.0268
DEBUG - 2011-04-16 08:33:27 --> Config Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:33:27 --> URI Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Router Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Output Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Input Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:33:27 --> Language Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Loader Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Controller Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Model Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Model Class Initialized
DEBUG - 2011-04-16 08:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:33:27 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:33:28 --> Final output sent to browser
DEBUG - 2011-04-16 08:33:28 --> Total execution time: 1.6244
DEBUG - 2011-04-16 08:39:04 --> Config Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:39:04 --> URI Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Router Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Output Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Input Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:39:04 --> Language Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Loader Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Controller Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:39:04 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:39:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 08:39:05 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:39:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:39:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:39:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:39:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:39:05 --> Final output sent to browser
DEBUG - 2011-04-16 08:39:05 --> Total execution time: 0.2569
DEBUG - 2011-04-16 08:39:36 --> Config Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:39:36 --> URI Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Router Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Output Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Input Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:39:36 --> Language Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Loader Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Controller Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:39:36 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:39:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 08:39:37 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:39:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:39:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:39:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:39:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:39:37 --> Final output sent to browser
DEBUG - 2011-04-16 08:39:37 --> Total execution time: 0.7378
DEBUG - 2011-04-16 08:39:39 --> Config Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:39:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:39:39 --> URI Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Router Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Output Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Input Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:39:39 --> Language Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Loader Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Controller Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:39:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:39:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 08:39:39 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:39:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:39:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:39:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:39:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:39:39 --> Final output sent to browser
DEBUG - 2011-04-16 08:39:39 --> Total execution time: 0.0486
DEBUG - 2011-04-16 08:39:58 --> Config Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:39:58 --> URI Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Router Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Output Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Input Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 08:39:58 --> Language Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Loader Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Controller Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Model Class Initialized
DEBUG - 2011-04-16 08:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 08:39:58 --> Database Driver Class Initialized
DEBUG - 2011-04-16 08:39:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 08:39:58 --> Helper loaded: url_helper
DEBUG - 2011-04-16 08:39:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 08:39:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 08:39:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 08:39:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 08:39:58 --> Final output sent to browser
DEBUG - 2011-04-16 08:39:58 --> Total execution time: 0.0633
DEBUG - 2011-04-16 08:40:00 --> Config Class Initialized
DEBUG - 2011-04-16 08:40:00 --> Hooks Class Initialized
DEBUG - 2011-04-16 08:40:00 --> Utf8 Class Initialized
DEBUG - 2011-04-16 08:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 08:40:00 --> URI Class Initialized
DEBUG - 2011-04-16 08:40:00 --> Router Class Initialized
ERROR - 2011-04-16 08:40:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:17:07 --> Config Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:17:07 --> URI Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Router Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Output Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Input Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:17:07 --> Language Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Loader Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Controller Class Initialized
ERROR - 2011-04-16 09:17:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:17:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:17:07 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:17:07 --> Config Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:17:07 --> URI Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Router Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Output Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Input Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:17:07 --> Language Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Loader Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Controller Class Initialized
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:17:07 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:17:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:17:07 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:17:07 --> Final output sent to browser
DEBUG - 2011-04-16 09:17:07 --> Total execution time: 0.5242
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 09:17:07 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:17:07 --> Final output sent to browser
DEBUG - 2011-04-16 09:17:07 --> Total execution time: 0.3107
DEBUG - 2011-04-16 09:17:08 --> Config Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:17:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:17:08 --> URI Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Router Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Output Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Input Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:17:08 --> Language Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Loader Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Controller Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:17:08 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:17:09 --> Final output sent to browser
DEBUG - 2011-04-16 09:17:09 --> Total execution time: 0.8792
DEBUG - 2011-04-16 09:17:10 --> Config Class Initialized
DEBUG - 2011-04-16 09:17:10 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:17:10 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:17:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:17:10 --> URI Class Initialized
DEBUG - 2011-04-16 09:17:10 --> Router Class Initialized
ERROR - 2011-04-16 09:17:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:17:30 --> Config Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:17:30 --> URI Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Router Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Output Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Input Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:17:30 --> Language Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Loader Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Controller Class Initialized
ERROR - 2011-04-16 09:17:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:17:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:17:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:17:30 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:17:30 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:17:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:17:30 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:17:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:17:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:17:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:17:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:17:30 --> Final output sent to browser
DEBUG - 2011-04-16 09:17:30 --> Total execution time: 0.0403
DEBUG - 2011-04-16 09:17:31 --> Config Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:17:31 --> URI Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Router Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Output Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Input Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:17:31 --> Language Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Loader Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Controller Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Model Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:17:31 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:17:31 --> Final output sent to browser
DEBUG - 2011-04-16 09:17:31 --> Total execution time: 0.6850
DEBUG - 2011-04-16 09:18:05 --> Config Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:18:05 --> URI Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Router Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Output Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Input Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:18:05 --> Language Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Loader Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Controller Class Initialized
ERROR - 2011-04-16 09:18:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:18:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:18:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:18:05 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:18:05 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:18:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:18:05 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:18:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:18:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:18:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:18:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:18:05 --> Final output sent to browser
DEBUG - 2011-04-16 09:18:05 --> Total execution time: 0.0280
DEBUG - 2011-04-16 09:18:05 --> Config Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:18:05 --> URI Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Router Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Output Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Input Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:18:05 --> Language Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Loader Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Controller Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:18:05 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:18:06 --> Final output sent to browser
DEBUG - 2011-04-16 09:18:06 --> Total execution time: 0.6118
DEBUG - 2011-04-16 09:18:13 --> Config Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:18:13 --> URI Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Router Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Output Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Input Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:18:13 --> Language Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Loader Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Controller Class Initialized
ERROR - 2011-04-16 09:18:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:18:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:18:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:18:13 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:18:13 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:18:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:18:13 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:18:13 --> Final output sent to browser
DEBUG - 2011-04-16 09:18:13 --> Total execution time: 0.0290
DEBUG - 2011-04-16 09:18:13 --> Config Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:18:13 --> URI Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Router Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Output Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Input Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:18:13 --> Language Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Loader Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Controller Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:18:13 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:18:14 --> Final output sent to browser
DEBUG - 2011-04-16 09:18:14 --> Total execution time: 0.6086
DEBUG - 2011-04-16 09:18:28 --> Config Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:18:28 --> URI Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Router Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Output Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Input Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:18:28 --> Language Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Loader Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Controller Class Initialized
ERROR - 2011-04-16 09:18:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:18:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:18:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:18:28 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:18:28 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:18:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:18:28 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:18:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:18:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:18:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:18:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:18:28 --> Final output sent to browser
DEBUG - 2011-04-16 09:18:28 --> Total execution time: 0.0295
DEBUG - 2011-04-16 09:18:29 --> Config Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:18:29 --> URI Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Router Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Output Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Input Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:18:29 --> Language Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Loader Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Controller Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:18:29 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:18:29 --> Final output sent to browser
DEBUG - 2011-04-16 09:18:29 --> Total execution time: 0.5618
DEBUG - 2011-04-16 09:18:38 --> Config Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:18:38 --> URI Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Router Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Output Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Input Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:18:38 --> Language Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Loader Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Controller Class Initialized
ERROR - 2011-04-16 09:18:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:18:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:18:38 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:18:38 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:18:38 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:18:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:18:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:18:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:18:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:18:38 --> Final output sent to browser
DEBUG - 2011-04-16 09:18:38 --> Total execution time: 0.0429
DEBUG - 2011-04-16 09:18:39 --> Config Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:18:39 --> URI Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Router Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Output Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Input Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:18:39 --> Language Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Loader Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Controller Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Model Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:18:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:18:39 --> Final output sent to browser
DEBUG - 2011-04-16 09:18:39 --> Total execution time: 0.5547
DEBUG - 2011-04-16 09:19:19 --> Config Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:19:19 --> URI Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Router Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Output Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Input Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:19:19 --> Language Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Loader Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Controller Class Initialized
ERROR - 2011-04-16 09:19:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:19:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:19:19 --> Model Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Model Class Initialized
DEBUG - 2011-04-16 09:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:19:19 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:19:19 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:19:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:19:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:19:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:19:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:19:19 --> Final output sent to browser
DEBUG - 2011-04-16 09:19:19 --> Total execution time: 0.0541
DEBUG - 2011-04-16 09:19:20 --> Config Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:19:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:19:20 --> URI Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Router Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Output Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Input Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:19:20 --> Language Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Loader Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Controller Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Model Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Model Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:19:20 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:19:20 --> Final output sent to browser
DEBUG - 2011-04-16 09:19:20 --> Total execution time: 0.4992
DEBUG - 2011-04-16 09:42:26 --> Config Class Initialized
DEBUG - 2011-04-16 09:42:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:42:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:42:26 --> URI Class Initialized
DEBUG - 2011-04-16 09:42:26 --> Router Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Output Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Input Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:42:27 --> Language Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Loader Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Controller Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Model Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Model Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Model Class Initialized
DEBUG - 2011-04-16 09:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:42:27 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:42:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 09:42:27 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:42:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:42:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:42:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:42:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:42:27 --> Final output sent to browser
DEBUG - 2011-04-16 09:42:27 --> Total execution time: 0.6352
DEBUG - 2011-04-16 09:42:28 --> Config Class Initialized
DEBUG - 2011-04-16 09:42:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:42:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:42:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:42:28 --> URI Class Initialized
DEBUG - 2011-04-16 09:42:28 --> Router Class Initialized
ERROR - 2011-04-16 09:42:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:42:39 --> Config Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:42:39 --> URI Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Router Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Output Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Input Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:42:39 --> Language Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Loader Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Controller Class Initialized
ERROR - 2011-04-16 09:42:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:42:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:42:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:42:39 --> Model Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Model Class Initialized
DEBUG - 2011-04-16 09:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:42:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:42:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:42:39 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:42:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:42:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:42:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:42:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:42:39 --> Final output sent to browser
DEBUG - 2011-04-16 09:42:39 --> Total execution time: 0.1301
DEBUG - 2011-04-16 09:42:40 --> Config Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:42:40 --> URI Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Router Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Output Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Input Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:42:40 --> Language Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Loader Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Controller Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Model Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Model Class Initialized
DEBUG - 2011-04-16 09:42:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:42:40 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:42:41 --> Final output sent to browser
DEBUG - 2011-04-16 09:42:41 --> Total execution time: 0.6749
DEBUG - 2011-04-16 09:42:41 --> Config Class Initialized
DEBUG - 2011-04-16 09:42:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:42:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:42:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:42:41 --> URI Class Initialized
DEBUG - 2011-04-16 09:42:41 --> Router Class Initialized
ERROR - 2011-04-16 09:42:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:43:07 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:07 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Router Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Output Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Input Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:43:07 --> Language Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Loader Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Controller Class Initialized
ERROR - 2011-04-16 09:43:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:43:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:43:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:43:07 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:43:07 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:43:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:43:07 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:43:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:43:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:43:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:43:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:43:07 --> Final output sent to browser
DEBUG - 2011-04-16 09:43:07 --> Total execution time: 0.0273
DEBUG - 2011-04-16 09:43:08 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:08 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Router Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Output Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Input Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:43:08 --> Language Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Loader Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Controller Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:43:08 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:43:08 --> Final output sent to browser
DEBUG - 2011-04-16 09:43:08 --> Total execution time: 0.5960
DEBUG - 2011-04-16 09:43:09 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:09 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:09 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:09 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:09 --> Router Class Initialized
ERROR - 2011-04-16 09:43:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:43:24 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:24 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Router Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Output Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Input Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:43:24 --> Language Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Loader Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Controller Class Initialized
ERROR - 2011-04-16 09:43:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:43:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:43:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:43:24 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:43:24 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:43:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:43:24 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:43:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:43:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:43:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:43:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:43:24 --> Final output sent to browser
DEBUG - 2011-04-16 09:43:24 --> Total execution time: 0.0392
DEBUG - 2011-04-16 09:43:25 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:25 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Router Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Output Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Input Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:43:25 --> Language Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Loader Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Controller Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:43:25 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:43:25 --> Final output sent to browser
DEBUG - 2011-04-16 09:43:25 --> Total execution time: 0.7581
DEBUG - 2011-04-16 09:43:26 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:26 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:26 --> Router Class Initialized
ERROR - 2011-04-16 09:43:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:43:48 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:48 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Router Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Output Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Input Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:43:48 --> Language Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Loader Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Controller Class Initialized
ERROR - 2011-04-16 09:43:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:43:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:43:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:43:48 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:43:48 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:43:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:43:48 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:43:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:43:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:43:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:43:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:43:48 --> Final output sent to browser
DEBUG - 2011-04-16 09:43:48 --> Total execution time: 0.0363
DEBUG - 2011-04-16 09:43:49 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:49 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Router Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Output Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Input Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:43:49 --> Language Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Loader Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Controller Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Model Class Initialized
DEBUG - 2011-04-16 09:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:43:49 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:43:50 --> Final output sent to browser
DEBUG - 2011-04-16 09:43:50 --> Total execution time: 0.5992
DEBUG - 2011-04-16 09:43:50 --> Config Class Initialized
DEBUG - 2011-04-16 09:43:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:43:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:43:50 --> URI Class Initialized
DEBUG - 2011-04-16 09:43:50 --> Router Class Initialized
ERROR - 2011-04-16 09:43:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:44:03 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:03 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Router Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Output Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Input Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:44:03 --> Language Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Loader Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Controller Class Initialized
ERROR - 2011-04-16 09:44:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:44:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:44:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:44:03 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:44:03 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:44:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:44:03 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:44:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:44:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:44:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:44:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:44:03 --> Final output sent to browser
DEBUG - 2011-04-16 09:44:03 --> Total execution time: 0.0305
DEBUG - 2011-04-16 09:44:03 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:03 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Router Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Output Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Input Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:44:03 --> Language Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Loader Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Controller Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:44:03 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:44:04 --> Final output sent to browser
DEBUG - 2011-04-16 09:44:04 --> Total execution time: 0.6044
DEBUG - 2011-04-16 09:44:04 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:04 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:04 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:04 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:04 --> Router Class Initialized
ERROR - 2011-04-16 09:44:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:44:20 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:20 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Router Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Output Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Input Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:44:20 --> Language Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Loader Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Controller Class Initialized
ERROR - 2011-04-16 09:44:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:44:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:44:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:44:20 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:44:20 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:44:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:44:20 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:44:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:44:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:44:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:44:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:44:20 --> Final output sent to browser
DEBUG - 2011-04-16 09:44:20 --> Total execution time: 0.0279
DEBUG - 2011-04-16 09:44:21 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:21 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Router Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Output Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Input Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:44:21 --> Language Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Loader Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Controller Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:44:21 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:44:22 --> Final output sent to browser
DEBUG - 2011-04-16 09:44:22 --> Total execution time: 0.5581
DEBUG - 2011-04-16 09:44:22 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:22 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:22 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:22 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:22 --> Router Class Initialized
ERROR - 2011-04-16 09:44:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:44:40 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:40 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Router Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Output Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Input Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:44:40 --> Language Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Loader Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Controller Class Initialized
ERROR - 2011-04-16 09:44:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:44:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:44:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:44:40 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:44:40 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:44:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:44:40 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:44:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:44:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:44:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:44:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:44:40 --> Final output sent to browser
DEBUG - 2011-04-16 09:44:40 --> Total execution time: 0.0378
DEBUG - 2011-04-16 09:44:40 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:40 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Router Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Output Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Input Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:44:40 --> Language Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Loader Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Controller Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:44:40 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:44:41 --> Final output sent to browser
DEBUG - 2011-04-16 09:44:41 --> Total execution time: 0.5455
DEBUG - 2011-04-16 09:44:41 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:41 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:41 --> Router Class Initialized
ERROR - 2011-04-16 09:44:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:44:50 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:50 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Router Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Output Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Input Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:44:50 --> Language Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Loader Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Controller Class Initialized
ERROR - 2011-04-16 09:44:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:44:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:44:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:44:50 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:44:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:44:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:44:50 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:44:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:44:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:44:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:44:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:44:50 --> Final output sent to browser
DEBUG - 2011-04-16 09:44:50 --> Total execution time: 0.0686
DEBUG - 2011-04-16 09:44:50 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:50 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Router Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Output Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Input Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:44:50 --> Language Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Loader Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Controller Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Model Class Initialized
DEBUG - 2011-04-16 09:44:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:44:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:44:51 --> Final output sent to browser
DEBUG - 2011-04-16 09:44:51 --> Total execution time: 0.6595
DEBUG - 2011-04-16 09:44:52 --> Config Class Initialized
DEBUG - 2011-04-16 09:44:52 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:44:52 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:44:52 --> URI Class Initialized
DEBUG - 2011-04-16 09:44:52 --> Router Class Initialized
ERROR - 2011-04-16 09:44:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:45:11 --> Config Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:45:11 --> URI Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Router Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Output Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Input Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:45:11 --> Language Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Loader Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Controller Class Initialized
ERROR - 2011-04-16 09:45:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:45:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:45:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:45:11 --> Model Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Model Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:45:11 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:45:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:45:11 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:45:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:45:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:45:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:45:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:45:11 --> Final output sent to browser
DEBUG - 2011-04-16 09:45:11 --> Total execution time: 0.0381
DEBUG - 2011-04-16 09:45:11 --> Config Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:45:11 --> URI Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Router Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Output Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Input Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:45:11 --> Language Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Loader Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Controller Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Model Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Model Class Initialized
DEBUG - 2011-04-16 09:45:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:45:11 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:45:12 --> Final output sent to browser
DEBUG - 2011-04-16 09:45:12 --> Total execution time: 0.6982
DEBUG - 2011-04-16 09:45:12 --> Config Class Initialized
DEBUG - 2011-04-16 09:45:12 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:45:12 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:45:12 --> URI Class Initialized
DEBUG - 2011-04-16 09:45:12 --> Router Class Initialized
ERROR - 2011-04-16 09:45:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 09:45:18 --> Config Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:45:18 --> URI Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Router Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Output Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Input Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:45:18 --> Language Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Loader Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Controller Class Initialized
ERROR - 2011-04-16 09:45:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 09:45:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 09:45:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:45:18 --> Model Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Model Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:45:18 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:45:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 09:45:18 --> Helper loaded: url_helper
DEBUG - 2011-04-16 09:45:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 09:45:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 09:45:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 09:45:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 09:45:18 --> Final output sent to browser
DEBUG - 2011-04-16 09:45:18 --> Total execution time: 0.0282
DEBUG - 2011-04-16 09:45:18 --> Config Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:45:18 --> URI Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Router Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Output Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Input Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 09:45:18 --> Language Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Loader Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Controller Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Model Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Model Class Initialized
DEBUG - 2011-04-16 09:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 09:45:18 --> Database Driver Class Initialized
DEBUG - 2011-04-16 09:45:19 --> Final output sent to browser
DEBUG - 2011-04-16 09:45:19 --> Total execution time: 0.5401
DEBUG - 2011-04-16 09:45:19 --> Config Class Initialized
DEBUG - 2011-04-16 09:45:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 09:45:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 09:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 09:45:19 --> URI Class Initialized
DEBUG - 2011-04-16 09:45:19 --> Router Class Initialized
ERROR - 2011-04-16 09:45:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 11:00:46 --> Config Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 11:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 11:00:46 --> URI Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Router Class Initialized
ERROR - 2011-04-16 11:00:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-16 11:00:46 --> Config Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 11:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 11:00:46 --> URI Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Router Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Output Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Input Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 11:00:46 --> Language Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Loader Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Controller Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Model Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Model Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Model Class Initialized
DEBUG - 2011-04-16 11:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 11:00:46 --> Database Driver Class Initialized
DEBUG - 2011-04-16 11:00:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 11:00:47 --> Helper loaded: url_helper
DEBUG - 2011-04-16 11:00:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 11:00:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 11:00:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 11:00:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 11:00:47 --> Final output sent to browser
DEBUG - 2011-04-16 11:00:47 --> Total execution time: 0.8553
DEBUG - 2011-04-16 11:01:17 --> Config Class Initialized
DEBUG - 2011-04-16 11:01:17 --> Hooks Class Initialized
DEBUG - 2011-04-16 11:01:17 --> Utf8 Class Initialized
DEBUG - 2011-04-16 11:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 11:01:17 --> URI Class Initialized
DEBUG - 2011-04-16 11:01:17 --> Router Class Initialized
DEBUG - 2011-04-16 11:01:18 --> Output Class Initialized
DEBUG - 2011-04-16 11:01:18 --> Input Class Initialized
DEBUG - 2011-04-16 11:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 11:01:18 --> Language Class Initialized
DEBUG - 2011-04-16 11:01:18 --> Loader Class Initialized
DEBUG - 2011-04-16 11:01:18 --> Controller Class Initialized
ERROR - 2011-04-16 11:01:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 11:01:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 11:01:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 11:01:18 --> Model Class Initialized
DEBUG - 2011-04-16 11:01:18 --> Model Class Initialized
DEBUG - 2011-04-16 11:01:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 11:01:18 --> Database Driver Class Initialized
DEBUG - 2011-04-16 11:01:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 11:01:18 --> Helper loaded: url_helper
DEBUG - 2011-04-16 11:01:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 11:01:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 11:01:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 11:01:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 11:01:18 --> Final output sent to browser
DEBUG - 2011-04-16 11:01:18 --> Total execution time: 0.0993
DEBUG - 2011-04-16 11:21:42 --> Config Class Initialized
DEBUG - 2011-04-16 11:21:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 11:21:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 11:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 11:21:43 --> URI Class Initialized
DEBUG - 2011-04-16 11:21:43 --> Router Class Initialized
DEBUG - 2011-04-16 11:21:43 --> No URI present. Default controller set.
DEBUG - 2011-04-16 11:21:43 --> Output Class Initialized
DEBUG - 2011-04-16 11:21:43 --> Input Class Initialized
DEBUG - 2011-04-16 11:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 11:21:43 --> Language Class Initialized
DEBUG - 2011-04-16 11:21:43 --> Loader Class Initialized
DEBUG - 2011-04-16 11:21:43 --> Controller Class Initialized
DEBUG - 2011-04-16 11:21:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 11:21:43 --> Helper loaded: url_helper
DEBUG - 2011-04-16 11:21:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 11:21:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 11:21:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 11:21:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 11:21:43 --> Final output sent to browser
DEBUG - 2011-04-16 11:21:43 --> Total execution time: 1.6330
DEBUG - 2011-04-16 12:18:16 --> Config Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 12:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 12:18:16 --> URI Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Router Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Output Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Input Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 12:18:16 --> Language Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Loader Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Controller Class Initialized
ERROR - 2011-04-16 12:18:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 12:18:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 12:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 12:18:16 --> Model Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Model Class Initialized
DEBUG - 2011-04-16 12:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 12:18:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 12:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 12:18:16 --> Helper loaded: url_helper
DEBUG - 2011-04-16 12:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 12:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 12:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 12:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 12:18:16 --> Final output sent to browser
DEBUG - 2011-04-16 12:18:16 --> Total execution time: 0.4877
DEBUG - 2011-04-16 12:18:18 --> Config Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Hooks Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Utf8 Class Initialized
DEBUG - 2011-04-16 12:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 12:18:18 --> URI Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Router Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Output Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Input Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 12:18:18 --> Language Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Loader Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Controller Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Model Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Model Class Initialized
DEBUG - 2011-04-16 12:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 12:18:18 --> Database Driver Class Initialized
DEBUG - 2011-04-16 12:18:19 --> Final output sent to browser
DEBUG - 2011-04-16 12:18:19 --> Total execution time: 1.6950
DEBUG - 2011-04-16 12:19:37 --> Config Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Hooks Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Utf8 Class Initialized
DEBUG - 2011-04-16 12:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 12:19:37 --> URI Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Router Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Output Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Input Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 12:19:37 --> Language Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Loader Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Controller Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Model Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Model Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Model Class Initialized
DEBUG - 2011-04-16 12:19:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 12:19:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 12:19:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 12:19:37 --> Helper loaded: url_helper
DEBUG - 2011-04-16 12:19:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 12:19:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 12:19:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 12:19:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 12:19:37 --> Final output sent to browser
DEBUG - 2011-04-16 12:19:37 --> Total execution time: 0.4090
DEBUG - 2011-04-16 12:19:39 --> Config Class Initialized
DEBUG - 2011-04-16 12:19:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 12:19:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 12:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 12:19:39 --> URI Class Initialized
DEBUG - 2011-04-16 12:19:39 --> Router Class Initialized
ERROR - 2011-04-16 12:19:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 12:19:40 --> Config Class Initialized
DEBUG - 2011-04-16 12:19:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 12:19:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 12:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 12:19:40 --> URI Class Initialized
DEBUG - 2011-04-16 12:19:40 --> Router Class Initialized
ERROR - 2011-04-16 12:19:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 12:30:58 --> Config Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Hooks Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Utf8 Class Initialized
DEBUG - 2011-04-16 12:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 12:30:58 --> URI Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Router Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Output Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Input Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 12:30:58 --> Language Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Loader Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Controller Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Model Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Model Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Model Class Initialized
DEBUG - 2011-04-16 12:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 12:30:58 --> Database Driver Class Initialized
DEBUG - 2011-04-16 12:30:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 12:30:58 --> Helper loaded: url_helper
DEBUG - 2011-04-16 12:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 12:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 12:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 12:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 12:30:58 --> Final output sent to browser
DEBUG - 2011-04-16 12:30:58 --> Total execution time: 0.2534
DEBUG - 2011-04-16 12:52:03 --> Config Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 12:52:03 --> URI Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Router Class Initialized
ERROR - 2011-04-16 12:52:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-16 12:52:03 --> Config Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 12:52:03 --> URI Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Router Class Initialized
DEBUG - 2011-04-16 12:52:03 --> No URI present. Default controller set.
DEBUG - 2011-04-16 12:52:03 --> Output Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Input Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 12:52:03 --> Language Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Loader Class Initialized
DEBUG - 2011-04-16 12:52:03 --> Controller Class Initialized
DEBUG - 2011-04-16 12:52:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 12:52:03 --> Helper loaded: url_helper
DEBUG - 2011-04-16 12:52:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 12:52:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 12:52:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 12:52:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 12:52:03 --> Final output sent to browser
DEBUG - 2011-04-16 12:52:03 --> Total execution time: 0.1617
DEBUG - 2011-04-16 13:09:07 --> Config Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Hooks Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Utf8 Class Initialized
DEBUG - 2011-04-16 13:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 13:09:07 --> URI Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Router Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Output Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Input Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 13:09:07 --> Language Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Loader Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Controller Class Initialized
ERROR - 2011-04-16 13:09:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 13:09:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 13:09:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 13:09:07 --> Model Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Model Class Initialized
DEBUG - 2011-04-16 13:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 13:09:08 --> Database Driver Class Initialized
DEBUG - 2011-04-16 13:09:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 13:09:08 --> Helper loaded: url_helper
DEBUG - 2011-04-16 13:09:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 13:09:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 13:09:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 13:09:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 13:09:08 --> Final output sent to browser
DEBUG - 2011-04-16 13:09:08 --> Total execution time: 0.4033
DEBUG - 2011-04-16 13:09:09 --> Config Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Hooks Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Utf8 Class Initialized
DEBUG - 2011-04-16 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 13:09:09 --> URI Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Router Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Output Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Input Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 13:09:09 --> Language Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Loader Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Controller Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Model Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Model Class Initialized
DEBUG - 2011-04-16 13:09:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 13:09:09 --> Database Driver Class Initialized
DEBUG - 2011-04-16 13:09:10 --> Final output sent to browser
DEBUG - 2011-04-16 13:09:10 --> Total execution time: 1.0317
DEBUG - 2011-04-16 13:09:11 --> Config Class Initialized
DEBUG - 2011-04-16 13:09:11 --> Hooks Class Initialized
DEBUG - 2011-04-16 13:09:11 --> Utf8 Class Initialized
DEBUG - 2011-04-16 13:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 13:09:11 --> URI Class Initialized
DEBUG - 2011-04-16 13:09:11 --> Router Class Initialized
ERROR - 2011-04-16 13:09:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 13:09:39 --> Config Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 13:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 13:09:39 --> URI Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Router Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Output Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Input Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 13:09:39 --> Language Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Loader Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Controller Class Initialized
ERROR - 2011-04-16 13:09:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 13:09:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 13:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 13:09:39 --> Model Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Model Class Initialized
DEBUG - 2011-04-16 13:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 13:09:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 13:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 13:09:39 --> Helper loaded: url_helper
DEBUG - 2011-04-16 13:09:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 13:09:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 13:09:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 13:09:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 13:09:39 --> Final output sent to browser
DEBUG - 2011-04-16 13:09:39 --> Total execution time: 0.0397
DEBUG - 2011-04-16 13:09:40 --> Config Class Initialized
DEBUG - 2011-04-16 13:09:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 13:09:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 13:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 13:09:40 --> URI Class Initialized
DEBUG - 2011-04-16 13:09:40 --> Router Class Initialized
ERROR - 2011-04-16 13:09:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-16 16:21:39 --> Config Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:21:39 --> URI Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Router Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Output Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Input Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:21:39 --> Language Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Loader Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Controller Class Initialized
ERROR - 2011-04-16 16:21:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:21:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:21:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:21:39 --> Model Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Model Class Initialized
DEBUG - 2011-04-16 16:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:21:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:21:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:21:40 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:21:40 --> Final output sent to browser
DEBUG - 2011-04-16 16:21:40 --> Total execution time: 0.3976
DEBUG - 2011-04-16 16:21:44 --> Config Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:21:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:21:44 --> URI Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Router Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Output Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Input Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:21:44 --> Language Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Loader Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Controller Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Model Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Model Class Initialized
DEBUG - 2011-04-16 16:21:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:21:44 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:21:45 --> Final output sent to browser
DEBUG - 2011-04-16 16:21:45 --> Total execution time: 0.7068
DEBUG - 2011-04-16 16:21:48 --> Config Class Initialized
DEBUG - 2011-04-16 16:21:48 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:21:48 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:21:48 --> URI Class Initialized
DEBUG - 2011-04-16 16:21:48 --> Router Class Initialized
ERROR - 2011-04-16 16:21:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 16:22:01 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:01 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:01 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Controller Class Initialized
ERROR - 2011-04-16 16:22:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:22:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:22:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:01 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:01 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:01 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:22:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:22:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:22:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:22:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:22:01 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:01 --> Total execution time: 0.0337
DEBUG - 2011-04-16 16:22:02 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:02 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:02 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Controller Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:02 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:03 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:03 --> Total execution time: 0.7167
DEBUG - 2011-04-16 16:22:11 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:11 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:11 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Controller Class Initialized
ERROR - 2011-04-16 16:22:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:22:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:22:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:11 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:11 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:12 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:22:12 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:12 --> Total execution time: 0.0515
DEBUG - 2011-04-16 16:22:12 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:12 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:12 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Controller Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:12 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:13 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:13 --> Total execution time: 0.6308
DEBUG - 2011-04-16 16:22:23 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:23 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:23 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Controller Class Initialized
ERROR - 2011-04-16 16:22:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:22:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:22:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:23 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:23 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:23 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:22:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:22:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:22:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:22:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:22:23 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:23 --> Total execution time: 0.0304
DEBUG - 2011-04-16 16:22:24 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:24 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:24 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Controller Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:24 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:24 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:24 --> Total execution time: 0.5970
DEBUG - 2011-04-16 16:22:31 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:31 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:31 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Controller Class Initialized
ERROR - 2011-04-16 16:22:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:22:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:22:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:31 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:31 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:31 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:22:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:22:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:22:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:22:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:22:31 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:31 --> Total execution time: 0.0307
DEBUG - 2011-04-16 16:22:32 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:32 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:32 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Controller Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:32 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:32 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:32 --> Total execution time: 0.4946
DEBUG - 2011-04-16 16:22:42 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:42 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:42 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Controller Class Initialized
ERROR - 2011-04-16 16:22:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:22:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:22:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:42 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:42 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:42 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:22:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:22:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:22:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:22:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:22:42 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:42 --> Total execution time: 0.0292
DEBUG - 2011-04-16 16:22:43 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:43 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:43 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Controller Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:43 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:43 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:43 --> Total execution time: 0.5820
DEBUG - 2011-04-16 16:22:47 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:47 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:47 --> Router Class Initialized
ERROR - 2011-04-16 16:22:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 16:22:53 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:53 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:53 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Controller Class Initialized
ERROR - 2011-04-16 16:22:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:22:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:22:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:53 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:22:53 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:22:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:22:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:22:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:22:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:22:53 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:53 --> Total execution time: 0.0503
DEBUG - 2011-04-16 16:22:54 --> Config Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:22:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:22:54 --> URI Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Router Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Output Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Input Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:22:54 --> Language Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Loader Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Controller Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Model Class Initialized
DEBUG - 2011-04-16 16:22:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:22:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:22:55 --> Final output sent to browser
DEBUG - 2011-04-16 16:22:55 --> Total execution time: 0.7570
DEBUG - 2011-04-16 16:23:14 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:14 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:14 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Controller Class Initialized
ERROR - 2011-04-16 16:23:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:23:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:23:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:14 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:14 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:14 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:23:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:23:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:23:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:23:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:23:14 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:14 --> Total execution time: 0.0284
DEBUG - 2011-04-16 16:23:16 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:16 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:16 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Controller Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:16 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:16 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:16 --> Total execution time: 0.7109
DEBUG - 2011-04-16 16:23:25 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:25 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:25 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Controller Class Initialized
ERROR - 2011-04-16 16:23:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:23:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:23:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:25 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:25 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:25 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:23:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:23:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:23:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:23:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:23:25 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:25 --> Total execution time: 0.0521
DEBUG - 2011-04-16 16:23:26 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:27 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:27 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Controller Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:27 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:27 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:27 --> Total execution time: 0.6214
DEBUG - 2011-04-16 16:23:34 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:34 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:34 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Controller Class Initialized
ERROR - 2011-04-16 16:23:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:23:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:23:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:34 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:34 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:34 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:23:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:23:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:23:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:23:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:23:34 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:34 --> Total execution time: 0.0356
DEBUG - 2011-04-16 16:23:36 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:36 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:36 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Controller Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:36 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:36 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:36 --> Total execution time: 0.5423
DEBUG - 2011-04-16 16:23:53 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:53 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:53 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:53 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:54 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Controller Class Initialized
ERROR - 2011-04-16 16:23:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:23:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:23:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:54 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:54 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:23:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:23:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:23:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:23:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:23:54 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:54 --> Total execution time: 0.0283
DEBUG - 2011-04-16 16:23:54 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:54 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:54 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Controller Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:55 --> Total execution time: 0.5717
DEBUG - 2011-04-16 16:23:55 --> Config Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:23:55 --> URI Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Router Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Output Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Input Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:23:55 --> Language Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Loader Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Controller Class Initialized
ERROR - 2011-04-16 16:23:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:23:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:55 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Model Class Initialized
DEBUG - 2011-04-16 16:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:23:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:23:55 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:23:55 --> Final output sent to browser
DEBUG - 2011-04-16 16:23:55 --> Total execution time: 0.0289
DEBUG - 2011-04-16 16:24:08 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:08 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:08 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Controller Class Initialized
ERROR - 2011-04-16 16:24:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:24:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:24:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:08 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:08 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:08 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:24:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:24:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:24:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:24:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:24:08 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:08 --> Total execution time: 0.0285
DEBUG - 2011-04-16 16:24:09 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:09 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:09 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Controller Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:09 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:09 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:09 --> Total execution time: 0.5847
DEBUG - 2011-04-16 16:24:10 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:10 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:10 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Controller Class Initialized
ERROR - 2011-04-16 16:24:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:24:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:24:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:10 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:10 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:10 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:24:10 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:10 --> Total execution time: 0.0293
DEBUG - 2011-04-16 16:24:19 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:19 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:19 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Controller Class Initialized
ERROR - 2011-04-16 16:24:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:24:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:24:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:19 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:19 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:19 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:24:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:24:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:24:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:24:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:24:19 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:19 --> Total execution time: 0.0297
DEBUG - 2011-04-16 16:24:20 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:20 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:20 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Controller Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:20 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:21 --> Total execution time: 0.4855
DEBUG - 2011-04-16 16:24:21 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:21 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:21 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Controller Class Initialized
ERROR - 2011-04-16 16:24:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:24:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:24:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:21 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:21 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:21 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:24:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:24:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:24:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:24:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:24:21 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:21 --> Total execution time: 0.0295
DEBUG - 2011-04-16 16:24:29 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:29 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:29 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Controller Class Initialized
ERROR - 2011-04-16 16:24:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:24:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:24:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:29 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:29 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:29 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:24:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:24:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:24:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:24:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:24:29 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:29 --> Total execution time: 0.0315
DEBUG - 2011-04-16 16:24:30 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:30 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:30 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Controller Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:31 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:31 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:31 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Controller Class Initialized
ERROR - 2011-04-16 16:24:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:24:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:24:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:31 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:31 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:31 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:24:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:24:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:24:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:24:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:24:31 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:31 --> Total execution time: 0.0677
DEBUG - 2011-04-16 16:24:36 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:36 --> Total execution time: 5.6911
DEBUG - 2011-04-16 16:24:39 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:39 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:39 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Controller Class Initialized
ERROR - 2011-04-16 16:24:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 16:24:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 16:24:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:39 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:39 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 16:24:39 --> Helper loaded: url_helper
DEBUG - 2011-04-16 16:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 16:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 16:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 16:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 16:24:39 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:39 --> Total execution time: 0.0357
DEBUG - 2011-04-16 16:24:40 --> Config Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Hooks Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Utf8 Class Initialized
DEBUG - 2011-04-16 16:24:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 16:24:40 --> URI Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Router Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Output Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Input Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 16:24:40 --> Language Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Loader Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Controller Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Model Class Initialized
DEBUG - 2011-04-16 16:24:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 16:24:40 --> Database Driver Class Initialized
DEBUG - 2011-04-16 16:24:41 --> Final output sent to browser
DEBUG - 2011-04-16 16:24:41 --> Total execution time: 0.6250
DEBUG - 2011-04-16 17:20:50 --> Config Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:20:50 --> URI Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Router Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Output Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Input Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:20:50 --> Language Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Loader Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Controller Class Initialized
ERROR - 2011-04-16 17:20:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:20:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:20:50 --> Model Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Model Class Initialized
DEBUG - 2011-04-16 17:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:20:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:20:50 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:20:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:20:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:20:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:20:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:20:50 --> Final output sent to browser
DEBUG - 2011-04-16 17:20:50 --> Total execution time: 0.3647
DEBUG - 2011-04-16 17:20:51 --> Config Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:20:51 --> URI Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Router Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Output Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Input Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:20:51 --> Language Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Loader Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Controller Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Model Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Model Class Initialized
DEBUG - 2011-04-16 17:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:20:51 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:20:52 --> Final output sent to browser
DEBUG - 2011-04-16 17:20:52 --> Total execution time: 0.6769
DEBUG - 2011-04-16 17:20:53 --> Config Class Initialized
DEBUG - 2011-04-16 17:20:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:20:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:20:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:20:53 --> URI Class Initialized
DEBUG - 2011-04-16 17:20:53 --> Router Class Initialized
ERROR - 2011-04-16 17:20:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:20:58 --> Config Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:20:58 --> URI Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Router Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Output Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Input Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:20:58 --> Language Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Loader Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Controller Class Initialized
ERROR - 2011-04-16 17:20:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:20:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:20:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:20:58 --> Model Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Model Class Initialized
DEBUG - 2011-04-16 17:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:20:58 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:20:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:20:58 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:20:58 --> Final output sent to browser
DEBUG - 2011-04-16 17:20:58 --> Total execution time: 0.0284
DEBUG - 2011-04-16 17:20:59 --> Config Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:20:59 --> URI Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Router Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Output Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Input Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:20:59 --> Language Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Loader Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Controller Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Model Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Model Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:20:59 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:20:59 --> Final output sent to browser
DEBUG - 2011-04-16 17:20:59 --> Total execution time: 0.5049
DEBUG - 2011-04-16 17:21:00 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:00 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:00 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:00 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:00 --> Router Class Initialized
ERROR - 2011-04-16 17:21:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:04 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:04 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:04 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:04 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:04 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:04 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:04 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:04 --> Total execution time: 0.0393
DEBUG - 2011-04-16 17:21:04 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:04 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:04 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Controller Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:04 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:05 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:05 --> Total execution time: 0.5520
DEBUG - 2011-04-16 17:21:06 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:06 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:06 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:06 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:06 --> Router Class Initialized
ERROR - 2011-04-16 17:21:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:10 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:10 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:10 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:10 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:10 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:10 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:10 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:10 --> Total execution time: 0.0306
DEBUG - 2011-04-16 17:21:11 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:11 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:11 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Controller Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:11 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:11 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:11 --> Total execution time: 0.5022
DEBUG - 2011-04-16 17:21:12 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:12 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:12 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:12 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:12 --> Router Class Initialized
ERROR - 2011-04-16 17:21:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:17 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:17 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:17 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:17 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:17 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:17 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:17 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:17 --> Total execution time: 0.0279
DEBUG - 2011-04-16 17:21:18 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:18 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:18 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Controller Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:18 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:18 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Router Class Initialized
ERROR - 2011-04-16 17:21:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-16 17:21:18 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:18 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:18 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:18 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:18 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:18 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:18 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:18 --> Total execution time: 0.0290
DEBUG - 2011-04-16 17:21:18 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:18 --> Total execution time: 0.5895
DEBUG - 2011-04-16 17:21:19 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:19 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:19 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:19 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:19 --> Router Class Initialized
ERROR - 2011-04-16 17:21:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:29 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:29 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:29 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:29 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:29 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:29 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:29 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:29 --> Total execution time: 0.0319
DEBUG - 2011-04-16 17:21:30 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:30 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:30 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Controller Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:30 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:30 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:30 --> Total execution time: 0.5453
DEBUG - 2011-04-16 17:21:31 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:31 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:31 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:31 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:31 --> Router Class Initialized
ERROR - 2011-04-16 17:21:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:37 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:37 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:37 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:37 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:37 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:37 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:37 --> Total execution time: 0.0286
DEBUG - 2011-04-16 17:21:37 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:37 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:37 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Controller Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:37 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:38 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:38 --> Total execution time: 0.5145
DEBUG - 2011-04-16 17:21:38 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:38 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:38 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:38 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:38 --> Router Class Initialized
ERROR - 2011-04-16 17:21:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:43 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:43 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:43 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:43 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:43 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:43 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:43 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:43 --> Total execution time: 0.0484
DEBUG - 2011-04-16 17:21:43 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:43 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:43 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Controller Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:43 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:44 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:44 --> Total execution time: 0.5148
DEBUG - 2011-04-16 17:21:45 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:45 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:45 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:45 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:45 --> Router Class Initialized
ERROR - 2011-04-16 17:21:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:48 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:48 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:48 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:48 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:48 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:48 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:48 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:48 --> Total execution time: 0.0275
DEBUG - 2011-04-16 17:21:49 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:49 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:49 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Controller Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:49 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:50 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:50 --> Total execution time: 0.6749
DEBUG - 2011-04-16 17:21:51 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:51 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:51 --> Router Class Initialized
ERROR - 2011-04-16 17:21:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:54 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:54 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:54 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:54 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:54 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:54 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:54 --> Total execution time: 0.0269
DEBUG - 2011-04-16 17:21:55 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:55 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:55 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Controller Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:55 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:55 --> Total execution time: 0.5798
DEBUG - 2011-04-16 17:21:57 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:57 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:57 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:57 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:57 --> Router Class Initialized
ERROR - 2011-04-16 17:21:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:21:59 --> Config Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:21:59 --> URI Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Router Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Output Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Input Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:21:59 --> Language Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Loader Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Controller Class Initialized
ERROR - 2011-04-16 17:21:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:21:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:59 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Model Class Initialized
DEBUG - 2011-04-16 17:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:21:59 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:21:59 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:21:59 --> Final output sent to browser
DEBUG - 2011-04-16 17:21:59 --> Total execution time: 0.0376
DEBUG - 2011-04-16 17:22:00 --> Config Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:22:00 --> URI Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Router Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Output Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Input Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:22:00 --> Language Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Loader Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Controller Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Model Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Model Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:22:00 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:22:00 --> Final output sent to browser
DEBUG - 2011-04-16 17:22:00 --> Total execution time: 0.5800
DEBUG - 2011-04-16 17:22:01 --> Config Class Initialized
DEBUG - 2011-04-16 17:22:01 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:22:01 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:22:01 --> URI Class Initialized
DEBUG - 2011-04-16 17:22:01 --> Router Class Initialized
ERROR - 2011-04-16 17:22:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:22:21 --> Config Class Initialized
DEBUG - 2011-04-16 17:22:21 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:22:21 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:22:21 --> URI Class Initialized
DEBUG - 2011-04-16 17:22:21 --> Router Class Initialized
ERROR - 2011-04-16 17:22:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:49:26 --> Config Class Initialized
DEBUG - 2011-04-16 17:49:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:49:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:49:26 --> URI Class Initialized
DEBUG - 2011-04-16 17:49:26 --> Router Class Initialized
ERROR - 2011-04-16 17:49:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-16 17:53:51 --> Config Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:53:51 --> URI Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Router Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Output Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Input Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:53:51 --> Language Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Loader Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Controller Class Initialized
ERROR - 2011-04-16 17:53:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 17:53:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 17:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:53:51 --> Model Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Model Class Initialized
DEBUG - 2011-04-16 17:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:53:51 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 17:53:51 --> Helper loaded: url_helper
DEBUG - 2011-04-16 17:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 17:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 17:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 17:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 17:53:51 --> Final output sent to browser
DEBUG - 2011-04-16 17:53:51 --> Total execution time: 0.0477
DEBUG - 2011-04-16 17:53:52 --> Config Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:53:52 --> URI Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Router Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Output Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Input Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 17:53:52 --> Language Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Loader Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Controller Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Model Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Model Class Initialized
DEBUG - 2011-04-16 17:53:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 17:53:52 --> Database Driver Class Initialized
DEBUG - 2011-04-16 17:53:53 --> Final output sent to browser
DEBUG - 2011-04-16 17:53:53 --> Total execution time: 0.8405
DEBUG - 2011-04-16 17:53:55 --> Config Class Initialized
DEBUG - 2011-04-16 17:53:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:53:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:53:55 --> URI Class Initialized
DEBUG - 2011-04-16 17:53:55 --> Router Class Initialized
ERROR - 2011-04-16 17:53:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 17:53:55 --> Config Class Initialized
DEBUG - 2011-04-16 17:53:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 17:53:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 17:53:55 --> URI Class Initialized
DEBUG - 2011-04-16 17:53:55 --> Router Class Initialized
ERROR - 2011-04-16 17:53:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 18:35:41 --> Config Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 18:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 18:35:41 --> URI Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Router Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Output Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Input Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 18:35:41 --> Language Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Loader Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Controller Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Model Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Model Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Model Class Initialized
DEBUG - 2011-04-16 18:35:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 18:35:41 --> Database Driver Class Initialized
DEBUG - 2011-04-16 18:35:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 18:35:42 --> Helper loaded: url_helper
DEBUG - 2011-04-16 18:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 18:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 18:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 18:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 18:35:42 --> Final output sent to browser
DEBUG - 2011-04-16 18:35:42 --> Total execution time: 0.7934
DEBUG - 2011-04-16 18:36:28 --> Config Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Hooks Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Utf8 Class Initialized
DEBUG - 2011-04-16 18:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 18:36:28 --> URI Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Router Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Output Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Input Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 18:36:28 --> Language Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Loader Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Controller Class Initialized
ERROR - 2011-04-16 18:36:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 18:36:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 18:36:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 18:36:28 --> Model Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Model Class Initialized
DEBUG - 2011-04-16 18:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 18:36:28 --> Database Driver Class Initialized
DEBUG - 2011-04-16 18:36:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 18:36:28 --> Helper loaded: url_helper
DEBUG - 2011-04-16 18:36:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 18:36:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 18:36:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 18:36:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 18:36:28 --> Final output sent to browser
DEBUG - 2011-04-16 18:36:28 --> Total execution time: 0.1885
DEBUG - 2011-04-16 18:52:09 --> Config Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Hooks Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Utf8 Class Initialized
DEBUG - 2011-04-16 18:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 18:52:09 --> URI Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Router Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Output Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Input Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 18:52:09 --> Language Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Loader Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Controller Class Initialized
ERROR - 2011-04-16 18:52:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 18:52:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 18:52:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 18:52:09 --> Model Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Model Class Initialized
DEBUG - 2011-04-16 18:52:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 18:52:09 --> Database Driver Class Initialized
DEBUG - 2011-04-16 18:52:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 18:52:09 --> Helper loaded: url_helper
DEBUG - 2011-04-16 18:52:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 18:52:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 18:52:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 18:52:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 18:52:09 --> Final output sent to browser
DEBUG - 2011-04-16 18:52:09 --> Total execution time: 0.0469
DEBUG - 2011-04-16 18:52:10 --> Config Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Hooks Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Utf8 Class Initialized
DEBUG - 2011-04-16 18:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 18:52:10 --> URI Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Router Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Output Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Input Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 18:52:10 --> Language Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Loader Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Controller Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Model Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Model Class Initialized
DEBUG - 2011-04-16 18:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 18:52:10 --> Database Driver Class Initialized
DEBUG - 2011-04-16 18:52:11 --> Final output sent to browser
DEBUG - 2011-04-16 18:52:11 --> Total execution time: 0.7220
DEBUG - 2011-04-16 18:52:13 --> Config Class Initialized
DEBUG - 2011-04-16 18:52:13 --> Hooks Class Initialized
DEBUG - 2011-04-16 18:52:13 --> Utf8 Class Initialized
DEBUG - 2011-04-16 18:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 18:52:13 --> URI Class Initialized
DEBUG - 2011-04-16 18:52:13 --> Router Class Initialized
ERROR - 2011-04-16 18:52:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 19:40:48 --> Config Class Initialized
DEBUG - 2011-04-16 19:40:48 --> Hooks Class Initialized
DEBUG - 2011-04-16 19:40:48 --> Utf8 Class Initialized
DEBUG - 2011-04-16 19:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 19:40:48 --> URI Class Initialized
DEBUG - 2011-04-16 19:40:48 --> Router Class Initialized
DEBUG - 2011-04-16 19:40:49 --> Output Class Initialized
DEBUG - 2011-04-16 19:40:49 --> Input Class Initialized
DEBUG - 2011-04-16 19:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 19:40:49 --> Language Class Initialized
DEBUG - 2011-04-16 19:40:49 --> Loader Class Initialized
DEBUG - 2011-04-16 19:40:49 --> Controller Class Initialized
ERROR - 2011-04-16 19:40:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 19:40:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 19:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 19:40:49 --> Model Class Initialized
DEBUG - 2011-04-16 19:40:49 --> Model Class Initialized
DEBUG - 2011-04-16 19:40:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 19:40:49 --> Database Driver Class Initialized
DEBUG - 2011-04-16 19:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 19:40:50 --> Helper loaded: url_helper
DEBUG - 2011-04-16 19:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 19:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 19:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 19:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 19:40:50 --> Final output sent to browser
DEBUG - 2011-04-16 19:40:50 --> Total execution time: 2.7693
DEBUG - 2011-04-16 19:40:53 --> Config Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Hooks Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Utf8 Class Initialized
DEBUG - 2011-04-16 19:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 19:40:53 --> URI Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Router Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Output Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Input Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 19:40:53 --> Language Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Loader Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Controller Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Model Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Model Class Initialized
DEBUG - 2011-04-16 19:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 19:40:53 --> Database Driver Class Initialized
DEBUG - 2011-04-16 19:40:54 --> Final output sent to browser
DEBUG - 2011-04-16 19:40:54 --> Total execution time: 0.7726
DEBUG - 2011-04-16 19:40:54 --> Config Class Initialized
DEBUG - 2011-04-16 19:40:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 19:40:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 19:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 19:40:54 --> URI Class Initialized
DEBUG - 2011-04-16 19:40:54 --> Router Class Initialized
DEBUG - 2011-04-16 19:40:54 --> No URI present. Default controller set.
DEBUG - 2011-04-16 19:40:54 --> Output Class Initialized
DEBUG - 2011-04-16 19:40:54 --> Input Class Initialized
DEBUG - 2011-04-16 19:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 19:40:54 --> Language Class Initialized
DEBUG - 2011-04-16 19:40:54 --> Loader Class Initialized
DEBUG - 2011-04-16 19:40:54 --> Controller Class Initialized
DEBUG - 2011-04-16 19:40:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 19:40:54 --> Helper loaded: url_helper
DEBUG - 2011-04-16 19:40:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 19:40:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 19:40:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 19:40:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 19:40:54 --> Final output sent to browser
DEBUG - 2011-04-16 19:40:54 --> Total execution time: 0.5726
DEBUG - 2011-04-16 20:00:46 --> Config Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 20:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 20:00:46 --> URI Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Router Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Output Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Input Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 20:00:46 --> Language Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Loader Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Controller Class Initialized
ERROR - 2011-04-16 20:00:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 20:00:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 20:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 20:00:46 --> Model Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Model Class Initialized
DEBUG - 2011-04-16 20:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 20:00:46 --> Database Driver Class Initialized
DEBUG - 2011-04-16 20:00:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 20:00:47 --> Helper loaded: url_helper
DEBUG - 2011-04-16 20:00:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 20:00:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 20:00:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 20:00:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 20:00:47 --> Final output sent to browser
DEBUG - 2011-04-16 20:00:47 --> Total execution time: 0.0489
DEBUG - 2011-04-16 20:00:50 --> Config Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 20:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 20:00:50 --> URI Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Router Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Output Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Input Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 20:00:50 --> Language Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Loader Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Controller Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Model Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Model Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 20:00:50 --> Database Driver Class Initialized
DEBUG - 2011-04-16 20:00:50 --> Final output sent to browser
DEBUG - 2011-04-16 20:00:50 --> Total execution time: 0.6190
DEBUG - 2011-04-16 20:00:51 --> Config Class Initialized
DEBUG - 2011-04-16 20:00:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 20:00:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 20:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 20:00:51 --> URI Class Initialized
DEBUG - 2011-04-16 20:00:51 --> Router Class Initialized
ERROR - 2011-04-16 20:00:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 20:53:46 --> Config Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 20:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 20:53:46 --> URI Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Router Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Output Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Input Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 20:53:46 --> Language Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Loader Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Controller Class Initialized
ERROR - 2011-04-16 20:53:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 20:53:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 20:53:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 20:53:46 --> Model Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Model Class Initialized
DEBUG - 2011-04-16 20:53:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 20:53:46 --> Database Driver Class Initialized
DEBUG - 2011-04-16 20:53:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 20:53:47 --> Helper loaded: url_helper
DEBUG - 2011-04-16 20:53:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 20:53:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 20:53:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 20:53:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 20:53:47 --> Final output sent to browser
DEBUG - 2011-04-16 20:53:47 --> Total execution time: 0.3576
DEBUG - 2011-04-16 20:53:47 --> Config Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Hooks Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Utf8 Class Initialized
DEBUG - 2011-04-16 20:53:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 20:53:47 --> URI Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Router Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Output Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Input Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 20:53:47 --> Language Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Loader Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Controller Class Initialized
DEBUG - 2011-04-16 20:53:47 --> Model Class Initialized
DEBUG - 2011-04-16 20:53:48 --> Model Class Initialized
DEBUG - 2011-04-16 20:53:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 20:53:48 --> Database Driver Class Initialized
DEBUG - 2011-04-16 20:53:48 --> Final output sent to browser
DEBUG - 2011-04-16 20:53:48 --> Total execution time: 0.6613
DEBUG - 2011-04-16 20:53:50 --> Config Class Initialized
DEBUG - 2011-04-16 20:53:50 --> Hooks Class Initialized
DEBUG - 2011-04-16 20:53:50 --> Utf8 Class Initialized
DEBUG - 2011-04-16 20:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 20:53:50 --> URI Class Initialized
DEBUG - 2011-04-16 20:53:50 --> Router Class Initialized
ERROR - 2011-04-16 20:53:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-16 20:54:03 --> Config Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Hooks Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Utf8 Class Initialized
DEBUG - 2011-04-16 20:54:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 20:54:03 --> URI Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Router Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Output Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Input Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 20:54:03 --> Language Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Loader Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Controller Class Initialized
ERROR - 2011-04-16 20:54:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 20:54:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 20:54:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 20:54:03 --> Model Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Model Class Initialized
DEBUG - 2011-04-16 20:54:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 20:54:03 --> Database Driver Class Initialized
DEBUG - 2011-04-16 20:54:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 20:54:03 --> Helper loaded: url_helper
DEBUG - 2011-04-16 20:54:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 20:54:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 20:54:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 20:54:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 20:54:03 --> Final output sent to browser
DEBUG - 2011-04-16 20:54:03 --> Total execution time: 0.0389
DEBUG - 2011-04-16 20:54:04 --> Config Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Hooks Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Utf8 Class Initialized
DEBUG - 2011-04-16 20:54:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 20:54:04 --> URI Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Router Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Output Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Input Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 20:54:04 --> Language Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Loader Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Controller Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Model Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Model Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 20:54:04 --> Database Driver Class Initialized
DEBUG - 2011-04-16 20:54:04 --> Final output sent to browser
DEBUG - 2011-04-16 20:54:04 --> Total execution time: 0.5502
DEBUG - 2011-04-16 22:07:15 --> Config Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Hooks Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Utf8 Class Initialized
DEBUG - 2011-04-16 22:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 22:07:15 --> URI Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Router Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Output Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Input Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 22:07:15 --> Language Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Loader Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Controller Class Initialized
ERROR - 2011-04-16 22:07:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-16 22:07:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-16 22:07:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 22:07:15 --> Model Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Model Class Initialized
DEBUG - 2011-04-16 22:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 22:07:15 --> Database Driver Class Initialized
DEBUG - 2011-04-16 22:07:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-16 22:07:15 --> Helper loaded: url_helper
DEBUG - 2011-04-16 22:07:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 22:07:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 22:07:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 22:07:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 22:07:15 --> Final output sent to browser
DEBUG - 2011-04-16 22:07:15 --> Total execution time: 0.3437
DEBUG - 2011-04-16 22:07:26 --> Config Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 22:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 22:07:26 --> URI Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Router Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Output Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Input Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 22:07:26 --> Language Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Loader Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Controller Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Model Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Model Class Initialized
DEBUG - 2011-04-16 22:07:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 22:07:26 --> Database Driver Class Initialized
DEBUG - 2011-04-16 22:07:27 --> Final output sent to browser
DEBUG - 2011-04-16 22:07:27 --> Total execution time: 1.2838
DEBUG - 2011-04-16 23:46:46 --> Config Class Initialized
DEBUG - 2011-04-16 23:46:46 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:46:46 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:46:46 --> URI Class Initialized
DEBUG - 2011-04-16 23:46:46 --> Router Class Initialized
ERROR - 2011-04-16 23:46:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-16 23:47:41 --> Config Class Initialized
DEBUG - 2011-04-16 23:47:41 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:47:41 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:47:41 --> URI Class Initialized
DEBUG - 2011-04-16 23:47:41 --> Router Class Initialized
DEBUG - 2011-04-16 23:47:41 --> No URI present. Default controller set.
DEBUG - 2011-04-16 23:47:41 --> Output Class Initialized
DEBUG - 2011-04-16 23:47:41 --> Input Class Initialized
DEBUG - 2011-04-16 23:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:47:41 --> Language Class Initialized
DEBUG - 2011-04-16 23:47:41 --> Loader Class Initialized
DEBUG - 2011-04-16 23:47:41 --> Controller Class Initialized
DEBUG - 2011-04-16 23:47:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-16 23:47:41 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:47:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:47:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:47:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:47:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:47:41 --> Final output sent to browser
DEBUG - 2011-04-16 23:47:41 --> Total execution time: 0.2811
DEBUG - 2011-04-16 23:47:56 --> Config Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:47:56 --> URI Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Router Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Output Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Input Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:47:56 --> Language Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Loader Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Controller Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Model Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Model Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Model Class Initialized
DEBUG - 2011-04-16 23:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:47:56 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:47:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:47:56 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:47:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:47:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:47:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:47:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:47:56 --> Final output sent to browser
DEBUG - 2011-04-16 23:47:56 --> Total execution time: 0.4093
DEBUG - 2011-04-16 23:48:54 --> Config Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:48:54 --> URI Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Router Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Output Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Input Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:48:54 --> Language Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Loader Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Controller Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Model Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Model Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Model Class Initialized
DEBUG - 2011-04-16 23:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:48:54 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:48:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:48:54 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:48:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:48:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:48:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:48:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:48:54 --> Final output sent to browser
DEBUG - 2011-04-16 23:48:54 --> Total execution time: 0.2868
DEBUG - 2011-04-16 23:48:58 --> Config Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:48:58 --> URI Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Router Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Output Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Input Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:48:58 --> Language Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Loader Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Controller Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Model Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Model Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Model Class Initialized
DEBUG - 2011-04-16 23:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:48:58 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:48:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:48:58 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:48:58 --> Final output sent to browser
DEBUG - 2011-04-16 23:48:58 --> Total execution time: 0.0559
DEBUG - 2011-04-16 23:49:22 --> Config Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:49:22 --> URI Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Router Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Output Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Input Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:49:22 --> Language Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Loader Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Controller Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:49:22 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:49:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:49:23 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:49:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:49:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:49:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:49:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:49:23 --> Final output sent to browser
DEBUG - 2011-04-16 23:49:23 --> Total execution time: 0.5250
DEBUG - 2011-04-16 23:49:26 --> Config Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:49:26 --> URI Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Router Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Output Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Input Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:49:26 --> Language Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Loader Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Controller Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:49:26 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:49:26 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:49:26 --> Final output sent to browser
DEBUG - 2011-04-16 23:49:26 --> Total execution time: 0.0504
DEBUG - 2011-04-16 23:49:27 --> Config Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:49:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:49:27 --> URI Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Router Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Output Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Input Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:49:27 --> Language Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Loader Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Controller Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:49:27 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:49:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:49:27 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:49:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:49:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:49:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:49:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:49:27 --> Final output sent to browser
DEBUG - 2011-04-16 23:49:27 --> Total execution time: 0.0471
DEBUG - 2011-04-16 23:49:51 --> Config Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:49:51 --> URI Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Router Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Output Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Input Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:49:51 --> Language Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Loader Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Controller Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:49:51 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:49:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:49:52 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:49:52 --> Final output sent to browser
DEBUG - 2011-04-16 23:49:52 --> Total execution time: 0.4361
DEBUG - 2011-04-16 23:49:55 --> Config Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:49:55 --> URI Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Router Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Output Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Input Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:49:55 --> Language Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Loader Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Controller Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Model Class Initialized
DEBUG - 2011-04-16 23:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:49:55 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:49:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:49:55 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:49:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:49:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:49:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:49:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:49:55 --> Final output sent to browser
DEBUG - 2011-04-16 23:49:55 --> Total execution time: 0.0536
DEBUG - 2011-04-16 23:50:06 --> Config Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:50:06 --> URI Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Router Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Output Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Input Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:50:06 --> Language Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Loader Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Controller Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:50:06 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:50:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:50:07 --> Final output sent to browser
DEBUG - 2011-04-16 23:50:07 --> Total execution time: 0.4354
DEBUG - 2011-04-16 23:50:10 --> Config Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:50:10 --> URI Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Router Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Output Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Input Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:50:10 --> Language Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Loader Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Controller Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:50:10 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:50:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:50:10 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:50:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:50:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:50:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:50:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:50:10 --> Final output sent to browser
DEBUG - 2011-04-16 23:50:10 --> Total execution time: 0.0424
DEBUG - 2011-04-16 23:50:20 --> Config Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:50:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:50:20 --> URI Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Router Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Output Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Input Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:50:20 --> Language Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Loader Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Controller Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:50:20 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:50:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:50:20 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:50:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:50:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:50:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:50:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:50:20 --> Final output sent to browser
DEBUG - 2011-04-16 23:50:20 --> Total execution time: 0.1916
DEBUG - 2011-04-16 23:50:23 --> Config Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:50:23 --> URI Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Router Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Output Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Input Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:50:23 --> Language Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Loader Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Controller Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Model Class Initialized
DEBUG - 2011-04-16 23:50:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:50:23 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:50:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:50:23 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:50:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:50:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:50:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:50:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:50:23 --> Final output sent to browser
DEBUG - 2011-04-16 23:50:23 --> Total execution time: 0.0493
DEBUG - 2011-04-16 23:51:10 --> Config Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:51:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:51:10 --> URI Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Router Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Output Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Input Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:51:10 --> Language Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Loader Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Controller Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Model Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Model Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Model Class Initialized
DEBUG - 2011-04-16 23:51:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:51:10 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:51:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:51:10 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:51:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:51:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:51:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:51:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:51:10 --> Final output sent to browser
DEBUG - 2011-04-16 23:51:10 --> Total execution time: 0.1534
DEBUG - 2011-04-16 23:51:13 --> Config Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Hooks Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Utf8 Class Initialized
DEBUG - 2011-04-16 23:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-16 23:51:13 --> URI Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Router Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Output Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Input Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-16 23:51:13 --> Language Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Loader Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Controller Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Model Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Model Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Model Class Initialized
DEBUG - 2011-04-16 23:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-16 23:51:13 --> Database Driver Class Initialized
DEBUG - 2011-04-16 23:51:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-16 23:51:13 --> Helper loaded: url_helper
DEBUG - 2011-04-16 23:51:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-16 23:51:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-16 23:51:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-16 23:51:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-16 23:51:13 --> Final output sent to browser
DEBUG - 2011-04-16 23:51:13 --> Total execution time: 0.0445

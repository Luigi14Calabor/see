<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-03 00:00:50 --> Config Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 00:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 00:00:50 --> URI Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Router Class Initialized
ERROR - 2011-09-03 00:00:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-03 00:00:50 --> Config Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 00:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 00:00:50 --> URI Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Router Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Output Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Input Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 00:00:50 --> Language Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Loader Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Controller Class Initialized
ERROR - 2011-09-03 00:00:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 00:00:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 00:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 00:00:50 --> Model Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Model Class Initialized
DEBUG - 2011-09-03 00:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 00:00:50 --> Database Driver Class Initialized
DEBUG - 2011-09-03 00:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 00:00:50 --> Helper loaded: url_helper
DEBUG - 2011-09-03 00:00:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 00:00:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 00:00:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 00:00:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 00:00:50 --> Final output sent to browser
DEBUG - 2011-09-03 00:00:50 --> Total execution time: 0.0298
DEBUG - 2011-09-03 00:37:10 --> Config Class Initialized
DEBUG - 2011-09-03 00:37:10 --> Hooks Class Initialized
DEBUG - 2011-09-03 00:37:10 --> Utf8 Class Initialized
DEBUG - 2011-09-03 00:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 00:37:10 --> URI Class Initialized
DEBUG - 2011-09-03 00:37:10 --> Router Class Initialized
DEBUG - 2011-09-03 00:37:10 --> No URI present. Default controller set.
DEBUG - 2011-09-03 00:37:10 --> Output Class Initialized
DEBUG - 2011-09-03 00:37:10 --> Input Class Initialized
DEBUG - 2011-09-03 00:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 00:37:10 --> Language Class Initialized
DEBUG - 2011-09-03 00:37:10 --> Loader Class Initialized
DEBUG - 2011-09-03 00:37:10 --> Controller Class Initialized
DEBUG - 2011-09-03 00:37:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-03 00:37:10 --> Helper loaded: url_helper
DEBUG - 2011-09-03 00:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 00:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 00:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 00:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 00:37:10 --> Final output sent to browser
DEBUG - 2011-09-03 00:37:10 --> Total execution time: 0.0408
DEBUG - 2011-09-03 01:32:04 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:04 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Router Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Output Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Input Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 01:32:04 --> Language Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Loader Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Controller Class Initialized
ERROR - 2011-09-03 01:32:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 01:32:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 01:32:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 01:32:04 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 01:32:04 --> Database Driver Class Initialized
DEBUG - 2011-09-03 01:32:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 01:32:04 --> Helper loaded: url_helper
DEBUG - 2011-09-03 01:32:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 01:32:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 01:32:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 01:32:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 01:32:04 --> Final output sent to browser
DEBUG - 2011-09-03 01:32:04 --> Total execution time: 0.1761
DEBUG - 2011-09-03 01:32:05 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:05 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Router Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Output Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Input Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 01:32:05 --> Language Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Loader Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Controller Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 01:32:05 --> Database Driver Class Initialized
DEBUG - 2011-09-03 01:32:07 --> Final output sent to browser
DEBUG - 2011-09-03 01:32:07 --> Total execution time: 2.3856
DEBUG - 2011-09-03 01:32:08 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:08 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:08 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:08 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:08 --> Router Class Initialized
ERROR - 2011-09-03 01:32:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 01:32:09 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:09 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:09 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:09 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:09 --> Router Class Initialized
ERROR - 2011-09-03 01:32:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 01:32:09 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:09 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:09 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:09 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:09 --> Router Class Initialized
ERROR - 2011-09-03 01:32:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 01:32:23 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:23 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Router Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Output Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Input Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 01:32:23 --> Language Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Loader Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Controller Class Initialized
ERROR - 2011-09-03 01:32:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 01:32:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 01:32:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 01:32:23 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 01:32:23 --> Database Driver Class Initialized
DEBUG - 2011-09-03 01:32:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 01:32:23 --> Helper loaded: url_helper
DEBUG - 2011-09-03 01:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 01:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 01:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 01:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 01:32:23 --> Final output sent to browser
DEBUG - 2011-09-03 01:32:23 --> Total execution time: 0.1833
DEBUG - 2011-09-03 01:32:24 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:24 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Router Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Output Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Input Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 01:32:24 --> Language Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Loader Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Controller Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 01:32:24 --> Database Driver Class Initialized
DEBUG - 2011-09-03 01:32:25 --> Final output sent to browser
DEBUG - 2011-09-03 01:32:25 --> Total execution time: 0.8466
DEBUG - 2011-09-03 01:32:48 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:48 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Router Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Output Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Input Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 01:32:48 --> Language Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Loader Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Controller Class Initialized
ERROR - 2011-09-03 01:32:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 01:32:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 01:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 01:32:48 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 01:32:48 --> Database Driver Class Initialized
DEBUG - 2011-09-03 01:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 01:32:48 --> Helper loaded: url_helper
DEBUG - 2011-09-03 01:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 01:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 01:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 01:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 01:32:48 --> Final output sent to browser
DEBUG - 2011-09-03 01:32:48 --> Total execution time: 0.0995
DEBUG - 2011-09-03 01:32:49 --> Config Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Hooks Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Utf8 Class Initialized
DEBUG - 2011-09-03 01:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 01:32:49 --> URI Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Router Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Output Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Input Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 01:32:49 --> Language Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Loader Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Controller Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Model Class Initialized
DEBUG - 2011-09-03 01:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 01:32:49 --> Database Driver Class Initialized
DEBUG - 2011-09-03 01:32:52 --> Final output sent to browser
DEBUG - 2011-09-03 01:32:52 --> Total execution time: 2.7844
DEBUG - 2011-09-03 02:12:48 --> Config Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:12:48 --> URI Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Router Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Output Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Input Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:12:48 --> Language Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Loader Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Controller Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Model Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Model Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Model Class Initialized
DEBUG - 2011-09-03 02:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:12:48 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:12:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:12:50 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:12:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:12:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:12:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:12:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:12:50 --> Final output sent to browser
DEBUG - 2011-09-03 02:12:50 --> Total execution time: 2.0560
DEBUG - 2011-09-03 02:12:53 --> Config Class Initialized
DEBUG - 2011-09-03 02:12:53 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:12:53 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:12:53 --> URI Class Initialized
DEBUG - 2011-09-03 02:12:53 --> Router Class Initialized
ERROR - 2011-09-03 02:12:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 02:19:40 --> Config Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:19:40 --> URI Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Router Class Initialized
ERROR - 2011-09-03 02:19:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-03 02:19:40 --> Config Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:19:40 --> URI Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Router Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Output Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Input Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:19:40 --> Language Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Loader Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Controller Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Model Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Model Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Model Class Initialized
DEBUG - 2011-09-03 02:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:19:40 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:19:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:19:40 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:19:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:19:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:19:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:19:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:19:40 --> Final output sent to browser
DEBUG - 2011-09-03 02:19:40 --> Total execution time: 0.1461
DEBUG - 2011-09-03 02:47:46 --> Config Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Config Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:47:46 --> URI Class Initialized
DEBUG - 2011-09-03 02:47:46 --> URI Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Router Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Router Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Output Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Output Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Input Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Input Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:47:46 --> Language Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Language Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Loader Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Loader Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Controller Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Controller Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Model Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Model Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Model Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Model Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Model Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Model Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:47:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:47:46 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:47:46 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:47:48 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:47:48 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:47:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:47:48 --> Final output sent to browser
DEBUG - 2011-09-03 02:47:48 --> Total execution time: 2.2381
DEBUG - 2011-09-03 02:47:48 --> Final output sent to browser
DEBUG - 2011-09-03 02:47:48 --> Total execution time: 2.2510
DEBUG - 2011-09-03 02:47:53 --> Config Class Initialized
DEBUG - 2011-09-03 02:47:53 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:47:53 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:47:53 --> URI Class Initialized
DEBUG - 2011-09-03 02:47:53 --> Router Class Initialized
ERROR - 2011-09-03 02:47:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 02:48:21 --> Config Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:48:21 --> URI Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Router Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Output Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Input Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:48:21 --> Language Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Loader Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Controller Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:48:21 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:48:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:48:21 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:48:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:48:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:48:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:48:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:48:21 --> Final output sent to browser
DEBUG - 2011-09-03 02:48:21 --> Total execution time: 0.0575
DEBUG - 2011-09-03 02:48:23 --> Config Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:48:23 --> URI Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Router Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Output Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Input Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:48:23 --> Language Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Loader Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Controller Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:48:23 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:48:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:48:23 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:48:23 --> Final output sent to browser
DEBUG - 2011-09-03 02:48:23 --> Total execution time: 0.0448
DEBUG - 2011-09-03 02:48:24 --> Config Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:48:24 --> URI Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Router Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Output Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Input Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:48:24 --> Language Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Loader Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Controller Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:48:24 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:48:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:48:24 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:48:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:48:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:48:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:48:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:48:24 --> Final output sent to browser
DEBUG - 2011-09-03 02:48:24 --> Total execution time: 0.0484
DEBUG - 2011-09-03 02:48:25 --> Config Class Initialized
DEBUG - 2011-09-03 02:48:25 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:48:25 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:48:25 --> URI Class Initialized
DEBUG - 2011-09-03 02:48:25 --> Router Class Initialized
ERROR - 2011-09-03 02:48:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 02:48:59 --> Config Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:48:59 --> URI Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Router Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Output Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Input Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:48:59 --> Language Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Loader Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Controller Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Model Class Initialized
DEBUG - 2011-09-03 02:48:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:48:59 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:48:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:48:59 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:48:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:48:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:48:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:48:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:48:59 --> Final output sent to browser
DEBUG - 2011-09-03 02:48:59 --> Total execution time: 0.2835
DEBUG - 2011-09-03 02:49:00 --> Config Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:49:00 --> URI Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Router Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Output Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Input Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:49:00 --> Language Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Loader Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Controller Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:49:00 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:49:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:49:00 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:49:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:49:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:49:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:49:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:49:00 --> Final output sent to browser
DEBUG - 2011-09-03 02:49:00 --> Total execution time: 0.0490
DEBUG - 2011-09-03 02:49:01 --> Config Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:49:01 --> URI Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Router Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Output Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Input Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:49:01 --> Language Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Loader Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Controller Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:49:01 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:49:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:49:01 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:49:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:49:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:49:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:49:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:49:01 --> Final output sent to browser
DEBUG - 2011-09-03 02:49:01 --> Total execution time: 0.0510
DEBUG - 2011-09-03 02:49:02 --> Config Class Initialized
DEBUG - 2011-09-03 02:49:02 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:49:02 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:49:02 --> URI Class Initialized
DEBUG - 2011-09-03 02:49:02 --> Router Class Initialized
ERROR - 2011-09-03 02:49:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 02:49:49 --> Config Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:49:49 --> URI Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Router Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Output Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Input Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:49:49 --> Language Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Loader Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Controller Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:49:49 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:49:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:49:50 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:49:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:49:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:49:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:49:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:49:50 --> Final output sent to browser
DEBUG - 2011-09-03 02:49:50 --> Total execution time: 0.4783
DEBUG - 2011-09-03 02:49:52 --> Config Class Initialized
DEBUG - 2011-09-03 02:49:52 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:49:52 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:49:52 --> URI Class Initialized
DEBUG - 2011-09-03 02:49:52 --> Router Class Initialized
ERROR - 2011-09-03 02:49:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 02:49:54 --> Config Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:49:54 --> URI Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Router Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Output Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Input Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:49:54 --> Language Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Loader Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Controller Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:49:54 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:49:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:49:54 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:49:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:49:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:49:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:49:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:49:54 --> Final output sent to browser
DEBUG - 2011-09-03 02:49:54 --> Total execution time: 0.0483
DEBUG - 2011-09-03 02:49:57 --> Config Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:49:57 --> URI Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Router Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Output Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Input Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:49:57 --> Language Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Loader Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Controller Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Model Class Initialized
DEBUG - 2011-09-03 02:49:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:49:57 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:49:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:49:57 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:49:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:49:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:49:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:49:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:49:57 --> Final output sent to browser
DEBUG - 2011-09-03 02:49:57 --> Total execution time: 0.0951
DEBUG - 2011-09-03 02:50:00 --> Config Class Initialized
DEBUG - 2011-09-03 02:50:00 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:50:00 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:50:00 --> URI Class Initialized
DEBUG - 2011-09-03 02:50:00 --> Router Class Initialized
ERROR - 2011-09-03 02:50:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 02:50:07 --> Config Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:50:07 --> URI Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Router Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Output Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Input Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:50:07 --> Language Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Loader Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Controller Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:50:07 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Config Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:50:08 --> URI Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Router Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Output Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Input Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:50:08 --> Language Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Loader Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Controller Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:50:08 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:50:09 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:50:09 --> Final output sent to browser
DEBUG - 2011-09-03 02:50:09 --> Total execution time: 1.4101
DEBUG - 2011-09-03 02:50:09 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:50:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:50:09 --> Final output sent to browser
DEBUG - 2011-09-03 02:50:09 --> Total execution time: 1.0268
DEBUG - 2011-09-03 02:50:10 --> Config Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:50:10 --> URI Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Router Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Output Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Input Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:50:10 --> Language Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Loader Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Controller Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:50:10 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:50:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:50:10 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:50:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:50:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:50:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:50:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:50:10 --> Final output sent to browser
DEBUG - 2011-09-03 02:50:10 --> Total execution time: 0.0457
DEBUG - 2011-09-03 02:50:11 --> Config Class Initialized
DEBUG - 2011-09-03 02:50:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:50:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:50:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:50:11 --> URI Class Initialized
DEBUG - 2011-09-03 02:50:11 --> Router Class Initialized
ERROR - 2011-09-03 02:50:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 02:50:20 --> Config Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:50:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:50:20 --> URI Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Router Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Output Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Input Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 02:50:20 --> Language Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Loader Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Controller Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Model Class Initialized
DEBUG - 2011-09-03 02:50:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 02:50:20 --> Database Driver Class Initialized
DEBUG - 2011-09-03 02:50:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 02:50:20 --> Helper loaded: url_helper
DEBUG - 2011-09-03 02:50:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 02:50:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 02:50:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 02:50:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 02:50:20 --> Final output sent to browser
DEBUG - 2011-09-03 02:50:20 --> Total execution time: 0.0996
DEBUG - 2011-09-03 02:50:23 --> Config Class Initialized
DEBUG - 2011-09-03 02:50:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 02:50:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 02:50:23 --> URI Class Initialized
DEBUG - 2011-09-03 02:50:23 --> Router Class Initialized
ERROR - 2011-09-03 02:50:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 03:03:29 --> Config Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:03:29 --> URI Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Router Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Output Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Input Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 03:03:29 --> Language Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Loader Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Controller Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Model Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Model Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Model Class Initialized
DEBUG - 2011-09-03 03:03:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 03:03:29 --> Database Driver Class Initialized
DEBUG - 2011-09-03 03:03:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 03:03:29 --> Helper loaded: url_helper
DEBUG - 2011-09-03 03:03:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 03:03:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 03:03:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 03:03:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 03:03:29 --> Final output sent to browser
DEBUG - 2011-09-03 03:03:29 --> Total execution time: 0.5642
DEBUG - 2011-09-03 03:03:31 --> Config Class Initialized
DEBUG - 2011-09-03 03:03:31 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:03:31 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:03:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:03:31 --> URI Class Initialized
DEBUG - 2011-09-03 03:03:31 --> Router Class Initialized
ERROR - 2011-09-03 03:03:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 03:03:38 --> Config Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:03:38 --> URI Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Router Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Output Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Input Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 03:03:38 --> Language Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Loader Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Controller Class Initialized
ERROR - 2011-09-03 03:03:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 03:03:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 03:03:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 03:03:38 --> Model Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Model Class Initialized
DEBUG - 2011-09-03 03:03:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 03:03:38 --> Database Driver Class Initialized
DEBUG - 2011-09-03 03:03:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 03:03:38 --> Helper loaded: url_helper
DEBUG - 2011-09-03 03:03:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 03:03:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 03:03:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 03:03:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 03:03:38 --> Final output sent to browser
DEBUG - 2011-09-03 03:03:38 --> Total execution time: 0.0913
DEBUG - 2011-09-03 03:03:39 --> Config Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:03:39 --> URI Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Router Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Output Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Input Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 03:03:39 --> Language Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Loader Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Controller Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Model Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Model Class Initialized
DEBUG - 2011-09-03 03:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 03:03:39 --> Database Driver Class Initialized
DEBUG - 2011-09-03 03:03:40 --> Final output sent to browser
DEBUG - 2011-09-03 03:03:40 --> Total execution time: 0.5875
DEBUG - 2011-09-03 03:03:41 --> Config Class Initialized
DEBUG - 2011-09-03 03:03:41 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:03:41 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:03:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:03:41 --> URI Class Initialized
DEBUG - 2011-09-03 03:03:41 --> Router Class Initialized
ERROR - 2011-09-03 03:03:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 03:40:05 --> Config Class Initialized
DEBUG - 2011-09-03 03:40:05 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:40:05 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:40:05 --> URI Class Initialized
DEBUG - 2011-09-03 03:40:05 --> Router Class Initialized
DEBUG - 2011-09-03 03:40:05 --> Output Class Initialized
DEBUG - 2011-09-03 03:40:05 --> Input Class Initialized
DEBUG - 2011-09-03 03:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 03:40:05 --> Language Class Initialized
DEBUG - 2011-09-03 03:40:06 --> Loader Class Initialized
DEBUG - 2011-09-03 03:40:06 --> Controller Class Initialized
DEBUG - 2011-09-03 03:40:06 --> Model Class Initialized
DEBUG - 2011-09-03 03:40:06 --> Model Class Initialized
DEBUG - 2011-09-03 03:40:06 --> Model Class Initialized
DEBUG - 2011-09-03 03:40:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 03:40:07 --> Database Driver Class Initialized
DEBUG - 2011-09-03 03:40:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 03:40:15 --> Helper loaded: url_helper
DEBUG - 2011-09-03 03:40:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 03:40:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 03:40:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 03:40:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 03:40:16 --> Final output sent to browser
DEBUG - 2011-09-03 03:40:16 --> Total execution time: 11.2675
DEBUG - 2011-09-03 03:40:17 --> Config Class Initialized
DEBUG - 2011-09-03 03:40:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:40:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:40:17 --> URI Class Initialized
DEBUG - 2011-09-03 03:40:17 --> Router Class Initialized
ERROR - 2011-09-03 03:40:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 03:41:05 --> Config Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:41:05 --> URI Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Router Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Output Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Input Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 03:41:05 --> Language Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Loader Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Controller Class Initialized
ERROR - 2011-09-03 03:41:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 03:41:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 03:41:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 03:41:05 --> Model Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Model Class Initialized
DEBUG - 2011-09-03 03:41:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 03:41:05 --> Database Driver Class Initialized
DEBUG - 2011-09-03 03:41:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 03:41:05 --> Helper loaded: url_helper
DEBUG - 2011-09-03 03:41:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 03:41:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 03:41:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 03:41:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 03:41:05 --> Final output sent to browser
DEBUG - 2011-09-03 03:41:05 --> Total execution time: 0.1351
DEBUG - 2011-09-03 03:41:06 --> Config Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:41:06 --> URI Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Router Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Output Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Input Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 03:41:06 --> Language Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Loader Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Controller Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Model Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Model Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 03:41:06 --> Database Driver Class Initialized
DEBUG - 2011-09-03 03:41:06 --> Final output sent to browser
DEBUG - 2011-09-03 03:41:06 --> Total execution time: 0.7320
DEBUG - 2011-09-03 03:42:16 --> Config Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:42:16 --> URI Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Router Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Output Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Input Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 03:42:16 --> Language Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Loader Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Controller Class Initialized
ERROR - 2011-09-03 03:42:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 03:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 03:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 03:42:16 --> Model Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Model Class Initialized
DEBUG - 2011-09-03 03:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 03:42:16 --> Database Driver Class Initialized
DEBUG - 2011-09-03 03:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 03:42:16 --> Helper loaded: url_helper
DEBUG - 2011-09-03 03:42:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 03:42:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 03:42:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 03:42:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 03:42:16 --> Final output sent to browser
DEBUG - 2011-09-03 03:42:16 --> Total execution time: 0.0491
DEBUG - 2011-09-03 03:42:17 --> Config Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 03:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 03:42:17 --> URI Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Router Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Output Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Input Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 03:42:17 --> Language Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Loader Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Controller Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Model Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Model Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 03:42:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 03:42:17 --> Final output sent to browser
DEBUG - 2011-09-03 03:42:17 --> Total execution time: 0.6963
DEBUG - 2011-09-03 04:01:49 --> Config Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:01:49 --> URI Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Router Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Output Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Input Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:01:49 --> Language Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Loader Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Controller Class Initialized
ERROR - 2011-09-03 04:01:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 04:01:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 04:01:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:01:49 --> Model Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Model Class Initialized
DEBUG - 2011-09-03 04:01:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:01:49 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:01:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:01:49 --> Helper loaded: url_helper
DEBUG - 2011-09-03 04:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 04:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 04:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 04:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 04:01:49 --> Final output sent to browser
DEBUG - 2011-09-03 04:01:49 --> Total execution time: 0.2164
DEBUG - 2011-09-03 04:01:50 --> Config Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:01:50 --> URI Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Router Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Output Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Input Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:01:50 --> Language Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Loader Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Controller Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Model Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Model Class Initialized
DEBUG - 2011-09-03 04:01:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:01:50 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:01:51 --> Final output sent to browser
DEBUG - 2011-09-03 04:01:51 --> Total execution time: 1.0013
DEBUG - 2011-09-03 04:01:54 --> Config Class Initialized
DEBUG - 2011-09-03 04:01:54 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:01:54 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:01:54 --> URI Class Initialized
DEBUG - 2011-09-03 04:01:54 --> Router Class Initialized
ERROR - 2011-09-03 04:01:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 04:01:54 --> Config Class Initialized
DEBUG - 2011-09-03 04:01:54 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:01:54 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:01:54 --> URI Class Initialized
DEBUG - 2011-09-03 04:01:54 --> Router Class Initialized
ERROR - 2011-09-03 04:01:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 04:02:28 --> Config Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:02:28 --> URI Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Router Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Output Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Input Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:02:28 --> Language Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Loader Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Controller Class Initialized
ERROR - 2011-09-03 04:02:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 04:02:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 04:02:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:02:28 --> Model Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Model Class Initialized
DEBUG - 2011-09-03 04:02:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:02:28 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:02:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:02:28 --> Helper loaded: url_helper
DEBUG - 2011-09-03 04:02:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 04:02:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 04:02:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 04:02:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 04:02:28 --> Final output sent to browser
DEBUG - 2011-09-03 04:02:28 --> Total execution time: 0.0290
DEBUG - 2011-09-03 04:02:30 --> Config Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:02:30 --> URI Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Router Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Output Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Input Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:02:30 --> Language Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Loader Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Controller Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Model Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Model Class Initialized
DEBUG - 2011-09-03 04:02:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:02:30 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:02:31 --> Final output sent to browser
DEBUG - 2011-09-03 04:02:31 --> Total execution time: 0.6694
DEBUG - 2011-09-03 04:02:50 --> Config Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:02:50 --> URI Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Router Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Output Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Input Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:02:50 --> Language Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Loader Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Controller Class Initialized
ERROR - 2011-09-03 04:02:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 04:02:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 04:02:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:02:50 --> Model Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Model Class Initialized
DEBUG - 2011-09-03 04:02:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:02:50 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:02:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:02:50 --> Helper loaded: url_helper
DEBUG - 2011-09-03 04:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 04:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 04:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 04:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 04:02:50 --> Final output sent to browser
DEBUG - 2011-09-03 04:02:50 --> Total execution time: 0.0266
DEBUG - 2011-09-03 04:02:52 --> Config Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:02:52 --> URI Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Router Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Output Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Input Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:02:52 --> Language Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Loader Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Controller Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Model Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Model Class Initialized
DEBUG - 2011-09-03 04:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:02:52 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:02:53 --> Final output sent to browser
DEBUG - 2011-09-03 04:02:53 --> Total execution time: 1.4545
DEBUG - 2011-09-03 04:03:05 --> Config Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:03:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:03:05 --> URI Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Router Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Output Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Input Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:03:05 --> Language Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Loader Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Controller Class Initialized
ERROR - 2011-09-03 04:03:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 04:03:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 04:03:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:03:05 --> Model Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Model Class Initialized
DEBUG - 2011-09-03 04:03:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:03:05 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:03:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:03:06 --> Helper loaded: url_helper
DEBUG - 2011-09-03 04:03:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 04:03:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 04:03:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 04:03:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 04:03:06 --> Final output sent to browser
DEBUG - 2011-09-03 04:03:06 --> Total execution time: 0.0377
DEBUG - 2011-09-03 04:03:07 --> Config Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:03:07 --> URI Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Router Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Output Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Input Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:03:07 --> Language Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Loader Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Controller Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Model Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Model Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:03:07 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:03:07 --> Final output sent to browser
DEBUG - 2011-09-03 04:03:07 --> Total execution time: 0.6474
DEBUG - 2011-09-03 04:38:01 --> Config Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:38:01 --> URI Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Router Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Output Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Input Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:38:01 --> Language Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Loader Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Controller Class Initialized
ERROR - 2011-09-03 04:38:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 04:38:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 04:38:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:38:01 --> Model Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Model Class Initialized
DEBUG - 2011-09-03 04:38:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:38:01 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:38:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:38:02 --> Helper loaded: url_helper
DEBUG - 2011-09-03 04:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 04:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 04:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 04:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 04:38:02 --> Final output sent to browser
DEBUG - 2011-09-03 04:38:02 --> Total execution time: 0.8616
DEBUG - 2011-09-03 04:38:25 --> Config Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:38:25 --> URI Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Router Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Output Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Input Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:38:25 --> Language Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Loader Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Controller Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Model Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Model Class Initialized
DEBUG - 2011-09-03 04:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:38:25 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:38:26 --> Final output sent to browser
DEBUG - 2011-09-03 04:38:26 --> Total execution time: 0.6133
DEBUG - 2011-09-03 04:39:04 --> Config Class Initialized
DEBUG - 2011-09-03 04:39:04 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:39:04 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:39:04 --> URI Class Initialized
DEBUG - 2011-09-03 04:39:04 --> Router Class Initialized
ERROR - 2011-09-03 04:39:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 04:40:01 --> Config Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:40:01 --> URI Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Router Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Output Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Input Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:40:01 --> Language Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Loader Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Controller Class Initialized
ERROR - 2011-09-03 04:40:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 04:40:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 04:40:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:40:01 --> Model Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Model Class Initialized
DEBUG - 2011-09-03 04:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:40:01 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:40:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:40:02 --> Helper loaded: url_helper
DEBUG - 2011-09-03 04:40:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 04:40:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 04:40:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 04:40:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 04:40:02 --> Final output sent to browser
DEBUG - 2011-09-03 04:40:02 --> Total execution time: 0.1178
DEBUG - 2011-09-03 04:40:23 --> Config Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:40:23 --> URI Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Router Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Output Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Input Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:40:23 --> Language Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Loader Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Controller Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Model Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Model Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:40:23 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:40:23 --> Final output sent to browser
DEBUG - 2011-09-03 04:40:23 --> Total execution time: 0.4984
DEBUG - 2011-09-03 04:54:50 --> Config Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:54:50 --> URI Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Router Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Output Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Input Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:54:50 --> Language Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Loader Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Controller Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Model Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Model Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Model Class Initialized
DEBUG - 2011-09-03 04:54:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:54:50 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:54:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 04:54:50 --> Helper loaded: url_helper
DEBUG - 2011-09-03 04:54:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 04:54:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 04:54:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 04:54:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 04:54:50 --> Final output sent to browser
DEBUG - 2011-09-03 04:54:50 --> Total execution time: 0.7402
DEBUG - 2011-09-03 04:55:08 --> Config Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:55:08 --> URI Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Router Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Output Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Input Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:55:08 --> Language Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Loader Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Controller Class Initialized
ERROR - 2011-09-03 04:55:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 04:55:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 04:55:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:55:08 --> Model Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Model Class Initialized
DEBUG - 2011-09-03 04:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:55:08 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:55:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 04:55:08 --> Helper loaded: url_helper
DEBUG - 2011-09-03 04:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 04:55:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 04:55:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 04:55:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 04:55:08 --> Final output sent to browser
DEBUG - 2011-09-03 04:55:08 --> Total execution time: 0.0288
DEBUG - 2011-09-03 04:55:13 --> Config Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Hooks Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Utf8 Class Initialized
DEBUG - 2011-09-03 04:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 04:55:13 --> URI Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Router Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Output Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Input Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 04:55:13 --> Language Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Loader Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Controller Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Model Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Model Class Initialized
DEBUG - 2011-09-03 04:55:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 04:55:13 --> Database Driver Class Initialized
DEBUG - 2011-09-03 04:55:14 --> Final output sent to browser
DEBUG - 2011-09-03 04:55:14 --> Total execution time: 0.5604
DEBUG - 2011-09-03 05:15:35 --> Config Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:15:35 --> URI Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Router Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Output Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Input Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:15:35 --> Language Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Loader Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Controller Class Initialized
ERROR - 2011-09-03 05:15:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:15:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:15:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:15:35 --> Model Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Model Class Initialized
DEBUG - 2011-09-03 05:15:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:15:35 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:15:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:15:35 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:15:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:15:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:15:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:15:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:15:35 --> Final output sent to browser
DEBUG - 2011-09-03 05:15:35 --> Total execution time: 0.1021
DEBUG - 2011-09-03 05:15:36 --> Config Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:15:36 --> URI Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Router Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Output Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Input Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:15:36 --> Language Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Loader Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Controller Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Model Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Model Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Model Class Initialized
DEBUG - 2011-09-03 05:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:15:36 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:15:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 05:15:37 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:15:37 --> Final output sent to browser
DEBUG - 2011-09-03 05:15:37 --> Total execution time: 0.1353
DEBUG - 2011-09-03 05:15:37 --> Config Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:15:37 --> URI Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Router Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Output Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Input Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:15:37 --> Language Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Loader Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Controller Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Model Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Model Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:15:37 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:15:37 --> Final output sent to browser
DEBUG - 2011-09-03 05:15:37 --> Total execution time: 0.5327
DEBUG - 2011-09-03 05:15:39 --> Config Class Initialized
DEBUG - 2011-09-03 05:15:39 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:15:39 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:15:39 --> URI Class Initialized
DEBUG - 2011-09-03 05:15:39 --> Router Class Initialized
ERROR - 2011-09-03 05:15:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:15:39 --> Config Class Initialized
DEBUG - 2011-09-03 05:15:39 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:15:39 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:15:39 --> URI Class Initialized
DEBUG - 2011-09-03 05:15:39 --> Router Class Initialized
ERROR - 2011-09-03 05:15:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:16:29 --> Config Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:16:29 --> URI Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Router Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Output Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Input Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:16:29 --> Language Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Loader Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Controller Class Initialized
ERROR - 2011-09-03 05:16:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:16:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:16:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:16:29 --> Model Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Model Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:16:29 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:16:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:16:29 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:16:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:16:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:16:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:16:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:16:29 --> Final output sent to browser
DEBUG - 2011-09-03 05:16:29 --> Total execution time: 0.0891
DEBUG - 2011-09-03 05:16:29 --> Config Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:16:29 --> URI Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Router Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Output Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Input Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:16:29 --> Language Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Loader Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Controller Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Model Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Model Class Initialized
DEBUG - 2011-09-03 05:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:16:29 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:16:30 --> Final output sent to browser
DEBUG - 2011-09-03 05:16:30 --> Total execution time: 0.7233
DEBUG - 2011-09-03 05:16:32 --> Config Class Initialized
DEBUG - 2011-09-03 05:16:32 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:16:32 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:16:32 --> URI Class Initialized
DEBUG - 2011-09-03 05:16:32 --> Router Class Initialized
ERROR - 2011-09-03 05:16:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:16:50 --> Config Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:16:50 --> URI Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Router Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Output Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Input Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:16:50 --> Language Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Loader Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Controller Class Initialized
ERROR - 2011-09-03 05:16:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:16:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:16:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:16:50 --> Model Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Model Class Initialized
DEBUG - 2011-09-03 05:16:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:16:50 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:16:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:16:50 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:16:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:16:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:16:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:16:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:16:50 --> Final output sent to browser
DEBUG - 2011-09-03 05:16:50 --> Total execution time: 0.0276
DEBUG - 2011-09-03 05:16:51 --> Config Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:16:51 --> URI Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Router Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Output Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Input Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:16:51 --> Language Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Loader Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Controller Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Model Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Model Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:16:51 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:16:51 --> Final output sent to browser
DEBUG - 2011-09-03 05:16:51 --> Total execution time: 0.5729
DEBUG - 2011-09-03 05:16:53 --> Config Class Initialized
DEBUG - 2011-09-03 05:16:53 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:16:53 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:16:53 --> URI Class Initialized
DEBUG - 2011-09-03 05:16:53 --> Router Class Initialized
ERROR - 2011-09-03 05:16:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:17:25 --> Config Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:17:25 --> URI Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Router Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Output Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Input Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:17:25 --> Language Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Loader Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Controller Class Initialized
ERROR - 2011-09-03 05:17:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:17:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:17:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:17:25 --> Model Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Model Class Initialized
DEBUG - 2011-09-03 05:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:17:25 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:17:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:17:25 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:17:25 --> Final output sent to browser
DEBUG - 2011-09-03 05:17:25 --> Total execution time: 0.0268
DEBUG - 2011-09-03 05:17:26 --> Config Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:17:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:17:26 --> URI Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Router Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Output Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Input Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:17:26 --> Language Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Loader Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Controller Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Model Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Model Class Initialized
DEBUG - 2011-09-03 05:17:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:17:26 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:17:27 --> Final output sent to browser
DEBUG - 2011-09-03 05:17:27 --> Total execution time: 0.5410
DEBUG - 2011-09-03 05:17:28 --> Config Class Initialized
DEBUG - 2011-09-03 05:17:28 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:17:28 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:17:28 --> URI Class Initialized
DEBUG - 2011-09-03 05:17:28 --> Router Class Initialized
ERROR - 2011-09-03 05:17:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:17:43 --> Config Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:17:43 --> URI Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Router Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Output Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Input Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:17:43 --> Language Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Loader Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Controller Class Initialized
ERROR - 2011-09-03 05:17:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:17:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:17:43 --> Model Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Model Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:17:43 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:17:43 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:17:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:17:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:17:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:17:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:17:43 --> Final output sent to browser
DEBUG - 2011-09-03 05:17:43 --> Total execution time: 0.0292
DEBUG - 2011-09-03 05:17:43 --> Config Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:17:43 --> URI Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Router Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Output Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Input Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:17:43 --> Language Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Loader Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Controller Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Model Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Model Class Initialized
DEBUG - 2011-09-03 05:17:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:17:43 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:17:44 --> Final output sent to browser
DEBUG - 2011-09-03 05:17:44 --> Total execution time: 0.5004
DEBUG - 2011-09-03 05:17:45 --> Config Class Initialized
DEBUG - 2011-09-03 05:17:45 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:17:45 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:17:45 --> URI Class Initialized
DEBUG - 2011-09-03 05:17:45 --> Router Class Initialized
ERROR - 2011-09-03 05:17:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:18:07 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:07 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Router Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Output Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Input Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:18:07 --> Language Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Loader Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Controller Class Initialized
ERROR - 2011-09-03 05:18:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:18:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:18:07 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:18:07 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:18:07 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:18:07 --> Final output sent to browser
DEBUG - 2011-09-03 05:18:07 --> Total execution time: 0.0301
DEBUG - 2011-09-03 05:18:07 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:07 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Router Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Output Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Input Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:18:07 --> Language Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Loader Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Controller Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:18:07 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:18:08 --> Final output sent to browser
DEBUG - 2011-09-03 05:18:08 --> Total execution time: 0.5709
DEBUG - 2011-09-03 05:18:10 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:10 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:10 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:10 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:10 --> Router Class Initialized
ERROR - 2011-09-03 05:18:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:18:27 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:27 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Router Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Output Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Input Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:18:27 --> Language Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Loader Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Controller Class Initialized
ERROR - 2011-09-03 05:18:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:18:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:18:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:18:27 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:18:27 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:18:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:18:27 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:18:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:18:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:18:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:18:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:18:27 --> Final output sent to browser
DEBUG - 2011-09-03 05:18:27 --> Total execution time: 0.0311
DEBUG - 2011-09-03 05:18:28 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:28 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Router Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Output Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Input Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:18:28 --> Language Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Loader Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Controller Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:18:28 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:18:29 --> Final output sent to browser
DEBUG - 2011-09-03 05:18:29 --> Total execution time: 0.8651
DEBUG - 2011-09-03 05:18:30 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:30 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:30 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:30 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:30 --> Router Class Initialized
ERROR - 2011-09-03 05:18:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:18:46 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:46 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Router Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Output Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Input Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:18:46 --> Language Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Loader Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Controller Class Initialized
ERROR - 2011-09-03 05:18:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:18:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:18:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:18:46 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:18:46 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:18:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:18:46 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:18:46 --> Final output sent to browser
DEBUG - 2011-09-03 05:18:46 --> Total execution time: 0.0393
DEBUG - 2011-09-03 05:18:47 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:47 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Router Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Output Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Input Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:18:47 --> Language Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Loader Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Controller Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Model Class Initialized
DEBUG - 2011-09-03 05:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:18:47 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:18:48 --> Final output sent to browser
DEBUG - 2011-09-03 05:18:48 --> Total execution time: 0.5068
DEBUG - 2011-09-03 05:18:50 --> Config Class Initialized
DEBUG - 2011-09-03 05:18:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:18:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:18:50 --> URI Class Initialized
DEBUG - 2011-09-03 05:18:50 --> Router Class Initialized
ERROR - 2011-09-03 05:18:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:19:14 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:14 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:14 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Controller Class Initialized
ERROR - 2011-09-03 05:19:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:19:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:19:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:14 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:14 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:14 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:19:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:19:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:19:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:19:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:19:14 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:14 --> Total execution time: 0.0302
DEBUG - 2011-09-03 05:19:14 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:14 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:14 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Controller Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:14 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:15 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:15 --> Total execution time: 0.5009
DEBUG - 2011-09-03 05:19:16 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:16 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:16 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:16 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:16 --> Router Class Initialized
ERROR - 2011-09-03 05:19:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:19:26 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:26 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:26 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Controller Class Initialized
ERROR - 2011-09-03 05:19:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:19:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:26 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:26 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:26 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:19:26 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:26 --> Total execution time: 0.0420
DEBUG - 2011-09-03 05:19:27 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:27 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:27 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Controller Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:27 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:27 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:27 --> Total execution time: 0.5339
DEBUG - 2011-09-03 05:19:29 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:29 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:29 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:29 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:29 --> Router Class Initialized
ERROR - 2011-09-03 05:19:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:19:34 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:34 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:34 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Controller Class Initialized
ERROR - 2011-09-03 05:19:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:19:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:34 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:34 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:34 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:19:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:19:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:19:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:19:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:19:34 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:34 --> Total execution time: 0.0269
DEBUG - 2011-09-03 05:19:34 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:34 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:34 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Controller Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:34 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:35 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:35 --> Total execution time: 0.5459
DEBUG - 2011-09-03 05:19:37 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:37 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:37 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:37 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:37 --> Router Class Initialized
ERROR - 2011-09-03 05:19:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:19:45 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:45 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:45 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Controller Class Initialized
ERROR - 2011-09-03 05:19:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:19:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:19:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:45 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:45 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:45 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:19:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:19:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:19:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:19:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:19:45 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:45 --> Total execution time: 0.0288
DEBUG - 2011-09-03 05:19:45 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:45 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:45 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Controller Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:45 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:46 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:46 --> Total execution time: 0.5519
DEBUG - 2011-09-03 05:19:47 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:47 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:47 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:47 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:47 --> Router Class Initialized
ERROR - 2011-09-03 05:19:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:19:51 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:51 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:51 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Controller Class Initialized
ERROR - 2011-09-03 05:19:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:19:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:19:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:51 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:51 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:19:51 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:19:51 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:51 --> Total execution time: 0.0273
DEBUG - 2011-09-03 05:19:52 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:52 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Router Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Output Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Input Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:19:52 --> Language Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Loader Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Controller Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Model Class Initialized
DEBUG - 2011-09-03 05:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:19:52 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:19:53 --> Final output sent to browser
DEBUG - 2011-09-03 05:19:53 --> Total execution time: 0.5257
DEBUG - 2011-09-03 05:19:54 --> Config Class Initialized
DEBUG - 2011-09-03 05:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:19:54 --> URI Class Initialized
DEBUG - 2011-09-03 05:19:54 --> Router Class Initialized
ERROR - 2011-09-03 05:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 05:20:23 --> Config Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:20:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:20:23 --> URI Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Router Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Output Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Input Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:20:23 --> Language Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Loader Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Controller Class Initialized
ERROR - 2011-09-03 05:20:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 05:20:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 05:20:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:20:23 --> Model Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Model Class Initialized
DEBUG - 2011-09-03 05:20:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 05:20:23 --> Database Driver Class Initialized
DEBUG - 2011-09-03 05:20:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 05:20:23 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:20:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:20:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:20:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:20:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:20:23 --> Final output sent to browser
DEBUG - 2011-09-03 05:20:23 --> Total execution time: 0.0270
DEBUG - 2011-09-03 05:56:34 --> Config Class Initialized
DEBUG - 2011-09-03 05:56:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 05:56:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 05:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 05:56:34 --> URI Class Initialized
DEBUG - 2011-09-03 05:56:34 --> Router Class Initialized
DEBUG - 2011-09-03 05:56:34 --> No URI present. Default controller set.
DEBUG - 2011-09-03 05:56:34 --> Output Class Initialized
DEBUG - 2011-09-03 05:56:34 --> Input Class Initialized
DEBUG - 2011-09-03 05:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 05:56:34 --> Language Class Initialized
DEBUG - 2011-09-03 05:56:34 --> Loader Class Initialized
DEBUG - 2011-09-03 05:56:34 --> Controller Class Initialized
DEBUG - 2011-09-03 05:56:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-03 05:56:34 --> Helper loaded: url_helper
DEBUG - 2011-09-03 05:56:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 05:56:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 05:56:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 05:56:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 05:56:34 --> Final output sent to browser
DEBUG - 2011-09-03 05:56:34 --> Total execution time: 0.1864
DEBUG - 2011-09-03 06:39:17 --> Config Class Initialized
DEBUG - 2011-09-03 06:39:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 06:39:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 06:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 06:39:17 --> URI Class Initialized
DEBUG - 2011-09-03 06:39:17 --> Router Class Initialized
ERROR - 2011-09-03 06:39:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-03 07:10:35 --> Config Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:10:35 --> URI Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Router Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Output Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Input Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:10:35 --> Language Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Loader Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Controller Class Initialized
ERROR - 2011-09-03 07:10:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:10:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:10:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:10:35 --> Model Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Model Class Initialized
DEBUG - 2011-09-03 07:10:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:10:35 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:10:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:10:36 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:10:36 --> Final output sent to browser
DEBUG - 2011-09-03 07:10:36 --> Total execution time: 0.5631
DEBUG - 2011-09-03 07:10:37 --> Config Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:10:37 --> URI Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Router Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Output Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Input Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:10:37 --> Language Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Loader Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Controller Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Model Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Model Class Initialized
DEBUG - 2011-09-03 07:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:10:37 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:10:38 --> Final output sent to browser
DEBUG - 2011-09-03 07:10:38 --> Total execution time: 1.1543
DEBUG - 2011-09-03 07:10:40 --> Config Class Initialized
DEBUG - 2011-09-03 07:10:40 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:10:40 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:10:40 --> URI Class Initialized
DEBUG - 2011-09-03 07:10:40 --> Router Class Initialized
ERROR - 2011-09-03 07:10:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:10:41 --> Config Class Initialized
DEBUG - 2011-09-03 07:10:41 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:10:41 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:10:41 --> URI Class Initialized
DEBUG - 2011-09-03 07:10:41 --> Router Class Initialized
ERROR - 2011-09-03 07:10:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:11:20 --> Config Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:11:20 --> URI Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Router Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Output Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Input Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:11:20 --> Language Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Loader Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Controller Class Initialized
ERROR - 2011-09-03 07:11:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:11:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:11:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:11:20 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:11:20 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:11:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:11:20 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:11:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:11:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:11:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:11:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:11:20 --> Final output sent to browser
DEBUG - 2011-09-03 07:11:20 --> Total execution time: 0.0268
DEBUG - 2011-09-03 07:11:21 --> Config Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:11:21 --> URI Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Router Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Output Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Input Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:11:21 --> Language Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Loader Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Controller Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:11:21 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:11:22 --> Final output sent to browser
DEBUG - 2011-09-03 07:11:22 --> Total execution time: 0.6855
DEBUG - 2011-09-03 07:11:36 --> Config Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:11:36 --> URI Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Router Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Output Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Input Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:11:36 --> Language Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Loader Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Controller Class Initialized
ERROR - 2011-09-03 07:11:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:11:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:11:36 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:11:36 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:11:36 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:11:36 --> Final output sent to browser
DEBUG - 2011-09-03 07:11:36 --> Total execution time: 0.0287
DEBUG - 2011-09-03 07:11:37 --> Config Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:11:37 --> URI Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Router Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Output Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Input Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:11:37 --> Language Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Loader Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Controller Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:11:37 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:11:38 --> Final output sent to browser
DEBUG - 2011-09-03 07:11:38 --> Total execution time: 0.7553
DEBUG - 2011-09-03 07:11:47 --> Config Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:11:47 --> URI Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Router Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Output Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Input Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:11:47 --> Language Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Loader Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Controller Class Initialized
ERROR - 2011-09-03 07:11:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:11:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:11:47 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:11:47 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:11:47 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:11:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:11:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:11:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:11:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:11:47 --> Final output sent to browser
DEBUG - 2011-09-03 07:11:47 --> Total execution time: 0.0303
DEBUG - 2011-09-03 07:11:47 --> Config Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:11:47 --> URI Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Router Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Output Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Input Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:11:47 --> Language Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Loader Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Controller Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Model Class Initialized
DEBUG - 2011-09-03 07:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:11:47 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:11:48 --> Final output sent to browser
DEBUG - 2011-09-03 07:11:48 --> Total execution time: 0.5421
DEBUG - 2011-09-03 07:12:03 --> Config Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:12:03 --> URI Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Router Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Output Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Input Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:12:03 --> Language Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Loader Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Controller Class Initialized
ERROR - 2011-09-03 07:12:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:12:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:12:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:12:03 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:12:03 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:12:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:12:03 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:12:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:12:03 --> Final output sent to browser
DEBUG - 2011-09-03 07:12:03 --> Total execution time: 0.0730
DEBUG - 2011-09-03 07:12:04 --> Config Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:12:04 --> URI Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Router Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Output Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Input Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:12:04 --> Language Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Loader Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Controller Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:12:04 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:12:04 --> Final output sent to browser
DEBUG - 2011-09-03 07:12:04 --> Total execution time: 0.5518
DEBUG - 2011-09-03 07:12:19 --> Config Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:12:19 --> URI Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Router Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Output Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Input Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:12:19 --> Language Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Loader Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Controller Class Initialized
ERROR - 2011-09-03 07:12:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:12:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:12:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:12:19 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:12:19 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:12:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:12:19 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:12:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:12:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:12:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:12:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:12:19 --> Final output sent to browser
DEBUG - 2011-09-03 07:12:19 --> Total execution time: 0.0271
DEBUG - 2011-09-03 07:12:20 --> Config Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:12:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:12:20 --> URI Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Router Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Output Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Input Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:12:20 --> Language Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Loader Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Controller Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:12:20 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:12:20 --> Final output sent to browser
DEBUG - 2011-09-03 07:12:20 --> Total execution time: 0.5634
DEBUG - 2011-09-03 07:12:38 --> Config Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:12:38 --> URI Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Router Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Output Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Input Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:12:38 --> Language Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Loader Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Controller Class Initialized
ERROR - 2011-09-03 07:12:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:12:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:12:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:12:38 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:12:38 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:12:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:12:38 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:12:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:12:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:12:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:12:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:12:38 --> Final output sent to browser
DEBUG - 2011-09-03 07:12:38 --> Total execution time: 0.0291
DEBUG - 2011-09-03 07:12:39 --> Config Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:12:39 --> URI Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Router Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Output Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Input Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:12:39 --> Language Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Loader Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Controller Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Model Class Initialized
DEBUG - 2011-09-03 07:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:12:39 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:12:40 --> Final output sent to browser
DEBUG - 2011-09-03 07:12:40 --> Total execution time: 0.6934
DEBUG - 2011-09-03 07:13:04 --> Config Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:13:04 --> URI Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Router Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Output Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Input Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:13:04 --> Language Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Loader Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Controller Class Initialized
ERROR - 2011-09-03 07:13:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:13:04 --> Model Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Model Class Initialized
DEBUG - 2011-09-03 07:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:13:04 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:13:04 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:13:04 --> Final output sent to browser
DEBUG - 2011-09-03 07:13:04 --> Total execution time: 0.0468
DEBUG - 2011-09-03 07:13:05 --> Config Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:13:05 --> URI Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Router Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Output Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Input Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:13:05 --> Language Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Loader Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Controller Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Model Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Model Class Initialized
DEBUG - 2011-09-03 07:13:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:13:05 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:13:06 --> Final output sent to browser
DEBUG - 2011-09-03 07:13:06 --> Total execution time: 0.6122
DEBUG - 2011-09-03 07:13:14 --> Config Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:13:14 --> URI Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Router Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Output Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Input Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:13:14 --> Language Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Loader Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Controller Class Initialized
ERROR - 2011-09-03 07:13:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:13:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:13:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:13:14 --> Model Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Model Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:13:14 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:13:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:13:14 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:13:14 --> Final output sent to browser
DEBUG - 2011-09-03 07:13:14 --> Total execution time: 0.0301
DEBUG - 2011-09-03 07:13:14 --> Config Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:13:14 --> URI Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Router Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Output Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Input Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:13:14 --> Language Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Loader Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Controller Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Model Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Model Class Initialized
DEBUG - 2011-09-03 07:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:13:14 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:13:15 --> Final output sent to browser
DEBUG - 2011-09-03 07:13:15 --> Total execution time: 0.4981
DEBUG - 2011-09-03 07:30:57 --> Config Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:30:57 --> URI Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Router Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Output Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Input Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:30:57 --> Language Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Loader Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Controller Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Model Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Model Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Model Class Initialized
DEBUG - 2011-09-03 07:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:30:57 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 07:30:58 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:30:58 --> Final output sent to browser
DEBUG - 2011-09-03 07:30:58 --> Total execution time: 0.6370
DEBUG - 2011-09-03 07:30:58 --> Config Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:30:58 --> URI Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Router Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Output Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Input Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:30:58 --> Language Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Loader Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Controller Class Initialized
ERROR - 2011-09-03 07:30:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:30:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:30:58 --> Model Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Model Class Initialized
DEBUG - 2011-09-03 07:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:30:58 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:30:58 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:30:58 --> Final output sent to browser
DEBUG - 2011-09-03 07:30:58 --> Total execution time: 0.1454
DEBUG - 2011-09-03 07:47:10 --> Config Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:47:10 --> URI Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Router Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Output Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Input Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:47:10 --> Language Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Loader Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Controller Class Initialized
ERROR - 2011-09-03 07:47:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:47:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:47:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:47:10 --> Model Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Model Class Initialized
DEBUG - 2011-09-03 07:47:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:47:10 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:47:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:47:10 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:47:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:47:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:47:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:47:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:47:10 --> Final output sent to browser
DEBUG - 2011-09-03 07:47:10 --> Total execution time: 0.3334
DEBUG - 2011-09-03 07:47:13 --> Config Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:47:13 --> URI Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Router Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Output Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Input Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:47:13 --> Language Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Loader Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Controller Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Model Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Model Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:47:13 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:47:13 --> Final output sent to browser
DEBUG - 2011-09-03 07:47:13 --> Total execution time: 0.6965
DEBUG - 2011-09-03 07:47:15 --> Config Class Initialized
DEBUG - 2011-09-03 07:47:15 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:47:15 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:47:15 --> URI Class Initialized
DEBUG - 2011-09-03 07:47:15 --> Router Class Initialized
ERROR - 2011-09-03 07:47:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:47:48 --> Config Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:47:48 --> URI Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Router Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Output Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Input Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:47:48 --> Language Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Loader Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Controller Class Initialized
ERROR - 2011-09-03 07:47:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:47:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:47:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:47:48 --> Model Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Model Class Initialized
DEBUG - 2011-09-03 07:47:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:47:48 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:47:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:47:48 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:47:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:47:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:47:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:47:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:47:48 --> Final output sent to browser
DEBUG - 2011-09-03 07:47:48 --> Total execution time: 0.0266
DEBUG - 2011-09-03 07:47:49 --> Config Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:47:49 --> URI Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Router Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Output Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Input Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:47:49 --> Language Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Loader Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Controller Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Model Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Model Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:47:49 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:47:49 --> Final output sent to browser
DEBUG - 2011-09-03 07:47:49 --> Total execution time: 0.5840
DEBUG - 2011-09-03 07:47:52 --> Config Class Initialized
DEBUG - 2011-09-03 07:47:52 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:47:52 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:47:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:47:52 --> URI Class Initialized
DEBUG - 2011-09-03 07:47:52 --> Router Class Initialized
ERROR - 2011-09-03 07:47:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:48:16 --> Config Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:48:16 --> URI Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Router Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Output Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Input Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:48:16 --> Language Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Loader Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Controller Class Initialized
ERROR - 2011-09-03 07:48:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:48:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:48:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:48:16 --> Model Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Model Class Initialized
DEBUG - 2011-09-03 07:48:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:48:16 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:48:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:48:16 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:48:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:48:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:48:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:48:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:48:16 --> Final output sent to browser
DEBUG - 2011-09-03 07:48:16 --> Total execution time: 0.0286
DEBUG - 2011-09-03 07:48:17 --> Config Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:48:17 --> URI Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Router Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Output Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Input Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:48:17 --> Language Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Loader Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Controller Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Model Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Model Class Initialized
DEBUG - 2011-09-03 07:48:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:48:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:48:18 --> Final output sent to browser
DEBUG - 2011-09-03 07:48:18 --> Total execution time: 0.5679
DEBUG - 2011-09-03 07:48:21 --> Config Class Initialized
DEBUG - 2011-09-03 07:48:21 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:48:21 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:48:21 --> URI Class Initialized
DEBUG - 2011-09-03 07:48:21 --> Router Class Initialized
ERROR - 2011-09-03 07:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:48:48 --> Config Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:48:48 --> URI Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Router Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Output Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Input Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:48:48 --> Language Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Loader Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Controller Class Initialized
ERROR - 2011-09-03 07:48:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:48:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:48:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:48:48 --> Model Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Model Class Initialized
DEBUG - 2011-09-03 07:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:48:48 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:48:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:48:49 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:48:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:48:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:48:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:48:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:48:49 --> Final output sent to browser
DEBUG - 2011-09-03 07:48:49 --> Total execution time: 0.0279
DEBUG - 2011-09-03 07:48:49 --> Config Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:48:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:48:49 --> URI Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Router Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Output Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Input Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:48:49 --> Language Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Loader Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Controller Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Model Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Model Class Initialized
DEBUG - 2011-09-03 07:48:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:48:49 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:48:50 --> Final output sent to browser
DEBUG - 2011-09-03 07:48:50 --> Total execution time: 0.4963
DEBUG - 2011-09-03 07:48:52 --> Config Class Initialized
DEBUG - 2011-09-03 07:48:52 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:48:52 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:48:52 --> URI Class Initialized
DEBUG - 2011-09-03 07:48:52 --> Router Class Initialized
ERROR - 2011-09-03 07:48:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:49:17 --> Config Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:49:17 --> URI Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Router Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Output Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Input Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:49:17 --> Language Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Loader Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Controller Class Initialized
ERROR - 2011-09-03 07:49:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:49:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:49:17 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:49:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:49:17 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:49:17 --> Final output sent to browser
DEBUG - 2011-09-03 07:49:17 --> Total execution time: 0.0280
DEBUG - 2011-09-03 07:49:17 --> Config Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:49:17 --> URI Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Router Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Output Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Input Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:49:17 --> Language Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Loader Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Controller Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:49:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:49:18 --> Final output sent to browser
DEBUG - 2011-09-03 07:49:18 --> Total execution time: 0.6758
DEBUG - 2011-09-03 07:49:20 --> Config Class Initialized
DEBUG - 2011-09-03 07:49:20 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:49:20 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:49:20 --> URI Class Initialized
DEBUG - 2011-09-03 07:49:20 --> Router Class Initialized
ERROR - 2011-09-03 07:49:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:49:40 --> Config Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:49:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:49:40 --> URI Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Router Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Output Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Input Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:49:40 --> Language Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Loader Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Controller Class Initialized
ERROR - 2011-09-03 07:49:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:49:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:49:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:49:40 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:49:40 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:49:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:49:40 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:49:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:49:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:49:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:49:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:49:40 --> Final output sent to browser
DEBUG - 2011-09-03 07:49:40 --> Total execution time: 0.0301
DEBUG - 2011-09-03 07:49:41 --> Config Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:49:41 --> URI Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Router Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Output Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Input Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:49:41 --> Language Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Loader Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Controller Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:49:41 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:49:41 --> Final output sent to browser
DEBUG - 2011-09-03 07:49:41 --> Total execution time: 0.5526
DEBUG - 2011-09-03 07:49:43 --> Config Class Initialized
DEBUG - 2011-09-03 07:49:43 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:49:43 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:49:43 --> URI Class Initialized
DEBUG - 2011-09-03 07:49:43 --> Router Class Initialized
ERROR - 2011-09-03 07:49:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:49:58 --> Config Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:49:58 --> URI Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Router Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Output Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Input Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:49:58 --> Language Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Loader Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Controller Class Initialized
ERROR - 2011-09-03 07:49:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:49:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:49:58 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:49:58 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:49:58 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:49:58 --> Final output sent to browser
DEBUG - 2011-09-03 07:49:58 --> Total execution time: 0.0295
DEBUG - 2011-09-03 07:49:59 --> Config Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:49:59 --> URI Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Router Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Output Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Input Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:49:59 --> Language Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Loader Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Controller Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Model Class Initialized
DEBUG - 2011-09-03 07:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:49:59 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:50:00 --> Final output sent to browser
DEBUG - 2011-09-03 07:50:00 --> Total execution time: 0.8767
DEBUG - 2011-09-03 07:50:02 --> Config Class Initialized
DEBUG - 2011-09-03 07:50:02 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:50:02 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:50:02 --> URI Class Initialized
DEBUG - 2011-09-03 07:50:02 --> Router Class Initialized
ERROR - 2011-09-03 07:50:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 07:50:10 --> Config Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:50:10 --> URI Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Router Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Output Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Input Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:50:10 --> Language Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Loader Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Controller Class Initialized
ERROR - 2011-09-03 07:50:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 07:50:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 07:50:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:50:10 --> Model Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Model Class Initialized
DEBUG - 2011-09-03 07:50:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:50:10 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:50:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 07:50:10 --> Helper loaded: url_helper
DEBUG - 2011-09-03 07:50:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 07:50:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 07:50:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 07:50:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 07:50:10 --> Final output sent to browser
DEBUG - 2011-09-03 07:50:10 --> Total execution time: 0.0282
DEBUG - 2011-09-03 07:50:11 --> Config Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:50:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:50:11 --> URI Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Router Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Output Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Input Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 07:50:11 --> Language Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Loader Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Controller Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Model Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Model Class Initialized
DEBUG - 2011-09-03 07:50:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 07:50:11 --> Database Driver Class Initialized
DEBUG - 2011-09-03 07:50:15 --> Final output sent to browser
DEBUG - 2011-09-03 07:50:15 --> Total execution time: 3.3520
DEBUG - 2011-09-03 07:50:19 --> Config Class Initialized
DEBUG - 2011-09-03 07:50:19 --> Hooks Class Initialized
DEBUG - 2011-09-03 07:50:19 --> Utf8 Class Initialized
DEBUG - 2011-09-03 07:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 07:50:19 --> URI Class Initialized
DEBUG - 2011-09-03 07:50:19 --> Router Class Initialized
ERROR - 2011-09-03 07:50:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 09:25:07 --> Config Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 09:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 09:25:07 --> URI Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Router Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Output Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Input Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 09:25:07 --> Language Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Loader Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Controller Class Initialized
ERROR - 2011-09-03 09:25:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 09:25:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 09:25:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 09:25:07 --> Model Class Initialized
DEBUG - 2011-09-03 09:25:07 --> Model Class Initialized
DEBUG - 2011-09-03 09:25:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 09:25:08 --> Database Driver Class Initialized
DEBUG - 2011-09-03 09:25:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 09:25:09 --> Helper loaded: url_helper
DEBUG - 2011-09-03 09:25:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 09:25:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 09:25:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 09:25:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 09:25:09 --> Final output sent to browser
DEBUG - 2011-09-03 09:25:09 --> Total execution time: 2.1468
DEBUG - 2011-09-03 09:25:23 --> Config Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 09:25:23 --> URI Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Router Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Output Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Input Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 09:25:23 --> Language Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Loader Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Controller Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Model Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Model Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 09:25:23 --> Database Driver Class Initialized
DEBUG - 2011-09-03 09:25:23 --> Final output sent to browser
DEBUG - 2011-09-03 09:25:23 --> Total execution time: 0.5850
DEBUG - 2011-09-03 09:26:24 --> Config Class Initialized
DEBUG - 2011-09-03 09:26:24 --> Hooks Class Initialized
DEBUG - 2011-09-03 09:26:24 --> Utf8 Class Initialized
DEBUG - 2011-09-03 09:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 09:26:24 --> URI Class Initialized
DEBUG - 2011-09-03 09:26:24 --> Router Class Initialized
ERROR - 2011-09-03 09:26:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 10:45:19 --> Config Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Hooks Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Utf8 Class Initialized
DEBUG - 2011-09-03 10:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 10:45:19 --> URI Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Router Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Output Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Input Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 10:45:19 --> Language Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Loader Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Controller Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Model Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Model Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Model Class Initialized
DEBUG - 2011-09-03 10:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 10:45:19 --> Database Driver Class Initialized
DEBUG - 2011-09-03 10:45:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 10:45:19 --> Helper loaded: url_helper
DEBUG - 2011-09-03 10:45:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 10:45:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 10:45:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 10:45:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 10:45:19 --> Final output sent to browser
DEBUG - 2011-09-03 10:45:19 --> Total execution time: 0.4179
DEBUG - 2011-09-03 11:52:31 --> Config Class Initialized
DEBUG - 2011-09-03 11:52:31 --> Hooks Class Initialized
DEBUG - 2011-09-03 11:52:31 --> Utf8 Class Initialized
DEBUG - 2011-09-03 11:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 11:52:31 --> URI Class Initialized
DEBUG - 2011-09-03 11:52:31 --> Router Class Initialized
ERROR - 2011-09-03 11:52:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-03 12:00:34 --> Config Class Initialized
DEBUG - 2011-09-03 12:00:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:00:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:00:34 --> URI Class Initialized
DEBUG - 2011-09-03 12:00:34 --> Router Class Initialized
DEBUG - 2011-09-03 12:00:34 --> No URI present. Default controller set.
DEBUG - 2011-09-03 12:00:34 --> Output Class Initialized
DEBUG - 2011-09-03 12:00:34 --> Input Class Initialized
DEBUG - 2011-09-03 12:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:00:34 --> Language Class Initialized
DEBUG - 2011-09-03 12:00:34 --> Loader Class Initialized
DEBUG - 2011-09-03 12:00:34 --> Controller Class Initialized
DEBUG - 2011-09-03 12:00:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-03 12:00:34 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:00:34 --> Final output sent to browser
DEBUG - 2011-09-03 12:00:34 --> Total execution time: 0.1212
DEBUG - 2011-09-03 12:00:38 --> Config Class Initialized
DEBUG - 2011-09-03 12:00:38 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:00:38 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:00:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:00:38 --> URI Class Initialized
DEBUG - 2011-09-03 12:00:38 --> Router Class Initialized
ERROR - 2011-09-03 12:00:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:00:43 --> Config Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:00:43 --> URI Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Router Class Initialized
ERROR - 2011-09-03 12:00:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-03 12:00:43 --> Config Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:00:43 --> URI Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Router Class Initialized
DEBUG - 2011-09-03 12:00:43 --> No URI present. Default controller set.
DEBUG - 2011-09-03 12:00:43 --> Output Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Input Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:00:43 --> Language Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Loader Class Initialized
DEBUG - 2011-09-03 12:00:43 --> Controller Class Initialized
DEBUG - 2011-09-03 12:00:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-03 12:00:43 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:00:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:00:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:00:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:00:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:00:43 --> Final output sent to browser
DEBUG - 2011-09-03 12:00:43 --> Total execution time: 0.0212
DEBUG - 2011-09-03 12:03:14 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:14 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Router Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Output Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Input Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:03:14 --> Language Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Loader Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Controller Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Model Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Model Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Model Class Initialized
DEBUG - 2011-09-03 12:03:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:03:14 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:03:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 12:03:14 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:03:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:03:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:03:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:03:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:03:14 --> Final output sent to browser
DEBUG - 2011-09-03 12:03:14 --> Total execution time: 0.2709
DEBUG - 2011-09-03 12:03:16 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:16 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:16 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:16 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:16 --> Router Class Initialized
ERROR - 2011-09-03 12:03:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:03:17 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:17 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:17 --> Router Class Initialized
ERROR - 2011-09-03 12:03:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:03:17 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:17 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:17 --> Router Class Initialized
ERROR - 2011-09-03 12:03:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:03:18 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:18 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:18 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:18 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:18 --> Router Class Initialized
ERROR - 2011-09-03 12:03:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:03:19 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:19 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Router Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Output Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:19 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Input Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:03:19 --> Language Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Router Class Initialized
ERROR - 2011-09-03 12:03:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:03:19 --> Loader Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Controller Class Initialized
ERROR - 2011-09-03 12:03:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:03:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:03:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:03:19 --> Model Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Model Class Initialized
DEBUG - 2011-09-03 12:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:03:19 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:03:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:03:19 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:03:19 --> Final output sent to browser
DEBUG - 2011-09-03 12:03:19 --> Total execution time: 0.0826
DEBUG - 2011-09-03 12:03:20 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:20 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Router Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Output Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Input Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:03:20 --> Language Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Loader Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Controller Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Model Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Model Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:03:20 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:03:20 --> Final output sent to browser
DEBUG - 2011-09-03 12:03:20 --> Total execution time: 0.6612
DEBUG - 2011-09-03 12:03:23 --> Config Class Initialized
DEBUG - 2011-09-03 12:03:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:03:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:03:23 --> URI Class Initialized
DEBUG - 2011-09-03 12:03:23 --> Router Class Initialized
ERROR - 2011-09-03 12:03:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:04:18 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:18 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Router Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Output Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Input Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:04:18 --> Language Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Loader Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Controller Class Initialized
ERROR - 2011-09-03 12:04:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:04:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:04:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:04:18 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:04:18 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:04:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:04:18 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:04:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:04:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:04:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:04:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:04:18 --> Final output sent to browser
DEBUG - 2011-09-03 12:04:18 --> Total execution time: 0.0316
DEBUG - 2011-09-03 12:04:18 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:18 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Router Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Output Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Input Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:04:18 --> Language Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Loader Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Controller Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:04:18 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:04:19 --> Final output sent to browser
DEBUG - 2011-09-03 12:04:19 --> Total execution time: 0.5250
DEBUG - 2011-09-03 12:04:21 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:21 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:21 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:21 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:21 --> Router Class Initialized
ERROR - 2011-09-03 12:04:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:04:25 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:25 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Router Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Output Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Input Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:04:25 --> Language Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Loader Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Controller Class Initialized
ERROR - 2011-09-03 12:04:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:04:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:04:25 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:04:25 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:04:25 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:04:25 --> Final output sent to browser
DEBUG - 2011-09-03 12:04:25 --> Total execution time: 0.0439
DEBUG - 2011-09-03 12:04:26 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:26 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Router Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Output Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Input Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:04:26 --> Language Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Loader Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Controller Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:04:26 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:04:26 --> Final output sent to browser
DEBUG - 2011-09-03 12:04:26 --> Total execution time: 0.5090
DEBUG - 2011-09-03 12:04:29 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:29 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:29 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:29 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:29 --> Router Class Initialized
ERROR - 2011-09-03 12:04:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:04:36 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:36 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Router Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Output Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Input Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:04:36 --> Language Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Loader Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Controller Class Initialized
ERROR - 2011-09-03 12:04:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:04:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:04:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:04:36 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:04:36 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:04:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:04:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:04:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:04:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:04:36 --> Final output sent to browser
DEBUG - 2011-09-03 12:04:36 --> Total execution time: 0.0907
DEBUG - 2011-09-03 12:04:38 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:38 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Router Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Output Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Input Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:04:38 --> Language Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Loader Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Controller Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Model Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:04:38 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:04:38 --> Final output sent to browser
DEBUG - 2011-09-03 12:04:38 --> Total execution time: 0.5921
DEBUG - 2011-09-03 12:04:41 --> Config Class Initialized
DEBUG - 2011-09-03 12:04:41 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:04:41 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:04:41 --> URI Class Initialized
DEBUG - 2011-09-03 12:04:41 --> Router Class Initialized
ERROR - 2011-09-03 12:04:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:05:34 --> Config Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:05:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:05:34 --> URI Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Router Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Output Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Input Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:05:34 --> Language Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Loader Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Controller Class Initialized
ERROR - 2011-09-03 12:05:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:05:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:05:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:05:34 --> Model Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Model Class Initialized
DEBUG - 2011-09-03 12:05:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:05:34 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:05:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:05:34 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:05:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:05:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:05:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:05:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:05:34 --> Final output sent to browser
DEBUG - 2011-09-03 12:05:34 --> Total execution time: 0.0311
DEBUG - 2011-09-03 12:05:35 --> Config Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:05:35 --> URI Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Router Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Output Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Input Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:05:35 --> Language Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Loader Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Controller Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Model Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Model Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:05:35 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:05:35 --> Final output sent to browser
DEBUG - 2011-09-03 12:05:35 --> Total execution time: 0.5698
DEBUG - 2011-09-03 12:05:38 --> Config Class Initialized
DEBUG - 2011-09-03 12:05:38 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:05:38 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:05:38 --> URI Class Initialized
DEBUG - 2011-09-03 12:05:38 --> Router Class Initialized
ERROR - 2011-09-03 12:05:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:05:57 --> Config Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:05:57 --> URI Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Router Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Output Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Input Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:05:57 --> Language Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Loader Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Controller Class Initialized
ERROR - 2011-09-03 12:05:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:05:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:05:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:05:57 --> Model Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Model Class Initialized
DEBUG - 2011-09-03 12:05:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:05:57 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:05:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:05:57 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:05:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:05:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:05:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:05:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:05:57 --> Final output sent to browser
DEBUG - 2011-09-03 12:05:57 --> Total execution time: 0.0272
DEBUG - 2011-09-03 12:05:58 --> Config Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:05:58 --> URI Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Router Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Output Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Input Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:05:58 --> Language Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Loader Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Controller Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Model Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Model Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:05:58 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:05:58 --> Final output sent to browser
DEBUG - 2011-09-03 12:05:58 --> Total execution time: 0.5795
DEBUG - 2011-09-03 12:06:01 --> Config Class Initialized
DEBUG - 2011-09-03 12:06:01 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:06:01 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:06:01 --> URI Class Initialized
DEBUG - 2011-09-03 12:06:01 --> Router Class Initialized
ERROR - 2011-09-03 12:06:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:06:17 --> Config Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:06:17 --> URI Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Router Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Output Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Input Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:06:17 --> Language Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Loader Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Controller Class Initialized
ERROR - 2011-09-03 12:06:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:06:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:06:17 --> Model Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Model Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:06:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:06:17 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:06:17 --> Final output sent to browser
DEBUG - 2011-09-03 12:06:17 --> Total execution time: 0.0300
DEBUG - 2011-09-03 12:06:17 --> Config Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:06:17 --> URI Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Router Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Output Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Input Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:06:17 --> Language Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Loader Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Controller Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Model Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Model Class Initialized
DEBUG - 2011-09-03 12:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:06:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:06:18 --> Final output sent to browser
DEBUG - 2011-09-03 12:06:18 --> Total execution time: 0.6154
DEBUG - 2011-09-03 12:06:21 --> Config Class Initialized
DEBUG - 2011-09-03 12:06:21 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:06:21 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:06:21 --> URI Class Initialized
DEBUG - 2011-09-03 12:06:21 --> Router Class Initialized
ERROR - 2011-09-03 12:06:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:06:40 --> Config Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:06:40 --> URI Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Router Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Output Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Input Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:06:40 --> Language Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Loader Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Controller Class Initialized
ERROR - 2011-09-03 12:06:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:06:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:06:40 --> Model Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Model Class Initialized
DEBUG - 2011-09-03 12:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:06:40 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:06:40 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:06:40 --> Final output sent to browser
DEBUG - 2011-09-03 12:06:40 --> Total execution time: 0.0289
DEBUG - 2011-09-03 12:06:41 --> Config Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:06:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:06:41 --> URI Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Router Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Output Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Input Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:06:41 --> Language Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Loader Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Controller Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Model Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Model Class Initialized
DEBUG - 2011-09-03 12:06:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:06:41 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:06:42 --> Final output sent to browser
DEBUG - 2011-09-03 12:06:42 --> Total execution time: 0.5489
DEBUG - 2011-09-03 12:06:44 --> Config Class Initialized
DEBUG - 2011-09-03 12:06:44 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:06:44 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:06:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:06:44 --> URI Class Initialized
DEBUG - 2011-09-03 12:06:44 --> Router Class Initialized
ERROR - 2011-09-03 12:06:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:07:13 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:13 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Router Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Output Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Input Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:07:13 --> Language Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Loader Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Controller Class Initialized
ERROR - 2011-09-03 12:07:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:07:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:07:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:07:13 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:07:13 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:07:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:07:13 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:07:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:07:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:07:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:07:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:07:13 --> Final output sent to browser
DEBUG - 2011-09-03 12:07:13 --> Total execution time: 0.0284
DEBUG - 2011-09-03 12:07:14 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:14 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Router Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Output Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Input Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:07:14 --> Language Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Loader Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Controller Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:07:14 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:07:14 --> Final output sent to browser
DEBUG - 2011-09-03 12:07:14 --> Total execution time: 0.5916
DEBUG - 2011-09-03 12:07:17 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:17 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:17 --> Router Class Initialized
ERROR - 2011-09-03 12:07:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:07:26 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:26 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Router Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Output Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Input Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:07:26 --> Language Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Loader Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Controller Class Initialized
ERROR - 2011-09-03 12:07:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:07:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:07:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:07:26 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:07:26 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:07:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:07:26 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:07:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:07:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:07:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:07:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:07:26 --> Final output sent to browser
DEBUG - 2011-09-03 12:07:26 --> Total execution time: 0.0305
DEBUG - 2011-09-03 12:07:27 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:27 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Router Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Output Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Input Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:07:27 --> Language Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Loader Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Controller Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:07:27 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:07:28 --> Final output sent to browser
DEBUG - 2011-09-03 12:07:28 --> Total execution time: 0.5066
DEBUG - 2011-09-03 12:07:31 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:31 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:31 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:31 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:31 --> Router Class Initialized
ERROR - 2011-09-03 12:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:07:44 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:44 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Router Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Output Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Input Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:07:44 --> Language Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Loader Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Controller Class Initialized
ERROR - 2011-09-03 12:07:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:07:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:07:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:07:44 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:07:44 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:07:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:07:44 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:07:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:07:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:07:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:07:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:07:44 --> Final output sent to browser
DEBUG - 2011-09-03 12:07:44 --> Total execution time: 0.0962
DEBUG - 2011-09-03 12:07:45 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:45 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Router Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Output Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Input Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:07:45 --> Language Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Loader Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Controller Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:07:45 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:07:46 --> Final output sent to browser
DEBUG - 2011-09-03 12:07:46 --> Total execution time: 0.5481
DEBUG - 2011-09-03 12:07:48 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:48 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:48 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:48 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:48 --> Router Class Initialized
ERROR - 2011-09-03 12:07:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:07:58 --> Config Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:07:58 --> URI Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Router Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Output Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Input Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:07:58 --> Language Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Loader Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Controller Class Initialized
ERROR - 2011-09-03 12:07:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:07:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:07:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:07:58 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Model Class Initialized
DEBUG - 2011-09-03 12:07:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:07:58 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:07:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:07:58 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:07:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:07:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:07:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:07:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:07:58 --> Final output sent to browser
DEBUG - 2011-09-03 12:07:58 --> Total execution time: 0.0279
DEBUG - 2011-09-03 12:08:00 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:00 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:08:00 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Controller Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:00 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:00 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:00 --> Total execution time: 0.4953
DEBUG - 2011-09-03 12:08:11 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:11 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:11 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Global POST and COOKIE data sanitized
ERROR - 2011-09-03 12:08:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:08:11 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Controller Class Initialized
ERROR - 2011-09-03 12:08:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:08:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:08:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:08:11 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:11 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:08:11 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:08:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:08:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:08:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:08:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:08:11 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:11 --> Total execution time: 0.0306
DEBUG - 2011-09-03 12:08:11 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:11 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:08:11 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Controller Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:11 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:12 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:12 --> Total execution time: 0.5878
DEBUG - 2011-09-03 12:08:15 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:15 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:15 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:15 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:15 --> Router Class Initialized
ERROR - 2011-09-03 12:08:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:08:29 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:29 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:08:29 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Controller Class Initialized
ERROR - 2011-09-03 12:08:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:08:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:08:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:08:29 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:29 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:08:29 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:08:29 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:29 --> Total execution time: 0.0286
DEBUG - 2011-09-03 12:08:29 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:29 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:08:29 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Controller Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:29 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:30 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:30 --> Total execution time: 0.4976
DEBUG - 2011-09-03 12:08:32 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:32 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:32 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:32 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:32 --> Router Class Initialized
ERROR - 2011-09-03 12:08:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:08:37 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:37 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:08:37 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Controller Class Initialized
ERROR - 2011-09-03 12:08:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:08:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:08:37 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:37 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:08:37 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:08:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:08:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:08:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:08:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:08:37 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:37 --> Total execution time: 0.0282
DEBUG - 2011-09-03 12:08:38 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:38 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:08:38 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Controller Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:38 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:38 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:38 --> Total execution time: 0.4812
DEBUG - 2011-09-03 12:08:41 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:41 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:41 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:41 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:41 --> Router Class Initialized
ERROR - 2011-09-03 12:08:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:08:46 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:46 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:08:46 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Controller Class Initialized
ERROR - 2011-09-03 12:08:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:08:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:08:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:08:46 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:46 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:08:46 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:08:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:08:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:08:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:08:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:08:46 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:46 --> Total execution time: 0.0271
DEBUG - 2011-09-03 12:08:47 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:47 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Router Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Output Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Input Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:08:47 --> Language Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Loader Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Controller Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Model Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:08:47 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:08:47 --> Final output sent to browser
DEBUG - 2011-09-03 12:08:47 --> Total execution time: 0.5840
DEBUG - 2011-09-03 12:08:50 --> Config Class Initialized
DEBUG - 2011-09-03 12:08:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:08:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:08:50 --> URI Class Initialized
DEBUG - 2011-09-03 12:08:50 --> Router Class Initialized
ERROR - 2011-09-03 12:08:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:09:02 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:02 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:02 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Controller Class Initialized
ERROR - 2011-09-03 12:09:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:09:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:09:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:02 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:02 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:02 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:09:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:09:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:09:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:09:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:09:02 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:02 --> Total execution time: 0.0280
DEBUG - 2011-09-03 12:09:03 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:03 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:03 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Controller Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:03 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:04 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:04 --> Total execution time: 0.5344
DEBUG - 2011-09-03 12:09:06 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:06 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:06 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:06 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:06 --> Router Class Initialized
ERROR - 2011-09-03 12:09:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:09:20 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:20 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:20 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Controller Class Initialized
ERROR - 2011-09-03 12:09:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:09:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:09:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:20 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:20 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:20 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:09:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:09:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:09:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:09:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:09:20 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:20 --> Total execution time: 0.0277
DEBUG - 2011-09-03 12:09:21 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:21 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:21 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Controller Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:21 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:22 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:22 --> Total execution time: 0.5812
DEBUG - 2011-09-03 12:09:24 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:24 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:24 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:24 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:24 --> Router Class Initialized
ERROR - 2011-09-03 12:09:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:09:28 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:28 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:28 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Controller Class Initialized
ERROR - 2011-09-03 12:09:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:09:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:28 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:28 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:28 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:09:28 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:28 --> Total execution time: 0.0268
DEBUG - 2011-09-03 12:09:28 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:28 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:28 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Controller Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:28 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:29 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:29 --> Total execution time: 0.5044
DEBUG - 2011-09-03 12:09:30 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:30 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:30 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Controller Class Initialized
ERROR - 2011-09-03 12:09:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:09:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:09:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:30 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:30 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:30 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:09:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:09:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:09:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:09:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:09:30 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:30 --> Total execution time: 0.0269
DEBUG - 2011-09-03 12:09:32 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:32 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:32 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:32 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:32 --> Router Class Initialized
ERROR - 2011-09-03 12:09:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:09:35 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:35 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:35 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Controller Class Initialized
ERROR - 2011-09-03 12:09:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:09:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:09:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:35 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:35 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:35 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:09:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:09:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:09:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:09:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:09:35 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:35 --> Total execution time: 0.0314
DEBUG - 2011-09-03 12:09:36 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:36 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:36 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Controller Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:36 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:36 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:36 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Controller Class Initialized
ERROR - 2011-09-03 12:09:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:09:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:09:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:36 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:36 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:09:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:09:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:09:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:09:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:09:36 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:36 --> Total execution time: 0.0407
DEBUG - 2011-09-03 12:09:36 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:36 --> Total execution time: 0.6988
DEBUG - 2011-09-03 12:09:39 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:39 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:39 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:39 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:39 --> Router Class Initialized
ERROR - 2011-09-03 12:09:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:09:54 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:54 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:54 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Controller Class Initialized
ERROR - 2011-09-03 12:09:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:09:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:54 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:54 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:09:54 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:09:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:09:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:09:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:09:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:09:54 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:54 --> Total execution time: 0.0285
DEBUG - 2011-09-03 12:09:55 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:55 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Router Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Output Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Input Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:09:55 --> Language Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Loader Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Controller Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Model Class Initialized
DEBUG - 2011-09-03 12:09:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:09:55 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:09:56 --> Final output sent to browser
DEBUG - 2011-09-03 12:09:56 --> Total execution time: 0.5619
DEBUG - 2011-09-03 12:09:58 --> Config Class Initialized
DEBUG - 2011-09-03 12:09:58 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:09:58 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:09:58 --> URI Class Initialized
DEBUG - 2011-09-03 12:09:58 --> Router Class Initialized
ERROR - 2011-09-03 12:09:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:10:04 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:04 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Router Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Output Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Input Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:10:04 --> Language Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Loader Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Controller Class Initialized
ERROR - 2011-09-03 12:10:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:10:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:10:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:04 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:10:04 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:10:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:04 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:10:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:10:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:10:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:10:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:10:04 --> Final output sent to browser
DEBUG - 2011-09-03 12:10:04 --> Total execution time: 0.0546
DEBUG - 2011-09-03 12:10:15 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:15 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Router Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Output Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Input Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:10:15 --> Language Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Loader Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Controller Class Initialized
ERROR - 2011-09-03 12:10:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:10:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:10:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:15 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:10:15 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:10:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:15 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:10:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:10:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:10:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:10:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:10:15 --> Final output sent to browser
DEBUG - 2011-09-03 12:10:15 --> Total execution time: 0.0369
DEBUG - 2011-09-03 12:10:16 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:16 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Router Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Output Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Input Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:10:16 --> Language Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Loader Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Controller Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:10:16 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:10:16 --> Final output sent to browser
DEBUG - 2011-09-03 12:10:16 --> Total execution time: 0.5178
DEBUG - 2011-09-03 12:10:17 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:17 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Router Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Output Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Input Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:10:17 --> Language Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Loader Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Controller Class Initialized
ERROR - 2011-09-03 12:10:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:10:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:10:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:17 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:10:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:10:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:17 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:10:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:10:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:10:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:10:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:10:17 --> Final output sent to browser
DEBUG - 2011-09-03 12:10:17 --> Total execution time: 0.0285
DEBUG - 2011-09-03 12:10:19 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:19 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:19 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:19 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:19 --> Router Class Initialized
ERROR - 2011-09-03 12:10:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:10:21 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:21 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Router Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Output Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Input Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:10:21 --> Language Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Loader Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Controller Class Initialized
ERROR - 2011-09-03 12:10:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:10:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:21 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:10:21 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:21 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:10:21 --> Final output sent to browser
DEBUG - 2011-09-03 12:10:21 --> Total execution time: 0.0290
DEBUG - 2011-09-03 12:10:22 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:22 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Router Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Output Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Input Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:10:22 --> Language Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Loader Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Controller Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:10:22 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Final output sent to browser
DEBUG - 2011-09-03 12:10:23 --> Total execution time: 0.5111
DEBUG - 2011-09-03 12:10:23 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:23 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Router Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Output Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Input Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:10:23 --> Language Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Loader Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Controller Class Initialized
ERROR - 2011-09-03 12:10:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 12:10:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 12:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:23 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Model Class Initialized
DEBUG - 2011-09-03 12:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:10:23 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 12:10:23 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:10:23 --> Final output sent to browser
DEBUG - 2011-09-03 12:10:23 --> Total execution time: 0.0325
DEBUG - 2011-09-03 12:10:25 --> Config Class Initialized
DEBUG - 2011-09-03 12:10:25 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:10:25 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:10:25 --> URI Class Initialized
DEBUG - 2011-09-03 12:10:25 --> Router Class Initialized
ERROR - 2011-09-03 12:10:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:31:36 --> Config Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:31:36 --> URI Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Router Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Output Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Input Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:31:36 --> Language Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Loader Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Controller Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Model Class Initialized
DEBUG - 2011-09-03 12:31:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 12:31:36 --> Database Driver Class Initialized
DEBUG - 2011-09-03 12:31:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 12:31:36 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:31:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:31:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:31:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:31:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:31:36 --> Final output sent to browser
DEBUG - 2011-09-03 12:31:36 --> Total execution time: 0.2229
DEBUG - 2011-09-03 12:31:37 --> Config Class Initialized
DEBUG - 2011-09-03 12:31:37 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:31:37 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:31:37 --> URI Class Initialized
DEBUG - 2011-09-03 12:31:37 --> Router Class Initialized
ERROR - 2011-09-03 12:31:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 12:47:58 --> Config Class Initialized
DEBUG - 2011-09-03 12:47:58 --> Hooks Class Initialized
DEBUG - 2011-09-03 12:47:58 --> Utf8 Class Initialized
DEBUG - 2011-09-03 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 12:47:58 --> URI Class Initialized
DEBUG - 2011-09-03 12:47:58 --> Router Class Initialized
DEBUG - 2011-09-03 12:47:58 --> No URI present. Default controller set.
DEBUG - 2011-09-03 12:47:58 --> Output Class Initialized
DEBUG - 2011-09-03 12:47:58 --> Input Class Initialized
DEBUG - 2011-09-03 12:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 12:47:58 --> Language Class Initialized
DEBUG - 2011-09-03 12:47:58 --> Loader Class Initialized
DEBUG - 2011-09-03 12:47:58 --> Controller Class Initialized
DEBUG - 2011-09-03 12:47:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-03 12:47:58 --> Helper loaded: url_helper
DEBUG - 2011-09-03 12:47:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 12:47:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 12:47:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 12:47:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 12:47:58 --> Final output sent to browser
DEBUG - 2011-09-03 12:47:58 --> Total execution time: 0.0124
DEBUG - 2011-09-03 13:00:10 --> Config Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:00:10 --> URI Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Router Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Output Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Input Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:00:10 --> Language Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Loader Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Controller Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Model Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Model Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Model Class Initialized
DEBUG - 2011-09-03 13:00:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:00:10 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:00:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 13:00:10 --> Helper loaded: url_helper
DEBUG - 2011-09-03 13:00:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 13:00:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 13:00:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 13:00:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 13:00:10 --> Final output sent to browser
DEBUG - 2011-09-03 13:00:10 --> Total execution time: 0.4845
DEBUG - 2011-09-03 13:00:11 --> Config Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:00:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:00:11 --> URI Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Router Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Output Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Input Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:00:11 --> Language Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Loader Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Controller Class Initialized
ERROR - 2011-09-03 13:00:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 13:00:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 13:00:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:00:11 --> Model Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Model Class Initialized
DEBUG - 2011-09-03 13:00:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:00:11 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:00:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:00:11 --> Helper loaded: url_helper
DEBUG - 2011-09-03 13:00:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 13:00:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 13:00:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 13:00:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 13:00:11 --> Final output sent to browser
DEBUG - 2011-09-03 13:00:11 --> Total execution time: 0.0270
DEBUG - 2011-09-03 13:24:40 --> Config Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:24:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:24:40 --> URI Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Router Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Output Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Input Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:24:40 --> Language Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Loader Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Controller Class Initialized
ERROR - 2011-09-03 13:24:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 13:24:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 13:24:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:24:40 --> Model Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Model Class Initialized
DEBUG - 2011-09-03 13:24:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:24:40 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:24:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:24:40 --> Helper loaded: url_helper
DEBUG - 2011-09-03 13:24:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 13:24:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 13:24:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 13:24:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 13:24:40 --> Final output sent to browser
DEBUG - 2011-09-03 13:24:40 --> Total execution time: 0.0447
DEBUG - 2011-09-03 13:24:41 --> Config Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:24:41 --> URI Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Router Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Output Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Input Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:24:41 --> Language Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Loader Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Controller Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Model Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Model Class Initialized
DEBUG - 2011-09-03 13:24:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:24:41 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:24:42 --> Final output sent to browser
DEBUG - 2011-09-03 13:24:42 --> Total execution time: 0.7876
DEBUG - 2011-09-03 13:24:42 --> Config Class Initialized
DEBUG - 2011-09-03 13:24:42 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:24:42 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:24:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:24:42 --> URI Class Initialized
DEBUG - 2011-09-03 13:24:42 --> Router Class Initialized
ERROR - 2011-09-03 13:24:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 13:24:57 --> Config Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:24:57 --> URI Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Router Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Output Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Input Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:24:57 --> Language Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Loader Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Controller Class Initialized
ERROR - 2011-09-03 13:24:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 13:24:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 13:24:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:24:57 --> Model Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Model Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:24:57 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:24:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:24:57 --> Helper loaded: url_helper
DEBUG - 2011-09-03 13:24:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 13:24:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 13:24:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 13:24:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 13:24:57 --> Final output sent to browser
DEBUG - 2011-09-03 13:24:57 --> Total execution time: 0.0283
DEBUG - 2011-09-03 13:24:57 --> Config Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:24:57 --> URI Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Router Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Output Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Input Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:24:57 --> Language Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Loader Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Controller Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Model Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Model Class Initialized
DEBUG - 2011-09-03 13:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:24:57 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:24:58 --> Final output sent to browser
DEBUG - 2011-09-03 13:24:58 --> Total execution time: 0.5872
DEBUG - 2011-09-03 13:24:58 --> Config Class Initialized
DEBUG - 2011-09-03 13:24:58 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:24:58 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:24:58 --> URI Class Initialized
DEBUG - 2011-09-03 13:24:58 --> Router Class Initialized
ERROR - 2011-09-03 13:24:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 13:25:09 --> Config Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:25:09 --> URI Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Router Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Output Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Input Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:25:09 --> Language Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Loader Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Controller Class Initialized
ERROR - 2011-09-03 13:25:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 13:25:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 13:25:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:25:09 --> Model Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Model Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:25:09 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:25:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:25:09 --> Helper loaded: url_helper
DEBUG - 2011-09-03 13:25:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 13:25:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 13:25:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 13:25:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 13:25:09 --> Final output sent to browser
DEBUG - 2011-09-03 13:25:09 --> Total execution time: 0.0316
DEBUG - 2011-09-03 13:25:09 --> Config Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:25:09 --> URI Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Router Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Output Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Input Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:25:09 --> Language Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Loader Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Controller Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Model Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Model Class Initialized
DEBUG - 2011-09-03 13:25:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:25:09 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:25:10 --> Final output sent to browser
DEBUG - 2011-09-03 13:25:10 --> Total execution time: 0.7635
DEBUG - 2011-09-03 13:25:10 --> Config Class Initialized
DEBUG - 2011-09-03 13:25:10 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:25:10 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:25:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:25:10 --> URI Class Initialized
DEBUG - 2011-09-03 13:25:10 --> Router Class Initialized
ERROR - 2011-09-03 13:25:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 13:25:55 --> Config Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:25:55 --> URI Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Router Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Output Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Input Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:25:55 --> Language Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Loader Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Controller Class Initialized
ERROR - 2011-09-03 13:25:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 13:25:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 13:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:25:55 --> Model Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Model Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:25:55 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 13:25:55 --> Helper loaded: url_helper
DEBUG - 2011-09-03 13:25:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 13:25:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 13:25:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 13:25:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 13:25:55 --> Final output sent to browser
DEBUG - 2011-09-03 13:25:55 --> Total execution time: 0.0346
DEBUG - 2011-09-03 13:25:55 --> Config Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:25:55 --> URI Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Router Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Output Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Input Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 13:25:55 --> Language Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Loader Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Controller Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Model Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Model Class Initialized
DEBUG - 2011-09-03 13:25:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 13:25:55 --> Database Driver Class Initialized
DEBUG - 2011-09-03 13:25:56 --> Final output sent to browser
DEBUG - 2011-09-03 13:25:56 --> Total execution time: 0.6208
DEBUG - 2011-09-03 13:25:56 --> Config Class Initialized
DEBUG - 2011-09-03 13:25:56 --> Hooks Class Initialized
DEBUG - 2011-09-03 13:25:56 --> Utf8 Class Initialized
DEBUG - 2011-09-03 13:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 13:25:56 --> URI Class Initialized
DEBUG - 2011-09-03 13:25:56 --> Router Class Initialized
ERROR - 2011-09-03 13:25:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 14:18:06 --> Config Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Hooks Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Utf8 Class Initialized
DEBUG - 2011-09-03 14:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 14:18:06 --> URI Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Router Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Output Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Input Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 14:18:06 --> Language Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Loader Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Controller Class Initialized
ERROR - 2011-09-03 14:18:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 14:18:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 14:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 14:18:06 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 14:18:06 --> Database Driver Class Initialized
DEBUG - 2011-09-03 14:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 14:18:06 --> Helper loaded: url_helper
DEBUG - 2011-09-03 14:18:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 14:18:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 14:18:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 14:18:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 14:18:06 --> Final output sent to browser
DEBUG - 2011-09-03 14:18:06 --> Total execution time: 0.0431
DEBUG - 2011-09-03 14:18:07 --> Config Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 14:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 14:18:07 --> URI Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Router Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Output Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Input Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 14:18:07 --> Language Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Loader Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Controller Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 14:18:07 --> Database Driver Class Initialized
DEBUG - 2011-09-03 14:18:08 --> Final output sent to browser
DEBUG - 2011-09-03 14:18:08 --> Total execution time: 0.5868
DEBUG - 2011-09-03 14:18:09 --> Config Class Initialized
DEBUG - 2011-09-03 14:18:09 --> Hooks Class Initialized
DEBUG - 2011-09-03 14:18:09 --> Utf8 Class Initialized
DEBUG - 2011-09-03 14:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 14:18:09 --> URI Class Initialized
DEBUG - 2011-09-03 14:18:09 --> Router Class Initialized
ERROR - 2011-09-03 14:18:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 14:18:32 --> Config Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Hooks Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Utf8 Class Initialized
DEBUG - 2011-09-03 14:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 14:18:32 --> URI Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Router Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Output Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Input Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 14:18:32 --> Language Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Loader Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Controller Class Initialized
ERROR - 2011-09-03 14:18:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 14:18:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 14:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 14:18:32 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 14:18:32 --> Database Driver Class Initialized
DEBUG - 2011-09-03 14:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 14:18:32 --> Helper loaded: url_helper
DEBUG - 2011-09-03 14:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 14:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 14:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 14:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 14:18:32 --> Final output sent to browser
DEBUG - 2011-09-03 14:18:32 --> Total execution time: 0.0300
DEBUG - 2011-09-03 14:18:33 --> Config Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Hooks Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Utf8 Class Initialized
DEBUG - 2011-09-03 14:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 14:18:33 --> URI Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Router Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Output Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Input Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 14:18:33 --> Language Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Loader Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Controller Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 14:18:33 --> Database Driver Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Final output sent to browser
DEBUG - 2011-09-03 14:18:34 --> Total execution time: 0.6984
DEBUG - 2011-09-03 14:18:34 --> Config Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 14:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 14:18:34 --> URI Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Router Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Output Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Input Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 14:18:34 --> Language Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Loader Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Controller Class Initialized
ERROR - 2011-09-03 14:18:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 14:18:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 14:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 14:18:34 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Model Class Initialized
DEBUG - 2011-09-03 14:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 14:18:34 --> Database Driver Class Initialized
DEBUG - 2011-09-03 14:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 14:18:34 --> Helper loaded: url_helper
DEBUG - 2011-09-03 14:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 14:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 14:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 14:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 14:18:34 --> Final output sent to browser
DEBUG - 2011-09-03 14:18:34 --> Total execution time: 0.0291
DEBUG - 2011-09-03 14:18:35 --> Config Class Initialized
DEBUG - 2011-09-03 14:18:35 --> Hooks Class Initialized
DEBUG - 2011-09-03 14:18:35 --> Utf8 Class Initialized
DEBUG - 2011-09-03 14:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 14:18:35 --> URI Class Initialized
DEBUG - 2011-09-03 14:18:35 --> Router Class Initialized
ERROR - 2011-09-03 14:18:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 15:31:23 --> Config Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:31:23 --> URI Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Router Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Output Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Input Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:31:23 --> Language Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Loader Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Controller Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Model Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Model Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Model Class Initialized
DEBUG - 2011-09-03 15:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:31:23 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:31:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:31:23 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:31:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:31:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:31:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:31:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:31:23 --> Final output sent to browser
DEBUG - 2011-09-03 15:31:23 --> Total execution time: 0.3564
DEBUG - 2011-09-03 15:31:26 --> Config Class Initialized
DEBUG - 2011-09-03 15:31:26 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:31:26 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:31:26 --> URI Class Initialized
DEBUG - 2011-09-03 15:31:26 --> Router Class Initialized
ERROR - 2011-09-03 15:31:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 15:31:27 --> Config Class Initialized
DEBUG - 2011-09-03 15:31:27 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:31:27 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:31:27 --> URI Class Initialized
DEBUG - 2011-09-03 15:31:27 --> Router Class Initialized
ERROR - 2011-09-03 15:31:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 15:31:51 --> Config Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:31:51 --> URI Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Router Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Output Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Input Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:31:51 --> Language Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Loader Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Controller Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Model Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Model Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Model Class Initialized
DEBUG - 2011-09-03 15:31:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:31:51 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:31:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:31:51 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:31:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:31:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:31:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:31:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:31:51 --> Final output sent to browser
DEBUG - 2011-09-03 15:31:51 --> Total execution time: 0.1382
DEBUG - 2011-09-03 15:32:15 --> Config Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:32:15 --> URI Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Router Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Output Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Input Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:32:15 --> Language Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Loader Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Controller Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:32:15 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:32:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:32:16 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:32:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:32:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:32:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:32:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:32:16 --> Final output sent to browser
DEBUG - 2011-09-03 15:32:16 --> Total execution time: 0.3663
DEBUG - 2011-09-03 15:32:26 --> Config Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:32:26 --> URI Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Router Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Output Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Input Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:32:26 --> Language Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Loader Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Controller Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:32:26 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:32:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:32:27 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:32:27 --> Final output sent to browser
DEBUG - 2011-09-03 15:32:27 --> Total execution time: 0.4094
DEBUG - 2011-09-03 15:32:33 --> Config Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:32:33 --> URI Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Router Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Output Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Input Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:32:33 --> Language Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Loader Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Controller Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:32:33 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:32:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:32:34 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:32:34 --> Final output sent to browser
DEBUG - 2011-09-03 15:32:34 --> Total execution time: 0.7201
DEBUG - 2011-09-03 15:32:40 --> Config Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:32:40 --> URI Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Router Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Output Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Input Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:32:40 --> Language Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Loader Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Controller Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:32:40 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:32:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:32:41 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:32:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:32:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:32:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:32:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:32:41 --> Final output sent to browser
DEBUG - 2011-09-03 15:32:41 --> Total execution time: 0.3266
DEBUG - 2011-09-03 15:32:47 --> Config Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:32:47 --> URI Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Router Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Output Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Input Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:32:47 --> Language Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Loader Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Controller Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:32:47 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:32:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:32:47 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:32:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:32:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:32:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:32:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:32:47 --> Final output sent to browser
DEBUG - 2011-09-03 15:32:47 --> Total execution time: 0.2670
DEBUG - 2011-09-03 15:32:54 --> Config Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:32:54 --> URI Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Router Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Output Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Input Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:32:54 --> Language Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Loader Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Controller Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Model Class Initialized
DEBUG - 2011-09-03 15:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:32:54 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:32:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:32:54 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:32:54 --> Final output sent to browser
DEBUG - 2011-09-03 15:32:54 --> Total execution time: 0.5952
DEBUG - 2011-09-03 15:33:07 --> Config Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:33:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:33:07 --> URI Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Router Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Output Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Input Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:33:07 --> Language Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Loader Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Controller Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Model Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Model Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Model Class Initialized
DEBUG - 2011-09-03 15:33:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:33:07 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:33:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:33:07 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:33:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:33:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:33:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:33:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:33:07 --> Final output sent to browser
DEBUG - 2011-09-03 15:33:07 --> Total execution time: 0.3004
DEBUG - 2011-09-03 15:33:28 --> Config Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:33:28 --> URI Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Router Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Output Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Input Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:33:28 --> Language Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Loader Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Controller Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Model Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Model Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Model Class Initialized
DEBUG - 2011-09-03 15:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:33:28 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:33:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:33:28 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:33:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:33:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:33:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:33:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:33:28 --> Final output sent to browser
DEBUG - 2011-09-03 15:33:28 --> Total execution time: 0.0506
DEBUG - 2011-09-03 15:50:18 --> Config Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:50:18 --> URI Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Router Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Output Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Input Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 15:50:18 --> Language Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Loader Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Controller Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Model Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Model Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Model Class Initialized
DEBUG - 2011-09-03 15:50:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 15:50:18 --> Database Driver Class Initialized
DEBUG - 2011-09-03 15:50:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 15:50:18 --> Helper loaded: url_helper
DEBUG - 2011-09-03 15:50:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 15:50:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 15:50:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 15:50:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 15:50:18 --> Final output sent to browser
DEBUG - 2011-09-03 15:50:18 --> Total execution time: 0.0796
DEBUG - 2011-09-03 15:50:22 --> Config Class Initialized
DEBUG - 2011-09-03 15:50:22 --> Hooks Class Initialized
DEBUG - 2011-09-03 15:50:22 --> Utf8 Class Initialized
DEBUG - 2011-09-03 15:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 15:50:22 --> URI Class Initialized
DEBUG - 2011-09-03 15:50:22 --> Router Class Initialized
ERROR - 2011-09-03 15:50:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 17:00:10 --> Config Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:00:10 --> URI Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Router Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Output Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Input Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:00:10 --> Language Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Loader Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Controller Class Initialized
ERROR - 2011-09-03 17:00:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 17:00:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 17:00:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:00:10 --> Model Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Model Class Initialized
DEBUG - 2011-09-03 17:00:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:00:10 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:00:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:00:10 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:00:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:00:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:00:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:00:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:00:10 --> Final output sent to browser
DEBUG - 2011-09-03 17:00:10 --> Total execution time: 0.0401
DEBUG - 2011-09-03 17:01:42 --> Config Class Initialized
DEBUG - 2011-09-03 17:01:42 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:01:42 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:01:42 --> URI Class Initialized
DEBUG - 2011-09-03 17:01:42 --> Router Class Initialized
DEBUG - 2011-09-03 17:01:42 --> No URI present. Default controller set.
DEBUG - 2011-09-03 17:01:42 --> Output Class Initialized
DEBUG - 2011-09-03 17:01:42 --> Input Class Initialized
DEBUG - 2011-09-03 17:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:01:42 --> Language Class Initialized
DEBUG - 2011-09-03 17:01:42 --> Loader Class Initialized
DEBUG - 2011-09-03 17:01:42 --> Controller Class Initialized
DEBUG - 2011-09-03 17:01:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-03 17:01:42 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:01:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:01:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:01:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:01:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:01:42 --> Final output sent to browser
DEBUG - 2011-09-03 17:01:42 --> Total execution time: 0.0196
DEBUG - 2011-09-03 17:05:47 --> Config Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:05:47 --> URI Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Router Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Output Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Input Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:05:47 --> Language Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Loader Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Controller Class Initialized
ERROR - 2011-09-03 17:05:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 17:05:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 17:05:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:05:47 --> Model Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Model Class Initialized
DEBUG - 2011-09-03 17:05:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:05:47 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:05:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:05:47 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:05:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:05:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:05:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:05:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:05:47 --> Final output sent to browser
DEBUG - 2011-09-03 17:05:47 --> Total execution time: 0.0276
DEBUG - 2011-09-03 17:05:48 --> Config Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:05:48 --> URI Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Router Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Output Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Input Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:05:48 --> Language Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Loader Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Controller Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Model Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Model Class Initialized
DEBUG - 2011-09-03 17:05:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:05:48 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:05:49 --> Final output sent to browser
DEBUG - 2011-09-03 17:05:49 --> Total execution time: 0.5867
DEBUG - 2011-09-03 17:06:17 --> Config Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:06:17 --> URI Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Router Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Output Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Input Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:06:17 --> Language Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Loader Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Controller Class Initialized
ERROR - 2011-09-03 17:06:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 17:06:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 17:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:06:17 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:06:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:06:17 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:06:17 --> Final output sent to browser
DEBUG - 2011-09-03 17:06:17 --> Total execution time: 0.0311
DEBUG - 2011-09-03 17:06:18 --> Config Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:06:18 --> URI Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Router Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Output Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Input Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:06:18 --> Language Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Loader Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Controller Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:06:18 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:06:18 --> Final output sent to browser
DEBUG - 2011-09-03 17:06:18 --> Total execution time: 0.6279
DEBUG - 2011-09-03 17:06:26 --> Config Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:06:26 --> URI Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Router Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Output Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Input Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:06:26 --> Language Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Loader Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Controller Class Initialized
ERROR - 2011-09-03 17:06:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 17:06:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 17:06:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:06:26 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:06:26 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:06:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:06:26 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:06:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:06:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:06:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:06:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:06:26 --> Final output sent to browser
DEBUG - 2011-09-03 17:06:26 --> Total execution time: 0.0328
DEBUG - 2011-09-03 17:06:28 --> Config Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:06:28 --> URI Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Router Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Output Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Input Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:06:28 --> Language Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Loader Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Controller Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:06:28 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:06:29 --> Final output sent to browser
DEBUG - 2011-09-03 17:06:29 --> Total execution time: 0.5493
DEBUG - 2011-09-03 17:06:34 --> Config Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:06:34 --> URI Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Router Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Output Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Input Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:06:34 --> Language Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Loader Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Controller Class Initialized
ERROR - 2011-09-03 17:06:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 17:06:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 17:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:06:34 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:06:34 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:06:34 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:06:34 --> Final output sent to browser
DEBUG - 2011-09-03 17:06:34 --> Total execution time: 0.0306
DEBUG - 2011-09-03 17:06:35 --> Config Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:06:35 --> URI Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Router Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Output Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Input Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:06:35 --> Language Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Loader Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Controller Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Model Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:06:35 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:06:35 --> Final output sent to browser
DEBUG - 2011-09-03 17:06:35 --> Total execution time: 0.6445
DEBUG - 2011-09-03 17:30:00 --> Config Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:30:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:30:00 --> URI Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Router Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Output Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Input Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:30:00 --> Language Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Loader Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Controller Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Model Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Model Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Model Class Initialized
DEBUG - 2011-09-03 17:30:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:30:00 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:30:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 17:30:01 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:30:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:30:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:30:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:30:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:30:01 --> Final output sent to browser
DEBUG - 2011-09-03 17:30:01 --> Total execution time: 0.5973
DEBUG - 2011-09-03 17:30:03 --> Config Class Initialized
DEBUG - 2011-09-03 17:30:03 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:30:03 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:30:03 --> URI Class Initialized
DEBUG - 2011-09-03 17:30:03 --> Router Class Initialized
ERROR - 2011-09-03 17:30:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 17:30:04 --> Config Class Initialized
DEBUG - 2011-09-03 17:30:04 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:30:04 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:30:04 --> URI Class Initialized
DEBUG - 2011-09-03 17:30:04 --> Router Class Initialized
ERROR - 2011-09-03 17:30:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 17:44:16 --> Config Class Initialized
DEBUG - 2011-09-03 17:44:16 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:44:16 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:44:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:44:16 --> URI Class Initialized
DEBUG - 2011-09-03 17:44:16 --> Router Class Initialized
ERROR - 2011-09-03 17:44:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-03 17:44:17 --> Config Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:44:17 --> URI Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Router Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Output Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Input Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:44:17 --> Language Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Loader Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Controller Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Model Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Model Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Model Class Initialized
DEBUG - 2011-09-03 17:44:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:44:17 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:44:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 17:44:17 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:44:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:44:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:44:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:44:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:44:17 --> Final output sent to browser
DEBUG - 2011-09-03 17:44:17 --> Total execution time: 0.0459
DEBUG - 2011-09-03 17:44:18 --> Config Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Hooks Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Utf8 Class Initialized
DEBUG - 2011-09-03 17:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 17:44:18 --> URI Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Router Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Output Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Input Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 17:44:18 --> Language Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Loader Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Controller Class Initialized
ERROR - 2011-09-03 17:44:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 17:44:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 17:44:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:44:18 --> Model Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Model Class Initialized
DEBUG - 2011-09-03 17:44:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 17:44:18 --> Database Driver Class Initialized
DEBUG - 2011-09-03 17:44:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 17:44:18 --> Helper loaded: url_helper
DEBUG - 2011-09-03 17:44:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 17:44:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 17:44:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 17:44:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 17:44:18 --> Final output sent to browser
DEBUG - 2011-09-03 17:44:18 --> Total execution time: 0.0618
DEBUG - 2011-09-03 19:10:11 --> Config Class Initialized
DEBUG - 2011-09-03 19:10:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:10:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:10:11 --> URI Class Initialized
DEBUG - 2011-09-03 19:10:11 --> Router Class Initialized
ERROR - 2011-09-03 19:10:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-03 19:10:11 --> Config Class Initialized
DEBUG - 2011-09-03 19:10:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:10:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:10:11 --> URI Class Initialized
DEBUG - 2011-09-03 19:10:11 --> Router Class Initialized
ERROR - 2011-09-03 19:10:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-03 19:10:12 --> Config Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:10:12 --> URI Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Router Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Output Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Input Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 19:10:12 --> Language Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Loader Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Controller Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Model Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Model Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Model Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 19:10:12 --> Database Driver Class Initialized
DEBUG - 2011-09-03 19:10:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 19:10:12 --> Helper loaded: url_helper
DEBUG - 2011-09-03 19:10:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 19:10:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 19:10:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 19:10:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 19:10:12 --> Final output sent to browser
DEBUG - 2011-09-03 19:10:12 --> Total execution time: 0.3296
DEBUG - 2011-09-03 19:10:12 --> Config Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:10:12 --> URI Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Router Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Output Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Input Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 19:10:12 --> Language Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Loader Class Initialized
DEBUG - 2011-09-03 19:10:12 --> Controller Class Initialized
ERROR - 2011-09-03 19:10:12 --> 404 Page Not Found --> table/text
DEBUG - 2011-09-03 19:12:24 --> Config Class Initialized
DEBUG - 2011-09-03 19:12:24 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:12:24 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:12:24 --> URI Class Initialized
DEBUG - 2011-09-03 19:12:24 --> Router Class Initialized
DEBUG - 2011-09-03 19:12:24 --> Output Class Initialized
DEBUG - 2011-09-03 19:12:24 --> Input Class Initialized
DEBUG - 2011-09-03 19:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 19:12:24 --> Language Class Initialized
DEBUG - 2011-09-03 19:12:24 --> Loader Class Initialized
DEBUG - 2011-09-03 19:12:24 --> Controller Class Initialized
ERROR - 2011-09-03 19:12:24 --> 404 Page Not Found --> snakes/text
DEBUG - 2011-09-03 19:13:29 --> Config Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:13:29 --> URI Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Router Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Output Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Input Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 19:13:29 --> Language Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Loader Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Controller Class Initialized
ERROR - 2011-09-03 19:13:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 19:13:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 19:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 19:13:29 --> Model Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Model Class Initialized
DEBUG - 2011-09-03 19:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 19:13:29 --> Database Driver Class Initialized
DEBUG - 2011-09-03 19:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 19:13:29 --> Helper loaded: url_helper
DEBUG - 2011-09-03 19:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 19:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 19:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 19:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 19:13:29 --> Final output sent to browser
DEBUG - 2011-09-03 19:13:29 --> Total execution time: 0.0294
DEBUG - 2011-09-03 19:18:50 --> Config Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:18:50 --> URI Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Router Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Output Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Input Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 19:18:50 --> Language Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Loader Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Controller Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Model Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Model Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Model Class Initialized
DEBUG - 2011-09-03 19:18:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 19:18:50 --> Database Driver Class Initialized
DEBUG - 2011-09-03 19:18:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 19:18:50 --> Helper loaded: url_helper
DEBUG - 2011-09-03 19:18:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 19:18:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 19:18:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 19:18:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 19:18:50 --> Final output sent to browser
DEBUG - 2011-09-03 19:18:50 --> Total execution time: 0.0446
DEBUG - 2011-09-03 19:18:51 --> Config Class Initialized
DEBUG - 2011-09-03 19:18:51 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:18:51 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:18:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:18:51 --> URI Class Initialized
DEBUG - 2011-09-03 19:18:51 --> Router Class Initialized
ERROR - 2011-09-03 19:18:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 19:18:53 --> Config Class Initialized
DEBUG - 2011-09-03 19:18:53 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:18:53 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:18:53 --> URI Class Initialized
DEBUG - 2011-09-03 19:18:53 --> Router Class Initialized
ERROR - 2011-09-03 19:18:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 19:39:19 --> Config Class Initialized
DEBUG - 2011-09-03 19:39:19 --> Hooks Class Initialized
DEBUG - 2011-09-03 19:39:19 --> Utf8 Class Initialized
DEBUG - 2011-09-03 19:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 19:39:19 --> URI Class Initialized
DEBUG - 2011-09-03 19:39:19 --> Router Class Initialized
DEBUG - 2011-09-03 19:39:19 --> No URI present. Default controller set.
DEBUG - 2011-09-03 19:39:19 --> Output Class Initialized
DEBUG - 2011-09-03 19:39:19 --> Input Class Initialized
DEBUG - 2011-09-03 19:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 19:39:19 --> Language Class Initialized
DEBUG - 2011-09-03 19:39:19 --> Loader Class Initialized
DEBUG - 2011-09-03 19:39:19 --> Controller Class Initialized
DEBUG - 2011-09-03 19:39:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-03 19:39:19 --> Helper loaded: url_helper
DEBUG - 2011-09-03 19:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 19:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 19:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 19:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 19:39:19 --> Final output sent to browser
DEBUG - 2011-09-03 19:39:19 --> Total execution time: 0.0138
DEBUG - 2011-09-03 21:21:00 --> Config Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:21:00 --> URI Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Router Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Output Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Input Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 21:21:00 --> Language Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Loader Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Controller Class Initialized
ERROR - 2011-09-03 21:21:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 21:21:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 21:21:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 21:21:00 --> Model Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Model Class Initialized
DEBUG - 2011-09-03 21:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 21:21:00 --> Database Driver Class Initialized
DEBUG - 2011-09-03 21:21:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 21:21:00 --> Helper loaded: url_helper
DEBUG - 2011-09-03 21:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 21:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 21:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 21:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 21:21:00 --> Final output sent to browser
DEBUG - 2011-09-03 21:21:00 --> Total execution time: 0.0543
DEBUG - 2011-09-03 21:21:07 --> Config Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:21:07 --> URI Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Router Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Output Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Input Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 21:21:07 --> Language Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Loader Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Controller Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Model Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Model Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 21:21:07 --> Database Driver Class Initialized
DEBUG - 2011-09-03 21:21:07 --> Final output sent to browser
DEBUG - 2011-09-03 21:21:07 --> Total execution time: 0.6447
DEBUG - 2011-09-03 21:21:12 --> Config Class Initialized
DEBUG - 2011-09-03 21:21:12 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:21:12 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:21:12 --> URI Class Initialized
DEBUG - 2011-09-03 21:21:12 --> Router Class Initialized
ERROR - 2011-09-03 21:21:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 21:25:21 --> Config Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:25:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:25:21 --> URI Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Router Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Output Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Input Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 21:25:21 --> Language Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Loader Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Controller Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 21:25:21 --> Database Driver Class Initialized
DEBUG - 2011-09-03 21:25:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 21:25:21 --> Helper loaded: url_helper
DEBUG - 2011-09-03 21:25:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 21:25:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 21:25:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 21:25:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 21:25:21 --> Final output sent to browser
DEBUG - 2011-09-03 21:25:21 --> Total execution time: 0.2721
DEBUG - 2011-09-03 21:25:23 --> Config Class Initialized
DEBUG - 2011-09-03 21:25:23 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:25:23 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:25:23 --> URI Class Initialized
DEBUG - 2011-09-03 21:25:23 --> Router Class Initialized
ERROR - 2011-09-03 21:25:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 21:25:33 --> Config Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:25:33 --> URI Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Router Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Output Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Input Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 21:25:33 --> Language Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Loader Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Controller Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 21:25:33 --> Database Driver Class Initialized
DEBUG - 2011-09-03 21:25:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 21:25:33 --> Helper loaded: url_helper
DEBUG - 2011-09-03 21:25:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 21:25:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 21:25:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 21:25:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 21:25:33 --> Final output sent to browser
DEBUG - 2011-09-03 21:25:33 --> Total execution time: 0.0424
DEBUG - 2011-09-03 21:25:34 --> Config Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:25:34 --> URI Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Router Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Output Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Input Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 21:25:34 --> Language Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Loader Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Controller Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 21:25:34 --> Database Driver Class Initialized
DEBUG - 2011-09-03 21:25:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 21:25:34 --> Helper loaded: url_helper
DEBUG - 2011-09-03 21:25:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 21:25:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 21:25:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 21:25:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 21:25:34 --> Final output sent to browser
DEBUG - 2011-09-03 21:25:34 --> Total execution time: 0.0422
DEBUG - 2011-09-03 21:25:34 --> Config Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:25:34 --> URI Class Initialized
DEBUG - 2011-09-03 21:25:34 --> Router Class Initialized
ERROR - 2011-09-03 21:25:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 21:25:44 --> Config Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:25:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:25:44 --> URI Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Router Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Output Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Input Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 21:25:44 --> Language Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Loader Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Controller Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 21:25:44 --> Database Driver Class Initialized
DEBUG - 2011-09-03 21:25:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 21:25:44 --> Helper loaded: url_helper
DEBUG - 2011-09-03 21:25:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 21:25:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 21:25:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 21:25:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 21:25:44 --> Final output sent to browser
DEBUG - 2011-09-03 21:25:44 --> Total execution time: 0.2082
DEBUG - 2011-09-03 21:25:46 --> Config Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:25:46 --> URI Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Router Class Initialized
ERROR - 2011-09-03 21:25:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 21:25:46 --> Config Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:25:46 --> URI Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Router Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Output Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Input Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 21:25:46 --> Language Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Loader Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Controller Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Model Class Initialized
DEBUG - 2011-09-03 21:25:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 21:25:46 --> Database Driver Class Initialized
DEBUG - 2011-09-03 21:25:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-03 21:25:46 --> Helper loaded: url_helper
DEBUG - 2011-09-03 21:25:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 21:25:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 21:25:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 21:25:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 21:25:46 --> Final output sent to browser
DEBUG - 2011-09-03 21:25:46 --> Total execution time: 0.0443
DEBUG - 2011-09-03 21:26:07 --> Config Class Initialized
DEBUG - 2011-09-03 21:26:07 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:26:07 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:26:07 --> URI Class Initialized
DEBUG - 2011-09-03 21:26:07 --> Router Class Initialized
ERROR - 2011-09-03 21:26:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 21:26:08 --> Config Class Initialized
DEBUG - 2011-09-03 21:26:08 --> Hooks Class Initialized
DEBUG - 2011-09-03 21:26:08 --> Utf8 Class Initialized
DEBUG - 2011-09-03 21:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 21:26:08 --> URI Class Initialized
DEBUG - 2011-09-03 21:26:08 --> Router Class Initialized
ERROR - 2011-09-03 21:26:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 22:34:01 --> Config Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Hooks Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Utf8 Class Initialized
DEBUG - 2011-09-03 22:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 22:34:01 --> URI Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Router Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Output Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Input Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 22:34:01 --> Language Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Loader Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Controller Class Initialized
ERROR - 2011-09-03 22:34:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 22:34:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 22:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 22:34:01 --> Model Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Model Class Initialized
DEBUG - 2011-09-03 22:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 22:34:01 --> Database Driver Class Initialized
DEBUG - 2011-09-03 22:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 22:34:01 --> Helper loaded: url_helper
DEBUG - 2011-09-03 22:34:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 22:34:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 22:34:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 22:34:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 22:34:01 --> Final output sent to browser
DEBUG - 2011-09-03 22:34:01 --> Total execution time: 0.0566
DEBUG - 2011-09-03 22:34:05 --> Config Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Hooks Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Utf8 Class Initialized
DEBUG - 2011-09-03 22:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 22:34:05 --> URI Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Router Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Output Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Input Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 22:34:05 --> Language Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Loader Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Controller Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Model Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Model Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 22:34:05 --> Database Driver Class Initialized
DEBUG - 2011-09-03 22:34:05 --> Final output sent to browser
DEBUG - 2011-09-03 22:34:05 --> Total execution time: 0.6781
DEBUG - 2011-09-03 22:34:09 --> Config Class Initialized
DEBUG - 2011-09-03 22:34:09 --> Hooks Class Initialized
DEBUG - 2011-09-03 22:34:09 --> Utf8 Class Initialized
DEBUG - 2011-09-03 22:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 22:34:09 --> URI Class Initialized
DEBUG - 2011-09-03 22:34:09 --> Router Class Initialized
ERROR - 2011-09-03 22:34:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 22:34:11 --> Config Class Initialized
DEBUG - 2011-09-03 22:34:11 --> Hooks Class Initialized
DEBUG - 2011-09-03 22:34:11 --> Utf8 Class Initialized
DEBUG - 2011-09-03 22:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 22:34:11 --> URI Class Initialized
DEBUG - 2011-09-03 22:34:11 --> Router Class Initialized
ERROR - 2011-09-03 22:34:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-03 23:34:30 --> Config Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Hooks Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Utf8 Class Initialized
DEBUG - 2011-09-03 23:34:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 23:34:30 --> URI Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Router Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Output Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Input Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 23:34:30 --> Language Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Loader Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Controller Class Initialized
ERROR - 2011-09-03 23:34:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 23:34:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 23:34:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 23:34:30 --> Model Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Model Class Initialized
DEBUG - 2011-09-03 23:34:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 23:34:30 --> Database Driver Class Initialized
DEBUG - 2011-09-03 23:34:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 23:34:30 --> Helper loaded: url_helper
DEBUG - 2011-09-03 23:34:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 23:34:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 23:34:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 23:34:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 23:34:30 --> Final output sent to browser
DEBUG - 2011-09-03 23:34:30 --> Total execution time: 0.0767
DEBUG - 2011-09-03 23:43:45 --> Config Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Hooks Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Utf8 Class Initialized
DEBUG - 2011-09-03 23:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-03 23:43:45 --> URI Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Router Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Output Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Input Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-03 23:43:45 --> Language Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Loader Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Controller Class Initialized
ERROR - 2011-09-03 23:43:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-03 23:43:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-03 23:43:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 23:43:45 --> Model Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Model Class Initialized
DEBUG - 2011-09-03 23:43:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-03 23:43:45 --> Database Driver Class Initialized
DEBUG - 2011-09-03 23:43:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-03 23:43:45 --> Helper loaded: url_helper
DEBUG - 2011-09-03 23:43:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-03 23:43:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-03 23:43:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-03 23:43:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-03 23:43:45 --> Final output sent to browser
DEBUG - 2011-09-03 23:43:45 --> Total execution time: 0.0262

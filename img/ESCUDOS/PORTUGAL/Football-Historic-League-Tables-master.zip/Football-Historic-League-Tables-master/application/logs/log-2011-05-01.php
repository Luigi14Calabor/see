<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-01 01:08:00 --> Config Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:08:00 --> URI Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Router Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Output Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Input Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:08:00 --> Language Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Loader Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Controller Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 01:08:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:08:01 --> Final output sent to browser
DEBUG - 2011-05-01 01:08:01 --> Total execution time: 0.9075
DEBUG - 2011-05-01 01:45:16 --> Config Class Initialized
DEBUG - 2011-05-01 01:45:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:45:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:45:16 --> URI Class Initialized
DEBUG - 2011-05-01 01:45:16 --> Router Class Initialized
DEBUG - 2011-05-01 01:45:16 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:45:16 --> Output Class Initialized
DEBUG - 2011-05-01 01:45:16 --> Input Class Initialized
DEBUG - 2011-05-01 01:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:45:16 --> Language Class Initialized
DEBUG - 2011-05-01 01:45:16 --> Loader Class Initialized
DEBUG - 2011-05-01 01:45:16 --> Controller Class Initialized
DEBUG - 2011-05-01 01:45:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 01:45:17 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:45:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 01:45:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 01:45:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 01:45:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 01:45:17 --> Final output sent to browser
DEBUG - 2011-05-01 01:45:17 --> Total execution time: 1.5651
DEBUG - 2011-05-01 01:52:55 --> Config Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:52:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:52:55 --> URI Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Router Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Output Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Input Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:52:55 --> Language Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Loader Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Controller Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Model Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Model Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Model Class Initialized
DEBUG - 2011-05-01 01:52:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 01:52:55 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:53:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 01:53:07 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:53:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 01:53:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 01:53:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 01:53:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 01:53:07 --> Final output sent to browser
DEBUG - 2011-05-01 01:53:07 --> Total execution time: 12.2710
DEBUG - 2011-05-01 01:53:08 --> Config Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:53:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:53:08 --> URI Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Router Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Output Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Input Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:53:08 --> Language Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Loader Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Controller Class Initialized
ERROR - 2011-05-01 01:53:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 01:53:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 01:53:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 01:53:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:53:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 01:53:08 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:53:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 01:53:08 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:53:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 01:53:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 01:53:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 01:53:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 01:53:08 --> Final output sent to browser
DEBUG - 2011-05-01 01:53:08 --> Total execution time: 0.1213
DEBUG - 2011-05-01 03:19:53 --> Config Class Initialized
DEBUG - 2011-05-01 03:19:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 03:19:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 03:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 03:19:53 --> URI Class Initialized
DEBUG - 2011-05-01 03:19:53 --> Router Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Output Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Input Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 03:19:54 --> Language Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Loader Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Controller Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Model Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Model Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Model Class Initialized
DEBUG - 2011-05-01 03:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 03:19:54 --> Database Driver Class Initialized
DEBUG - 2011-05-01 03:20:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 03:20:25 --> Helper loaded: url_helper
DEBUG - 2011-05-01 03:20:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 03:20:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 03:20:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 03:20:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 03:20:25 --> Final output sent to browser
DEBUG - 2011-05-01 03:20:25 --> Total execution time: 31.7167
DEBUG - 2011-05-01 04:28:51 --> Config Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:28:51 --> URI Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Router Class Initialized
ERROR - 2011-05-01 04:28:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-01 04:28:51 --> Config Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:28:51 --> URI Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Router Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Output Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Input Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:28:51 --> Language Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Loader Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Controller Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Model Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Model Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Model Class Initialized
DEBUG - 2011-05-01 04:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:28:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:28:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:28:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:28:52 --> Final output sent to browser
DEBUG - 2011-05-01 04:28:52 --> Total execution time: 1.2872
DEBUG - 2011-05-01 04:31:03 --> Config Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:31:03 --> URI Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Router Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Output Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Input Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:31:03 --> Language Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Loader Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Controller Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Model Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Model Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Model Class Initialized
DEBUG - 2011-05-01 04:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:31:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:31:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:31:03 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:31:03 --> Final output sent to browser
DEBUG - 2011-05-01 04:31:03 --> Total execution time: 0.0598
DEBUG - 2011-05-01 04:31:05 --> Config Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:31:05 --> URI Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Router Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Output Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Input Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:31:05 --> Language Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Loader Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Controller Class Initialized
ERROR - 2011-05-01 04:31:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 04:31:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 04:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 04:31:05 --> Model Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Model Class Initialized
DEBUG - 2011-05-01 04:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:31:05 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 04:31:05 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:31:05 --> Final output sent to browser
DEBUG - 2011-05-01 04:31:05 --> Total execution time: 0.0988
DEBUG - 2011-05-01 04:50:07 --> Config Class Initialized
DEBUG - 2011-05-01 04:50:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:50:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:50:07 --> URI Class Initialized
DEBUG - 2011-05-01 04:50:07 --> Router Class Initialized
DEBUG - 2011-05-01 04:50:07 --> No URI present. Default controller set.
DEBUG - 2011-05-01 04:50:07 --> Output Class Initialized
DEBUG - 2011-05-01 04:50:07 --> Input Class Initialized
DEBUG - 2011-05-01 04:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:50:07 --> Language Class Initialized
DEBUG - 2011-05-01 04:50:07 --> Loader Class Initialized
DEBUG - 2011-05-01 04:50:07 --> Controller Class Initialized
DEBUG - 2011-05-01 04:50:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 04:50:08 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:50:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:50:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:50:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:50:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:50:08 --> Final output sent to browser
DEBUG - 2011-05-01 04:50:08 --> Total execution time: 0.6714
DEBUG - 2011-05-01 04:50:10 --> Config Class Initialized
DEBUG - 2011-05-01 04:50:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:50:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:50:10 --> URI Class Initialized
DEBUG - 2011-05-01 04:50:10 --> Router Class Initialized
ERROR - 2011-05-01 04:50:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 04:50:35 --> Config Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:50:35 --> URI Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Router Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Output Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Input Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:50:35 --> Language Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Loader Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Controller Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Model Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Model Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Model Class Initialized
DEBUG - 2011-05-01 04:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:50:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:50:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:50:35 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:50:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:50:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:50:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:50:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:50:35 --> Final output sent to browser
DEBUG - 2011-05-01 04:50:35 --> Total execution time: 0.2125
DEBUG - 2011-05-01 04:50:40 --> Config Class Initialized
DEBUG - 2011-05-01 04:50:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:50:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:50:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:50:40 --> URI Class Initialized
DEBUG - 2011-05-01 04:50:40 --> Router Class Initialized
DEBUG - 2011-05-01 04:50:40 --> No URI present. Default controller set.
DEBUG - 2011-05-01 04:50:40 --> Output Class Initialized
DEBUG - 2011-05-01 04:50:40 --> Input Class Initialized
DEBUG - 2011-05-01 04:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:50:40 --> Language Class Initialized
DEBUG - 2011-05-01 04:50:40 --> Loader Class Initialized
DEBUG - 2011-05-01 04:50:40 --> Controller Class Initialized
DEBUG - 2011-05-01 04:50:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 04:50:40 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:50:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:50:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:50:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:50:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:50:40 --> Final output sent to browser
DEBUG - 2011-05-01 04:50:40 --> Total execution time: 0.0147
DEBUG - 2011-05-01 04:50:57 --> Config Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:50:57 --> URI Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Router Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Output Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Input Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:50:57 --> Language Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Loader Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Controller Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Model Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Model Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Model Class Initialized
DEBUG - 2011-05-01 04:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:50:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:50:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:50:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:50:58 --> Final output sent to browser
DEBUG - 2011-05-01 04:50:58 --> Total execution time: 0.2122
DEBUG - 2011-05-01 04:51:05 --> Config Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:51:05 --> URI Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Router Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Output Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Input Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:51:05 --> Language Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Loader Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Controller Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Model Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Model Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Model Class Initialized
DEBUG - 2011-05-01 04:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:51:05 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:51:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:51:06 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:51:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:51:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:51:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:51:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:51:06 --> Final output sent to browser
DEBUG - 2011-05-01 04:51:06 --> Total execution time: 0.4048
DEBUG - 2011-05-01 04:51:08 --> Config Class Initialized
DEBUG - 2011-05-01 04:51:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:51:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:51:08 --> URI Class Initialized
DEBUG - 2011-05-01 04:51:08 --> Router Class Initialized
ERROR - 2011-05-01 04:51:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-01 04:51:24 --> Config Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:51:24 --> URI Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Router Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Output Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Input Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:51:24 --> Language Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Loader Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Controller Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Model Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Model Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Model Class Initialized
DEBUG - 2011-05-01 04:51:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:51:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:51:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:51:24 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:51:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:51:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:51:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:51:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:51:24 --> Final output sent to browser
DEBUG - 2011-05-01 04:51:24 --> Total execution time: 0.2358
DEBUG - 2011-05-01 04:54:31 --> Config Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:54:31 --> URI Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Router Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Output Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Input Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:54:31 --> Language Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Loader Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Controller Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:54:31 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:54:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:54:31 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:54:31 --> Final output sent to browser
DEBUG - 2011-05-01 04:54:31 --> Total execution time: 0.0442
DEBUG - 2011-05-01 04:54:34 --> Config Class Initialized
DEBUG - 2011-05-01 04:54:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:54:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:54:34 --> URI Class Initialized
DEBUG - 2011-05-01 04:54:34 --> Router Class Initialized
ERROR - 2011-05-01 04:54:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 04:54:34 --> Config Class Initialized
DEBUG - 2011-05-01 04:54:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:54:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:54:34 --> URI Class Initialized
DEBUG - 2011-05-01 04:54:34 --> Router Class Initialized
ERROR - 2011-05-01 04:54:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 04:54:42 --> Config Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:54:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:54:42 --> URI Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Router Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Output Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Input Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:54:42 --> Language Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Loader Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Controller Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:54:42 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:54:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:54:42 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:54:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:54:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:54:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:54:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:54:42 --> Final output sent to browser
DEBUG - 2011-05-01 04:54:42 --> Total execution time: 0.3300
DEBUG - 2011-05-01 04:54:44 --> Config Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:54:44 --> URI Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Router Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Output Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Input Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:54:44 --> Language Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Loader Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Controller Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:54:44 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:54:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:54:44 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:54:44 --> Final output sent to browser
DEBUG - 2011-05-01 04:54:44 --> Total execution time: 0.0740
DEBUG - 2011-05-01 04:54:57 --> Config Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:54:57 --> URI Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Router Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Output Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Input Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:54:57 --> Language Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Loader Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Controller Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Model Class Initialized
DEBUG - 2011-05-01 04:54:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:54:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:55:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:55:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:55:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:55:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:55:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:55:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:55:00 --> Final output sent to browser
DEBUG - 2011-05-01 04:55:00 --> Total execution time: 3.4099
DEBUG - 2011-05-01 04:55:09 --> Config Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:55:09 --> URI Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Router Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Output Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Input Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:55:09 --> Language Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Loader Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Controller Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Model Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Model Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Model Class Initialized
DEBUG - 2011-05-01 04:55:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:55:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:55:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:55:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:55:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:55:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:55:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:55:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:55:09 --> Final output sent to browser
DEBUG - 2011-05-01 04:55:09 --> Total execution time: 0.0578
DEBUG - 2011-05-01 04:55:12 --> Config Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 04:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 04:55:12 --> URI Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Router Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Output Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Input Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 04:55:12 --> Language Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Loader Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Controller Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Model Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Model Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Model Class Initialized
DEBUG - 2011-05-01 04:55:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 04:55:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 04:55:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 04:55:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 04:55:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 04:55:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 04:55:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 04:55:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 04:55:58 --> Final output sent to browser
DEBUG - 2011-05-01 04:55:58 --> Total execution time: 46.4038
DEBUG - 2011-05-01 05:25:24 --> Config Class Initialized
DEBUG - 2011-05-01 05:25:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:25:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:25:24 --> URI Class Initialized
DEBUG - 2011-05-01 05:25:24 --> Router Class Initialized
DEBUG - 2011-05-01 05:25:25 --> Output Class Initialized
DEBUG - 2011-05-01 05:25:25 --> Input Class Initialized
DEBUG - 2011-05-01 05:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 05:25:25 --> Language Class Initialized
DEBUG - 2011-05-01 05:25:26 --> Loader Class Initialized
DEBUG - 2011-05-01 05:25:26 --> Controller Class Initialized
ERROR - 2011-05-01 05:25:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 05:25:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 05:25:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 05:25:28 --> Model Class Initialized
DEBUG - 2011-05-01 05:25:28 --> Model Class Initialized
DEBUG - 2011-05-01 05:25:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 05:25:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 05:25:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 05:25:30 --> Helper loaded: url_helper
DEBUG - 2011-05-01 05:25:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 05:25:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 05:25:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 05:25:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 05:25:30 --> Final output sent to browser
DEBUG - 2011-05-01 05:25:30 --> Total execution time: 7.5244
DEBUG - 2011-05-01 05:25:44 --> Config Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:25:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:25:44 --> URI Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Router Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Output Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Input Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 05:25:44 --> Language Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Loader Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Controller Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Model Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Model Class Initialized
DEBUG - 2011-05-01 05:25:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 05:25:44 --> Database Driver Class Initialized
DEBUG - 2011-05-01 05:25:45 --> Final output sent to browser
DEBUG - 2011-05-01 05:25:45 --> Total execution time: 0.6716
DEBUG - 2011-05-01 05:54:10 --> Config Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Config Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:54:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:54:10 --> URI Class Initialized
DEBUG - 2011-05-01 05:54:10 --> URI Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Router Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Router Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Output Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Output Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Input Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 05:54:10 --> Config Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:54:10 --> Input Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 05:54:10 --> URI Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Router Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Output Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Input Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 05:54:10 --> Language Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Language Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Language Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Loader Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Loader Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Loader Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Controller Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Controller Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Controller Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Model Class Initialized
ERROR - 2011-05-01 05:54:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 05:54:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 05:54:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 05:54:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 05:54:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 05:54:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 05:54:10 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 05:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 05:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 05:54:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 05:54:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 05:54:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 05:54:11 --> Helper loaded: url_helper
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 05:54:11 --> Helper loaded: url_helper
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 05:54:11 --> Final output sent to browser
DEBUG - 2011-05-01 05:54:11 --> Total execution time: 0.6958
DEBUG - 2011-05-01 05:54:11 --> Final output sent to browser
DEBUG - 2011-05-01 05:54:11 --> Total execution time: 0.8937
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 05:54:11 --> Helper loaded: url_helper
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 05:54:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 05:54:11 --> Final output sent to browser
DEBUG - 2011-05-01 05:54:11 --> Total execution time: 1.1570
DEBUG - 2011-05-01 05:54:12 --> Config Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:54:12 --> URI Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Router Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Output Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Input Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 05:54:12 --> Language Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Loader Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Controller Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 05:54:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 05:54:12 --> Final output sent to browser
DEBUG - 2011-05-01 05:54:12 --> Total execution time: 0.6846
DEBUG - 2011-05-01 05:54:13 --> Config Class Initialized
DEBUG - 2011-05-01 05:54:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:54:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:54:13 --> URI Class Initialized
DEBUG - 2011-05-01 05:54:13 --> Router Class Initialized
ERROR - 2011-05-01 05:54:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 05:54:15 --> Config Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:54:15 --> URI Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Router Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Output Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Input Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 05:54:15 --> Language Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Loader Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Controller Class Initialized
ERROR - 2011-05-01 05:54:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 05:54:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 05:54:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 05:54:15 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 05:54:15 --> Database Driver Class Initialized
DEBUG - 2011-05-01 05:54:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 05:54:15 --> Helper loaded: url_helper
DEBUG - 2011-05-01 05:54:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 05:54:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 05:54:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 05:54:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 05:54:15 --> Final output sent to browser
DEBUG - 2011-05-01 05:54:15 --> Total execution time: 0.0284
DEBUG - 2011-05-01 05:54:15 --> Config Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:54:15 --> URI Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Router Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Output Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Input Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 05:54:15 --> Language Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Loader Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Controller Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Model Class Initialized
DEBUG - 2011-05-01 05:54:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 05:54:15 --> Database Driver Class Initialized
DEBUG - 2011-05-01 05:54:16 --> Final output sent to browser
DEBUG - 2011-05-01 05:54:16 --> Total execution time: 0.6846
DEBUG - 2011-05-01 05:54:17 --> Config Class Initialized
DEBUG - 2011-05-01 05:54:17 --> Hooks Class Initialized
DEBUG - 2011-05-01 05:54:17 --> Utf8 Class Initialized
DEBUG - 2011-05-01 05:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 05:54:17 --> URI Class Initialized
DEBUG - 2011-05-01 05:54:17 --> Router Class Initialized
ERROR - 2011-05-01 05:54:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 07:09:39 --> Config Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:09:39 --> URI Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Router Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Output Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Input Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:09:39 --> Language Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Loader Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Controller Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Model Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Model Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Model Class Initialized
DEBUG - 2011-05-01 07:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 07:09:40 --> Database Driver Class Initialized
DEBUG - 2011-05-01 07:09:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 07:09:40 --> Helper loaded: url_helper
DEBUG - 2011-05-01 07:09:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 07:09:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 07:09:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 07:09:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 07:09:40 --> Final output sent to browser
DEBUG - 2011-05-01 07:09:40 --> Total execution time: 0.5166
DEBUG - 2011-05-01 07:09:41 --> Config Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:09:41 --> URI Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Router Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Output Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Input Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:09:41 --> Language Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Loader Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Controller Class Initialized
ERROR - 2011-05-01 07:09:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 07:09:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 07:09:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 07:09:41 --> Model Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Model Class Initialized
DEBUG - 2011-05-01 07:09:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 07:09:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 07:09:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 07:09:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 07:09:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 07:09:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 07:09:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 07:09:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 07:09:41 --> Final output sent to browser
DEBUG - 2011-05-01 07:09:41 --> Total execution time: 0.0826
DEBUG - 2011-05-01 07:21:10 --> Config Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:21:12 --> URI Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Router Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Output Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Input Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:21:12 --> Language Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Loader Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Controller Class Initialized
ERROR - 2011-05-01 07:21:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 07:21:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 07:21:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 07:21:12 --> Model Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Model Class Initialized
DEBUG - 2011-05-01 07:21:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 07:21:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 07:21:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 07:21:13 --> Helper loaded: url_helper
DEBUG - 2011-05-01 07:21:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 07:21:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 07:21:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 07:21:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 07:21:13 --> Final output sent to browser
DEBUG - 2011-05-01 07:21:13 --> Total execution time: 4.7644
DEBUG - 2011-05-01 07:34:53 --> Config Class Initialized
DEBUG - 2011-05-01 07:34:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:34:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:34:53 --> URI Class Initialized
DEBUG - 2011-05-01 07:34:53 --> Router Class Initialized
DEBUG - 2011-05-01 07:34:53 --> No URI present. Default controller set.
DEBUG - 2011-05-01 07:34:53 --> Output Class Initialized
DEBUG - 2011-05-01 07:34:53 --> Input Class Initialized
DEBUG - 2011-05-01 07:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:34:53 --> Language Class Initialized
DEBUG - 2011-05-01 07:34:53 --> Loader Class Initialized
DEBUG - 2011-05-01 07:34:54 --> Controller Class Initialized
DEBUG - 2011-05-01 07:34:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 07:34:54 --> Helper loaded: url_helper
DEBUG - 2011-05-01 07:34:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 07:34:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 07:34:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 07:34:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 07:34:54 --> Final output sent to browser
DEBUG - 2011-05-01 07:34:54 --> Total execution time: 0.1909
DEBUG - 2011-05-01 07:34:54 --> Config Class Initialized
DEBUG - 2011-05-01 07:34:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:34:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:34:54 --> URI Class Initialized
DEBUG - 2011-05-01 07:34:54 --> Router Class Initialized
ERROR - 2011-05-01 07:34:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 07:34:55 --> Config Class Initialized
DEBUG - 2011-05-01 07:34:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:34:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:34:55 --> URI Class Initialized
DEBUG - 2011-05-01 07:34:55 --> Router Class Initialized
ERROR - 2011-05-01 07:34:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 07:34:55 --> Config Class Initialized
DEBUG - 2011-05-01 07:34:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:34:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:34:55 --> URI Class Initialized
DEBUG - 2011-05-01 07:34:55 --> Router Class Initialized
ERROR - 2011-05-01 07:34:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 07:34:57 --> Config Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:34:57 --> URI Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Router Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Output Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Input Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:34:57 --> Language Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Loader Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Controller Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Model Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Model Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Model Class Initialized
DEBUG - 2011-05-01 07:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 07:34:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 07:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 07:34:57 --> Helper loaded: url_helper
DEBUG - 2011-05-01 07:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 07:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 07:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 07:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 07:34:57 --> Final output sent to browser
DEBUG - 2011-05-01 07:34:57 --> Total execution time: 0.3585
DEBUG - 2011-05-01 07:35:08 --> Config Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:35:08 --> URI Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Router Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Output Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Input Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:35:08 --> Language Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Loader Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Controller Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Model Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Model Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Model Class Initialized
DEBUG - 2011-05-01 07:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 07:35:08 --> Database Driver Class Initialized
DEBUG - 2011-05-01 07:35:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 07:35:08 --> Helper loaded: url_helper
DEBUG - 2011-05-01 07:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 07:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 07:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 07:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 07:35:08 --> Final output sent to browser
DEBUG - 2011-05-01 07:35:08 --> Total execution time: 0.2039
DEBUG - 2011-05-01 07:39:13 --> Config Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:39:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:39:13 --> URI Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Router Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Output Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Input Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:39:13 --> Language Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Loader Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Controller Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Model Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Model Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Model Class Initialized
DEBUG - 2011-05-01 07:39:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 07:39:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 07:39:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 07:39:13 --> Helper loaded: url_helper
DEBUG - 2011-05-01 07:39:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 07:39:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 07:39:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 07:39:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 07:39:13 --> Final output sent to browser
DEBUG - 2011-05-01 07:39:13 --> Total execution time: 0.1850
DEBUG - 2011-05-01 07:58:51 --> Config Class Initialized
DEBUG - 2011-05-01 07:58:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:58:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:58:51 --> URI Class Initialized
DEBUG - 2011-05-01 07:58:51 --> Router Class Initialized
DEBUG - 2011-05-01 07:58:51 --> Output Class Initialized
DEBUG - 2011-05-01 07:58:51 --> Input Class Initialized
DEBUG - 2011-05-01 07:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:58:51 --> Language Class Initialized
DEBUG - 2011-05-01 07:58:51 --> Loader Class Initialized
DEBUG - 2011-05-01 07:58:51 --> Controller Class Initialized
ERROR - 2011-05-01 07:58:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 07:58:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 07:58:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 07:58:52 --> Model Class Initialized
DEBUG - 2011-05-01 07:58:52 --> Model Class Initialized
DEBUG - 2011-05-01 07:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 07:58:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 07:58:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 07:58:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 07:58:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 07:58:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 07:58:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 07:58:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 07:58:52 --> Final output sent to browser
DEBUG - 2011-05-01 07:58:52 --> Total execution time: 0.2986
DEBUG - 2011-05-01 07:58:55 --> Config Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:58:55 --> URI Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Router Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Output Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Input Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 07:58:55 --> Language Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Loader Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Controller Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Model Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Model Class Initialized
DEBUG - 2011-05-01 07:58:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 07:58:55 --> Database Driver Class Initialized
DEBUG - 2011-05-01 07:58:56 --> Final output sent to browser
DEBUG - 2011-05-01 07:58:56 --> Total execution time: 0.7129
DEBUG - 2011-05-01 07:59:03 --> Config Class Initialized
DEBUG - 2011-05-01 07:59:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:59:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:59:03 --> URI Class Initialized
DEBUG - 2011-05-01 07:59:03 --> Router Class Initialized
ERROR - 2011-05-01 07:59:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 07:59:04 --> Config Class Initialized
DEBUG - 2011-05-01 07:59:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:59:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:59:04 --> URI Class Initialized
DEBUG - 2011-05-01 07:59:04 --> Router Class Initialized
ERROR - 2011-05-01 07:59:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 07:59:05 --> Config Class Initialized
DEBUG - 2011-05-01 07:59:05 --> Hooks Class Initialized
DEBUG - 2011-05-01 07:59:05 --> Utf8 Class Initialized
DEBUG - 2011-05-01 07:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 07:59:05 --> URI Class Initialized
DEBUG - 2011-05-01 07:59:05 --> Router Class Initialized
ERROR - 2011-05-01 07:59:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 08:22:07 --> Config Class Initialized
DEBUG - 2011-05-01 08:22:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 08:22:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 08:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 08:22:07 --> URI Class Initialized
DEBUG - 2011-05-01 08:22:07 --> Router Class Initialized
DEBUG - 2011-05-01 08:22:07 --> No URI present. Default controller set.
DEBUG - 2011-05-01 08:22:07 --> Output Class Initialized
DEBUG - 2011-05-01 08:22:07 --> Input Class Initialized
DEBUG - 2011-05-01 08:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 08:22:07 --> Language Class Initialized
DEBUG - 2011-05-01 08:22:07 --> Loader Class Initialized
DEBUG - 2011-05-01 08:22:07 --> Controller Class Initialized
DEBUG - 2011-05-01 08:22:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 08:22:07 --> Helper loaded: url_helper
DEBUG - 2011-05-01 08:22:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 08:22:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 08:22:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 08:22:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 08:22:07 --> Final output sent to browser
DEBUG - 2011-05-01 08:22:07 --> Total execution time: 0.2990
DEBUG - 2011-05-01 08:22:10 --> Config Class Initialized
DEBUG - 2011-05-01 08:22:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 08:22:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 08:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 08:22:10 --> URI Class Initialized
DEBUG - 2011-05-01 08:22:10 --> Router Class Initialized
ERROR - 2011-05-01 08:22:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 08:22:12 --> Config Class Initialized
DEBUG - 2011-05-01 08:22:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 08:22:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 08:22:12 --> URI Class Initialized
DEBUG - 2011-05-01 08:22:12 --> Router Class Initialized
ERROR - 2011-05-01 08:22:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 08:25:12 --> Config Class Initialized
DEBUG - 2011-05-01 08:25:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 08:25:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 08:25:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 08:25:12 --> URI Class Initialized
DEBUG - 2011-05-01 08:25:12 --> Router Class Initialized
DEBUG - 2011-05-01 08:25:14 --> Output Class Initialized
DEBUG - 2011-05-01 08:25:14 --> Input Class Initialized
DEBUG - 2011-05-01 08:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 08:25:14 --> Language Class Initialized
DEBUG - 2011-05-01 08:25:15 --> Loader Class Initialized
DEBUG - 2011-05-01 08:25:15 --> Controller Class Initialized
ERROR - 2011-05-01 08:25:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 08:25:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 08:25:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 08:25:17 --> Model Class Initialized
DEBUG - 2011-05-01 08:25:17 --> Model Class Initialized
DEBUG - 2011-05-01 08:25:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 08:25:18 --> Database Driver Class Initialized
DEBUG - 2011-05-01 08:25:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 08:25:18 --> Helper loaded: url_helper
DEBUG - 2011-05-01 08:25:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 08:25:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 08:25:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 08:25:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 08:25:18 --> Final output sent to browser
DEBUG - 2011-05-01 08:25:18 --> Total execution time: 5.8713
DEBUG - 2011-05-01 08:25:25 --> Config Class Initialized
DEBUG - 2011-05-01 08:25:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 08:25:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 08:25:25 --> URI Class Initialized
DEBUG - 2011-05-01 08:25:25 --> Router Class Initialized
DEBUG - 2011-05-01 08:25:25 --> Output Class Initialized
DEBUG - 2011-05-01 08:25:25 --> Input Class Initialized
DEBUG - 2011-05-01 08:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 08:25:25 --> Language Class Initialized
DEBUG - 2011-05-01 08:25:25 --> Loader Class Initialized
DEBUG - 2011-05-01 08:25:25 --> Controller Class Initialized
DEBUG - 2011-05-01 08:25:26 --> Model Class Initialized
DEBUG - 2011-05-01 08:25:26 --> Model Class Initialized
DEBUG - 2011-05-01 08:25:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 08:25:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 08:25:27 --> Final output sent to browser
DEBUG - 2011-05-01 08:25:27 --> Total execution time: 1.5454
DEBUG - 2011-05-01 08:25:30 --> Config Class Initialized
DEBUG - 2011-05-01 08:25:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 08:25:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 08:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 08:25:30 --> URI Class Initialized
DEBUG - 2011-05-01 08:25:30 --> Router Class Initialized
ERROR - 2011-05-01 08:25:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 08:42:43 --> Config Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 08:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 08:42:43 --> URI Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Router Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Output Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Input Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 08:42:43 --> Language Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Loader Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Controller Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Model Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Model Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Model Class Initialized
DEBUG - 2011-05-01 08:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 08:42:44 --> Database Driver Class Initialized
DEBUG - 2011-05-01 08:42:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 08:42:44 --> Helper loaded: url_helper
DEBUG - 2011-05-01 08:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 08:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 08:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 08:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 08:42:44 --> Final output sent to browser
DEBUG - 2011-05-01 08:42:44 --> Total execution time: 0.7103
DEBUG - 2011-05-01 08:42:52 --> Config Class Initialized
DEBUG - 2011-05-01 08:42:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 08:42:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 08:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 08:42:52 --> URI Class Initialized
DEBUG - 2011-05-01 08:42:52 --> Router Class Initialized
ERROR - 2011-05-01 08:42:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-01 09:08:27 --> Config Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:08:27 --> URI Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Router Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Output Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Input Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:08:27 --> Language Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Loader Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Controller Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Model Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Model Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Model Class Initialized
DEBUG - 2011-05-01 09:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:08:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:08:28 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:08:28 --> Final output sent to browser
DEBUG - 2011-05-01 09:08:28 --> Total execution time: 0.6413
DEBUG - 2011-05-01 09:08:28 --> Config Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:08:28 --> URI Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Router Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Output Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Input Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:08:28 --> Language Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Loader Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Controller Class Initialized
ERROR - 2011-05-01 09:08:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:08:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:08:28 --> Model Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Model Class Initialized
DEBUG - 2011-05-01 09:08:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:08:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:08:28 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:08:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:08:28 --> Final output sent to browser
DEBUG - 2011-05-01 09:08:28 --> Total execution time: 0.0979
DEBUG - 2011-05-01 09:08:30 --> Config Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:08:30 --> URI Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Router Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Output Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Input Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:08:30 --> Language Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Loader Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Controller Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Model Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Model Class Initialized
DEBUG - 2011-05-01 09:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:08:30 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:08:31 --> Final output sent to browser
DEBUG - 2011-05-01 09:08:31 --> Total execution time: 0.7685
DEBUG - 2011-05-01 09:08:43 --> Config Class Initialized
DEBUG - 2011-05-01 09:08:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:08:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:08:43 --> URI Class Initialized
DEBUG - 2011-05-01 09:08:43 --> Router Class Initialized
ERROR - 2011-05-01 09:08:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:08:45 --> Config Class Initialized
DEBUG - 2011-05-01 09:08:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:08:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:08:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:08:45 --> URI Class Initialized
DEBUG - 2011-05-01 09:08:45 --> Router Class Initialized
ERROR - 2011-05-01 09:08:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:08:46 --> Config Class Initialized
DEBUG - 2011-05-01 09:08:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:08:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:08:46 --> URI Class Initialized
DEBUG - 2011-05-01 09:08:46 --> Router Class Initialized
ERROR - 2011-05-01 09:08:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:08:46 --> Config Class Initialized
DEBUG - 2011-05-01 09:08:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:08:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:08:46 --> URI Class Initialized
DEBUG - 2011-05-01 09:08:46 --> Router Class Initialized
ERROR - 2011-05-01 09:08:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:08:47 --> Config Class Initialized
DEBUG - 2011-05-01 09:08:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:08:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:08:47 --> URI Class Initialized
DEBUG - 2011-05-01 09:08:47 --> Router Class Initialized
ERROR - 2011-05-01 09:08:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:14:09 --> Config Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:14:09 --> URI Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Router Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Output Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Input Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:14:09 --> Language Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Loader Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Controller Class Initialized
ERROR - 2011-05-01 09:14:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:14:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:14:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:14:09 --> Model Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Model Class Initialized
DEBUG - 2011-05-01 09:14:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:14:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:14:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:14:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:14:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:14:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:14:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:14:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:14:10 --> Final output sent to browser
DEBUG - 2011-05-01 09:14:10 --> Total execution time: 1.3567
DEBUG - 2011-05-01 09:14:12 --> Config Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:14:12 --> URI Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Router Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Output Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Input Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:14:12 --> Language Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Loader Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Controller Class Initialized
DEBUG - 2011-05-01 09:14:12 --> Model Class Initialized
DEBUG - 2011-05-01 09:14:13 --> Model Class Initialized
DEBUG - 2011-05-01 09:14:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:14:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:14:14 --> Final output sent to browser
DEBUG - 2011-05-01 09:14:14 --> Total execution time: 1.7047
DEBUG - 2011-05-01 09:14:16 --> Config Class Initialized
DEBUG - 2011-05-01 09:14:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:14:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:14:16 --> URI Class Initialized
DEBUG - 2011-05-01 09:14:16 --> Router Class Initialized
ERROR - 2011-05-01 09:14:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:21:03 --> Config Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:21:03 --> URI Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Router Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Output Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Input Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:21:03 --> Language Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Loader Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Controller Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Model Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Model Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Model Class Initialized
DEBUG - 2011-05-01 09:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:21:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:21:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:21:04 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:21:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:21:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:21:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:21:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:21:04 --> Final output sent to browser
DEBUG - 2011-05-01 09:21:04 --> Total execution time: 0.6183
DEBUG - 2011-05-01 09:22:27 --> Config Class Initialized
DEBUG - 2011-05-01 09:22:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:22:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:22:27 --> URI Class Initialized
DEBUG - 2011-05-01 09:22:27 --> Router Class Initialized
ERROR - 2011-05-01 09:22:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:23:04 --> Config Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:23:04 --> URI Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Router Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Output Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Input Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:23:04 --> Language Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Loader Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Controller Class Initialized
ERROR - 2011-05-01 09:23:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:23:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:23:04 --> Model Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Model Class Initialized
DEBUG - 2011-05-01 09:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:23:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:23:04 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:23:04 --> Final output sent to browser
DEBUG - 2011-05-01 09:23:04 --> Total execution time: 0.0599
DEBUG - 2011-05-01 09:23:11 --> Config Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:23:11 --> URI Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Router Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Output Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Input Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:23:11 --> Language Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Loader Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Controller Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Model Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Model Class Initialized
DEBUG - 2011-05-01 09:23:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:23:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:23:12 --> Final output sent to browser
DEBUG - 2011-05-01 09:23:12 --> Total execution time: 0.7716
DEBUG - 2011-05-01 09:23:15 --> Config Class Initialized
DEBUG - 2011-05-01 09:23:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:23:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:23:15 --> URI Class Initialized
DEBUG - 2011-05-01 09:23:15 --> Router Class Initialized
ERROR - 2011-05-01 09:23:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:23:16 --> Config Class Initialized
DEBUG - 2011-05-01 09:23:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:23:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:23:16 --> URI Class Initialized
DEBUG - 2011-05-01 09:23:16 --> Router Class Initialized
ERROR - 2011-05-01 09:23:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:28:14 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:14 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Router Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Output Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Input Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:28:14 --> Language Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Loader Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Controller Class Initialized
ERROR - 2011-05-01 09:28:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:28:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:28:14 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:28:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:28:14 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:28:14 --> Final output sent to browser
DEBUG - 2011-05-01 09:28:14 --> Total execution time: 0.0752
DEBUG - 2011-05-01 09:28:16 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:16 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Router Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Output Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Input Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:28:16 --> Language Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Loader Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Controller Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:28:16 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:28:16 --> Final output sent to browser
DEBUG - 2011-05-01 09:28:16 --> Total execution time: 0.7391
DEBUG - 2011-05-01 09:28:18 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:18 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:18 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:18 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:18 --> Router Class Initialized
ERROR - 2011-05-01 09:28:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:28:34 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:34 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Router Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Output Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Input Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:28:34 --> Language Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Loader Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Controller Class Initialized
ERROR - 2011-05-01 09:28:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:28:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:28:34 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:28:34 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:28:34 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:28:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:28:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:28:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:28:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:28:34 --> Final output sent to browser
DEBUG - 2011-05-01 09:28:34 --> Total execution time: 0.0923
DEBUG - 2011-05-01 09:28:35 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:35 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Router Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Output Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Input Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:28:35 --> Language Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Loader Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Controller Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:28:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:28:36 --> Final output sent to browser
DEBUG - 2011-05-01 09:28:36 --> Total execution time: 0.7846
DEBUG - 2011-05-01 09:28:39 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:39 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:39 --> Router Class Initialized
ERROR - 2011-05-01 09:28:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:28:46 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:46 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:47 --> Router Class Initialized
DEBUG - 2011-05-01 09:28:47 --> Output Class Initialized
DEBUG - 2011-05-01 09:28:47 --> Input Class Initialized
DEBUG - 2011-05-01 09:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:28:47 --> Language Class Initialized
DEBUG - 2011-05-01 09:28:47 --> Loader Class Initialized
DEBUG - 2011-05-01 09:28:47 --> Controller Class Initialized
ERROR - 2011-05-01 09:28:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:28:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:28:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:28:47 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:47 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:28:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:28:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:28:47 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:28:47 --> Final output sent to browser
DEBUG - 2011-05-01 09:28:47 --> Total execution time: 0.0572
DEBUG - 2011-05-01 09:28:48 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:48 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Router Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Output Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Input Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:28:48 --> Language Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Loader Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Controller Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Model Class Initialized
DEBUG - 2011-05-01 09:28:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:28:49 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:28:49 --> Final output sent to browser
DEBUG - 2011-05-01 09:28:49 --> Total execution time: 0.6417
DEBUG - 2011-05-01 09:28:52 --> Config Class Initialized
DEBUG - 2011-05-01 09:28:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:28:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:28:52 --> URI Class Initialized
DEBUG - 2011-05-01 09:28:52 --> Router Class Initialized
ERROR - 2011-05-01 09:28:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:29:00 --> Config Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:29:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:29:00 --> URI Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Router Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Output Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Input Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:29:00 --> Language Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Loader Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Controller Class Initialized
ERROR - 2011-05-01 09:29:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:29:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:29:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:29:00 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:29:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:29:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:29:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:29:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:29:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:29:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:29:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:29:00 --> Final output sent to browser
DEBUG - 2011-05-01 09:29:00 --> Total execution time: 0.0282
DEBUG - 2011-05-01 09:29:02 --> Config Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:29:02 --> URI Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Router Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Output Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Input Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:29:02 --> Language Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Loader Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Controller Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:29:02 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:29:02 --> Final output sent to browser
DEBUG - 2011-05-01 09:29:02 --> Total execution time: 0.5630
DEBUG - 2011-05-01 09:29:20 --> Config Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:29:20 --> URI Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Router Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Output Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Input Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:29:20 --> Language Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Loader Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Controller Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:29:20 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Final output sent to browser
DEBUG - 2011-05-01 09:29:21 --> Total execution time: 0.6470
DEBUG - 2011-05-01 09:29:21 --> Config Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:29:21 --> URI Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Router Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Output Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Input Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:29:21 --> Language Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Loader Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Controller Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:29:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:29:21 --> Final output sent to browser
DEBUG - 2011-05-01 09:29:21 --> Total execution time: 0.5074
DEBUG - 2011-05-01 09:29:30 --> Config Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:29:30 --> URI Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Router Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Output Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Input Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:29:30 --> Language Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Loader Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Controller Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Model Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:29:30 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:29:30 --> Final output sent to browser
DEBUG - 2011-05-01 09:29:30 --> Total execution time: 0.6317
DEBUG - 2011-05-01 09:30:18 --> Config Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:30:18 --> URI Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Router Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Output Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Input Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:30:18 --> Language Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Loader Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Controller Class Initialized
ERROR - 2011-05-01 09:30:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:30:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:30:18 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:30:18 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:30:18 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:30:18 --> Final output sent to browser
DEBUG - 2011-05-01 09:30:18 --> Total execution time: 0.0308
DEBUG - 2011-05-01 09:30:20 --> Config Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:30:20 --> URI Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Router Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Output Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Input Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:30:20 --> Language Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Loader Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Controller Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:30:20 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:30:21 --> Final output sent to browser
DEBUG - 2011-05-01 09:30:21 --> Total execution time: 0.5399
DEBUG - 2011-05-01 09:30:23 --> Config Class Initialized
DEBUG - 2011-05-01 09:30:23 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:30:23 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:30:23 --> URI Class Initialized
DEBUG - 2011-05-01 09:30:23 --> Router Class Initialized
ERROR - 2011-05-01 09:30:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:30:43 --> Config Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:30:43 --> URI Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Router Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Output Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Input Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:30:43 --> Language Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Loader Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Controller Class Initialized
ERROR - 2011-05-01 09:30:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:30:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:30:43 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:30:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:30:43 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:30:43 --> Final output sent to browser
DEBUG - 2011-05-01 09:30:43 --> Total execution time: 0.0478
DEBUG - 2011-05-01 09:30:51 --> Config Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:30:51 --> URI Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Router Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Output Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Input Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:30:51 --> Language Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Loader Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Controller Class Initialized
ERROR - 2011-05-01 09:30:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:30:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:30:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:30:51 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:30:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:30:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:30:51 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:30:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:30:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:30:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:30:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:30:51 --> Final output sent to browser
DEBUG - 2011-05-01 09:30:51 --> Total execution time: 0.0323
DEBUG - 2011-05-01 09:30:52 --> Config Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:30:52 --> URI Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Router Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Output Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Input Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:30:52 --> Language Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Loader Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Controller Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Model Class Initialized
DEBUG - 2011-05-01 09:30:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:30:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:30:53 --> Final output sent to browser
DEBUG - 2011-05-01 09:30:53 --> Total execution time: 0.7228
DEBUG - 2011-05-01 09:31:06 --> Config Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:31:06 --> URI Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Router Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Output Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Input Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:31:06 --> Language Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Loader Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Controller Class Initialized
ERROR - 2011-05-01 09:31:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:31:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:31:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:31:06 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:31:06 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:31:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:31:06 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:31:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:31:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:31:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:31:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:31:06 --> Final output sent to browser
DEBUG - 2011-05-01 09:31:06 --> Total execution time: 0.0972
DEBUG - 2011-05-01 09:31:09 --> Config Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:31:09 --> URI Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Router Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Output Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Input Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:31:09 --> Language Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Loader Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Controller Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:31:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:31:10 --> Final output sent to browser
DEBUG - 2011-05-01 09:31:10 --> Total execution time: 0.9279
DEBUG - 2011-05-01 09:31:20 --> Config Class Initialized
DEBUG - 2011-05-01 09:31:20 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:31:20 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:31:20 --> URI Class Initialized
DEBUG - 2011-05-01 09:31:20 --> Router Class Initialized
DEBUG - 2011-05-01 09:31:20 --> Output Class Initialized
DEBUG - 2011-05-01 09:31:20 --> Input Class Initialized
DEBUG - 2011-05-01 09:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:31:20 --> Language Class Initialized
DEBUG - 2011-05-01 09:31:20 --> Loader Class Initialized
DEBUG - 2011-05-01 09:31:21 --> Controller Class Initialized
ERROR - 2011-05-01 09:31:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:31:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:31:21 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:21 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:31:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:31:21 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:31:21 --> Final output sent to browser
DEBUG - 2011-05-01 09:31:21 --> Total execution time: 0.3905
DEBUG - 2011-05-01 09:31:22 --> Config Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:31:22 --> URI Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Router Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Output Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Input Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:31:22 --> Language Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Loader Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Controller Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:31:22 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:31:22 --> Final output sent to browser
DEBUG - 2011-05-01 09:31:22 --> Total execution time: 0.7619
DEBUG - 2011-05-01 09:31:38 --> Config Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:31:38 --> URI Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Router Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Output Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Input Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:31:38 --> Language Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Loader Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Controller Class Initialized
ERROR - 2011-05-01 09:31:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:31:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:31:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:31:38 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:31:38 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:31:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:31:38 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:31:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:31:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:31:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:31:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:31:38 --> Final output sent to browser
DEBUG - 2011-05-01 09:31:38 --> Total execution time: 0.1869
DEBUG - 2011-05-01 09:31:42 --> Config Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:31:42 --> URI Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Router Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Output Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Input Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:31:42 --> Language Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Loader Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Controller Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Model Class Initialized
DEBUG - 2011-05-01 09:31:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:31:42 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:31:43 --> Final output sent to browser
DEBUG - 2011-05-01 09:31:43 --> Total execution time: 0.8791
DEBUG - 2011-05-01 09:32:24 --> Config Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:32:24 --> URI Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Router Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Output Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Input Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:32:24 --> Language Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Loader Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Controller Class Initialized
ERROR - 2011-05-01 09:32:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:32:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:32:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:32:24 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:32:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:32:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:32:24 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:32:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:32:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:32:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:32:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:32:24 --> Final output sent to browser
DEBUG - 2011-05-01 09:32:24 --> Total execution time: 0.0444
DEBUG - 2011-05-01 09:32:26 --> Config Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:32:26 --> URI Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Router Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Output Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Input Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:32:26 --> Language Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Loader Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Controller Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:32:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:32:27 --> Final output sent to browser
DEBUG - 2011-05-01 09:32:27 --> Total execution time: 0.5741
DEBUG - 2011-05-01 09:32:42 --> Config Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:32:42 --> URI Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Router Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Output Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Input Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:32:42 --> Language Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Loader Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Controller Class Initialized
ERROR - 2011-05-01 09:32:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:32:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:32:42 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:32:42 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:32:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:32:42 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:32:42 --> Final output sent to browser
DEBUG - 2011-05-01 09:32:42 --> Total execution time: 0.0688
DEBUG - 2011-05-01 09:32:45 --> Config Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:32:45 --> URI Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Router Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Output Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Input Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:32:45 --> Language Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Loader Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Controller Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:32:45 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:32:45 --> Final output sent to browser
DEBUG - 2011-05-01 09:32:45 --> Total execution time: 0.5134
DEBUG - 2011-05-01 09:32:55 --> Config Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:32:55 --> URI Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Router Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Output Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Input Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:32:55 --> Language Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Loader Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Controller Class Initialized
ERROR - 2011-05-01 09:32:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:32:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:32:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:32:55 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:32:55 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:32:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:32:55 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:32:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:32:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:32:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:32:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:32:55 --> Final output sent to browser
DEBUG - 2011-05-01 09:32:55 --> Total execution time: 0.0859
DEBUG - 2011-05-01 09:32:57 --> Config Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:32:57 --> URI Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Router Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Output Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Input Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:32:57 --> Language Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Loader Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Controller Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Model Class Initialized
DEBUG - 2011-05-01 09:32:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:32:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:32:58 --> Final output sent to browser
DEBUG - 2011-05-01 09:32:58 --> Total execution time: 0.5803
DEBUG - 2011-05-01 09:33:12 --> Config Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:33:12 --> URI Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Router Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Output Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Input Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:33:12 --> Language Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Loader Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Controller Class Initialized
ERROR - 2011-05-01 09:33:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:33:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:33:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:33:12 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:33:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:33:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:33:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:33:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:33:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:33:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:33:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:33:12 --> Final output sent to browser
DEBUG - 2011-05-01 09:33:12 --> Total execution time: 0.1193
DEBUG - 2011-05-01 09:33:15 --> Config Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:33:15 --> URI Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Router Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Output Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Input Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:33:15 --> Language Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Loader Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Controller Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:33:15 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:33:15 --> Final output sent to browser
DEBUG - 2011-05-01 09:33:15 --> Total execution time: 0.5084
DEBUG - 2011-05-01 09:33:24 --> Config Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:33:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:33:24 --> URI Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Router Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Output Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Input Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:33:24 --> Language Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Loader Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Controller Class Initialized
ERROR - 2011-05-01 09:33:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:33:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:33:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:33:24 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:33:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:33:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:33:24 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:33:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:33:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:33:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:33:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:33:24 --> Final output sent to browser
DEBUG - 2011-05-01 09:33:24 --> Total execution time: 0.3603
DEBUG - 2011-05-01 09:33:28 --> Config Class Initialized
DEBUG - 2011-05-01 09:33:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:33:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:33:28 --> URI Class Initialized
DEBUG - 2011-05-01 09:33:29 --> Router Class Initialized
DEBUG - 2011-05-01 09:33:29 --> Output Class Initialized
DEBUG - 2011-05-01 09:33:29 --> Input Class Initialized
DEBUG - 2011-05-01 09:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:33:29 --> Language Class Initialized
DEBUG - 2011-05-01 09:33:29 --> Loader Class Initialized
DEBUG - 2011-05-01 09:33:29 --> Controller Class Initialized
DEBUG - 2011-05-01 09:33:30 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:30 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:33:30 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:33:31 --> Final output sent to browser
DEBUG - 2011-05-01 09:33:31 --> Total execution time: 3.0289
DEBUG - 2011-05-01 09:33:41 --> Config Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:33:41 --> URI Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Router Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Output Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Input Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:33:41 --> Language Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Loader Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Controller Class Initialized
ERROR - 2011-05-01 09:33:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:33:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:33:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:33:41 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:33:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:33:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:33:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:33:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:33:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:33:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:33:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:33:41 --> Final output sent to browser
DEBUG - 2011-05-01 09:33:41 --> Total execution time: 0.0302
DEBUG - 2011-05-01 09:33:44 --> Config Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:33:44 --> URI Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Router Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Output Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Input Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:33:44 --> Language Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Loader Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Controller Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:33:44 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:33:45 --> Final output sent to browser
DEBUG - 2011-05-01 09:33:45 --> Total execution time: 0.8930
DEBUG - 2011-05-01 09:33:53 --> Config Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:33:53 --> URI Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Router Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Output Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Input Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:33:53 --> Language Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Loader Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Controller Class Initialized
ERROR - 2011-05-01 09:33:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:33:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:33:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:33:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:33:55 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:33:56 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:33:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:33:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:33:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:33:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:33:56 --> Final output sent to browser
DEBUG - 2011-05-01 09:33:56 --> Total execution time: 2.4115
DEBUG - 2011-05-01 09:33:58 --> Config Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:33:58 --> URI Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Router Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Output Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Input Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:33:58 --> Language Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Loader Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Controller Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Model Class Initialized
DEBUG - 2011-05-01 09:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:33:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:34:02 --> Final output sent to browser
DEBUG - 2011-05-01 09:34:02 --> Total execution time: 3.0980
DEBUG - 2011-05-01 09:36:52 --> Config Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:36:52 --> URI Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Router Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Output Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Input Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:36:52 --> Language Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Loader Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Controller Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Model Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Model Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:36:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:36:52 --> Final output sent to browser
DEBUG - 2011-05-01 09:36:52 --> Total execution time: 0.5924
DEBUG - 2011-05-01 09:38:43 --> Config Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:38:43 --> URI Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Router Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Output Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Input Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:38:43 --> Language Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Loader Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Controller Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Model Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Model Class Initialized
DEBUG - 2011-05-01 09:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:38:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:38:44 --> Final output sent to browser
DEBUG - 2011-05-01 09:38:44 --> Total execution time: 0.8981
DEBUG - 2011-05-01 09:38:53 --> Config Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:38:53 --> URI Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Router Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Output Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Input Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:38:53 --> Language Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Loader Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Controller Class Initialized
ERROR - 2011-05-01 09:38:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:38:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:38:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:38:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:38:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:38:53 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:38:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:38:53 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:38:53 --> Final output sent to browser
DEBUG - 2011-05-01 09:38:53 --> Total execution time: 0.0421
DEBUG - 2011-05-01 09:38:54 --> Config Class Initialized
DEBUG - 2011-05-01 09:38:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:38:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:38:54 --> URI Class Initialized
DEBUG - 2011-05-01 09:38:54 --> Router Class Initialized
DEBUG - 2011-05-01 09:38:54 --> Output Class Initialized
DEBUG - 2011-05-01 09:38:55 --> Input Class Initialized
DEBUG - 2011-05-01 09:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:38:55 --> Language Class Initialized
DEBUG - 2011-05-01 09:38:55 --> Loader Class Initialized
DEBUG - 2011-05-01 09:38:55 --> Controller Class Initialized
DEBUG - 2011-05-01 09:38:55 --> Model Class Initialized
DEBUG - 2011-05-01 09:38:55 --> Model Class Initialized
DEBUG - 2011-05-01 09:38:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:38:55 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:38:55 --> Final output sent to browser
DEBUG - 2011-05-01 09:38:55 --> Total execution time: 0.5535
DEBUG - 2011-05-01 09:38:56 --> Config Class Initialized
DEBUG - 2011-05-01 09:38:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:38:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:38:56 --> URI Class Initialized
DEBUG - 2011-05-01 09:38:56 --> Router Class Initialized
ERROR - 2011-05-01 09:38:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:39:12 --> Config Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:39:12 --> URI Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Router Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Output Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Input Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:39:12 --> Language Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Loader Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Controller Class Initialized
ERROR - 2011-05-01 09:39:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:39:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:39:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:39:12 --> Model Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Model Class Initialized
DEBUG - 2011-05-01 09:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:39:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:39:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:39:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:39:12 --> Final output sent to browser
DEBUG - 2011-05-01 09:39:12 --> Total execution time: 0.0268
DEBUG - 2011-05-01 09:39:13 --> Config Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:39:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:39:13 --> URI Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Router Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Output Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Input Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:39:13 --> Language Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Loader Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Controller Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Model Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Model Class Initialized
DEBUG - 2011-05-01 09:39:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:39:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:39:14 --> Final output sent to browser
DEBUG - 2011-05-01 09:39:14 --> Total execution time: 0.7700
DEBUG - 2011-05-01 09:39:15 --> Config Class Initialized
DEBUG - 2011-05-01 09:39:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:39:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:39:15 --> URI Class Initialized
DEBUG - 2011-05-01 09:39:15 --> Router Class Initialized
ERROR - 2011-05-01 09:39:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:39:28 --> Config Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:39:28 --> URI Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Router Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Output Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Input Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:39:28 --> Language Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Loader Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Controller Class Initialized
ERROR - 2011-05-01 09:39:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:39:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:39:28 --> Model Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Model Class Initialized
DEBUG - 2011-05-01 09:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:39:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:39:28 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:39:28 --> Final output sent to browser
DEBUG - 2011-05-01 09:39:28 --> Total execution time: 0.0293
DEBUG - 2011-05-01 09:39:29 --> Config Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:39:29 --> URI Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Router Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Output Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Input Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:39:29 --> Language Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Loader Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Controller Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Model Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Model Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:39:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:39:29 --> Final output sent to browser
DEBUG - 2011-05-01 09:39:29 --> Total execution time: 0.5222
DEBUG - 2011-05-01 09:39:30 --> Config Class Initialized
DEBUG - 2011-05-01 09:39:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:39:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:39:30 --> URI Class Initialized
DEBUG - 2011-05-01 09:39:30 --> Router Class Initialized
ERROR - 2011-05-01 09:39:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:41:06 --> Config Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:41:06 --> URI Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Router Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Output Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Input Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:41:06 --> Language Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Loader Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Controller Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:41:06 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:41:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:41:07 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:41:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:41:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:41:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:41:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:41:07 --> Final output sent to browser
DEBUG - 2011-05-01 09:41:07 --> Total execution time: 0.5904
DEBUG - 2011-05-01 09:41:09 --> Config Class Initialized
DEBUG - 2011-05-01 09:41:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:41:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:41:09 --> URI Class Initialized
DEBUG - 2011-05-01 09:41:09 --> Router Class Initialized
ERROR - 2011-05-01 09:41:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 09:41:19 --> Config Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:41:19 --> URI Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Router Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Output Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Input Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:41:19 --> Language Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Loader Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Controller Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:41:19 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:41:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:41:20 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:41:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:41:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:41:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:41:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:41:20 --> Final output sent to browser
DEBUG - 2011-05-01 09:41:20 --> Total execution time: 0.5076
DEBUG - 2011-05-01 09:41:21 --> Config Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:41:21 --> URI Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Router Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Output Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Input Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:41:21 --> Language Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Loader Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Controller Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Model Class Initialized
DEBUG - 2011-05-01 09:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:41:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:41:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:41:21 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:41:21 --> Final output sent to browser
DEBUG - 2011-05-01 09:41:21 --> Total execution time: 0.0503
DEBUG - 2011-05-01 09:42:01 --> Config Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:42:01 --> URI Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Router Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Output Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Input Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:42:01 --> Language Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Loader Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Controller Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:42:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:42:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:42:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:42:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:42:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:42:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:42:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:42:01 --> Final output sent to browser
DEBUG - 2011-05-01 09:42:01 --> Total execution time: 0.0779
DEBUG - 2011-05-01 09:42:03 --> Config Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:42:03 --> URI Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Router Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Output Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Input Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:42:03 --> Language Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Loader Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Controller Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:42:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:42:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:42:03 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:42:03 --> Final output sent to browser
DEBUG - 2011-05-01 09:42:03 --> Total execution time: 0.0426
DEBUG - 2011-05-01 09:42:04 --> Config Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:42:04 --> URI Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Router Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Output Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Input Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:42:04 --> Language Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Loader Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Controller Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:42:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:42:05 --> Final output sent to browser
DEBUG - 2011-05-01 09:42:05 --> Total execution time: 1.1366
DEBUG - 2011-05-01 09:42:51 --> Config Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:42:51 --> URI Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Router Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Output Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Input Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:42:51 --> Language Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Loader Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Controller Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:42:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:42:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:42:51 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:42:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:42:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:42:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:42:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:42:51 --> Final output sent to browser
DEBUG - 2011-05-01 09:42:51 --> Total execution time: 0.0616
DEBUG - 2011-05-01 09:42:53 --> Config Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:42:53 --> URI Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Router Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Output Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Input Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:42:53 --> Language Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Loader Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Controller Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:42:53 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:42:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:42:53 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:42:53 --> Final output sent to browser
DEBUG - 2011-05-01 09:42:53 --> Total execution time: 0.0586
DEBUG - 2011-05-01 09:42:58 --> Config Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:42:58 --> URI Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Router Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Output Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Input Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:42:58 --> Language Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Loader Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Controller Class Initialized
ERROR - 2011-05-01 09:42:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:42:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:42:58 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:42:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:42:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:42:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:42:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:42:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:42:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:42:58 --> Final output sent to browser
DEBUG - 2011-05-01 09:42:58 --> Total execution time: 0.0312
DEBUG - 2011-05-01 09:42:59 --> Config Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:42:59 --> URI Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Router Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Output Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Input Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:42:59 --> Language Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Loader Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Controller Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Model Class Initialized
DEBUG - 2011-05-01 09:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:42:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:43:00 --> Final output sent to browser
DEBUG - 2011-05-01 09:43:00 --> Total execution time: 0.5615
DEBUG - 2011-05-01 09:43:14 --> Config Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:43:14 --> URI Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Router Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Output Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Input Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:43:14 --> Language Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Loader Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Controller Class Initialized
ERROR - 2011-05-01 09:43:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:43:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:43:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:43:14 --> Model Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Model Class Initialized
DEBUG - 2011-05-01 09:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:43:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:43:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:43:14 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:43:14 --> Final output sent to browser
DEBUG - 2011-05-01 09:43:14 --> Total execution time: 0.0302
DEBUG - 2011-05-01 09:43:16 --> Config Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:43:16 --> URI Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Router Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Output Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Input Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:43:16 --> Language Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Loader Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Controller Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Model Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Model Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:43:16 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:43:16 --> Final output sent to browser
DEBUG - 2011-05-01 09:43:16 --> Total execution time: 0.5997
DEBUG - 2011-05-01 09:43:49 --> Config Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:43:49 --> URI Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Router Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Output Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Input Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:43:49 --> Language Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Loader Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Controller Class Initialized
ERROR - 2011-05-01 09:43:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:43:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:43:49 --> Model Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Model Class Initialized
DEBUG - 2011-05-01 09:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:43:49 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:43:49 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:43:50 --> Final output sent to browser
DEBUG - 2011-05-01 09:43:50 --> Total execution time: 0.2625
DEBUG - 2011-05-01 09:47:00 --> Config Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:47:00 --> URI Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Router Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Output Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Input Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:47:00 --> Language Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Loader Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Controller Class Initialized
ERROR - 2011-05-01 09:47:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:47:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:47:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:47:00 --> Model Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Model Class Initialized
DEBUG - 2011-05-01 09:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:47:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:47:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:47:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:47:00 --> Final output sent to browser
DEBUG - 2011-05-01 09:47:00 --> Total execution time: 0.0583
DEBUG - 2011-05-01 09:47:02 --> Config Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:47:02 --> URI Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Router Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Output Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Input Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:47:02 --> Language Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Loader Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Controller Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Model Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Model Class Initialized
DEBUG - 2011-05-01 09:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:47:02 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:47:03 --> Final output sent to browser
DEBUG - 2011-05-01 09:47:03 --> Total execution time: 0.7039
DEBUG - 2011-05-01 09:48:35 --> Config Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:48:35 --> URI Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Router Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Output Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Input Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:48:35 --> Language Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Loader Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Controller Class Initialized
ERROR - 2011-05-01 09:48:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:48:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:48:35 --> Model Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Model Class Initialized
DEBUG - 2011-05-01 09:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:48:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:48:35 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:48:35 --> Final output sent to browser
DEBUG - 2011-05-01 09:48:35 --> Total execution time: 0.0272
DEBUG - 2011-05-01 09:48:37 --> Config Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:48:37 --> URI Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Router Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Output Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Input Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:48:37 --> Language Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Loader Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Controller Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Model Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Model Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:48:37 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:48:37 --> Final output sent to browser
DEBUG - 2011-05-01 09:48:37 --> Total execution time: 0.6116
DEBUG - 2011-05-01 09:48:53 --> Config Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:48:53 --> URI Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Router Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Output Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Input Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:48:53 --> Language Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Loader Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Controller Class Initialized
ERROR - 2011-05-01 09:48:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:48:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:48:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:48:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Model Class Initialized
DEBUG - 2011-05-01 09:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:48:53 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:48:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:48:53 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:48:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:48:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:48:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:48:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:48:53 --> Final output sent to browser
DEBUG - 2011-05-01 09:48:53 --> Total execution time: 0.0336
DEBUG - 2011-05-01 09:48:54 --> Config Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:48:54 --> URI Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Router Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Output Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Input Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:48:54 --> Language Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Loader Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Controller Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Model Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Model Class Initialized
DEBUG - 2011-05-01 09:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:48:54 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:48:55 --> Final output sent to browser
DEBUG - 2011-05-01 09:48:55 --> Total execution time: 0.7070
DEBUG - 2011-05-01 09:51:24 --> Config Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:51:24 --> URI Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Router Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Output Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Input Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:51:24 --> Language Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Loader Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Controller Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Model Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Model Class Initialized
DEBUG - 2011-05-01 09:51:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:51:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:51:25 --> Final output sent to browser
DEBUG - 2011-05-01 09:51:25 --> Total execution time: 0.6290
DEBUG - 2011-05-01 09:54:59 --> Config Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:54:59 --> URI Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Router Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Output Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Input Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:54:59 --> Language Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Loader Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Controller Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Model Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Model Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:54:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:54:59 --> Final output sent to browser
DEBUG - 2011-05-01 09:54:59 --> Total execution time: 0.7529
DEBUG - 2011-05-01 09:55:51 --> Config Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:55:51 --> URI Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Router Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Output Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Input Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:55:51 --> Language Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Loader Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Controller Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Model Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Model Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Model Class Initialized
DEBUG - 2011-05-01 09:55:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:55:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:55:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 09:55:51 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:55:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:55:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:55:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:55:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:55:51 --> Final output sent to browser
DEBUG - 2011-05-01 09:55:51 --> Total execution time: 0.1391
DEBUG - 2011-05-01 09:55:52 --> Config Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 09:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 09:55:52 --> URI Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Router Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Output Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Input Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 09:55:52 --> Language Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Loader Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Controller Class Initialized
ERROR - 2011-05-01 09:55:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 09:55:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 09:55:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:55:52 --> Model Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Model Class Initialized
DEBUG - 2011-05-01 09:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 09:55:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 09:55:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 09:55:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 09:55:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 09:55:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 09:55:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 09:55:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 09:55:52 --> Final output sent to browser
DEBUG - 2011-05-01 09:55:52 --> Total execution time: 0.0324
DEBUG - 2011-05-01 10:07:29 --> Config Class Initialized
DEBUG - 2011-05-01 10:07:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:07:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:07:29 --> URI Class Initialized
DEBUG - 2011-05-01 10:07:30 --> Router Class Initialized
DEBUG - 2011-05-01 10:07:30 --> Output Class Initialized
DEBUG - 2011-05-01 10:07:30 --> Input Class Initialized
DEBUG - 2011-05-01 10:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:07:30 --> Language Class Initialized
DEBUG - 2011-05-01 10:07:30 --> Loader Class Initialized
DEBUG - 2011-05-01 10:07:30 --> Controller Class Initialized
ERROR - 2011-05-01 10:07:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 10:07:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 10:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:07:30 --> Model Class Initialized
DEBUG - 2011-05-01 10:07:30 --> Model Class Initialized
DEBUG - 2011-05-01 10:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:07:31 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:07:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:07:31 --> Helper loaded: url_helper
DEBUG - 2011-05-01 10:07:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 10:07:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 10:07:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 10:07:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 10:07:31 --> Final output sent to browser
DEBUG - 2011-05-01 10:07:31 --> Total execution time: 2.1479
DEBUG - 2011-05-01 10:07:33 --> Config Class Initialized
DEBUG - 2011-05-01 10:07:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:07:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:07:33 --> URI Class Initialized
DEBUG - 2011-05-01 10:07:33 --> Router Class Initialized
DEBUG - 2011-05-01 10:07:33 --> Output Class Initialized
DEBUG - 2011-05-01 10:07:33 --> Input Class Initialized
DEBUG - 2011-05-01 10:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:07:33 --> Language Class Initialized
DEBUG - 2011-05-01 10:07:33 --> Loader Class Initialized
DEBUG - 2011-05-01 10:07:33 --> Controller Class Initialized
DEBUG - 2011-05-01 10:07:34 --> Model Class Initialized
DEBUG - 2011-05-01 10:07:34 --> Model Class Initialized
DEBUG - 2011-05-01 10:07:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:07:34 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:07:34 --> Final output sent to browser
DEBUG - 2011-05-01 10:07:34 --> Total execution time: 0.8295
DEBUG - 2011-05-01 10:07:35 --> Config Class Initialized
DEBUG - 2011-05-01 10:07:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:07:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:07:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:07:35 --> URI Class Initialized
DEBUG - 2011-05-01 10:07:35 --> Router Class Initialized
ERROR - 2011-05-01 10:07:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 10:08:00 --> Config Class Initialized
DEBUG - 2011-05-01 10:08:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:08:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:08:00 --> URI Class Initialized
DEBUG - 2011-05-01 10:08:00 --> Router Class Initialized
ERROR - 2011-05-01 10:08:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-01 10:08:07 --> Config Class Initialized
DEBUG - 2011-05-01 10:08:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:08:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:08:07 --> URI Class Initialized
DEBUG - 2011-05-01 10:08:07 --> Router Class Initialized
ERROR - 2011-05-01 10:08:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-01 10:10:22 --> Config Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:10:22 --> URI Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Router Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Output Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Input Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:10:22 --> Language Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Loader Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Controller Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Model Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Model Class Initialized
DEBUG - 2011-05-01 10:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:10:22 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:10:23 --> Final output sent to browser
DEBUG - 2011-05-01 10:10:23 --> Total execution time: 1.0681
DEBUG - 2011-05-01 10:26:09 --> Config Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:26:09 --> URI Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Router Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Output Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Input Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:26:09 --> Language Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Loader Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Controller Class Initialized
ERROR - 2011-05-01 10:26:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 10:26:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 10:26:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:26:09 --> Model Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Model Class Initialized
DEBUG - 2011-05-01 10:26:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:26:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:26:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:26:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 10:26:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 10:26:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 10:26:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 10:26:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 10:26:09 --> Final output sent to browser
DEBUG - 2011-05-01 10:26:09 --> Total execution time: 0.2632
DEBUG - 2011-05-01 10:26:10 --> Config Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:26:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:26:10 --> URI Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Router Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Output Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Input Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:26:10 --> Language Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Loader Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Controller Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Model Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Model Class Initialized
DEBUG - 2011-05-01 10:26:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:26:10 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:26:11 --> Final output sent to browser
DEBUG - 2011-05-01 10:26:11 --> Total execution time: 1.2814
DEBUG - 2011-05-01 10:26:12 --> Config Class Initialized
DEBUG - 2011-05-01 10:26:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:26:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:26:12 --> URI Class Initialized
DEBUG - 2011-05-01 10:26:12 --> Router Class Initialized
ERROR - 2011-05-01 10:26:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 10:35:17 --> Config Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:35:17 --> URI Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Router Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Output Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Input Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:35:17 --> Language Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Loader Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Controller Class Initialized
DEBUG - 2011-05-01 10:35:17 --> Model Class Initialized
DEBUG - 2011-05-01 10:35:18 --> Model Class Initialized
DEBUG - 2011-05-01 10:35:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:35:18 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:35:19 --> Final output sent to browser
DEBUG - 2011-05-01 10:35:19 --> Total execution time: 1.2938
DEBUG - 2011-05-01 10:48:28 --> Config Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:48:28 --> URI Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Router Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Output Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Input Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:48:28 --> Language Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Loader Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Controller Class Initialized
ERROR - 2011-05-01 10:48:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 10:48:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 10:48:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:48:28 --> Model Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Model Class Initialized
DEBUG - 2011-05-01 10:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:48:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:48:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:48:28 --> Helper loaded: url_helper
DEBUG - 2011-05-01 10:48:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 10:48:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 10:48:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 10:48:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 10:48:28 --> Final output sent to browser
DEBUG - 2011-05-01 10:48:28 --> Total execution time: 0.2237
DEBUG - 2011-05-01 10:48:34 --> Config Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:48:34 --> URI Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Router Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Output Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Input Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:48:34 --> Language Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Loader Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Controller Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Model Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Model Class Initialized
DEBUG - 2011-05-01 10:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:48:34 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:48:35 --> Final output sent to browser
DEBUG - 2011-05-01 10:48:35 --> Total execution time: 0.6646
DEBUG - 2011-05-01 10:48:38 --> Config Class Initialized
DEBUG - 2011-05-01 10:48:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:48:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:48:38 --> URI Class Initialized
DEBUG - 2011-05-01 10:48:38 --> Router Class Initialized
ERROR - 2011-05-01 10:48:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 10:51:42 --> Config Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:51:42 --> URI Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Router Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Output Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Input Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:51:42 --> Language Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Loader Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Controller Class Initialized
ERROR - 2011-05-01 10:51:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 10:51:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 10:51:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:51:42 --> Model Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Model Class Initialized
DEBUG - 2011-05-01 10:51:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:51:42 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:51:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:51:42 --> Helper loaded: url_helper
DEBUG - 2011-05-01 10:51:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 10:51:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 10:51:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 10:51:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 10:51:42 --> Final output sent to browser
DEBUG - 2011-05-01 10:51:42 --> Total execution time: 0.0521
DEBUG - 2011-05-01 10:51:46 --> Config Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:51:46 --> URI Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Router Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Output Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Input Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:51:46 --> Language Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Loader Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Controller Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Model Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Model Class Initialized
DEBUG - 2011-05-01 10:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:51:46 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:51:48 --> Final output sent to browser
DEBUG - 2011-05-01 10:51:48 --> Total execution time: 1.4028
DEBUG - 2011-05-01 10:52:04 --> Config Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:52:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:52:04 --> URI Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Router Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Output Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Input Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:52:04 --> Language Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Loader Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Controller Class Initialized
ERROR - 2011-05-01 10:52:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 10:52:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 10:52:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:52:04 --> Model Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Model Class Initialized
DEBUG - 2011-05-01 10:52:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:52:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:52:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 10:52:04 --> Helper loaded: url_helper
DEBUG - 2011-05-01 10:52:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 10:52:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 10:52:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 10:52:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 10:52:04 --> Final output sent to browser
DEBUG - 2011-05-01 10:52:04 --> Total execution time: 0.0313
DEBUG - 2011-05-01 10:52:09 --> Config Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 10:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 10:52:09 --> URI Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Router Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Output Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Input Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 10:52:09 --> Language Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Loader Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Controller Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Model Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Model Class Initialized
DEBUG - 2011-05-01 10:52:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 10:52:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 10:52:10 --> Final output sent to browser
DEBUG - 2011-05-01 10:52:10 --> Total execution time: 1.2208
DEBUG - 2011-05-01 11:01:27 --> Config Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:01:27 --> URI Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Router Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Output Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Input Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:01:27 --> Language Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Loader Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Controller Class Initialized
ERROR - 2011-05-01 11:01:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:01:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:01:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:01:27 --> Model Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Model Class Initialized
DEBUG - 2011-05-01 11:01:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:01:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:01:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:01:27 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:01:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:01:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:01:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:01:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:01:27 --> Final output sent to browser
DEBUG - 2011-05-01 11:01:27 --> Total execution time: 0.0816
DEBUG - 2011-05-01 11:01:34 --> Config Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:01:34 --> URI Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Router Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Output Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Input Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:01:34 --> Language Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Loader Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Controller Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Model Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Model Class Initialized
DEBUG - 2011-05-01 11:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:01:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:01:35 --> Final output sent to browser
DEBUG - 2011-05-01 11:01:35 --> Total execution time: 0.6646
DEBUG - 2011-05-01 11:01:41 --> Config Class Initialized
DEBUG - 2011-05-01 11:01:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:01:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:01:41 --> URI Class Initialized
DEBUG - 2011-05-01 11:01:41 --> Router Class Initialized
ERROR - 2011-05-01 11:01:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:03:52 --> Config Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:03:52 --> URI Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Router Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Output Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Input Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:03:52 --> Language Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Loader Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Controller Class Initialized
ERROR - 2011-05-01 11:03:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:03:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:03:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:03:52 --> Model Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Model Class Initialized
DEBUG - 2011-05-01 11:03:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:03:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:03:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:03:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:03:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:03:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:03:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:03:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:03:52 --> Final output sent to browser
DEBUG - 2011-05-01 11:03:52 --> Total execution time: 0.0498
DEBUG - 2011-05-01 11:03:54 --> Config Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:03:54 --> URI Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Router Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Output Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Input Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:03:54 --> Language Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Loader Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Controller Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Model Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Model Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:03:54 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:03:54 --> Final output sent to browser
DEBUG - 2011-05-01 11:03:54 --> Total execution time: 0.7421
DEBUG - 2011-05-01 11:04:39 --> Config Class Initialized
DEBUG - 2011-05-01 11:04:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:04:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:04:39 --> URI Class Initialized
DEBUG - 2011-05-01 11:04:39 --> Router Class Initialized
DEBUG - 2011-05-01 11:04:39 --> No URI present. Default controller set.
DEBUG - 2011-05-01 11:04:39 --> Output Class Initialized
DEBUG - 2011-05-01 11:04:39 --> Input Class Initialized
DEBUG - 2011-05-01 11:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:04:39 --> Language Class Initialized
DEBUG - 2011-05-01 11:04:39 --> Loader Class Initialized
DEBUG - 2011-05-01 11:04:39 --> Controller Class Initialized
DEBUG - 2011-05-01 11:04:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 11:04:39 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:04:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:04:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:04:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:04:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:04:39 --> Final output sent to browser
DEBUG - 2011-05-01 11:04:39 --> Total execution time: 0.0799
DEBUG - 2011-05-01 11:06:16 --> Config Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:06:16 --> URI Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Router Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Output Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Input Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:06:16 --> Language Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Loader Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Controller Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:06:16 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:06:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:06:16 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:06:16 --> Final output sent to browser
DEBUG - 2011-05-01 11:06:16 --> Total execution time: 0.2744
DEBUG - 2011-05-01 11:06:19 --> Config Class Initialized
DEBUG - 2011-05-01 11:06:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:06:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:06:19 --> URI Class Initialized
DEBUG - 2011-05-01 11:06:19 --> Router Class Initialized
ERROR - 2011-05-01 11:06:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:06:31 --> Config Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:06:31 --> URI Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Router Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Output Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Input Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:06:31 --> Language Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Loader Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Controller Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:06:31 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:06:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:06:31 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:06:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:06:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:06:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:06:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:06:31 --> Final output sent to browser
DEBUG - 2011-05-01 11:06:31 --> Total execution time: 0.2440
DEBUG - 2011-05-01 11:06:33 --> Config Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:06:33 --> URI Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Router Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Output Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Input Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:06:33 --> Language Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Loader Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Controller Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:06:34 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:06:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:06:34 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:06:34 --> Final output sent to browser
DEBUG - 2011-05-01 11:06:34 --> Total execution time: 0.0505
DEBUG - 2011-05-01 11:06:53 --> Config Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:06:53 --> URI Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Router Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Output Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Input Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:06:53 --> Language Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Loader Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Controller Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Model Class Initialized
DEBUG - 2011-05-01 11:06:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:06:53 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:06:54 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:06:54 --> Final output sent to browser
DEBUG - 2011-05-01 11:06:54 --> Total execution time: 0.3138
DEBUG - 2011-05-01 11:07:04 --> Config Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:07:04 --> URI Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Router Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Output Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Input Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:07:04 --> Language Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Loader Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Controller Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:07:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:07:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:07:04 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:07:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:07:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:07:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:07:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:07:04 --> Final output sent to browser
DEBUG - 2011-05-01 11:07:04 --> Total execution time: 0.0563
DEBUG - 2011-05-01 11:07:24 --> Config Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:07:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:07:24 --> URI Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Router Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Output Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Input Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:07:24 --> Language Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Loader Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Controller Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:07:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:07:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:07:24 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:07:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:07:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:07:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:07:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:07:24 --> Final output sent to browser
DEBUG - 2011-05-01 11:07:24 --> Total execution time: 0.7635
DEBUG - 2011-05-01 11:07:29 --> Config Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:07:29 --> URI Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Router Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Output Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Input Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:07:29 --> Language Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Loader Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Controller Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:07:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:07:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:07:29 --> Final output sent to browser
DEBUG - 2011-05-01 11:07:29 --> Total execution time: 0.0881
DEBUG - 2011-05-01 11:07:40 --> Config Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:07:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:07:40 --> URI Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Router Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Output Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Input Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:07:40 --> Language Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Loader Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Controller Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Model Class Initialized
DEBUG - 2011-05-01 11:07:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:07:40 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:07:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:07:40 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:07:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:07:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:07:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:07:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:07:40 --> Final output sent to browser
DEBUG - 2011-05-01 11:07:40 --> Total execution time: 0.0546
DEBUG - 2011-05-01 11:10:24 --> Config Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:10:24 --> URI Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Router Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Output Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Input Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:10:24 --> Language Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Loader Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Controller Class Initialized
ERROR - 2011-05-01 11:10:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:10:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:10:24 --> Model Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Model Class Initialized
DEBUG - 2011-05-01 11:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:10:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:10:24 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:10:24 --> Final output sent to browser
DEBUG - 2011-05-01 11:10:24 --> Total execution time: 0.1568
DEBUG - 2011-05-01 11:10:28 --> Config Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:10:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:10:28 --> URI Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Router Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Output Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Input Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:10:28 --> Language Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Loader Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Controller Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Model Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Model Class Initialized
DEBUG - 2011-05-01 11:10:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:10:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:10:29 --> Final output sent to browser
DEBUG - 2011-05-01 11:10:29 --> Total execution time: 0.8821
DEBUG - 2011-05-01 11:10:34 --> Config Class Initialized
DEBUG - 2011-05-01 11:10:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:10:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:10:34 --> URI Class Initialized
DEBUG - 2011-05-01 11:10:34 --> Router Class Initialized
ERROR - 2011-05-01 11:10:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:32:39 --> Config Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:32:39 --> URI Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Router Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Output Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Input Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:32:39 --> Language Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Loader Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Controller Class Initialized
ERROR - 2011-05-01 11:32:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:32:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:32:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:32:39 --> Model Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Model Class Initialized
DEBUG - 2011-05-01 11:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:32:39 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:32:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:32:39 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:32:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:32:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:32:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:32:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:32:39 --> Final output sent to browser
DEBUG - 2011-05-01 11:32:39 --> Total execution time: 0.6884
DEBUG - 2011-05-01 11:32:40 --> Config Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:32:40 --> URI Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Router Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Output Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Input Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:32:40 --> Language Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Loader Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Controller Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Model Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Model Class Initialized
DEBUG - 2011-05-01 11:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:32:40 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:32:41 --> Final output sent to browser
DEBUG - 2011-05-01 11:32:41 --> Total execution time: 1.1267
DEBUG - 2011-05-01 11:32:42 --> Config Class Initialized
DEBUG - 2011-05-01 11:32:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:32:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:32:42 --> URI Class Initialized
DEBUG - 2011-05-01 11:32:42 --> Router Class Initialized
ERROR - 2011-05-01 11:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:33:13 --> Config Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:33:13 --> URI Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Router Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Output Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Input Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:33:13 --> Language Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Loader Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Controller Class Initialized
ERROR - 2011-05-01 11:33:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:33:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:33:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:33:13 --> Model Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Model Class Initialized
DEBUG - 2011-05-01 11:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:33:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:33:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:33:13 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:33:13 --> Final output sent to browser
DEBUG - 2011-05-01 11:33:13 --> Total execution time: 0.0647
DEBUG - 2011-05-01 11:33:14 --> Config Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:33:14 --> URI Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Router Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Output Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Input Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:33:14 --> Language Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Loader Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Controller Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Model Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Model Class Initialized
DEBUG - 2011-05-01 11:33:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:33:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:33:15 --> Final output sent to browser
DEBUG - 2011-05-01 11:33:15 --> Total execution time: 0.7147
DEBUG - 2011-05-01 11:33:15 --> Config Class Initialized
DEBUG - 2011-05-01 11:33:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:33:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:33:15 --> URI Class Initialized
DEBUG - 2011-05-01 11:33:15 --> Router Class Initialized
ERROR - 2011-05-01 11:33:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:33:21 --> Config Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:33:21 --> URI Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Router Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Output Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Input Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:33:21 --> Language Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Loader Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Controller Class Initialized
ERROR - 2011-05-01 11:33:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:33:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:33:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:33:21 --> Model Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Model Class Initialized
DEBUG - 2011-05-01 11:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:33:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:33:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:33:21 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:33:21 --> Final output sent to browser
DEBUG - 2011-05-01 11:33:21 --> Total execution time: 0.0406
DEBUG - 2011-05-01 11:33:22 --> Config Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:33:22 --> URI Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Router Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Output Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Input Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:33:22 --> Language Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Loader Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Controller Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Model Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Model Class Initialized
DEBUG - 2011-05-01 11:33:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:33:22 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:33:23 --> Final output sent to browser
DEBUG - 2011-05-01 11:33:23 --> Total execution time: 0.7581
DEBUG - 2011-05-01 11:39:51 --> Config Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:39:51 --> URI Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Router Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Output Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Input Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:39:51 --> Language Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Loader Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Controller Class Initialized
ERROR - 2011-05-01 11:39:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:39:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:39:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:39:51 --> Model Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Model Class Initialized
DEBUG - 2011-05-01 11:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:39:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:39:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:39:51 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:39:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:39:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:39:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:39:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:39:51 --> Final output sent to browser
DEBUG - 2011-05-01 11:39:51 --> Total execution time: 0.0300
DEBUG - 2011-05-01 11:39:53 --> Config Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:39:53 --> URI Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Router Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Output Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Input Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:39:53 --> Language Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Loader Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Controller Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Model Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Model Class Initialized
DEBUG - 2011-05-01 11:39:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:39:53 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:39:54 --> Final output sent to browser
DEBUG - 2011-05-01 11:39:54 --> Total execution time: 0.5983
DEBUG - 2011-05-01 11:41:39 --> Config Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:41:39 --> URI Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Router Class Initialized
ERROR - 2011-05-01 11:41:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:41:39 --> Config Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:41:39 --> URI Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Router Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Output Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Input Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:41:39 --> Language Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Loader Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Controller Class Initialized
ERROR - 2011-05-01 11:41:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:41:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:41:39 --> Model Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Model Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:41:39 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:41:39 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:41:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:41:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:41:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:41:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:41:39 --> Final output sent to browser
DEBUG - 2011-05-01 11:41:39 --> Total execution time: 0.0612
DEBUG - 2011-05-01 11:41:39 --> Config Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:41:39 --> URI Class Initialized
DEBUG - 2011-05-01 11:41:39 --> Router Class Initialized
ERROR - 2011-05-01 11:41:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:41:40 --> Config Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:41:40 --> URI Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Router Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Output Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Input Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:41:40 --> Language Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Loader Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Controller Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Model Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Model Class Initialized
DEBUG - 2011-05-01 11:41:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:41:40 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:41:42 --> Config Class Initialized
DEBUG - 2011-05-01 11:41:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:41:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:41:42 --> URI Class Initialized
DEBUG - 2011-05-01 11:41:42 --> Router Class Initialized
ERROR - 2011-05-01 11:41:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:41:42 --> Final output sent to browser
DEBUG - 2011-05-01 11:41:42 --> Total execution time: 2.4501
DEBUG - 2011-05-01 11:41:52 --> Config Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:41:52 --> URI Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Router Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Output Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Input Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:41:52 --> Language Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Loader Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Controller Class Initialized
ERROR - 2011-05-01 11:41:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:41:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:41:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:41:52 --> Model Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Model Class Initialized
DEBUG - 2011-05-01 11:41:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:41:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:41:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:41:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:41:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:41:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:41:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:41:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:41:52 --> Final output sent to browser
DEBUG - 2011-05-01 11:41:52 --> Total execution time: 0.0398
DEBUG - 2011-05-01 11:41:53 --> Config Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:41:53 --> URI Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Router Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Output Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Input Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:41:53 --> Language Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Loader Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Controller Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Model Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Model Class Initialized
DEBUG - 2011-05-01 11:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:41:53 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:41:54 --> Final output sent to browser
DEBUG - 2011-05-01 11:41:54 --> Total execution time: 0.7084
DEBUG - 2011-05-01 11:42:26 --> Config Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:42:26 --> URI Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Router Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Output Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Input Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:42:26 --> Language Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Loader Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Controller Class Initialized
ERROR - 2011-05-01 11:42:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:42:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:42:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:42:26 --> Model Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Model Class Initialized
DEBUG - 2011-05-01 11:42:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:42:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:42:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:42:26 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:42:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:42:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:42:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:42:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:42:26 --> Final output sent to browser
DEBUG - 2011-05-01 11:42:26 --> Total execution time: 0.0794
DEBUG - 2011-05-01 11:42:27 --> Config Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:42:27 --> URI Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Router Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Output Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Input Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:42:27 --> Language Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Loader Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Controller Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Model Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Model Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:42:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:42:27 --> Final output sent to browser
DEBUG - 2011-05-01 11:42:27 --> Total execution time: 0.6729
DEBUG - 2011-05-01 11:48:03 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:03 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:03 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Controller Class Initialized
ERROR - 2011-05-01 11:48:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:48:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:48:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:03 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:03 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:48:03 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:03 --> Total execution time: 0.0994
DEBUG - 2011-05-01 11:48:03 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:03 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:03 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Controller Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:04 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:04 --> Total execution time: 0.6105
DEBUG - 2011-05-01 11:48:04 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:04 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:04 --> Router Class Initialized
ERROR - 2011-05-01 11:48:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:48:05 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:05 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:05 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:05 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:05 --> Router Class Initialized
ERROR - 2011-05-01 11:48:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:48:19 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:19 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:19 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Controller Class Initialized
ERROR - 2011-05-01 11:48:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:48:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:48:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:19 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:19 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:19 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:48:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:48:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:48:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:48:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:48:19 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:19 --> Total execution time: 0.0706
DEBUG - 2011-05-01 11:48:19 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:19 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:19 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Controller Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:19 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:20 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:20 --> Total execution time: 0.5814
DEBUG - 2011-05-01 11:48:26 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:26 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:26 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Controller Class Initialized
ERROR - 2011-05-01 11:48:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:48:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:48:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:26 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:26 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:48:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:48:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:48:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:48:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:48:26 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:26 --> Total execution time: 0.0602
DEBUG - 2011-05-01 11:48:26 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:26 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:26 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Controller Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:27 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:27 --> Total execution time: 0.5125
DEBUG - 2011-05-01 11:48:35 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:35 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:35 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Controller Class Initialized
ERROR - 2011-05-01 11:48:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:48:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:35 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:35 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:48:35 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:35 --> Total execution time: 0.0814
DEBUG - 2011-05-01 11:48:35 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:35 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:35 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Controller Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:36 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:36 --> Total execution time: 0.8982
DEBUG - 2011-05-01 11:48:41 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:41 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:41 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Controller Class Initialized
ERROR - 2011-05-01 11:48:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:48:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:41 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:48:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:48:41 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:41 --> Total execution time: 0.0499
DEBUG - 2011-05-01 11:48:42 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:42 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:42 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Controller Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:42 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:42 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:42 --> Total execution time: 0.5086
DEBUG - 2011-05-01 11:48:50 --> Config Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:48:50 --> URI Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Router Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Output Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Input Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:48:50 --> Language Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Loader Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Controller Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Model Class Initialized
DEBUG - 2011-05-01 11:48:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:48:50 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:48:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:48:50 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:48:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:48:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:48:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:48:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:48:50 --> Final output sent to browser
DEBUG - 2011-05-01 11:48:50 --> Total execution time: 0.8285
DEBUG - 2011-05-01 11:49:09 --> Config Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:49:09 --> URI Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Router Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Output Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Input Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:49:09 --> Language Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Loader Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Controller Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Model Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Model Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Model Class Initialized
DEBUG - 2011-05-01 11:49:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:49:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:49:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 11:49:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:49:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:49:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:49:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:49:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:49:09 --> Final output sent to browser
DEBUG - 2011-05-01 11:49:09 --> Total execution time: 0.0575
DEBUG - 2011-05-01 11:58:06 --> Config Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:58:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:58:06 --> URI Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Router Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Output Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Input Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:58:06 --> Language Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Loader Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Controller Class Initialized
ERROR - 2011-05-01 11:58:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:58:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:58:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:58:06 --> Model Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Model Class Initialized
DEBUG - 2011-05-01 11:58:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:58:06 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:58:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:58:06 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:58:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:58:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:58:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:58:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:58:06 --> Final output sent to browser
DEBUG - 2011-05-01 11:58:06 --> Total execution time: 0.1697
DEBUG - 2011-05-01 11:58:08 --> Config Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:58:08 --> URI Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Router Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Output Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Input Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:58:08 --> Language Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Loader Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Controller Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Model Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Model Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:58:08 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:58:08 --> Final output sent to browser
DEBUG - 2011-05-01 11:58:08 --> Total execution time: 0.5979
DEBUG - 2011-05-01 11:58:10 --> Config Class Initialized
DEBUG - 2011-05-01 11:58:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:58:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:58:10 --> URI Class Initialized
DEBUG - 2011-05-01 11:58:10 --> Router Class Initialized
ERROR - 2011-05-01 11:58:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:59:15 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:15 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:15 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Controller Class Initialized
ERROR - 2011-05-01 11:59:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:59:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:59:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:15 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:15 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:59:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:15 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:59:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:59:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:59:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:59:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:59:15 --> Final output sent to browser
DEBUG - 2011-05-01 11:59:15 --> Total execution time: 0.0278
DEBUG - 2011-05-01 11:59:17 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:17 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:17 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Controller Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:17 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:59:18 --> Final output sent to browser
DEBUG - 2011-05-01 11:59:18 --> Total execution time: 0.5591
DEBUG - 2011-05-01 11:59:19 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:19 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:19 --> Router Class Initialized
ERROR - 2011-05-01 11:59:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:59:25 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:25 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:25 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Controller Class Initialized
ERROR - 2011-05-01 11:59:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:59:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:59:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:25 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:25 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:59:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:25 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:59:25 --> Final output sent to browser
DEBUG - 2011-05-01 11:59:25 --> Total execution time: 0.0304
DEBUG - 2011-05-01 11:59:25 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:25 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:25 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Controller Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:26 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:26 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Controller Class Initialized
ERROR - 2011-05-01 11:59:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:59:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:59:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:26 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:59:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:26 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:59:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:59:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:59:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:59:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:59:26 --> Final output sent to browser
DEBUG - 2011-05-01 11:59:26 --> Total execution time: 0.0486
DEBUG - 2011-05-01 11:59:26 --> Final output sent to browser
DEBUG - 2011-05-01 11:59:26 --> Total execution time: 0.4870
DEBUG - 2011-05-01 11:59:28 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:28 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:28 --> Router Class Initialized
ERROR - 2011-05-01 11:59:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:59:41 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:41 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:41 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Controller Class Initialized
ERROR - 2011-05-01 11:59:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:59:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:59:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:41 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:59:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:59:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:59:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:59:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:59:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:59:41 --> Final output sent to browser
DEBUG - 2011-05-01 11:59:41 --> Total execution time: 0.0301
DEBUG - 2011-05-01 11:59:42 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:42 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:42 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Controller Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:42 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:59:44 --> Final output sent to browser
DEBUG - 2011-05-01 11:59:44 --> Total execution time: 1.9012
DEBUG - 2011-05-01 11:59:46 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:46 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:46 --> Router Class Initialized
ERROR - 2011-05-01 11:59:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 11:59:58 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:58 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:58 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Controller Class Initialized
ERROR - 2011-05-01 11:59:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 11:59:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 11:59:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:58 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 11:59:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 11:59:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 11:59:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 11:59:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 11:59:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 11:59:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 11:59:58 --> Final output sent to browser
DEBUG - 2011-05-01 11:59:58 --> Total execution time: 0.0979
DEBUG - 2011-05-01 11:59:59 --> Config Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 11:59:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 11:59:59 --> URI Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Router Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Output Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Input Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 11:59:59 --> Language Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Loader Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Controller Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Model Class Initialized
DEBUG - 2011-05-01 11:59:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 11:59:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:00 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:00 --> Total execution time: 1.2413
DEBUG - 2011-05-01 12:00:03 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:03 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:03 --> Router Class Initialized
ERROR - 2011-05-01 12:00:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:00:06 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:06 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:06 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Controller Class Initialized
ERROR - 2011-05-01 12:00:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:00:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:00:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:06 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:06 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:06 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:00:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:00:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:00:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:00:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:00:06 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:06 --> Total execution time: 0.0398
DEBUG - 2011-05-01 12:00:07 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:07 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:07 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Controller Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:07 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:07 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:07 --> Total execution time: 0.5082
DEBUG - 2011-05-01 12:00:09 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:09 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:09 --> Router Class Initialized
ERROR - 2011-05-01 12:00:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:00:19 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:19 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:19 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Controller Class Initialized
ERROR - 2011-05-01 12:00:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:00:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:00:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:19 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:19 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:19 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:00:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:00:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:00:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:00:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:00:19 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:19 --> Total execution time: 0.1710
DEBUG - 2011-05-01 12:00:20 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:20 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:20 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Controller Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:20 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:21 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:21 --> Total execution time: 0.5277
DEBUG - 2011-05-01 12:00:23 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:23 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:23 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:23 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:23 --> Router Class Initialized
ERROR - 2011-05-01 12:00:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:00:27 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:27 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:27 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Controller Class Initialized
ERROR - 2011-05-01 12:00:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:00:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:00:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:27 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:27 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:00:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:00:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:00:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:00:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:00:27 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:27 --> Total execution time: 0.0280
DEBUG - 2011-05-01 12:00:28 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:28 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:28 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Controller Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:30 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:30 --> Total execution time: 1.1497
DEBUG - 2011-05-01 12:00:32 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:32 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:32 --> Router Class Initialized
ERROR - 2011-05-01 12:00:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:00:38 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:38 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:38 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Controller Class Initialized
ERROR - 2011-05-01 12:00:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:00:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:00:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:38 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:38 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:38 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:00:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:00:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:00:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:00:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:00:38 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:38 --> Total execution time: 0.1874
DEBUG - 2011-05-01 12:00:39 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:39 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:39 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Controller Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:39 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:40 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:40 --> Total execution time: 0.7267
DEBUG - 2011-05-01 12:00:42 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:42 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:42 --> Router Class Initialized
ERROR - 2011-05-01 12:00:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:00:46 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:46 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:46 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Controller Class Initialized
ERROR - 2011-05-01 12:00:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:00:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:46 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:46 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:46 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:00:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:00:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:00:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:00:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:00:46 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:46 --> Total execution time: 0.0455
DEBUG - 2011-05-01 12:00:47 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:47 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:47 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Controller Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:48 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:48 --> Total execution time: 0.5902
DEBUG - 2011-05-01 12:00:50 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:50 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:50 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:50 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:50 --> Router Class Initialized
ERROR - 2011-05-01 12:00:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:00:55 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:55 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:55 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Controller Class Initialized
ERROR - 2011-05-01 12:00:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:00:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:55 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:55 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:00:55 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:00:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:00:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:00:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:00:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:00:55 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:55 --> Total execution time: 0.0589
DEBUG - 2011-05-01 12:00:56 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:56 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Router Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Output Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Input Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:00:56 --> Language Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Loader Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Controller Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Model Class Initialized
DEBUG - 2011-05-01 12:00:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:00:56 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:00:57 --> Final output sent to browser
DEBUG - 2011-05-01 12:00:57 --> Total execution time: 0.7139
DEBUG - 2011-05-01 12:00:59 --> Config Class Initialized
DEBUG - 2011-05-01 12:00:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:00:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:00:59 --> URI Class Initialized
DEBUG - 2011-05-01 12:00:59 --> Router Class Initialized
ERROR - 2011-05-01 12:00:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:01:01 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:01 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Router Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Output Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Input Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:01:01 --> Language Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Loader Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Controller Class Initialized
ERROR - 2011-05-01 12:01:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:01:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:01:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:01:01 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:01:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:01:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:01:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:01:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:01:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:01:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:01:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:01:01 --> Final output sent to browser
DEBUG - 2011-05-01 12:01:01 --> Total execution time: 0.0347
DEBUG - 2011-05-01 12:01:02 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:02 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Router Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Output Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Input Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:01:02 --> Language Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Loader Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Controller Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:01:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:01:03 --> Final output sent to browser
DEBUG - 2011-05-01 12:01:03 --> Total execution time: 0.8807
DEBUG - 2011-05-01 12:01:04 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:04 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Router Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Output Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Input Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:01:04 --> Language Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Loader Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Controller Class Initialized
ERROR - 2011-05-01 12:01:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:01:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:01:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:01:04 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:01:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:01:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:01:04 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:01:04 --> Final output sent to browser
DEBUG - 2011-05-01 12:01:04 --> Total execution time: 0.1060
DEBUG - 2011-05-01 12:01:06 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:06 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:06 --> Router Class Initialized
ERROR - 2011-05-01 12:01:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:01:09 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:09 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Router Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Output Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Input Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:01:09 --> Language Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Loader Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Controller Class Initialized
ERROR - 2011-05-01 12:01:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:01:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:01:09 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:01:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:01:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:01:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:01:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:01:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:01:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:01:09 --> Final output sent to browser
DEBUG - 2011-05-01 12:01:09 --> Total execution time: 0.0310
DEBUG - 2011-05-01 12:01:10 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:10 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:10 --> Router Class Initialized
DEBUG - 2011-05-01 12:01:10 --> Output Class Initialized
DEBUG - 2011-05-01 12:01:11 --> Input Class Initialized
DEBUG - 2011-05-01 12:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:01:11 --> Language Class Initialized
DEBUG - 2011-05-01 12:01:11 --> Loader Class Initialized
DEBUG - 2011-05-01 12:01:11 --> Controller Class Initialized
DEBUG - 2011-05-01 12:01:11 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:11 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:01:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:01:11 --> Final output sent to browser
DEBUG - 2011-05-01 12:01:11 --> Total execution time: 0.6087
DEBUG - 2011-05-01 12:01:14 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:14 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:14 --> Router Class Initialized
ERROR - 2011-05-01 12:01:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:01:16 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:16 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Router Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Output Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Input Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:01:16 --> Language Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Loader Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Controller Class Initialized
ERROR - 2011-05-01 12:01:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:01:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:01:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:01:16 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:01:16 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:01:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:01:16 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:01:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:01:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:01:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:01:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:01:16 --> Final output sent to browser
DEBUG - 2011-05-01 12:01:16 --> Total execution time: 0.0291
DEBUG - 2011-05-01 12:01:17 --> Config Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:01:17 --> URI Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Router Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Output Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Input Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:01:17 --> Language Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Loader Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Controller Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Model Class Initialized
DEBUG - 2011-05-01 12:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:01:17 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:01:18 --> Final output sent to browser
DEBUG - 2011-05-01 12:01:18 --> Total execution time: 0.6428
DEBUG - 2011-05-01 12:28:03 --> Config Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Config Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:28:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:28:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:28:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:28:03 --> URI Class Initialized
DEBUG - 2011-05-01 12:28:03 --> URI Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Router Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Router Class Initialized
DEBUG - 2011-05-01 12:28:03 --> No URI present. Default controller set.
DEBUG - 2011-05-01 12:28:03 --> No URI present. Default controller set.
DEBUG - 2011-05-01 12:28:03 --> Output Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Output Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Input Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Input Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:28:03 --> Language Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Language Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Loader Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Loader Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Controller Class Initialized
DEBUG - 2011-05-01 12:28:03 --> Controller Class Initialized
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 12:28:03 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:28:03 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:28:03 --> Final output sent to browser
DEBUG - 2011-05-01 12:28:03 --> Total execution time: 0.2680
DEBUG - 2011-05-01 12:28:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:28:03 --> Final output sent to browser
DEBUG - 2011-05-01 12:28:03 --> Total execution time: 0.2696
DEBUG - 2011-05-01 12:30:54 --> Config Class Initialized
DEBUG - 2011-05-01 12:30:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:30:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:30:54 --> URI Class Initialized
DEBUG - 2011-05-01 12:30:54 --> Router Class Initialized
DEBUG - 2011-05-01 12:30:54 --> Output Class Initialized
DEBUG - 2011-05-01 12:30:54 --> Input Class Initialized
DEBUG - 2011-05-01 12:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:30:54 --> Language Class Initialized
DEBUG - 2011-05-01 12:30:54 --> Loader Class Initialized
DEBUG - 2011-05-01 12:30:54 --> Controller Class Initialized
DEBUG - 2011-05-01 12:30:55 --> Model Class Initialized
DEBUG - 2011-05-01 12:30:56 --> Model Class Initialized
DEBUG - 2011-05-01 12:30:56 --> Model Class Initialized
DEBUG - 2011-05-01 12:30:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:30:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:31:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 12:31:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:31:00 --> Final output sent to browser
DEBUG - 2011-05-01 12:31:00 --> Total execution time: 5.3018
DEBUG - 2011-05-01 12:31:12 --> Config Class Initialized
DEBUG - 2011-05-01 12:31:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:31:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:31:12 --> URI Class Initialized
DEBUG - 2011-05-01 12:31:12 --> Router Class Initialized
ERROR - 2011-05-01 12:31:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:31:21 --> Config Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:31:21 --> URI Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Router Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Output Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Input Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:31:21 --> Language Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Loader Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Controller Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:31:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:31:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 12:31:21 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:31:21 --> Final output sent to browser
DEBUG - 2011-05-01 12:31:21 --> Total execution time: 0.3997
DEBUG - 2011-05-01 12:31:29 --> Config Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:31:29 --> URI Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Router Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Output Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Input Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:31:29 --> Language Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Loader Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Controller Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:31:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Config Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:31:29 --> URI Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Router Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Output Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Input Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:31:29 --> Language Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Loader Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Controller Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Model Class Initialized
DEBUG - 2011-05-01 12:31:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:31:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:31:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 12:31:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:31:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:31:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:31:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:31:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:31:29 --> Final output sent to browser
DEBUG - 2011-05-01 12:31:29 --> Total execution time: 0.0513
DEBUG - 2011-05-01 12:31:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 12:31:30 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:31:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:31:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:31:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:31:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:31:30 --> Final output sent to browser
DEBUG - 2011-05-01 12:31:30 --> Total execution time: 0.8055
DEBUG - 2011-05-01 12:31:31 --> Config Class Initialized
DEBUG - 2011-05-01 12:31:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:31:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:31:31 --> URI Class Initialized
DEBUG - 2011-05-01 12:31:31 --> Router Class Initialized
ERROR - 2011-05-01 12:31:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:31:36 --> Config Class Initialized
DEBUG - 2011-05-01 12:31:36 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:31:36 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:31:36 --> URI Class Initialized
DEBUG - 2011-05-01 12:31:36 --> Router Class Initialized
ERROR - 2011-05-01 12:31:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:36:49 --> Config Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:36:49 --> URI Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Router Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Output Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Input Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:36:49 --> Language Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Loader Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Controller Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:36:49 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:36:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 12:36:49 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:36:49 --> Final output sent to browser
DEBUG - 2011-05-01 12:36:49 --> Total execution time: 0.0666
DEBUG - 2011-05-01 12:36:50 --> Config Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:36:50 --> URI Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Router Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Output Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Input Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:36:50 --> Language Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Loader Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Controller Class Initialized
ERROR - 2011-05-01 12:36:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:36:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:36:50 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:36:50 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:36:50 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:36:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:36:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:36:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:36:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:36:50 --> Final output sent to browser
DEBUG - 2011-05-01 12:36:50 --> Total execution time: 0.1599
DEBUG - 2011-05-01 12:36:56 --> Config Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:36:56 --> URI Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Router Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Output Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Input Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:36:56 --> Language Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Loader Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Controller Class Initialized
ERROR - 2011-05-01 12:36:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:36:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:36:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:36:56 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:36:56 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:36:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:36:56 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:36:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:36:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:36:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:36:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:36:56 --> Final output sent to browser
DEBUG - 2011-05-01 12:36:56 --> Total execution time: 0.0323
DEBUG - 2011-05-01 12:36:57 --> Config Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:36:57 --> URI Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Router Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Output Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Input Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:36:57 --> Language Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Loader Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Controller Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Model Class Initialized
DEBUG - 2011-05-01 12:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:36:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:36:58 --> Final output sent to browser
DEBUG - 2011-05-01 12:36:58 --> Total execution time: 0.7829
DEBUG - 2011-05-01 12:36:59 --> Config Class Initialized
DEBUG - 2011-05-01 12:36:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:36:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:36:59 --> URI Class Initialized
DEBUG - 2011-05-01 12:36:59 --> Router Class Initialized
ERROR - 2011-05-01 12:36:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:37:01 --> Config Class Initialized
DEBUG - 2011-05-01 12:37:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:37:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:37:01 --> URI Class Initialized
DEBUG - 2011-05-01 12:37:01 --> Router Class Initialized
ERROR - 2011-05-01 12:37:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:37:01 --> Config Class Initialized
DEBUG - 2011-05-01 12:37:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:37:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:37:01 --> URI Class Initialized
DEBUG - 2011-05-01 12:37:01 --> Router Class Initialized
ERROR - 2011-05-01 12:37:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:56:07 --> Config Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:56:07 --> URI Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Router Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Output Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Input Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:56:07 --> Language Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Loader Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Controller Class Initialized
ERROR - 2011-05-01 12:56:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:56:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:56:07 --> Model Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Model Class Initialized
DEBUG - 2011-05-01 12:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:56:07 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:56:08 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:56:08 --> Final output sent to browser
DEBUG - 2011-05-01 12:56:08 --> Total execution time: 0.2951
DEBUG - 2011-05-01 12:56:11 --> Config Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:56:11 --> URI Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Router Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Output Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Input Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:56:11 --> Language Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Loader Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Controller Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Model Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Model Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:56:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:56:11 --> Final output sent to browser
DEBUG - 2011-05-01 12:56:11 --> Total execution time: 0.7040
DEBUG - 2011-05-01 12:56:13 --> Config Class Initialized
DEBUG - 2011-05-01 12:56:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:56:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:56:13 --> URI Class Initialized
DEBUG - 2011-05-01 12:56:13 --> Router Class Initialized
ERROR - 2011-05-01 12:56:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:57:00 --> Config Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:57:00 --> URI Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Router Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Output Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Input Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:57:00 --> Language Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Loader Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Controller Class Initialized
ERROR - 2011-05-01 12:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:57:00 --> Model Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Model Class Initialized
DEBUG - 2011-05-01 12:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:57:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:57:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:57:00 --> Final output sent to browser
DEBUG - 2011-05-01 12:57:00 --> Total execution time: 0.0310
DEBUG - 2011-05-01 12:57:04 --> Config Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:57:04 --> URI Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Router Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Output Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Input Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:57:04 --> Language Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Loader Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Controller Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Model Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Model Class Initialized
DEBUG - 2011-05-01 12:57:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:57:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:57:05 --> Final output sent to browser
DEBUG - 2011-05-01 12:57:05 --> Total execution time: 0.8656
DEBUG - 2011-05-01 12:57:08 --> Config Class Initialized
DEBUG - 2011-05-01 12:57:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:57:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:57:08 --> URI Class Initialized
DEBUG - 2011-05-01 12:57:08 --> Router Class Initialized
ERROR - 2011-05-01 12:57:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 12:58:29 --> Config Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:58:29 --> URI Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Router Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Output Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Input Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:58:29 --> Language Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Loader Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Controller Class Initialized
ERROR - 2011-05-01 12:58:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 12:58:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 12:58:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:58:29 --> Model Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Model Class Initialized
DEBUG - 2011-05-01 12:58:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:58:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:58:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 12:58:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 12:58:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 12:58:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 12:58:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 12:58:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 12:58:29 --> Final output sent to browser
DEBUG - 2011-05-01 12:58:29 --> Total execution time: 0.0308
DEBUG - 2011-05-01 12:58:31 --> Config Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:58:31 --> URI Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Router Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Output Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Input Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 12:58:31 --> Language Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Loader Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Controller Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Model Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Model Class Initialized
DEBUG - 2011-05-01 12:58:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 12:58:31 --> Database Driver Class Initialized
DEBUG - 2011-05-01 12:58:32 --> Final output sent to browser
DEBUG - 2011-05-01 12:58:32 --> Total execution time: 0.6988
DEBUG - 2011-05-01 12:58:34 --> Config Class Initialized
DEBUG - 2011-05-01 12:58:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 12:58:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 12:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 12:58:34 --> URI Class Initialized
DEBUG - 2011-05-01 12:58:34 --> Router Class Initialized
ERROR - 2011-05-01 12:58:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:25:27 --> Config Class Initialized
DEBUG - 2011-05-01 13:25:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:25:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:25:27 --> URI Class Initialized
DEBUG - 2011-05-01 13:25:27 --> Router Class Initialized
DEBUG - 2011-05-01 13:25:28 --> Output Class Initialized
DEBUG - 2011-05-01 13:25:29 --> Input Class Initialized
DEBUG - 2011-05-01 13:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:25:29 --> Language Class Initialized
DEBUG - 2011-05-01 13:25:29 --> Loader Class Initialized
DEBUG - 2011-05-01 13:25:29 --> Controller Class Initialized
DEBUG - 2011-05-01 13:25:29 --> Model Class Initialized
DEBUG - 2011-05-01 13:25:29 --> Model Class Initialized
DEBUG - 2011-05-01 13:25:29 --> Model Class Initialized
DEBUG - 2011-05-01 13:25:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:25:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:25:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:25:30 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:25:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:25:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:25:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:25:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:25:30 --> Final output sent to browser
DEBUG - 2011-05-01 13:25:30 --> Total execution time: 3.8106
DEBUG - 2011-05-01 13:25:32 --> Config Class Initialized
DEBUG - 2011-05-01 13:25:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:25:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:25:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:25:32 --> URI Class Initialized
DEBUG - 2011-05-01 13:25:32 --> Router Class Initialized
ERROR - 2011-05-01 13:25:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:26:45 --> Config Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:26:45 --> URI Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Router Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Output Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Input Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:26:45 --> Language Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Loader Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Controller Class Initialized
ERROR - 2011-05-01 13:26:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:26:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:26:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:26:45 --> Model Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Model Class Initialized
DEBUG - 2011-05-01 13:26:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:26:45 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:26:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:26:45 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:26:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:26:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:26:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:26:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:26:45 --> Final output sent to browser
DEBUG - 2011-05-01 13:26:45 --> Total execution time: 0.0956
DEBUG - 2011-05-01 13:26:46 --> Config Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:26:46 --> URI Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Router Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Output Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Input Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:26:46 --> Language Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Loader Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Controller Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Model Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Model Class Initialized
DEBUG - 2011-05-01 13:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:26:46 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:26:47 --> Final output sent to browser
DEBUG - 2011-05-01 13:26:47 --> Total execution time: 0.7300
DEBUG - 2011-05-01 13:26:49 --> Config Class Initialized
DEBUG - 2011-05-01 13:26:49 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:26:49 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:26:49 --> URI Class Initialized
DEBUG - 2011-05-01 13:26:49 --> Router Class Initialized
ERROR - 2011-05-01 13:26:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:33:13 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:33:13 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Router Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Output Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Input Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:33:13 --> Language Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Loader Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Controller Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:33:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:33:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:33:13 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:33:13 --> Final output sent to browser
DEBUG - 2011-05-01 13:33:13 --> Total execution time: 0.0519
DEBUG - 2011-05-01 13:33:33 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:33:33 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Router Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:33 --> UTF-8 Support Enabled
ERROR - 2011-05-01 13:33:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:33:33 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Router Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Output Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Input Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:33:33 --> Language Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Loader Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Controller Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:33:33 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:33:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:33:34 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:33:34 --> Final output sent to browser
DEBUG - 2011-05-01 13:33:34 --> Total execution time: 0.4550
DEBUG - 2011-05-01 13:33:35 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:33:35 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Router Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Output Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Input Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:33:35 --> Language Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Loader Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Controller Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:33:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:33:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:33:35 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:33:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:33:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:33:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:33:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:33:35 --> Final output sent to browser
DEBUG - 2011-05-01 13:33:35 --> Total execution time: 0.0556
DEBUG - 2011-05-01 13:33:35 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:33:35 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:35 --> Router Class Initialized
ERROR - 2011-05-01 13:33:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:33:41 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:33:41 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Router Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Output Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Input Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:33:41 --> Language Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Loader Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Controller Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:33:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:33:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:33:42 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:33:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:33:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:33:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:33:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:33:42 --> Final output sent to browser
DEBUG - 2011-05-01 13:33:42 --> Total execution time: 0.5948
DEBUG - 2011-05-01 13:33:43 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:33:43 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:43 --> Router Class Initialized
ERROR - 2011-05-01 13:33:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:33:51 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:33:51 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Router Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Output Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Input Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:33:51 --> Language Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Loader Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Controller Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Model Class Initialized
DEBUG - 2011-05-01 13:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:33:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:33:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:33:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:33:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:33:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:33:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:33:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:33:52 --> Final output sent to browser
DEBUG - 2011-05-01 13:33:52 --> Total execution time: 1.0297
DEBUG - 2011-05-01 13:33:54 --> Config Class Initialized
DEBUG - 2011-05-01 13:33:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:33:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:33:54 --> URI Class Initialized
DEBUG - 2011-05-01 13:33:54 --> Router Class Initialized
ERROR - 2011-05-01 13:33:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:34:09 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:09 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Router Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Output Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Input Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:34:09 --> Language Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Loader Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Controller Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:34:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:34:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:34:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:34:09 --> Final output sent to browser
DEBUG - 2011-05-01 13:34:09 --> Total execution time: 0.3645
DEBUG - 2011-05-01 13:34:10 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:10 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Router Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Output Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Input Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:34:10 --> Language Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Loader Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Controller Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:34:10 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:34:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:34:10 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:34:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:34:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:34:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:34:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:34:10 --> Final output sent to browser
DEBUG - 2011-05-01 13:34:10 --> Total execution time: 0.0546
DEBUG - 2011-05-01 13:34:11 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:11 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:11 --> Router Class Initialized
ERROR - 2011-05-01 13:34:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:34:12 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:12 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Router Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Output Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Input Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:34:12 --> Language Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Loader Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Controller Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:34:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:34:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:34:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:34:12 --> Final output sent to browser
DEBUG - 2011-05-01 13:34:12 --> Total execution time: 0.0445
DEBUG - 2011-05-01 13:34:21 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:21 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Router Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Output Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Input Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:34:21 --> Language Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Loader Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Controller Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:34:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:34:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:34:21 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:34:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:34:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:34:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:34:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:34:21 --> Final output sent to browser
DEBUG - 2011-05-01 13:34:21 --> Total execution time: 0.3972
DEBUG - 2011-05-01 13:34:23 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:23 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:23 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:23 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:23 --> Router Class Initialized
ERROR - 2011-05-01 13:34:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:34:24 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:24 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Router Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Output Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Input Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:34:24 --> Language Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Loader Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Controller Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:34:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:34:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:34:24 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:34:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:34:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:34:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:34:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:34:24 --> Final output sent to browser
DEBUG - 2011-05-01 13:34:24 --> Total execution time: 0.0942
DEBUG - 2011-05-01 13:34:40 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:40 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Router Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Output Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Input Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:34:40 --> Language Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Loader Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Controller Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Model Class Initialized
DEBUG - 2011-05-01 13:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:34:40 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:34:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:34:40 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:34:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:34:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:34:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:34:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:34:40 --> Final output sent to browser
DEBUG - 2011-05-01 13:34:40 --> Total execution time: 0.3061
DEBUG - 2011-05-01 13:34:42 --> Config Class Initialized
DEBUG - 2011-05-01 13:34:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:34:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:34:42 --> URI Class Initialized
DEBUG - 2011-05-01 13:34:42 --> Router Class Initialized
ERROR - 2011-05-01 13:34:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:37:52 --> Config Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:37:52 --> URI Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Router Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Output Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Input Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:37:52 --> Language Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Loader Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Controller Class Initialized
ERROR - 2011-05-01 13:37:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:37:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:37:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:37:52 --> Model Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Model Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:37:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:37:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:37:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:37:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:37:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:37:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:37:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:37:52 --> Final output sent to browser
DEBUG - 2011-05-01 13:37:52 --> Total execution time: 0.0299
DEBUG - 2011-05-01 13:37:52 --> Config Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:37:52 --> URI Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Router Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Output Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Input Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:37:52 --> Language Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Loader Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Controller Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Model Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Model Class Initialized
DEBUG - 2011-05-01 13:37:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:37:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:37:53 --> Final output sent to browser
DEBUG - 2011-05-01 13:37:53 --> Total execution time: 0.8039
DEBUG - 2011-05-01 13:37:54 --> Config Class Initialized
DEBUG - 2011-05-01 13:37:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:37:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:37:54 --> URI Class Initialized
DEBUG - 2011-05-01 13:37:54 --> Router Class Initialized
ERROR - 2011-05-01 13:37:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:37:54 --> Config Class Initialized
DEBUG - 2011-05-01 13:37:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:37:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:37:54 --> URI Class Initialized
DEBUG - 2011-05-01 13:37:54 --> Router Class Initialized
ERROR - 2011-05-01 13:37:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:37:56 --> Config Class Initialized
DEBUG - 2011-05-01 13:37:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:37:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:37:56 --> URI Class Initialized
DEBUG - 2011-05-01 13:37:56 --> Router Class Initialized
ERROR - 2011-05-01 13:37:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:38:08 --> Config Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:38:08 --> URI Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Router Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Output Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Input Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:38:08 --> Language Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Loader Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Controller Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Model Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Model Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Model Class Initialized
DEBUG - 2011-05-01 13:38:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:38:08 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:38:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 13:38:08 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:38:08 --> Final output sent to browser
DEBUG - 2011-05-01 13:38:08 --> Total execution time: 0.1343
DEBUG - 2011-05-01 13:38:11 --> Config Class Initialized
DEBUG - 2011-05-01 13:38:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:38:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:38:11 --> URI Class Initialized
DEBUG - 2011-05-01 13:38:11 --> Router Class Initialized
ERROR - 2011-05-01 13:38:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:39:45 --> Config Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:39:45 --> URI Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Router Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Output Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Input Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:39:45 --> Language Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Loader Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Controller Class Initialized
ERROR - 2011-05-01 13:39:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:39:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:39:45 --> Model Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Model Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:39:45 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:39:45 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:39:45 --> Final output sent to browser
DEBUG - 2011-05-01 13:39:45 --> Total execution time: 0.0397
DEBUG - 2011-05-01 13:39:45 --> Config Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:39:45 --> URI Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Router Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Output Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Input Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:39:45 --> Language Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Loader Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Controller Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Model Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Model Class Initialized
DEBUG - 2011-05-01 13:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:39:45 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:39:46 --> Final output sent to browser
DEBUG - 2011-05-01 13:39:46 --> Total execution time: 0.6579
DEBUG - 2011-05-01 13:39:47 --> Config Class Initialized
DEBUG - 2011-05-01 13:39:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:39:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:39:47 --> URI Class Initialized
DEBUG - 2011-05-01 13:39:47 --> Router Class Initialized
ERROR - 2011-05-01 13:39:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:39:47 --> Config Class Initialized
DEBUG - 2011-05-01 13:39:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:39:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:39:47 --> URI Class Initialized
DEBUG - 2011-05-01 13:39:47 --> Router Class Initialized
ERROR - 2011-05-01 13:39:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 13:40:53 --> Config Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:40:53 --> URI Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Router Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Output Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Input Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:40:53 --> Language Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Loader Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Controller Class Initialized
ERROR - 2011-05-01 13:40:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:40:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:40:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:40:53 --> Model Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Model Class Initialized
DEBUG - 2011-05-01 13:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:40:53 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:40:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:40:53 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:40:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:40:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:40:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:40:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:40:53 --> Final output sent to browser
DEBUG - 2011-05-01 13:40:53 --> Total execution time: 0.0279
DEBUG - 2011-05-01 13:40:54 --> Config Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:40:54 --> URI Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Router Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Output Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Input Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:40:54 --> Language Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Loader Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Controller Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Model Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Model Class Initialized
DEBUG - 2011-05-01 13:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:40:54 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:40:55 --> Final output sent to browser
DEBUG - 2011-05-01 13:40:55 --> Total execution time: 0.9433
DEBUG - 2011-05-01 13:41:14 --> Config Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:41:14 --> URI Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Router Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Output Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Input Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:41:14 --> Language Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Loader Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Controller Class Initialized
ERROR - 2011-05-01 13:41:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:41:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:41:14 --> Model Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Model Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:41:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:41:14 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:41:14 --> Final output sent to browser
DEBUG - 2011-05-01 13:41:14 --> Total execution time: 0.0575
DEBUG - 2011-05-01 13:41:14 --> Config Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:41:14 --> URI Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Router Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Output Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Input Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:41:14 --> Language Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Loader Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Controller Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Model Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Model Class Initialized
DEBUG - 2011-05-01 13:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:41:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:41:15 --> Final output sent to browser
DEBUG - 2011-05-01 13:41:15 --> Total execution time: 0.6580
DEBUG - 2011-05-01 13:41:35 --> Config Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:41:35 --> URI Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Router Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Output Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Input Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:41:35 --> Language Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Loader Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Controller Class Initialized
ERROR - 2011-05-01 13:41:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:41:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:41:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:41:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:41:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:41:35 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:41:35 --> Final output sent to browser
DEBUG - 2011-05-01 13:41:35 --> Total execution time: 0.0308
DEBUG - 2011-05-01 13:41:35 --> Config Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:41:35 --> URI Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Router Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Output Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Input Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:41:35 --> Language Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Loader Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Controller Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:41:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:41:36 --> Final output sent to browser
DEBUG - 2011-05-01 13:41:36 --> Total execution time: 0.6282
DEBUG - 2011-05-01 13:42:00 --> Config Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:42:00 --> URI Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Router Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Output Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Input Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:42:00 --> Language Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Loader Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Controller Class Initialized
ERROR - 2011-05-01 13:42:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:42:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:42:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:42:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:42:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:42:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:42:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:42:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:42:00 --> Final output sent to browser
DEBUG - 2011-05-01 13:42:00 --> Total execution time: 0.0295
DEBUG - 2011-05-01 13:42:01 --> Config Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:42:01 --> URI Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Router Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Output Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Input Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:42:01 --> Language Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Loader Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Controller Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:42:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:42:01 --> Final output sent to browser
DEBUG - 2011-05-01 13:42:01 --> Total execution time: 0.5433
DEBUG - 2011-05-01 13:42:07 --> Config Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:42:07 --> URI Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Router Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Output Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Input Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:42:07 --> Language Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Loader Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Controller Class Initialized
ERROR - 2011-05-01 13:42:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:42:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:42:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:42:07 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:42:07 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:42:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:42:07 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:42:07 --> Final output sent to browser
DEBUG - 2011-05-01 13:42:07 --> Total execution time: 0.0312
DEBUG - 2011-05-01 13:42:08 --> Config Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:42:08 --> URI Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Router Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Output Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Input Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:42:08 --> Language Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Loader Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Controller Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:42:08 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:42:08 --> Final output sent to browser
DEBUG - 2011-05-01 13:42:08 --> Total execution time: 0.5879
DEBUG - 2011-05-01 13:42:39 --> Config Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:42:39 --> URI Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Router Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Output Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Input Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:42:39 --> Language Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Loader Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Controller Class Initialized
ERROR - 2011-05-01 13:42:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:42:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:42:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:42:39 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:42:39 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:42:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:42:39 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:42:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:42:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:42:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:42:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:42:39 --> Final output sent to browser
DEBUG - 2011-05-01 13:42:39 --> Total execution time: 0.0305
DEBUG - 2011-05-01 13:42:40 --> Config Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:42:40 --> URI Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Router Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Output Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Input Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:42:40 --> Language Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Loader Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Controller Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:42:40 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:42:40 --> Final output sent to browser
DEBUG - 2011-05-01 13:42:40 --> Total execution time: 0.7843
DEBUG - 2011-05-01 13:42:57 --> Config Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:42:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:42:57 --> URI Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Router Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Output Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Input Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:42:57 --> Language Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Loader Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Controller Class Initialized
ERROR - 2011-05-01 13:42:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:42:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:42:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:42:57 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:42:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:42:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:42:57 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:42:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:42:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:42:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:42:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:42:57 --> Final output sent to browser
DEBUG - 2011-05-01 13:42:57 --> Total execution time: 0.0292
DEBUG - 2011-05-01 13:42:58 --> Config Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:42:58 --> URI Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Router Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Output Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Input Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:42:58 --> Language Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Loader Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Controller Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Model Class Initialized
DEBUG - 2011-05-01 13:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:42:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:42:59 --> Final output sent to browser
DEBUG - 2011-05-01 13:42:59 --> Total execution time: 1.0096
DEBUG - 2011-05-01 13:43:34 --> Config Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:43:34 --> URI Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Router Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Output Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Input Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:43:34 --> Language Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Loader Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Controller Class Initialized
ERROR - 2011-05-01 13:43:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:43:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:43:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:43:34 --> Model Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Model Class Initialized
DEBUG - 2011-05-01 13:43:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:43:34 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:43:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:43:34 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:43:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:43:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:43:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:43:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:43:34 --> Final output sent to browser
DEBUG - 2011-05-01 13:43:34 --> Total execution time: 0.0293
DEBUG - 2011-05-01 13:43:35 --> Config Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:43:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:43:35 --> URI Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Router Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Output Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Input Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:43:35 --> Language Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Loader Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Controller Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Model Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:43:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:43:35 --> Final output sent to browser
DEBUG - 2011-05-01 13:43:35 --> Total execution time: 0.6223
DEBUG - 2011-05-01 13:43:54 --> Config Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:43:54 --> URI Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Router Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Output Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Input Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:43:54 --> Language Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Loader Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Controller Class Initialized
ERROR - 2011-05-01 13:43:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:43:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:43:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:43:54 --> Model Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Model Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:43:54 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:43:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:43:54 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:43:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:43:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:43:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:43:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:43:54 --> Final output sent to browser
DEBUG - 2011-05-01 13:43:54 --> Total execution time: 0.0287
DEBUG - 2011-05-01 13:43:54 --> Config Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:43:54 --> URI Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Router Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Output Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Input Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:43:54 --> Language Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Loader Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Controller Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Model Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Model Class Initialized
DEBUG - 2011-05-01 13:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:43:54 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:43:55 --> Final output sent to browser
DEBUG - 2011-05-01 13:43:55 --> Total execution time: 0.7740
DEBUG - 2011-05-01 13:44:16 --> Config Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:44:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:44:16 --> URI Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Router Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Output Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Input Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:44:16 --> Language Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Loader Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Controller Class Initialized
ERROR - 2011-05-01 13:44:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:44:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:44:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:44:16 --> Model Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Model Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:44:16 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:44:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:44:16 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:44:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:44:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:44:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:44:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:44:16 --> Final output sent to browser
DEBUG - 2011-05-01 13:44:16 --> Total execution time: 0.0335
DEBUG - 2011-05-01 13:44:16 --> Config Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:44:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:44:16 --> URI Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Router Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Output Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Input Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:44:16 --> Language Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Loader Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Controller Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Model Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Model Class Initialized
DEBUG - 2011-05-01 13:44:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:44:16 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:44:17 --> Final output sent to browser
DEBUG - 2011-05-01 13:44:17 --> Total execution time: 0.6187
DEBUG - 2011-05-01 13:44:26 --> Config Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:44:26 --> URI Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Router Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Output Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Input Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:44:26 --> Language Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Loader Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Controller Class Initialized
ERROR - 2011-05-01 13:44:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:44:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:44:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:44:26 --> Model Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Model Class Initialized
DEBUG - 2011-05-01 13:44:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:44:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:44:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:44:26 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:44:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:44:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:44:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:44:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:44:26 --> Final output sent to browser
DEBUG - 2011-05-01 13:44:26 --> Total execution time: 0.0764
DEBUG - 2011-05-01 13:44:27 --> Config Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:44:27 --> URI Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Router Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Output Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Input Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:44:27 --> Language Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Loader Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Controller Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Model Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Model Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:44:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:44:27 --> Final output sent to browser
DEBUG - 2011-05-01 13:44:27 --> Total execution time: 0.5769
DEBUG - 2011-05-01 13:59:26 --> Config Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:59:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:59:26 --> URI Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Router Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Output Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Input Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:59:26 --> Language Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Loader Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Controller Class Initialized
ERROR - 2011-05-01 13:59:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 13:59:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 13:59:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:59:26 --> Model Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Model Class Initialized
DEBUG - 2011-05-01 13:59:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:59:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:59:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 13:59:26 --> Helper loaded: url_helper
DEBUG - 2011-05-01 13:59:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 13:59:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 13:59:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 13:59:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 13:59:26 --> Final output sent to browser
DEBUG - 2011-05-01 13:59:26 --> Total execution time: 0.1912
DEBUG - 2011-05-01 13:59:28 --> Config Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:59:28 --> URI Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Router Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Output Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Input Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 13:59:28 --> Language Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Loader Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Controller Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Model Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Model Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 13:59:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 13:59:28 --> Final output sent to browser
DEBUG - 2011-05-01 13:59:28 --> Total execution time: 0.6520
DEBUG - 2011-05-01 13:59:30 --> Config Class Initialized
DEBUG - 2011-05-01 13:59:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 13:59:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 13:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 13:59:30 --> URI Class Initialized
DEBUG - 2011-05-01 13:59:30 --> Router Class Initialized
ERROR - 2011-05-01 13:59:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 14:03:41 --> Config Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:03:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:03:41 --> URI Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Router Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Output Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Input Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:03:41 --> Language Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Loader Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Controller Class Initialized
ERROR - 2011-05-01 14:03:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:03:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:03:41 --> Model Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Model Class Initialized
DEBUG - 2011-05-01 14:03:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:03:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:03:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:03:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:03:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:03:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:03:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:03:41 --> Final output sent to browser
DEBUG - 2011-05-01 14:03:41 --> Total execution time: 0.0305
DEBUG - 2011-05-01 14:03:43 --> Config Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:03:43 --> URI Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Router Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Output Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Input Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:03:43 --> Language Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Loader Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Controller Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Model Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Model Class Initialized
DEBUG - 2011-05-01 14:03:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:03:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:03:44 --> Final output sent to browser
DEBUG - 2011-05-01 14:03:44 --> Total execution time: 0.6680
DEBUG - 2011-05-01 14:03:45 --> Config Class Initialized
DEBUG - 2011-05-01 14:03:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:03:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:03:45 --> URI Class Initialized
DEBUG - 2011-05-01 14:03:45 --> Router Class Initialized
ERROR - 2011-05-01 14:03:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 14:04:01 --> Config Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:04:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:04:01 --> URI Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Router Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Output Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Input Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:04:01 --> Language Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Loader Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Controller Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:04:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:04:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 14:04:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:04:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:04:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:04:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:04:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:04:01 --> Final output sent to browser
DEBUG - 2011-05-01 14:04:01 --> Total execution time: 0.2231
DEBUG - 2011-05-01 14:04:04 --> Config Class Initialized
DEBUG - 2011-05-01 14:04:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:04:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:04:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:04:04 --> URI Class Initialized
DEBUG - 2011-05-01 14:04:04 --> Router Class Initialized
ERROR - 2011-05-01 14:04:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 14:04:19 --> Config Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:04:19 --> URI Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Router Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Output Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Input Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:04:19 --> Language Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Loader Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Controller Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:04:19 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:04:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 14:04:19 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:04:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:04:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:04:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:04:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:04:19 --> Final output sent to browser
DEBUG - 2011-05-01 14:04:19 --> Total execution time: 0.0473
DEBUG - 2011-05-01 14:04:25 --> Config Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:04:25 --> URI Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Router Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Output Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Input Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:04:25 --> Language Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Loader Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Controller Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:04:25 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:04:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 14:04:25 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:04:25 --> Final output sent to browser
DEBUG - 2011-05-01 14:04:25 --> Total execution time: 0.2218
DEBUG - 2011-05-01 14:04:27 --> Config Class Initialized
DEBUG - 2011-05-01 14:04:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:04:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:04:27 --> URI Class Initialized
DEBUG - 2011-05-01 14:04:27 --> Router Class Initialized
ERROR - 2011-05-01 14:04:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 14:04:55 --> Config Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:04:55 --> URI Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Router Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Output Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Input Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:04:55 --> Language Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Loader Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Controller Class Initialized
ERROR - 2011-05-01 14:04:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:04:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:04:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:04:55 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:04:55 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:04:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:04:55 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:04:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:04:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:04:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:04:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:04:55 --> Final output sent to browser
DEBUG - 2011-05-01 14:04:55 --> Total execution time: 0.3271
DEBUG - 2011-05-01 14:04:58 --> Config Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:04:58 --> URI Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Router Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Output Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Input Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:04:58 --> Language Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Loader Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Controller Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Model Class Initialized
DEBUG - 2011-05-01 14:04:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:04:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:05:00 --> Final output sent to browser
DEBUG - 2011-05-01 14:05:00 --> Total execution time: 1.3789
DEBUG - 2011-05-01 14:09:27 --> Config Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:09:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:09:27 --> URI Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Router Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Output Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Input Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:09:27 --> Language Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Loader Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Controller Class Initialized
ERROR - 2011-05-01 14:09:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:09:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:09:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:09:27 --> Model Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Model Class Initialized
DEBUG - 2011-05-01 14:09:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:09:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:09:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:09:27 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:09:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:09:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:09:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:09:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:09:27 --> Final output sent to browser
DEBUG - 2011-05-01 14:09:27 --> Total execution time: 0.0879
DEBUG - 2011-05-01 14:09:28 --> Config Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:09:28 --> URI Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Router Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Output Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Input Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:09:28 --> Language Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Loader Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Controller Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Model Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Model Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:09:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:09:28 --> Final output sent to browser
DEBUG - 2011-05-01 14:09:28 --> Total execution time: 0.5518
DEBUG - 2011-05-01 14:09:30 --> Config Class Initialized
DEBUG - 2011-05-01 14:09:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:09:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:09:30 --> URI Class Initialized
DEBUG - 2011-05-01 14:09:30 --> Router Class Initialized
ERROR - 2011-05-01 14:09:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 14:09:30 --> Config Class Initialized
DEBUG - 2011-05-01 14:09:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:09:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:09:30 --> URI Class Initialized
DEBUG - 2011-05-01 14:09:30 --> Router Class Initialized
ERROR - 2011-05-01 14:09:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 14:09:58 --> Config Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:09:58 --> URI Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Router Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Output Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Input Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:09:58 --> Language Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Loader Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Controller Class Initialized
ERROR - 2011-05-01 14:09:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:09:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:09:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:09:58 --> Model Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Model Class Initialized
DEBUG - 2011-05-01 14:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:09:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:09:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:09:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:09:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:09:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:09:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:09:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:09:58 --> Final output sent to browser
DEBUG - 2011-05-01 14:09:58 --> Total execution time: 0.0276
DEBUG - 2011-05-01 14:09:59 --> Config Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:09:59 --> URI Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Router Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Output Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Input Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:09:59 --> Language Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Loader Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Controller Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Model Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Model Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:09:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:09:59 --> Final output sent to browser
DEBUG - 2011-05-01 14:09:59 --> Total execution time: 0.5608
DEBUG - 2011-05-01 14:10:31 --> Config Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:10:31 --> URI Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Router Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Output Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Input Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:10:31 --> Language Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Loader Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Controller Class Initialized
ERROR - 2011-05-01 14:10:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:10:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:10:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:10:31 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:10:31 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:10:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:10:31 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:10:31 --> Final output sent to browser
DEBUG - 2011-05-01 14:10:31 --> Total execution time: 0.0314
DEBUG - 2011-05-01 14:10:32 --> Config Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:10:32 --> URI Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Router Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Output Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Input Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:10:32 --> Language Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Loader Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Controller Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:10:32 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:10:33 --> Final output sent to browser
DEBUG - 2011-05-01 14:10:33 --> Total execution time: 1.0814
DEBUG - 2011-05-01 14:10:46 --> Config Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:10:46 --> URI Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Router Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Output Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Input Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:10:46 --> Language Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Loader Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Controller Class Initialized
ERROR - 2011-05-01 14:10:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:10:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:10:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:10:46 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:10:46 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:10:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:10:46 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:10:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:10:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:10:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:10:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:10:46 --> Final output sent to browser
DEBUG - 2011-05-01 14:10:46 --> Total execution time: 0.0341
DEBUG - 2011-05-01 14:10:47 --> Config Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:10:47 --> URI Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Router Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Output Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Input Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:10:47 --> Language Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Loader Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Controller Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:10:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:10:48 --> Final output sent to browser
DEBUG - 2011-05-01 14:10:48 --> Total execution time: 1.2049
DEBUG - 2011-05-01 14:10:56 --> Config Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:10:56 --> URI Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Router Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Output Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Input Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:10:56 --> Language Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Loader Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Controller Class Initialized
ERROR - 2011-05-01 14:10:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:10:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:10:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:10:56 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:10:56 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:10:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:10:56 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:10:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:10:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:10:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:10:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:10:56 --> Final output sent to browser
DEBUG - 2011-05-01 14:10:56 --> Total execution time: 0.0329
DEBUG - 2011-05-01 14:10:56 --> Config Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:10:56 --> URI Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Router Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Output Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Input Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:10:56 --> Language Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Loader Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Controller Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Model Class Initialized
DEBUG - 2011-05-01 14:10:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:10:56 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:10:57 --> Final output sent to browser
DEBUG - 2011-05-01 14:10:57 --> Total execution time: 0.9412
DEBUG - 2011-05-01 14:11:06 --> Config Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:11:06 --> URI Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Router Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Output Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Input Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:11:06 --> Language Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Loader Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Controller Class Initialized
ERROR - 2011-05-01 14:11:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:11:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:11:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:11:06 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:11:06 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:11:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:11:06 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:11:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:11:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:11:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:11:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:11:06 --> Final output sent to browser
DEBUG - 2011-05-01 14:11:06 --> Total execution time: 0.0331
DEBUG - 2011-05-01 14:11:07 --> Config Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:11:07 --> URI Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Router Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Output Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Input Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:11:07 --> Language Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Loader Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Controller Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:11:07 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:11:08 --> Final output sent to browser
DEBUG - 2011-05-01 14:11:08 --> Total execution time: 0.9476
DEBUG - 2011-05-01 14:11:21 --> Config Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:11:21 --> URI Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Router Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Output Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Input Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:11:21 --> Language Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Loader Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Controller Class Initialized
ERROR - 2011-05-01 14:11:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:11:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:11:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:11:21 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:11:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:11:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:11:21 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:11:21 --> Final output sent to browser
DEBUG - 2011-05-01 14:11:21 --> Total execution time: 0.0318
DEBUG - 2011-05-01 14:11:22 --> Config Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:11:22 --> URI Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Router Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Output Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Input Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:11:22 --> Language Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Loader Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Controller Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:11:22 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:11:23 --> Final output sent to browser
DEBUG - 2011-05-01 14:11:23 --> Total execution time: 0.5747
DEBUG - 2011-05-01 14:11:33 --> Config Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:11:33 --> URI Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Router Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Output Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Input Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:11:33 --> Language Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Loader Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Controller Class Initialized
ERROR - 2011-05-01 14:11:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:11:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:11:33 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:11:33 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:11:33 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:11:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:11:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:11:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:11:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:11:33 --> Final output sent to browser
DEBUG - 2011-05-01 14:11:33 --> Total execution time: 0.0379
DEBUG - 2011-05-01 14:11:33 --> Config Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:11:33 --> URI Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Router Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Output Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Input Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:11:33 --> Language Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Loader Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Controller Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:11:33 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:11:34 --> Final output sent to browser
DEBUG - 2011-05-01 14:11:34 --> Total execution time: 0.8556
DEBUG - 2011-05-01 14:11:47 --> Config Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:11:47 --> URI Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Router Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Output Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Input Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:11:47 --> Language Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Loader Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Controller Class Initialized
ERROR - 2011-05-01 14:11:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:11:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:11:47 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:11:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:11:47 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:11:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:11:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:11:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:11:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:11:47 --> Final output sent to browser
DEBUG - 2011-05-01 14:11:47 --> Total execution time: 0.0334
DEBUG - 2011-05-01 14:11:48 --> Config Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:11:48 --> URI Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Router Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Output Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Input Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:11:48 --> Language Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Loader Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Controller Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Model Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:11:48 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:11:48 --> Final output sent to browser
DEBUG - 2011-05-01 14:11:48 --> Total execution time: 0.6829
DEBUG - 2011-05-01 14:41:53 --> Config Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:41:53 --> URI Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Router Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Output Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Input Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:41:53 --> Language Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Loader Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Controller Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Model Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Model Class Initialized
DEBUG - 2011-05-01 14:41:53 --> Model Class Initialized
DEBUG - 2011-05-01 14:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:41:54 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:41:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 14:41:55 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:41:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:41:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:41:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:41:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:41:55 --> Final output sent to browser
DEBUG - 2011-05-01 14:41:55 --> Total execution time: 3.1910
DEBUG - 2011-05-01 14:41:58 --> Config Class Initialized
DEBUG - 2011-05-01 14:41:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:41:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:41:58 --> URI Class Initialized
DEBUG - 2011-05-01 14:41:58 --> Router Class Initialized
ERROR - 2011-05-01 14:41:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 14:48:37 --> Config Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:48:37 --> URI Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Router Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Output Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Input Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:48:37 --> Language Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Loader Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Controller Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Model Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Model Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Model Class Initialized
DEBUG - 2011-05-01 14:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:48:37 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:48:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 14:48:37 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:48:37 --> Final output sent to browser
DEBUG - 2011-05-01 14:48:37 --> Total execution time: 0.0807
DEBUG - 2011-05-01 14:48:38 --> Config Class Initialized
DEBUG - 2011-05-01 14:48:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:48:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:48:38 --> URI Class Initialized
DEBUG - 2011-05-01 14:48:38 --> Router Class Initialized
ERROR - 2011-05-01 14:48:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 14:49:12 --> Config Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:49:12 --> URI Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Router Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Output Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Input Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:49:12 --> Language Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Loader Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Controller Class Initialized
ERROR - 2011-05-01 14:49:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 14:49:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 14:49:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:49:12 --> Model Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Model Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:49:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:49:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 14:49:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 14:49:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 14:49:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 14:49:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 14:49:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 14:49:12 --> Final output sent to browser
DEBUG - 2011-05-01 14:49:12 --> Total execution time: 0.0776
DEBUG - 2011-05-01 14:49:12 --> Config Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:49:12 --> URI Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Router Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Output Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Input Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 14:49:12 --> Language Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Loader Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Controller Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Model Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Model Class Initialized
DEBUG - 2011-05-01 14:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 14:49:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 14:49:13 --> Final output sent to browser
DEBUG - 2011-05-01 14:49:13 --> Total execution time: 0.6484
DEBUG - 2011-05-01 14:49:14 --> Config Class Initialized
DEBUG - 2011-05-01 14:49:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 14:49:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 14:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 14:49:14 --> URI Class Initialized
DEBUG - 2011-05-01 14:49:14 --> Router Class Initialized
ERROR - 2011-05-01 14:49:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 15:13:28 --> Config Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 15:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 15:13:28 --> URI Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Router Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Output Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Input Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 15:13:28 --> Language Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Loader Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Controller Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Model Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Model Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Model Class Initialized
DEBUG - 2011-05-01 15:13:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 15:13:28 --> Database Driver Class Initialized
DEBUG - 2011-05-01 15:13:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 15:13:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 15:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 15:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 15:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 15:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 15:13:29 --> Final output sent to browser
DEBUG - 2011-05-01 15:13:29 --> Total execution time: 0.5730
DEBUG - 2011-05-01 15:13:30 --> Config Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 15:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 15:13:30 --> URI Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Router Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Output Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Input Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 15:13:30 --> Language Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Loader Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Controller Class Initialized
ERROR - 2011-05-01 15:13:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 15:13:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 15:13:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 15:13:30 --> Model Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Model Class Initialized
DEBUG - 2011-05-01 15:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 15:13:30 --> Database Driver Class Initialized
DEBUG - 2011-05-01 15:13:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 15:13:30 --> Helper loaded: url_helper
DEBUG - 2011-05-01 15:13:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 15:13:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 15:13:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 15:13:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 15:13:30 --> Final output sent to browser
DEBUG - 2011-05-01 15:13:30 --> Total execution time: 0.0360
DEBUG - 2011-05-01 16:00:27 --> Config Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:00:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:00:27 --> URI Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Router Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Output Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Input Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:00:27 --> Language Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Loader Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Controller Class Initialized
ERROR - 2011-05-01 16:00:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 16:00:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 16:00:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 16:00:27 --> Model Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Model Class Initialized
DEBUG - 2011-05-01 16:00:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 16:00:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 16:00:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 16:00:27 --> Helper loaded: url_helper
DEBUG - 2011-05-01 16:00:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 16:00:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 16:00:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 16:00:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 16:00:27 --> Final output sent to browser
DEBUG - 2011-05-01 16:00:27 --> Total execution time: 0.8331
DEBUG - 2011-05-01 16:00:29 --> Config Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:00:29 --> URI Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Router Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Output Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Input Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:00:29 --> Language Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Loader Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Controller Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Model Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Model Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 16:00:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 16:00:29 --> Final output sent to browser
DEBUG - 2011-05-01 16:00:29 --> Total execution time: 0.8212
DEBUG - 2011-05-01 16:00:31 --> Config Class Initialized
DEBUG - 2011-05-01 16:00:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:00:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:00:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:00:31 --> URI Class Initialized
DEBUG - 2011-05-01 16:00:31 --> Router Class Initialized
ERROR - 2011-05-01 16:00:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 16:00:32 --> Config Class Initialized
DEBUG - 2011-05-01 16:00:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:00:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:00:32 --> URI Class Initialized
DEBUG - 2011-05-01 16:00:32 --> Router Class Initialized
ERROR - 2011-05-01 16:00:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 16:05:54 --> Config Class Initialized
DEBUG - 2011-05-01 16:05:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:05:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:05:54 --> URI Class Initialized
DEBUG - 2011-05-01 16:05:54 --> Router Class Initialized
DEBUG - 2011-05-01 16:05:54 --> No URI present. Default controller set.
DEBUG - 2011-05-01 16:05:54 --> Output Class Initialized
DEBUG - 2011-05-01 16:05:54 --> Input Class Initialized
DEBUG - 2011-05-01 16:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:05:54 --> Language Class Initialized
DEBUG - 2011-05-01 16:05:54 --> Loader Class Initialized
DEBUG - 2011-05-01 16:05:54 --> Controller Class Initialized
DEBUG - 2011-05-01 16:05:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 16:05:54 --> Helper loaded: url_helper
DEBUG - 2011-05-01 16:05:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 16:05:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 16:05:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 16:05:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 16:05:54 --> Final output sent to browser
DEBUG - 2011-05-01 16:05:54 --> Total execution time: 0.1316
DEBUG - 2011-05-01 16:05:55 --> Config Class Initialized
DEBUG - 2011-05-01 16:05:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:05:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:05:55 --> URI Class Initialized
DEBUG - 2011-05-01 16:05:55 --> Router Class Initialized
ERROR - 2011-05-01 16:05:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 16:19:13 --> Config Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:19:13 --> URI Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Router Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Output Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Input Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:19:13 --> Language Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Loader Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Controller Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Model Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Model Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Model Class Initialized
DEBUG - 2011-05-01 16:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 16:19:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 16:19:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 16:19:14 --> Helper loaded: url_helper
DEBUG - 2011-05-01 16:19:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 16:19:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 16:19:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 16:19:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 16:19:14 --> Final output sent to browser
DEBUG - 2011-05-01 16:19:14 --> Total execution time: 0.7392
DEBUG - 2011-05-01 16:19:20 --> Config Class Initialized
DEBUG - 2011-05-01 16:19:20 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:19:20 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:19:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:19:20 --> URI Class Initialized
DEBUG - 2011-05-01 16:19:20 --> Router Class Initialized
ERROR - 2011-05-01 16:19:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 16:56:58 --> Config Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:56:58 --> URI Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Router Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Output Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Input Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:56:58 --> Language Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Loader Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Controller Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Model Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Model Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Model Class Initialized
DEBUG - 2011-05-01 16:56:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 16:56:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 16:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 16:56:59 --> Helper loaded: url_helper
DEBUG - 2011-05-01 16:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 16:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 16:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 16:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 16:56:59 --> Final output sent to browser
DEBUG - 2011-05-01 16:56:59 --> Total execution time: 1.2611
DEBUG - 2011-05-01 16:57:01 --> Config Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:57:01 --> URI Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Router Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Output Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Input Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:57:01 --> Language Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Loader Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Controller Class Initialized
ERROR - 2011-05-01 16:57:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 16:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 16:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 16:57:01 --> Model Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Model Class Initialized
DEBUG - 2011-05-01 16:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 16:57:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 16:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 16:57:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 16:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 16:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 16:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 16:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 16:57:01 --> Final output sent to browser
DEBUG - 2011-05-01 16:57:01 --> Total execution time: 0.1100
DEBUG - 2011-05-01 16:57:29 --> Config Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:57:29 --> URI Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Router Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Output Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Input Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:57:29 --> Language Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Loader Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Controller Class Initialized
ERROR - 2011-05-01 16:57:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 16:57:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 16:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 16:57:29 --> Model Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Model Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 16:57:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 16:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 16:57:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 16:57:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 16:57:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 16:57:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 16:57:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 16:57:29 --> Final output sent to browser
DEBUG - 2011-05-01 16:57:29 --> Total execution time: 0.0479
DEBUG - 2011-05-01 16:57:29 --> Config Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:57:29 --> URI Class Initialized
DEBUG - 2011-05-01 16:57:29 --> Router Class Initialized
ERROR - 2011-05-01 16:57:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 16:57:32 --> Config Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:57:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:57:32 --> URI Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Router Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Output Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Input Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:57:32 --> Language Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Loader Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Controller Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Model Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Model Class Initialized
DEBUG - 2011-05-01 16:57:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 16:57:32 --> Database Driver Class Initialized
DEBUG - 2011-05-01 16:57:33 --> Final output sent to browser
DEBUG - 2011-05-01 16:57:33 --> Total execution time: 0.7525
DEBUG - 2011-05-01 16:59:03 --> Config Class Initialized
DEBUG - 2011-05-01 16:59:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:59:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:59:03 --> URI Class Initialized
DEBUG - 2011-05-01 16:59:03 --> Router Class Initialized
DEBUG - 2011-05-01 16:59:03 --> No URI present. Default controller set.
DEBUG - 2011-05-01 16:59:03 --> Output Class Initialized
DEBUG - 2011-05-01 16:59:03 --> Input Class Initialized
DEBUG - 2011-05-01 16:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:59:03 --> Language Class Initialized
DEBUG - 2011-05-01 16:59:03 --> Loader Class Initialized
DEBUG - 2011-05-01 16:59:03 --> Controller Class Initialized
DEBUG - 2011-05-01 16:59:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 16:59:03 --> Helper loaded: url_helper
DEBUG - 2011-05-01 16:59:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 16:59:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 16:59:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 16:59:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 16:59:09 --> Config Class Initialized
DEBUG - 2011-05-01 16:59:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 16:59:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 16:59:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 16:59:09 --> URI Class Initialized
DEBUG - 2011-05-01 16:59:09 --> Router Class Initialized
DEBUG - 2011-05-01 16:59:09 --> No URI present. Default controller set.
DEBUG - 2011-05-01 16:59:09 --> Output Class Initialized
DEBUG - 2011-05-01 16:59:09 --> Input Class Initialized
DEBUG - 2011-05-01 16:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 16:59:09 --> Language Class Initialized
DEBUG - 2011-05-01 16:59:09 --> Loader Class Initialized
DEBUG - 2011-05-01 16:59:09 --> Controller Class Initialized
DEBUG - 2011-05-01 16:59:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 16:59:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 16:59:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 16:59:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 16:59:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 16:59:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:00:47 --> Config Class Initialized
DEBUG - 2011-05-01 17:00:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:00:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:00:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:00:47 --> URI Class Initialized
DEBUG - 2011-05-01 17:00:47 --> Router Class Initialized
DEBUG - 2011-05-01 17:00:47 --> No URI present. Default controller set.
DEBUG - 2011-05-01 17:00:47 --> Output Class Initialized
DEBUG - 2011-05-01 17:00:47 --> Input Class Initialized
DEBUG - 2011-05-01 17:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:00:47 --> Language Class Initialized
DEBUG - 2011-05-01 17:00:47 --> Loader Class Initialized
DEBUG - 2011-05-01 17:00:47 --> Controller Class Initialized
DEBUG - 2011-05-01 17:00:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 17:00:47 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:00:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:00:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:00:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:00:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:01:18 --> Config Class Initialized
DEBUG - 2011-05-01 17:01:18 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:01:18 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:01:18 --> URI Class Initialized
DEBUG - 2011-05-01 17:01:18 --> Router Class Initialized
DEBUG - 2011-05-01 17:01:18 --> No URI present. Default controller set.
DEBUG - 2011-05-01 17:01:18 --> Output Class Initialized
DEBUG - 2011-05-01 17:01:18 --> Input Class Initialized
DEBUG - 2011-05-01 17:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:01:18 --> Language Class Initialized
DEBUG - 2011-05-01 17:01:18 --> Loader Class Initialized
DEBUG - 2011-05-01 17:01:18 --> Controller Class Initialized
DEBUG - 2011-05-01 17:01:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 17:01:18 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:01:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:01:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:01:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:01:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:02:11 --> Config Class Initialized
DEBUG - 2011-05-01 17:02:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:02:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:02:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:02:11 --> URI Class Initialized
DEBUG - 2011-05-01 17:02:11 --> Router Class Initialized
DEBUG - 2011-05-01 17:02:11 --> No URI present. Default controller set.
DEBUG - 2011-05-01 17:02:11 --> Output Class Initialized
DEBUG - 2011-05-01 17:02:11 --> Input Class Initialized
DEBUG - 2011-05-01 17:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:02:11 --> Language Class Initialized
DEBUG - 2011-05-01 17:02:11 --> Loader Class Initialized
DEBUG - 2011-05-01 17:02:11 --> Controller Class Initialized
DEBUG - 2011-05-01 17:02:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 17:02:11 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:02:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:02:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:02:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:02:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:02:51 --> Config Class Initialized
DEBUG - 2011-05-01 17:02:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:02:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:02:51 --> URI Class Initialized
DEBUG - 2011-05-01 17:02:51 --> Router Class Initialized
DEBUG - 2011-05-01 17:02:51 --> No URI present. Default controller set.
DEBUG - 2011-05-01 17:02:51 --> Output Class Initialized
DEBUG - 2011-05-01 17:02:51 --> Input Class Initialized
DEBUG - 2011-05-01 17:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:02:51 --> Language Class Initialized
DEBUG - 2011-05-01 17:02:51 --> Loader Class Initialized
DEBUG - 2011-05-01 17:02:51 --> Controller Class Initialized
DEBUG - 2011-05-01 17:02:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 17:02:51 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:02:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:02:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:02:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:02:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:10:47 --> Config Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:10:47 --> URI Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Router Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Output Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Input Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:10:47 --> Language Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Loader Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Controller Class Initialized
ERROR - 2011-05-01 17:10:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 17:10:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 17:10:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:10:47 --> Model Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Model Class Initialized
DEBUG - 2011-05-01 17:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:10:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:10:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:10:47 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:10:47 --> Final output sent to browser
DEBUG - 2011-05-01 17:10:47 --> Total execution time: 0.1495
DEBUG - 2011-05-01 17:10:48 --> Config Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:10:48 --> URI Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Router Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Output Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Input Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:10:48 --> Language Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Loader Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Controller Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Model Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Model Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:10:48 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:10:48 --> Final output sent to browser
DEBUG - 2011-05-01 17:10:48 --> Total execution time: 0.6766
DEBUG - 2011-05-01 17:10:49 --> Config Class Initialized
DEBUG - 2011-05-01 17:10:49 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:10:49 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:10:49 --> URI Class Initialized
DEBUG - 2011-05-01 17:10:49 --> Router Class Initialized
ERROR - 2011-05-01 17:10:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:12:10 --> Config Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:12:10 --> URI Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Router Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Output Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Input Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:12:10 --> Language Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Loader Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Controller Class Initialized
ERROR - 2011-05-01 17:12:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 17:12:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 17:12:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:12:10 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:12:10 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:12:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:12:10 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:12:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:12:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:12:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:12:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:12:10 --> Final output sent to browser
DEBUG - 2011-05-01 17:12:10 --> Total execution time: 0.0348
DEBUG - 2011-05-01 17:12:11 --> Config Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:12:11 --> URI Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Router Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Output Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Input Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:12:11 --> Language Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Loader Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Controller Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:12:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:12:12 --> Final output sent to browser
DEBUG - 2011-05-01 17:12:12 --> Total execution time: 0.6799
DEBUG - 2011-05-01 17:12:12 --> Config Class Initialized
DEBUG - 2011-05-01 17:12:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:12:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:12:12 --> URI Class Initialized
DEBUG - 2011-05-01 17:12:12 --> Router Class Initialized
ERROR - 2011-05-01 17:12:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:12:13 --> Config Class Initialized
DEBUG - 2011-05-01 17:12:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:12:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:12:13 --> URI Class Initialized
DEBUG - 2011-05-01 17:12:13 --> Router Class Initialized
ERROR - 2011-05-01 17:12:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:12:14 --> Config Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:12:14 --> URI Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Router Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Output Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Input Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:12:14 --> Language Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Loader Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Controller Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:12:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:12:15 --> Final output sent to browser
DEBUG - 2011-05-01 17:12:15 --> Total execution time: 0.7617
DEBUG - 2011-05-01 17:12:24 --> Config Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:12:24 --> URI Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Router Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Output Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Input Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:12:24 --> Language Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Loader Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Controller Class Initialized
ERROR - 2011-05-01 17:12:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 17:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 17:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:12:24 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:12:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:12:24 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:12:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:12:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:12:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:12:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:12:24 --> Final output sent to browser
DEBUG - 2011-05-01 17:12:24 --> Total execution time: 0.0791
DEBUG - 2011-05-01 17:12:24 --> Config Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:12:24 --> URI Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Router Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Output Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Input Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:12:24 --> Language Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Loader Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Controller Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Model Class Initialized
DEBUG - 2011-05-01 17:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:12:24 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:12:25 --> Final output sent to browser
DEBUG - 2011-05-01 17:12:25 --> Total execution time: 0.6994
DEBUG - 2011-05-01 17:12:25 --> Config Class Initialized
DEBUG - 2011-05-01 17:12:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:12:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:12:25 --> URI Class Initialized
DEBUG - 2011-05-01 17:12:25 --> Router Class Initialized
ERROR - 2011-05-01 17:12:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:13:07 --> Config Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:13:07 --> URI Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Router Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Output Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Input Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:13:07 --> Language Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Loader Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Controller Class Initialized
ERROR - 2011-05-01 17:13:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 17:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 17:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:13:07 --> Model Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Model Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:13:07 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:13:07 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:13:07 --> Final output sent to browser
DEBUG - 2011-05-01 17:13:07 --> Total execution time: 0.0464
DEBUG - 2011-05-01 17:13:07 --> Config Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:13:07 --> URI Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Router Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Output Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Input Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:13:07 --> Language Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Loader Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Controller Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Model Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Model Class Initialized
DEBUG - 2011-05-01 17:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:13:07 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:13:08 --> Final output sent to browser
DEBUG - 2011-05-01 17:13:08 --> Total execution time: 0.5606
DEBUG - 2011-05-01 17:13:09 --> Config Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:13:09 --> URI Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Router Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Output Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Input Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:13:09 --> Language Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Loader Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Controller Class Initialized
ERROR - 2011-05-01 17:13:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 17:13:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 17:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:13:09 --> Model Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Model Class Initialized
DEBUG - 2011-05-01 17:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:13:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:13:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:13:09 --> Final output sent to browser
DEBUG - 2011-05-01 17:13:09 --> Total execution time: 0.0293
DEBUG - 2011-05-01 17:13:27 --> Config Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:13:27 --> URI Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Router Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Output Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Input Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:13:27 --> Language Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Loader Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Controller Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Model Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Model Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:13:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:13:27 --> Final output sent to browser
DEBUG - 2011-05-01 17:13:27 --> Total execution time: 0.6475
DEBUG - 2011-05-01 17:15:32 --> Config Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:15:32 --> URI Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Router Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Output Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Input Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:15:32 --> Language Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Loader Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Controller Class Initialized
ERROR - 2011-05-01 17:15:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 17:15:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 17:15:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:15:32 --> Model Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Model Class Initialized
DEBUG - 2011-05-01 17:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:15:32 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:15:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:15:32 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:15:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:15:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:15:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:15:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:15:32 --> Final output sent to browser
DEBUG - 2011-05-01 17:15:32 --> Total execution time: 0.0294
DEBUG - 2011-05-01 17:15:33 --> Config Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:15:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:15:33 --> URI Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Router Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Output Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Input Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:15:33 --> Language Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Loader Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Controller Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Model Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Model Class Initialized
DEBUG - 2011-05-01 17:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:15:33 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:15:34 --> Final output sent to browser
DEBUG - 2011-05-01 17:15:34 --> Total execution time: 1.0117
DEBUG - 2011-05-01 17:15:35 --> Config Class Initialized
DEBUG - 2011-05-01 17:15:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:15:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:15:35 --> URI Class Initialized
DEBUG - 2011-05-01 17:15:35 --> Router Class Initialized
ERROR - 2011-05-01 17:15:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:56:15 --> Config Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:56:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:56:15 --> URI Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Router Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Output Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Input Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:56:15 --> Language Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Loader Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Controller Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Model Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Model Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Model Class Initialized
DEBUG - 2011-05-01 17:56:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:56:15 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:56:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:56:15 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:56:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:56:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:56:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:56:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:56:15 --> Final output sent to browser
DEBUG - 2011-05-01 17:56:15 --> Total execution time: 0.6124
DEBUG - 2011-05-01 17:56:17 --> Config Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:56:17 --> URI Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Router Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Output Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Input Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:56:17 --> Language Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Loader Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Controller Class Initialized
ERROR - 2011-05-01 17:56:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 17:56:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 17:56:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:56:17 --> Model Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Model Class Initialized
DEBUG - 2011-05-01 17:56:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:56:17 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:56:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 17:56:17 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:56:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:56:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:56:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:56:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:56:17 --> Final output sent to browser
DEBUG - 2011-05-01 17:56:17 --> Total execution time: 0.1248
DEBUG - 2011-05-01 17:58:27 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:27 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Router Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Output Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Input Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:58:27 --> Language Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Loader Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Controller Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:58:27 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:58:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:58:27 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:58:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:58:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:58:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:58:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:58:27 --> Final output sent to browser
DEBUG - 2011-05-01 17:58:27 --> Total execution time: 0.0591
DEBUG - 2011-05-01 17:58:29 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:29 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:29 --> Router Class Initialized
ERROR - 2011-05-01 17:58:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:58:29 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:29 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:29 --> Router Class Initialized
ERROR - 2011-05-01 17:58:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:58:37 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:37 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Router Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Output Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Input Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:58:37 --> Language Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Loader Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Controller Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:58:37 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:58:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:58:37 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:58:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:58:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:58:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:58:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:58:37 --> Final output sent to browser
DEBUG - 2011-05-01 17:58:37 --> Total execution time: 0.2108
DEBUG - 2011-05-01 17:58:38 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:38 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:38 --> Router Class Initialized
ERROR - 2011-05-01 17:58:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-01 17:58:39 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:39 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Router Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Output Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Input Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:58:39 --> Language Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Loader Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Controller Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:58:39 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:39 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:58:39 --> Router Class Initialized
ERROR - 2011-05-01 17:58:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:58:39 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:58:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:58:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:58:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:58:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:58:39 --> Final output sent to browser
DEBUG - 2011-05-01 17:58:39 --> Total execution time: 0.0474
DEBUG - 2011-05-01 17:58:52 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:52 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Router Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Output Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Input Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:58:52 --> Language Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Loader Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Controller Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:58:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:58:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:58:53 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:58:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:58:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:58:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:58:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:58:53 --> Final output sent to browser
DEBUG - 2011-05-01 17:58:53 --> Total execution time: 0.3622
DEBUG - 2011-05-01 17:58:54 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:54 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Router Class Initialized
ERROR - 2011-05-01 17:58:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:58:54 --> Config Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:58:54 --> URI Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Router Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Output Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Input Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:58:54 --> Language Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Loader Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Controller Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Model Class Initialized
DEBUG - 2011-05-01 17:58:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:58:54 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:58:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:58:54 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:58:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:58:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:58:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:58:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:58:54 --> Final output sent to browser
DEBUG - 2011-05-01 17:58:54 --> Total execution time: 0.0514
DEBUG - 2011-05-01 17:59:12 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:12 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Router Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Output Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Input Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:59:12 --> Language Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Loader Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Controller Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:59:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:59:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:59:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:59:12 --> Final output sent to browser
DEBUG - 2011-05-01 17:59:12 --> Total execution time: 0.2225
DEBUG - 2011-05-01 17:59:12 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:12 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:12 --> Router Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Output Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Input Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:59:13 --> Language Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Loader Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Controller Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:59:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:59:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:59:13 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:59:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:59:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:59:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:59:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:59:13 --> Final output sent to browser
DEBUG - 2011-05-01 17:59:13 --> Total execution time: 0.0441
DEBUG - 2011-05-01 17:59:13 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:13 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:13 --> Router Class Initialized
ERROR - 2011-05-01 17:59:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:59:22 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:22 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Router Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Output Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Input Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:59:22 --> Language Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Loader Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Controller Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:59:22 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:59:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:59:22 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:59:22 --> Final output sent to browser
DEBUG - 2011-05-01 17:59:22 --> Total execution time: 0.3138
DEBUG - 2011-05-01 17:59:23 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:23 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Router Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Output Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Input Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:59:23 --> Language Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Loader Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Controller Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:59:23 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:59:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:59:23 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:59:23 --> Final output sent to browser
DEBUG - 2011-05-01 17:59:23 --> Total execution time: 0.0464
DEBUG - 2011-05-01 17:59:24 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:24 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:24 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:24 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:24 --> Router Class Initialized
ERROR - 2011-05-01 17:59:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:59:29 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:29 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Router Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Output Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Input Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:59:29 --> Language Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Loader Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Controller Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:59:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:59:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:59:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:59:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:59:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:59:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:59:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:59:29 --> Final output sent to browser
DEBUG - 2011-05-01 17:59:29 --> Total execution time: 0.3853
DEBUG - 2011-05-01 17:59:30 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:30 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Router Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Output Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Input Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:59:30 --> Language Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Loader Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Controller Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:59:30 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:59:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:59:30 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:59:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:59:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:59:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:59:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:59:30 --> Final output sent to browser
DEBUG - 2011-05-01 17:59:30 --> Total execution time: 0.0466
DEBUG - 2011-05-01 17:59:31 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:31 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:31 --> Router Class Initialized
ERROR - 2011-05-01 17:59:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 17:59:35 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:35 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Router Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Output Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Input Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:59:35 --> Language Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Loader Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Controller Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:59:35 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:59:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:59:36 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:59:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:59:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:59:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:59:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:59:36 --> Final output sent to browser
DEBUG - 2011-05-01 17:59:36 --> Total execution time: 0.2349
DEBUG - 2011-05-01 17:59:37 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:37 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Router Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Output Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Input Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 17:59:37 --> Language Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Loader Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Controller Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Model Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 17:59:37 --> Database Driver Class Initialized
DEBUG - 2011-05-01 17:59:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 17:59:37 --> Helper loaded: url_helper
DEBUG - 2011-05-01 17:59:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 17:59:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 17:59:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 17:59:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 17:59:37 --> Final output sent to browser
DEBUG - 2011-05-01 17:59:37 --> Total execution time: 0.0535
DEBUG - 2011-05-01 17:59:37 --> Config Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 17:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 17:59:37 --> URI Class Initialized
DEBUG - 2011-05-01 17:59:37 --> Router Class Initialized
ERROR - 2011-05-01 17:59:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:02:09 --> Config Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:02:09 --> URI Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Router Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Output Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Input Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:02:09 --> Language Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Loader Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Controller Class Initialized
ERROR - 2011-05-01 18:02:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:02:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:02:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:02:09 --> Model Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Model Class Initialized
DEBUG - 2011-05-01 18:02:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:02:09 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:02:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:02:09 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:02:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:02:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:02:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:02:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:02:09 --> Final output sent to browser
DEBUG - 2011-05-01 18:02:09 --> Total execution time: 0.0451
DEBUG - 2011-05-01 18:02:11 --> Config Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:02:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:02:11 --> URI Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Router Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Output Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Input Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:02:11 --> Language Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Loader Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Controller Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Model Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Model Class Initialized
DEBUG - 2011-05-01 18:02:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:02:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:02:12 --> Final output sent to browser
DEBUG - 2011-05-01 18:02:12 --> Total execution time: 0.8012
DEBUG - 2011-05-01 18:02:15 --> Config Class Initialized
DEBUG - 2011-05-01 18:02:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:02:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:02:15 --> URI Class Initialized
DEBUG - 2011-05-01 18:02:15 --> Router Class Initialized
ERROR - 2011-05-01 18:02:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:02:49 --> Config Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:02:49 --> URI Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Router Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Output Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Input Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:02:49 --> Language Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Loader Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Controller Class Initialized
ERROR - 2011-05-01 18:02:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:02:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:02:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:02:49 --> Model Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Model Class Initialized
DEBUG - 2011-05-01 18:02:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:02:49 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:02:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:02:49 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:02:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:02:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:02:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:02:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:02:49 --> Final output sent to browser
DEBUG - 2011-05-01 18:02:49 --> Total execution time: 0.0297
DEBUG - 2011-05-01 18:02:50 --> Config Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:02:50 --> URI Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Router Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Output Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Input Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:02:50 --> Language Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Loader Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Controller Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Model Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Model Class Initialized
DEBUG - 2011-05-01 18:02:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:02:50 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:02:51 --> Final output sent to browser
DEBUG - 2011-05-01 18:02:51 --> Total execution time: 0.6903
DEBUG - 2011-05-01 18:02:53 --> Config Class Initialized
DEBUG - 2011-05-01 18:02:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:02:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:02:53 --> URI Class Initialized
DEBUG - 2011-05-01 18:02:53 --> Router Class Initialized
ERROR - 2011-05-01 18:02:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:03:02 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:02 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:02 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Controller Class Initialized
ERROR - 2011-05-01 18:03:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:03:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:02 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:02 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:02 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:03:02 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:02 --> Total execution time: 0.0404
DEBUG - 2011-05-01 18:03:03 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:03 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:03 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Controller Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:03 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:03 --> Total execution time: 0.7815
DEBUG - 2011-05-01 18:03:04 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:04 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:04 --> Router Class Initialized
ERROR - 2011-05-01 18:03:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:03:13 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:13 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:13 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Controller Class Initialized
ERROR - 2011-05-01 18:03:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:03:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:13 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:13 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:03:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:03:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:03:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:03:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:03:13 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:13 --> Total execution time: 0.0301
DEBUG - 2011-05-01 18:03:14 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:14 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:14 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Controller Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:15 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:15 --> Total execution time: 0.5168
DEBUG - 2011-05-01 18:03:19 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:19 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:19 --> Router Class Initialized
ERROR - 2011-05-01 18:03:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:03:36 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:36 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:36 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Controller Class Initialized
ERROR - 2011-05-01 18:03:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:03:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:03:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:36 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:36 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:36 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:03:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:03:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:03:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:03:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:03:36 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:36 --> Total execution time: 0.1071
DEBUG - 2011-05-01 18:03:37 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:37 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:37 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Controller Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:37 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:37 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:37 --> Total execution time: 0.6599
DEBUG - 2011-05-01 18:03:43 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:43 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:43 --> Router Class Initialized
ERROR - 2011-05-01 18:03:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:03:44 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:44 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:44 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Controller Class Initialized
ERROR - 2011-05-01 18:03:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:03:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:03:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:44 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:44 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:44 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:03:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:03:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:03:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:03:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:03:44 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:44 --> Total execution time: 0.0818
DEBUG - 2011-05-01 18:03:45 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:45 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:45 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Controller Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:45 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:46 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:46 --> Total execution time: 0.6610
DEBUG - 2011-05-01 18:03:49 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:49 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:49 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:49 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:49 --> Router Class Initialized
ERROR - 2011-05-01 18:03:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:03:52 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:52 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:52 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Controller Class Initialized
ERROR - 2011-05-01 18:03:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:03:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:03:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:52 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:03:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:03:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:03:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:03:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:03:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:03:52 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:52 --> Total execution time: 0.0351
DEBUG - 2011-05-01 18:03:53 --> Config Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:03:53 --> URI Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Router Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Output Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Input Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:03:53 --> Language Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Loader Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Controller Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Model Class Initialized
DEBUG - 2011-05-01 18:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:03:53 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:03:54 --> Final output sent to browser
DEBUG - 2011-05-01 18:03:54 --> Total execution time: 0.8694
DEBUG - 2011-05-01 18:04:06 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:06 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:06 --> Router Class Initialized
ERROR - 2011-05-01 18:04:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:04:11 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:11 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:11 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Controller Class Initialized
ERROR - 2011-05-01 18:04:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:04:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:04:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:11 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:11 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:04:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:04:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:04:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:04:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:04:11 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:11 --> Total execution time: 0.0839
DEBUG - 2011-05-01 18:04:12 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:12 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:12 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Controller Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:12 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:12 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Controller Class Initialized
ERROR - 2011-05-01 18:04:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:04:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:04:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:12 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:04:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:04:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:04:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:04:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:04:12 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:12 --> Total execution time: 0.0437
DEBUG - 2011-05-01 18:04:13 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:13 --> Total execution time: 1.0393
DEBUG - 2011-05-01 18:04:36 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:36 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:36 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Controller Class Initialized
ERROR - 2011-05-01 18:04:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:04:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:36 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:36 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:36 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:04:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:04:36 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:04:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:04:36 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:36 --> Total execution time: 0.0921
DEBUG - 2011-05-01 18:04:36 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:36 --> Router Class Initialized
ERROR - 2011-05-01 18:04:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:04:37 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:37 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:37 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Controller Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:37 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:38 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:38 --> Total execution time: 0.6438
DEBUG - 2011-05-01 18:04:40 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:40 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:40 --> Router Class Initialized
ERROR - 2011-05-01 18:04:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:04:41 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:41 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:41 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Controller Class Initialized
ERROR - 2011-05-01 18:04:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:04:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:41 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:04:41 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:41 --> Total execution time: 0.0359
DEBUG - 2011-05-01 18:04:47 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:47 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:47 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Controller Class Initialized
ERROR - 2011-05-01 18:04:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:04:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:04:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:47 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:47 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:04:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:04:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:04:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:04:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:04:47 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:47 --> Total execution time: 0.0456
DEBUG - 2011-05-01 18:04:48 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:48 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:48 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Controller Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:48 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:49 --> Total execution time: 1.4178
DEBUG - 2011-05-01 18:04:49 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:49 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Router Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Output Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Input Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:04:49 --> Language Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Loader Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Controller Class Initialized
ERROR - 2011-05-01 18:04:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:04:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:04:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:49 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Model Class Initialized
DEBUG - 2011-05-01 18:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:04:49 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:04:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:04:49 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:04:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:04:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:04:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:04:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:04:49 --> Final output sent to browser
DEBUG - 2011-05-01 18:04:49 --> Total execution time: 0.0415
DEBUG - 2011-05-01 18:04:52 --> Config Class Initialized
DEBUG - 2011-05-01 18:04:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:04:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:04:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:04:52 --> URI Class Initialized
DEBUG - 2011-05-01 18:04:52 --> Router Class Initialized
ERROR - 2011-05-01 18:04:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:08:29 --> Config Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:08:29 --> URI Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Router Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Output Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Input Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:08:29 --> Language Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Loader Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Controller Class Initialized
ERROR - 2011-05-01 18:08:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:08:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:08:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:08:29 --> Model Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Model Class Initialized
DEBUG - 2011-05-01 18:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:08:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:08:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:08:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:08:29 --> Final output sent to browser
DEBUG - 2011-05-01 18:08:29 --> Total execution time: 0.0328
DEBUG - 2011-05-01 18:08:30 --> Config Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:08:30 --> URI Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Router Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Output Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Input Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:08:30 --> Language Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Loader Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Controller Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Model Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Model Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:08:30 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:08:30 --> Final output sent to browser
DEBUG - 2011-05-01 18:08:30 --> Total execution time: 0.5867
DEBUG - 2011-05-01 18:08:31 --> Config Class Initialized
DEBUG - 2011-05-01 18:08:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:08:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:08:31 --> URI Class Initialized
DEBUG - 2011-05-01 18:08:31 --> Router Class Initialized
ERROR - 2011-05-01 18:08:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:08:33 --> Config Class Initialized
DEBUG - 2011-05-01 18:08:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:08:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:08:33 --> URI Class Initialized
DEBUG - 2011-05-01 18:08:33 --> Router Class Initialized
ERROR - 2011-05-01 18:08:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:15:21 --> Config Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:15:21 --> URI Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Router Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Output Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Input Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:15:21 --> Language Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Loader Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Controller Class Initialized
ERROR - 2011-05-01 18:15:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:15:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:15:21 --> Model Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Model Class Initialized
DEBUG - 2011-05-01 18:15:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:15:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:15:22 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:15:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:15:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:15:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:15:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:15:22 --> Final output sent to browser
DEBUG - 2011-05-01 18:15:22 --> Total execution time: 0.2953
DEBUG - 2011-05-01 18:15:23 --> Config Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:15:23 --> URI Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Router Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Output Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Input Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:15:23 --> Language Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Loader Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Controller Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Model Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Model Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:15:23 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:15:23 --> Final output sent to browser
DEBUG - 2011-05-01 18:15:23 --> Total execution time: 0.6260
DEBUG - 2011-05-01 18:15:25 --> Config Class Initialized
DEBUG - 2011-05-01 18:15:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:15:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:15:25 --> URI Class Initialized
DEBUG - 2011-05-01 18:15:25 --> Router Class Initialized
ERROR - 2011-05-01 18:15:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:38:36 --> Config Class Initialized
DEBUG - 2011-05-01 18:38:36 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:38:36 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:38:36 --> URI Class Initialized
DEBUG - 2011-05-01 18:38:36 --> Router Class Initialized
DEBUG - 2011-05-01 18:38:36 --> No URI present. Default controller set.
DEBUG - 2011-05-01 18:38:36 --> Output Class Initialized
DEBUG - 2011-05-01 18:38:36 --> Input Class Initialized
DEBUG - 2011-05-01 18:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:38:36 --> Language Class Initialized
DEBUG - 2011-05-01 18:38:36 --> Loader Class Initialized
DEBUG - 2011-05-01 18:38:36 --> Controller Class Initialized
DEBUG - 2011-05-01 18:38:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 18:38:37 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:38:37 --> Final output sent to browser
DEBUG - 2011-05-01 18:38:37 --> Total execution time: 0.2335
DEBUG - 2011-05-01 18:38:39 --> Config Class Initialized
DEBUG - 2011-05-01 18:38:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:38:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:38:39 --> URI Class Initialized
DEBUG - 2011-05-01 18:38:39 --> Router Class Initialized
ERROR - 2011-05-01 18:38:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:38:51 --> Config Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:38:51 --> URI Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Router Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Output Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Input Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:38:51 --> Language Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Loader Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Controller Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Model Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Model Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Model Class Initialized
DEBUG - 2011-05-01 18:38:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:38:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:38:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:38:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:38:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:38:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:38:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:38:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:38:52 --> Final output sent to browser
DEBUG - 2011-05-01 18:38:52 --> Total execution time: 0.4355
DEBUG - 2011-05-01 18:38:53 --> Config Class Initialized
DEBUG - 2011-05-01 18:38:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:38:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:38:53 --> URI Class Initialized
DEBUG - 2011-05-01 18:38:53 --> Router Class Initialized
ERROR - 2011-05-01 18:38:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:39:04 --> Config Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:39:04 --> URI Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Router Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Output Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Input Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:39:04 --> Language Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Loader Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Controller Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:39:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:39:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:39:04 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:39:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:39:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:39:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:39:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:39:04 --> Final output sent to browser
DEBUG - 2011-05-01 18:39:04 --> Total execution time: 0.1989
DEBUG - 2011-05-01 18:39:06 --> Config Class Initialized
DEBUG - 2011-05-01 18:39:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:39:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:39:06 --> URI Class Initialized
DEBUG - 2011-05-01 18:39:06 --> Router Class Initialized
ERROR - 2011-05-01 18:39:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:39:33 --> Config Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:39:33 --> URI Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Router Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Output Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Input Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:39:33 --> Language Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Loader Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Controller Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:39:33 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:39:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:39:33 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:39:33 --> Final output sent to browser
DEBUG - 2011-05-01 18:39:33 --> Total execution time: 0.2385
DEBUG - 2011-05-01 18:39:35 --> Config Class Initialized
DEBUG - 2011-05-01 18:39:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:39:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:39:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:39:35 --> URI Class Initialized
DEBUG - 2011-05-01 18:39:35 --> Router Class Initialized
ERROR - 2011-05-01 18:39:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:39:49 --> Config Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:39:49 --> URI Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Router Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Output Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Input Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:39:49 --> Language Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Loader Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Controller Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Model Class Initialized
DEBUG - 2011-05-01 18:39:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:39:49 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:39:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:39:49 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:39:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:39:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:39:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:39:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:39:49 --> Final output sent to browser
DEBUG - 2011-05-01 18:39:49 --> Total execution time: 0.2074
DEBUG - 2011-05-01 18:39:50 --> Config Class Initialized
DEBUG - 2011-05-01 18:39:50 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:39:50 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:39:50 --> URI Class Initialized
DEBUG - 2011-05-01 18:39:50 --> Router Class Initialized
ERROR - 2011-05-01 18:39:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:40:11 --> Config Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:40:11 --> URI Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Router Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Output Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Input Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:40:11 --> Language Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Loader Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Controller Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:40:11 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:40:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:40:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:40:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:40:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:40:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:40:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:40:12 --> Final output sent to browser
DEBUG - 2011-05-01 18:40:12 --> Total execution time: 0.2008
DEBUG - 2011-05-01 18:40:13 --> Config Class Initialized
DEBUG - 2011-05-01 18:40:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:40:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:40:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:40:13 --> URI Class Initialized
DEBUG - 2011-05-01 18:40:13 --> Router Class Initialized
ERROR - 2011-05-01 18:40:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:40:45 --> Config Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:40:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:40:45 --> URI Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Router Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Output Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Input Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:40:45 --> Language Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Loader Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Controller Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:40:45 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:40:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:40:45 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:40:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:40:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:40:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:40:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:40:45 --> Final output sent to browser
DEBUG - 2011-05-01 18:40:45 --> Total execution time: 0.2377
DEBUG - 2011-05-01 18:40:47 --> Config Class Initialized
DEBUG - 2011-05-01 18:40:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:40:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:40:47 --> URI Class Initialized
DEBUG - 2011-05-01 18:40:47 --> Router Class Initialized
ERROR - 2011-05-01 18:40:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:40:56 --> Config Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:40:56 --> URI Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Router Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Output Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Input Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:40:56 --> Language Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Loader Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Controller Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Model Class Initialized
DEBUG - 2011-05-01 18:40:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:40:56 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:40:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:40:56 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:40:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:40:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:40:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:40:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:40:56 --> Final output sent to browser
DEBUG - 2011-05-01 18:40:56 --> Total execution time: 0.0684
DEBUG - 2011-05-01 18:40:58 --> Config Class Initialized
DEBUG - 2011-05-01 18:40:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:40:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:40:58 --> URI Class Initialized
DEBUG - 2011-05-01 18:40:58 --> Router Class Initialized
ERROR - 2011-05-01 18:40:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:41:18 --> Config Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:41:18 --> URI Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Router Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Output Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Input Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:41:18 --> Language Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Loader Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Controller Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Model Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Model Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Model Class Initialized
DEBUG - 2011-05-01 18:41:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:41:18 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:41:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:41:18 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:41:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:41:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:41:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:41:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:41:18 --> Final output sent to browser
DEBUG - 2011-05-01 18:41:18 --> Total execution time: 0.2331
DEBUG - 2011-05-01 18:41:20 --> Config Class Initialized
DEBUG - 2011-05-01 18:41:20 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:41:20 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:41:20 --> URI Class Initialized
DEBUG - 2011-05-01 18:41:20 --> Router Class Initialized
ERROR - 2011-05-01 18:41:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:41:32 --> Config Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:41:32 --> URI Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Router Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Output Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Input Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:41:32 --> Language Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Loader Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Controller Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Model Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Model Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Model Class Initialized
DEBUG - 2011-05-01 18:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:41:32 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:41:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:41:32 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:41:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:41:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:41:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:41:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:41:32 --> Final output sent to browser
DEBUG - 2011-05-01 18:41:32 --> Total execution time: 0.0492
DEBUG - 2011-05-01 18:41:34 --> Config Class Initialized
DEBUG - 2011-05-01 18:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:41:34 --> URI Class Initialized
DEBUG - 2011-05-01 18:41:34 --> Router Class Initialized
ERROR - 2011-05-01 18:41:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:57:37 --> Config Class Initialized
DEBUG - 2011-05-01 18:57:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:57:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:57:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:57:37 --> URI Class Initialized
DEBUG - 2011-05-01 18:57:37 --> Router Class Initialized
DEBUG - 2011-05-01 18:57:37 --> No URI present. Default controller set.
DEBUG - 2011-05-01 18:57:37 --> Output Class Initialized
DEBUG - 2011-05-01 18:57:37 --> Input Class Initialized
DEBUG - 2011-05-01 18:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:57:37 --> Language Class Initialized
DEBUG - 2011-05-01 18:57:37 --> Loader Class Initialized
DEBUG - 2011-05-01 18:57:37 --> Controller Class Initialized
DEBUG - 2011-05-01 18:57:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-01 18:57:37 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:57:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:57:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:57:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:57:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:57:37 --> Final output sent to browser
DEBUG - 2011-05-01 18:57:37 --> Total execution time: 0.0899
DEBUG - 2011-05-01 18:57:38 --> Config Class Initialized
DEBUG - 2011-05-01 18:57:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:57:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:57:38 --> URI Class Initialized
DEBUG - 2011-05-01 18:57:38 --> Router Class Initialized
ERROR - 2011-05-01 18:57:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:57:38 --> Config Class Initialized
DEBUG - 2011-05-01 18:57:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:57:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:57:38 --> URI Class Initialized
DEBUG - 2011-05-01 18:57:38 --> Router Class Initialized
ERROR - 2011-05-01 18:57:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:57:42 --> Config Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:57:42 --> URI Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Router Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Output Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Input Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:57:42 --> Language Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Loader Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Controller Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Model Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Model Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Model Class Initialized
DEBUG - 2011-05-01 18:57:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:57:42 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:57:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:57:42 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:57:42 --> Final output sent to browser
DEBUG - 2011-05-01 18:57:42 --> Total execution time: 0.2226
DEBUG - 2011-05-01 18:57:43 --> Config Class Initialized
DEBUG - 2011-05-01 18:57:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:57:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:57:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:57:43 --> URI Class Initialized
DEBUG - 2011-05-01 18:57:43 --> Router Class Initialized
ERROR - 2011-05-01 18:57:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:57:59 --> Config Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:57:59 --> URI Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Router Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Output Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Input Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:57:59 --> Language Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Loader Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Controller Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Model Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Model Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Model Class Initialized
DEBUG - 2011-05-01 18:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:57:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:57:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 18:57:59 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:57:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:57:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:57:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:57:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:57:59 --> Final output sent to browser
DEBUG - 2011-05-01 18:57:59 --> Total execution time: 0.2219
DEBUG - 2011-05-01 18:58:00 --> Config Class Initialized
DEBUG - 2011-05-01 18:58:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:58:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:58:00 --> URI Class Initialized
DEBUG - 2011-05-01 18:58:00 --> Router Class Initialized
ERROR - 2011-05-01 18:58:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 18:58:01 --> Config Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:58:01 --> URI Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Router Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Output Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Input Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:58:01 --> Language Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Loader Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Controller Class Initialized
ERROR - 2011-05-01 18:58:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 18:58:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 18:58:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:58:01 --> Model Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Model Class Initialized
DEBUG - 2011-05-01 18:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:58:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:58:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 18:58:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 18:58:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 18:58:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 18:58:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 18:58:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 18:58:01 --> Final output sent to browser
DEBUG - 2011-05-01 18:58:01 --> Total execution time: 0.0998
DEBUG - 2011-05-01 18:58:03 --> Config Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Hooks Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Utf8 Class Initialized
DEBUG - 2011-05-01 18:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 18:58:03 --> URI Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Router Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Output Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Input Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 18:58:03 --> Language Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Loader Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Controller Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Model Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Model Class Initialized
DEBUG - 2011-05-01 18:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 18:58:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 18:58:04 --> Final output sent to browser
DEBUG - 2011-05-01 18:58:04 --> Total execution time: 0.6726
DEBUG - 2011-05-01 19:02:04 --> Config Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:02:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:02:04 --> URI Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Router Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Output Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Input Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:02:04 --> Language Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Loader Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Controller Class Initialized
ERROR - 2011-05-01 19:02:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 19:02:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 19:02:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 19:02:04 --> Model Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Model Class Initialized
DEBUG - 2011-05-01 19:02:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:02:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:02:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 19:02:04 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:02:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:02:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:02:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:02:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:02:04 --> Final output sent to browser
DEBUG - 2011-05-01 19:02:04 --> Total execution time: 0.0356
DEBUG - 2011-05-01 19:02:05 --> Config Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:02:05 --> URI Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Router Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Output Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Input Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:02:05 --> Language Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Loader Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Controller Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Model Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Model Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:02:05 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:02:05 --> Final output sent to browser
DEBUG - 2011-05-01 19:02:05 --> Total execution time: 0.6416
DEBUG - 2011-05-01 19:02:07 --> Config Class Initialized
DEBUG - 2011-05-01 19:02:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:02:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:02:07 --> URI Class Initialized
DEBUG - 2011-05-01 19:02:07 --> Router Class Initialized
ERROR - 2011-05-01 19:02:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:02:07 --> Config Class Initialized
DEBUG - 2011-05-01 19:02:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:02:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:02:07 --> URI Class Initialized
DEBUG - 2011-05-01 19:02:07 --> Router Class Initialized
ERROR - 2011-05-01 19:02:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:12:16 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:16 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Router Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Output Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Input Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:12:16 --> Language Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Loader Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Controller Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:12:16 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:12:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:12:16 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:12:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:12:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:12:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:12:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:12:16 --> Final output sent to browser
DEBUG - 2011-05-01 19:12:16 --> Total execution time: 0.0764
DEBUG - 2011-05-01 19:12:18 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:18 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:18 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:18 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:18 --> Router Class Initialized
ERROR - 2011-05-01 19:12:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:12:28 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:28 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:28 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:28 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:28 --> Router Class Initialized
DEBUG - 2011-05-01 19:12:28 --> Output Class Initialized
DEBUG - 2011-05-01 19:12:28 --> Input Class Initialized
DEBUG - 2011-05-01 19:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:12:28 --> Language Class Initialized
DEBUG - 2011-05-01 19:12:28 --> Loader Class Initialized
DEBUG - 2011-05-01 19:12:28 --> Controller Class Initialized
DEBUG - 2011-05-01 19:12:29 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:29 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:29 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:12:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:12:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:12:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:12:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:12:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:12:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:12:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:12:29 --> Final output sent to browser
DEBUG - 2011-05-01 19:12:29 --> Total execution time: 0.4775
DEBUG - 2011-05-01 19:12:30 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:30 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Router Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Output Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Input Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:12:30 --> Language Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Loader Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Controller Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:12:30 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:12:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:12:30 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:12:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:12:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:12:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:12:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:12:30 --> Final output sent to browser
DEBUG - 2011-05-01 19:12:30 --> Total execution time: 0.0516
DEBUG - 2011-05-01 19:12:31 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:31 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:31 --> Router Class Initialized
ERROR - 2011-05-01 19:12:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:12:56 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:56 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Router Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Output Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Input Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:12:56 --> Language Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Loader Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Controller Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:12:56 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:12:57 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:12:57 --> Final output sent to browser
DEBUG - 2011-05-01 19:12:57 --> Total execution time: 0.4190
DEBUG - 2011-05-01 19:12:57 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:57 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Router Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Output Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Input Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:12:57 --> Language Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Loader Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Controller Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:12:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:12:57 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:12:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:12:57 --> Final output sent to browser
DEBUG - 2011-05-01 19:12:57 --> Total execution time: 0.0527
DEBUG - 2011-05-01 19:12:58 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:58 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Router Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Output Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Input Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:12:58 --> Language Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Loader Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Controller Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Model Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:12:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:12:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:12:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:12:58 --> Final output sent to browser
DEBUG - 2011-05-01 19:12:58 --> Total execution time: 0.0525
DEBUG - 2011-05-01 19:12:58 --> Config Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:12:58 --> URI Class Initialized
DEBUG - 2011-05-01 19:12:58 --> Router Class Initialized
ERROR - 2011-05-01 19:12:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:13:20 --> Config Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:13:20 --> URI Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Router Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Output Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Input Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:13:20 --> Language Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Loader Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Controller Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:13:20 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:13:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:13:20 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:13:20 --> Final output sent to browser
DEBUG - 2011-05-01 19:13:20 --> Total execution time: 0.3245
DEBUG - 2011-05-01 19:13:21 --> Config Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:13:21 --> URI Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Router Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Output Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Input Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:13:21 --> Language Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Loader Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Controller Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:13:21 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:13:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:13:21 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:13:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:13:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:13:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:13:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:13:21 --> Final output sent to browser
DEBUG - 2011-05-01 19:13:21 --> Total execution time: 0.0850
DEBUG - 2011-05-01 19:13:21 --> Config Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:13:21 --> URI Class Initialized
DEBUG - 2011-05-01 19:13:21 --> Router Class Initialized
ERROR - 2011-05-01 19:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:13:38 --> Config Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:13:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:13:38 --> URI Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Router Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Output Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Input Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:13:38 --> Language Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Loader Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Controller Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:13:38 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:13:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:13:38 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:13:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:13:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:13:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:13:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:13:38 --> Final output sent to browser
DEBUG - 2011-05-01 19:13:38 --> Total execution time: 0.2472
DEBUG - 2011-05-01 19:13:39 --> Config Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:13:39 --> URI Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Router Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Output Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Input Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:13:39 --> Language Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Loader Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Controller Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:13:39 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:13:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:13:39 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:13:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:13:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:13:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:13:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:13:39 --> Final output sent to browser
DEBUG - 2011-05-01 19:13:39 --> Total execution time: 0.0725
DEBUG - 2011-05-01 19:13:41 --> Config Class Initialized
DEBUG - 2011-05-01 19:13:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:13:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:13:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:13:41 --> URI Class Initialized
DEBUG - 2011-05-01 19:13:41 --> Router Class Initialized
ERROR - 2011-05-01 19:13:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:13:59 --> Config Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:13:59 --> URI Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Router Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Output Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Input Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:13:59 --> Language Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Loader Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Controller Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Model Class Initialized
DEBUG - 2011-05-01 19:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:13:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:14:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:14:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:14:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:14:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:14:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:14:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:14:00 --> Final output sent to browser
DEBUG - 2011-05-01 19:14:00 --> Total execution time: 0.5224
DEBUG - 2011-05-01 19:14:01 --> Config Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:14:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:14:01 --> URI Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Router Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Output Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Input Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:14:01 --> Language Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Loader Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Controller Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:14:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:14:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:14:01 --> Final output sent to browser
DEBUG - 2011-05-01 19:14:01 --> Total execution time: 0.1287
DEBUG - 2011-05-01 19:14:01 --> Config Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:14:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:14:01 --> URI Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Router Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Output Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Input Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:14:01 --> Language Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Loader Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Controller Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:14:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:14:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:14:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:14:01 --> Final output sent to browser
DEBUG - 2011-05-01 19:14:01 --> Total execution time: 0.1675
DEBUG - 2011-05-01 19:14:02 --> Config Class Initialized
DEBUG - 2011-05-01 19:14:02 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:14:02 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:14:02 --> URI Class Initialized
DEBUG - 2011-05-01 19:14:02 --> Router Class Initialized
ERROR - 2011-05-01 19:14:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:14:31 --> Config Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:14:31 --> URI Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Router Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Output Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Input Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:14:31 --> Language Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Loader Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Controller Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:14:31 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:14:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:14:31 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:14:31 --> Final output sent to browser
DEBUG - 2011-05-01 19:14:31 --> Total execution time: 0.2490
DEBUG - 2011-05-01 19:14:32 --> Config Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:14:32 --> URI Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Router Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Output Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Input Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:14:32 --> Language Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Loader Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Controller Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Model Class Initialized
DEBUG - 2011-05-01 19:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:14:32 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:14:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:14:32 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:14:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:14:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:14:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:14:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:14:32 --> Final output sent to browser
DEBUG - 2011-05-01 19:14:32 --> Total execution time: 0.0484
DEBUG - 2011-05-01 19:14:33 --> Config Class Initialized
DEBUG - 2011-05-01 19:14:33 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:14:33 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:14:33 --> URI Class Initialized
DEBUG - 2011-05-01 19:14:33 --> Router Class Initialized
ERROR - 2011-05-01 19:14:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:31:42 --> Config Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:31:42 --> URI Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Router Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Output Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Input Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:31:42 --> Language Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Loader Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Controller Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Model Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Model Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Model Class Initialized
DEBUG - 2011-05-01 19:31:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:31:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:31:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:31:43 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:31:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:31:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:31:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:31:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:31:43 --> Final output sent to browser
DEBUG - 2011-05-01 19:31:43 --> Total execution time: 0.9666
DEBUG - 2011-05-01 19:34:26 --> Config Class Initialized
DEBUG - 2011-05-01 19:34:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:34:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:34:26 --> URI Class Initialized
DEBUG - 2011-05-01 19:34:26 --> Router Class Initialized
ERROR - 2011-05-01 19:34:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-01 19:39:31 --> Config Class Initialized
DEBUG - 2011-05-01 19:39:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:39:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:39:31 --> URI Class Initialized
DEBUG - 2011-05-01 19:39:31 --> Router Class Initialized
ERROR - 2011-05-01 19:39:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-01 19:39:32 --> Config Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:39:32 --> URI Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Router Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Output Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Input Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:39:32 --> Language Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Loader Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Controller Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Model Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Model Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Model Class Initialized
DEBUG - 2011-05-01 19:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:39:32 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:39:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:39:32 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:39:32 --> Final output sent to browser
DEBUG - 2011-05-01 19:39:32 --> Total execution time: 0.1624
DEBUG - 2011-05-01 19:40:50 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:50 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Router Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Output Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Input Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:40:50 --> Language Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:50 --> Loader Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Controller Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Model Class Initialized
DEBUG - 2011-05-01 19:40:50 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Model Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Router Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Model Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:40:50 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Output Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Input Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:40:50 --> Language Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Loader Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Controller Class Initialized
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:40:50 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:40:50 --> Final output sent to browser
DEBUG - 2011-05-01 19:40:50 --> Total execution time: 0.1337
ERROR - 2011-05-01 19:40:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 19:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 19:40:50 --> Model Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Model Class Initialized
DEBUG - 2011-05-01 19:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:40:50 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 19:40:50 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:40:50 --> Final output sent to browser
DEBUG - 2011-05-01 19:40:50 --> Total execution time: 0.1906
DEBUG - 2011-05-01 19:40:52 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:52 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Router Class Initialized
ERROR - 2011-05-01 19:40:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:40:52 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:52 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Router Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Output Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Input Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:40:52 --> Language Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Loader Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Controller Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Model Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Model Class Initialized
DEBUG - 2011-05-01 19:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:40:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:40:53 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:53 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:53 --> Router Class Initialized
ERROR - 2011-05-01 19:40:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:40:53 --> Final output sent to browser
DEBUG - 2011-05-01 19:40:53 --> Total execution time: 0.7406
DEBUG - 2011-05-01 19:40:53 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:53 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:53 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:53 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:53 --> Router Class Initialized
ERROR - 2011-05-01 19:40:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:40:54 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:54 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:54 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:54 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:54 --> Router Class Initialized
ERROR - 2011-05-01 19:40:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:40:55 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:55 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:55 --> Router Class Initialized
ERROR - 2011-05-01 19:40:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:40:55 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:55 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:55 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:55 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:55 --> Router Class Initialized
ERROR - 2011-05-01 19:40:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:40:56 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:56 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:56 --> Router Class Initialized
ERROR - 2011-05-01 19:40:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:40:56 --> Config Class Initialized
DEBUG - 2011-05-01 19:40:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:40:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:40:56 --> URI Class Initialized
DEBUG - 2011-05-01 19:40:56 --> Router Class Initialized
ERROR - 2011-05-01 19:40:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:41:06 --> Config Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:41:06 --> URI Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Router Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Output Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Input Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:41:06 --> Language Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Loader Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Controller Class Initialized
ERROR - 2011-05-01 19:41:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 19:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 19:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 19:41:06 --> Model Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Model Class Initialized
DEBUG - 2011-05-01 19:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:41:06 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 19:41:06 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:41:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:41:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:41:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:41:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:41:06 --> Final output sent to browser
DEBUG - 2011-05-01 19:41:06 --> Total execution time: 0.0918
DEBUG - 2011-05-01 19:41:07 --> Config Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:41:07 --> URI Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Router Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Output Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Input Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:41:07 --> Language Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Loader Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Controller Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Model Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Model Class Initialized
DEBUG - 2011-05-01 19:41:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:41:07 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:41:08 --> Final output sent to browser
DEBUG - 2011-05-01 19:41:08 --> Total execution time: 0.7585
DEBUG - 2011-05-01 19:41:10 --> Config Class Initialized
DEBUG - 2011-05-01 19:41:10 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:41:10 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:41:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:41:10 --> URI Class Initialized
DEBUG - 2011-05-01 19:41:10 --> Router Class Initialized
ERROR - 2011-05-01 19:41:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:41:29 --> Config Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:41:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:41:29 --> URI Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Router Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Output Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Input Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:41:29 --> Language Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Loader Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Controller Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Model Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Model Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Model Class Initialized
DEBUG - 2011-05-01 19:41:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:41:29 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:41:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:41:29 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:41:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:41:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:41:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:41:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:41:29 --> Final output sent to browser
DEBUG - 2011-05-01 19:41:29 --> Total execution time: 0.2279
DEBUG - 2011-05-01 19:41:32 --> Config Class Initialized
DEBUG - 2011-05-01 19:41:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:41:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:41:32 --> URI Class Initialized
DEBUG - 2011-05-01 19:41:32 --> Router Class Initialized
ERROR - 2011-05-01 19:41:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 19:42:01 --> Config Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 19:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 19:42:01 --> URI Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Router Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Output Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Input Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 19:42:01 --> Language Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Loader Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Controller Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Model Class Initialized
DEBUG - 2011-05-01 19:42:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 19:42:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 19:42:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 19:42:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 19:42:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 19:42:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 19:42:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 19:42:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 19:42:01 --> Final output sent to browser
DEBUG - 2011-05-01 19:42:01 --> Total execution time: 0.1166
DEBUG - 2011-05-01 20:19:52 --> Config Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:19:52 --> URI Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Router Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Output Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Input Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:19:52 --> Language Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Loader Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Controller Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Model Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Model Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Model Class Initialized
DEBUG - 2011-05-01 20:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:19:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:19:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 20:19:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:19:52 --> Final output sent to browser
DEBUG - 2011-05-01 20:19:52 --> Total execution time: 0.5898
DEBUG - 2011-05-01 20:20:32 --> Config Class Initialized
DEBUG - 2011-05-01 20:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:20:32 --> URI Class Initialized
DEBUG - 2011-05-01 20:20:32 --> Router Class Initialized
ERROR - 2011-05-01 20:20:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 20:20:35 --> Config Class Initialized
DEBUG - 2011-05-01 20:20:35 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:20:35 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:20:35 --> URI Class Initialized
DEBUG - 2011-05-01 20:20:35 --> Router Class Initialized
ERROR - 2011-05-01 20:20:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 20:20:44 --> Config Class Initialized
DEBUG - 2011-05-01 20:20:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:20:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:20:44 --> URI Class Initialized
DEBUG - 2011-05-01 20:20:44 --> Router Class Initialized
ERROR - 2011-05-01 20:20:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 20:21:06 --> Config Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:21:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:21:06 --> URI Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Router Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Output Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Input Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:21:06 --> Language Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Loader Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Controller Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Model Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Model Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Model Class Initialized
DEBUG - 2011-05-01 20:21:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:21:06 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:21:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 20:21:06 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:21:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:21:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:21:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:21:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:21:06 --> Final output sent to browser
DEBUG - 2011-05-01 20:21:06 --> Total execution time: 0.2708
DEBUG - 2011-05-01 20:24:59 --> Config Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:24:59 --> URI Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Router Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Output Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Input Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:24:59 --> Language Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Loader Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Controller Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Model Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Model Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Model Class Initialized
DEBUG - 2011-05-01 20:24:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:24:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:24:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 20:24:59 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:24:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:24:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:24:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:24:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:24:59 --> Final output sent to browser
DEBUG - 2011-05-01 20:24:59 --> Total execution time: 0.0730
DEBUG - 2011-05-01 20:31:59 --> Config Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:31:59 --> URI Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Router Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Output Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Input Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:31:59 --> Language Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Loader Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Controller Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Model Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Model Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Model Class Initialized
DEBUG - 2011-05-01 20:31:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:31:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:31:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 20:31:59 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:31:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:31:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:31:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:31:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:31:59 --> Final output sent to browser
DEBUG - 2011-05-01 20:31:59 --> Total execution time: 0.1677
DEBUG - 2011-05-01 20:32:00 --> Config Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:32:00 --> URI Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Router Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Output Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Input Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:32:00 --> Language Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Loader Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Controller Class Initialized
ERROR - 2011-05-01 20:32:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 20:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 20:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 20:32:00 --> Model Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Model Class Initialized
DEBUG - 2011-05-01 20:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:32:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 20:32:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:32:00 --> Final output sent to browser
DEBUG - 2011-05-01 20:32:00 --> Total execution time: 0.3164
DEBUG - 2011-05-01 20:52:43 --> Config Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:52:43 --> URI Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Router Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Output Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Input Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:52:43 --> Language Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Loader Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Controller Class Initialized
ERROR - 2011-05-01 20:52:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 20:52:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 20:52:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 20:52:43 --> Model Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Model Class Initialized
DEBUG - 2011-05-01 20:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:52:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:52:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 20:52:43 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:52:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:52:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:52:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:52:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:52:43 --> Final output sent to browser
DEBUG - 2011-05-01 20:52:43 --> Total execution time: 0.2860
DEBUG - 2011-05-01 20:52:44 --> Config Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:52:44 --> URI Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Router Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Output Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Input Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:52:44 --> Language Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Loader Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Controller Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Model Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Model Class Initialized
DEBUG - 2011-05-01 20:52:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:52:44 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:52:45 --> Final output sent to browser
DEBUG - 2011-05-01 20:52:45 --> Total execution time: 0.8279
DEBUG - 2011-05-01 20:52:46 --> Config Class Initialized
DEBUG - 2011-05-01 20:52:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:52:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:52:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:52:46 --> URI Class Initialized
DEBUG - 2011-05-01 20:52:46 --> Router Class Initialized
ERROR - 2011-05-01 20:52:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 20:53:00 --> Config Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:53:00 --> URI Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Router Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Output Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Input Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:53:00 --> Language Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Loader Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Controller Class Initialized
ERROR - 2011-05-01 20:53:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 20:53:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 20:53:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 20:53:00 --> Model Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Model Class Initialized
DEBUG - 2011-05-01 20:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:53:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:53:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 20:53:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:53:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:53:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:53:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:53:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:53:00 --> Final output sent to browser
DEBUG - 2011-05-01 20:53:00 --> Total execution time: 0.0283
DEBUG - 2011-05-01 20:53:01 --> Config Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:53:01 --> URI Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Router Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Output Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Input Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:53:01 --> Language Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Loader Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Controller Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Model Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Model Class Initialized
DEBUG - 2011-05-01 20:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:53:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:53:02 --> Final output sent to browser
DEBUG - 2011-05-01 20:53:02 --> Total execution time: 0.6898
DEBUG - 2011-05-01 20:53:02 --> Config Class Initialized
DEBUG - 2011-05-01 20:53:02 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:53:02 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:53:02 --> URI Class Initialized
DEBUG - 2011-05-01 20:53:02 --> Router Class Initialized
ERROR - 2011-05-01 20:53:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 20:53:14 --> Config Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:53:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:53:14 --> URI Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Router Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Output Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Input Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:53:14 --> Language Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Loader Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Controller Class Initialized
ERROR - 2011-05-01 20:53:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 20:53:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 20:53:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 20:53:14 --> Model Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Model Class Initialized
DEBUG - 2011-05-01 20:53:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:53:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:53:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 20:53:14 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:53:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:53:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:53:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:53:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:53:14 --> Final output sent to browser
DEBUG - 2011-05-01 20:53:14 --> Total execution time: 0.0356
DEBUG - 2011-05-01 20:53:15 --> Config Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:53:15 --> URI Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Router Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Output Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Input Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:53:15 --> Language Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Loader Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Controller Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Model Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Model Class Initialized
DEBUG - 2011-05-01 20:53:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:53:15 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:53:16 --> Final output sent to browser
DEBUG - 2011-05-01 20:53:16 --> Total execution time: 0.7029
DEBUG - 2011-05-01 20:53:16 --> Config Class Initialized
DEBUG - 2011-05-01 20:53:16 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:53:16 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:53:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:53:16 --> URI Class Initialized
DEBUG - 2011-05-01 20:53:16 --> Router Class Initialized
ERROR - 2011-05-01 20:53:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 20:57:41 --> Config Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:57:41 --> URI Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Router Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Output Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Input Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 20:57:41 --> Language Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Loader Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Controller Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Model Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Model Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Model Class Initialized
DEBUG - 2011-05-01 20:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 20:57:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 20:57:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 20:57:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 20:57:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 20:57:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 20:57:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 20:57:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 20:57:41 --> Final output sent to browser
DEBUG - 2011-05-01 20:57:41 --> Total execution time: 0.2593
DEBUG - 2011-05-01 20:57:44 --> Config Class Initialized
DEBUG - 2011-05-01 20:57:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:57:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:57:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:57:44 --> URI Class Initialized
DEBUG - 2011-05-01 20:57:44 --> Router Class Initialized
ERROR - 2011-05-01 20:57:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 20:57:45 --> Config Class Initialized
DEBUG - 2011-05-01 20:57:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 20:57:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 20:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 20:57:46 --> URI Class Initialized
DEBUG - 2011-05-01 20:57:46 --> Router Class Initialized
ERROR - 2011-05-01 20:57:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 21:17:50 --> Config Class Initialized
DEBUG - 2011-05-01 21:17:50 --> Hooks Class Initialized
DEBUG - 2011-05-01 21:17:50 --> Utf8 Class Initialized
DEBUG - 2011-05-01 21:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 21:17:50 --> URI Class Initialized
DEBUG - 2011-05-01 21:17:50 --> Router Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Output Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Input Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 21:17:51 --> Language Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Loader Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Controller Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Model Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Model Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Model Class Initialized
DEBUG - 2011-05-01 21:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 21:17:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 21:17:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 21:17:51 --> Helper loaded: url_helper
DEBUG - 2011-05-01 21:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 21:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 21:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 21:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 21:17:51 --> Final output sent to browser
DEBUG - 2011-05-01 21:17:51 --> Total execution time: 0.3483
DEBUG - 2011-05-01 21:53:02 --> Config Class Initialized
DEBUG - 2011-05-01 21:53:02 --> Hooks Class Initialized
DEBUG - 2011-05-01 21:53:02 --> Utf8 Class Initialized
DEBUG - 2011-05-01 21:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 21:53:02 --> URI Class Initialized
DEBUG - 2011-05-01 21:53:02 --> Router Class Initialized
DEBUG - 2011-05-01 21:53:02 --> Output Class Initialized
DEBUG - 2011-05-01 21:53:02 --> Input Class Initialized
DEBUG - 2011-05-01 21:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 21:53:02 --> Language Class Initialized
DEBUG - 2011-05-01 21:53:02 --> Loader Class Initialized
DEBUG - 2011-05-01 21:53:02 --> Controller Class Initialized
ERROR - 2011-05-01 21:53:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 21:53:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 21:53:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 21:53:03 --> Model Class Initialized
DEBUG - 2011-05-01 21:53:03 --> Model Class Initialized
DEBUG - 2011-05-01 21:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 21:53:03 --> Database Driver Class Initialized
DEBUG - 2011-05-01 21:53:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 21:53:03 --> Helper loaded: url_helper
DEBUG - 2011-05-01 21:53:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 21:53:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 21:53:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 21:53:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 21:53:03 --> Final output sent to browser
DEBUG - 2011-05-01 21:53:03 --> Total execution time: 0.6314
DEBUG - 2011-05-01 21:53:04 --> Config Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Hooks Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Utf8 Class Initialized
DEBUG - 2011-05-01 21:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 21:53:04 --> URI Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Router Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Output Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Input Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 21:53:04 --> Language Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Loader Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Controller Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Model Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Model Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 21:53:04 --> Database Driver Class Initialized
DEBUG - 2011-05-01 21:53:04 --> Final output sent to browser
DEBUG - 2011-05-01 21:53:04 --> Total execution time: 0.7054
DEBUG - 2011-05-01 21:53:05 --> Config Class Initialized
DEBUG - 2011-05-01 21:53:05 --> Hooks Class Initialized
DEBUG - 2011-05-01 21:53:05 --> Utf8 Class Initialized
DEBUG - 2011-05-01 21:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 21:53:05 --> URI Class Initialized
DEBUG - 2011-05-01 21:53:05 --> Router Class Initialized
ERROR - 2011-05-01 21:53:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 22:16:41 --> Config Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:16:41 --> URI Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Router Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Output Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Input Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 22:16:41 --> Language Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Loader Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Controller Class Initialized
ERROR - 2011-05-01 22:16:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 22:16:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 22:16:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 22:16:41 --> Model Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Model Class Initialized
DEBUG - 2011-05-01 22:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 22:16:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 22:16:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 22:16:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 22:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 22:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 22:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 22:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 22:16:41 --> Final output sent to browser
DEBUG - 2011-05-01 22:16:41 --> Total execution time: 0.5638
DEBUG - 2011-05-01 22:16:43 --> Config Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:16:43 --> URI Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Router Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Output Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Input Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 22:16:43 --> Language Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Loader Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Controller Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Model Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Model Class Initialized
DEBUG - 2011-05-01 22:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 22:16:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 22:16:44 --> Final output sent to browser
DEBUG - 2011-05-01 22:16:44 --> Total execution time: 1.1014
DEBUG - 2011-05-01 22:16:46 --> Config Class Initialized
DEBUG - 2011-05-01 22:16:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:16:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:16:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:16:46 --> URI Class Initialized
DEBUG - 2011-05-01 22:16:46 --> Router Class Initialized
ERROR - 2011-05-01 22:16:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 22:17:14 --> Config Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:17:14 --> URI Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Router Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Output Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Input Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 22:17:14 --> Language Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Loader Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Controller Class Initialized
ERROR - 2011-05-01 22:17:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 22:17:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 22:17:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 22:17:14 --> Model Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Model Class Initialized
DEBUG - 2011-05-01 22:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 22:17:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 22:17:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 22:17:14 --> Helper loaded: url_helper
DEBUG - 2011-05-01 22:17:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 22:17:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 22:17:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 22:17:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 22:17:14 --> Final output sent to browser
DEBUG - 2011-05-01 22:17:14 --> Total execution time: 0.0693
DEBUG - 2011-05-01 22:17:15 --> Config Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:17:15 --> URI Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Router Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Output Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Input Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 22:17:15 --> Language Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Loader Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Controller Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Model Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Model Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 22:17:15 --> Database Driver Class Initialized
DEBUG - 2011-05-01 22:17:15 --> Final output sent to browser
DEBUG - 2011-05-01 22:17:15 --> Total execution time: 0.6026
DEBUG - 2011-05-01 22:17:17 --> Config Class Initialized
DEBUG - 2011-05-01 22:17:17 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:17:17 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:17:17 --> URI Class Initialized
DEBUG - 2011-05-01 22:17:17 --> Router Class Initialized
ERROR - 2011-05-01 22:17:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 22:37:31 --> Config Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:37:31 --> URI Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Router Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Output Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Input Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 22:37:31 --> Language Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Loader Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Controller Class Initialized
ERROR - 2011-05-01 22:37:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 22:37:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 22:37:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 22:37:31 --> Model Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Model Class Initialized
DEBUG - 2011-05-01 22:37:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 22:37:32 --> Database Driver Class Initialized
DEBUG - 2011-05-01 22:37:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 22:37:32 --> Helper loaded: url_helper
DEBUG - 2011-05-01 22:37:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 22:37:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 22:37:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 22:37:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 22:37:32 --> Final output sent to browser
DEBUG - 2011-05-01 22:37:32 --> Total execution time: 0.6096
DEBUG - 2011-05-01 22:37:36 --> Config Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:37:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:37:36 --> URI Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Router Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Output Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Input Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 22:37:36 --> Language Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Loader Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Controller Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Model Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Model Class Initialized
DEBUG - 2011-05-01 22:37:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 22:37:36 --> Database Driver Class Initialized
DEBUG - 2011-05-01 22:37:37 --> Final output sent to browser
DEBUG - 2011-05-01 22:37:37 --> Total execution time: 1.0787
DEBUG - 2011-05-01 22:37:40 --> Config Class Initialized
DEBUG - 2011-05-01 22:37:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:37:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:37:40 --> URI Class Initialized
DEBUG - 2011-05-01 22:37:40 --> Router Class Initialized
ERROR - 2011-05-01 22:37:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 22:39:56 --> Config Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Hooks Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Utf8 Class Initialized
DEBUG - 2011-05-01 22:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 22:39:56 --> URI Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Router Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Output Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Input Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 22:39:56 --> Language Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Loader Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Controller Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Model Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Model Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Model Class Initialized
DEBUG - 2011-05-01 22:39:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 22:39:56 --> Database Driver Class Initialized
DEBUG - 2011-05-01 22:39:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 22:39:56 --> Helper loaded: url_helper
DEBUG - 2011-05-01 22:39:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 22:39:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 22:39:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 22:39:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 22:39:56 --> Final output sent to browser
DEBUG - 2011-05-01 22:39:56 --> Total execution time: 0.3241
DEBUG - 2011-05-01 23:11:39 --> Config Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:11:39 --> URI Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Router Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Output Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Input Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 23:11:39 --> Language Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Loader Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Controller Class Initialized
DEBUG - 2011-05-01 23:11:39 --> Model Class Initialized
DEBUG - 2011-05-01 23:11:40 --> Model Class Initialized
DEBUG - 2011-05-01 23:11:40 --> Model Class Initialized
DEBUG - 2011-05-01 23:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 23:11:40 --> Database Driver Class Initialized
DEBUG - 2011-05-01 23:11:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-01 23:11:40 --> Helper loaded: url_helper
DEBUG - 2011-05-01 23:11:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 23:11:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 23:11:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 23:11:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 23:11:40 --> Final output sent to browser
DEBUG - 2011-05-01 23:11:40 --> Total execution time: 0.6272
DEBUG - 2011-05-01 23:11:41 --> Config Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:11:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:11:41 --> URI Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Router Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Output Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Input Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 23:11:41 --> Language Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Loader Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Controller Class Initialized
ERROR - 2011-05-01 23:11:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 23:11:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 23:11:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 23:11:41 --> Model Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Model Class Initialized
DEBUG - 2011-05-01 23:11:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 23:11:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 23:11:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 23:11:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 23:11:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 23:11:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 23:11:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 23:11:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 23:11:41 --> Final output sent to browser
DEBUG - 2011-05-01 23:11:41 --> Total execution time: 0.3064
DEBUG - 2011-05-01 23:19:22 --> Config Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:19:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:19:22 --> URI Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Router Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Output Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Input Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 23:19:22 --> Language Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Loader Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Controller Class Initialized
ERROR - 2011-05-01 23:19:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 23:19:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 23:19:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 23:19:22 --> Model Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Model Class Initialized
DEBUG - 2011-05-01 23:19:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 23:19:22 --> Database Driver Class Initialized
DEBUG - 2011-05-01 23:19:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 23:19:22 --> Helper loaded: url_helper
DEBUG - 2011-05-01 23:19:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 23:19:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 23:19:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 23:19:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 23:19:22 --> Final output sent to browser
DEBUG - 2011-05-01 23:19:22 --> Total execution time: 0.0384
DEBUG - 2011-05-01 23:19:23 --> Config Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:19:23 --> URI Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Router Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Output Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Input Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 23:19:23 --> Language Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Loader Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Controller Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Model Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Model Class Initialized
DEBUG - 2011-05-01 23:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 23:19:23 --> Database Driver Class Initialized
DEBUG - 2011-05-01 23:19:24 --> Final output sent to browser
DEBUG - 2011-05-01 23:19:24 --> Total execution time: 0.5947
DEBUG - 2011-05-01 23:19:26 --> Config Class Initialized
DEBUG - 2011-05-01 23:19:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:19:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:19:26 --> URI Class Initialized
DEBUG - 2011-05-01 23:19:26 --> Router Class Initialized
ERROR - 2011-05-01 23:19:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 23:19:27 --> Config Class Initialized
DEBUG - 2011-05-01 23:19:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:19:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:19:27 --> URI Class Initialized
DEBUG - 2011-05-01 23:19:27 --> Router Class Initialized
ERROR - 2011-05-01 23:19:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 23:19:27 --> Config Class Initialized
DEBUG - 2011-05-01 23:19:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:19:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:19:27 --> URI Class Initialized
DEBUG - 2011-05-01 23:19:27 --> Router Class Initialized
ERROR - 2011-05-01 23:19:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 23:32:39 --> Config Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:32:39 --> URI Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Router Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Output Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Input Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 23:32:39 --> Language Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Loader Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Controller Class Initialized
ERROR - 2011-05-01 23:32:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 23:32:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 23:32:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 23:32:39 --> Model Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Model Class Initialized
DEBUG - 2011-05-01 23:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 23:32:39 --> Database Driver Class Initialized
DEBUG - 2011-05-01 23:32:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 23:32:39 --> Helper loaded: url_helper
DEBUG - 2011-05-01 23:32:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 23:32:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 23:32:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 23:32:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 23:32:39 --> Final output sent to browser
DEBUG - 2011-05-01 23:32:39 --> Total execution time: 0.0594
DEBUG - 2011-05-01 23:32:40 --> Config Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:32:40 --> URI Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Router Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Output Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Input Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 23:32:40 --> Language Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Loader Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Controller Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Model Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Model Class Initialized
DEBUG - 2011-05-01 23:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 23:32:40 --> Database Driver Class Initialized
DEBUG - 2011-05-01 23:32:41 --> Final output sent to browser
DEBUG - 2011-05-01 23:32:41 --> Total execution time: 0.7204
DEBUG - 2011-05-01 23:32:42 --> Config Class Initialized
DEBUG - 2011-05-01 23:32:42 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:32:42 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:32:42 --> URI Class Initialized
DEBUG - 2011-05-01 23:32:42 --> Router Class Initialized
ERROR - 2011-05-01 23:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-01 23:36:25 --> Config Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:36:25 --> URI Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Router Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Output Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Input Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 23:36:25 --> Language Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Loader Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Controller Class Initialized
ERROR - 2011-05-01 23:36:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-01 23:36:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-01 23:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 23:36:25 --> Model Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Model Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 23:36:25 --> Database Driver Class Initialized
DEBUG - 2011-05-01 23:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-01 23:36:25 --> Helper loaded: url_helper
DEBUG - 2011-05-01 23:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-01 23:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-01 23:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-01 23:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-01 23:36:25 --> Final output sent to browser
DEBUG - 2011-05-01 23:36:25 --> Total execution time: 0.0484
DEBUG - 2011-05-01 23:36:25 --> Config Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:36:25 --> URI Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Router Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Output Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Input Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 23:36:25 --> Language Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Loader Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Controller Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Model Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Model Class Initialized
DEBUG - 2011-05-01 23:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-01 23:36:25 --> Database Driver Class Initialized
DEBUG - 2011-05-01 23:36:26 --> Final output sent to browser
DEBUG - 2011-05-01 23:36:26 --> Total execution time: 0.9194
DEBUG - 2011-05-01 23:36:27 --> Config Class Initialized
DEBUG - 2011-05-01 23:36:27 --> Hooks Class Initialized
DEBUG - 2011-05-01 23:36:27 --> Utf8 Class Initialized
DEBUG - 2011-05-01 23:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 23:36:27 --> URI Class Initialized
DEBUG - 2011-05-01 23:36:27 --> Router Class Initialized
ERROR - 2011-05-01 23:36:27 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-01 00:34:53 --> Config Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Hooks Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Utf8 Class Initialized
DEBUG - 2011-06-01 00:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 00:34:53 --> URI Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Router Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Output Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Input Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 00:34:53 --> Language Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Loader Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Controller Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Model Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Model Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Model Class Initialized
DEBUG - 2011-06-01 00:34:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 00:34:53 --> Database Driver Class Initialized
DEBUG - 2011-06-01 00:34:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 00:34:54 --> Helper loaded: url_helper
DEBUG - 2011-06-01 00:34:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 00:34:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 00:34:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 00:34:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 00:34:54 --> Final output sent to browser
DEBUG - 2011-06-01 00:34:54 --> Total execution time: 0.5431
DEBUG - 2011-06-01 00:34:56 --> Config Class Initialized
DEBUG - 2011-06-01 00:34:56 --> Hooks Class Initialized
DEBUG - 2011-06-01 00:34:56 --> Utf8 Class Initialized
DEBUG - 2011-06-01 00:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 00:34:56 --> URI Class Initialized
DEBUG - 2011-06-01 00:34:56 --> Router Class Initialized
ERROR - 2011-06-01 00:34:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 00:34:56 --> Config Class Initialized
DEBUG - 2011-06-01 00:34:56 --> Hooks Class Initialized
DEBUG - 2011-06-01 00:34:56 --> Utf8 Class Initialized
DEBUG - 2011-06-01 00:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 00:34:56 --> URI Class Initialized
DEBUG - 2011-06-01 00:34:56 --> Router Class Initialized
ERROR - 2011-06-01 00:34:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 01:12:04 --> Config Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:12:04 --> URI Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Router Class Initialized
ERROR - 2011-06-01 01:12:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-01 01:12:04 --> Config Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:12:04 --> URI Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Router Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Output Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Input Class Initialized
DEBUG - 2011-06-01 01:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:12:04 --> Language Class Initialized
DEBUG - 2011-06-01 01:12:05 --> Loader Class Initialized
DEBUG - 2011-06-01 01:12:05 --> Controller Class Initialized
DEBUG - 2011-06-01 01:12:05 --> Model Class Initialized
DEBUG - 2011-06-01 01:12:05 --> Model Class Initialized
DEBUG - 2011-06-01 01:12:05 --> Model Class Initialized
DEBUG - 2011-06-01 01:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:12:05 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:12:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 01:12:05 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:12:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:12:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:12:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:12:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:12:05 --> Final output sent to browser
DEBUG - 2011-06-01 01:12:05 --> Total execution time: 0.4441
DEBUG - 2011-06-01 01:12:35 --> Config Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:12:35 --> URI Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Router Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Output Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Input Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:12:35 --> Language Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Loader Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Controller Class Initialized
ERROR - 2011-06-01 01:12:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 01:12:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 01:12:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 01:12:35 --> Model Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Model Class Initialized
DEBUG - 2011-06-01 01:12:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:12:35 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:12:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 01:12:35 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:12:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:12:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:12:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:12:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:12:35 --> Final output sent to browser
DEBUG - 2011-06-01 01:12:35 --> Total execution time: 0.0894
DEBUG - 2011-06-01 01:17:56 --> Config Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:17:56 --> URI Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Router Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Output Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Input Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:17:56 --> Language Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Loader Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Controller Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Model Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Model Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Model Class Initialized
DEBUG - 2011-06-01 01:17:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:17:56 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:17:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 01:17:57 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:17:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:17:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:17:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:17:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:17:57 --> Final output sent to browser
DEBUG - 2011-06-01 01:17:57 --> Total execution time: 0.0639
DEBUG - 2011-06-01 01:18:03 --> Config Class Initialized
DEBUG - 2011-06-01 01:18:03 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:18:03 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:18:03 --> URI Class Initialized
DEBUG - 2011-06-01 01:18:03 --> Router Class Initialized
ERROR - 2011-06-01 01:18:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 01:18:04 --> Config Class Initialized
DEBUG - 2011-06-01 01:18:04 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:18:04 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:18:04 --> URI Class Initialized
DEBUG - 2011-06-01 01:18:04 --> Router Class Initialized
ERROR - 2011-06-01 01:18:04 --> 404 Page Not Found --> crossdomain.xml
DEBUG - 2011-06-01 01:18:34 --> Config Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:18:34 --> URI Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Router Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Output Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Input Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:18:34 --> Language Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Loader Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Controller Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Model Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Model Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Model Class Initialized
DEBUG - 2011-06-01 01:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:18:34 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:18:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 01:18:34 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:18:34 --> Final output sent to browser
DEBUG - 2011-06-01 01:18:34 --> Total execution time: 0.3070
DEBUG - 2011-06-01 01:18:38 --> Config Class Initialized
DEBUG - 2011-06-01 01:18:38 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:18:38 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:18:38 --> URI Class Initialized
DEBUG - 2011-06-01 01:18:38 --> Router Class Initialized
ERROR - 2011-06-01 01:18:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 01:18:41 --> Config Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:18:41 --> URI Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Router Class Initialized
ERROR - 2011-06-01 01:18:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-01 01:18:41 --> Config Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:18:41 --> URI Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Router Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Output Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Input Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:18:41 --> Language Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Loader Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Controller Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Model Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Model Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Model Class Initialized
DEBUG - 2011-06-01 01:18:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:18:41 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:18:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 01:18:41 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:18:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:18:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:18:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:18:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:18:41 --> Final output sent to browser
DEBUG - 2011-06-01 01:18:41 --> Total execution time: 0.1042
DEBUG - 2011-06-01 01:19:02 --> Config Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:19:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:19:02 --> URI Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Router Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Output Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Input Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:19:02 --> Language Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Loader Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Controller Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:19:02 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:19:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 01:19:03 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:19:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:19:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:19:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:19:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:19:03 --> Final output sent to browser
DEBUG - 2011-06-01 01:19:03 --> Total execution time: 0.3092
DEBUG - 2011-06-01 01:19:04 --> Config Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:19:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:19:04 --> URI Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Router Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Output Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Input Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:19:04 --> Language Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Loader Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Controller Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:19:04 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 01:19:04 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:19:04 --> Final output sent to browser
DEBUG - 2011-06-01 01:19:04 --> Total execution time: 0.0620
DEBUG - 2011-06-01 01:19:04 --> Config Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:19:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:19:04 --> URI Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Router Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Output Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Input Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:19:04 --> Language Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Loader Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Controller Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:19:04 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 01:19:04 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:19:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:19:04 --> Final output sent to browser
DEBUG - 2011-06-01 01:19:04 --> Total execution time: 0.1179
DEBUG - 2011-06-01 01:19:05 --> Config Class Initialized
DEBUG - 2011-06-01 01:19:05 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:19:05 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:19:05 --> URI Class Initialized
DEBUG - 2011-06-01 01:19:05 --> Router Class Initialized
ERROR - 2011-06-01 01:19:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 01:19:19 --> Config Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:19:19 --> URI Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Router Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Output Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Input Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:19:19 --> Language Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Loader Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Controller Class Initialized
ERROR - 2011-06-01 01:19:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 01:19:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 01:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 01:19:19 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:19:19 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 01:19:19 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:19:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:19:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:19:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:19:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:19:19 --> Final output sent to browser
DEBUG - 2011-06-01 01:19:19 --> Total execution time: 0.0323
DEBUG - 2011-06-01 01:19:20 --> Config Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:19:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:19:20 --> URI Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Router Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Output Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Input Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:19:20 --> Language Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Loader Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Controller Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Model Class Initialized
DEBUG - 2011-06-01 01:19:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:19:20 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:19:21 --> Final output sent to browser
DEBUG - 2011-06-01 01:19:21 --> Total execution time: 0.7069
DEBUG - 2011-06-01 01:19:23 --> Config Class Initialized
DEBUG - 2011-06-01 01:19:23 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:19:23 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:19:23 --> URI Class Initialized
DEBUG - 2011-06-01 01:19:23 --> Router Class Initialized
ERROR - 2011-06-01 01:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 01:33:51 --> Config Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:33:51 --> URI Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Router Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Output Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Input Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:33:51 --> Language Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Loader Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Controller Class Initialized
ERROR - 2011-06-01 01:33:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 01:33:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 01:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 01:33:51 --> Model Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Model Class Initialized
DEBUG - 2011-06-01 01:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:33:51 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 01:33:51 --> Helper loaded: url_helper
DEBUG - 2011-06-01 01:33:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 01:33:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 01:33:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 01:33:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 01:33:51 --> Final output sent to browser
DEBUG - 2011-06-01 01:33:51 --> Total execution time: 0.2334
DEBUG - 2011-06-01 01:33:52 --> Config Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:33:52 --> URI Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Router Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Output Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Input Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 01:33:52 --> Language Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Loader Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Controller Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Model Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Model Class Initialized
DEBUG - 2011-06-01 01:33:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 01:33:52 --> Database Driver Class Initialized
DEBUG - 2011-06-01 01:33:53 --> Final output sent to browser
DEBUG - 2011-06-01 01:33:53 --> Total execution time: 0.6066
DEBUG - 2011-06-01 01:33:55 --> Config Class Initialized
DEBUG - 2011-06-01 01:33:55 --> Hooks Class Initialized
DEBUG - 2011-06-01 01:33:55 --> Utf8 Class Initialized
DEBUG - 2011-06-01 01:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 01:33:55 --> URI Class Initialized
DEBUG - 2011-06-01 01:33:55 --> Router Class Initialized
ERROR - 2011-06-01 01:33:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 02:59:14 --> Config Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Hooks Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Utf8 Class Initialized
DEBUG - 2011-06-01 02:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 02:59:14 --> URI Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Router Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Output Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Input Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 02:59:14 --> Language Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Loader Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Controller Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 02:59:14 --> Database Driver Class Initialized
DEBUG - 2011-06-01 02:59:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 02:59:26 --> Helper loaded: url_helper
DEBUG - 2011-06-01 02:59:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 02:59:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 02:59:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 02:59:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 02:59:26 --> Final output sent to browser
DEBUG - 2011-06-01 02:59:26 --> Total execution time: 12.2509
DEBUG - 2011-06-01 02:59:29 --> Config Class Initialized
DEBUG - 2011-06-01 02:59:29 --> Hooks Class Initialized
DEBUG - 2011-06-01 02:59:29 --> Utf8 Class Initialized
DEBUG - 2011-06-01 02:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 02:59:29 --> URI Class Initialized
DEBUG - 2011-06-01 02:59:29 --> Router Class Initialized
ERROR - 2011-06-01 02:59:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 02:59:34 --> Config Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Hooks Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Utf8 Class Initialized
DEBUG - 2011-06-01 02:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 02:59:34 --> URI Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Router Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Output Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Input Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 02:59:34 --> Language Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Loader Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Controller Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 02:59:34 --> Database Driver Class Initialized
DEBUG - 2011-06-01 02:59:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 02:59:36 --> Helper loaded: url_helper
DEBUG - 2011-06-01 02:59:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 02:59:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 02:59:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 02:59:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 02:59:36 --> Final output sent to browser
DEBUG - 2011-06-01 02:59:36 --> Total execution time: 1.4048
DEBUG - 2011-06-01 02:59:37 --> Config Class Initialized
DEBUG - 2011-06-01 02:59:37 --> Hooks Class Initialized
DEBUG - 2011-06-01 02:59:37 --> Utf8 Class Initialized
DEBUG - 2011-06-01 02:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 02:59:37 --> URI Class Initialized
DEBUG - 2011-06-01 02:59:37 --> Router Class Initialized
ERROR - 2011-06-01 02:59:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 02:59:44 --> Config Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Hooks Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Utf8 Class Initialized
DEBUG - 2011-06-01 02:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 02:59:44 --> URI Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Router Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Output Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Input Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 02:59:44 --> Language Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Loader Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Controller Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Model Class Initialized
DEBUG - 2011-06-01 02:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 02:59:44 --> Database Driver Class Initialized
DEBUG - 2011-06-01 02:59:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 02:59:44 --> Helper loaded: url_helper
DEBUG - 2011-06-01 02:59:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 02:59:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 02:59:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 02:59:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 02:59:44 --> Final output sent to browser
DEBUG - 2011-06-01 02:59:44 --> Total execution time: 0.0512
DEBUG - 2011-06-01 03:08:51 --> Config Class Initialized
DEBUG - 2011-06-01 03:08:51 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:08:51 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:08:51 --> URI Class Initialized
DEBUG - 2011-06-01 03:08:51 --> Router Class Initialized
DEBUG - 2011-06-01 03:08:52 --> No URI present. Default controller set.
DEBUG - 2011-06-01 03:08:52 --> Output Class Initialized
DEBUG - 2011-06-01 03:08:52 --> Input Class Initialized
DEBUG - 2011-06-01 03:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 03:08:52 --> Language Class Initialized
DEBUG - 2011-06-01 03:08:52 --> Loader Class Initialized
DEBUG - 2011-06-01 03:08:52 --> Controller Class Initialized
DEBUG - 2011-06-01 03:08:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-01 03:08:52 --> Helper loaded: url_helper
DEBUG - 2011-06-01 03:08:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 03:08:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 03:08:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 03:08:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 03:08:52 --> Final output sent to browser
DEBUG - 2011-06-01 03:08:52 --> Total execution time: 1.2315
DEBUG - 2011-06-01 03:38:29 --> Config Class Initialized
DEBUG - 2011-06-01 03:38:30 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:38:30 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:38:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:38:30 --> URI Class Initialized
DEBUG - 2011-06-01 03:38:30 --> Router Class Initialized
DEBUG - 2011-06-01 03:38:30 --> No URI present. Default controller set.
DEBUG - 2011-06-01 03:38:30 --> Output Class Initialized
DEBUG - 2011-06-01 03:38:30 --> Input Class Initialized
DEBUG - 2011-06-01 03:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 03:38:30 --> Language Class Initialized
DEBUG - 2011-06-01 03:38:30 --> Loader Class Initialized
DEBUG - 2011-06-01 03:38:30 --> Controller Class Initialized
DEBUG - 2011-06-01 03:38:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-01 03:38:30 --> Helper loaded: url_helper
DEBUG - 2011-06-01 03:38:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 03:38:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 03:38:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 03:38:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 03:38:30 --> Final output sent to browser
DEBUG - 2011-06-01 03:38:30 --> Total execution time: 0.2438
DEBUG - 2011-06-01 03:38:31 --> Config Class Initialized
DEBUG - 2011-06-01 03:38:31 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:38:31 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:38:31 --> URI Class Initialized
DEBUG - 2011-06-01 03:38:31 --> Router Class Initialized
ERROR - 2011-06-01 03:38:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 03:38:31 --> Config Class Initialized
DEBUG - 2011-06-01 03:38:31 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:38:31 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:38:31 --> URI Class Initialized
DEBUG - 2011-06-01 03:38:31 --> Router Class Initialized
ERROR - 2011-06-01 03:38:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 03:38:36 --> Config Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:38:36 --> URI Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Router Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Output Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Input Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 03:38:36 --> Language Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Loader Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Controller Class Initialized
ERROR - 2011-06-01 03:38:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 03:38:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 03:38:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 03:38:36 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 03:38:36 --> Database Driver Class Initialized
DEBUG - 2011-06-01 03:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 03:38:37 --> Helper loaded: url_helper
DEBUG - 2011-06-01 03:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 03:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 03:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 03:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 03:38:37 --> Final output sent to browser
DEBUG - 2011-06-01 03:38:37 --> Total execution time: 0.7502
DEBUG - 2011-06-01 03:38:37 --> Config Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:38:37 --> URI Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Router Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Output Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Input Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 03:38:37 --> Language Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Loader Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Controller Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 03:38:37 --> Database Driver Class Initialized
DEBUG - 2011-06-01 03:38:40 --> Config Class Initialized
DEBUG - 2011-06-01 03:38:40 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:38:40 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:38:40 --> URI Class Initialized
DEBUG - 2011-06-01 03:38:40 --> Router Class Initialized
ERROR - 2011-06-01 03:38:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 03:38:42 --> Config Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:38:42 --> URI Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Router Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Output Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Input Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 03:38:42 --> Language Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Loader Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Controller Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 03:38:42 --> Database Driver Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Config Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Hooks Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Utf8 Class Initialized
DEBUG - 2011-06-01 03:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 03:38:44 --> URI Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Router Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Output Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Input Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 03:38:44 --> Language Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Loader Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Controller Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Model Class Initialized
DEBUG - 2011-06-01 03:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 03:38:44 --> Database Driver Class Initialized
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 03:38:48 --> Helper loaded: url_helper
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 03:38:48 --> Helper loaded: url_helper
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 03:38:48 --> Final output sent to browser
DEBUG - 2011-06-01 03:38:48 --> Total execution time: 5.4368
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 03:38:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 03:38:48 --> Final output sent to browser
DEBUG - 2011-06-01 03:38:48 --> Total execution time: 3.4302
DEBUG - 2011-06-01 06:04:41 --> Config Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:04:41 --> URI Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Router Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Output Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Input Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:04:41 --> Language Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Loader Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Controller Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Model Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Model Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Model Class Initialized
DEBUG - 2011-06-01 06:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:04:41 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:04:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:04:43 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:04:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:04:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:04:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:04:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:04:43 --> Final output sent to browser
DEBUG - 2011-06-01 06:04:43 --> Total execution time: 1.8152
DEBUG - 2011-06-01 06:04:59 --> Config Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:04:59 --> URI Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Router Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Output Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Input Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:04:59 --> Language Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Loader Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Controller Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Model Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Model Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Model Class Initialized
DEBUG - 2011-06-01 06:04:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:04:59 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:05:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:05:00 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:05:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:05:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:05:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:05:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:05:00 --> Final output sent to browser
DEBUG - 2011-06-01 06:05:00 --> Total execution time: 1.7317
DEBUG - 2011-06-01 06:05:24 --> Config Class Initialized
DEBUG - 2011-06-01 06:05:24 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:05:24 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:05:24 --> URI Class Initialized
DEBUG - 2011-06-01 06:05:24 --> Router Class Initialized
ERROR - 2011-06-01 06:05:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-01 06:05:25 --> Config Class Initialized
DEBUG - 2011-06-01 06:05:25 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:05:25 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:05:25 --> URI Class Initialized
DEBUG - 2011-06-01 06:05:25 --> Router Class Initialized
DEBUG - 2011-06-01 06:05:25 --> Output Class Initialized
DEBUG - 2011-06-01 06:05:25 --> Input Class Initialized
DEBUG - 2011-06-01 06:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:05:25 --> Language Class Initialized
DEBUG - 2011-06-01 06:05:26 --> Loader Class Initialized
DEBUG - 2011-06-01 06:05:26 --> Controller Class Initialized
ERROR - 2011-06-01 06:05:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 06:05:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 06:05:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 06:05:26 --> Model Class Initialized
DEBUG - 2011-06-01 06:05:26 --> Model Class Initialized
DEBUG - 2011-06-01 06:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:05:26 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:05:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 06:05:26 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:05:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:05:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:05:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:05:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:05:26 --> Final output sent to browser
DEBUG - 2011-06-01 06:05:26 --> Total execution time: 1.1554
DEBUG - 2011-06-01 06:05:32 --> Config Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:05:32 --> URI Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Router Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Output Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Input Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:05:32 --> Language Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Loader Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Controller Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Model Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Model Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Model Class Initialized
DEBUG - 2011-06-01 06:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:05:32 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:05:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:05:33 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:05:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:05:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:05:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:05:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:05:33 --> Final output sent to browser
DEBUG - 2011-06-01 06:05:33 --> Total execution time: 1.1321
DEBUG - 2011-06-01 06:06:03 --> Config Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:06:03 --> URI Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Router Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Output Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Input Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:06:03 --> Language Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Loader Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Controller Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:06:03 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:06:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:06:03 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:06:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:06:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:06:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:06:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:06:03 --> Final output sent to browser
DEBUG - 2011-06-01 06:06:03 --> Total execution time: 0.7304
DEBUG - 2011-06-01 06:06:09 --> Config Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:06:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:06:09 --> URI Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Router Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Output Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Input Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:06:09 --> Language Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Loader Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Controller Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:06:09 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:06:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:06:09 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:06:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:06:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:06:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:06:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:06:09 --> Final output sent to browser
DEBUG - 2011-06-01 06:06:09 --> Total execution time: 0.0867
DEBUG - 2011-06-01 06:06:12 --> Config Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:06:12 --> URI Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Router Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Output Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Input Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:06:12 --> Language Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Loader Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Controller Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:06:12 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:06:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:06:12 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:06:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:06:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:06:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:06:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:06:12 --> Final output sent to browser
DEBUG - 2011-06-01 06:06:12 --> Total execution time: 0.1460
DEBUG - 2011-06-01 06:06:15 --> Config Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:06:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:06:15 --> URI Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Router Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Output Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Input Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:06:15 --> Language Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Loader Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Controller Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:06:15 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:06:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:06:15 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:06:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:06:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:06:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:06:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:06:15 --> Final output sent to browser
DEBUG - 2011-06-01 06:06:15 --> Total execution time: 0.1042
DEBUG - 2011-06-01 06:06:24 --> Config Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:06:24 --> URI Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Router Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Output Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Input Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:06:24 --> Language Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Loader Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Controller Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:06:24 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:06:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:06:25 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:06:25 --> Final output sent to browser
DEBUG - 2011-06-01 06:06:25 --> Total execution time: 0.4051
DEBUG - 2011-06-01 06:06:27 --> Config Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:06:27 --> URI Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Router Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Output Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Input Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:06:27 --> Language Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Loader Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Controller Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:06:27 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:06:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:06:27 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:06:27 --> Final output sent to browser
DEBUG - 2011-06-01 06:06:27 --> Total execution time: 0.0499
DEBUG - 2011-06-01 06:06:44 --> Config Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:06:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:06:44 --> URI Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Router Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Output Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Input Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:06:44 --> Language Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Loader Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Controller Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:06:44 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:06:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:06:45 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:06:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:06:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:06:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:06:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:06:45 --> Final output sent to browser
DEBUG - 2011-06-01 06:06:45 --> Total execution time: 0.7149
DEBUG - 2011-06-01 06:06:46 --> Config Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:06:46 --> URI Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Router Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Output Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Input Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:06:46 --> Language Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Loader Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Controller Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Model Class Initialized
DEBUG - 2011-06-01 06:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:06:46 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:06:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:06:46 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:06:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:06:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:06:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:06:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:06:46 --> Final output sent to browser
DEBUG - 2011-06-01 06:06:46 --> Total execution time: 0.0821
DEBUG - 2011-06-01 06:07:01 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:01 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:01 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:01 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:02 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:02 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:02 --> Total execution time: 0.3356
DEBUG - 2011-06-01 06:07:03 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:03 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:03 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:03 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:03 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:03 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:03 --> Total execution time: 0.0454
DEBUG - 2011-06-01 06:07:03 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:03 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:03 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:03 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:03 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:03 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:03 --> Total execution time: 0.0522
DEBUG - 2011-06-01 06:07:17 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:17 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:17 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:17 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:18 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:18 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:18 --> Total execution time: 0.9005
DEBUG - 2011-06-01 06:07:19 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:19 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:19 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:19 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:19 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:19 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:19 --> Total execution time: 0.0718
DEBUG - 2011-06-01 06:07:29 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:29 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:29 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:29 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:29 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:29 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:29 --> Total execution time: 0.6702
DEBUG - 2011-06-01 06:07:33 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:33 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:33 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:33 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:33 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:33 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:33 --> Total execution time: 0.1475
DEBUG - 2011-06-01 06:07:47 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:47 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:47 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:47 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:47 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:47 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:47 --> Total execution time: 0.3231
DEBUG - 2011-06-01 06:07:48 --> Config Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:07:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:07:48 --> URI Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Router Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Output Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Input Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:07:48 --> Language Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Loader Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Controller Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Model Class Initialized
DEBUG - 2011-06-01 06:07:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:07:48 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:07:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:07:49 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:07:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:07:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:07:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:07:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:07:49 --> Final output sent to browser
DEBUG - 2011-06-01 06:07:49 --> Total execution time: 0.2218
DEBUG - 2011-06-01 06:08:05 --> Config Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:08:05 --> URI Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Router Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Output Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Input Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:08:05 --> Language Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Loader Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Controller Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:08:05 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:08:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:08:06 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:08:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:08:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:08:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:08:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:08:06 --> Final output sent to browser
DEBUG - 2011-06-01 06:08:06 --> Total execution time: 0.7120
DEBUG - 2011-06-01 06:08:36 --> Config Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:08:36 --> URI Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Router Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Output Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Input Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:08:36 --> Language Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Loader Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Controller Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:08:36 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:08:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:08:36 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:08:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:08:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:08:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:08:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:08:36 --> Final output sent to browser
DEBUG - 2011-06-01 06:08:36 --> Total execution time: 0.5467
DEBUG - 2011-06-01 06:08:37 --> Config Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:08:37 --> URI Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Router Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Output Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Input Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:08:37 --> Language Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Loader Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Controller Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:08:37 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:08:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:08:37 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:08:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:08:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:08:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:08:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:08:37 --> Final output sent to browser
DEBUG - 2011-06-01 06:08:37 --> Total execution time: 0.0599
DEBUG - 2011-06-01 06:08:38 --> Config Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:08:38 --> URI Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Router Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Output Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Input Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:08:38 --> Language Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Loader Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Controller Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:08:38 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:08:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:08:38 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:08:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:08:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:08:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:08:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:08:38 --> Final output sent to browser
DEBUG - 2011-06-01 06:08:38 --> Total execution time: 0.0864
DEBUG - 2011-06-01 06:08:43 --> Config Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:08:43 --> URI Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Router Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Output Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Input Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:08:43 --> Language Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Loader Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Controller Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:08:43 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:08:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:08:43 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:08:43 --> Final output sent to browser
DEBUG - 2011-06-01 06:08:43 --> Total execution time: 0.7549
DEBUG - 2011-06-01 06:08:52 --> Config Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:08:52 --> URI Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Router Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Output Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Input Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:08:52 --> Language Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Loader Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Controller Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:08:52 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:08:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:08:53 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:08:53 --> Final output sent to browser
DEBUG - 2011-06-01 06:08:53 --> Total execution time: 0.2767
DEBUG - 2011-06-01 06:08:58 --> Config Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:08:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:08:58 --> URI Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Router Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Output Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Input Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:08:58 --> Language Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Loader Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Controller Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Model Class Initialized
DEBUG - 2011-06-01 06:08:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:08:58 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:08:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:08:59 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:08:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:08:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:08:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:08:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:08:59 --> Final output sent to browser
DEBUG - 2011-06-01 06:08:59 --> Total execution time: 1.3733
DEBUG - 2011-06-01 06:09:08 --> Config Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:09:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:09:08 --> URI Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Router Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Output Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Input Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:09:08 --> Language Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Loader Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Controller Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:09:08 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:09:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:09:09 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:09:09 --> Final output sent to browser
DEBUG - 2011-06-01 06:09:09 --> Total execution time: 1.4234
DEBUG - 2011-06-01 06:09:20 --> Config Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:09:20 --> URI Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Router Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Output Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Input Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:09:20 --> Language Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Loader Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Controller Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:09:20 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:09:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:09:20 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:09:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:09:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:09:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:09:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:09:20 --> Final output sent to browser
DEBUG - 2011-06-01 06:09:20 --> Total execution time: 0.2634
DEBUG - 2011-06-01 06:09:26 --> Config Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:09:26 --> URI Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Router Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Output Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Input Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:09:26 --> Language Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Loader Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Controller Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Model Class Initialized
DEBUG - 2011-06-01 06:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:09:26 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:09:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:09:26 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:09:26 --> Final output sent to browser
DEBUG - 2011-06-01 06:09:26 --> Total execution time: 0.0488
DEBUG - 2011-06-01 06:10:37 --> Config Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:10:37 --> URI Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Router Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Output Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Input Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:10:37 --> Language Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Loader Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Controller Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Model Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Model Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Model Class Initialized
DEBUG - 2011-06-01 06:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:10:37 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:10:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:10:37 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:10:37 --> Final output sent to browser
DEBUG - 2011-06-01 06:10:37 --> Total execution time: 0.0606
DEBUG - 2011-06-01 06:11:02 --> Config Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:11:02 --> URI Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Router Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Output Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Input Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:11:02 --> Language Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Loader Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Controller Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:11:02 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:11:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:11:02 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:11:02 --> Final output sent to browser
DEBUG - 2011-06-01 06:11:02 --> Total execution time: 0.0650
DEBUG - 2011-06-01 06:11:05 --> Config Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:11:05 --> URI Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Router Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Output Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Input Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:11:05 --> Language Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Loader Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Controller Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:11:05 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:11:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:11:05 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:11:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:11:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:11:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:11:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:11:05 --> Final output sent to browser
DEBUG - 2011-06-01 06:11:05 --> Total execution time: 0.0429
DEBUG - 2011-06-01 06:11:06 --> Config Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:11:06 --> URI Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Router Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Output Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Input Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:11:06 --> Language Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Loader Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Controller Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:11:06 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:11:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:11:06 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:11:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:11:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:11:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:11:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:11:06 --> Final output sent to browser
DEBUG - 2011-06-01 06:11:06 --> Total execution time: 0.0432
DEBUG - 2011-06-01 06:11:07 --> Config Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Hooks Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Utf8 Class Initialized
DEBUG - 2011-06-01 06:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 06:11:07 --> URI Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Router Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Output Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Input Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 06:11:07 --> Language Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Loader Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Controller Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Model Class Initialized
DEBUG - 2011-06-01 06:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 06:11:07 --> Database Driver Class Initialized
DEBUG - 2011-06-01 06:11:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 06:11:07 --> Helper loaded: url_helper
DEBUG - 2011-06-01 06:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 06:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 06:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 06:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 06:11:07 --> Final output sent to browser
DEBUG - 2011-06-01 06:11:07 --> Total execution time: 0.0505
DEBUG - 2011-06-01 12:03:56 --> Config Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Hooks Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Utf8 Class Initialized
DEBUG - 2011-06-01 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 12:03:56 --> URI Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Router Class Initialized
ERROR - 2011-06-01 12:03:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-01 12:03:56 --> Config Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Hooks Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Utf8 Class Initialized
DEBUG - 2011-06-01 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 12:03:56 --> URI Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Router Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Output Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Input Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 12:03:56 --> Language Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Loader Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Controller Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Model Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Model Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Model Class Initialized
DEBUG - 2011-06-01 12:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 12:03:56 --> Database Driver Class Initialized
DEBUG - 2011-06-01 12:03:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 12:03:57 --> Helper loaded: url_helper
DEBUG - 2011-06-01 12:03:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 12:03:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 12:03:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 12:03:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 12:03:57 --> Final output sent to browser
DEBUG - 2011-06-01 12:03:57 --> Total execution time: 1.3872
DEBUG - 2011-06-01 12:04:28 --> Config Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Hooks Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Utf8 Class Initialized
DEBUG - 2011-06-01 12:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 12:04:28 --> URI Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Router Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Output Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Input Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 12:04:28 --> Language Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Loader Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Controller Class Initialized
ERROR - 2011-06-01 12:04:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 12:04:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 12:04:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 12:04:28 --> Model Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Model Class Initialized
DEBUG - 2011-06-01 12:04:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 12:04:28 --> Database Driver Class Initialized
DEBUG - 2011-06-01 12:04:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 12:04:28 --> Helper loaded: url_helper
DEBUG - 2011-06-01 12:04:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 12:04:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 12:04:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 12:04:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 12:04:28 --> Final output sent to browser
DEBUG - 2011-06-01 12:04:28 --> Total execution time: 0.1144
DEBUG - 2011-06-01 13:35:21 --> Config Class Initialized
DEBUG - 2011-06-01 13:35:21 --> Hooks Class Initialized
DEBUG - 2011-06-01 13:35:22 --> Utf8 Class Initialized
DEBUG - 2011-06-01 13:35:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 13:35:22 --> URI Class Initialized
DEBUG - 2011-06-01 13:35:22 --> Router Class Initialized
DEBUG - 2011-06-01 13:35:23 --> Output Class Initialized
DEBUG - 2011-06-01 13:35:23 --> Input Class Initialized
DEBUG - 2011-06-01 13:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 13:35:23 --> Language Class Initialized
DEBUG - 2011-06-01 13:35:24 --> Loader Class Initialized
DEBUG - 2011-06-01 13:35:24 --> Controller Class Initialized
DEBUG - 2011-06-01 13:35:24 --> Model Class Initialized
DEBUG - 2011-06-01 13:35:25 --> Model Class Initialized
DEBUG - 2011-06-01 13:35:25 --> Model Class Initialized
DEBUG - 2011-06-01 13:35:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 13:35:25 --> Database Driver Class Initialized
DEBUG - 2011-06-01 13:35:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 13:35:26 --> Helper loaded: url_helper
DEBUG - 2011-06-01 13:35:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 13:35:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 13:35:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 13:35:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 13:35:26 --> Final output sent to browser
DEBUG - 2011-06-01 13:35:26 --> Total execution time: 6.5908
DEBUG - 2011-06-01 13:35:38 --> Config Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Hooks Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Utf8 Class Initialized
DEBUG - 2011-06-01 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 13:35:38 --> URI Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Router Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Output Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Input Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 13:35:38 --> Language Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Loader Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Controller Class Initialized
ERROR - 2011-06-01 13:35:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 13:35:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 13:35:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 13:35:38 --> Model Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Model Class Initialized
DEBUG - 2011-06-01 13:35:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 13:35:38 --> Database Driver Class Initialized
DEBUG - 2011-06-01 13:35:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 13:35:38 --> Helper loaded: url_helper
DEBUG - 2011-06-01 13:35:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 13:35:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 13:35:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 13:35:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 13:35:38 --> Final output sent to browser
DEBUG - 2011-06-01 13:35:38 --> Total execution time: 0.2718
DEBUG - 2011-06-01 13:43:11 --> Config Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Hooks Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Utf8 Class Initialized
DEBUG - 2011-06-01 13:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 13:43:11 --> URI Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Router Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Output Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Input Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 13:43:11 --> Language Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Loader Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Controller Class Initialized
ERROR - 2011-06-01 13:43:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 13:43:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 13:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 13:43:11 --> Model Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Model Class Initialized
DEBUG - 2011-06-01 13:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 13:43:11 --> Database Driver Class Initialized
DEBUG - 2011-06-01 13:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 13:43:11 --> Helper loaded: url_helper
DEBUG - 2011-06-01 13:43:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 13:43:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 13:43:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 13:43:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 13:43:11 --> Final output sent to browser
DEBUG - 2011-06-01 13:43:11 --> Total execution time: 0.1117
DEBUG - 2011-06-01 13:43:15 --> Config Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Hooks Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Utf8 Class Initialized
DEBUG - 2011-06-01 13:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 13:43:15 --> URI Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Router Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Output Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Input Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 13:43:15 --> Language Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Loader Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Controller Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Model Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Model Class Initialized
DEBUG - 2011-06-01 13:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 13:43:15 --> Database Driver Class Initialized
DEBUG - 2011-06-01 13:43:16 --> Final output sent to browser
DEBUG - 2011-06-01 13:43:16 --> Total execution time: 0.6959
DEBUG - 2011-06-01 13:58:37 --> Config Class Initialized
DEBUG - 2011-06-01 13:58:37 --> Hooks Class Initialized
DEBUG - 2011-06-01 13:58:37 --> Utf8 Class Initialized
DEBUG - 2011-06-01 13:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 13:58:37 --> URI Class Initialized
DEBUG - 2011-06-01 13:58:37 --> Router Class Initialized
DEBUG - 2011-06-01 13:58:37 --> No URI present. Default controller set.
DEBUG - 2011-06-01 13:58:37 --> Output Class Initialized
DEBUG - 2011-06-01 13:58:37 --> Input Class Initialized
DEBUG - 2011-06-01 13:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 13:58:37 --> Language Class Initialized
DEBUG - 2011-06-01 13:58:37 --> Loader Class Initialized
DEBUG - 2011-06-01 13:58:37 --> Controller Class Initialized
DEBUG - 2011-06-01 13:58:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-01 13:58:37 --> Helper loaded: url_helper
DEBUG - 2011-06-01 13:58:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 13:58:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 13:58:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 13:58:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 13:58:37 --> Final output sent to browser
DEBUG - 2011-06-01 13:58:37 --> Total execution time: 0.5051
DEBUG - 2011-06-01 14:00:14 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:14 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:14 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:14 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:14 --> Router Class Initialized
DEBUG - 2011-06-01 14:00:14 --> Output Class Initialized
DEBUG - 2011-06-01 14:00:14 --> Input Class Initialized
DEBUG - 2011-06-01 14:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 14:00:14 --> Language Class Initialized
DEBUG - 2011-06-01 14:00:14 --> Loader Class Initialized
DEBUG - 2011-06-01 14:00:14 --> Controller Class Initialized
ERROR - 2011-06-01 14:00:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 14:00:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 14:00:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 14:00:15 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:15 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 14:00:15 --> Database Driver Class Initialized
DEBUG - 2011-06-01 14:00:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 14:00:16 --> Helper loaded: url_helper
DEBUG - 2011-06-01 14:00:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 14:00:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 14:00:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 14:00:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 14:00:16 --> Final output sent to browser
DEBUG - 2011-06-01 14:00:16 --> Total execution time: 1.6628
DEBUG - 2011-06-01 14:00:17 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:17 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Router Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Output Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Input Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 14:00:17 --> Language Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Loader Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Controller Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 14:00:17 --> Database Driver Class Initialized
DEBUG - 2011-06-01 14:00:18 --> Final output sent to browser
DEBUG - 2011-06-01 14:00:18 --> Total execution time: 0.7189
DEBUG - 2011-06-01 14:00:18 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:18 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:18 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:18 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:18 --> Router Class Initialized
ERROR - 2011-06-01 14:00:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 14:00:42 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:42 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Router Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Output Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Input Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 14:00:42 --> Language Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Loader Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Controller Class Initialized
ERROR - 2011-06-01 14:00:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 14:00:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 14:00:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 14:00:42 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 14:00:42 --> Database Driver Class Initialized
DEBUG - 2011-06-01 14:00:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 14:00:42 --> Helper loaded: url_helper
DEBUG - 2011-06-01 14:00:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 14:00:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 14:00:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 14:00:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 14:00:42 --> Final output sent to browser
DEBUG - 2011-06-01 14:00:42 --> Total execution time: 0.0290
DEBUG - 2011-06-01 14:00:43 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:43 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Router Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Output Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Input Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 14:00:43 --> Language Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Loader Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Controller Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 14:00:43 --> Database Driver Class Initialized
DEBUG - 2011-06-01 14:00:43 --> Final output sent to browser
DEBUG - 2011-06-01 14:00:43 --> Total execution time: 0.5977
DEBUG - 2011-06-01 14:00:45 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:45 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:45 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:45 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:45 --> Router Class Initialized
ERROR - 2011-06-01 14:00:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 14:00:46 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:46 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Router Class Initialized
ERROR - 2011-06-01 14:00:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-01 14:00:46 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:46 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Router Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Output Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Input Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 14:00:46 --> Language Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Loader Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Controller Class Initialized
ERROR - 2011-06-01 14:00:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 14:00:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 14:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 14:00:46 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 14:00:46 --> Database Driver Class Initialized
DEBUG - 2011-06-01 14:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 14:00:46 --> Helper loaded: url_helper
DEBUG - 2011-06-01 14:00:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 14:00:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 14:00:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 14:00:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 14:00:46 --> Final output sent to browser
DEBUG - 2011-06-01 14:00:46 --> Total execution time: 0.0286
DEBUG - 2011-06-01 14:00:50 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:50 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Router Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Output Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Input Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 14:00:50 --> Language Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Loader Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Controller Class Initialized
ERROR - 2011-06-01 14:00:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 14:00:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 14:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 14:00:50 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 14:00:50 --> Database Driver Class Initialized
DEBUG - 2011-06-01 14:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 14:00:50 --> Helper loaded: url_helper
DEBUG - 2011-06-01 14:00:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 14:00:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 14:00:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 14:00:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 14:00:50 --> Final output sent to browser
DEBUG - 2011-06-01 14:00:50 --> Total execution time: 0.0687
DEBUG - 2011-06-01 14:00:50 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:50 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Router Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Output Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Input Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 14:00:50 --> Language Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Loader Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Controller Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Model Class Initialized
DEBUG - 2011-06-01 14:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 14:00:50 --> Database Driver Class Initialized
DEBUG - 2011-06-01 14:00:51 --> Final output sent to browser
DEBUG - 2011-06-01 14:00:51 --> Total execution time: 0.8232
DEBUG - 2011-06-01 14:00:52 --> Config Class Initialized
DEBUG - 2011-06-01 14:00:52 --> Hooks Class Initialized
DEBUG - 2011-06-01 14:00:52 --> Utf8 Class Initialized
DEBUG - 2011-06-01 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 14:00:52 --> URI Class Initialized
DEBUG - 2011-06-01 14:00:52 --> Router Class Initialized
ERROR - 2011-06-01 14:00:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 16:22:32 --> Config Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Hooks Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Utf8 Class Initialized
DEBUG - 2011-06-01 16:22:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 16:22:32 --> URI Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Router Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Output Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Input Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 16:22:32 --> Language Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Loader Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Controller Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Model Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Model Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Model Class Initialized
DEBUG - 2011-06-01 16:22:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 16:22:32 --> Database Driver Class Initialized
DEBUG - 2011-06-01 16:22:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 16:22:33 --> Helper loaded: url_helper
DEBUG - 2011-06-01 16:22:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 16:22:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 16:22:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 16:22:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 16:22:33 --> Final output sent to browser
DEBUG - 2011-06-01 16:22:33 --> Total execution time: 0.8215
DEBUG - 2011-06-01 16:22:35 --> Config Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Hooks Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Utf8 Class Initialized
DEBUG - 2011-06-01 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 16:22:35 --> URI Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Router Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Output Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Input Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 16:22:35 --> Language Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Loader Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Controller Class Initialized
ERROR - 2011-06-01 16:22:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 16:22:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 16:22:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 16:22:35 --> Model Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Model Class Initialized
DEBUG - 2011-06-01 16:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 16:22:35 --> Database Driver Class Initialized
DEBUG - 2011-06-01 16:22:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 16:22:35 --> Helper loaded: url_helper
DEBUG - 2011-06-01 16:22:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 16:22:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 16:22:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 16:22:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 16:22:35 --> Final output sent to browser
DEBUG - 2011-06-01 16:22:35 --> Total execution time: 0.0873
DEBUG - 2011-06-01 16:41:41 --> Config Class Initialized
DEBUG - 2011-06-01 16:41:41 --> Hooks Class Initialized
DEBUG - 2011-06-01 16:41:41 --> Utf8 Class Initialized
DEBUG - 2011-06-01 16:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 16:41:41 --> URI Class Initialized
DEBUG - 2011-06-01 16:41:41 --> Router Class Initialized
DEBUG - 2011-06-01 16:41:41 --> No URI present. Default controller set.
DEBUG - 2011-06-01 16:41:41 --> Output Class Initialized
DEBUG - 2011-06-01 16:41:41 --> Input Class Initialized
DEBUG - 2011-06-01 16:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 16:41:41 --> Language Class Initialized
DEBUG - 2011-06-01 16:41:41 --> Loader Class Initialized
DEBUG - 2011-06-01 16:41:41 --> Controller Class Initialized
DEBUG - 2011-06-01 16:41:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-01 16:41:41 --> Helper loaded: url_helper
DEBUG - 2011-06-01 16:41:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 16:41:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 16:41:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 16:41:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 16:41:41 --> Final output sent to browser
DEBUG - 2011-06-01 16:41:41 --> Total execution time: 0.1213
DEBUG - 2011-06-01 16:50:38 --> Config Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Hooks Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Utf8 Class Initialized
DEBUG - 2011-06-01 16:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 16:50:38 --> URI Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Router Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Output Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Input Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 16:50:38 --> Language Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Loader Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Controller Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Model Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Model Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Model Class Initialized
DEBUG - 2011-06-01 16:50:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 16:50:38 --> Database Driver Class Initialized
DEBUG - 2011-06-01 16:50:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 16:50:39 --> Helper loaded: url_helper
DEBUG - 2011-06-01 16:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 16:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 16:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 16:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 16:50:39 --> Final output sent to browser
DEBUG - 2011-06-01 16:50:39 --> Total execution time: 1.2159
DEBUG - 2011-06-01 16:51:31 --> Config Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Hooks Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Utf8 Class Initialized
DEBUG - 2011-06-01 16:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 16:51:31 --> URI Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Router Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Output Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Input Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 16:51:31 --> Language Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Loader Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Controller Class Initialized
ERROR - 2011-06-01 16:51:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 16:51:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 16:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 16:51:31 --> Model Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Model Class Initialized
DEBUG - 2011-06-01 16:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 16:51:31 --> Database Driver Class Initialized
DEBUG - 2011-06-01 16:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 16:51:31 --> Helper loaded: url_helper
DEBUG - 2011-06-01 16:51:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 16:51:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 16:51:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 16:51:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 16:51:31 --> Final output sent to browser
DEBUG - 2011-06-01 16:51:31 --> Total execution time: 0.0941
DEBUG - 2011-06-01 17:48:23 --> Config Class Initialized
DEBUG - 2011-06-01 17:48:24 --> Hooks Class Initialized
DEBUG - 2011-06-01 17:48:24 --> Utf8 Class Initialized
DEBUG - 2011-06-01 17:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 17:48:24 --> URI Class Initialized
DEBUG - 2011-06-01 17:48:24 --> Router Class Initialized
ERROR - 2011-06-01 17:48:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-01 17:49:20 --> Config Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Hooks Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Utf8 Class Initialized
DEBUG - 2011-06-01 17:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 17:49:20 --> URI Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Router Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Output Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Input Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 17:49:20 --> Language Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Loader Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Controller Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Model Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Model Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Model Class Initialized
DEBUG - 2011-06-01 17:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 17:49:20 --> Database Driver Class Initialized
DEBUG - 2011-06-01 17:49:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 17:49:21 --> Helper loaded: url_helper
DEBUG - 2011-06-01 17:49:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 17:49:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 17:49:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 17:49:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 17:49:21 --> Final output sent to browser
DEBUG - 2011-06-01 17:49:21 --> Total execution time: 0.8850
DEBUG - 2011-06-01 17:50:18 --> Config Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Hooks Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Utf8 Class Initialized
DEBUG - 2011-06-01 17:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 17:50:18 --> URI Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Router Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Output Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Input Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 17:50:18 --> Language Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Loader Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Controller Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Model Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Model Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Model Class Initialized
DEBUG - 2011-06-01 17:50:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 17:50:18 --> Database Driver Class Initialized
DEBUG - 2011-06-01 17:50:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 17:50:18 --> Helper loaded: url_helper
DEBUG - 2011-06-01 17:50:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 17:50:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 17:50:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 17:50:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 17:50:18 --> Final output sent to browser
DEBUG - 2011-06-01 17:50:18 --> Total execution time: 0.0428
DEBUG - 2011-06-01 17:50:19 --> Config Class Initialized
DEBUG - 2011-06-01 17:50:19 --> Hooks Class Initialized
DEBUG - 2011-06-01 17:50:19 --> Utf8 Class Initialized
DEBUG - 2011-06-01 17:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 17:50:19 --> URI Class Initialized
DEBUG - 2011-06-01 17:50:19 --> Router Class Initialized
DEBUG - 2011-06-01 17:50:20 --> Output Class Initialized
DEBUG - 2011-06-01 17:50:20 --> Input Class Initialized
DEBUG - 2011-06-01 17:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 17:50:20 --> Language Class Initialized
DEBUG - 2011-06-01 17:50:20 --> Loader Class Initialized
DEBUG - 2011-06-01 17:50:20 --> Controller Class Initialized
ERROR - 2011-06-01 17:50:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 17:50:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 17:50:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 17:50:21 --> Model Class Initialized
DEBUG - 2011-06-01 17:50:21 --> Model Class Initialized
DEBUG - 2011-06-01 17:50:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 17:50:21 --> Database Driver Class Initialized
DEBUG - 2011-06-01 17:50:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 17:50:21 --> Helper loaded: url_helper
DEBUG - 2011-06-01 17:50:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 17:50:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 17:50:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 17:50:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 17:50:21 --> Final output sent to browser
DEBUG - 2011-06-01 17:50:21 --> Total execution time: 1.5908
DEBUG - 2011-06-01 18:11:59 --> Config Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Hooks Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Utf8 Class Initialized
DEBUG - 2011-06-01 18:11:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 18:11:59 --> URI Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Router Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Output Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Input Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 18:11:59 --> Language Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Loader Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Controller Class Initialized
ERROR - 2011-06-01 18:11:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 18:11:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 18:11:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 18:11:59 --> Model Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Model Class Initialized
DEBUG - 2011-06-01 18:11:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 18:11:59 --> Database Driver Class Initialized
DEBUG - 2011-06-01 18:11:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 18:11:59 --> Helper loaded: url_helper
DEBUG - 2011-06-01 18:11:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 18:11:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 18:11:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 18:11:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 18:11:59 --> Final output sent to browser
DEBUG - 2011-06-01 18:11:59 --> Total execution time: 0.0457
DEBUG - 2011-06-01 19:18:00 --> Config Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Hooks Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Utf8 Class Initialized
DEBUG - 2011-06-01 19:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 19:18:00 --> URI Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Router Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Output Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Input Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 19:18:00 --> Language Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Loader Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Controller Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Model Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Model Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Model Class Initialized
DEBUG - 2011-06-01 19:18:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 19:18:00 --> Database Driver Class Initialized
DEBUG - 2011-06-01 19:18:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 19:18:02 --> Helper loaded: url_helper
DEBUG - 2011-06-01 19:18:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 19:18:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 19:18:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 19:18:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 19:18:02 --> Final output sent to browser
DEBUG - 2011-06-01 19:18:02 --> Total execution time: 1.8331
DEBUG - 2011-06-01 19:18:03 --> Config Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Hooks Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Utf8 Class Initialized
DEBUG - 2011-06-01 19:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 19:18:03 --> URI Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Router Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Output Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Input Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 19:18:03 --> Language Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Loader Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Controller Class Initialized
ERROR - 2011-06-01 19:18:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 19:18:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 19:18:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 19:18:03 --> Model Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Model Class Initialized
DEBUG - 2011-06-01 19:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 19:18:03 --> Database Driver Class Initialized
DEBUG - 2011-06-01 19:18:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 19:18:03 --> Helper loaded: url_helper
DEBUG - 2011-06-01 19:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 19:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 19:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 19:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 19:18:03 --> Final output sent to browser
DEBUG - 2011-06-01 19:18:03 --> Total execution time: 0.0920
DEBUG - 2011-06-01 19:53:06 --> Config Class Initialized
DEBUG - 2011-06-01 19:53:06 --> Hooks Class Initialized
DEBUG - 2011-06-01 19:53:06 --> Utf8 Class Initialized
DEBUG - 2011-06-01 19:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 19:53:06 --> URI Class Initialized
DEBUG - 2011-06-01 19:53:06 --> Router Class Initialized
DEBUG - 2011-06-01 19:53:06 --> No URI present. Default controller set.
DEBUG - 2011-06-01 19:53:06 --> Output Class Initialized
DEBUG - 2011-06-01 19:53:06 --> Input Class Initialized
DEBUG - 2011-06-01 19:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 19:53:06 --> Language Class Initialized
DEBUG - 2011-06-01 19:53:06 --> Loader Class Initialized
DEBUG - 2011-06-01 19:53:06 --> Controller Class Initialized
DEBUG - 2011-06-01 19:53:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-01 19:53:06 --> Helper loaded: url_helper
DEBUG - 2011-06-01 19:53:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 19:53:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 19:53:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 19:53:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 19:53:06 --> Final output sent to browser
DEBUG - 2011-06-01 19:53:06 --> Total execution time: 0.2327
DEBUG - 2011-06-01 20:48:00 --> Config Class Initialized
DEBUG - 2011-06-01 20:48:00 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:48:00 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:48:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:48:00 --> URI Class Initialized
DEBUG - 2011-06-01 20:48:00 --> Router Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Output Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Input Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:48:01 --> Language Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Loader Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Controller Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Model Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Model Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Model Class Initialized
DEBUG - 2011-06-01 20:48:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:48:01 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:48:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 20:48:01 --> Helper loaded: url_helper
DEBUG - 2011-06-01 20:48:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 20:48:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 20:48:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 20:48:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 20:48:01 --> Final output sent to browser
DEBUG - 2011-06-01 20:48:01 --> Total execution time: 0.5907
DEBUG - 2011-06-01 20:48:03 --> Config Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:48:03 --> URI Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Router Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Output Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Input Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:48:03 --> Language Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Loader Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Controller Class Initialized
ERROR - 2011-06-01 20:48:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 20:48:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 20:48:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:48:03 --> Model Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Model Class Initialized
DEBUG - 2011-06-01 20:48:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:48:03 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:48:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:48:03 --> Helper loaded: url_helper
DEBUG - 2011-06-01 20:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 20:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 20:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 20:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 20:48:03 --> Final output sent to browser
DEBUG - 2011-06-01 20:48:03 --> Total execution time: 0.1422
DEBUG - 2011-06-01 20:49:44 --> Config Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:49:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:49:44 --> URI Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Router Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Output Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Input Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:49:44 --> Language Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Loader Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Controller Class Initialized
ERROR - 2011-06-01 20:49:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 20:49:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 20:49:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:49:44 --> Model Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Model Class Initialized
DEBUG - 2011-06-01 20:49:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:49:44 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:49:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:49:44 --> Helper loaded: url_helper
DEBUG - 2011-06-01 20:49:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 20:49:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 20:49:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 20:49:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 20:49:44 --> Final output sent to browser
DEBUG - 2011-06-01 20:49:44 --> Total execution time: 0.0297
DEBUG - 2011-06-01 20:49:45 --> Config Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:49:45 --> URI Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Router Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Output Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Input Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:49:45 --> Language Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Loader Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Controller Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Model Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Model Class Initialized
DEBUG - 2011-06-01 20:49:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:49:45 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:49:46 --> Final output sent to browser
DEBUG - 2011-06-01 20:49:46 --> Total execution time: 0.6034
DEBUG - 2011-06-01 20:49:48 --> Config Class Initialized
DEBUG - 2011-06-01 20:49:48 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:49:48 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:49:48 --> URI Class Initialized
DEBUG - 2011-06-01 20:49:48 --> Router Class Initialized
ERROR - 2011-06-01 20:49:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 20:49:49 --> Config Class Initialized
DEBUG - 2011-06-01 20:49:49 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:49:49 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:49:49 --> URI Class Initialized
DEBUG - 2011-06-01 20:49:49 --> Router Class Initialized
ERROR - 2011-06-01 20:49:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 20:50:32 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:32 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Router Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Output Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Input Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:50:32 --> Language Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Loader Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Controller Class Initialized
ERROR - 2011-06-01 20:50:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 20:50:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 20:50:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:50:32 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:50:32 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:50:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:50:32 --> Helper loaded: url_helper
DEBUG - 2011-06-01 20:50:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 20:50:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 20:50:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 20:50:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 20:50:32 --> Final output sent to browser
DEBUG - 2011-06-01 20:50:32 --> Total execution time: 0.0354
DEBUG - 2011-06-01 20:50:33 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:33 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Router Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Output Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Input Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:50:33 --> Language Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Loader Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Controller Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:50:33 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:50:34 --> Final output sent to browser
DEBUG - 2011-06-01 20:50:34 --> Total execution time: 0.5750
DEBUG - 2011-06-01 20:50:35 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:35 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:35 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:35 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:35 --> Router Class Initialized
ERROR - 2011-06-01 20:50:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 20:50:40 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:40 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Router Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Output Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Input Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:50:40 --> Language Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Loader Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Controller Class Initialized
ERROR - 2011-06-01 20:50:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 20:50:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 20:50:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:50:40 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:50:40 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:50:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:50:40 --> Helper loaded: url_helper
DEBUG - 2011-06-01 20:50:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 20:50:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 20:50:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 20:50:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 20:50:40 --> Final output sent to browser
DEBUG - 2011-06-01 20:50:40 --> Total execution time: 0.0307
DEBUG - 2011-06-01 20:50:41 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:41 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Router Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Output Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Input Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:50:41 --> Language Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Loader Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Controller Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:50:41 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:50:41 --> Final output sent to browser
DEBUG - 2011-06-01 20:50:41 --> Total execution time: 0.5058
DEBUG - 2011-06-01 20:50:43 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:43 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:43 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:43 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:43 --> Router Class Initialized
ERROR - 2011-06-01 20:50:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 20:50:49 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:49 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Router Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Output Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Input Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:50:49 --> Language Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Loader Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Controller Class Initialized
ERROR - 2011-06-01 20:50:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 20:50:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 20:50:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:50:49 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:50:49 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:50:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:50:49 --> Helper loaded: url_helper
DEBUG - 2011-06-01 20:50:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 20:50:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 20:50:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 20:50:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 20:50:49 --> Final output sent to browser
DEBUG - 2011-06-01 20:50:49 --> Total execution time: 0.0351
DEBUG - 2011-06-01 20:50:49 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:49 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Router Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Output Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Input Class Initialized
DEBUG - 2011-06-01 20:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:50:49 --> Language Class Initialized
DEBUG - 2011-06-01 20:50:50 --> Loader Class Initialized
DEBUG - 2011-06-01 20:50:50 --> Controller Class Initialized
DEBUG - 2011-06-01 20:50:50 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:50 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:50:50 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:50:50 --> Final output sent to browser
DEBUG - 2011-06-01 20:50:50 --> Total execution time: 0.5060
DEBUG - 2011-06-01 20:50:52 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:52 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:52 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:52 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:52 --> Router Class Initialized
ERROR - 2011-06-01 20:50:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 20:50:58 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:58 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Router Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Output Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Input Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:50:58 --> Language Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Loader Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Controller Class Initialized
ERROR - 2011-06-01 20:50:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 20:50:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 20:50:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:50:58 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:50:58 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:50:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:50:58 --> Helper loaded: url_helper
DEBUG - 2011-06-01 20:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 20:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 20:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 20:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 20:50:58 --> Final output sent to browser
DEBUG - 2011-06-01 20:50:58 --> Total execution time: 0.0292
DEBUG - 2011-06-01 20:50:59 --> Config Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:50:59 --> URI Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Router Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Output Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Input Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:50:59 --> Language Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Loader Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Controller Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Model Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:50:59 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:50:59 --> Final output sent to browser
DEBUG - 2011-06-01 20:50:59 --> Total execution time: 0.6330
DEBUG - 2011-06-01 20:51:01 --> Config Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:51:01 --> URI Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Router Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Output Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Input Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 20:51:01 --> Language Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Loader Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Controller Class Initialized
ERROR - 2011-06-01 20:51:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-01 20:51:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-01 20:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:51:01 --> Model Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Model Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 20:51:01 --> Database Driver Class Initialized
DEBUG - 2011-06-01 20:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-01 20:51:01 --> Helper loaded: url_helper
DEBUG - 2011-06-01 20:51:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 20:51:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 20:51:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 20:51:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 20:51:01 --> Final output sent to browser
DEBUG - 2011-06-01 20:51:01 --> Total execution time: 0.0294
DEBUG - 2011-06-01 20:51:01 --> Config Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Hooks Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Utf8 Class Initialized
DEBUG - 2011-06-01 20:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 20:51:01 --> URI Class Initialized
DEBUG - 2011-06-01 20:51:01 --> Router Class Initialized
ERROR - 2011-06-01 20:51:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 21:34:01 --> Config Class Initialized
DEBUG - 2011-06-01 21:34:01 --> Hooks Class Initialized
DEBUG - 2011-06-01 21:34:01 --> Utf8 Class Initialized
DEBUG - 2011-06-01 21:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 21:34:01 --> URI Class Initialized
DEBUG - 2011-06-01 21:34:01 --> Router Class Initialized
ERROR - 2011-06-01 21:34:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-01 21:34:02 --> Config Class Initialized
DEBUG - 2011-06-01 21:34:02 --> Hooks Class Initialized
DEBUG - 2011-06-01 21:34:02 --> Utf8 Class Initialized
DEBUG - 2011-06-01 21:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 21:34:02 --> URI Class Initialized
DEBUG - 2011-06-01 21:34:02 --> Router Class Initialized
DEBUG - 2011-06-01 21:34:02 --> No URI present. Default controller set.
DEBUG - 2011-06-01 21:34:02 --> Output Class Initialized
DEBUG - 2011-06-01 21:34:02 --> Input Class Initialized
DEBUG - 2011-06-01 21:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 21:34:02 --> Language Class Initialized
DEBUG - 2011-06-01 21:34:02 --> Loader Class Initialized
DEBUG - 2011-06-01 21:34:02 --> Controller Class Initialized
DEBUG - 2011-06-01 21:34:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-01 21:34:02 --> Helper loaded: url_helper
DEBUG - 2011-06-01 21:34:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 21:34:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 21:34:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 21:34:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 21:34:02 --> Final output sent to browser
DEBUG - 2011-06-01 21:34:02 --> Total execution time: 0.1832
DEBUG - 2011-06-01 23:33:56 --> Config Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Hooks Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Utf8 Class Initialized
DEBUG - 2011-06-01 23:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 23:33:56 --> URI Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Router Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Output Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Input Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-01 23:33:56 --> Language Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Loader Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Controller Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Model Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Model Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Model Class Initialized
DEBUG - 2011-06-01 23:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-01 23:33:56 --> Database Driver Class Initialized
DEBUG - 2011-06-01 23:33:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-01 23:33:56 --> Helper loaded: url_helper
DEBUG - 2011-06-01 23:33:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-01 23:33:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-01 23:33:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-01 23:33:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-01 23:33:56 --> Final output sent to browser
DEBUG - 2011-06-01 23:33:56 --> Total execution time: 0.5471
DEBUG - 2011-06-01 23:33:59 --> Config Class Initialized
DEBUG - 2011-06-01 23:33:59 --> Hooks Class Initialized
DEBUG - 2011-06-01 23:33:59 --> Utf8 Class Initialized
DEBUG - 2011-06-01 23:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 23:33:59 --> URI Class Initialized
DEBUG - 2011-06-01 23:33:59 --> Router Class Initialized
ERROR - 2011-06-01 23:33:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 23:34:00 --> Config Class Initialized
DEBUG - 2011-06-01 23:34:00 --> Hooks Class Initialized
DEBUG - 2011-06-01 23:34:00 --> Utf8 Class Initialized
DEBUG - 2011-06-01 23:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 23:34:00 --> URI Class Initialized
DEBUG - 2011-06-01 23:34:00 --> Router Class Initialized
ERROR - 2011-06-01 23:34:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-01 23:34:01 --> Config Class Initialized
DEBUG - 2011-06-01 23:34:01 --> Hooks Class Initialized
DEBUG - 2011-06-01 23:34:01 --> Utf8 Class Initialized
DEBUG - 2011-06-01 23:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-01 23:34:01 --> URI Class Initialized
DEBUG - 2011-06-01 23:34:01 --> Router Class Initialized
ERROR - 2011-06-01 23:34:01 --> 404 Page Not Found --> favicon.ico

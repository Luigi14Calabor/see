<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-14 01:57:08 --> Config Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Hooks Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Utf8 Class Initialized
DEBUG - 2011-05-14 01:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 01:57:08 --> URI Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Router Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Output Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Input Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 01:57:08 --> Language Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Loader Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Controller Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Model Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Model Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Model Class Initialized
DEBUG - 2011-05-14 01:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 01:57:08 --> Database Driver Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Config Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Hooks Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Utf8 Class Initialized
DEBUG - 2011-05-14 01:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 01:57:15 --> URI Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Router Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Output Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Input Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 01:57:15 --> Language Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Loader Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Controller Class Initialized
ERROR - 2011-05-14 01:57:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 01:57:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 01:57:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 01:57:15 --> Model Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Model Class Initialized
DEBUG - 2011-05-14 01:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 01:57:15 --> Database Driver Class Initialized
DEBUG - 2011-05-14 01:57:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 01:57:16 --> Helper loaded: url_helper
DEBUG - 2011-05-14 01:57:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 01:57:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 01:57:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 01:57:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 01:57:16 --> Final output sent to browser
DEBUG - 2011-05-14 01:57:16 --> Total execution time: 0.4401
DEBUG - 2011-05-14 01:57:17 --> Config Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Hooks Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Utf8 Class Initialized
DEBUG - 2011-05-14 01:57:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 01:57:17 --> URI Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Router Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Output Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Input Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 01:57:17 --> Language Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Loader Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Controller Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Model Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Model Class Initialized
DEBUG - 2011-05-14 01:57:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 01:57:17 --> Database Driver Class Initialized
DEBUG - 2011-05-14 01:57:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 01:57:18 --> Helper loaded: url_helper
DEBUG - 2011-05-14 01:57:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 01:57:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 01:57:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 01:57:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 01:57:18 --> Final output sent to browser
DEBUG - 2011-05-14 01:57:18 --> Total execution time: 10.2982
DEBUG - 2011-05-14 01:57:19 --> Final output sent to browser
DEBUG - 2011-05-14 01:57:19 --> Total execution time: 1.9380
DEBUG - 2011-05-14 01:57:21 --> Config Class Initialized
DEBUG - 2011-05-14 01:57:21 --> Hooks Class Initialized
DEBUG - 2011-05-14 01:57:21 --> Utf8 Class Initialized
DEBUG - 2011-05-14 01:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 01:57:21 --> URI Class Initialized
DEBUG - 2011-05-14 01:57:21 --> Router Class Initialized
ERROR - 2011-05-14 01:57:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 10:01:14 --> Config Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:01:14 --> URI Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Router Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Output Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Input Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 10:01:14 --> Language Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Loader Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Controller Class Initialized
ERROR - 2011-05-14 10:01:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 10:01:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 10:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 10:01:14 --> Model Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Model Class Initialized
DEBUG - 2011-05-14 10:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 10:01:14 --> Database Driver Class Initialized
DEBUG - 2011-05-14 10:01:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 10:01:16 --> Helper loaded: url_helper
DEBUG - 2011-05-14 10:01:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 10:01:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 10:01:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 10:01:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 10:01:16 --> Final output sent to browser
DEBUG - 2011-05-14 10:01:16 --> Total execution time: 1.8567
DEBUG - 2011-05-14 10:01:16 --> Config Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:01:16 --> URI Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Router Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Output Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Input Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 10:01:16 --> Language Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Loader Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Controller Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Model Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Model Class Initialized
DEBUG - 2011-05-14 10:01:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 10:01:16 --> Database Driver Class Initialized
DEBUG - 2011-05-14 10:01:17 --> Final output sent to browser
DEBUG - 2011-05-14 10:01:17 --> Total execution time: 1.0664
DEBUG - 2011-05-14 10:01:18 --> Config Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:01:18 --> URI Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Router Class Initialized
ERROR - 2011-05-14 10:01:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 10:01:18 --> Config Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:01:18 --> URI Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Router Class Initialized
ERROR - 2011-05-14 10:01:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 10:01:18 --> Config Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:01:18 --> URI Class Initialized
DEBUG - 2011-05-14 10:01:18 --> Router Class Initialized
ERROR - 2011-05-14 10:01:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 10:35:13 --> Config Class Initialized
DEBUG - 2011-05-14 10:35:13 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:35:13 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:35:14 --> URI Class Initialized
DEBUG - 2011-05-14 10:35:14 --> Router Class Initialized
DEBUG - 2011-05-14 10:35:14 --> Output Class Initialized
DEBUG - 2011-05-14 10:35:14 --> Input Class Initialized
DEBUG - 2011-05-14 10:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 10:35:14 --> Language Class Initialized
DEBUG - 2011-05-14 10:35:15 --> Loader Class Initialized
DEBUG - 2011-05-14 10:35:15 --> Controller Class Initialized
DEBUG - 2011-05-14 10:35:15 --> Model Class Initialized
DEBUG - 2011-05-14 10:35:15 --> Model Class Initialized
DEBUG - 2011-05-14 10:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 10:35:15 --> Database Driver Class Initialized
DEBUG - 2011-05-14 10:35:16 --> Final output sent to browser
DEBUG - 2011-05-14 10:35:16 --> Total execution time: 2.9414
DEBUG - 2011-05-14 10:59:09 --> Config Class Initialized
DEBUG - 2011-05-14 10:59:09 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:59:09 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:59:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:59:09 --> URI Class Initialized
DEBUG - 2011-05-14 10:59:09 --> Router Class Initialized
DEBUG - 2011-05-14 10:59:09 --> Output Class Initialized
DEBUG - 2011-05-14 10:59:09 --> Input Class Initialized
DEBUG - 2011-05-14 10:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 10:59:09 --> Language Class Initialized
DEBUG - 2011-05-14 10:59:10 --> Loader Class Initialized
DEBUG - 2011-05-14 10:59:10 --> Controller Class Initialized
DEBUG - 2011-05-14 10:59:10 --> Model Class Initialized
DEBUG - 2011-05-14 10:59:10 --> Model Class Initialized
DEBUG - 2011-05-14 10:59:10 --> Model Class Initialized
DEBUG - 2011-05-14 10:59:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 10:59:10 --> Database Driver Class Initialized
DEBUG - 2011-05-14 10:59:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 10:59:10 --> Helper loaded: url_helper
DEBUG - 2011-05-14 10:59:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 10:59:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 10:59:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 10:59:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 10:59:10 --> Final output sent to browser
DEBUG - 2011-05-14 10:59:10 --> Total execution time: 1.0309
DEBUG - 2011-05-14 10:59:12 --> Config Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:59:12 --> URI Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Router Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Output Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Input Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 10:59:12 --> Language Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Loader Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Controller Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Model Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Model Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Model Class Initialized
DEBUG - 2011-05-14 10:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 10:59:12 --> Database Driver Class Initialized
DEBUG - 2011-05-14 10:59:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 10:59:12 --> Helper loaded: url_helper
DEBUG - 2011-05-14 10:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 10:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 10:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 10:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 10:59:12 --> Final output sent to browser
DEBUG - 2011-05-14 10:59:12 --> Total execution time: 0.0620
DEBUG - 2011-05-14 10:59:13 --> Config Class Initialized
DEBUG - 2011-05-14 10:59:13 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:59:13 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:59:13 --> URI Class Initialized
DEBUG - 2011-05-14 10:59:13 --> Router Class Initialized
ERROR - 2011-05-14 10:59:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 10:59:13 --> Config Class Initialized
DEBUG - 2011-05-14 10:59:13 --> Hooks Class Initialized
DEBUG - 2011-05-14 10:59:13 --> Utf8 Class Initialized
DEBUG - 2011-05-14 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 10:59:13 --> URI Class Initialized
DEBUG - 2011-05-14 10:59:13 --> Router Class Initialized
ERROR - 2011-05-14 10:59:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 11:50:33 --> Config Class Initialized
DEBUG - 2011-05-14 11:50:33 --> Hooks Class Initialized
DEBUG - 2011-05-14 11:50:33 --> Utf8 Class Initialized
DEBUG - 2011-05-14 11:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 11:50:33 --> URI Class Initialized
DEBUG - 2011-05-14 11:50:33 --> Router Class Initialized
ERROR - 2011-05-14 11:50:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-14 11:57:54 --> Config Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Hooks Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Utf8 Class Initialized
DEBUG - 2011-05-14 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 11:57:54 --> URI Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Router Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Output Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Input Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 11:57:54 --> Language Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Loader Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Controller Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Model Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Model Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Model Class Initialized
DEBUG - 2011-05-14 11:57:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 11:57:54 --> Database Driver Class Initialized
DEBUG - 2011-05-14 11:57:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 11:57:54 --> Helper loaded: url_helper
DEBUG - 2011-05-14 11:57:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 11:57:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 11:57:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 11:57:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 11:57:54 --> Final output sent to browser
DEBUG - 2011-05-14 11:57:54 --> Total execution time: 0.6721
DEBUG - 2011-05-14 11:57:57 --> Config Class Initialized
DEBUG - 2011-05-14 11:57:57 --> Hooks Class Initialized
DEBUG - 2011-05-14 11:57:57 --> Utf8 Class Initialized
DEBUG - 2011-05-14 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 11:57:57 --> URI Class Initialized
DEBUG - 2011-05-14 11:57:57 --> Router Class Initialized
ERROR - 2011-05-14 11:57:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 11:57:57 --> Config Class Initialized
DEBUG - 2011-05-14 11:57:57 --> Hooks Class Initialized
DEBUG - 2011-05-14 11:57:57 --> Utf8 Class Initialized
DEBUG - 2011-05-14 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 11:57:57 --> URI Class Initialized
DEBUG - 2011-05-14 11:57:57 --> Router Class Initialized
ERROR - 2011-05-14 11:57:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 11:57:58 --> Config Class Initialized
DEBUG - 2011-05-14 11:57:58 --> Hooks Class Initialized
DEBUG - 2011-05-14 11:57:58 --> Utf8 Class Initialized
DEBUG - 2011-05-14 11:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 11:57:58 --> URI Class Initialized
DEBUG - 2011-05-14 11:57:58 --> Router Class Initialized
ERROR - 2011-05-14 11:57:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 11:58:01 --> Config Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Hooks Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Utf8 Class Initialized
DEBUG - 2011-05-14 11:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 11:58:01 --> URI Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Router Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Output Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Input Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 11:58:01 --> Language Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Loader Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Controller Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Model Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Model Class Initialized
DEBUG - 2011-05-14 11:58:01 --> Model Class Initialized
DEBUG - 2011-05-14 11:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 11:58:02 --> Database Driver Class Initialized
DEBUG - 2011-05-14 11:58:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 11:58:02 --> Helper loaded: url_helper
DEBUG - 2011-05-14 11:58:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 11:58:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 11:58:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 11:58:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 11:58:02 --> Final output sent to browser
DEBUG - 2011-05-14 11:58:02 --> Total execution time: 0.3695
DEBUG - 2011-05-14 11:58:03 --> Config Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Hooks Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Utf8 Class Initialized
DEBUG - 2011-05-14 11:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 11:58:03 --> URI Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Router Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Output Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Input Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 11:58:03 --> Language Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Loader Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Controller Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Model Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Model Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Model Class Initialized
DEBUG - 2011-05-14 11:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 11:58:03 --> Database Driver Class Initialized
DEBUG - 2011-05-14 11:58:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 11:58:03 --> Helper loaded: url_helper
DEBUG - 2011-05-14 11:58:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 11:58:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 11:58:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 11:58:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 11:58:03 --> Final output sent to browser
DEBUG - 2011-05-14 11:58:03 --> Total execution time: 0.0435
DEBUG - 2011-05-14 12:02:10 --> Config Class Initialized
DEBUG - 2011-05-14 12:02:10 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:02:10 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:02:10 --> URI Class Initialized
DEBUG - 2011-05-14 12:02:10 --> Router Class Initialized
ERROR - 2011-05-14 12:02:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-14 12:02:46 --> Config Class Initialized
DEBUG - 2011-05-14 12:02:46 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:02:46 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:02:46 --> URI Class Initialized
DEBUG - 2011-05-14 12:02:46 --> Router Class Initialized
DEBUG - 2011-05-14 12:02:46 --> Output Class Initialized
DEBUG - 2011-05-14 12:02:47 --> Input Class Initialized
DEBUG - 2011-05-14 12:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:02:47 --> Language Class Initialized
DEBUG - 2011-05-14 12:02:47 --> Loader Class Initialized
DEBUG - 2011-05-14 12:02:47 --> Controller Class Initialized
ERROR - 2011-05-14 12:02:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 12:02:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 12:02:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 12:02:47 --> Model Class Initialized
DEBUG - 2011-05-14 12:02:47 --> Model Class Initialized
DEBUG - 2011-05-14 12:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:02:47 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:02:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 12:02:47 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:02:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:02:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:02:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:02:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:02:47 --> Final output sent to browser
DEBUG - 2011-05-14 12:02:47 --> Total execution time: 0.1079
DEBUG - 2011-05-14 12:40:33 --> Config Class Initialized
DEBUG - 2011-05-14 12:40:33 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:40:33 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:40:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:40:33 --> URI Class Initialized
DEBUG - 2011-05-14 12:40:33 --> Router Class Initialized
DEBUG - 2011-05-14 12:40:33 --> No URI present. Default controller set.
DEBUG - 2011-05-14 12:40:33 --> Output Class Initialized
DEBUG - 2011-05-14 12:40:33 --> Input Class Initialized
DEBUG - 2011-05-14 12:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:40:33 --> Language Class Initialized
DEBUG - 2011-05-14 12:40:33 --> Loader Class Initialized
DEBUG - 2011-05-14 12:40:33 --> Controller Class Initialized
DEBUG - 2011-05-14 12:40:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-14 12:40:33 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:40:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:40:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:40:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:40:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:40:33 --> Final output sent to browser
DEBUG - 2011-05-14 12:40:33 --> Total execution time: 0.7371
DEBUG - 2011-05-14 12:40:37 --> Config Class Initialized
DEBUG - 2011-05-14 12:40:37 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:40:37 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:40:37 --> URI Class Initialized
DEBUG - 2011-05-14 12:40:37 --> Router Class Initialized
ERROR - 2011-05-14 12:40:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 12:40:39 --> Config Class Initialized
DEBUG - 2011-05-14 12:40:39 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:40:39 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:40:39 --> URI Class Initialized
DEBUG - 2011-05-14 12:40:39 --> Router Class Initialized
ERROR - 2011-05-14 12:40:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 12:40:44 --> Config Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:40:44 --> URI Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Router Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Output Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Input Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:40:44 --> Language Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Loader Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Controller Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Model Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Model Class Initialized
DEBUG - 2011-05-14 12:40:44 --> Model Class Initialized
DEBUG - 2011-05-14 12:40:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:40:45 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:40:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:40:46 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:40:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:40:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:40:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:40:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:40:46 --> Final output sent to browser
DEBUG - 2011-05-14 12:40:46 --> Total execution time: 2.2928
DEBUG - 2011-05-14 12:41:13 --> Config Class Initialized
DEBUG - 2011-05-14 12:41:13 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:41:13 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:41:13 --> URI Class Initialized
DEBUG - 2011-05-14 12:41:13 --> Router Class Initialized
DEBUG - 2011-05-14 12:41:13 --> Output Class Initialized
DEBUG - 2011-05-14 12:41:14 --> Input Class Initialized
DEBUG - 2011-05-14 12:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:41:14 --> Language Class Initialized
DEBUG - 2011-05-14 12:41:14 --> Loader Class Initialized
DEBUG - 2011-05-14 12:41:14 --> Controller Class Initialized
DEBUG - 2011-05-14 12:41:14 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:14 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:14 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:41:14 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:41:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:41:14 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:41:14 --> Final output sent to browser
DEBUG - 2011-05-14 12:41:14 --> Total execution time: 0.4925
DEBUG - 2011-05-14 12:41:15 --> Config Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:41:15 --> URI Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Router Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Output Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Input Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:41:15 --> Language Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Loader Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Controller Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:41:15 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:41:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:41:15 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:41:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:41:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:41:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:41:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:41:15 --> Final output sent to browser
DEBUG - 2011-05-14 12:41:15 --> Total execution time: 0.0475
DEBUG - 2011-05-14 12:41:24 --> Config Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:41:24 --> URI Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Router Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Output Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Input Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:41:24 --> Language Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Loader Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Controller Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:41:24 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:41:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:41:24 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:41:24 --> Final output sent to browser
DEBUG - 2011-05-14 12:41:24 --> Total execution time: 0.1884
DEBUG - 2011-05-14 12:41:25 --> Config Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:41:25 --> URI Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Router Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Output Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Input Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:41:25 --> Language Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Loader Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Controller Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:41:25 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:41:25 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:41:25 --> Final output sent to browser
DEBUG - 2011-05-14 12:41:25 --> Total execution time: 0.0444
DEBUG - 2011-05-14 12:41:25 --> Config Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:41:25 --> URI Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Router Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Output Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Input Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:41:25 --> Language Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Loader Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Controller Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:41:25 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:41:25 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:41:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:41:25 --> Final output sent to browser
DEBUG - 2011-05-14 12:41:25 --> Total execution time: 0.0487
DEBUG - 2011-05-14 12:41:33 --> Config Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:41:33 --> URI Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Router Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Output Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Input Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:41:33 --> Language Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Loader Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Controller Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:41:33 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:41:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:41:33 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:41:33 --> Final output sent to browser
DEBUG - 2011-05-14 12:41:33 --> Total execution time: 0.2090
DEBUG - 2011-05-14 12:41:34 --> Config Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:41:34 --> URI Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Router Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Output Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Input Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:41:34 --> Language Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Loader Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Controller Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:41:34 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:41:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:41:34 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:41:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:41:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:41:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:41:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:41:34 --> Final output sent to browser
DEBUG - 2011-05-14 12:41:34 --> Total execution time: 0.0504
DEBUG - 2011-05-14 12:41:46 --> Config Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:41:46 --> URI Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Router Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Output Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Input Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:41:46 --> Language Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Loader Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Controller Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Model Class Initialized
DEBUG - 2011-05-14 12:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:41:46 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:41:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:41:47 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:41:47 --> Final output sent to browser
DEBUG - 2011-05-14 12:41:47 --> Total execution time: 0.9934
DEBUG - 2011-05-14 12:42:03 --> Config Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:42:03 --> URI Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Router Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Output Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Input Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:42:03 --> Language Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Loader Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Controller Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:42:03 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:42:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:42:03 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:42:03 --> Final output sent to browser
DEBUG - 2011-05-14 12:42:03 --> Total execution time: 0.2634
DEBUG - 2011-05-14 12:42:12 --> Config Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:42:12 --> URI Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Router Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Output Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Input Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:42:12 --> Language Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Loader Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Controller Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:42:12 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:42:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:42:12 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:42:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:42:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:42:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:42:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:42:12 --> Final output sent to browser
DEBUG - 2011-05-14 12:42:12 --> Total execution time: 0.2046
DEBUG - 2011-05-14 12:42:23 --> Config Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:42:23 --> URI Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Router Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Output Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Input Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:42:23 --> Language Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Loader Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Controller Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:42:23 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:42:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:42:23 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:42:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:42:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:42:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:42:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:42:23 --> Final output sent to browser
DEBUG - 2011-05-14 12:42:23 --> Total execution time: 0.0927
DEBUG - 2011-05-14 12:42:26 --> Config Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:42:26 --> URI Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Router Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Output Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Input Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:42:26 --> Language Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Loader Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Controller Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:42:26 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:42:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:42:26 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:42:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:42:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:42:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:42:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:42:26 --> Final output sent to browser
DEBUG - 2011-05-14 12:42:26 --> Total execution time: 0.0437
DEBUG - 2011-05-14 12:42:27 --> Config Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Hooks Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Utf8 Class Initialized
DEBUG - 2011-05-14 12:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 12:42:27 --> URI Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Router Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Output Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Input Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 12:42:27 --> Language Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Loader Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Controller Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Model Class Initialized
DEBUG - 2011-05-14 12:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 12:42:27 --> Database Driver Class Initialized
DEBUG - 2011-05-14 12:42:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 12:42:27 --> Helper loaded: url_helper
DEBUG - 2011-05-14 12:42:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 12:42:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 12:42:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 12:42:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 12:42:27 --> Final output sent to browser
DEBUG - 2011-05-14 12:42:27 --> Total execution time: 0.0442
DEBUG - 2011-05-14 13:53:53 --> Config Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:53:53 --> URI Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Router Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Output Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Input Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 13:53:53 --> Language Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Loader Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Controller Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Model Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Model Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Model Class Initialized
DEBUG - 2011-05-14 13:53:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 13:53:53 --> Database Driver Class Initialized
DEBUG - 2011-05-14 13:53:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 13:53:53 --> Helper loaded: url_helper
DEBUG - 2011-05-14 13:53:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 13:53:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 13:53:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 13:53:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 13:53:53 --> Final output sent to browser
DEBUG - 2011-05-14 13:53:53 --> Total execution time: 0.7408
DEBUG - 2011-05-14 13:53:56 --> Config Class Initialized
DEBUG - 2011-05-14 13:53:56 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:53:56 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:53:56 --> URI Class Initialized
DEBUG - 2011-05-14 13:53:56 --> Router Class Initialized
ERROR - 2011-05-14 13:53:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 13:54:37 --> Config Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:54:37 --> URI Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Router Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Output Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Input Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 13:54:37 --> Language Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Loader Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Controller Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 13:54:37 --> Database Driver Class Initialized
DEBUG - 2011-05-14 13:54:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 13:54:37 --> Helper loaded: url_helper
DEBUG - 2011-05-14 13:54:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 13:54:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 13:54:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 13:54:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 13:54:37 --> Final output sent to browser
DEBUG - 2011-05-14 13:54:37 --> Total execution time: 0.4142
DEBUG - 2011-05-14 13:54:39 --> Config Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:54:39 --> URI Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Router Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Output Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Input Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 13:54:39 --> Language Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Loader Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Controller Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 13:54:39 --> Database Driver Class Initialized
DEBUG - 2011-05-14 13:54:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 13:54:39 --> Helper loaded: url_helper
DEBUG - 2011-05-14 13:54:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 13:54:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 13:54:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 13:54:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 13:54:39 --> Final output sent to browser
DEBUG - 2011-05-14 13:54:39 --> Total execution time: 0.0457
DEBUG - 2011-05-14 13:54:51 --> Config Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:54:51 --> URI Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Router Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Output Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Input Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 13:54:51 --> Language Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Loader Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Controller Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 13:54:51 --> Database Driver Class Initialized
DEBUG - 2011-05-14 13:54:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 13:54:51 --> Helper loaded: url_helper
DEBUG - 2011-05-14 13:54:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 13:54:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 13:54:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 13:54:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 13:54:51 --> Final output sent to browser
DEBUG - 2011-05-14 13:54:51 --> Total execution time: 0.2130
DEBUG - 2011-05-14 13:54:53 --> Config Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:54:53 --> URI Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Router Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Output Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Input Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 13:54:53 --> Language Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Loader Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Controller Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Model Class Initialized
DEBUG - 2011-05-14 13:54:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 13:54:53 --> Database Driver Class Initialized
DEBUG - 2011-05-14 13:54:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 13:54:53 --> Helper loaded: url_helper
DEBUG - 2011-05-14 13:54:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 13:54:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 13:54:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 13:54:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 13:54:53 --> Final output sent to browser
DEBUG - 2011-05-14 13:54:53 --> Total execution time: 0.0512
DEBUG - 2011-05-14 13:55:06 --> Config Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:55:06 --> URI Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Router Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Output Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Input Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 13:55:06 --> Language Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Loader Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Controller Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 13:55:06 --> Database Driver Class Initialized
DEBUG - 2011-05-14 13:55:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 13:55:06 --> Helper loaded: url_helper
DEBUG - 2011-05-14 13:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 13:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 13:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 13:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 13:55:06 --> Final output sent to browser
DEBUG - 2011-05-14 13:55:06 --> Total execution time: 0.2741
DEBUG - 2011-05-14 13:55:07 --> Config Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:55:07 --> URI Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Router Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Output Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Input Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 13:55:07 --> Language Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Loader Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Controller Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 13:55:07 --> Database Driver Class Initialized
DEBUG - 2011-05-14 13:55:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 13:55:07 --> Helper loaded: url_helper
DEBUG - 2011-05-14 13:55:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 13:55:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 13:55:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 13:55:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 13:55:07 --> Final output sent to browser
DEBUG - 2011-05-14 13:55:07 --> Total execution time: 0.0541
DEBUG - 2011-05-14 13:55:08 --> Config Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Hooks Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Utf8 Class Initialized
DEBUG - 2011-05-14 13:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 13:55:08 --> URI Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Router Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Output Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Input Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 13:55:08 --> Language Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Loader Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Controller Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Model Class Initialized
DEBUG - 2011-05-14 13:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 13:55:08 --> Database Driver Class Initialized
DEBUG - 2011-05-14 13:55:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 13:55:08 --> Helper loaded: url_helper
DEBUG - 2011-05-14 13:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 13:55:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 13:55:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 13:55:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 13:55:08 --> Final output sent to browser
DEBUG - 2011-05-14 13:55:08 --> Total execution time: 0.0453
DEBUG - 2011-05-14 14:27:12 --> Config Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Hooks Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Utf8 Class Initialized
DEBUG - 2011-05-14 14:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 14:27:12 --> URI Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Router Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Output Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Input Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 14:27:12 --> Language Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Loader Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Controller Class Initialized
ERROR - 2011-05-14 14:27:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 14:27:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 14:27:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 14:27:12 --> Model Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Model Class Initialized
DEBUG - 2011-05-14 14:27:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 14:27:12 --> Database Driver Class Initialized
DEBUG - 2011-05-14 14:27:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 14:27:12 --> Helper loaded: url_helper
DEBUG - 2011-05-14 14:27:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 14:27:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 14:27:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 14:27:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 14:27:12 --> Final output sent to browser
DEBUG - 2011-05-14 14:27:12 --> Total execution time: 0.3113
DEBUG - 2011-05-14 15:11:57 --> Config Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Hooks Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Utf8 Class Initialized
DEBUG - 2011-05-14 15:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 15:11:57 --> URI Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Router Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Output Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Input Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 15:11:57 --> Language Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Loader Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Controller Class Initialized
ERROR - 2011-05-14 15:11:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 15:11:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 15:11:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 15:11:57 --> Model Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Model Class Initialized
DEBUG - 2011-05-14 15:11:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 15:11:57 --> Database Driver Class Initialized
DEBUG - 2011-05-14 15:11:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 15:11:57 --> Helper loaded: url_helper
DEBUG - 2011-05-14 15:11:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 15:11:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 15:11:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 15:11:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 15:11:57 --> Final output sent to browser
DEBUG - 2011-05-14 15:11:57 --> Total execution time: 0.3540
DEBUG - 2011-05-14 15:11:58 --> Config Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Hooks Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Utf8 Class Initialized
DEBUG - 2011-05-14 15:11:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 15:11:58 --> URI Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Router Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Output Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Input Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 15:11:58 --> Language Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Loader Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Controller Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Model Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Model Class Initialized
DEBUG - 2011-05-14 15:11:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 15:11:58 --> Database Driver Class Initialized
DEBUG - 2011-05-14 15:11:59 --> Final output sent to browser
DEBUG - 2011-05-14 15:11:59 --> Total execution time: 0.8080
DEBUG - 2011-05-14 15:12:00 --> Config Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Hooks Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Utf8 Class Initialized
DEBUG - 2011-05-14 15:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 15:12:00 --> URI Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Router Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Output Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Input Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 15:12:00 --> Language Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Loader Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Controller Class Initialized
ERROR - 2011-05-14 15:12:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 15:12:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 15:12:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 15:12:00 --> Model Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Model Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 15:12:00 --> Database Driver Class Initialized
DEBUG - 2011-05-14 15:12:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 15:12:00 --> Helper loaded: url_helper
DEBUG - 2011-05-14 15:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 15:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 15:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 15:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 15:12:00 --> Final output sent to browser
DEBUG - 2011-05-14 15:12:00 --> Total execution time: 0.0354
DEBUG - 2011-05-14 15:12:00 --> Config Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Hooks Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Utf8 Class Initialized
DEBUG - 2011-05-14 15:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 15:12:00 --> URI Class Initialized
DEBUG - 2011-05-14 15:12:00 --> Router Class Initialized
ERROR - 2011-05-14 15:12:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 15:12:02 --> Config Class Initialized
DEBUG - 2011-05-14 15:12:02 --> Hooks Class Initialized
DEBUG - 2011-05-14 15:12:02 --> Utf8 Class Initialized
DEBUG - 2011-05-14 15:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 15:12:02 --> URI Class Initialized
DEBUG - 2011-05-14 15:12:02 --> Router Class Initialized
ERROR - 2011-05-14 15:12:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 16:33:52 --> Config Class Initialized
DEBUG - 2011-05-14 16:33:52 --> Hooks Class Initialized
DEBUG - 2011-05-14 16:33:52 --> Utf8 Class Initialized
DEBUG - 2011-05-14 16:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 16:33:52 --> URI Class Initialized
DEBUG - 2011-05-14 16:33:52 --> Router Class Initialized
ERROR - 2011-05-14 16:33:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-14 16:33:53 --> Config Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Hooks Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Utf8 Class Initialized
DEBUG - 2011-05-14 16:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 16:33:53 --> URI Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Router Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Output Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Input Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 16:33:53 --> Language Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Loader Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Controller Class Initialized
ERROR - 2011-05-14 16:33:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 16:33:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 16:33:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 16:33:53 --> Model Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Model Class Initialized
DEBUG - 2011-05-14 16:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 16:33:53 --> Database Driver Class Initialized
DEBUG - 2011-05-14 16:33:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 16:33:53 --> Helper loaded: url_helper
DEBUG - 2011-05-14 16:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 16:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 16:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 16:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 16:33:53 --> Final output sent to browser
DEBUG - 2011-05-14 16:33:53 --> Total execution time: 0.3895
DEBUG - 2011-05-14 16:33:57 --> Config Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Hooks Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Utf8 Class Initialized
DEBUG - 2011-05-14 16:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 16:33:57 --> URI Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Router Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Output Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Input Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 16:33:57 --> Language Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Loader Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Controller Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Model Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Model Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Model Class Initialized
DEBUG - 2011-05-14 16:33:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 16:33:57 --> Database Driver Class Initialized
DEBUG - 2011-05-14 16:33:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-14 16:33:58 --> Helper loaded: url_helper
DEBUG - 2011-05-14 16:33:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 16:33:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 16:33:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 16:33:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 16:33:58 --> Final output sent to browser
DEBUG - 2011-05-14 16:33:58 --> Total execution time: 0.2960
DEBUG - 2011-05-14 17:26:14 --> Config Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Hooks Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Utf8 Class Initialized
DEBUG - 2011-05-14 17:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 17:26:14 --> URI Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Router Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Output Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Input Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 17:26:14 --> Language Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Loader Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Controller Class Initialized
ERROR - 2011-05-14 17:26:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 17:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 17:26:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 17:26:14 --> Model Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Model Class Initialized
DEBUG - 2011-05-14 17:26:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 17:26:14 --> Database Driver Class Initialized
DEBUG - 2011-05-14 17:26:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 17:26:14 --> Helper loaded: url_helper
DEBUG - 2011-05-14 17:26:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 17:26:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 17:26:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 17:26:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 17:26:14 --> Final output sent to browser
DEBUG - 2011-05-14 17:26:14 --> Total execution time: 0.3230
DEBUG - 2011-05-14 17:26:15 --> Config Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Hooks Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Utf8 Class Initialized
DEBUG - 2011-05-14 17:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 17:26:15 --> URI Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Router Class Initialized
ERROR - 2011-05-14 17:26:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 17:26:15 --> Config Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Hooks Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Utf8 Class Initialized
DEBUG - 2011-05-14 17:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 17:26:15 --> URI Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Router Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Output Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Input Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 17:26:15 --> Language Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Loader Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Controller Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Model Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Model Class Initialized
DEBUG - 2011-05-14 17:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 17:26:15 --> Database Driver Class Initialized
DEBUG - 2011-05-14 17:26:16 --> Final output sent to browser
DEBUG - 2011-05-14 17:26:16 --> Total execution time: 0.9207
DEBUG - 2011-05-14 18:06:16 --> Config Class Initialized
DEBUG - 2011-05-14 18:06:16 --> Hooks Class Initialized
DEBUG - 2011-05-14 18:06:16 --> Utf8 Class Initialized
DEBUG - 2011-05-14 18:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 18:06:16 --> URI Class Initialized
DEBUG - 2011-05-14 18:06:16 --> Router Class Initialized
DEBUG - 2011-05-14 18:06:16 --> Output Class Initialized
DEBUG - 2011-05-14 18:06:16 --> Input Class Initialized
DEBUG - 2011-05-14 18:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 18:06:16 --> Language Class Initialized
DEBUG - 2011-05-14 18:06:16 --> Loader Class Initialized
DEBUG - 2011-05-14 18:06:16 --> Controller Class Initialized
ERROR - 2011-05-14 18:06:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 18:06:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 18:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 18:06:17 --> Model Class Initialized
DEBUG - 2011-05-14 18:06:17 --> Model Class Initialized
DEBUG - 2011-05-14 18:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 18:06:17 --> Database Driver Class Initialized
DEBUG - 2011-05-14 18:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 18:06:17 --> Helper loaded: url_helper
DEBUG - 2011-05-14 18:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 18:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 18:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 18:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 18:06:17 --> Final output sent to browser
DEBUG - 2011-05-14 18:06:17 --> Total execution time: 0.3403
DEBUG - 2011-05-14 18:06:18 --> Config Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Hooks Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Utf8 Class Initialized
DEBUG - 2011-05-14 18:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 18:06:18 --> URI Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Router Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Output Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Input Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 18:06:18 --> Language Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Loader Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Controller Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Model Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Model Class Initialized
DEBUG - 2011-05-14 18:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 18:06:18 --> Database Driver Class Initialized
DEBUG - 2011-05-14 18:06:19 --> Final output sent to browser
DEBUG - 2011-05-14 18:06:19 --> Total execution time: 0.7180
DEBUG - 2011-05-14 18:06:21 --> Config Class Initialized
DEBUG - 2011-05-14 18:06:21 --> Hooks Class Initialized
DEBUG - 2011-05-14 18:06:21 --> Utf8 Class Initialized
DEBUG - 2011-05-14 18:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 18:06:21 --> URI Class Initialized
DEBUG - 2011-05-14 18:06:21 --> Router Class Initialized
ERROR - 2011-05-14 18:06:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-14 19:59:25 --> Config Class Initialized
DEBUG - 2011-05-14 19:59:25 --> Hooks Class Initialized
DEBUG - 2011-05-14 19:59:25 --> Utf8 Class Initialized
DEBUG - 2011-05-14 19:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 19:59:25 --> URI Class Initialized
DEBUG - 2011-05-14 19:59:25 --> Router Class Initialized
ERROR - 2011-05-14 19:59:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-14 19:59:26 --> Config Class Initialized
DEBUG - 2011-05-14 19:59:26 --> Hooks Class Initialized
DEBUG - 2011-05-14 19:59:26 --> Utf8 Class Initialized
DEBUG - 2011-05-14 19:59:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 19:59:26 --> URI Class Initialized
DEBUG - 2011-05-14 19:59:26 --> Router Class Initialized
DEBUG - 2011-05-14 19:59:26 --> No URI present. Default controller set.
DEBUG - 2011-05-14 19:59:26 --> Output Class Initialized
DEBUG - 2011-05-14 19:59:26 --> Input Class Initialized
DEBUG - 2011-05-14 19:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 19:59:26 --> Language Class Initialized
DEBUG - 2011-05-14 19:59:26 --> Loader Class Initialized
DEBUG - 2011-05-14 19:59:26 --> Controller Class Initialized
DEBUG - 2011-05-14 19:59:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-14 19:59:26 --> Helper loaded: url_helper
DEBUG - 2011-05-14 19:59:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 19:59:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 19:59:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 19:59:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 19:59:26 --> Final output sent to browser
DEBUG - 2011-05-14 19:59:26 --> Total execution time: 0.2146
DEBUG - 2011-05-14 20:04:06 --> Config Class Initialized
DEBUG - 2011-05-14 20:04:06 --> Hooks Class Initialized
DEBUG - 2011-05-14 20:04:06 --> Utf8 Class Initialized
DEBUG - 2011-05-14 20:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 20:04:06 --> URI Class Initialized
DEBUG - 2011-05-14 20:04:06 --> Router Class Initialized
DEBUG - 2011-05-14 20:04:06 --> No URI present. Default controller set.
DEBUG - 2011-05-14 20:04:06 --> Output Class Initialized
DEBUG - 2011-05-14 20:04:06 --> Input Class Initialized
DEBUG - 2011-05-14 20:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 20:04:06 --> Language Class Initialized
DEBUG - 2011-05-14 20:04:06 --> Loader Class Initialized
DEBUG - 2011-05-14 20:04:06 --> Controller Class Initialized
DEBUG - 2011-05-14 20:04:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-14 20:04:06 --> Helper loaded: url_helper
DEBUG - 2011-05-14 20:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 20:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 20:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 20:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 20:04:06 --> Final output sent to browser
DEBUG - 2011-05-14 20:04:06 --> Total execution time: 0.0138
DEBUG - 2011-05-14 21:53:45 --> Config Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Hooks Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Utf8 Class Initialized
DEBUG - 2011-05-14 21:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-14 21:53:45 --> URI Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Router Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Output Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Input Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-14 21:53:45 --> Language Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Loader Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Controller Class Initialized
ERROR - 2011-05-14 21:53:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-14 21:53:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-14 21:53:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 21:53:45 --> Model Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Model Class Initialized
DEBUG - 2011-05-14 21:53:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-14 21:53:45 --> Database Driver Class Initialized
DEBUG - 2011-05-14 21:53:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-14 21:53:45 --> Helper loaded: url_helper
DEBUG - 2011-05-14 21:53:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-14 21:53:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-14 21:53:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-14 21:53:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-14 21:53:45 --> Final output sent to browser
DEBUG - 2011-05-14 21:53:45 --> Total execution time: 0.4120

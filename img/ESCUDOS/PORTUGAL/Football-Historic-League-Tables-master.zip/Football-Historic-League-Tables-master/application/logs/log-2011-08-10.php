<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-10 00:10:34 --> Config Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Hooks Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Utf8 Class Initialized
DEBUG - 2011-08-10 00:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 00:10:34 --> URI Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Router Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Output Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Input Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 00:10:34 --> Language Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Loader Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Controller Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Model Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Model Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Model Class Initialized
DEBUG - 2011-08-10 00:10:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 00:10:34 --> Database Driver Class Initialized
DEBUG - 2011-08-10 00:10:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 00:10:34 --> Helper loaded: url_helper
DEBUG - 2011-08-10 00:10:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 00:10:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 00:10:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 00:10:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 00:10:34 --> Final output sent to browser
DEBUG - 2011-08-10 00:10:34 --> Total execution time: 0.2575
DEBUG - 2011-08-10 01:41:14 --> Config Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Hooks Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Utf8 Class Initialized
DEBUG - 2011-08-10 01:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 01:41:14 --> URI Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Router Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Output Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Input Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 01:41:14 --> Language Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Loader Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Controller Class Initialized
ERROR - 2011-08-10 01:41:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 01:41:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 01:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 01:41:14 --> Model Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Model Class Initialized
DEBUG - 2011-08-10 01:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 01:41:14 --> Database Driver Class Initialized
DEBUG - 2011-08-10 01:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 01:41:14 --> Helper loaded: url_helper
DEBUG - 2011-08-10 01:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 01:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 01:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 01:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 01:41:15 --> Config Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Hooks Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Utf8 Class Initialized
DEBUG - 2011-08-10 01:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 01:41:15 --> URI Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Router Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Output Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Input Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 01:41:15 --> Language Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Loader Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Controller Class Initialized
ERROR - 2011-08-10 01:41:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 01:41:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 01:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 01:41:15 --> Model Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Model Class Initialized
DEBUG - 2011-08-10 01:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 01:41:15 --> Database Driver Class Initialized
DEBUG - 2011-08-10 01:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 01:41:15 --> Helper loaded: url_helper
DEBUG - 2011-08-10 01:41:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 01:41:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 01:41:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 01:41:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 01:41:15 --> Final output sent to browser
DEBUG - 2011-08-10 01:41:15 --> Total execution time: 0.1805
DEBUG - 2011-08-10 01:41:46 --> Config Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Hooks Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Utf8 Class Initialized
DEBUG - 2011-08-10 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 01:41:46 --> URI Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Router Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Output Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Input Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 01:41:46 --> Language Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Loader Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Controller Class Initialized
ERROR - 2011-08-10 01:41:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 01:41:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 01:41:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 01:41:46 --> Model Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Model Class Initialized
DEBUG - 2011-08-10 01:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 01:41:46 --> Database Driver Class Initialized
DEBUG - 2011-08-10 01:41:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 01:41:46 --> Helper loaded: url_helper
DEBUG - 2011-08-10 01:41:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 01:41:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 01:41:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 01:41:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 01:41:46 --> Final output sent to browser
DEBUG - 2011-08-10 01:41:46 --> Total execution time: 0.0967
DEBUG - 2011-08-10 01:54:23 --> Config Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Hooks Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Utf8 Class Initialized
DEBUG - 2011-08-10 01:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 01:54:23 --> URI Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Router Class Initialized
ERROR - 2011-08-10 01:54:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 01:54:23 --> Config Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Hooks Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Utf8 Class Initialized
DEBUG - 2011-08-10 01:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 01:54:23 --> URI Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Router Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Output Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Input Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 01:54:23 --> Language Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Loader Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Controller Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Model Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Model Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Model Class Initialized
DEBUG - 2011-08-10 01:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 01:54:23 --> Database Driver Class Initialized
DEBUG - 2011-08-10 01:54:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 01:54:27 --> Helper loaded: url_helper
DEBUG - 2011-08-10 01:54:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 01:54:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 01:54:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 01:54:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 01:54:27 --> Final output sent to browser
DEBUG - 2011-08-10 01:54:27 --> Total execution time: 3.6906
DEBUG - 2011-08-10 02:21:07 --> Config Class Initialized
DEBUG - 2011-08-10 02:21:07 --> Hooks Class Initialized
DEBUG - 2011-08-10 02:21:07 --> Utf8 Class Initialized
DEBUG - 2011-08-10 02:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 02:21:07 --> URI Class Initialized
DEBUG - 2011-08-10 02:21:07 --> Router Class Initialized
ERROR - 2011-08-10 02:21:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 02:30:09 --> Config Class Initialized
DEBUG - 2011-08-10 02:30:09 --> Hooks Class Initialized
DEBUG - 2011-08-10 02:30:09 --> Utf8 Class Initialized
DEBUG - 2011-08-10 02:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 02:30:09 --> URI Class Initialized
DEBUG - 2011-08-10 02:30:09 --> Router Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Output Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Input Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 02:30:10 --> Language Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Loader Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Controller Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Model Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Model Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Model Class Initialized
DEBUG - 2011-08-10 02:30:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 02:30:10 --> Database Driver Class Initialized
DEBUG - 2011-08-10 02:30:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 02:30:27 --> Helper loaded: url_helper
DEBUG - 2011-08-10 02:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 02:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 02:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 02:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 02:30:28 --> Config Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Hooks Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Utf8 Class Initialized
DEBUG - 2011-08-10 02:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 02:30:28 --> URI Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Router Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Output Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Input Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 02:30:28 --> Language Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Loader Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Controller Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Model Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Model Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Model Class Initialized
DEBUG - 2011-08-10 02:30:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 02:30:28 --> Database Driver Class Initialized
DEBUG - 2011-08-10 02:30:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 02:30:28 --> Helper loaded: url_helper
DEBUG - 2011-08-10 02:30:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 02:30:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 02:30:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 02:30:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 02:30:28 --> Final output sent to browser
DEBUG - 2011-08-10 02:30:28 --> Total execution time: 0.0426
DEBUG - 2011-08-10 02:30:59 --> Config Class Initialized
DEBUG - 2011-08-10 02:30:59 --> Hooks Class Initialized
DEBUG - 2011-08-10 02:30:59 --> Utf8 Class Initialized
DEBUG - 2011-08-10 02:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 02:30:59 --> URI Class Initialized
DEBUG - 2011-08-10 02:30:59 --> Router Class Initialized
ERROR - 2011-08-10 02:30:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 02:31:00 --> Config Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Hooks Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Utf8 Class Initialized
DEBUG - 2011-08-10 02:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 02:31:00 --> URI Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Router Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Output Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Input Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 02:31:00 --> Language Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Loader Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Controller Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Model Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Model Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Model Class Initialized
DEBUG - 2011-08-10 02:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 02:31:00 --> Database Driver Class Initialized
DEBUG - 2011-08-10 02:31:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 02:31:00 --> Helper loaded: url_helper
DEBUG - 2011-08-10 02:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 02:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 02:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 02:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 02:31:00 --> Final output sent to browser
DEBUG - 2011-08-10 02:31:00 --> Total execution time: 0.2281
DEBUG - 2011-08-10 04:30:31 --> Config Class Initialized
DEBUG - 2011-08-10 04:30:31 --> Hooks Class Initialized
DEBUG - 2011-08-10 04:30:31 --> Utf8 Class Initialized
DEBUG - 2011-08-10 04:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 04:30:31 --> URI Class Initialized
DEBUG - 2011-08-10 04:30:31 --> Router Class Initialized
DEBUG - 2011-08-10 04:30:31 --> Output Class Initialized
DEBUG - 2011-08-10 04:30:31 --> Input Class Initialized
DEBUG - 2011-08-10 04:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 04:30:31 --> Language Class Initialized
DEBUG - 2011-08-10 04:30:31 --> Loader Class Initialized
DEBUG - 2011-08-10 04:30:32 --> Controller Class Initialized
ERROR - 2011-08-10 04:30:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 04:30:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 04:30:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 04:30:32 --> Model Class Initialized
DEBUG - 2011-08-10 04:30:32 --> Model Class Initialized
DEBUG - 2011-08-10 04:30:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 04:30:32 --> Database Driver Class Initialized
DEBUG - 2011-08-10 04:30:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 04:30:32 --> Helper loaded: url_helper
DEBUG - 2011-08-10 04:30:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 04:30:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 04:30:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 04:30:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 04:30:32 --> Final output sent to browser
DEBUG - 2011-08-10 04:30:32 --> Total execution time: 0.9082
DEBUG - 2011-08-10 04:30:33 --> Config Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Hooks Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Utf8 Class Initialized
DEBUG - 2011-08-10 04:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 04:30:33 --> URI Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Router Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Output Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Input Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 04:30:33 --> Language Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Loader Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Controller Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Model Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Model Class Initialized
DEBUG - 2011-08-10 04:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 04:30:33 --> Database Driver Class Initialized
DEBUG - 2011-08-10 04:30:34 --> Final output sent to browser
DEBUG - 2011-08-10 04:30:34 --> Total execution time: 0.6524
DEBUG - 2011-08-10 04:30:35 --> Config Class Initialized
DEBUG - 2011-08-10 04:30:35 --> Hooks Class Initialized
DEBUG - 2011-08-10 04:30:35 --> Utf8 Class Initialized
DEBUG - 2011-08-10 04:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 04:30:35 --> URI Class Initialized
DEBUG - 2011-08-10 04:30:35 --> Router Class Initialized
ERROR - 2011-08-10 04:30:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 04:30:36 --> Config Class Initialized
DEBUG - 2011-08-10 04:30:36 --> Hooks Class Initialized
DEBUG - 2011-08-10 04:30:36 --> Utf8 Class Initialized
DEBUG - 2011-08-10 04:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 04:30:36 --> URI Class Initialized
DEBUG - 2011-08-10 04:30:36 --> Router Class Initialized
ERROR - 2011-08-10 04:30:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 06:58:46 --> Config Class Initialized
DEBUG - 2011-08-10 06:58:46 --> Hooks Class Initialized
DEBUG - 2011-08-10 06:58:46 --> Utf8 Class Initialized
DEBUG - 2011-08-10 06:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 06:58:46 --> URI Class Initialized
DEBUG - 2011-08-10 06:58:46 --> Router Class Initialized
DEBUG - 2011-08-10 06:58:46 --> No URI present. Default controller set.
DEBUG - 2011-08-10 06:58:46 --> Output Class Initialized
DEBUG - 2011-08-10 06:58:46 --> Input Class Initialized
DEBUG - 2011-08-10 06:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 06:58:46 --> Language Class Initialized
DEBUG - 2011-08-10 06:58:46 --> Loader Class Initialized
DEBUG - 2011-08-10 06:58:46 --> Controller Class Initialized
DEBUG - 2011-08-10 06:58:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-10 06:58:47 --> Helper loaded: url_helper
DEBUG - 2011-08-10 06:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 06:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 06:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 06:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 06:58:47 --> Final output sent to browser
DEBUG - 2011-08-10 06:58:47 --> Total execution time: 0.2450
DEBUG - 2011-08-10 07:07:22 --> Config Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Hooks Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Utf8 Class Initialized
DEBUG - 2011-08-10 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 07:07:22 --> URI Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Router Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Config Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Hooks Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Utf8 Class Initialized
DEBUG - 2011-08-10 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 07:07:22 --> URI Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Router Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Output Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Input Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 07:07:22 --> Language Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Output Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Input Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 07:07:22 --> Language Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Loader Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Controller Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Loader Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Controller Class Initialized
DEBUG - 2011-08-10 07:07:22 --> Model Class Initialized
ERROR - 2011-08-10 07:07:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 07:07:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 07:07:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 07:07:23 --> Model Class Initialized
DEBUG - 2011-08-10 07:07:23 --> Model Class Initialized
DEBUG - 2011-08-10 07:07:23 --> Model Class Initialized
DEBUG - 2011-08-10 07:07:23 --> Model Class Initialized
DEBUG - 2011-08-10 07:07:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 07:07:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 07:07:23 --> Database Driver Class Initialized
DEBUG - 2011-08-10 07:07:23 --> Database Driver Class Initialized
DEBUG - 2011-08-10 07:07:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 07:07:23 --> Helper loaded: url_helper
DEBUG - 2011-08-10 07:07:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 07:07:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 07:07:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 07:07:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 07:07:23 --> Final output sent to browser
DEBUG - 2011-08-10 07:07:23 --> Total execution time: 1.7467
DEBUG - 2011-08-10 07:07:27 --> Config Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Hooks Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Utf8 Class Initialized
DEBUG - 2011-08-10 07:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 07:07:27 --> URI Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Router Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Output Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Input Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 07:07:27 --> Language Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Loader Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Controller Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Model Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Model Class Initialized
DEBUG - 2011-08-10 07:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 07:07:27 --> Database Driver Class Initialized
DEBUG - 2011-08-10 07:07:28 --> Final output sent to browser
DEBUG - 2011-08-10 07:07:28 --> Total execution time: 1.4938
DEBUG - 2011-08-10 07:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 07:07:29 --> Helper loaded: url_helper
DEBUG - 2011-08-10 07:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 07:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 07:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 07:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 07:07:29 --> Final output sent to browser
DEBUG - 2011-08-10 07:07:29 --> Total execution time: 7.4140
DEBUG - 2011-08-10 07:07:32 --> Config Class Initialized
DEBUG - 2011-08-10 07:07:32 --> Hooks Class Initialized
DEBUG - 2011-08-10 07:07:32 --> Utf8 Class Initialized
DEBUG - 2011-08-10 07:07:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 07:07:32 --> URI Class Initialized
DEBUG - 2011-08-10 07:07:32 --> Router Class Initialized
ERROR - 2011-08-10 07:07:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 07:07:32 --> Config Class Initialized
DEBUG - 2011-08-10 07:07:32 --> Hooks Class Initialized
DEBUG - 2011-08-10 07:07:32 --> Utf8 Class Initialized
DEBUG - 2011-08-10 07:07:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 07:07:32 --> URI Class Initialized
DEBUG - 2011-08-10 07:07:32 --> Router Class Initialized
ERROR - 2011-08-10 07:07:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 07:45:09 --> Config Class Initialized
DEBUG - 2011-08-10 07:45:09 --> Hooks Class Initialized
DEBUG - 2011-08-10 07:45:09 --> Utf8 Class Initialized
DEBUG - 2011-08-10 07:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 07:45:09 --> URI Class Initialized
DEBUG - 2011-08-10 07:45:09 --> Router Class Initialized
ERROR - 2011-08-10 07:45:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 08:13:03 --> Config Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Hooks Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Utf8 Class Initialized
DEBUG - 2011-08-10 08:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 08:13:03 --> URI Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Router Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Output Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Input Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 08:13:03 --> Language Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Loader Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Controller Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Model Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Model Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Model Class Initialized
DEBUG - 2011-08-10 08:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 08:13:03 --> Database Driver Class Initialized
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 08:13:04 --> Helper loaded: url_helper
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 08:13:04 --> Final output sent to browser
DEBUG - 2011-08-10 08:13:04 --> Total execution time: 1.4010
DEBUG - 2011-08-10 08:13:04 --> Config Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Hooks Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Utf8 Class Initialized
DEBUG - 2011-08-10 08:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 08:13:04 --> URI Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Router Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Output Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Input Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 08:13:04 --> Language Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Loader Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Controller Class Initialized
ERROR - 2011-08-10 08:13:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 08:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 08:13:04 --> Model Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Model Class Initialized
DEBUG - 2011-08-10 08:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 08:13:04 --> Database Driver Class Initialized
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 08:13:04 --> Helper loaded: url_helper
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 08:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 08:13:04 --> Final output sent to browser
DEBUG - 2011-08-10 08:13:04 --> Total execution time: 0.0810
DEBUG - 2011-08-10 08:13:06 --> Config Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Hooks Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Utf8 Class Initialized
DEBUG - 2011-08-10 08:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 08:13:06 --> URI Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Router Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Output Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Input Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 08:13:06 --> Language Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Loader Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Controller Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Model Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Model Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 08:13:06 --> Database Driver Class Initialized
DEBUG - 2011-08-10 08:13:06 --> Final output sent to browser
DEBUG - 2011-08-10 08:13:06 --> Total execution time: 0.5482
DEBUG - 2011-08-10 08:13:08 --> Config Class Initialized
DEBUG - 2011-08-10 08:13:08 --> Hooks Class Initialized
DEBUG - 2011-08-10 08:13:08 --> Utf8 Class Initialized
DEBUG - 2011-08-10 08:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 08:13:08 --> URI Class Initialized
DEBUG - 2011-08-10 08:13:08 --> Router Class Initialized
ERROR - 2011-08-10 08:13:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 09:20:48 --> Config Class Initialized
DEBUG - 2011-08-10 09:20:48 --> Hooks Class Initialized
DEBUG - 2011-08-10 09:20:48 --> Utf8 Class Initialized
DEBUG - 2011-08-10 09:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 09:20:48 --> URI Class Initialized
DEBUG - 2011-08-10 09:20:48 --> Router Class Initialized
DEBUG - 2011-08-10 09:20:48 --> Output Class Initialized
DEBUG - 2011-08-10 09:20:48 --> Input Class Initialized
DEBUG - 2011-08-10 09:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 09:20:48 --> Language Class Initialized
DEBUG - 2011-08-10 09:20:48 --> Loader Class Initialized
DEBUG - 2011-08-10 09:20:48 --> Controller Class Initialized
ERROR - 2011-08-10 09:20:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 09:20:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 09:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 09:20:49 --> Model Class Initialized
DEBUG - 2011-08-10 09:20:49 --> Model Class Initialized
DEBUG - 2011-08-10 09:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 09:20:49 --> Database Driver Class Initialized
DEBUG - 2011-08-10 09:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 09:20:49 --> Helper loaded: url_helper
DEBUG - 2011-08-10 09:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 09:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 09:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 09:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 09:20:49 --> Final output sent to browser
DEBUG - 2011-08-10 09:20:49 --> Total execution time: 0.1496
DEBUG - 2011-08-10 09:20:50 --> Config Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Hooks Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Utf8 Class Initialized
DEBUG - 2011-08-10 09:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 09:20:50 --> URI Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Router Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Output Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Input Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 09:20:50 --> Language Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Loader Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Controller Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Model Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Model Class Initialized
DEBUG - 2011-08-10 09:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 09:20:50 --> Database Driver Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Config Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Hooks Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Utf8 Class Initialized
DEBUG - 2011-08-10 10:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 10:01:03 --> URI Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Router Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Output Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Input Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 10:01:03 --> Language Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Loader Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Controller Class Initialized
ERROR - 2011-08-10 10:01:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 10:01:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 10:01:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 10:01:03 --> Model Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Model Class Initialized
DEBUG - 2011-08-10 10:01:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 10:01:03 --> Database Driver Class Initialized
DEBUG - 2011-08-10 10:01:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 10:01:03 --> Helper loaded: url_helper
DEBUG - 2011-08-10 10:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 10:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 10:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 10:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 10:01:03 --> Final output sent to browser
DEBUG - 2011-08-10 10:01:03 --> Total execution time: 0.1435
DEBUG - 2011-08-10 10:01:05 --> Config Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Hooks Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Utf8 Class Initialized
DEBUG - 2011-08-10 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 10:01:05 --> URI Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Router Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Output Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Input Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 10:01:05 --> Language Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Loader Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Controller Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Model Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Model Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 10:01:05 --> Database Driver Class Initialized
DEBUG - 2011-08-10 10:01:05 --> Final output sent to browser
DEBUG - 2011-08-10 10:01:05 --> Total execution time: 0.6616
DEBUG - 2011-08-10 10:53:11 --> Config Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Hooks Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Utf8 Class Initialized
DEBUG - 2011-08-10 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 10:53:11 --> URI Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Router Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Output Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Input Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 10:53:11 --> Language Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Loader Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Controller Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Model Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Model Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Model Class Initialized
DEBUG - 2011-08-10 10:53:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 10:53:11 --> Database Driver Class Initialized
DEBUG - 2011-08-10 10:53:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 10:53:12 --> Helper loaded: url_helper
DEBUG - 2011-08-10 10:53:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 10:53:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 10:53:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 10:53:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 10:53:12 --> Final output sent to browser
DEBUG - 2011-08-10 10:53:12 --> Total execution time: 0.4113
DEBUG - 2011-08-10 10:53:15 --> Config Class Initialized
DEBUG - 2011-08-10 10:53:15 --> Hooks Class Initialized
DEBUG - 2011-08-10 10:53:15 --> Utf8 Class Initialized
DEBUG - 2011-08-10 10:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 10:53:15 --> URI Class Initialized
DEBUG - 2011-08-10 10:53:15 --> Router Class Initialized
ERROR - 2011-08-10 10:53:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 10:53:18 --> Config Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Hooks Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Utf8 Class Initialized
DEBUG - 2011-08-10 10:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 10:53:18 --> URI Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Router Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Output Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Input Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 10:53:18 --> Language Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Loader Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Controller Class Initialized
ERROR - 2011-08-10 10:53:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 10:53:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 10:53:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 10:53:18 --> Model Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Model Class Initialized
DEBUG - 2011-08-10 10:53:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 10:53:18 --> Database Driver Class Initialized
DEBUG - 2011-08-10 10:53:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 10:53:18 --> Helper loaded: url_helper
DEBUG - 2011-08-10 10:53:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 10:53:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 10:53:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 10:53:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 10:53:18 --> Final output sent to browser
DEBUG - 2011-08-10 10:53:18 --> Total execution time: 0.0752
DEBUG - 2011-08-10 10:53:19 --> Config Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Hooks Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Utf8 Class Initialized
DEBUG - 2011-08-10 10:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 10:53:19 --> URI Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Router Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Output Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Input Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 10:53:19 --> Language Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Loader Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Controller Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Model Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Model Class Initialized
DEBUG - 2011-08-10 10:53:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 10:53:19 --> Database Driver Class Initialized
DEBUG - 2011-08-10 10:53:20 --> Final output sent to browser
DEBUG - 2011-08-10 10:53:20 --> Total execution time: 0.6292
DEBUG - 2011-08-10 10:53:21 --> Config Class Initialized
DEBUG - 2011-08-10 10:53:21 --> Hooks Class Initialized
DEBUG - 2011-08-10 10:53:21 --> Utf8 Class Initialized
DEBUG - 2011-08-10 10:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 10:53:21 --> URI Class Initialized
DEBUG - 2011-08-10 10:53:21 --> Router Class Initialized
ERROR - 2011-08-10 10:53:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 11:39:40 --> Config Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:39:40 --> URI Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Router Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Output Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Input Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:39:40 --> Language Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Loader Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Controller Class Initialized
ERROR - 2011-08-10 11:39:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 11:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 11:39:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:39:40 --> Model Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Model Class Initialized
DEBUG - 2011-08-10 11:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:39:40 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:39:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:39:40 --> Helper loaded: url_helper
DEBUG - 2011-08-10 11:39:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 11:39:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 11:39:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 11:39:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 11:39:40 --> Final output sent to browser
DEBUG - 2011-08-10 11:39:40 --> Total execution time: 0.0440
DEBUG - 2011-08-10 11:39:42 --> Config Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:39:42 --> URI Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Router Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Output Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Input Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:39:42 --> Language Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Loader Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Controller Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Model Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Model Class Initialized
DEBUG - 2011-08-10 11:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:39:42 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:39:43 --> Final output sent to browser
DEBUG - 2011-08-10 11:39:43 --> Total execution time: 0.5360
DEBUG - 2011-08-10 11:39:44 --> Config Class Initialized
DEBUG - 2011-08-10 11:39:44 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:39:44 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:39:44 --> URI Class Initialized
DEBUG - 2011-08-10 11:39:44 --> Router Class Initialized
ERROR - 2011-08-10 11:39:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 11:40:09 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:09 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Router Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Output Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Input Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:40:09 --> Language Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Loader Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Controller Class Initialized
ERROR - 2011-08-10 11:40:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 11:40:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 11:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:40:09 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:40:09 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:40:09 --> Helper loaded: url_helper
DEBUG - 2011-08-10 11:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 11:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 11:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 11:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 11:40:09 --> Final output sent to browser
DEBUG - 2011-08-10 11:40:09 --> Total execution time: 0.0525
DEBUG - 2011-08-10 11:40:10 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:10 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Router Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Output Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Input Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:40:10 --> Language Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Loader Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Controller Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:40:10 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:40:11 --> Final output sent to browser
DEBUG - 2011-08-10 11:40:11 --> Total execution time: 0.7031
DEBUG - 2011-08-10 11:40:13 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:13 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:13 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:13 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:13 --> Router Class Initialized
ERROR - 2011-08-10 11:40:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 11:40:31 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:31 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:31 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:31 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:31 --> Router Class Initialized
ERROR - 2011-08-10 11:40:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 11:40:35 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:35 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Router Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Output Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Input Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:40:35 --> Language Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Loader Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Controller Class Initialized
ERROR - 2011-08-10 11:40:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 11:40:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 11:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:40:35 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:40:35 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:40:35 --> Helper loaded: url_helper
DEBUG - 2011-08-10 11:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 11:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 11:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 11:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 11:40:35 --> Final output sent to browser
DEBUG - 2011-08-10 11:40:35 --> Total execution time: 0.0313
DEBUG - 2011-08-10 11:40:36 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:36 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Router Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Output Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Input Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:40:36 --> Language Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Loader Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Controller Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:40:36 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:40:37 --> Final output sent to browser
DEBUG - 2011-08-10 11:40:37 --> Total execution time: 0.5457
DEBUG - 2011-08-10 11:40:38 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:38 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:38 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:38 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:38 --> Router Class Initialized
ERROR - 2011-08-10 11:40:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 11:40:55 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:55 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Router Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Output Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Input Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:40:55 --> Language Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Loader Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Controller Class Initialized
ERROR - 2011-08-10 11:40:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 11:40:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 11:40:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:40:55 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:40:55 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:40:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:40:55 --> Helper loaded: url_helper
DEBUG - 2011-08-10 11:40:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 11:40:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 11:40:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 11:40:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 11:40:55 --> Final output sent to browser
DEBUG - 2011-08-10 11:40:55 --> Total execution time: 0.0272
DEBUG - 2011-08-10 11:40:56 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:56 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Router Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Output Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Input Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:40:56 --> Language Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Loader Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Controller Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:40:56 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:40:57 --> Final output sent to browser
DEBUG - 2011-08-10 11:40:57 --> Total execution time: 0.6532
DEBUG - 2011-08-10 11:40:58 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:58 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Router Class Initialized
ERROR - 2011-08-10 11:40:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 11:40:58 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:58 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Router Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Output Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Input Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 11:40:58 --> Language Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Loader Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Controller Class Initialized
ERROR - 2011-08-10 11:40:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 11:40:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 11:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:40:58 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Model Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 11:40:58 --> Database Driver Class Initialized
DEBUG - 2011-08-10 11:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 11:40:58 --> Helper loaded: url_helper
DEBUG - 2011-08-10 11:40:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 11:40:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 11:40:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 11:40:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 11:40:58 --> Final output sent to browser
DEBUG - 2011-08-10 11:40:58 --> Total execution time: 0.0577
DEBUG - 2011-08-10 11:40:58 --> Config Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:40:58 --> URI Class Initialized
DEBUG - 2011-08-10 11:40:58 --> Router Class Initialized
ERROR - 2011-08-10 11:40:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 11:41:18 --> Config Class Initialized
DEBUG - 2011-08-10 11:41:18 --> Hooks Class Initialized
DEBUG - 2011-08-10 11:41:18 --> Utf8 Class Initialized
DEBUG - 2011-08-10 11:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 11:41:18 --> URI Class Initialized
DEBUG - 2011-08-10 11:41:18 --> Router Class Initialized
ERROR - 2011-08-10 11:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 12:48:02 --> Config Class Initialized
DEBUG - 2011-08-10 12:48:02 --> Hooks Class Initialized
DEBUG - 2011-08-10 12:48:02 --> Utf8 Class Initialized
DEBUG - 2011-08-10 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 12:48:02 --> URI Class Initialized
DEBUG - 2011-08-10 12:48:02 --> Router Class Initialized
ERROR - 2011-08-10 12:48:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 12:51:54 --> Config Class Initialized
DEBUG - 2011-08-10 12:51:54 --> Hooks Class Initialized
DEBUG - 2011-08-10 12:51:54 --> Utf8 Class Initialized
DEBUG - 2011-08-10 12:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 12:51:54 --> URI Class Initialized
DEBUG - 2011-08-10 12:51:54 --> Router Class Initialized
ERROR - 2011-08-10 12:51:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 12:51:55 --> Config Class Initialized
DEBUG - 2011-08-10 12:51:55 --> Hooks Class Initialized
DEBUG - 2011-08-10 12:51:55 --> Utf8 Class Initialized
DEBUG - 2011-08-10 12:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 12:51:55 --> URI Class Initialized
DEBUG - 2011-08-10 12:51:55 --> Router Class Initialized
DEBUG - 2011-08-10 12:51:55 --> No URI present. Default controller set.
DEBUG - 2011-08-10 12:51:55 --> Output Class Initialized
DEBUG - 2011-08-10 12:51:55 --> Input Class Initialized
DEBUG - 2011-08-10 12:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 12:51:55 --> Language Class Initialized
DEBUG - 2011-08-10 12:51:55 --> Loader Class Initialized
DEBUG - 2011-08-10 12:51:55 --> Controller Class Initialized
DEBUG - 2011-08-10 12:51:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-10 12:51:55 --> Helper loaded: url_helper
DEBUG - 2011-08-10 12:51:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 12:51:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 12:51:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 12:51:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 12:51:55 --> Final output sent to browser
DEBUG - 2011-08-10 12:51:55 --> Total execution time: 0.1012
DEBUG - 2011-08-10 12:53:16 --> Config Class Initialized
DEBUG - 2011-08-10 12:53:16 --> Hooks Class Initialized
DEBUG - 2011-08-10 12:53:16 --> Utf8 Class Initialized
DEBUG - 2011-08-10 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 12:53:16 --> URI Class Initialized
DEBUG - 2011-08-10 12:53:16 --> Router Class Initialized
ERROR - 2011-08-10 12:53:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 12:53:17 --> Config Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Hooks Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Utf8 Class Initialized
DEBUG - 2011-08-10 12:53:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 12:53:17 --> URI Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Router Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Output Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Input Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 12:53:17 --> Language Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Loader Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Controller Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Model Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Model Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Model Class Initialized
DEBUG - 2011-08-10 12:53:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 12:53:17 --> Database Driver Class Initialized
DEBUG - 2011-08-10 12:53:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 12:53:17 --> Helper loaded: url_helper
DEBUG - 2011-08-10 12:53:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 12:53:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 12:53:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 12:53:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 12:53:17 --> Final output sent to browser
DEBUG - 2011-08-10 12:53:17 --> Total execution time: 0.5488
DEBUG - 2011-08-10 13:39:56 --> Config Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:39:56 --> URI Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Router Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Output Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Input Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:39:56 --> Language Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Loader Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Controller Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Model Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Model Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Model Class Initialized
DEBUG - 2011-08-10 13:39:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:39:56 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:39:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:39:57 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:39:57 --> Final output sent to browser
DEBUG - 2011-08-10 13:39:57 --> Total execution time: 0.6839
DEBUG - 2011-08-10 13:39:58 --> Config Class Initialized
DEBUG - 2011-08-10 13:39:58 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:39:58 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:39:58 --> URI Class Initialized
DEBUG - 2011-08-10 13:39:58 --> Router Class Initialized
ERROR - 2011-08-10 13:39:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 13:40:22 --> Config Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:40:22 --> URI Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Router Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Output Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Input Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:40:22 --> Language Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Loader Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Controller Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:40:22 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:40:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:40:22 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:40:22 --> Final output sent to browser
DEBUG - 2011-08-10 13:40:22 --> Total execution time: 0.4128
DEBUG - 2011-08-10 13:40:24 --> Config Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:40:24 --> URI Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Router Class Initialized
ERROR - 2011-08-10 13:40:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 13:40:24 --> Config Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:40:24 --> URI Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Router Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Output Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Input Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:40:24 --> Language Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Loader Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Controller Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:40:24 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:40:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:40:24 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:40:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:40:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:40:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:40:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:40:24 --> Final output sent to browser
DEBUG - 2011-08-10 13:40:24 --> Total execution time: 0.0454
DEBUG - 2011-08-10 13:40:47 --> Config Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:40:47 --> URI Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Router Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Output Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Input Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:40:47 --> Language Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Loader Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Controller Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:40:47 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:40:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:40:48 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:40:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:40:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:40:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:40:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:40:48 --> Final output sent to browser
DEBUG - 2011-08-10 13:40:48 --> Total execution time: 0.2705
DEBUG - 2011-08-10 13:40:49 --> Config Class Initialized
DEBUG - 2011-08-10 13:40:49 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:40:49 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:40:49 --> URI Class Initialized
DEBUG - 2011-08-10 13:40:49 --> Router Class Initialized
ERROR - 2011-08-10 13:40:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 13:40:59 --> Config Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:40:59 --> URI Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Router Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Output Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Input Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:40:59 --> Language Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Loader Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Controller Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Model Class Initialized
DEBUG - 2011-08-10 13:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:40:59 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:40:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:40:59 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:40:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:40:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:40:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:40:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:40:59 --> Final output sent to browser
DEBUG - 2011-08-10 13:40:59 --> Total execution time: 0.3193
DEBUG - 2011-08-10 13:41:00 --> Config Class Initialized
DEBUG - 2011-08-10 13:41:00 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:41:00 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:41:00 --> URI Class Initialized
DEBUG - 2011-08-10 13:41:00 --> Router Class Initialized
ERROR - 2011-08-10 13:41:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 13:41:08 --> Config Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:41:08 --> URI Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Router Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Output Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Input Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:41:08 --> Language Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Loader Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Controller Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:41:08 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:41:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:41:08 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:41:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:41:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:41:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:41:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:41:08 --> Final output sent to browser
DEBUG - 2011-08-10 13:41:08 --> Total execution time: 0.3037
DEBUG - 2011-08-10 13:41:09 --> Config Class Initialized
DEBUG - 2011-08-10 13:41:09 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:41:09 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:41:09 --> URI Class Initialized
DEBUG - 2011-08-10 13:41:09 --> Router Class Initialized
ERROR - 2011-08-10 13:41:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 13:41:24 --> Config Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:41:24 --> URI Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Router Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Output Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Input Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:41:24 --> Language Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Loader Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Controller Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:41:24 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:41:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:41:24 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:41:24 --> Final output sent to browser
DEBUG - 2011-08-10 13:41:24 --> Total execution time: 0.0728
DEBUG - 2011-08-10 13:41:24 --> Config Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:41:24 --> URI Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Router Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Output Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Input Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:41:24 --> Language Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Loader Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Controller Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:41:24 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:41:25 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:41:25 --> Final output sent to browser
DEBUG - 2011-08-10 13:41:25 --> Total execution time: 0.7221
DEBUG - 2011-08-10 13:41:25 --> Config Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:41:25 --> URI Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Router Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Output Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Input Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:41:25 --> Language Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Loader Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Controller Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:41:25 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:41:25 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:41:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:41:25 --> Final output sent to browser
DEBUG - 2011-08-10 13:41:25 --> Total execution time: 0.0430
DEBUG - 2011-08-10 13:41:26 --> Config Class Initialized
DEBUG - 2011-08-10 13:41:26 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:41:26 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:41:26 --> URI Class Initialized
DEBUG - 2011-08-10 13:41:26 --> Router Class Initialized
ERROR - 2011-08-10 13:41:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 13:41:27 --> Config Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:41:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:41:27 --> URI Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Router Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Output Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Input Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:41:27 --> Language Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Loader Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Controller Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Model Class Initialized
DEBUG - 2011-08-10 13:41:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:41:27 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:41:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:41:27 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:41:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:41:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:41:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:41:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:41:27 --> Final output sent to browser
DEBUG - 2011-08-10 13:41:27 --> Total execution time: 0.0480
DEBUG - 2011-08-10 13:43:53 --> Config Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Hooks Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Utf8 Class Initialized
DEBUG - 2011-08-10 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 13:43:53 --> URI Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Router Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Output Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Input Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 13:43:53 --> Language Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Loader Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Controller Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Model Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Model Class Initialized
DEBUG - 2011-08-10 13:43:53 --> Model Class Initialized
DEBUG - 2011-08-10 13:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 13:43:54 --> Database Driver Class Initialized
DEBUG - 2011-08-10 13:43:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 13:43:54 --> Helper loaded: url_helper
DEBUG - 2011-08-10 13:43:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 13:43:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 13:43:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 13:43:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 13:43:54 --> Final output sent to browser
DEBUG - 2011-08-10 13:43:54 --> Total execution time: 0.2993
DEBUG - 2011-08-10 14:46:12 --> Config Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Hooks Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Utf8 Class Initialized
DEBUG - 2011-08-10 14:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 14:46:12 --> URI Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Router Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Output Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Input Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 14:46:12 --> Language Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Loader Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Controller Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Model Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Model Class Initialized
DEBUG - 2011-08-10 14:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 14:46:12 --> Database Driver Class Initialized
DEBUG - 2011-08-10 14:46:13 --> Final output sent to browser
DEBUG - 2011-08-10 14:46:13 --> Total execution time: 0.8452
DEBUG - 2011-08-10 14:52:40 --> Config Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Hooks Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Utf8 Class Initialized
DEBUG - 2011-08-10 14:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 14:52:40 --> URI Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Router Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Output Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Input Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 14:52:40 --> Language Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Loader Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Controller Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Model Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Model Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Model Class Initialized
DEBUG - 2011-08-10 14:52:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 14:52:40 --> Database Driver Class Initialized
DEBUG - 2011-08-10 14:52:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 14:52:41 --> Helper loaded: url_helper
DEBUG - 2011-08-10 14:52:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 14:52:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 14:52:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 14:52:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 14:52:41 --> Final output sent to browser
DEBUG - 2011-08-10 14:52:41 --> Total execution time: 0.2717
DEBUG - 2011-08-10 14:53:38 --> Config Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Hooks Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Utf8 Class Initialized
DEBUG - 2011-08-10 14:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 14:53:38 --> URI Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Router Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Output Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Input Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 14:53:38 --> Language Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Loader Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Controller Class Initialized
ERROR - 2011-08-10 14:53:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-10 14:53:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-10 14:53:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 14:53:38 --> Model Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Model Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 14:53:38 --> Database Driver Class Initialized
DEBUG - 2011-08-10 14:53:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-10 14:53:38 --> Helper loaded: url_helper
DEBUG - 2011-08-10 14:53:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 14:53:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 14:53:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 14:53:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 14:53:38 --> Final output sent to browser
DEBUG - 2011-08-10 14:53:38 --> Total execution time: 0.0715
DEBUG - 2011-08-10 14:53:38 --> Config Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Hooks Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Utf8 Class Initialized
DEBUG - 2011-08-10 14:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 14:53:38 --> URI Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Router Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Output Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Input Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 14:53:38 --> Language Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Loader Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Controller Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Model Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Model Class Initialized
DEBUG - 2011-08-10 14:53:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 14:53:38 --> Database Driver Class Initialized
DEBUG - 2011-08-10 14:53:39 --> Final output sent to browser
DEBUG - 2011-08-10 14:53:39 --> Total execution time: 0.5898
DEBUG - 2011-08-10 14:53:40 --> Config Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Hooks Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Utf8 Class Initialized
DEBUG - 2011-08-10 14:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 14:53:40 --> URI Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Router Class Initialized
ERROR - 2011-08-10 14:53:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 14:53:40 --> Config Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Hooks Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Utf8 Class Initialized
DEBUG - 2011-08-10 14:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 14:53:40 --> URI Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Router Class Initialized
ERROR - 2011-08-10 14:53:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 14:53:40 --> Config Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Hooks Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Utf8 Class Initialized
DEBUG - 2011-08-10 14:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 14:53:40 --> URI Class Initialized
DEBUG - 2011-08-10 14:53:40 --> Router Class Initialized
ERROR - 2011-08-10 14:53:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 14:53:46 --> Config Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Hooks Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Utf8 Class Initialized
DEBUG - 2011-08-10 14:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 14:53:46 --> URI Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Router Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Output Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Input Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 14:53:46 --> Language Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Loader Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Controller Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Model Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Model Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Model Class Initialized
DEBUG - 2011-08-10 14:53:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 14:53:46 --> Database Driver Class Initialized
DEBUG - 2011-08-10 14:53:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 14:53:46 --> Helper loaded: url_helper
DEBUG - 2011-08-10 14:53:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 14:53:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 14:53:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 14:53:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 14:53:46 --> Final output sent to browser
DEBUG - 2011-08-10 14:53:46 --> Total execution time: 0.0491
DEBUG - 2011-08-10 15:16:07 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:07 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Router Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Output Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Input Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:16:07 --> Language Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Loader Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Controller Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:16:07 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:16:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:16:07 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:16:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:16:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:16:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:16:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:16:07 --> Final output sent to browser
DEBUG - 2011-08-10 15:16:07 --> Total execution time: 0.4482
DEBUG - 2011-08-10 15:16:09 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:09 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:09 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:09 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:09 --> Router Class Initialized
ERROR - 2011-08-10 15:16:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:16:19 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:19 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Router Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Output Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Input Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:16:19 --> Language Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Loader Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Controller Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:16:19 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:16:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:16:19 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:16:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:16:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:16:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:16:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:16:19 --> Final output sent to browser
DEBUG - 2011-08-10 15:16:19 --> Total execution time: 0.5055
DEBUG - 2011-08-10 15:16:21 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:21 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:21 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:21 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:21 --> Router Class Initialized
ERROR - 2011-08-10 15:16:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:16:31 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:31 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Router Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Output Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Input Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:16:31 --> Language Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Loader Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Controller Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:16:31 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:16:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:16:31 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:16:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:16:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:16:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:16:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:16:31 --> Final output sent to browser
DEBUG - 2011-08-10 15:16:31 --> Total execution time: 0.3424
DEBUG - 2011-08-10 15:16:32 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:32 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Router Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Output Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Input Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:16:32 --> Language Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Loader Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Controller Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:16:32 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:16:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:16:32 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:16:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:16:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:16:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:16:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:16:32 --> Final output sent to browser
DEBUG - 2011-08-10 15:16:32 --> Total execution time: 0.0641
DEBUG - 2011-08-10 15:16:33 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:33 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:33 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:33 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:33 --> Router Class Initialized
ERROR - 2011-08-10 15:16:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:16:57 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:57 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Router Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Output Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Input Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:16:57 --> Language Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Loader Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Controller Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:16:57 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:16:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:16:57 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:16:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:16:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:16:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:16:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:16:57 --> Final output sent to browser
DEBUG - 2011-08-10 15:16:57 --> Total execution time: 0.2395
DEBUG - 2011-08-10 15:16:58 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:58 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Router Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Output Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Input Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:16:58 --> Language Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Loader Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Controller Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:16:58 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:16:58 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:16:58 --> Final output sent to browser
DEBUG - 2011-08-10 15:16:58 --> Total execution time: 0.0620
DEBUG - 2011-08-10 15:16:58 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:58 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Router Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Output Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Input Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:16:58 --> Language Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Loader Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Controller Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Model Class Initialized
DEBUG - 2011-08-10 15:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:16:58 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:16:58 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:16:58 --> Final output sent to browser
DEBUG - 2011-08-10 15:16:58 --> Total execution time: 0.0640
DEBUG - 2011-08-10 15:16:59 --> Config Class Initialized
DEBUG - 2011-08-10 15:16:59 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:16:59 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:16:59 --> URI Class Initialized
DEBUG - 2011-08-10 15:16:59 --> Router Class Initialized
ERROR - 2011-08-10 15:16:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:17:11 --> Config Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:17:11 --> URI Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Router Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Output Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Input Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:17:11 --> Language Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Loader Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Controller Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:17:11 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:17:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:17:11 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:17:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:17:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:17:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:17:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:17:11 --> Final output sent to browser
DEBUG - 2011-08-10 15:17:11 --> Total execution time: 0.2986
DEBUG - 2011-08-10 15:17:12 --> Config Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:17:12 --> URI Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Router Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Output Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Input Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:17:12 --> Language Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Loader Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Controller Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:17:12 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:17:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:17:12 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:17:12 --> Final output sent to browser
DEBUG - 2011-08-10 15:17:12 --> Total execution time: 0.0468
DEBUG - 2011-08-10 15:17:12 --> Config Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:17:12 --> URI Class Initialized
DEBUG - 2011-08-10 15:17:12 --> Router Class Initialized
ERROR - 2011-08-10 15:17:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:17:24 --> Config Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:17:24 --> URI Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Router Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Output Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Input Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:17:24 --> Language Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Loader Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Controller Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:17:24 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:17:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:17:25 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:17:25 --> Final output sent to browser
DEBUG - 2011-08-10 15:17:25 --> Total execution time: 0.7643
DEBUG - 2011-08-10 15:17:26 --> Config Class Initialized
DEBUG - 2011-08-10 15:17:26 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:17:26 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:17:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:17:26 --> URI Class Initialized
DEBUG - 2011-08-10 15:17:26 --> Router Class Initialized
ERROR - 2011-08-10 15:17:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:17:28 --> Config Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:17:28 --> URI Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Router Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Output Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Input Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:17:28 --> Language Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Loader Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Controller Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Model Class Initialized
DEBUG - 2011-08-10 15:17:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:17:28 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:17:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:17:28 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:17:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:17:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:17:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:17:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:17:28 --> Final output sent to browser
DEBUG - 2011-08-10 15:17:28 --> Total execution time: 0.0462
DEBUG - 2011-08-10 15:19:39 --> Config Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:19:39 --> URI Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Router Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Output Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Input Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:19:39 --> Language Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Loader Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Controller Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Model Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Model Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Model Class Initialized
DEBUG - 2011-08-10 15:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:19:39 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:19:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:19:39 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:19:39 --> Final output sent to browser
DEBUG - 2011-08-10 15:19:39 --> Total execution time: 0.1739
DEBUG - 2011-08-10 15:19:41 --> Config Class Initialized
DEBUG - 2011-08-10 15:19:41 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:19:41 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:19:41 --> URI Class Initialized
DEBUG - 2011-08-10 15:19:41 --> Router Class Initialized
ERROR - 2011-08-10 15:19:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:20:20 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:20 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Router Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Output Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Input Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:20:20 --> Language Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Loader Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Controller Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:20:20 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:20:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:20:20 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:20:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:20:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:20:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:20:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:20:20 --> Final output sent to browser
DEBUG - 2011-08-10 15:20:20 --> Total execution time: 0.6059
DEBUG - 2011-08-10 15:20:21 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:21 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Router Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Output Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Input Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:20:21 --> Language Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Loader Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Controller Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:20:21 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:20:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:20:22 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:20:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:20:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:20:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:20:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:20:22 --> Final output sent to browser
DEBUG - 2011-08-10 15:20:22 --> Total execution time: 0.0541
DEBUG - 2011-08-10 15:20:22 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:22 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:22 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:22 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:22 --> Router Class Initialized
ERROR - 2011-08-10 15:20:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:20:28 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:28 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Router Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Output Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Input Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:20:28 --> Language Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Loader Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Controller Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:20:28 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:20:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:20:28 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:20:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:20:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:20:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:20:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:20:28 --> Final output sent to browser
DEBUG - 2011-08-10 15:20:28 --> Total execution time: 0.2494
DEBUG - 2011-08-10 15:20:29 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:29 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Router Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Output Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Input Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:20:29 --> Language Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Loader Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Controller Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:20:29 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:20:29 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:20:29 --> Final output sent to browser
DEBUG - 2011-08-10 15:20:29 --> Total execution time: 0.0484
DEBUG - 2011-08-10 15:20:29 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:29 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Router Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Output Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Input Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:20:29 --> Language Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Loader Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Controller Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:20:29 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:20:29 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:20:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:20:29 --> Final output sent to browser
DEBUG - 2011-08-10 15:20:29 --> Total execution time: 0.0478
DEBUG - 2011-08-10 15:20:29 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:29 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:29 --> Router Class Initialized
ERROR - 2011-08-10 15:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:20:37 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:37 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Router Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Output Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Input Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:20:37 --> Language Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Loader Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Controller Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:20:37 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:20:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:20:37 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:20:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:20:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:20:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:20:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:20:37 --> Final output sent to browser
DEBUG - 2011-08-10 15:20:37 --> Total execution time: 0.2292
DEBUG - 2011-08-10 15:20:38 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:38 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Router Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Output Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Input Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:20:38 --> Language Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Loader Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Controller Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:20:38 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:20:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:20:38 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:20:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:20:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:20:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:20:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:20:38 --> Final output sent to browser
DEBUG - 2011-08-10 15:20:38 --> Total execution time: 0.0461
DEBUG - 2011-08-10 15:20:38 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:38 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:38 --> Router Class Initialized
ERROR - 2011-08-10 15:20:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:20:56 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:56 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Router Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Output Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Input Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:20:56 --> Language Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Loader Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Controller Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Model Class Initialized
DEBUG - 2011-08-10 15:20:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:20:56 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:20:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:20:56 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:20:56 --> Final output sent to browser
DEBUG - 2011-08-10 15:20:56 --> Total execution time: 0.3144
DEBUG - 2011-08-10 15:20:58 --> Config Class Initialized
DEBUG - 2011-08-10 15:20:58 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:20:58 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:20:58 --> URI Class Initialized
DEBUG - 2011-08-10 15:20:58 --> Router Class Initialized
ERROR - 2011-08-10 15:20:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:21:01 --> Config Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:21:01 --> URI Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Router Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Output Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Input Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:21:01 --> Language Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Loader Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Controller Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Model Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Model Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Model Class Initialized
DEBUG - 2011-08-10 15:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:21:01 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:21:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:21:01 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:21:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:21:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:21:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:21:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:21:01 --> Final output sent to browser
DEBUG - 2011-08-10 15:21:01 --> Total execution time: 0.1940
DEBUG - 2011-08-10 15:21:05 --> Config Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:21:05 --> URI Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Router Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Output Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Input Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:21:05 --> Language Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Loader Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Controller Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Model Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Model Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Model Class Initialized
DEBUG - 2011-08-10 15:21:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:21:05 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:21:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:21:06 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:21:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:21:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:21:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:21:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:21:06 --> Final output sent to browser
DEBUG - 2011-08-10 15:21:06 --> Total execution time: 0.3151
DEBUG - 2011-08-10 15:21:07 --> Config Class Initialized
DEBUG - 2011-08-10 15:21:07 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:21:07 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:21:07 --> URI Class Initialized
DEBUG - 2011-08-10 15:21:07 --> Router Class Initialized
ERROR - 2011-08-10 15:21:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:32:18 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:18 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Router Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Output Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Input Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:32:18 --> Language Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Loader Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Controller Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:32:18 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:32:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:32:19 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:32:19 --> Final output sent to browser
DEBUG - 2011-08-10 15:32:19 --> Total execution time: 0.3076
DEBUG - 2011-08-10 15:32:20 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:20 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:20 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:20 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:20 --> Router Class Initialized
ERROR - 2011-08-10 15:32:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:32:24 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:24 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Router Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Output Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Input Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:32:24 --> Language Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Loader Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Controller Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:32:24 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:32:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:32:24 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:32:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:32:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:32:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:32:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:32:24 --> Final output sent to browser
DEBUG - 2011-08-10 15:32:24 --> Total execution time: 0.0446
DEBUG - 2011-08-10 15:32:25 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:25 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Router Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Output Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Input Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:32:25 --> Language Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Loader Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Controller Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:32:25 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:32:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:32:25 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:32:25 --> Final output sent to browser
DEBUG - 2011-08-10 15:32:25 --> Total execution time: 0.2773
DEBUG - 2011-08-10 15:32:26 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:26 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Router Class Initialized
ERROR - 2011-08-10 15:32:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:32:26 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:26 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Router Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Output Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Input Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:32:26 --> Language Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Loader Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Controller Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:32:26 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:32:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:32:26 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:32:26 --> Final output sent to browser
DEBUG - 2011-08-10 15:32:26 --> Total execution time: 0.0411
DEBUG - 2011-08-10 15:32:31 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:31 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Router Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Output Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Input Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:32:31 --> Language Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Loader Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Controller Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:32:31 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:32:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:32:31 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:32:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:32:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:32:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:32:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:32:31 --> Final output sent to browser
DEBUG - 2011-08-10 15:32:31 --> Total execution time: 0.5126
DEBUG - 2011-08-10 15:32:33 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:33 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:33 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:33 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:33 --> Router Class Initialized
ERROR - 2011-08-10 15:32:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 15:32:34 --> Config Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:32:34 --> URI Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Router Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Output Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Input Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:32:34 --> Language Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Loader Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Controller Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Model Class Initialized
DEBUG - 2011-08-10 15:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:32:34 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:32:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:32:34 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:32:34 --> Final output sent to browser
DEBUG - 2011-08-10 15:32:34 --> Total execution time: 0.0426
DEBUG - 2011-08-10 15:34:20 --> Config Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:34:20 --> URI Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Router Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Output Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Input Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:34:20 --> Language Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Loader Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Controller Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Model Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Model Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Model Class Initialized
DEBUG - 2011-08-10 15:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:34:20 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:34:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:34:21 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:34:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:34:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:34:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:34:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:34:21 --> Final output sent to browser
DEBUG - 2011-08-10 15:34:21 --> Total execution time: 0.2518
DEBUG - 2011-08-10 15:34:22 --> Config Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:34:22 --> URI Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Router Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Output Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Input Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 15:34:22 --> Language Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Loader Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Controller Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Model Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Model Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Model Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 15:34:22 --> Database Driver Class Initialized
DEBUG - 2011-08-10 15:34:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 15:34:22 --> Helper loaded: url_helper
DEBUG - 2011-08-10 15:34:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 15:34:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 15:34:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 15:34:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 15:34:22 --> Final output sent to browser
DEBUG - 2011-08-10 15:34:22 --> Total execution time: 0.0489
DEBUG - 2011-08-10 15:34:22 --> Config Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Hooks Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Utf8 Class Initialized
DEBUG - 2011-08-10 15:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 15:34:22 --> URI Class Initialized
DEBUG - 2011-08-10 15:34:22 --> Router Class Initialized
ERROR - 2011-08-10 15:34:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 18:02:19 --> Config Class Initialized
DEBUG - 2011-08-10 18:02:19 --> Hooks Class Initialized
DEBUG - 2011-08-10 18:02:19 --> Utf8 Class Initialized
DEBUG - 2011-08-10 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 18:02:19 --> URI Class Initialized
DEBUG - 2011-08-10 18:02:19 --> Router Class Initialized
ERROR - 2011-08-10 18:02:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 18:53:50 --> Config Class Initialized
DEBUG - 2011-08-10 18:53:50 --> Hooks Class Initialized
DEBUG - 2011-08-10 18:53:50 --> Utf8 Class Initialized
DEBUG - 2011-08-10 18:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 18:53:50 --> URI Class Initialized
DEBUG - 2011-08-10 18:53:50 --> Router Class Initialized
DEBUG - 2011-08-10 18:53:50 --> No URI present. Default controller set.
DEBUG - 2011-08-10 18:53:50 --> Output Class Initialized
DEBUG - 2011-08-10 18:53:50 --> Input Class Initialized
DEBUG - 2011-08-10 18:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 18:53:50 --> Language Class Initialized
DEBUG - 2011-08-10 18:53:50 --> Loader Class Initialized
DEBUG - 2011-08-10 18:53:50 --> Controller Class Initialized
DEBUG - 2011-08-10 18:53:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-10 18:53:50 --> Helper loaded: url_helper
DEBUG - 2011-08-10 18:53:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 18:53:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 18:53:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 18:53:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 18:53:50 --> Final output sent to browser
DEBUG - 2011-08-10 18:53:50 --> Total execution time: 0.2236
DEBUG - 2011-08-10 18:53:56 --> Config Class Initialized
DEBUG - 2011-08-10 18:53:56 --> Hooks Class Initialized
DEBUG - 2011-08-10 18:53:56 --> Utf8 Class Initialized
DEBUG - 2011-08-10 18:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 18:53:56 --> URI Class Initialized
DEBUG - 2011-08-10 18:53:56 --> Router Class Initialized
ERROR - 2011-08-10 18:53:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 18:54:18 --> Config Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Hooks Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Utf8 Class Initialized
DEBUG - 2011-08-10 18:54:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 18:54:18 --> URI Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Router Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Output Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Input Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 18:54:18 --> Language Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Loader Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Controller Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Model Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Model Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Model Class Initialized
DEBUG - 2011-08-10 18:54:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 18:54:18 --> Database Driver Class Initialized
DEBUG - 2011-08-10 18:54:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 18:54:19 --> Helper loaded: url_helper
DEBUG - 2011-08-10 18:54:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 18:54:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 18:54:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 18:54:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 18:54:19 --> Final output sent to browser
DEBUG - 2011-08-10 18:54:19 --> Total execution time: 0.3682
DEBUG - 2011-08-10 18:54:21 --> Config Class Initialized
DEBUG - 2011-08-10 18:54:21 --> Hooks Class Initialized
DEBUG - 2011-08-10 18:54:21 --> Utf8 Class Initialized
DEBUG - 2011-08-10 18:54:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 18:54:21 --> URI Class Initialized
DEBUG - 2011-08-10 18:54:21 --> Router Class Initialized
ERROR - 2011-08-10 18:54:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-10 18:58:22 --> Config Class Initialized
DEBUG - 2011-08-10 18:58:22 --> Hooks Class Initialized
DEBUG - 2011-08-10 18:58:22 --> Utf8 Class Initialized
DEBUG - 2011-08-10 18:58:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 18:58:22 --> URI Class Initialized
DEBUG - 2011-08-10 18:58:22 --> Router Class Initialized
ERROR - 2011-08-10 18:58:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 22:45:45 --> Config Class Initialized
DEBUG - 2011-08-10 22:45:45 --> Hooks Class Initialized
DEBUG - 2011-08-10 22:45:45 --> Utf8 Class Initialized
DEBUG - 2011-08-10 22:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 22:45:45 --> URI Class Initialized
DEBUG - 2011-08-10 22:45:45 --> Router Class Initialized
DEBUG - 2011-08-10 22:45:45 --> No URI present. Default controller set.
DEBUG - 2011-08-10 22:45:45 --> Output Class Initialized
DEBUG - 2011-08-10 22:45:45 --> Input Class Initialized
DEBUG - 2011-08-10 22:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 22:45:45 --> Language Class Initialized
DEBUG - 2011-08-10 22:45:45 --> Loader Class Initialized
DEBUG - 2011-08-10 22:45:45 --> Controller Class Initialized
DEBUG - 2011-08-10 22:45:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-10 22:45:45 --> Helper loaded: url_helper
DEBUG - 2011-08-10 22:45:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 22:45:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 22:45:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 22:45:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 22:45:45 --> Final output sent to browser
DEBUG - 2011-08-10 22:45:45 --> Total execution time: 0.2078
DEBUG - 2011-08-10 22:49:47 --> Config Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Hooks Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Utf8 Class Initialized
DEBUG - 2011-08-10 22:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 22:49:47 --> URI Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Router Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Output Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Input Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 22:49:47 --> Language Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Loader Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Controller Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Model Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Model Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Model Class Initialized
DEBUG - 2011-08-10 22:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-10 22:49:47 --> Database Driver Class Initialized
DEBUG - 2011-08-10 22:49:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-10 22:49:48 --> Helper loaded: url_helper
DEBUG - 2011-08-10 22:49:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 22:49:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 22:49:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 22:49:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 22:49:48 --> Final output sent to browser
DEBUG - 2011-08-10 22:49:48 --> Total execution time: 0.5104
DEBUG - 2011-08-10 23:16:41 --> Config Class Initialized
DEBUG - 2011-08-10 23:16:41 --> Hooks Class Initialized
DEBUG - 2011-08-10 23:16:41 --> Utf8 Class Initialized
DEBUG - 2011-08-10 23:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 23:16:41 --> URI Class Initialized
DEBUG - 2011-08-10 23:16:41 --> Router Class Initialized
ERROR - 2011-08-10 23:16:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-10 23:40:16 --> Config Class Initialized
DEBUG - 2011-08-10 23:40:16 --> Hooks Class Initialized
DEBUG - 2011-08-10 23:40:16 --> Utf8 Class Initialized
DEBUG - 2011-08-10 23:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-10 23:40:16 --> URI Class Initialized
DEBUG - 2011-08-10 23:40:16 --> Router Class Initialized
DEBUG - 2011-08-10 23:40:16 --> No URI present. Default controller set.
DEBUG - 2011-08-10 23:40:16 --> Output Class Initialized
DEBUG - 2011-08-10 23:40:16 --> Input Class Initialized
DEBUG - 2011-08-10 23:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-10 23:40:16 --> Language Class Initialized
DEBUG - 2011-08-10 23:40:16 --> Loader Class Initialized
DEBUG - 2011-08-10 23:40:16 --> Controller Class Initialized
DEBUG - 2011-08-10 23:40:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-10 23:40:16 --> Helper loaded: url_helper
DEBUG - 2011-08-10 23:40:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-10 23:40:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-10 23:40:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-10 23:40:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-10 23:40:16 --> Final output sent to browser
DEBUG - 2011-08-10 23:40:16 --> Total execution time: 0.0148

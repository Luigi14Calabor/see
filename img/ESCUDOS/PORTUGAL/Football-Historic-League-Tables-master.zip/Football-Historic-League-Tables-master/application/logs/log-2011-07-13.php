<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-13 00:12:18 --> Config Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Hooks Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Utf8 Class Initialized
DEBUG - 2011-07-13 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 00:12:18 --> URI Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Router Class Initialized
ERROR - 2011-07-13 00:12:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-13 00:12:18 --> Config Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Hooks Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Utf8 Class Initialized
DEBUG - 2011-07-13 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 00:12:18 --> URI Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Router Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Output Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Input Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 00:12:18 --> Language Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Loader Class Initialized
DEBUG - 2011-07-13 00:12:18 --> Controller Class Initialized
ERROR - 2011-07-13 00:12:18 --> 404 Page Not Found --> snakes/image%3Fcode%3Deng12010
DEBUG - 2011-07-13 02:04:03 --> Config Class Initialized
DEBUG - 2011-07-13 02:04:03 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:04:03 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:04:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:04:03 --> URI Class Initialized
DEBUG - 2011-07-13 02:04:03 --> Router Class Initialized
ERROR - 2011-07-13 02:04:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-13 02:04:36 --> Config Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:04:36 --> URI Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Router Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Output Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Input Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:04:36 --> Language Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Loader Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Controller Class Initialized
ERROR - 2011-07-13 02:04:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 02:04:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 02:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:04:36 --> Model Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Model Class Initialized
DEBUG - 2011-07-13 02:04:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:04:36 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:04:36 --> Helper loaded: url_helper
DEBUG - 2011-07-13 02:04:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 02:04:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 02:04:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 02:04:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 02:04:36 --> Final output sent to browser
DEBUG - 2011-07-13 02:04:36 --> Total execution time: 0.3515
DEBUG - 2011-07-13 02:54:13 --> Config Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:54:13 --> URI Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Router Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Output Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Input Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:54:13 --> Language Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Loader Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Controller Class Initialized
ERROR - 2011-07-13 02:54:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 02:54:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 02:54:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:54:13 --> Model Class Initialized
DEBUG - 2011-07-13 02:54:13 --> Model Class Initialized
DEBUG - 2011-07-13 02:54:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:54:14 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:54:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:54:15 --> Helper loaded: url_helper
DEBUG - 2011-07-13 02:54:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 02:54:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 02:54:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 02:54:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 02:54:17 --> Final output sent to browser
DEBUG - 2011-07-13 02:54:17 --> Total execution time: 4.5880
DEBUG - 2011-07-13 02:54:18 --> Config Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:54:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:54:18 --> URI Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Router Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Output Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Input Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:54:18 --> Language Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Loader Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Controller Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Model Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Model Class Initialized
DEBUG - 2011-07-13 02:54:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:54:18 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:54:19 --> Final output sent to browser
DEBUG - 2011-07-13 02:54:19 --> Total execution time: 1.1786
DEBUG - 2011-07-13 02:54:20 --> Config Class Initialized
DEBUG - 2011-07-13 02:54:20 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:54:20 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:54:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:54:20 --> URI Class Initialized
DEBUG - 2011-07-13 02:54:20 --> Router Class Initialized
ERROR - 2011-07-13 02:54:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 02:54:20 --> Config Class Initialized
DEBUG - 2011-07-13 02:54:20 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:54:20 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:54:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:54:20 --> URI Class Initialized
DEBUG - 2011-07-13 02:54:20 --> Router Class Initialized
ERROR - 2011-07-13 02:54:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 02:55:21 --> Config Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:55:21 --> URI Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Router Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Output Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Input Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:55:21 --> Language Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Loader Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Controller Class Initialized
ERROR - 2011-07-13 02:55:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 02:55:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 02:55:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:55:21 --> Model Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Model Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:55:21 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:55:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:55:21 --> Helper loaded: url_helper
DEBUG - 2011-07-13 02:55:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 02:55:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 02:55:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 02:55:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 02:55:21 --> Final output sent to browser
DEBUG - 2011-07-13 02:55:21 --> Total execution time: 0.0315
DEBUG - 2011-07-13 02:55:21 --> Config Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:55:21 --> URI Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Router Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Output Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Input Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:55:21 --> Language Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Loader Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Controller Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Model Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Model Class Initialized
DEBUG - 2011-07-13 02:55:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:55:21 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:55:22 --> Final output sent to browser
DEBUG - 2011-07-13 02:55:22 --> Total execution time: 0.5980
DEBUG - 2011-07-13 02:55:52 --> Config Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:55:52 --> URI Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Router Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Output Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Input Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:55:52 --> Language Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Loader Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Controller Class Initialized
ERROR - 2011-07-13 02:55:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 02:55:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 02:55:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:55:52 --> Model Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Model Class Initialized
DEBUG - 2011-07-13 02:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:55:52 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:55:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:55:52 --> Helper loaded: url_helper
DEBUG - 2011-07-13 02:55:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 02:55:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 02:55:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 02:55:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 02:55:52 --> Final output sent to browser
DEBUG - 2011-07-13 02:55:52 --> Total execution time: 0.0282
DEBUG - 2011-07-13 02:55:53 --> Config Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:55:53 --> URI Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Router Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Output Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Input Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:55:53 --> Language Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Loader Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Controller Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Model Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Model Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:55:53 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:55:53 --> Final output sent to browser
DEBUG - 2011-07-13 02:55:53 --> Total execution time: 0.5041
DEBUG - 2011-07-13 02:56:02 --> Config Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:56:02 --> URI Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Router Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Output Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Input Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:56:02 --> Language Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Loader Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Controller Class Initialized
ERROR - 2011-07-13 02:56:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 02:56:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 02:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:56:02 --> Model Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Model Class Initialized
DEBUG - 2011-07-13 02:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:56:02 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:56:02 --> Helper loaded: url_helper
DEBUG - 2011-07-13 02:56:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 02:56:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 02:56:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 02:56:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 02:56:02 --> Final output sent to browser
DEBUG - 2011-07-13 02:56:02 --> Total execution time: 0.0288
DEBUG - 2011-07-13 02:56:03 --> Config Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:56:03 --> URI Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Router Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Output Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Input Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:56:03 --> Language Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Loader Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Controller Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Model Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Model Class Initialized
DEBUG - 2011-07-13 02:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:56:03 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:56:05 --> Final output sent to browser
DEBUG - 2011-07-13 02:56:05 --> Total execution time: 1.9108
DEBUG - 2011-07-13 02:56:12 --> Config Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:56:12 --> URI Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Router Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Output Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Input Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:56:12 --> Language Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Loader Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Controller Class Initialized
ERROR - 2011-07-13 02:56:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 02:56:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 02:56:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:56:12 --> Model Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Model Class Initialized
DEBUG - 2011-07-13 02:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:56:12 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:56:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 02:56:12 --> Helper loaded: url_helper
DEBUG - 2011-07-13 02:56:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 02:56:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 02:56:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 02:56:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 02:56:12 --> Final output sent to browser
DEBUG - 2011-07-13 02:56:12 --> Total execution time: 0.0301
DEBUG - 2011-07-13 02:56:13 --> Config Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Hooks Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Utf8 Class Initialized
DEBUG - 2011-07-13 02:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 02:56:13 --> URI Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Router Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Output Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Input Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 02:56:13 --> Language Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Loader Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Controller Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Model Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Model Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 02:56:13 --> Database Driver Class Initialized
DEBUG - 2011-07-13 02:56:13 --> Final output sent to browser
DEBUG - 2011-07-13 02:56:13 --> Total execution time: 0.5467
DEBUG - 2011-07-13 04:05:40 --> Config Class Initialized
DEBUG - 2011-07-13 04:05:40 --> Hooks Class Initialized
DEBUG - 2011-07-13 04:05:40 --> Utf8 Class Initialized
DEBUG - 2011-07-13 04:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 04:05:40 --> URI Class Initialized
DEBUG - 2011-07-13 04:05:40 --> Router Class Initialized
DEBUG - 2011-07-13 04:05:40 --> No URI present. Default controller set.
DEBUG - 2011-07-13 04:05:40 --> Output Class Initialized
DEBUG - 2011-07-13 04:05:40 --> Input Class Initialized
DEBUG - 2011-07-13 04:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 04:05:40 --> Language Class Initialized
DEBUG - 2011-07-13 04:05:40 --> Loader Class Initialized
DEBUG - 2011-07-13 04:05:40 --> Controller Class Initialized
DEBUG - 2011-07-13 04:05:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-13 04:05:40 --> Helper loaded: url_helper
DEBUG - 2011-07-13 04:05:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 04:05:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 04:05:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 04:05:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 04:05:40 --> Final output sent to browser
DEBUG - 2011-07-13 04:05:40 --> Total execution time: 0.2867
DEBUG - 2011-07-13 04:32:41 --> Config Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Hooks Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Utf8 Class Initialized
DEBUG - 2011-07-13 04:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 04:32:41 --> URI Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Router Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Output Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Input Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 04:32:41 --> Language Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Loader Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Controller Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Model Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Model Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Model Class Initialized
DEBUG - 2011-07-13 04:32:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 04:32:41 --> Database Driver Class Initialized
DEBUG - 2011-07-13 04:32:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 04:32:41 --> Helper loaded: url_helper
DEBUG - 2011-07-13 04:32:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 04:32:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 04:32:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 04:32:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 04:32:41 --> Final output sent to browser
DEBUG - 2011-07-13 04:32:41 --> Total execution time: 0.5476
DEBUG - 2011-07-13 04:32:43 --> Config Class Initialized
DEBUG - 2011-07-13 04:32:43 --> Hooks Class Initialized
DEBUG - 2011-07-13 04:32:43 --> Utf8 Class Initialized
DEBUG - 2011-07-13 04:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 04:32:43 --> URI Class Initialized
DEBUG - 2011-07-13 04:32:43 --> Router Class Initialized
ERROR - 2011-07-13 04:32:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 04:32:44 --> Config Class Initialized
DEBUG - 2011-07-13 04:32:44 --> Hooks Class Initialized
DEBUG - 2011-07-13 04:32:44 --> Utf8 Class Initialized
DEBUG - 2011-07-13 04:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 04:32:44 --> URI Class Initialized
DEBUG - 2011-07-13 04:32:44 --> Router Class Initialized
ERROR - 2011-07-13 04:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 04:32:44 --> Config Class Initialized
DEBUG - 2011-07-13 04:32:44 --> Hooks Class Initialized
DEBUG - 2011-07-13 04:32:44 --> Utf8 Class Initialized
DEBUG - 2011-07-13 04:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 04:32:44 --> URI Class Initialized
DEBUG - 2011-07-13 04:32:44 --> Router Class Initialized
ERROR - 2011-07-13 04:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 06:16:32 --> Config Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:16:32 --> URI Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Router Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Output Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Input Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 06:16:32 --> Language Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Loader Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Controller Class Initialized
ERROR - 2011-07-13 06:16:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 06:16:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 06:16:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 06:16:32 --> Model Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Model Class Initialized
DEBUG - 2011-07-13 06:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 06:16:32 --> Database Driver Class Initialized
DEBUG - 2011-07-13 06:16:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 06:16:32 --> Helper loaded: url_helper
DEBUG - 2011-07-13 06:16:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 06:16:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 06:16:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 06:16:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 06:16:32 --> Final output sent to browser
DEBUG - 2011-07-13 06:16:32 --> Total execution time: 0.4768
DEBUG - 2011-07-13 06:16:34 --> Config Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:16:34 --> URI Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Router Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Output Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Input Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 06:16:34 --> Language Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Loader Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Controller Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Model Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Model Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 06:16:34 --> Database Driver Class Initialized
DEBUG - 2011-07-13 06:16:34 --> Final output sent to browser
DEBUG - 2011-07-13 06:16:34 --> Total execution time: 0.7611
DEBUG - 2011-07-13 06:16:35 --> Config Class Initialized
DEBUG - 2011-07-13 06:16:35 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:16:35 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:16:35 --> URI Class Initialized
DEBUG - 2011-07-13 06:16:35 --> Router Class Initialized
ERROR - 2011-07-13 06:16:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 06:16:36 --> Config Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:16:36 --> URI Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Router Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Output Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Input Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 06:16:36 --> Language Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Loader Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Controller Class Initialized
ERROR - 2011-07-13 06:16:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 06:16:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 06:16:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 06:16:36 --> Model Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Model Class Initialized
DEBUG - 2011-07-13 06:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 06:16:36 --> Database Driver Class Initialized
DEBUG - 2011-07-13 06:16:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 06:16:36 --> Helper loaded: url_helper
DEBUG - 2011-07-13 06:16:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 06:16:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 06:16:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 06:16:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 06:16:36 --> Final output sent to browser
DEBUG - 2011-07-13 06:16:36 --> Total execution time: 0.0267
DEBUG - 2011-07-13 06:42:23 --> Config Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:42:23 --> URI Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Router Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Output Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Input Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 06:42:23 --> Language Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Loader Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Controller Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 06:42:23 --> Database Driver Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Config Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:42:23 --> URI Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Router Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Output Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Input Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 06:42:23 --> Language Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Loader Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Controller Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 06:42:24 --> Database Driver Class Initialized
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 06:42:24 --> Helper loaded: url_helper
DEBUG - 2011-07-13 06:42:24 --> Helper loaded: url_helper
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 06:42:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 06:42:24 --> Final output sent to browser
DEBUG - 2011-07-13 06:42:24 --> Total execution time: 0.4575
DEBUG - 2011-07-13 06:42:24 --> Final output sent to browser
DEBUG - 2011-07-13 06:42:24 --> Total execution time: 0.2568
DEBUG - 2011-07-13 06:42:29 --> Config Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:42:29 --> URI Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Router Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Output Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Input Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 06:42:29 --> Language Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Loader Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Controller Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Model Class Initialized
DEBUG - 2011-07-13 06:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 06:42:29 --> Database Driver Class Initialized
DEBUG - 2011-07-13 06:42:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 06:42:29 --> Helper loaded: url_helper
DEBUG - 2011-07-13 06:42:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 06:42:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 06:42:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 06:42:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 06:42:29 --> Final output sent to browser
DEBUG - 2011-07-13 06:42:29 --> Total execution time: 0.0434
DEBUG - 2011-07-13 06:42:32 --> Config Class Initialized
DEBUG - 2011-07-13 06:42:32 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:42:32 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:42:32 --> URI Class Initialized
DEBUG - 2011-07-13 06:42:32 --> Router Class Initialized
ERROR - 2011-07-13 06:42:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 06:47:31 --> Config Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Config Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Hooks Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Utf8 Class Initialized
DEBUG - 2011-07-13 06:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 06:47:31 --> URI Class Initialized
DEBUG - 2011-07-13 06:47:31 --> URI Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Router Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Router Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Output Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Output Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Input Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 06:47:31 --> Language Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Input Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 06:47:31 --> Language Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Loader Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Controller Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Loader Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Controller Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Model Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Model Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Model Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-07-13 06:47:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 06:47:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 06:47:31 --> Model Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Model Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 06:47:31 --> Database Driver Class Initialized
DEBUG - 2011-07-13 06:47:31 --> Database Driver Class Initialized
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 06:47:31 --> Helper loaded: url_helper
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 06:47:31 --> Final output sent to browser
DEBUG - 2011-07-13 06:47:31 --> Total execution time: 0.0725
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 06:47:31 --> Helper loaded: url_helper
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 06:47:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 06:47:31 --> Final output sent to browser
DEBUG - 2011-07-13 06:47:31 --> Total execution time: 0.0817
DEBUG - 2011-07-13 07:12:05 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:05 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:05 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:05 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:05 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:05 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:05 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:05 --> Total execution time: 0.2253
DEBUG - 2011-07-13 07:12:05 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:05 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:05 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Controller Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:05 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:06 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:06 --> Total execution time: 0.7416
DEBUG - 2011-07-13 07:12:07 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:07 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:07 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:07 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:07 --> Router Class Initialized
ERROR - 2011-07-13 07:12:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 07:12:07 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:07 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:07 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:07 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:07 --> Router Class Initialized
ERROR - 2011-07-13 07:12:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 07:12:08 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:08 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:08 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:08 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:08 --> Router Class Initialized
ERROR - 2011-07-13 07:12:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 07:12:24 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:24 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:24 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:24 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:24 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:24 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:24 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:24 --> Total execution time: 0.0315
DEBUG - 2011-07-13 07:12:24 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:24 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:24 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Controller Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:24 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:25 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:25 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:25 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:25 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:25 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:25 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:25 --> Total execution time: 0.0270
DEBUG - 2011-07-13 07:12:25 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:25 --> Total execution time: 0.8153
DEBUG - 2011-07-13 07:12:32 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:32 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:32 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:32 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:32 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:32 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:32 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:32 --> Total execution time: 0.0276
DEBUG - 2011-07-13 07:12:33 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:33 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:33 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Controller Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:33 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:33 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:33 --> Total execution time: 0.6937
DEBUG - 2011-07-13 07:12:34 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:34 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:34 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:34 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:34 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:34 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:34 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:34 --> Total execution time: 0.0508
DEBUG - 2011-07-13 07:12:43 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:43 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:43 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:43 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:43 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:43 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:43 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:43 --> Total execution time: 0.0403
DEBUG - 2011-07-13 07:12:43 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:43 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:43 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Controller Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:43 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:44 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:44 --> Total execution time: 0.5534
DEBUG - 2011-07-13 07:12:46 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:46 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:46 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:46 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:46 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:46 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:46 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:46 --> Total execution time: 0.0293
DEBUG - 2011-07-13 07:12:56 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:56 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:56 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:56 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:56 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:56 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:56 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:56 --> Total execution time: 0.0267
DEBUG - 2011-07-13 07:12:56 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:56 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:56 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Controller Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:56 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:57 --> Total execution time: 0.7472
DEBUG - 2011-07-13 07:12:57 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:57 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:57 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:57 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:57 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:57 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:57 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:57 --> Total execution time: 0.0285
DEBUG - 2011-07-13 07:12:58 --> Config Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:12:58 --> URI Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Router Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Output Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Input Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:12:58 --> Language Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Loader Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Controller Class Initialized
ERROR - 2011-07-13 07:12:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:12:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:12:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:58 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Model Class Initialized
DEBUG - 2011-07-13 07:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:12:58 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:12:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:12:58 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:12:58 --> Final output sent to browser
DEBUG - 2011-07-13 07:12:58 --> Total execution time: 0.0326
DEBUG - 2011-07-13 07:13:02 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:02 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:02 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:02 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:02 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:02 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:02 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:02 --> Total execution time: 0.0648
DEBUG - 2011-07-13 07:13:03 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:03 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:03 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Controller Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:03 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:03 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:03 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:03 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:03 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:03 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:03 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:03 --> Total execution time: 0.0361
DEBUG - 2011-07-13 07:13:04 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:04 --> Total execution time: 0.7482
DEBUG - 2011-07-13 07:13:04 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:04 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:04 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:04 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:04 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:04 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:04 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:04 --> Total execution time: 0.0266
DEBUG - 2011-07-13 07:13:12 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:12 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:12 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:12 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:12 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:12 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:12 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:12 --> Total execution time: 0.0318
DEBUG - 2011-07-13 07:13:12 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:12 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:12 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Controller Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:12 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:13 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:13 --> Total execution time: 0.6125
DEBUG - 2011-07-13 07:13:18 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:18 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:18 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:18 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:18 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:18 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:18 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:18 --> Total execution time: 0.0570
DEBUG - 2011-07-13 07:13:18 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:18 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:18 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:18 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:18 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:18 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:18 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:18 --> Total execution time: 0.0858
DEBUG - 2011-07-13 07:13:19 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:19 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:19 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Controller Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:19 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:19 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:19 --> Total execution time: 0.8340
DEBUG - 2011-07-13 07:13:25 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:25 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:25 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:25 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:25 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:25 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:25 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:25 --> Total execution time: 0.0296
DEBUG - 2011-07-13 07:13:54 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:54 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:54 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:54 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:54 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:54 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:54 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:54 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:54 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:54 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:55 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:55 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:55 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:55 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:55 --> Total execution time: 0.1924
DEBUG - 2011-07-13 07:13:55 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:55 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:55 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Controller Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:55 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:56 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:56 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:56 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:56 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:56 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:56 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:56 --> Total execution time: 0.0291
DEBUG - 2011-07-13 07:13:56 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:56 --> Total execution time: 0.5245
DEBUG - 2011-07-13 07:13:57 --> Config Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Hooks Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Utf8 Class Initialized
DEBUG - 2011-07-13 07:13:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 07:13:57 --> URI Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Router Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Output Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Input Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 07:13:57 --> Language Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Loader Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Controller Class Initialized
ERROR - 2011-07-13 07:13:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 07:13:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 07:13:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:57 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Model Class Initialized
DEBUG - 2011-07-13 07:13:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 07:13:57 --> Database Driver Class Initialized
DEBUG - 2011-07-13 07:13:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 07:13:57 --> Helper loaded: url_helper
DEBUG - 2011-07-13 07:13:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 07:13:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 07:13:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 07:13:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 07:13:57 --> Final output sent to browser
DEBUG - 2011-07-13 07:13:57 --> Total execution time: 0.0263
DEBUG - 2011-07-13 08:15:22 --> Config Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:15:22 --> URI Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Router Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Output Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Input Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:15:22 --> Language Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Loader Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Controller Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:15:22 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:15:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:15:22 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:15:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:15:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:15:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:15:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:15:22 --> Final output sent to browser
DEBUG - 2011-07-13 08:15:22 --> Total execution time: 0.5327
DEBUG - 2011-07-13 08:15:26 --> Config Class Initialized
DEBUG - 2011-07-13 08:15:26 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:15:26 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:15:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:15:26 --> URI Class Initialized
DEBUG - 2011-07-13 08:15:26 --> Router Class Initialized
ERROR - 2011-07-13 08:15:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:15:41 --> Config Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:15:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:15:41 --> URI Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Router Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Output Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Input Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:15:41 --> Language Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Loader Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Controller Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:15:41 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:15:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:15:41 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:15:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:15:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:15:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:15:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:15:41 --> Final output sent to browser
DEBUG - 2011-07-13 08:15:41 --> Total execution time: 0.3184
DEBUG - 2011-07-13 08:15:47 --> Config Class Initialized
DEBUG - 2011-07-13 08:15:47 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:15:47 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:15:48 --> URI Class Initialized
DEBUG - 2011-07-13 08:15:48 --> Router Class Initialized
ERROR - 2011-07-13 08:15:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:15:59 --> Config Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:15:59 --> URI Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Router Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Output Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Input Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:15:59 --> Language Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Loader Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Controller Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Model Class Initialized
DEBUG - 2011-07-13 08:15:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:15:59 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:15:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:15:59 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:15:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:15:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:15:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:15:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:15:59 --> Final output sent to browser
DEBUG - 2011-07-13 08:15:59 --> Total execution time: 0.2737
DEBUG - 2011-07-13 08:16:03 --> Config Class Initialized
DEBUG - 2011-07-13 08:16:03 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:16:03 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:16:03 --> URI Class Initialized
DEBUG - 2011-07-13 08:16:03 --> Router Class Initialized
ERROR - 2011-07-13 08:16:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:16:09 --> Config Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:16:09 --> URI Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Router Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Output Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Input Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:16:09 --> Language Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Loader Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Controller Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Model Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Model Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Model Class Initialized
DEBUG - 2011-07-13 08:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:16:09 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:16:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:16:09 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:16:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:16:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:16:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:16:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:16:09 --> Final output sent to browser
DEBUG - 2011-07-13 08:16:09 --> Total execution time: 0.2748
DEBUG - 2011-07-13 08:16:13 --> Config Class Initialized
DEBUG - 2011-07-13 08:16:13 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:16:13 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:16:13 --> URI Class Initialized
DEBUG - 2011-07-13 08:16:13 --> Router Class Initialized
ERROR - 2011-07-13 08:16:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:16:27 --> Config Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:16:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:16:27 --> URI Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Router Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Output Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Input Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:16:27 --> Language Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Loader Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Controller Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Model Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Model Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Model Class Initialized
DEBUG - 2011-07-13 08:16:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:16:27 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:16:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:16:28 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:16:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:16:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:16:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:16:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:16:28 --> Final output sent to browser
DEBUG - 2011-07-13 08:16:28 --> Total execution time: 0.9565
DEBUG - 2011-07-13 08:16:33 --> Config Class Initialized
DEBUG - 2011-07-13 08:16:33 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:16:33 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:16:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:16:33 --> URI Class Initialized
DEBUG - 2011-07-13 08:16:33 --> Router Class Initialized
ERROR - 2011-07-13 08:16:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:17:05 --> Config Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:17:05 --> URI Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Router Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Output Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Input Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:17:05 --> Language Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Loader Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Controller Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:17:05 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:17:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:17:05 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:17:05 --> Final output sent to browser
DEBUG - 2011-07-13 08:17:05 --> Total execution time: 0.3651
DEBUG - 2011-07-13 08:17:07 --> Config Class Initialized
DEBUG - 2011-07-13 08:17:07 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:17:07 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:17:07 --> URI Class Initialized
DEBUG - 2011-07-13 08:17:07 --> Router Class Initialized
ERROR - 2011-07-13 08:17:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:17:22 --> Config Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:17:22 --> URI Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Router Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Output Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Input Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:17:22 --> Language Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Loader Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Controller Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:17:22 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:17:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:17:23 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:17:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:17:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:17:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:17:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:17:23 --> Final output sent to browser
DEBUG - 2011-07-13 08:17:23 --> Total execution time: 0.3424
DEBUG - 2011-07-13 08:17:28 --> Config Class Initialized
DEBUG - 2011-07-13 08:17:28 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:17:28 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:17:28 --> URI Class Initialized
DEBUG - 2011-07-13 08:17:28 --> Router Class Initialized
ERROR - 2011-07-13 08:17:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:17:38 --> Config Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:17:38 --> URI Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Router Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Output Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Input Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:17:38 --> Language Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Loader Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Controller Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Model Class Initialized
DEBUG - 2011-07-13 08:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:17:38 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:17:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:17:39 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:17:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:17:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:17:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:17:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:17:39 --> Final output sent to browser
DEBUG - 2011-07-13 08:17:39 --> Total execution time: 0.2795
DEBUG - 2011-07-13 08:17:42 --> Config Class Initialized
DEBUG - 2011-07-13 08:17:42 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:17:42 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:17:42 --> URI Class Initialized
DEBUG - 2011-07-13 08:17:42 --> Router Class Initialized
ERROR - 2011-07-13 08:17:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:18:04 --> Config Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:18:04 --> URI Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Router Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Output Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Input Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:18:04 --> Language Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Loader Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Controller Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:18:04 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:18:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:18:04 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:18:04 --> Final output sent to browser
DEBUG - 2011-07-13 08:18:04 --> Total execution time: 0.3566
DEBUG - 2011-07-13 08:18:06 --> Config Class Initialized
DEBUG - 2011-07-13 08:18:06 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:18:06 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:18:06 --> URI Class Initialized
DEBUG - 2011-07-13 08:18:06 --> Router Class Initialized
ERROR - 2011-07-13 08:18:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:18:21 --> Config Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:18:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:18:21 --> URI Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Router Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Output Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Input Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:18:21 --> Language Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Loader Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Controller Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:18:21 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:18:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:18:22 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:18:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:18:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:18:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:18:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:18:22 --> Final output sent to browser
DEBUG - 2011-07-13 08:18:22 --> Total execution time: 0.9551
DEBUG - 2011-07-13 08:18:25 --> Config Class Initialized
DEBUG - 2011-07-13 08:18:25 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:18:25 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:18:25 --> URI Class Initialized
DEBUG - 2011-07-13 08:18:25 --> Router Class Initialized
ERROR - 2011-07-13 08:18:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:18:42 --> Config Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:18:42 --> URI Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Router Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Output Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Input Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:18:42 --> Language Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Loader Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Controller Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Model Class Initialized
DEBUG - 2011-07-13 08:18:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:18:42 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:18:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:18:42 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:18:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:18:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:18:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:18:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:18:42 --> Final output sent to browser
DEBUG - 2011-07-13 08:18:42 --> Total execution time: 0.3200
DEBUG - 2011-07-13 08:18:46 --> Config Class Initialized
DEBUG - 2011-07-13 08:18:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:18:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:18:46 --> URI Class Initialized
DEBUG - 2011-07-13 08:18:46 --> Router Class Initialized
ERROR - 2011-07-13 08:18:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:19:10 --> Config Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:19:10 --> URI Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Router Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Output Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Input Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:19:10 --> Language Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Loader Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Controller Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Model Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Model Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Model Class Initialized
DEBUG - 2011-07-13 08:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:19:10 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:19:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:19:11 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:19:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:19:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:19:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:19:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:19:11 --> Final output sent to browser
DEBUG - 2011-07-13 08:19:11 --> Total execution time: 0.5090
DEBUG - 2011-07-13 08:19:22 --> Config Class Initialized
DEBUG - 2011-07-13 08:19:22 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:19:22 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:19:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:19:22 --> URI Class Initialized
DEBUG - 2011-07-13 08:19:22 --> Router Class Initialized
ERROR - 2011-07-13 08:19:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:28:53 --> Config Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:28:53 --> URI Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Router Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Output Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Input Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:28:53 --> Language Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Loader Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Controller Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Model Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Model Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Model Class Initialized
DEBUG - 2011-07-13 08:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:28:53 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:28:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:28:53 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:28:53 --> Final output sent to browser
DEBUG - 2011-07-13 08:28:53 --> Total execution time: 0.0464
DEBUG - 2011-07-13 08:41:46 --> Config Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:41:46 --> URI Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Router Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Output Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Input Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:41:46 --> Language Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Loader Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Controller Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Model Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Model Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Model Class Initialized
DEBUG - 2011-07-13 08:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:41:47 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:41:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:41:47 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:41:47 --> Final output sent to browser
DEBUG - 2011-07-13 08:41:47 --> Total execution time: 0.5120
DEBUG - 2011-07-13 08:41:48 --> Config Class Initialized
DEBUG - 2011-07-13 08:41:48 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:41:48 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:41:48 --> URI Class Initialized
DEBUG - 2011-07-13 08:41:48 --> Router Class Initialized
ERROR - 2011-07-13 08:41:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:41:49 --> Config Class Initialized
DEBUG - 2011-07-13 08:41:49 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:41:49 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:41:49 --> URI Class Initialized
DEBUG - 2011-07-13 08:41:49 --> Router Class Initialized
ERROR - 2011-07-13 08:41:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:41:58 --> Config Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:41:58 --> URI Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Router Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Output Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Input Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:41:58 --> Language Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Loader Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Controller Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Model Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Model Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Model Class Initialized
DEBUG - 2011-07-13 08:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:41:58 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:41:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:41:59 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:41:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:41:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:41:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:41:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:41:59 --> Final output sent to browser
DEBUG - 2011-07-13 08:41:59 --> Total execution time: 0.6030
DEBUG - 2011-07-13 08:42:24 --> Config Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:42:24 --> URI Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Router Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Output Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Input Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:42:24 --> Language Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Loader Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Controller Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Model Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Model Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Model Class Initialized
DEBUG - 2011-07-13 08:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:42:24 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:42:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:42:25 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:42:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:42:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:42:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:42:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:42:25 --> Final output sent to browser
DEBUG - 2011-07-13 08:42:25 --> Total execution time: 0.1458
DEBUG - 2011-07-13 08:56:38 --> Config Class Initialized
DEBUG - 2011-07-13 08:56:38 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:56:38 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:56:38 --> URI Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Router Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Output Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Input Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:56:39 --> Language Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Loader Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Controller Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Model Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Model Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Model Class Initialized
DEBUG - 2011-07-13 08:56:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:56:39 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:56:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 08:56:39 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:56:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:56:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:56:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:56:39 --> Final output sent to browser
DEBUG - 2011-07-13 08:56:39 --> Total execution time: 0.8423
DEBUG - 2011-07-13 08:56:42 --> Config Class Initialized
DEBUG - 2011-07-13 08:56:42 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:56:42 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:56:42 --> URI Class Initialized
DEBUG - 2011-07-13 08:56:42 --> Router Class Initialized
ERROR - 2011-07-13 08:56:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 08:59:33 --> Config Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:59:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:59:33 --> URI Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Router Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Output Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Input Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:59:33 --> Language Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Loader Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Controller Class Initialized
ERROR - 2011-07-13 08:59:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 08:59:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 08:59:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 08:59:33 --> Model Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Model Class Initialized
DEBUG - 2011-07-13 08:59:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:59:33 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:59:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 08:59:33 --> Helper loaded: url_helper
DEBUG - 2011-07-13 08:59:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 08:59:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 08:59:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 08:59:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 08:59:33 --> Final output sent to browser
DEBUG - 2011-07-13 08:59:33 --> Total execution time: 0.1426
DEBUG - 2011-07-13 08:59:35 --> Config Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:59:35 --> URI Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Router Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Output Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Input Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 08:59:35 --> Language Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Loader Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Controller Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Model Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Model Class Initialized
DEBUG - 2011-07-13 08:59:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 08:59:35 --> Database Driver Class Initialized
DEBUG - 2011-07-13 08:59:36 --> Final output sent to browser
DEBUG - 2011-07-13 08:59:36 --> Total execution time: 1.2090
DEBUG - 2011-07-13 08:59:38 --> Config Class Initialized
DEBUG - 2011-07-13 08:59:38 --> Hooks Class Initialized
DEBUG - 2011-07-13 08:59:38 --> Utf8 Class Initialized
DEBUG - 2011-07-13 08:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 08:59:38 --> URI Class Initialized
DEBUG - 2011-07-13 08:59:38 --> Router Class Initialized
ERROR - 2011-07-13 08:59:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:07:13 --> Config Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:07:13 --> URI Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Router Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Output Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Input Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:07:13 --> Language Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Loader Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Controller Class Initialized
ERROR - 2011-07-13 09:07:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 09:07:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 09:07:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:07:13 --> Model Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Model Class Initialized
DEBUG - 2011-07-13 09:07:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:07:13 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:07:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:07:13 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:07:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:07:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:07:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:07:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:07:13 --> Final output sent to browser
DEBUG - 2011-07-13 09:07:13 --> Total execution time: 0.0495
DEBUG - 2011-07-13 09:07:19 --> Config Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:07:19 --> URI Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Router Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Output Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Input Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:07:19 --> Language Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Loader Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Controller Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Model Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Model Class Initialized
DEBUG - 2011-07-13 09:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:07:19 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:07:20 --> Final output sent to browser
DEBUG - 2011-07-13 09:07:20 --> Total execution time: 0.7670
DEBUG - 2011-07-13 09:10:17 --> Config Class Initialized
DEBUG - 2011-07-13 09:10:17 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:10:17 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:10:18 --> URI Class Initialized
DEBUG - 2011-07-13 09:10:18 --> Router Class Initialized
DEBUG - 2011-07-13 09:10:18 --> Output Class Initialized
DEBUG - 2011-07-13 09:10:18 --> Input Class Initialized
DEBUG - 2011-07-13 09:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:10:18 --> Language Class Initialized
DEBUG - 2011-07-13 09:10:18 --> Loader Class Initialized
DEBUG - 2011-07-13 09:10:18 --> Controller Class Initialized
ERROR - 2011-07-13 09:10:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 09:10:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 09:10:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:10:18 --> Model Class Initialized
DEBUG - 2011-07-13 09:10:18 --> Model Class Initialized
DEBUG - 2011-07-13 09:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:10:19 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:10:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:10:19 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:10:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:10:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:10:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:10:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:10:19 --> Final output sent to browser
DEBUG - 2011-07-13 09:10:19 --> Total execution time: 1.3541
DEBUG - 2011-07-13 09:10:21 --> Config Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:10:21 --> URI Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Router Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Output Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Input Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:10:21 --> Language Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Loader Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Controller Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Model Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Model Class Initialized
DEBUG - 2011-07-13 09:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:10:21 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:10:24 --> Final output sent to browser
DEBUG - 2011-07-13 09:10:24 --> Total execution time: 3.0210
DEBUG - 2011-07-13 09:11:57 --> Config Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:11:57 --> URI Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Router Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Output Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Input Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:11:57 --> Language Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Loader Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Controller Class Initialized
ERROR - 2011-07-13 09:11:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 09:11:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 09:11:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:11:57 --> Model Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Model Class Initialized
DEBUG - 2011-07-13 09:11:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:11:58 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:11:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:11:58 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:11:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:11:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:11:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:11:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:11:58 --> Final output sent to browser
DEBUG - 2011-07-13 09:11:58 --> Total execution time: 0.0422
DEBUG - 2011-07-13 09:11:58 --> Config Class Initialized
DEBUG - 2011-07-13 09:11:58 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:11:58 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:11:58 --> URI Class Initialized
DEBUG - 2011-07-13 09:11:58 --> Router Class Initialized
DEBUG - 2011-07-13 09:11:58 --> Output Class Initialized
DEBUG - 2011-07-13 09:11:59 --> Input Class Initialized
DEBUG - 2011-07-13 09:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:11:59 --> Language Class Initialized
DEBUG - 2011-07-13 09:11:59 --> Loader Class Initialized
DEBUG - 2011-07-13 09:11:59 --> Controller Class Initialized
DEBUG - 2011-07-13 09:11:59 --> Model Class Initialized
DEBUG - 2011-07-13 09:11:59 --> Model Class Initialized
DEBUG - 2011-07-13 09:11:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:11:59 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:11:59 --> Final output sent to browser
DEBUG - 2011-07-13 09:11:59 --> Total execution time: 0.8269
DEBUG - 2011-07-13 09:12:01 --> Config Class Initialized
DEBUG - 2011-07-13 09:12:01 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:12:01 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:12:01 --> URI Class Initialized
DEBUG - 2011-07-13 09:12:01 --> Router Class Initialized
ERROR - 2011-07-13 09:12:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:12:01 --> Config Class Initialized
DEBUG - 2011-07-13 09:12:01 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:12:01 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:12:01 --> URI Class Initialized
DEBUG - 2011-07-13 09:12:01 --> Router Class Initialized
ERROR - 2011-07-13 09:12:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:12:02 --> Config Class Initialized
DEBUG - 2011-07-13 09:12:02 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:12:02 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:12:02 --> URI Class Initialized
DEBUG - 2011-07-13 09:12:02 --> Router Class Initialized
ERROR - 2011-07-13 09:12:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:23:02 --> Config Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:23:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:23:02 --> URI Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Router Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Output Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Input Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:23:02 --> Language Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Loader Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Controller Class Initialized
ERROR - 2011-07-13 09:23:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 09:23:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 09:23:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:23:02 --> Model Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Model Class Initialized
DEBUG - 2011-07-13 09:23:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:23:02 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:23:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:23:02 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:23:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:23:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:23:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:23:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:23:02 --> Final output sent to browser
DEBUG - 2011-07-13 09:23:02 --> Total execution time: 0.0553
DEBUG - 2011-07-13 09:23:03 --> Config Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:23:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:23:03 --> URI Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Router Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Output Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Input Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:23:03 --> Language Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Loader Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Controller Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Model Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Model Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Model Class Initialized
DEBUG - 2011-07-13 09:23:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:23:03 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:23:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 09:23:04 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:23:04 --> Final output sent to browser
DEBUG - 2011-07-13 09:23:04 --> Total execution time: 0.2988
DEBUG - 2011-07-13 09:23:04 --> Config Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:23:04 --> URI Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Router Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Output Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Input Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:23:04 --> Language Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Loader Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Controller Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Model Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Model Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:23:04 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:23:04 --> Final output sent to browser
DEBUG - 2011-07-13 09:23:04 --> Total execution time: 0.6159
DEBUG - 2011-07-13 09:23:12 --> Config Class Initialized
DEBUG - 2011-07-13 09:23:12 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:23:12 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:23:12 --> URI Class Initialized
DEBUG - 2011-07-13 09:23:12 --> Router Class Initialized
ERROR - 2011-07-13 09:23:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:38:49 --> Config Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:38:49 --> URI Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Router Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Output Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Input Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:38:49 --> Language Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Loader Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Controller Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Model Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Model Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Model Class Initialized
DEBUG - 2011-07-13 09:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:38:49 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 09:38:50 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:38:50 --> Final output sent to browser
DEBUG - 2011-07-13 09:38:50 --> Total execution time: 0.6014
DEBUG - 2011-07-13 09:38:54 --> Config Class Initialized
DEBUG - 2011-07-13 09:38:54 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:38:54 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:38:54 --> URI Class Initialized
DEBUG - 2011-07-13 09:38:54 --> Router Class Initialized
ERROR - 2011-07-13 09:38:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:53:40 --> Config Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:53:40 --> URI Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Router Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Output Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Input Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:53:40 --> Language Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Loader Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Controller Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Model Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Model Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Model Class Initialized
DEBUG - 2011-07-13 09:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:53:40 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:53:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 09:53:41 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:53:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:53:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:53:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:53:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:53:41 --> Final output sent to browser
DEBUG - 2011-07-13 09:53:41 --> Total execution time: 0.9148
DEBUG - 2011-07-13 09:53:46 --> Config Class Initialized
DEBUG - 2011-07-13 09:53:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:53:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:53:46 --> URI Class Initialized
DEBUG - 2011-07-13 09:53:46 --> Router Class Initialized
ERROR - 2011-07-13 09:53:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:53:46 --> Config Class Initialized
DEBUG - 2011-07-13 09:53:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:53:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:53:46 --> URI Class Initialized
DEBUG - 2011-07-13 09:53:46 --> Router Class Initialized
ERROR - 2011-07-13 09:53:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:56:39 --> Config Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:56:39 --> URI Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Router Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Output Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Input Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:56:39 --> Language Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Loader Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Controller Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Model Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Model Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Model Class Initialized
DEBUG - 2011-07-13 09:56:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:56:39 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:56:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 09:56:39 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:56:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:56:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:56:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:56:39 --> Final output sent to browser
DEBUG - 2011-07-13 09:56:39 --> Total execution time: 0.1658
DEBUG - 2011-07-13 09:56:41 --> Config Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:56:41 --> URI Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Router Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Output Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Input Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:56:41 --> Language Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Loader Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Controller Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Model Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Model Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Model Class Initialized
DEBUG - 2011-07-13 09:56:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:56:41 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:56:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 09:56:41 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:56:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:56:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:56:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:56:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:56:41 --> Final output sent to browser
DEBUG - 2011-07-13 09:56:41 --> Total execution time: 0.2092
DEBUG - 2011-07-13 09:56:45 --> Config Class Initialized
DEBUG - 2011-07-13 09:56:45 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:56:45 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:56:45 --> URI Class Initialized
DEBUG - 2011-07-13 09:56:45 --> Router Class Initialized
ERROR - 2011-07-13 09:56:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 09:58:01 --> Config Class Initialized
DEBUG - 2011-07-13 09:58:01 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:58:01 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:58:01 --> URI Class Initialized
DEBUG - 2011-07-13 09:58:02 --> Router Class Initialized
DEBUG - 2011-07-13 09:58:02 --> Output Class Initialized
DEBUG - 2011-07-13 09:58:02 --> Input Class Initialized
DEBUG - 2011-07-13 09:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:58:02 --> Language Class Initialized
DEBUG - 2011-07-13 09:58:02 --> Loader Class Initialized
DEBUG - 2011-07-13 09:58:02 --> Controller Class Initialized
ERROR - 2011-07-13 09:58:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 09:58:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 09:58:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:58:02 --> Model Class Initialized
DEBUG - 2011-07-13 09:58:02 --> Model Class Initialized
DEBUG - 2011-07-13 09:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:58:02 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:58:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 09:58:02 --> Helper loaded: url_helper
DEBUG - 2011-07-13 09:58:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 09:58:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 09:58:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 09:58:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 09:58:02 --> Final output sent to browser
DEBUG - 2011-07-13 09:58:02 --> Total execution time: 0.4326
DEBUG - 2011-07-13 09:58:04 --> Config Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:58:04 --> URI Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Router Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Output Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Input Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 09:58:04 --> Language Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Loader Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Controller Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Model Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Model Class Initialized
DEBUG - 2011-07-13 09:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 09:58:04 --> Database Driver Class Initialized
DEBUG - 2011-07-13 09:58:05 --> Final output sent to browser
DEBUG - 2011-07-13 09:58:05 --> Total execution time: 1.1011
DEBUG - 2011-07-13 09:58:06 --> Config Class Initialized
DEBUG - 2011-07-13 09:58:06 --> Hooks Class Initialized
DEBUG - 2011-07-13 09:58:06 --> Utf8 Class Initialized
DEBUG - 2011-07-13 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 09:58:06 --> URI Class Initialized
DEBUG - 2011-07-13 09:58:06 --> Router Class Initialized
ERROR - 2011-07-13 09:58:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 10:04:57 --> Config Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Hooks Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Utf8 Class Initialized
DEBUG - 2011-07-13 10:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 10:04:57 --> URI Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Router Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Output Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Input Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 10:04:57 --> Language Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Loader Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Controller Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Model Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Model Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Model Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 10:04:57 --> Database Driver Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Config Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Hooks Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Utf8 Class Initialized
DEBUG - 2011-07-13 10:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 10:04:57 --> URI Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Router Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Output Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Input Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 10:04:57 --> Language Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Loader Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Controller Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Model Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Model Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Model Class Initialized
DEBUG - 2011-07-13 10:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 10:04:57 --> Database Driver Class Initialized
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 10:04:57 --> Helper loaded: url_helper
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 10:04:57 --> Final output sent to browser
DEBUG - 2011-07-13 10:04:57 --> Total execution time: 0.2891
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 10:04:57 --> Helper loaded: url_helper
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 10:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 10:04:57 --> Final output sent to browser
DEBUG - 2011-07-13 10:04:57 --> Total execution time: 0.0945
DEBUG - 2011-07-13 10:54:20 --> Config Class Initialized
DEBUG - 2011-07-13 10:54:20 --> Hooks Class Initialized
DEBUG - 2011-07-13 10:54:20 --> Utf8 Class Initialized
DEBUG - 2011-07-13 10:54:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 10:54:20 --> URI Class Initialized
DEBUG - 2011-07-13 10:54:20 --> Router Class Initialized
DEBUG - 2011-07-13 10:54:20 --> Output Class Initialized
DEBUG - 2011-07-13 10:54:22 --> Input Class Initialized
DEBUG - 2011-07-13 10:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 10:54:22 --> Language Class Initialized
DEBUG - 2011-07-13 10:54:22 --> Loader Class Initialized
DEBUG - 2011-07-13 10:54:22 --> Controller Class Initialized
DEBUG - 2011-07-13 10:54:23 --> Model Class Initialized
DEBUG - 2011-07-13 10:54:23 --> Model Class Initialized
DEBUG - 2011-07-13 10:54:23 --> Model Class Initialized
DEBUG - 2011-07-13 10:54:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 10:54:25 --> Database Driver Class Initialized
DEBUG - 2011-07-13 10:54:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 10:54:26 --> Helper loaded: url_helper
DEBUG - 2011-07-13 10:54:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 10:54:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 10:54:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 10:54:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 10:54:26 --> Final output sent to browser
DEBUG - 2011-07-13 10:54:26 --> Total execution time: 5.7670
DEBUG - 2011-07-13 11:50:02 --> Config Class Initialized
DEBUG - 2011-07-13 11:50:02 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:50:02 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:50:02 --> URI Class Initialized
DEBUG - 2011-07-13 11:50:02 --> Router Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Output Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Input Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:50:03 --> Language Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Loader Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Controller Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Model Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Model Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Model Class Initialized
DEBUG - 2011-07-13 11:50:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:50:03 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:50:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 11:50:04 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:50:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:50:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:50:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:50:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:50:04 --> Final output sent to browser
DEBUG - 2011-07-13 11:50:04 --> Total execution time: 2.1613
DEBUG - 2011-07-13 11:50:31 --> Config Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:50:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:50:31 --> URI Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Router Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Output Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Input Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:50:31 --> Language Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Loader Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Controller Class Initialized
ERROR - 2011-07-13 11:50:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:50:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:50:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:50:31 --> Model Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Model Class Initialized
DEBUG - 2011-07-13 11:50:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:50:31 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:50:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:50:31 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:50:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:50:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:50:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:50:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:50:31 --> Final output sent to browser
DEBUG - 2011-07-13 11:50:31 --> Total execution time: 0.1183
DEBUG - 2011-07-13 11:50:32 --> Config Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:50:32 --> URI Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Router Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Output Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Input Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:50:32 --> Language Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Loader Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Controller Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Model Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Model Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:50:32 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:50:32 --> Final output sent to browser
DEBUG - 2011-07-13 11:50:32 --> Total execution time: 0.6393
DEBUG - 2011-07-13 11:54:36 --> Config Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:54:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:54:36 --> URI Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Router Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Output Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Input Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:54:36 --> Language Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Loader Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Controller Class Initialized
ERROR - 2011-07-13 11:54:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:54:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:54:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:54:36 --> Model Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Model Class Initialized
DEBUG - 2011-07-13 11:54:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:54:36 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:54:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:54:36 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:54:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:54:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:54:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:54:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:54:36 --> Final output sent to browser
DEBUG - 2011-07-13 11:54:36 --> Total execution time: 0.1559
DEBUG - 2011-07-13 11:54:37 --> Config Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:54:37 --> URI Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Router Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Output Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Input Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:54:37 --> Language Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Loader Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Controller Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Model Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Model Class Initialized
DEBUG - 2011-07-13 11:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:54:37 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:54:38 --> Final output sent to browser
DEBUG - 2011-07-13 11:54:38 --> Total execution time: 0.6058
DEBUG - 2011-07-13 11:54:40 --> Config Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:54:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:54:40 --> URI Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Router Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Output Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Input Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:54:40 --> Language Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Loader Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Controller Class Initialized
ERROR - 2011-07-13 11:54:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:54:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:54:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:54:40 --> Model Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Model Class Initialized
DEBUG - 2011-07-13 11:54:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:54:40 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:54:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:54:40 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:54:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:54:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:54:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:54:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:54:40 --> Final output sent to browser
DEBUG - 2011-07-13 11:54:40 --> Total execution time: 0.0610
DEBUG - 2011-07-13 11:54:42 --> Config Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:54:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:54:42 --> URI Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Router Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Output Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Input Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:54:42 --> Language Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Loader Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Controller Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Model Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Model Class Initialized
DEBUG - 2011-07-13 11:54:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:54:42 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:54:43 --> Final output sent to browser
DEBUG - 2011-07-13 11:54:43 --> Total execution time: 0.7118
DEBUG - 2011-07-13 11:54:45 --> Config Class Initialized
DEBUG - 2011-07-13 11:54:45 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:54:45 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:54:45 --> URI Class Initialized
DEBUG - 2011-07-13 11:54:45 --> Router Class Initialized
ERROR - 2011-07-13 11:54:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 11:55:08 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:08 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:08 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:08 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:08 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:08 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:08 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:08 --> Total execution time: 0.0282
DEBUG - 2011-07-13 11:55:10 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:10 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:10 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Controller Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:10 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:11 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:11 --> Total execution time: 1.1991
DEBUG - 2011-07-13 11:55:12 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:12 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:12 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:12 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:12 --> Router Class Initialized
ERROR - 2011-07-13 11:55:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 11:55:14 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:14 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:14 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:14 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:15 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:15 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:15 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:15 --> Total execution time: 0.0277
DEBUG - 2011-07-13 11:55:19 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:19 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:19 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:19 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:19 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:19 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:19 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:19 --> Total execution time: 0.0419
DEBUG - 2011-07-13 11:55:20 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:20 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:20 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Controller Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:20 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:21 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:21 --> Total execution time: 0.7445
DEBUG - 2011-07-13 11:55:22 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:22 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:22 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:22 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:22 --> Router Class Initialized
ERROR - 2011-07-13 11:55:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 11:55:25 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:25 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:25 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:25 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:25 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:25 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:25 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:25 --> Total execution time: 0.0541
DEBUG - 2011-07-13 11:55:31 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:31 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:31 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:31 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:31 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:31 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:31 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:31 --> Total execution time: 0.0370
DEBUG - 2011-07-13 11:55:32 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:32 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:32 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Controller Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:32 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:33 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:33 --> Total execution time: 1.0214
DEBUG - 2011-07-13 11:55:35 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:35 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:35 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:35 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:35 --> Router Class Initialized
ERROR - 2011-07-13 11:55:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 11:55:41 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:41 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:41 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:41 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:41 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:41 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:41 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:41 --> Total execution time: 0.0432
DEBUG - 2011-07-13 11:55:42 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:42 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:42 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Controller Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:42 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:43 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:43 --> Total execution time: 0.7452
DEBUG - 2011-07-13 11:55:45 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:45 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:45 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:45 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:45 --> Router Class Initialized
ERROR - 2011-07-13 11:55:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 11:55:46 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:46 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:46 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:46 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:46 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:46 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:46 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:46 --> Total execution time: 0.0545
DEBUG - 2011-07-13 11:55:46 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:46 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:46 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:46 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:46 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:46 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:46 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:46 --> Total execution time: 0.0405
DEBUG - 2011-07-13 11:55:51 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:51 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:51 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:51 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:51 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:51 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:51 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:51 --> Total execution time: 0.0651
DEBUG - 2011-07-13 11:55:52 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:52 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:52 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Controller Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:52 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:52 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Router Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Output Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Input Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 11:55:52 --> Language Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Loader Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Controller Class Initialized
ERROR - 2011-07-13 11:55:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 11:55:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 11:55:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:52 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Model Class Initialized
DEBUG - 2011-07-13 11:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 11:55:52 --> Database Driver Class Initialized
DEBUG - 2011-07-13 11:55:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 11:55:53 --> Helper loaded: url_helper
DEBUG - 2011-07-13 11:55:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 11:55:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 11:55:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 11:55:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 11:55:53 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:53 --> Total execution time: 0.0325
DEBUG - 2011-07-13 11:55:53 --> Final output sent to browser
DEBUG - 2011-07-13 11:55:54 --> Total execution time: 1.2983
DEBUG - 2011-07-13 11:55:55 --> Config Class Initialized
DEBUG - 2011-07-13 11:55:55 --> Hooks Class Initialized
DEBUG - 2011-07-13 11:55:55 --> Utf8 Class Initialized
DEBUG - 2011-07-13 11:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 11:55:55 --> URI Class Initialized
DEBUG - 2011-07-13 11:55:55 --> Router Class Initialized
ERROR - 2011-07-13 11:55:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:07:09 --> Config Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:07:09 --> URI Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Router Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Output Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Input Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:07:09 --> Language Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Loader Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Controller Class Initialized
ERROR - 2011-07-13 12:07:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:07:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:07:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:07:09 --> Model Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Model Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:07:09 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:07:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:07:09 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:07:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:07:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:07:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:07:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:07:09 --> Final output sent to browser
DEBUG - 2011-07-13 12:07:09 --> Total execution time: 0.2086
DEBUG - 2011-07-13 12:07:09 --> Config Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:07:09 --> URI Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Router Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Output Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Input Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:07:09 --> Language Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Loader Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Controller Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Model Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Model Class Initialized
DEBUG - 2011-07-13 12:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:07:09 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:07:10 --> Final output sent to browser
DEBUG - 2011-07-13 12:07:10 --> Total execution time: 0.4967
DEBUG - 2011-07-13 12:07:10 --> Config Class Initialized
DEBUG - 2011-07-13 12:07:10 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:07:10 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:07:10 --> URI Class Initialized
DEBUG - 2011-07-13 12:07:10 --> Router Class Initialized
ERROR - 2011-07-13 12:07:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:07:10 --> Config Class Initialized
DEBUG - 2011-07-13 12:07:10 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:07:10 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:07:10 --> URI Class Initialized
DEBUG - 2011-07-13 12:07:10 --> Router Class Initialized
ERROR - 2011-07-13 12:07:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:07:51 --> Config Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:07:51 --> URI Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Router Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Output Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Input Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:07:51 --> Language Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Loader Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Controller Class Initialized
ERROR - 2011-07-13 12:07:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:07:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:07:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:07:51 --> Model Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Model Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:07:51 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:07:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:07:51 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:07:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:07:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:07:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:07:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:07:51 --> Final output sent to browser
DEBUG - 2011-07-13 12:07:51 --> Total execution time: 0.0297
DEBUG - 2011-07-13 12:07:51 --> Config Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:07:51 --> URI Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Router Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Output Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Input Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:07:51 --> Language Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Loader Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Controller Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Model Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Model Class Initialized
DEBUG - 2011-07-13 12:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:07:51 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:07:52 --> Final output sent to browser
DEBUG - 2011-07-13 12:07:52 --> Total execution time: 0.5102
DEBUG - 2011-07-13 12:08:23 --> Config Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:08:23 --> URI Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Router Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Output Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Input Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:08:23 --> Language Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Loader Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Controller Class Initialized
ERROR - 2011-07-13 12:08:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:08:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:08:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:08:23 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:08:23 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:08:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:08:23 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:08:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:08:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:08:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:08:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:08:23 --> Final output sent to browser
DEBUG - 2011-07-13 12:08:23 --> Total execution time: 0.0263
DEBUG - 2011-07-13 12:08:24 --> Config Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:08:24 --> URI Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Router Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Output Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Input Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:08:24 --> Language Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Loader Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Controller Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:08:24 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:08:24 --> Final output sent to browser
DEBUG - 2011-07-13 12:08:24 --> Total execution time: 0.6124
DEBUG - 2011-07-13 12:08:31 --> Config Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:08:31 --> URI Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Router Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Output Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Input Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:08:31 --> Language Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Loader Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Controller Class Initialized
ERROR - 2011-07-13 12:08:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:08:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:08:31 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:08:31 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:08:31 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:08:31 --> Final output sent to browser
DEBUG - 2011-07-13 12:08:31 --> Total execution time: 0.0407
DEBUG - 2011-07-13 12:08:31 --> Config Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:08:31 --> URI Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Router Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Output Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Input Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:08:31 --> Language Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Loader Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Controller Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:08:31 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:08:32 --> Final output sent to browser
DEBUG - 2011-07-13 12:08:32 --> Total execution time: 0.6269
DEBUG - 2011-07-13 12:08:41 --> Config Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:08:41 --> URI Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Router Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Output Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Input Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:08:41 --> Language Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Loader Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Controller Class Initialized
ERROR - 2011-07-13 12:08:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:08:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:08:41 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:08:41 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:08:41 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:08:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:08:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:08:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:08:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:08:41 --> Final output sent to browser
DEBUG - 2011-07-13 12:08:41 --> Total execution time: 0.0994
DEBUG - 2011-07-13 12:08:43 --> Config Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:08:43 --> URI Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Router Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Output Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Input Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:08:43 --> Language Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Loader Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Controller Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:08:43 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:08:44 --> Final output sent to browser
DEBUG - 2011-07-13 12:08:44 --> Total execution time: 0.5747
DEBUG - 2011-07-13 12:08:50 --> Config Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:08:50 --> URI Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Router Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Output Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Input Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:08:50 --> Language Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Loader Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Controller Class Initialized
ERROR - 2011-07-13 12:08:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:08:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:08:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:08:50 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:08:50 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:08:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:08:51 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:08:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:08:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:08:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:08:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:08:51 --> Final output sent to browser
DEBUG - 2011-07-13 12:08:51 --> Total execution time: 0.2814
DEBUG - 2011-07-13 12:08:51 --> Config Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:08:51 --> URI Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Router Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Output Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Input Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:08:51 --> Language Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Loader Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Controller Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Model Class Initialized
DEBUG - 2011-07-13 12:08:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:08:52 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:08:53 --> Final output sent to browser
DEBUG - 2011-07-13 12:08:53 --> Total execution time: 1.2125
DEBUG - 2011-07-13 12:10:47 --> Config Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:10:47 --> URI Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Router Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Output Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Input Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:10:47 --> Language Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Loader Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Controller Class Initialized
ERROR - 2011-07-13 12:10:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:10:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:10:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:10:47 --> Model Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Model Class Initialized
DEBUG - 2011-07-13 12:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:10:47 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:10:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:10:47 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:10:47 --> Final output sent to browser
DEBUG - 2011-07-13 12:10:47 --> Total execution time: 0.0294
DEBUG - 2011-07-13 12:11:02 --> Config Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:11:02 --> URI Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Router Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Output Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Input Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:11:02 --> Language Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Loader Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Controller Class Initialized
ERROR - 2011-07-13 12:11:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:11:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:11:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:11:02 --> Model Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Model Class Initialized
DEBUG - 2011-07-13 12:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:11:02 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:11:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:11:02 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:11:02 --> Final output sent to browser
DEBUG - 2011-07-13 12:11:02 --> Total execution time: 0.0631
DEBUG - 2011-07-13 12:11:49 --> Config Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:11:49 --> URI Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Router Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Output Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Input Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:11:49 --> Language Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Loader Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Controller Class Initialized
ERROR - 2011-07-13 12:11:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:11:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:11:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:11:49 --> Model Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Model Class Initialized
DEBUG - 2011-07-13 12:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:11:49 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:11:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:11:49 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:11:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:11:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:11:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:11:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:11:49 --> Final output sent to browser
DEBUG - 2011-07-13 12:11:49 --> Total execution time: 0.2632
DEBUG - 2011-07-13 12:11:50 --> Config Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:11:50 --> URI Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Router Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Output Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Input Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:11:50 --> Language Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Loader Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Controller Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Model Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Model Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:11:50 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:11:50 --> Final output sent to browser
DEBUG - 2011-07-13 12:11:50 --> Total execution time: 0.7003
DEBUG - 2011-07-13 12:11:51 --> Config Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:11:51 --> URI Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Router Class Initialized
ERROR - 2011-07-13 12:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:11:51 --> Config Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:11:51 --> URI Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Router Class Initialized
ERROR - 2011-07-13 12:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:11:51 --> Config Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:11:51 --> URI Class Initialized
DEBUG - 2011-07-13 12:11:51 --> Router Class Initialized
ERROR - 2011-07-13 12:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:12:06 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:06 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Router Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Output Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Input Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:12:06 --> Language Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Loader Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Controller Class Initialized
ERROR - 2011-07-13 12:12:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:12:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:12:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:12:06 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:12:07 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:12:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:12:07 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:12:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:12:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:12:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:12:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:12:07 --> Final output sent to browser
DEBUG - 2011-07-13 12:12:07 --> Total execution time: 0.1410
DEBUG - 2011-07-13 12:12:08 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:08 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Router Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Output Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Input Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:12:08 --> Language Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Loader Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Controller Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:12:08 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:12:09 --> Final output sent to browser
DEBUG - 2011-07-13 12:12:09 --> Total execution time: 1.1335
DEBUG - 2011-07-13 12:12:10 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:10 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:10 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:10 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:10 --> Router Class Initialized
ERROR - 2011-07-13 12:12:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:12:11 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:11 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:11 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:11 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:11 --> Router Class Initialized
ERROR - 2011-07-13 12:12:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:12:11 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:11 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:11 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:11 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:11 --> Router Class Initialized
ERROR - 2011-07-13 12:12:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:12:26 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:26 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Router Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Output Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Input Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:12:26 --> Language Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Loader Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Controller Class Initialized
ERROR - 2011-07-13 12:12:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:12:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:12:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:12:26 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:12:26 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:12:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:12:26 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:12:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:12:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:12:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:12:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:12:26 --> Final output sent to browser
DEBUG - 2011-07-13 12:12:26 --> Total execution time: 0.0282
DEBUG - 2011-07-13 12:12:27 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:27 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Router Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Output Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Input Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:12:27 --> Language Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Loader Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Controller Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:12:27 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:12:27 --> Final output sent to browser
DEBUG - 2011-07-13 12:12:27 --> Total execution time: 0.5245
DEBUG - 2011-07-13 12:12:44 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:44 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Router Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Output Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Input Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:12:44 --> Language Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Loader Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Controller Class Initialized
ERROR - 2011-07-13 12:12:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 12:12:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 12:12:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:12:44 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:12:44 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:12:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 12:12:44 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:12:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:12:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:12:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:12:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:12:44 --> Final output sent to browser
DEBUG - 2011-07-13 12:12:44 --> Total execution time: 0.0383
DEBUG - 2011-07-13 12:12:45 --> Config Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:12:45 --> URI Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Router Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Output Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Input Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:12:45 --> Language Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Loader Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Controller Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Model Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:12:45 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:12:45 --> Final output sent to browser
DEBUG - 2011-07-13 12:12:45 --> Total execution time: 0.6285
DEBUG - 2011-07-13 12:46:43 --> Config Class Initialized
DEBUG - 2011-07-13 12:46:43 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:46:43 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:46:43 --> URI Class Initialized
DEBUG - 2011-07-13 12:46:43 --> Router Class Initialized
DEBUG - 2011-07-13 12:46:44 --> No URI present. Default controller set.
DEBUG - 2011-07-13 12:46:44 --> Output Class Initialized
DEBUG - 2011-07-13 12:46:44 --> Input Class Initialized
DEBUG - 2011-07-13 12:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:46:44 --> Language Class Initialized
DEBUG - 2011-07-13 12:46:44 --> Loader Class Initialized
DEBUG - 2011-07-13 12:46:44 --> Controller Class Initialized
DEBUG - 2011-07-13 12:46:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-13 12:46:44 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:46:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:46:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:46:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:46:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:46:44 --> Final output sent to browser
DEBUG - 2011-07-13 12:46:44 --> Total execution time: 0.3618
DEBUG - 2011-07-13 12:46:46 --> Config Class Initialized
DEBUG - 2011-07-13 12:46:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:46:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:46:46 --> URI Class Initialized
DEBUG - 2011-07-13 12:46:46 --> Router Class Initialized
ERROR - 2011-07-13 12:46:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:46:49 --> Config Class Initialized
DEBUG - 2011-07-13 12:46:49 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:46:49 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:46:49 --> URI Class Initialized
DEBUG - 2011-07-13 12:46:49 --> Router Class Initialized
DEBUG - 2011-07-13 12:46:49 --> Output Class Initialized
DEBUG - 2011-07-13 12:46:49 --> Input Class Initialized
DEBUG - 2011-07-13 12:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:46:49 --> Language Class Initialized
DEBUG - 2011-07-13 12:46:49 --> Loader Class Initialized
DEBUG - 2011-07-13 12:46:49 --> Controller Class Initialized
DEBUG - 2011-07-13 12:46:50 --> Model Class Initialized
DEBUG - 2011-07-13 12:46:50 --> Model Class Initialized
DEBUG - 2011-07-13 12:46:50 --> Model Class Initialized
DEBUG - 2011-07-13 12:46:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:46:50 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:46:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 12:46:50 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:46:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:46:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:46:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:46:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:46:50 --> Final output sent to browser
DEBUG - 2011-07-13 12:46:50 --> Total execution time: 0.9456
DEBUG - 2011-07-13 12:46:51 --> Config Class Initialized
DEBUG - 2011-07-13 12:46:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:46:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:46:51 --> URI Class Initialized
DEBUG - 2011-07-13 12:46:51 --> Router Class Initialized
ERROR - 2011-07-13 12:46:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:46:53 --> Config Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:46:53 --> URI Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Router Class Initialized
ERROR - 2011-07-13 12:46:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-13 12:46:53 --> Config Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:46:53 --> URI Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Router Class Initialized
DEBUG - 2011-07-13 12:46:53 --> No URI present. Default controller set.
DEBUG - 2011-07-13 12:46:53 --> Output Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Input Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:46:53 --> Language Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Loader Class Initialized
DEBUG - 2011-07-13 12:46:53 --> Controller Class Initialized
DEBUG - 2011-07-13 12:46:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-13 12:46:53 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:46:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:46:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:46:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:46:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:46:53 --> Final output sent to browser
DEBUG - 2011-07-13 12:46:53 --> Total execution time: 0.0637
DEBUG - 2011-07-13 12:47:15 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:15 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Router Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Output Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Input Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:47:15 --> Language Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Loader Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Controller Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:47:15 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:47:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 12:47:16 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:47:16 --> Final output sent to browser
DEBUG - 2011-07-13 12:47:16 --> Total execution time: 0.7401
DEBUG - 2011-07-13 12:47:17 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:17 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:17 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:17 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:17 --> Router Class Initialized
ERROR - 2011-07-13 12:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:47:28 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:28 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Router Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Output Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Input Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:47:28 --> Language Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Loader Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Controller Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:47:28 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:47:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 12:47:29 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:47:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:47:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:47:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:47:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:47:29 --> Final output sent to browser
DEBUG - 2011-07-13 12:47:29 --> Total execution time: 0.3378
DEBUG - 2011-07-13 12:47:30 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:30 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:30 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:30 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:30 --> Router Class Initialized
ERROR - 2011-07-13 12:47:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:47:33 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:33 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Router Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Output Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Input Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:47:33 --> Language Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Loader Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Controller Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:47:33 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:47:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 12:47:33 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:47:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:47:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:47:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:47:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:47:33 --> Final output sent to browser
DEBUG - 2011-07-13 12:47:33 --> Total execution time: 0.0481
DEBUG - 2011-07-13 12:47:38 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:38 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Router Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Output Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Input Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:47:38 --> Language Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Loader Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Controller Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:47:38 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:47:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 12:47:38 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:47:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:47:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:47:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:47:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:47:38 --> Final output sent to browser
DEBUG - 2011-07-13 12:47:38 --> Total execution time: 0.3003
DEBUG - 2011-07-13 12:47:42 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:42 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Router Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Output Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Input Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:47:42 --> Language Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Loader Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Controller Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:47:42 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:47:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 12:47:45 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:47:45 --> Final output sent to browser
DEBUG - 2011-07-13 12:47:45 --> Total execution time: 3.6807
DEBUG - 2011-07-13 12:47:46 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:46 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:46 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:46 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:46 --> Router Class Initialized
ERROR - 2011-07-13 12:47:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 12:47:49 --> Config Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:47:49 --> URI Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Router Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Output Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Input Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:47:49 --> Language Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Loader Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Controller Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Model Class Initialized
DEBUG - 2011-07-13 12:47:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:47:49 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:47:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 12:47:49 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:47:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:47:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:47:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:47:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:47:49 --> Final output sent to browser
DEBUG - 2011-07-13 12:47:49 --> Total execution time: 0.1026
DEBUG - 2011-07-13 12:56:06 --> Config Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Hooks Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Utf8 Class Initialized
DEBUG - 2011-07-13 12:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 12:56:06 --> URI Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Router Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Output Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Input Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 12:56:06 --> Language Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Loader Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Controller Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Model Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Model Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Model Class Initialized
DEBUG - 2011-07-13 12:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 12:56:06 --> Database Driver Class Initialized
DEBUG - 2011-07-13 12:56:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 12:56:06 --> Helper loaded: url_helper
DEBUG - 2011-07-13 12:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 12:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 12:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 12:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 12:56:06 --> Final output sent to browser
DEBUG - 2011-07-13 12:56:06 --> Total execution time: 0.1958
DEBUG - 2011-07-13 13:08:52 --> Config Class Initialized
DEBUG - 2011-07-13 13:08:52 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:08:52 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:08:52 --> URI Class Initialized
DEBUG - 2011-07-13 13:08:52 --> Router Class Initialized
ERROR - 2011-07-13 13:08:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-13 13:36:27 --> Config Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:36:27 --> URI Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Router Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Output Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Input Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:36:27 --> Language Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Loader Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Controller Class Initialized
ERROR - 2011-07-13 13:36:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 13:36:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 13:36:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:36:27 --> Model Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Model Class Initialized
DEBUG - 2011-07-13 13:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:36:27 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:36:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:36:28 --> Helper loaded: url_helper
DEBUG - 2011-07-13 13:36:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 13:36:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 13:36:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 13:36:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 13:36:28 --> Final output sent to browser
DEBUG - 2011-07-13 13:36:28 --> Total execution time: 0.3959
DEBUG - 2011-07-13 13:36:28 --> Config Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:36:28 --> URI Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Router Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Output Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Input Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:36:28 --> Language Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Loader Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Controller Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Model Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Model Class Initialized
DEBUG - 2011-07-13 13:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:36:28 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:36:29 --> Final output sent to browser
DEBUG - 2011-07-13 13:36:29 --> Total execution time: 0.7418
DEBUG - 2011-07-13 13:36:31 --> Config Class Initialized
DEBUG - 2011-07-13 13:36:31 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:36:31 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:36:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:36:31 --> URI Class Initialized
DEBUG - 2011-07-13 13:36:31 --> Router Class Initialized
ERROR - 2011-07-13 13:36:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 13:36:32 --> Config Class Initialized
DEBUG - 2011-07-13 13:36:32 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:36:32 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:36:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:36:32 --> URI Class Initialized
DEBUG - 2011-07-13 13:36:32 --> Router Class Initialized
ERROR - 2011-07-13 13:36:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 13:41:32 --> Config Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:41:32 --> URI Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Router Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Output Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Input Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:41:32 --> Language Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Loader Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Controller Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Model Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Model Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Model Class Initialized
DEBUG - 2011-07-13 13:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:41:32 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:41:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 13:41:33 --> Helper loaded: url_helper
DEBUG - 2011-07-13 13:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 13:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 13:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 13:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 13:41:33 --> Final output sent to browser
DEBUG - 2011-07-13 13:41:33 --> Total execution time: 0.4870
DEBUG - 2011-07-13 13:41:54 --> Config Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:41:54 --> URI Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Router Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Output Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Input Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:41:54 --> Language Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Loader Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Controller Class Initialized
ERROR - 2011-07-13 13:41:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 13:41:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 13:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:41:54 --> Model Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Model Class Initialized
DEBUG - 2011-07-13 13:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:41:54 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:41:54 --> Helper loaded: url_helper
DEBUG - 2011-07-13 13:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 13:41:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 13:41:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 13:41:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 13:41:54 --> Final output sent to browser
DEBUG - 2011-07-13 13:41:54 --> Total execution time: 0.0571
DEBUG - 2011-07-13 13:41:55 --> Config Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:41:55 --> URI Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Router Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Output Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Input Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:41:55 --> Language Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Loader Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Controller Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Model Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Model Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:41:55 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:41:55 --> Final output sent to browser
DEBUG - 2011-07-13 13:41:55 --> Total execution time: 0.5182
DEBUG - 2011-07-13 13:49:20 --> Config Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:49:20 --> URI Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Router Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Output Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Input Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:49:20 --> Language Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Loader Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Controller Class Initialized
ERROR - 2011-07-13 13:49:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 13:49:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 13:49:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:49:20 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:49:21 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:49:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:49:21 --> Helper loaded: url_helper
DEBUG - 2011-07-13 13:49:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 13:49:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 13:49:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 13:49:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 13:49:21 --> Final output sent to browser
DEBUG - 2011-07-13 13:49:21 --> Total execution time: 1.6759
DEBUG - 2011-07-13 13:49:22 --> Config Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:49:22 --> URI Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Router Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Output Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Input Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:49:22 --> Language Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Loader Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Controller Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:49:22 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:49:23 --> Final output sent to browser
DEBUG - 2011-07-13 13:49:23 --> Total execution time: 1.2188
DEBUG - 2011-07-13 13:49:29 --> Config Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:49:29 --> URI Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Router Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Output Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Input Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:49:29 --> Language Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Loader Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Controller Class Initialized
ERROR - 2011-07-13 13:49:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 13:49:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 13:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:49:29 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:49:29 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:49:29 --> Helper loaded: url_helper
DEBUG - 2011-07-13 13:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 13:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 13:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 13:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 13:49:29 --> Final output sent to browser
DEBUG - 2011-07-13 13:49:29 --> Total execution time: 0.1682
DEBUG - 2011-07-13 13:49:29 --> Config Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:49:29 --> URI Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Router Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Output Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Input Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:49:29 --> Language Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Loader Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Controller Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:49:29 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:49:30 --> Final output sent to browser
DEBUG - 2011-07-13 13:49:30 --> Total execution time: 0.6156
DEBUG - 2011-07-13 13:49:37 --> Config Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Hooks Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Utf8 Class Initialized
DEBUG - 2011-07-13 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 13:49:37 --> URI Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Router Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Output Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Input Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 13:49:37 --> Language Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Loader Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Controller Class Initialized
ERROR - 2011-07-13 13:49:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 13:49:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 13:49:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:49:37 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Model Class Initialized
DEBUG - 2011-07-13 13:49:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 13:49:37 --> Database Driver Class Initialized
DEBUG - 2011-07-13 13:49:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 13:49:38 --> Helper loaded: url_helper
DEBUG - 2011-07-13 13:49:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 13:49:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 13:49:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 13:49:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 13:49:38 --> Final output sent to browser
DEBUG - 2011-07-13 13:49:38 --> Total execution time: 0.0855
DEBUG - 2011-07-13 14:09:00 --> Config Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Hooks Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Utf8 Class Initialized
DEBUG - 2011-07-13 14:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 14:09:00 --> URI Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Router Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Output Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Input Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 14:09:00 --> Language Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Loader Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Controller Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Model Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Model Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Model Class Initialized
DEBUG - 2011-07-13 14:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 14:09:00 --> Database Driver Class Initialized
DEBUG - 2011-07-13 14:09:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 14:09:01 --> Helper loaded: url_helper
DEBUG - 2011-07-13 14:09:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 14:09:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 14:09:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 14:09:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 14:09:01 --> Final output sent to browser
DEBUG - 2011-07-13 14:09:01 --> Total execution time: 1.7028
DEBUG - 2011-07-13 14:09:03 --> Config Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Hooks Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Utf8 Class Initialized
DEBUG - 2011-07-13 14:09:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 14:09:03 --> URI Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Router Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Output Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Input Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 14:09:03 --> Language Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Loader Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Controller Class Initialized
ERROR - 2011-07-13 14:09:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 14:09:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 14:09:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 14:09:03 --> Model Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Model Class Initialized
DEBUG - 2011-07-13 14:09:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 14:09:03 --> Database Driver Class Initialized
DEBUG - 2011-07-13 14:09:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 14:09:03 --> Helper loaded: url_helper
DEBUG - 2011-07-13 14:09:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 14:09:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 14:09:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 14:09:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 14:09:03 --> Final output sent to browser
DEBUG - 2011-07-13 14:09:03 --> Total execution time: 0.2479
DEBUG - 2011-07-13 15:55:08 --> Config Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Hooks Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Utf8 Class Initialized
DEBUG - 2011-07-13 15:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 15:55:08 --> URI Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Router Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Output Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Input Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 15:55:08 --> Language Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Loader Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Controller Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Model Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Model Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Model Class Initialized
DEBUG - 2011-07-13 15:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 15:55:08 --> Database Driver Class Initialized
DEBUG - 2011-07-13 15:55:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 15:55:08 --> Helper loaded: url_helper
DEBUG - 2011-07-13 15:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 15:55:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 15:55:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 15:55:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 15:55:09 --> Final output sent to browser
DEBUG - 2011-07-13 15:55:09 --> Total execution time: 0.5690
DEBUG - 2011-07-13 15:55:12 --> Config Class Initialized
DEBUG - 2011-07-13 15:55:12 --> Hooks Class Initialized
DEBUG - 2011-07-13 15:55:12 --> Utf8 Class Initialized
DEBUG - 2011-07-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 15:55:12 --> URI Class Initialized
DEBUG - 2011-07-13 15:55:12 --> Router Class Initialized
DEBUG - 2011-07-13 15:55:12 --> Output Class Initialized
DEBUG - 2011-07-13 15:55:12 --> Input Class Initialized
DEBUG - 2011-07-13 15:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 15:55:12 --> Language Class Initialized
DEBUG - 2011-07-13 15:55:12 --> Loader Class Initialized
DEBUG - 2011-07-13 15:55:12 --> Controller Class Initialized
ERROR - 2011-07-13 15:55:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 15:55:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 15:55:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 15:55:13 --> Model Class Initialized
DEBUG - 2011-07-13 15:55:13 --> Model Class Initialized
DEBUG - 2011-07-13 15:55:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 15:55:13 --> Database Driver Class Initialized
DEBUG - 2011-07-13 15:55:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 15:55:13 --> Helper loaded: url_helper
DEBUG - 2011-07-13 15:55:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 15:55:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 15:55:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 15:55:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 15:55:13 --> Final output sent to browser
DEBUG - 2011-07-13 15:55:13 --> Total execution time: 0.1085
DEBUG - 2011-07-13 16:59:38 --> Config Class Initialized
DEBUG - 2011-07-13 16:59:38 --> Hooks Class Initialized
DEBUG - 2011-07-13 16:59:38 --> Utf8 Class Initialized
DEBUG - 2011-07-13 16:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 16:59:38 --> URI Class Initialized
DEBUG - 2011-07-13 16:59:38 --> Router Class Initialized
DEBUG - 2011-07-13 16:59:38 --> Output Class Initialized
DEBUG - 2011-07-13 16:59:39 --> Input Class Initialized
DEBUG - 2011-07-13 16:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 16:59:39 --> Language Class Initialized
DEBUG - 2011-07-13 16:59:39 --> Loader Class Initialized
DEBUG - 2011-07-13 16:59:39 --> Controller Class Initialized
ERROR - 2011-07-13 16:59:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 16:59:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 16:59:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 16:59:39 --> Model Class Initialized
DEBUG - 2011-07-13 16:59:39 --> Model Class Initialized
DEBUG - 2011-07-13 16:59:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 16:59:39 --> Database Driver Class Initialized
DEBUG - 2011-07-13 16:59:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 16:59:39 --> Helper loaded: url_helper
DEBUG - 2011-07-13 16:59:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 16:59:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 16:59:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 16:59:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 16:59:39 --> Final output sent to browser
DEBUG - 2011-07-13 16:59:39 --> Total execution time: 0.4026
DEBUG - 2011-07-13 16:59:41 --> Config Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Hooks Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Utf8 Class Initialized
DEBUG - 2011-07-13 16:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 16:59:41 --> URI Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Router Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Output Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Input Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 16:59:41 --> Language Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Loader Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Controller Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Model Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Model Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 16:59:41 --> Database Driver Class Initialized
DEBUG - 2011-07-13 16:59:41 --> Final output sent to browser
DEBUG - 2011-07-13 16:59:41 --> Total execution time: 0.6167
DEBUG - 2011-07-13 16:59:43 --> Config Class Initialized
DEBUG - 2011-07-13 16:59:43 --> Hooks Class Initialized
DEBUG - 2011-07-13 16:59:43 --> Utf8 Class Initialized
DEBUG - 2011-07-13 16:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 16:59:43 --> URI Class Initialized
DEBUG - 2011-07-13 16:59:43 --> Router Class Initialized
ERROR - 2011-07-13 16:59:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 17:00:36 --> Config Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:00:36 --> URI Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Router Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Output Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Input Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:00:36 --> Language Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Loader Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Controller Class Initialized
ERROR - 2011-07-13 17:00:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:00:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:00:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:00:36 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:00:36 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:00:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:00:36 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:00:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:00:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:00:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:00:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:00:36 --> Final output sent to browser
DEBUG - 2011-07-13 17:00:36 --> Total execution time: 0.1705
DEBUG - 2011-07-13 17:00:37 --> Config Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:00:37 --> URI Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Router Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Output Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Input Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:00:37 --> Language Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Loader Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Controller Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:00:37 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Config Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:00:37 --> URI Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Router Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Output Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Input Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:00:37 --> Language Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Loader Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Controller Class Initialized
ERROR - 2011-07-13 17:00:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:00:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:00:37 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:00:37 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:00:37 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:00:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:00:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:00:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:00:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:00:37 --> Final output sent to browser
DEBUG - 2011-07-13 17:00:37 --> Total execution time: 0.0335
DEBUG - 2011-07-13 17:00:38 --> Final output sent to browser
DEBUG - 2011-07-13 17:00:38 --> Total execution time: 0.5996
DEBUG - 2011-07-13 17:00:39 --> Config Class Initialized
DEBUG - 2011-07-13 17:00:39 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:00:39 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:00:39 --> URI Class Initialized
DEBUG - 2011-07-13 17:00:39 --> Router Class Initialized
ERROR - 2011-07-13 17:00:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 17:00:51 --> Config Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:00:51 --> URI Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Router Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Output Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Input Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:00:51 --> Language Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Loader Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Controller Class Initialized
ERROR - 2011-07-13 17:00:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:00:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:00:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:00:51 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:00:51 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:00:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:00:51 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:00:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:00:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:00:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:00:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:00:51 --> Final output sent to browser
DEBUG - 2011-07-13 17:00:51 --> Total execution time: 0.0301
DEBUG - 2011-07-13 17:00:52 --> Config Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:00:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:00:52 --> URI Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Router Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Output Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Input Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:00:52 --> Language Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Loader Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Controller Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Model Class Initialized
DEBUG - 2011-07-13 17:00:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:00:52 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:00:53 --> Final output sent to browser
DEBUG - 2011-07-13 17:00:53 --> Total execution time: 0.5471
DEBUG - 2011-07-13 17:00:54 --> Config Class Initialized
DEBUG - 2011-07-13 17:00:54 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:00:54 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:00:54 --> URI Class Initialized
DEBUG - 2011-07-13 17:00:54 --> Router Class Initialized
ERROR - 2011-07-13 17:00:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 17:01:34 --> Config Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:01:34 --> URI Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Router Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Output Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Input Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:01:34 --> Language Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Loader Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Controller Class Initialized
ERROR - 2011-07-13 17:01:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:01:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:01:34 --> Model Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Model Class Initialized
DEBUG - 2011-07-13 17:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:01:34 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:01:34 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:01:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:01:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:01:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:01:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:01:34 --> Final output sent to browser
DEBUG - 2011-07-13 17:01:34 --> Total execution time: 0.0470
DEBUG - 2011-07-13 17:01:35 --> Config Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:01:35 --> URI Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Router Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Output Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Input Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:01:35 --> Language Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Loader Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Controller Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Model Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Model Class Initialized
DEBUG - 2011-07-13 17:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:01:35 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:01:36 --> Final output sent to browser
DEBUG - 2011-07-13 17:01:36 --> Total execution time: 0.5580
DEBUG - 2011-07-13 17:01:37 --> Config Class Initialized
DEBUG - 2011-07-13 17:01:37 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:01:37 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:01:37 --> URI Class Initialized
DEBUG - 2011-07-13 17:01:37 --> Router Class Initialized
ERROR - 2011-07-13 17:01:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 17:01:40 --> Config Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:01:40 --> URI Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Router Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Output Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Input Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:01:40 --> Language Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Loader Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Controller Class Initialized
ERROR - 2011-07-13 17:01:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:01:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:01:40 --> Model Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Model Class Initialized
DEBUG - 2011-07-13 17:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:01:40 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:01:40 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:01:40 --> Final output sent to browser
DEBUG - 2011-07-13 17:01:40 --> Total execution time: 0.0975
DEBUG - 2011-07-13 17:09:09 --> Config Class Initialized
DEBUG - 2011-07-13 17:09:09 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:09:09 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:09:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:09:09 --> URI Class Initialized
DEBUG - 2011-07-13 17:09:09 --> Router Class Initialized
DEBUG - 2011-07-13 17:09:09 --> No URI present. Default controller set.
DEBUG - 2011-07-13 17:09:09 --> Output Class Initialized
DEBUG - 2011-07-13 17:09:09 --> Input Class Initialized
DEBUG - 2011-07-13 17:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:09:09 --> Language Class Initialized
DEBUG - 2011-07-13 17:09:09 --> Loader Class Initialized
DEBUG - 2011-07-13 17:09:09 --> Controller Class Initialized
DEBUG - 2011-07-13 17:09:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-13 17:09:09 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:09:09 --> Final output sent to browser
DEBUG - 2011-07-13 17:09:09 --> Total execution time: 0.6699
DEBUG - 2011-07-13 17:12:09 --> Config Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:12:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:12:09 --> URI Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Router Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Output Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Input Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:12:09 --> Language Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Loader Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Controller Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Model Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Model Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Model Class Initialized
DEBUG - 2011-07-13 17:12:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:12:10 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:12:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 17:12:10 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:12:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:12:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:12:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:12:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:12:10 --> Final output sent to browser
DEBUG - 2011-07-13 17:12:10 --> Total execution time: 0.7181
DEBUG - 2011-07-13 17:12:11 --> Config Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:12:11 --> URI Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Router Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Output Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Input Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:12:11 --> Language Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Loader Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Controller Class Initialized
ERROR - 2011-07-13 17:12:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:12:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:12:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:12:11 --> Model Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Model Class Initialized
DEBUG - 2011-07-13 17:12:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:12:11 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:12:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:12:11 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:12:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:12:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:12:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:12:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:12:11 --> Final output sent to browser
DEBUG - 2011-07-13 17:12:11 --> Total execution time: 0.0505
DEBUG - 2011-07-13 17:31:47 --> Config Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:31:47 --> URI Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Router Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Output Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Input Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:31:47 --> Language Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Loader Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Controller Class Initialized
ERROR - 2011-07-13 17:31:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:31:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:31:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:31:47 --> Model Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Model Class Initialized
DEBUG - 2011-07-13 17:31:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:31:47 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:31:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:31:47 --> Helper loaded: url_helper
DEBUG - 2011-07-13 17:31:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 17:31:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 17:31:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 17:31:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 17:31:47 --> Final output sent to browser
DEBUG - 2011-07-13 17:31:47 --> Total execution time: 0.5339
DEBUG - 2011-07-13 17:31:48 --> Config Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:31:48 --> URI Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Router Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Output Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Input Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:31:48 --> Language Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Loader Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Controller Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Model Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Model Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 17:31:48 --> Database Driver Class Initialized
DEBUG - 2011-07-13 17:31:48 --> Final output sent to browser
DEBUG - 2011-07-13 17:31:48 --> Total execution time: 0.5254
DEBUG - 2011-07-13 17:31:49 --> Config Class Initialized
DEBUG - 2011-07-13 17:31:49 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:31:49 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:31:49 --> URI Class Initialized
DEBUG - 2011-07-13 17:31:49 --> Router Class Initialized
ERROR - 2011-07-13 17:31:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 17:31:51 --> Config Class Initialized
DEBUG - 2011-07-13 17:31:51 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:31:51 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:31:51 --> URI Class Initialized
DEBUG - 2011-07-13 17:31:51 --> Router Class Initialized
ERROR - 2011-07-13 17:31:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 17:59:55 --> Config Class Initialized
DEBUG - 2011-07-13 17:59:55 --> Config Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Hooks Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Utf8 Class Initialized
DEBUG - 2011-07-13 17:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 17:59:56 --> URI Class Initialized
DEBUG - 2011-07-13 17:59:56 --> URI Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Router Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Router Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Output Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Output Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Input Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Input Class Initialized
DEBUG - 2011-07-13 17:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 17:59:57 --> Language Class Initialized
DEBUG - 2011-07-13 17:59:57 --> Language Class Initialized
DEBUG - 2011-07-13 17:59:58 --> Loader Class Initialized
DEBUG - 2011-07-13 17:59:58 --> Loader Class Initialized
DEBUG - 2011-07-13 17:59:58 --> Controller Class Initialized
DEBUG - 2011-07-13 17:59:58 --> Controller Class Initialized
ERROR - 2011-07-13 17:59:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:59:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:59:58 --> File loaded: application/views/snakes/main.php
ERROR - 2011-07-13 17:59:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 17:59:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 17:59:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 17:59:59 --> Model Class Initialized
DEBUG - 2011-07-13 17:59:59 --> Model Class Initialized
DEBUG - 2011-07-13 17:59:59 --> Model Class Initialized
DEBUG - 2011-07-13 17:59:59 --> Model Class Initialized
DEBUG - 2011-07-13 18:00:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 18:00:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 18:00:00 --> Database Driver Class Initialized
DEBUG - 2011-07-13 18:00:00 --> Database Driver Class Initialized
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 18:00:00 --> Helper loaded: url_helper
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 18:00:00 --> Helper loaded: url_helper
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 18:00:00 --> Final output sent to browser
DEBUG - 2011-07-13 18:00:00 --> Total execution time: 4.8520
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 18:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 18:00:00 --> Final output sent to browser
DEBUG - 2011-07-13 18:00:00 --> Total execution time: 4.8566
DEBUG - 2011-07-13 18:00:01 --> Config Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Hooks Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Utf8 Class Initialized
DEBUG - 2011-07-13 18:00:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 18:00:01 --> URI Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Router Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Output Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Input Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 18:00:01 --> Language Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Loader Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Controller Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Model Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Model Class Initialized
DEBUG - 2011-07-13 18:00:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 18:00:01 --> Database Driver Class Initialized
DEBUG - 2011-07-13 18:00:02 --> Final output sent to browser
DEBUG - 2011-07-13 18:00:02 --> Total execution time: 0.7285
DEBUG - 2011-07-13 18:00:04 --> Config Class Initialized
DEBUG - 2011-07-13 18:00:04 --> Hooks Class Initialized
DEBUG - 2011-07-13 18:00:04 --> Utf8 Class Initialized
DEBUG - 2011-07-13 18:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 18:00:04 --> URI Class Initialized
DEBUG - 2011-07-13 18:00:04 --> Router Class Initialized
ERROR - 2011-07-13 18:00:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 18:00:06 --> Config Class Initialized
DEBUG - 2011-07-13 18:00:06 --> Hooks Class Initialized
DEBUG - 2011-07-13 18:00:06 --> Utf8 Class Initialized
DEBUG - 2011-07-13 18:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 18:00:06 --> URI Class Initialized
DEBUG - 2011-07-13 18:00:06 --> Router Class Initialized
ERROR - 2011-07-13 18:00:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 18:25:07 --> Config Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Hooks Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Utf8 Class Initialized
DEBUG - 2011-07-13 18:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 18:25:07 --> URI Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Router Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Output Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Input Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 18:25:07 --> Language Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Loader Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Controller Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Model Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Model Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Model Class Initialized
DEBUG - 2011-07-13 18:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 18:25:08 --> Database Driver Class Initialized
DEBUG - 2011-07-13 18:25:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 18:25:08 --> Helper loaded: url_helper
DEBUG - 2011-07-13 18:25:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 18:25:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 18:25:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 18:25:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 18:25:08 --> Final output sent to browser
DEBUG - 2011-07-13 18:25:08 --> Total execution time: 0.6072
DEBUG - 2011-07-13 18:25:10 --> Config Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Hooks Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Utf8 Class Initialized
DEBUG - 2011-07-13 18:25:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 18:25:10 --> URI Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Router Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Output Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Input Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 18:25:10 --> Language Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Loader Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Controller Class Initialized
ERROR - 2011-07-13 18:25:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 18:25:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 18:25:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 18:25:10 --> Model Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Model Class Initialized
DEBUG - 2011-07-13 18:25:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 18:25:10 --> Database Driver Class Initialized
DEBUG - 2011-07-13 18:25:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 18:25:10 --> Helper loaded: url_helper
DEBUG - 2011-07-13 18:25:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 18:25:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 18:25:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 18:25:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 18:25:10 --> Final output sent to browser
DEBUG - 2011-07-13 18:25:10 --> Total execution time: 0.0775
DEBUG - 2011-07-13 19:25:49 --> Config Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:25:49 --> URI Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Router Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Output Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Input Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:25:49 --> Language Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Loader Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Controller Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Model Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Model Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Model Class Initialized
DEBUG - 2011-07-13 19:25:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:25:49 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:25:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:25:50 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:25:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:25:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:25:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:25:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:25:50 --> Final output sent to browser
DEBUG - 2011-07-13 19:25:50 --> Total execution time: 0.7918
DEBUG - 2011-07-13 19:25:53 --> Config Class Initialized
DEBUG - 2011-07-13 19:25:53 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:25:53 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:25:53 --> URI Class Initialized
DEBUG - 2011-07-13 19:25:53 --> Router Class Initialized
ERROR - 2011-07-13 19:25:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 19:25:53 --> Config Class Initialized
DEBUG - 2011-07-13 19:25:53 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:25:53 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:25:53 --> URI Class Initialized
DEBUG - 2011-07-13 19:25:53 --> Router Class Initialized
ERROR - 2011-07-13 19:25:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-13 19:26:05 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:05 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:05 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:05 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:05 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:05 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:05 --> Total execution time: 0.3442
DEBUG - 2011-07-13 19:26:07 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:07 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:07 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:07 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:07 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:07 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:07 --> Total execution time: 0.0500
DEBUG - 2011-07-13 19:26:07 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:07 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:07 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:07 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:07 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:07 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:07 --> Total execution time: 0.0749
DEBUG - 2011-07-13 19:26:27 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:27 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:27 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:27 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:27 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:27 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:27 --> Total execution time: 0.2519
DEBUG - 2011-07-13 19:26:29 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:29 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:29 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:29 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:29 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:29 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:29 --> Total execution time: 0.0915
DEBUG - 2011-07-13 19:26:38 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:38 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:38 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:38 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:39 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:39 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:39 --> Total execution time: 0.2517
DEBUG - 2011-07-13 19:26:40 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:40 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:40 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:40 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:40 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:40 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:40 --> Total execution time: 0.0480
DEBUG - 2011-07-13 19:26:41 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:41 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:41 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:41 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:41 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:41 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:41 --> Total execution time: 0.0450
DEBUG - 2011-07-13 19:26:52 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:52 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:52 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:52 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:52 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:52 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:52 --> Total execution time: 0.2423
DEBUG - 2011-07-13 19:26:54 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:54 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:54 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:54 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:54 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:54 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:54 --> Total execution time: 0.0483
DEBUG - 2011-07-13 19:26:54 --> Config Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:26:54 --> URI Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Router Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Output Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Input Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:26:54 --> Language Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Loader Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Controller Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Model Class Initialized
DEBUG - 2011-07-13 19:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:26:54 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:26:54 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:26:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:26:54 --> Final output sent to browser
DEBUG - 2011-07-13 19:26:54 --> Total execution time: 0.0482
DEBUG - 2011-07-13 19:27:04 --> Config Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:27:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:27:04 --> URI Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Router Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Output Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Input Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:27:04 --> Language Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Loader Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Controller Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Model Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Model Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Model Class Initialized
DEBUG - 2011-07-13 19:27:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:27:04 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:27:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:27:04 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:27:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:27:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:27:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:27:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:27:04 --> Final output sent to browser
DEBUG - 2011-07-13 19:27:04 --> Total execution time: 0.2560
DEBUG - 2011-07-13 19:27:06 --> Config Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:27:06 --> URI Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Router Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Output Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Input Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:27:06 --> Language Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Loader Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Controller Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Model Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Model Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Model Class Initialized
DEBUG - 2011-07-13 19:27:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:27:06 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:27:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:27:06 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:27:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:27:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:27:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:27:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:27:06 --> Final output sent to browser
DEBUG - 2011-07-13 19:27:06 --> Total execution time: 0.0487
DEBUG - 2011-07-13 19:32:29 --> Config Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:32:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:32:29 --> URI Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Router Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Output Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Input Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:32:29 --> Language Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Loader Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Controller Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Model Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Model Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Model Class Initialized
DEBUG - 2011-07-13 19:32:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:32:29 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:32:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 19:32:29 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:32:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:32:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:32:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:32:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:32:29 --> Final output sent to browser
DEBUG - 2011-07-13 19:32:29 --> Total execution time: 0.1109
DEBUG - 2011-07-13 19:32:33 --> Config Class Initialized
DEBUG - 2011-07-13 19:32:33 --> Hooks Class Initialized
DEBUG - 2011-07-13 19:32:33 --> Utf8 Class Initialized
DEBUG - 2011-07-13 19:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 19:32:33 --> URI Class Initialized
DEBUG - 2011-07-13 19:32:33 --> Router Class Initialized
DEBUG - 2011-07-13 19:32:33 --> Output Class Initialized
DEBUG - 2011-07-13 19:32:33 --> Input Class Initialized
DEBUG - 2011-07-13 19:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 19:32:33 --> Language Class Initialized
DEBUG - 2011-07-13 19:32:34 --> Loader Class Initialized
DEBUG - 2011-07-13 19:32:34 --> Controller Class Initialized
ERROR - 2011-07-13 19:32:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 19:32:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 19:32:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 19:32:34 --> Model Class Initialized
DEBUG - 2011-07-13 19:32:34 --> Model Class Initialized
DEBUG - 2011-07-13 19:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 19:32:34 --> Database Driver Class Initialized
DEBUG - 2011-07-13 19:32:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 19:32:34 --> Helper loaded: url_helper
DEBUG - 2011-07-13 19:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 19:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 19:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 19:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 19:32:34 --> Final output sent to browser
DEBUG - 2011-07-13 19:32:34 --> Total execution time: 0.2916
DEBUG - 2011-07-13 20:56:21 --> Config Class Initialized
DEBUG - 2011-07-13 20:56:21 --> Hooks Class Initialized
DEBUG - 2011-07-13 20:56:21 --> Utf8 Class Initialized
DEBUG - 2011-07-13 20:56:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 20:56:21 --> URI Class Initialized
DEBUG - 2011-07-13 20:56:21 --> Router Class Initialized
DEBUG - 2011-07-13 20:56:21 --> Output Class Initialized
DEBUG - 2011-07-13 20:56:21 --> Input Class Initialized
DEBUG - 2011-07-13 20:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 20:56:21 --> Language Class Initialized
DEBUG - 2011-07-13 20:56:22 --> Loader Class Initialized
DEBUG - 2011-07-13 20:56:22 --> Controller Class Initialized
ERROR - 2011-07-13 20:56:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 20:56:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 20:56:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 20:56:22 --> Model Class Initialized
DEBUG - 2011-07-13 20:56:22 --> Model Class Initialized
DEBUG - 2011-07-13 20:56:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 20:56:22 --> Database Driver Class Initialized
DEBUG - 2011-07-13 20:56:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 20:56:22 --> Helper loaded: url_helper
DEBUG - 2011-07-13 20:56:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 20:56:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 20:56:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 20:56:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 20:56:22 --> Final output sent to browser
DEBUG - 2011-07-13 20:56:22 --> Total execution time: 0.3465
DEBUG - 2011-07-13 22:18:13 --> Config Class Initialized
DEBUG - 2011-07-13 22:18:13 --> Hooks Class Initialized
DEBUG - 2011-07-13 22:18:13 --> Utf8 Class Initialized
DEBUG - 2011-07-13 22:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 22:18:13 --> URI Class Initialized
DEBUG - 2011-07-13 22:18:13 --> Router Class Initialized
DEBUG - 2011-07-13 22:18:13 --> No URI present. Default controller set.
DEBUG - 2011-07-13 22:18:13 --> Output Class Initialized
DEBUG - 2011-07-13 22:18:13 --> Input Class Initialized
DEBUG - 2011-07-13 22:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 22:18:13 --> Language Class Initialized
DEBUG - 2011-07-13 22:18:13 --> Loader Class Initialized
DEBUG - 2011-07-13 22:18:13 --> Controller Class Initialized
DEBUG - 2011-07-13 22:18:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-13 22:18:13 --> Helper loaded: url_helper
DEBUG - 2011-07-13 22:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 22:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 22:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 22:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 22:18:13 --> Final output sent to browser
DEBUG - 2011-07-13 22:18:13 --> Total execution time: 0.2526
DEBUG - 2011-07-13 22:31:54 --> Config Class Initialized
DEBUG - 2011-07-13 22:31:54 --> Hooks Class Initialized
DEBUG - 2011-07-13 22:31:54 --> Utf8 Class Initialized
DEBUG - 2011-07-13 22:31:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 22:31:54 --> URI Class Initialized
DEBUG - 2011-07-13 22:31:54 --> Router Class Initialized
DEBUG - 2011-07-13 22:31:54 --> Output Class Initialized
DEBUG - 2011-07-13 22:31:54 --> Input Class Initialized
DEBUG - 2011-07-13 22:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 22:31:54 --> Language Class Initialized
DEBUG - 2011-07-13 22:31:54 --> Loader Class Initialized
DEBUG - 2011-07-13 22:31:54 --> Controller Class Initialized
ERROR - 2011-07-13 22:31:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 22:31:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 22:31:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 22:31:55 --> Model Class Initialized
DEBUG - 2011-07-13 22:31:55 --> Model Class Initialized
DEBUG - 2011-07-13 22:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 22:31:55 --> Database Driver Class Initialized
DEBUG - 2011-07-13 22:31:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 22:31:55 --> Helper loaded: url_helper
DEBUG - 2011-07-13 22:31:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 22:31:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 22:31:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 22:31:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 22:31:55 --> Final output sent to browser
DEBUG - 2011-07-13 22:31:55 --> Total execution time: 0.4201
DEBUG - 2011-07-13 22:31:56 --> Config Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Hooks Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Utf8 Class Initialized
DEBUG - 2011-07-13 22:31:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 22:31:56 --> URI Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Router Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Output Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Input Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 22:31:56 --> Language Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Loader Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Controller Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Model Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Model Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 22:31:56 --> Database Driver Class Initialized
DEBUG - 2011-07-13 22:31:56 --> Final output sent to browser
DEBUG - 2011-07-13 22:31:56 --> Total execution time: 0.7032
DEBUG - 2011-07-13 22:46:15 --> Config Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Hooks Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Utf8 Class Initialized
DEBUG - 2011-07-13 22:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 22:46:15 --> URI Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Router Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Output Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Input Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 22:46:15 --> Language Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Loader Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Controller Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Model Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Model Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Model Class Initialized
DEBUG - 2011-07-13 22:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 22:46:15 --> Database Driver Class Initialized
DEBUG - 2011-07-13 22:46:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 22:46:15 --> Helper loaded: url_helper
DEBUG - 2011-07-13 22:46:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 22:46:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 22:46:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 22:46:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 22:46:15 --> Final output sent to browser
DEBUG - 2011-07-13 22:46:15 --> Total execution time: 0.4217
DEBUG - 2011-07-13 23:06:29 --> Config Class Initialized
DEBUG - 2011-07-13 23:06:29 --> Hooks Class Initialized
DEBUG - 2011-07-13 23:06:29 --> Utf8 Class Initialized
DEBUG - 2011-07-13 23:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 23:06:29 --> URI Class Initialized
DEBUG - 2011-07-13 23:06:29 --> Router Class Initialized
ERROR - 2011-07-13 23:06:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-13 23:08:57 --> Config Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Hooks Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Utf8 Class Initialized
DEBUG - 2011-07-13 23:08:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 23:08:57 --> URI Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Router Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Output Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Input Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 23:08:57 --> Language Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Loader Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Controller Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Model Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Model Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Model Class Initialized
DEBUG - 2011-07-13 23:08:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 23:08:57 --> Database Driver Class Initialized
DEBUG - 2011-07-13 23:08:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-13 23:08:58 --> Helper loaded: url_helper
DEBUG - 2011-07-13 23:08:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 23:08:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 23:08:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 23:08:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 23:08:58 --> Final output sent to browser
DEBUG - 2011-07-13 23:08:58 --> Total execution time: 0.9782
DEBUG - 2011-07-13 23:10:53 --> Config Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Hooks Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Utf8 Class Initialized
DEBUG - 2011-07-13 23:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-13 23:10:53 --> URI Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Router Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Output Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Input Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-13 23:10:53 --> Language Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Loader Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Controller Class Initialized
ERROR - 2011-07-13 23:10:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-13 23:10:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-13 23:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 23:10:53 --> Model Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Model Class Initialized
DEBUG - 2011-07-13 23:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-13 23:10:53 --> Database Driver Class Initialized
DEBUG - 2011-07-13 23:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-13 23:10:53 --> Helper loaded: url_helper
DEBUG - 2011-07-13 23:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-13 23:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-13 23:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-13 23:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-13 23:10:53 --> Final output sent to browser
DEBUG - 2011-07-13 23:10:53 --> Total execution time: 0.1225

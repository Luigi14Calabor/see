<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-31 03:06:09 --> Config Class Initialized
DEBUG - 2011-07-31 03:06:09 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:06:09 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:06:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:06:10 --> URI Class Initialized
DEBUG - 2011-07-31 03:06:10 --> Router Class Initialized
DEBUG - 2011-07-31 03:06:10 --> Output Class Initialized
DEBUG - 2011-07-31 03:06:12 --> Input Class Initialized
DEBUG - 2011-07-31 03:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:06:12 --> Language Class Initialized
DEBUG - 2011-07-31 03:06:13 --> Loader Class Initialized
DEBUG - 2011-07-31 03:06:13 --> Controller Class Initialized
ERROR - 2011-07-31 03:06:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 03:06:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 03:06:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 03:06:13 --> Model Class Initialized
DEBUG - 2011-07-31 03:06:13 --> Model Class Initialized
DEBUG - 2011-07-31 03:06:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:06:14 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 03:06:20 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:06:20 --> Final output sent to browser
DEBUG - 2011-07-31 03:06:20 --> Total execution time: 10.8687
DEBUG - 2011-07-31 03:18:14 --> Config Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:18:14 --> URI Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Router Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Output Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Input Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:18:14 --> Language Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Loader Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Controller Class Initialized
ERROR - 2011-07-31 03:18:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 03:18:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 03:18:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 03:18:14 --> Model Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Model Class Initialized
DEBUG - 2011-07-31 03:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:18:14 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:18:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 03:18:14 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:18:14 --> Final output sent to browser
DEBUG - 2011-07-31 03:18:14 --> Total execution time: 0.2203
DEBUG - 2011-07-31 03:29:07 --> Config Class Initialized
DEBUG - 2011-07-31 03:29:07 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:29:07 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:29:07 --> URI Class Initialized
DEBUG - 2011-07-31 03:29:07 --> Router Class Initialized
DEBUG - 2011-07-31 03:29:07 --> No URI present. Default controller set.
DEBUG - 2011-07-31 03:29:07 --> Output Class Initialized
DEBUG - 2011-07-31 03:29:07 --> Input Class Initialized
DEBUG - 2011-07-31 03:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:29:07 --> Language Class Initialized
DEBUG - 2011-07-31 03:29:07 --> Loader Class Initialized
DEBUG - 2011-07-31 03:29:07 --> Controller Class Initialized
DEBUG - 2011-07-31 03:29:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-31 03:29:07 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:29:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:29:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:29:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:29:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:29:07 --> Final output sent to browser
DEBUG - 2011-07-31 03:29:07 --> Total execution time: 0.0872
DEBUG - 2011-07-31 03:29:17 --> Config Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:29:17 --> URI Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Router Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Output Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Input Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:29:17 --> Language Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Loader Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Controller Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:29:17 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:29:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:29:17 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:29:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:29:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:29:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:29:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:29:17 --> Final output sent to browser
DEBUG - 2011-07-31 03:29:17 --> Total execution time: 0.3663
DEBUG - 2011-07-31 03:29:22 --> Config Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:29:22 --> URI Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Router Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Output Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Input Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:29:22 --> Language Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Loader Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Controller Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:29:22 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:29:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:29:22 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:29:22 --> Final output sent to browser
DEBUG - 2011-07-31 03:29:22 --> Total execution time: 0.1107
DEBUG - 2011-07-31 03:29:45 --> Config Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:29:45 --> URI Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Router Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Output Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Input Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:29:45 --> Language Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Loader Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Controller Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:29:45 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:29:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:29:45 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:29:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:29:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:29:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:29:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:29:45 --> Final output sent to browser
DEBUG - 2011-07-31 03:29:45 --> Total execution time: 0.1205
DEBUG - 2011-07-31 03:29:47 --> Config Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:29:47 --> URI Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Router Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Output Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Input Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:29:47 --> Language Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Loader Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Controller Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Model Class Initialized
DEBUG - 2011-07-31 03:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:29:47 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:29:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:29:47 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:29:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:29:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:29:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:29:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:29:47 --> Final output sent to browser
DEBUG - 2011-07-31 03:29:47 --> Total execution time: 0.0495
DEBUG - 2011-07-31 03:30:04 --> Config Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:30:04 --> URI Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Router Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Output Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Input Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:30:04 --> Language Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Loader Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Controller Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:30:04 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:30:05 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:30:05 --> Final output sent to browser
DEBUG - 2011-07-31 03:30:05 --> Total execution time: 1.6381
DEBUG - 2011-07-31 03:30:20 --> Config Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:30:20 --> URI Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Router Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Output Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Input Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:30:20 --> Language Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Loader Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Controller Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:30:20 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:30:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:30:20 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:30:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:30:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:30:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:30:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:30:20 --> Final output sent to browser
DEBUG - 2011-07-31 03:30:20 --> Total execution time: 0.3188
DEBUG - 2011-07-31 03:30:27 --> Config Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:30:27 --> URI Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Router Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Output Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Input Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:30:27 --> Language Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Loader Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Controller Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:30:27 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:30:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:30:27 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:30:27 --> Final output sent to browser
DEBUG - 2011-07-31 03:30:27 --> Total execution time: 0.0539
DEBUG - 2011-07-31 03:30:30 --> Config Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:30:30 --> URI Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Router Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Output Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Input Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:30:30 --> Language Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Loader Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Controller Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:30:30 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:30:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:30:31 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:30:31 --> Final output sent to browser
DEBUG - 2011-07-31 03:30:31 --> Total execution time: 0.3620
DEBUG - 2011-07-31 03:30:36 --> Config Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:30:36 --> URI Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Router Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Output Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Input Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:30:36 --> Language Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Loader Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Controller Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:30:36 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:30:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:30:36 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:30:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:30:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:30:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:30:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:30:36 --> Final output sent to browser
DEBUG - 2011-07-31 03:30:36 --> Total execution time: 0.0425
DEBUG - 2011-07-31 03:30:38 --> Config Class Initialized
DEBUG - 2011-07-31 03:30:38 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:30:38 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:30:38 --> URI Class Initialized
DEBUG - 2011-07-31 03:30:38 --> Router Class Initialized
DEBUG - 2011-07-31 03:30:38 --> Output Class Initialized
DEBUG - 2011-07-31 03:30:38 --> Input Class Initialized
DEBUG - 2011-07-31 03:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:30:39 --> Language Class Initialized
DEBUG - 2011-07-31 03:30:39 --> Loader Class Initialized
DEBUG - 2011-07-31 03:30:39 --> Controller Class Initialized
DEBUG - 2011-07-31 03:30:39 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:39 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:39 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:30:39 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:30:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:30:39 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:30:39 --> Final output sent to browser
DEBUG - 2011-07-31 03:30:39 --> Total execution time: 0.0459
DEBUG - 2011-07-31 03:30:44 --> Config Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:30:44 --> URI Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Router Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Output Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Input Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:30:44 --> Language Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Loader Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Controller Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:30:44 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:30:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:30:45 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:30:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:30:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:30:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:30:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:30:45 --> Final output sent to browser
DEBUG - 2011-07-31 03:30:45 --> Total execution time: 1.3409
DEBUG - 2011-07-31 03:30:48 --> Config Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:30:48 --> URI Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Router Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Output Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Input Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:30:48 --> Language Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Loader Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Controller Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Model Class Initialized
DEBUG - 2011-07-31 03:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:30:48 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:30:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:30:48 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:30:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:30:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:30:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:30:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:30:48 --> Final output sent to browser
DEBUG - 2011-07-31 03:30:48 --> Total execution time: 0.0482
DEBUG - 2011-07-31 03:31:03 --> Config Class Initialized
DEBUG - 2011-07-31 03:31:03 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:31:03 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:31:03 --> URI Class Initialized
DEBUG - 2011-07-31 03:31:03 --> Router Class Initialized
DEBUG - 2011-07-31 03:31:03 --> Output Class Initialized
DEBUG - 2011-07-31 03:31:03 --> Input Class Initialized
DEBUG - 2011-07-31 03:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:31:04 --> Language Class Initialized
DEBUG - 2011-07-31 03:31:04 --> Loader Class Initialized
DEBUG - 2011-07-31 03:31:04 --> Controller Class Initialized
DEBUG - 2011-07-31 03:31:04 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:04 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:04 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:31:04 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:31:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:31:04 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:31:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:31:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:31:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:31:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:31:04 --> Final output sent to browser
DEBUG - 2011-07-31 03:31:04 --> Total execution time: 0.3655
DEBUG - 2011-07-31 03:31:27 --> Config Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:31:27 --> URI Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Router Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Output Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Input Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:31:27 --> Language Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Loader Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Controller Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:31:27 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:31:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:31:27 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:31:27 --> Final output sent to browser
DEBUG - 2011-07-31 03:31:27 --> Total execution time: 0.0431
DEBUG - 2011-07-31 03:31:29 --> Config Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:31:29 --> URI Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Router Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Output Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Input Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:31:29 --> Language Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Loader Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Controller Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Model Class Initialized
DEBUG - 2011-07-31 03:31:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:31:29 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:31:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:31:29 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:31:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:31:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:31:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:31:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:31:29 --> Final output sent to browser
DEBUG - 2011-07-31 03:31:29 --> Total execution time: 0.2352
DEBUG - 2011-07-31 03:32:07 --> Config Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:32:07 --> URI Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Router Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Output Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Input Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:32:07 --> Language Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Loader Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Controller Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:32:07 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:32:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:32:07 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:32:07 --> Final output sent to browser
DEBUG - 2011-07-31 03:32:07 --> Total execution time: 0.0567
DEBUG - 2011-07-31 03:32:11 --> Config Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:32:11 --> URI Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Router Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Output Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Input Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:32:11 --> Language Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Loader Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Controller Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:32:11 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:32:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:32:11 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:32:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:32:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:32:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:32:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:32:11 --> Final output sent to browser
DEBUG - 2011-07-31 03:32:11 --> Total execution time: 0.2198
DEBUG - 2011-07-31 03:32:18 --> Config Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:32:18 --> URI Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Router Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Output Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Input Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:32:18 --> Language Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Loader Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Controller Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:32:18 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:32:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:32:19 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:32:19 --> Final output sent to browser
DEBUG - 2011-07-31 03:32:19 --> Total execution time: 0.5336
DEBUG - 2011-07-31 03:32:27 --> Config Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:32:27 --> URI Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Router Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Output Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Input Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:32:27 --> Language Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Loader Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Controller Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:32:27 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:32:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:32:27 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:32:27 --> Final output sent to browser
DEBUG - 2011-07-31 03:32:27 --> Total execution time: 0.0403
DEBUG - 2011-07-31 03:32:32 --> Config Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:32:32 --> URI Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Router Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Output Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Input Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:32:32 --> Language Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Loader Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Controller Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:32:32 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:32:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:32:32 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:32:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:32:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:32:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:32:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:32:32 --> Final output sent to browser
DEBUG - 2011-07-31 03:32:32 --> Total execution time: 0.0418
DEBUG - 2011-07-31 03:32:44 --> Config Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:32:44 --> URI Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Router Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Output Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Input Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:32:44 --> Language Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Loader Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Controller Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:32:44 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:32:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:32:45 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:32:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:32:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:32:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:32:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:32:45 --> Final output sent to browser
DEBUG - 2011-07-31 03:32:45 --> Total execution time: 1.5141
DEBUG - 2011-07-31 03:32:49 --> Config Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 03:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 03:32:49 --> URI Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Router Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Output Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Input Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 03:32:49 --> Language Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Loader Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Controller Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Model Class Initialized
DEBUG - 2011-07-31 03:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 03:32:49 --> Database Driver Class Initialized
DEBUG - 2011-07-31 03:32:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 03:32:49 --> Helper loaded: url_helper
DEBUG - 2011-07-31 03:32:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 03:32:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 03:32:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 03:32:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 03:32:49 --> Final output sent to browser
DEBUG - 2011-07-31 03:32:49 --> Total execution time: 0.0645
DEBUG - 2011-07-31 04:43:34 --> Config Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Hooks Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Utf8 Class Initialized
DEBUG - 2011-07-31 04:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 04:43:34 --> URI Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Router Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Output Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Input Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 04:43:34 --> Language Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Loader Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Controller Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Model Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Model Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Model Class Initialized
DEBUG - 2011-07-31 04:43:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 04:43:35 --> Database Driver Class Initialized
DEBUG - 2011-07-31 04:43:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 04:43:35 --> Helper loaded: url_helper
DEBUG - 2011-07-31 04:43:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 04:43:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 04:43:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 04:43:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 04:43:35 --> Final output sent to browser
DEBUG - 2011-07-31 04:43:35 --> Total execution time: 1.3241
DEBUG - 2011-07-31 04:43:40 --> Config Class Initialized
DEBUG - 2011-07-31 04:43:40 --> Hooks Class Initialized
DEBUG - 2011-07-31 04:43:40 --> Utf8 Class Initialized
DEBUG - 2011-07-31 04:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 04:43:40 --> URI Class Initialized
DEBUG - 2011-07-31 04:43:40 --> Router Class Initialized
ERROR - 2011-07-31 04:43:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 04:43:40 --> Config Class Initialized
DEBUG - 2011-07-31 04:43:40 --> Hooks Class Initialized
DEBUG - 2011-07-31 04:43:40 --> Utf8 Class Initialized
DEBUG - 2011-07-31 04:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 04:43:40 --> URI Class Initialized
DEBUG - 2011-07-31 04:43:40 --> Router Class Initialized
ERROR - 2011-07-31 04:43:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 05:34:32 --> Config Class Initialized
DEBUG - 2011-07-31 05:34:32 --> Hooks Class Initialized
DEBUG - 2011-07-31 05:34:32 --> Utf8 Class Initialized
DEBUG - 2011-07-31 05:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 05:34:32 --> URI Class Initialized
DEBUG - 2011-07-31 05:34:32 --> Router Class Initialized
DEBUG - 2011-07-31 05:34:32 --> Output Class Initialized
DEBUG - 2011-07-31 05:34:32 --> Input Class Initialized
DEBUG - 2011-07-31 05:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 05:34:32 --> Language Class Initialized
DEBUG - 2011-07-31 05:34:33 --> Loader Class Initialized
DEBUG - 2011-07-31 05:34:33 --> Controller Class Initialized
ERROR - 2011-07-31 05:34:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 05:34:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 05:34:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 05:34:33 --> Model Class Initialized
DEBUG - 2011-07-31 05:34:33 --> Model Class Initialized
DEBUG - 2011-07-31 05:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 05:34:33 --> Database Driver Class Initialized
DEBUG - 2011-07-31 05:34:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 05:34:33 --> Helper loaded: url_helper
DEBUG - 2011-07-31 05:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 05:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 05:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 05:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 05:34:33 --> Final output sent to browser
DEBUG - 2011-07-31 05:34:33 --> Total execution time: 0.2532
DEBUG - 2011-07-31 05:34:37 --> Config Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Hooks Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Utf8 Class Initialized
DEBUG - 2011-07-31 05:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 05:34:37 --> URI Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Router Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Output Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Input Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 05:34:37 --> Language Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Loader Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Controller Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Model Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Model Class Initialized
DEBUG - 2011-07-31 05:34:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 05:34:37 --> Database Driver Class Initialized
DEBUG - 2011-07-31 05:34:38 --> Final output sent to browser
DEBUG - 2011-07-31 05:34:38 --> Total execution time: 0.6589
DEBUG - 2011-07-31 05:34:41 --> Config Class Initialized
DEBUG - 2011-07-31 05:34:41 --> Hooks Class Initialized
DEBUG - 2011-07-31 05:34:41 --> Utf8 Class Initialized
DEBUG - 2011-07-31 05:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 05:34:41 --> URI Class Initialized
DEBUG - 2011-07-31 05:34:41 --> Router Class Initialized
ERROR - 2011-07-31 05:34:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 05:34:44 --> Config Class Initialized
DEBUG - 2011-07-31 05:34:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 05:34:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 05:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 05:34:44 --> URI Class Initialized
DEBUG - 2011-07-31 05:34:44 --> Router Class Initialized
ERROR - 2011-07-31 05:34:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 06:13:37 --> Config Class Initialized
DEBUG - 2011-07-31 06:13:37 --> Hooks Class Initialized
DEBUG - 2011-07-31 06:13:37 --> Utf8 Class Initialized
DEBUG - 2011-07-31 06:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 06:13:37 --> URI Class Initialized
DEBUG - 2011-07-31 06:13:37 --> Router Class Initialized
DEBUG - 2011-07-31 06:13:37 --> No URI present. Default controller set.
DEBUG - 2011-07-31 06:13:37 --> Output Class Initialized
DEBUG - 2011-07-31 06:13:37 --> Input Class Initialized
DEBUG - 2011-07-31 06:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 06:13:37 --> Language Class Initialized
DEBUG - 2011-07-31 06:13:37 --> Loader Class Initialized
DEBUG - 2011-07-31 06:13:37 --> Controller Class Initialized
DEBUG - 2011-07-31 06:13:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-31 06:13:38 --> Helper loaded: url_helper
DEBUG - 2011-07-31 06:13:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 06:13:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 06:13:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 06:13:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 06:13:38 --> Final output sent to browser
DEBUG - 2011-07-31 06:13:38 --> Total execution time: 0.3636
DEBUG - 2011-07-31 10:23:22 --> Config Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:23:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:23:22 --> URI Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Router Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Output Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Input Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:23:22 --> Language Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Loader Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Controller Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:23:22 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:23:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:23:22 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:23:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:23:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:23:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:23:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:23:22 --> Final output sent to browser
DEBUG - 2011-07-31 10:23:22 --> Total execution time: 0.6067
DEBUG - 2011-07-31 10:23:27 --> Config Class Initialized
DEBUG - 2011-07-31 10:23:27 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:23:27 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:23:27 --> URI Class Initialized
DEBUG - 2011-07-31 10:23:27 --> Router Class Initialized
ERROR - 2011-07-31 10:23:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 10:23:28 --> Config Class Initialized
DEBUG - 2011-07-31 10:23:28 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:23:28 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:23:28 --> URI Class Initialized
DEBUG - 2011-07-31 10:23:28 --> Router Class Initialized
ERROR - 2011-07-31 10:23:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 10:23:28 --> Config Class Initialized
DEBUG - 2011-07-31 10:23:28 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:23:28 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:23:28 --> URI Class Initialized
DEBUG - 2011-07-31 10:23:28 --> Router Class Initialized
ERROR - 2011-07-31 10:23:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 10:23:39 --> Config Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:23:39 --> URI Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Router Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Output Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Input Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:23:39 --> Language Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Loader Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Controller Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:23:39 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:23:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:23:39 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:23:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:23:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:23:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:23:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:23:39 --> Final output sent to browser
DEBUG - 2011-07-31 10:23:39 --> Total execution time: 0.2761
DEBUG - 2011-07-31 10:23:43 --> Config Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:23:43 --> URI Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Router Class Initialized
ERROR - 2011-07-31 10:23:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-31 10:23:43 --> Config Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:23:43 --> URI Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Router Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Output Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Input Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:23:43 --> Language Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Loader Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Controller Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Model Class Initialized
DEBUG - 2011-07-31 10:23:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:23:43 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:23:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:23:43 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:23:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:23:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:23:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:23:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:23:43 --> Final output sent to browser
DEBUG - 2011-07-31 10:23:43 --> Total execution time: 0.0491
DEBUG - 2011-07-31 10:24:25 --> Config Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:24:25 --> URI Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Router Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Output Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Input Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:24:25 --> Language Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Loader Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Controller Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:24:25 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:24:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:24:25 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:24:25 --> Final output sent to browser
DEBUG - 2011-07-31 10:24:25 --> Total execution time: 0.1886
DEBUG - 2011-07-31 10:24:28 --> Config Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:24:28 --> URI Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Router Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Output Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Input Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:24:28 --> Language Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Loader Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Controller Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:24:28 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:24:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:24:28 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:24:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:24:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:24:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:24:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:24:28 --> Final output sent to browser
DEBUG - 2011-07-31 10:24:28 --> Total execution time: 0.0720
DEBUG - 2011-07-31 10:24:41 --> Config Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:24:41 --> URI Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Router Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Output Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Input Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:24:41 --> Language Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Loader Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Controller Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:24:41 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:24:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:24:42 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:24:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:24:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:24:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:24:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:24:42 --> Final output sent to browser
DEBUG - 2011-07-31 10:24:42 --> Total execution time: 0.3512
DEBUG - 2011-07-31 10:24:44 --> Config Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:24:44 --> URI Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Router Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Output Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Input Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:24:44 --> Language Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Loader Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Controller Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:24:44 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:24:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:24:44 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:24:44 --> Final output sent to browser
DEBUG - 2011-07-31 10:24:44 --> Total execution time: 0.0517
DEBUG - 2011-07-31 10:24:56 --> Config Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:24:56 --> URI Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Router Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Output Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Input Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:24:56 --> Language Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Loader Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Controller Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:24:56 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:24:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:24:56 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:24:56 --> Final output sent to browser
DEBUG - 2011-07-31 10:24:56 --> Total execution time: 0.2579
DEBUG - 2011-07-31 10:24:59 --> Config Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:24:59 --> URI Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Router Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Output Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Input Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:24:59 --> Language Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Loader Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Controller Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Model Class Initialized
DEBUG - 2011-07-31 10:24:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:24:59 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:24:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:24:59 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:24:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:24:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:24:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:24:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:24:59 --> Final output sent to browser
DEBUG - 2011-07-31 10:24:59 --> Total execution time: 0.1138
DEBUG - 2011-07-31 10:25:08 --> Config Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:25:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:25:08 --> URI Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Router Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Output Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Input Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:25:08 --> Language Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Loader Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Controller Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:25:08 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:25:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:25:09 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:25:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:25:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:25:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:25:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:25:09 --> Final output sent to browser
DEBUG - 2011-07-31 10:25:09 --> Total execution time: 0.5655
DEBUG - 2011-07-31 10:25:14 --> Config Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:25:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:25:14 --> URI Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Router Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Output Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Input Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:25:14 --> Language Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Loader Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Controller Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:25:14 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:25:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:25:14 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:25:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:25:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:25:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:25:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:25:14 --> Final output sent to browser
DEBUG - 2011-07-31 10:25:14 --> Total execution time: 0.1160
DEBUG - 2011-07-31 10:25:26 --> Config Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:25:26 --> URI Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Router Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Output Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Input Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:25:26 --> Language Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Loader Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Controller Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:25:26 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:25:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:25:27 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:25:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:25:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:25:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:25:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:25:27 --> Final output sent to browser
DEBUG - 2011-07-31 10:25:27 --> Total execution time: 0.3156
DEBUG - 2011-07-31 10:25:32 --> Config Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:25:32 --> URI Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Router Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Output Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Input Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:25:32 --> Language Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Loader Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Controller Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:25:32 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:25:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:25:32 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:25:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:25:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:25:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:25:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:25:32 --> Final output sent to browser
DEBUG - 2011-07-31 10:25:32 --> Total execution time: 0.0746
DEBUG - 2011-07-31 10:25:39 --> Config Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:25:39 --> URI Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Router Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Output Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Input Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:25:39 --> Language Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Loader Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Controller Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:25:39 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:25:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:25:39 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:25:39 --> Final output sent to browser
DEBUG - 2011-07-31 10:25:39 --> Total execution time: 0.4522
DEBUG - 2011-07-31 10:25:42 --> Config Class Initialized
DEBUG - 2011-07-31 10:25:42 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:25:42 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:25:42 --> URI Class Initialized
DEBUG - 2011-07-31 10:25:42 --> Router Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Output Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Input Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:25:43 --> Language Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Loader Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Controller Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:25:43 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:25:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:25:43 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:25:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:25:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:25:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:25:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:25:43 --> Final output sent to browser
DEBUG - 2011-07-31 10:25:43 --> Total execution time: 0.6308
DEBUG - 2011-07-31 10:25:49 --> Config Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:25:49 --> URI Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Router Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Output Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Input Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:25:49 --> Language Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Loader Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Controller Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:25:49 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:25:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:25:49 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:25:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:25:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:25:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:25:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:25:49 --> Final output sent to browser
DEBUG - 2011-07-31 10:25:49 --> Total execution time: 0.2514
DEBUG - 2011-07-31 10:25:57 --> Config Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:25:57 --> URI Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Router Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Output Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Input Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:25:57 --> Language Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Loader Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Controller Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Model Class Initialized
DEBUG - 2011-07-31 10:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:25:57 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:25:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:25:58 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:25:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:25:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:25:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:25:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:25:58 --> Final output sent to browser
DEBUG - 2011-07-31 10:25:58 --> Total execution time: 0.4498
DEBUG - 2011-07-31 10:26:18 --> Config Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:26:18 --> URI Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Router Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Output Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Input Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:26:18 --> Language Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Loader Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Controller Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:26:18 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:26:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:26:18 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:26:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:26:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:26:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:26:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:26:18 --> Final output sent to browser
DEBUG - 2011-07-31 10:26:18 --> Total execution time: 0.3289
DEBUG - 2011-07-31 10:26:29 --> Config Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:26:29 --> URI Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Router Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Output Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Input Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:26:29 --> Language Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Loader Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Controller Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:26:29 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:26:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:26:29 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:26:29 --> Final output sent to browser
DEBUG - 2011-07-31 10:26:29 --> Total execution time: 0.0607
DEBUG - 2011-07-31 10:26:57 --> Config Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:26:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:26:57 --> URI Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Router Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Output Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Input Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:26:57 --> Language Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Loader Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Controller Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Model Class Initialized
DEBUG - 2011-07-31 10:26:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:26:57 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:26:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:26:57 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:26:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:26:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:26:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:26:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:26:57 --> Final output sent to browser
DEBUG - 2011-07-31 10:26:57 --> Total execution time: 0.0490
DEBUG - 2011-07-31 10:27:06 --> Config Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:27:06 --> URI Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Router Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Output Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Input Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:27:06 --> Language Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Loader Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Controller Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Model Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Model Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Model Class Initialized
DEBUG - 2011-07-31 10:27:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:27:06 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:27:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:27:06 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:27:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:27:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:27:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:27:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:27:06 --> Final output sent to browser
DEBUG - 2011-07-31 10:27:06 --> Total execution time: 0.1586
DEBUG - 2011-07-31 10:29:48 --> Config Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:29:48 --> URI Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Router Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Output Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Input Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 10:29:48 --> Language Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Loader Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Controller Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Model Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Model Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Model Class Initialized
DEBUG - 2011-07-31 10:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 10:29:48 --> Database Driver Class Initialized
DEBUG - 2011-07-31 10:29:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 10:29:48 --> Helper loaded: url_helper
DEBUG - 2011-07-31 10:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 10:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 10:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 10:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 10:29:48 --> Final output sent to browser
DEBUG - 2011-07-31 10:29:48 --> Total execution time: 0.0631
DEBUG - 2011-07-31 10:29:50 --> Config Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:29:50 --> URI Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Router Class Initialized
ERROR - 2011-07-31 10:29:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 10:29:50 --> Config Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:29:50 --> URI Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Router Class Initialized
ERROR - 2011-07-31 10:29:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 10:29:50 --> Config Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Hooks Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Utf8 Class Initialized
DEBUG - 2011-07-31 10:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 10:29:50 --> URI Class Initialized
DEBUG - 2011-07-31 10:29:50 --> Router Class Initialized
ERROR - 2011-07-31 10:29:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 11:21:52 --> Config Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:21:52 --> URI Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Router Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Output Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Input Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:21:52 --> Language Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Loader Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Controller Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Model Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Model Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Model Class Initialized
DEBUG - 2011-07-31 11:21:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:21:52 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:21:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 11:21:53 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:21:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:21:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:21:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:21:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:21:53 --> Final output sent to browser
DEBUG - 2011-07-31 11:21:53 --> Total execution time: 0.7832
DEBUG - 2011-07-31 11:47:42 --> Config Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:47:42 --> URI Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Router Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Output Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Input Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:47:42 --> Language Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Loader Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Controller Class Initialized
ERROR - 2011-07-31 11:47:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:47:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:47:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:47:42 --> Model Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Model Class Initialized
DEBUG - 2011-07-31 11:47:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:47:42 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:47:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:47:42 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:47:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:47:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:47:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:47:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:47:42 --> Final output sent to browser
DEBUG - 2011-07-31 11:47:42 --> Total execution time: 0.0995
DEBUG - 2011-07-31 11:47:47 --> Config Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:47:47 --> URI Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Router Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Output Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Input Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:47:47 --> Language Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Loader Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Controller Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Model Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Model Class Initialized
DEBUG - 2011-07-31 11:47:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:47:47 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:47:48 --> Final output sent to browser
DEBUG - 2011-07-31 11:47:48 --> Total execution time: 0.8397
DEBUG - 2011-07-31 11:47:54 --> Config Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:47:54 --> URI Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Router Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Output Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Input Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:47:54 --> Language Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Loader Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Controller Class Initialized
ERROR - 2011-07-31 11:47:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:47:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:47:54 --> Model Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Model Class Initialized
DEBUG - 2011-07-31 11:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:47:54 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:47:54 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:47:54 --> Final output sent to browser
DEBUG - 2011-07-31 11:47:54 --> Total execution time: 0.0280
DEBUG - 2011-07-31 11:48:25 --> Config Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:48:25 --> URI Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Config Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:48:25 --> URI Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Router Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Output Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Router Class Initialized
ERROR - 2011-07-31 11:48:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 11:48:25 --> Input Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:48:25 --> Language Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Loader Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Controller Class Initialized
ERROR - 2011-07-31 11:48:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:48:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:48:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:48:25 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:48:25 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:48:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:48:25 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:48:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:48:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:48:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:48:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:48:25 --> Final output sent to browser
DEBUG - 2011-07-31 11:48:25 --> Total execution time: 0.0347
DEBUG - 2011-07-31 11:48:26 --> Config Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:48:26 --> URI Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Router Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Output Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Input Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:48:26 --> Language Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Loader Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Controller Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:48:26 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:48:27 --> Final output sent to browser
DEBUG - 2011-07-31 11:48:27 --> Total execution time: 0.5610
DEBUG - 2011-07-31 11:48:29 --> Config Class Initialized
DEBUG - 2011-07-31 11:48:29 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:48:29 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:48:29 --> URI Class Initialized
DEBUG - 2011-07-31 11:48:29 --> Router Class Initialized
ERROR - 2011-07-31 11:48:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 11:48:44 --> Config Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:48:44 --> URI Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Router Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Output Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Input Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:48:44 --> Language Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Loader Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Controller Class Initialized
ERROR - 2011-07-31 11:48:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:48:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:48:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:48:44 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:48:44 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:48:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:48:44 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:48:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:48:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:48:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:48:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:48:44 --> Final output sent to browser
DEBUG - 2011-07-31 11:48:44 --> Total execution time: 0.0302
DEBUG - 2011-07-31 11:48:44 --> Config Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:48:44 --> URI Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Router Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Output Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Input Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:48:44 --> Language Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Loader Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Controller Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:48:44 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:48:45 --> Final output sent to browser
DEBUG - 2011-07-31 11:48:45 --> Total execution time: 0.5364
DEBUG - 2011-07-31 11:48:55 --> Config Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:48:55 --> URI Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Router Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Output Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Input Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:48:55 --> Language Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Loader Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Controller Class Initialized
ERROR - 2011-07-31 11:48:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:48:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:48:55 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:48:55 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:48:55 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:48:55 --> Final output sent to browser
DEBUG - 2011-07-31 11:48:55 --> Total execution time: 0.0334
DEBUG - 2011-07-31 11:48:56 --> Config Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:48:56 --> URI Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Router Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Output Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Input Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:48:56 --> Language Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Loader Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Controller Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Model Class Initialized
DEBUG - 2011-07-31 11:48:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:48:56 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:48:57 --> Final output sent to browser
DEBUG - 2011-07-31 11:48:57 --> Total execution time: 1.0021
DEBUG - 2011-07-31 11:49:18 --> Config Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:49:18 --> URI Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Router Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Output Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Input Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:49:18 --> Language Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Loader Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Controller Class Initialized
ERROR - 2011-07-31 11:49:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:49:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:49:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:49:18 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:49:18 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:49:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:49:18 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:49:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:49:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:49:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:49:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:49:18 --> Final output sent to browser
DEBUG - 2011-07-31 11:49:18 --> Total execution time: 0.0631
DEBUG - 2011-07-31 11:49:19 --> Config Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:49:19 --> URI Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Router Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Output Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Input Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:49:19 --> Language Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Loader Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Controller Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:49:19 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:49:20 --> Final output sent to browser
DEBUG - 2011-07-31 11:49:20 --> Total execution time: 0.5546
DEBUG - 2011-07-31 11:49:31 --> Config Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:49:31 --> URI Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Router Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Output Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Input Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:49:31 --> Language Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Loader Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Controller Class Initialized
ERROR - 2011-07-31 11:49:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:49:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:49:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:49:31 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:49:31 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:49:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:49:31 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:49:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:49:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:49:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:49:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:49:31 --> Final output sent to browser
DEBUG - 2011-07-31 11:49:31 --> Total execution time: 0.0337
DEBUG - 2011-07-31 11:49:32 --> Config Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:49:32 --> URI Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Router Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Output Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Input Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:49:32 --> Language Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Loader Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Controller Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:49:32 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:49:32 --> Final output sent to browser
DEBUG - 2011-07-31 11:49:32 --> Total execution time: 0.6133
DEBUG - 2011-07-31 11:49:58 --> Config Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:49:58 --> URI Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Router Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Output Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Input Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:49:58 --> Language Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Loader Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Controller Class Initialized
ERROR - 2011-07-31 11:49:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:49:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:49:58 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:49:58 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:49:58 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:49:58 --> Final output sent to browser
DEBUG - 2011-07-31 11:49:58 --> Total execution time: 0.0268
DEBUG - 2011-07-31 11:49:58 --> Config Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:49:58 --> URI Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Router Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Output Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Input Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:49:58 --> Language Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Loader Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Controller Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Model Class Initialized
DEBUG - 2011-07-31 11:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:49:58 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:49:59 --> Final output sent to browser
DEBUG - 2011-07-31 11:49:59 --> Total execution time: 0.5519
DEBUG - 2011-07-31 11:50:08 --> Config Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:50:08 --> URI Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Router Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Output Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Input Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:50:08 --> Language Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Loader Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Controller Class Initialized
ERROR - 2011-07-31 11:50:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:50:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:50:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:08 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:50:08 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:50:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:08 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:50:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:50:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:50:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:50:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:50:08 --> Final output sent to browser
DEBUG - 2011-07-31 11:50:08 --> Total execution time: 0.0414
DEBUG - 2011-07-31 11:50:09 --> Config Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:50:09 --> URI Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Router Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Output Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Input Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:50:09 --> Language Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Loader Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Controller Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:50:09 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:50:09 --> Final output sent to browser
DEBUG - 2011-07-31 11:50:09 --> Total execution time: 0.5220
DEBUG - 2011-07-31 11:50:45 --> Config Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:50:45 --> URI Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Router Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Output Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Input Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:50:45 --> Language Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Loader Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Controller Class Initialized
ERROR - 2011-07-31 11:50:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:50:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:45 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:50:45 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:45 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:50:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:50:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:50:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:50:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:50:45 --> Final output sent to browser
DEBUG - 2011-07-31 11:50:45 --> Total execution time: 0.0721
DEBUG - 2011-07-31 11:50:45 --> Config Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:50:45 --> URI Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Router Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Output Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Input Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:50:45 --> Language Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Loader Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Controller Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:50:45 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:50:46 --> Final output sent to browser
DEBUG - 2011-07-31 11:50:46 --> Total execution time: 0.5087
DEBUG - 2011-07-31 11:50:50 --> Config Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:50:50 --> URI Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Router Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Output Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Input Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:50:50 --> Language Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Loader Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Controller Class Initialized
ERROR - 2011-07-31 11:50:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:50:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:50:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:50 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:50:50 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:50:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:50 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:50:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:50:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:50:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:50:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:50:50 --> Final output sent to browser
DEBUG - 2011-07-31 11:50:50 --> Total execution time: 0.0873
DEBUG - 2011-07-31 11:50:58 --> Config Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:50:58 --> URI Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Router Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Output Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Input Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:50:58 --> Language Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Loader Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Controller Class Initialized
ERROR - 2011-07-31 11:50:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:50:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:50:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:58 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:50:58 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:50:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:58 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:50:58 --> Final output sent to browser
DEBUG - 2011-07-31 11:50:58 --> Total execution time: 0.0285
DEBUG - 2011-07-31 11:50:58 --> Config Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:50:58 --> URI Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Router Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Output Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Input Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:50:58 --> Language Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Loader Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Controller Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:50:58 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Final output sent to browser
DEBUG - 2011-07-31 11:50:59 --> Total execution time: 0.6109
DEBUG - 2011-07-31 11:50:59 --> Config Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:50:59 --> URI Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Router Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Output Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Input Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:50:59 --> Language Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Loader Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Controller Class Initialized
ERROR - 2011-07-31 11:50:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:50:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:50:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:59 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Model Class Initialized
DEBUG - 2011-07-31 11:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:50:59 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:50:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:50:59 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:50:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:50:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:50:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:50:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:50:59 --> Final output sent to browser
DEBUG - 2011-07-31 11:50:59 --> Total execution time: 0.0293
DEBUG - 2011-07-31 11:51:12 --> Config Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:51:12 --> URI Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Router Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Output Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Input Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:51:12 --> Language Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Loader Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Controller Class Initialized
ERROR - 2011-07-31 11:51:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 11:51:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 11:51:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:51:12 --> Model Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Model Class Initialized
DEBUG - 2011-07-31 11:51:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:51:12 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:51:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 11:51:12 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:51:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:51:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:51:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:51:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:51:12 --> Final output sent to browser
DEBUG - 2011-07-31 11:51:12 --> Total execution time: 0.0285
DEBUG - 2011-07-31 11:51:13 --> Config Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:51:13 --> URI Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Router Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Output Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Input Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:51:13 --> Language Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Loader Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Controller Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Model Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Model Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:51:13 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:51:13 --> Final output sent to browser
DEBUG - 2011-07-31 11:51:13 --> Total execution time: 0.6248
DEBUG - 2011-07-31 11:52:47 --> Config Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:52:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:52:47 --> URI Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Router Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Output Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Input Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 11:52:47 --> Language Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Loader Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Controller Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Model Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Model Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Model Class Initialized
DEBUG - 2011-07-31 11:52:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 11:52:47 --> Database Driver Class Initialized
DEBUG - 2011-07-31 11:52:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 11:52:47 --> Helper loaded: url_helper
DEBUG - 2011-07-31 11:52:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 11:52:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 11:52:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 11:52:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 11:52:47 --> Final output sent to browser
DEBUG - 2011-07-31 11:52:47 --> Total execution time: 0.3413
DEBUG - 2011-07-31 11:52:51 --> Config Class Initialized
DEBUG - 2011-07-31 11:52:51 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:52:51 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:52:51 --> URI Class Initialized
DEBUG - 2011-07-31 11:52:51 --> Router Class Initialized
ERROR - 2011-07-31 11:52:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 11:52:51 --> Config Class Initialized
DEBUG - 2011-07-31 11:52:51 --> Hooks Class Initialized
DEBUG - 2011-07-31 11:52:51 --> Utf8 Class Initialized
DEBUG - 2011-07-31 11:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 11:52:51 --> URI Class Initialized
DEBUG - 2011-07-31 11:52:51 --> Router Class Initialized
ERROR - 2011-07-31 11:52:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 12:02:18 --> Config Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:02:18 --> URI Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Router Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Output Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Input Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:02:18 --> Language Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Loader Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Controller Class Initialized
ERROR - 2011-07-31 12:02:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 12:02:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 12:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 12:02:18 --> Model Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Model Class Initialized
DEBUG - 2011-07-31 12:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 12:02:18 --> Database Driver Class Initialized
DEBUG - 2011-07-31 12:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 12:02:18 --> Helper loaded: url_helper
DEBUG - 2011-07-31 12:02:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 12:02:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 12:02:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 12:02:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 12:02:18 --> Final output sent to browser
DEBUG - 2011-07-31 12:02:18 --> Total execution time: 0.0404
DEBUG - 2011-07-31 12:02:20 --> Config Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:02:20 --> URI Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Router Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Output Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Input Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:02:20 --> Language Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Loader Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Controller Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Model Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Model Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 12:02:20 --> Database Driver Class Initialized
DEBUG - 2011-07-31 12:02:20 --> Final output sent to browser
DEBUG - 2011-07-31 12:02:20 --> Total execution time: 0.4929
DEBUG - 2011-07-31 12:02:34 --> Config Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:02:34 --> URI Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Router Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Output Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Input Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:02:34 --> Language Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Loader Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Controller Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Model Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Model Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Model Class Initialized
DEBUG - 2011-07-31 12:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 12:02:34 --> Database Driver Class Initialized
DEBUG - 2011-07-31 12:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 12:02:34 --> Helper loaded: url_helper
DEBUG - 2011-07-31 12:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 12:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 12:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 12:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 12:02:34 --> Final output sent to browser
DEBUG - 2011-07-31 12:02:34 --> Total execution time: 0.0562
DEBUG - 2011-07-31 12:02:37 --> Config Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:02:37 --> URI Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Router Class Initialized
ERROR - 2011-07-31 12:02:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 12:02:37 --> Config Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:02:37 --> URI Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Router Class Initialized
ERROR - 2011-07-31 12:02:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 12:02:37 --> Config Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:02:37 --> URI Class Initialized
DEBUG - 2011-07-31 12:02:37 --> Router Class Initialized
ERROR - 2011-07-31 12:02:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 12:04:32 --> Config Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:04:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:04:32 --> URI Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Router Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Output Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Input Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:04:32 --> Language Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Loader Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Controller Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Model Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Model Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Model Class Initialized
DEBUG - 2011-07-31 12:04:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 12:04:32 --> Database Driver Class Initialized
DEBUG - 2011-07-31 12:04:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 12:04:32 --> Helper loaded: url_helper
DEBUG - 2011-07-31 12:04:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 12:04:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 12:04:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 12:04:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 12:04:32 --> Final output sent to browser
DEBUG - 2011-07-31 12:04:32 --> Total execution time: 0.0724
DEBUG - 2011-07-31 12:12:21 --> Config Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:12:21 --> URI Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Router Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Output Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Input Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:12:21 --> Language Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Loader Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Controller Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Model Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Model Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Model Class Initialized
DEBUG - 2011-07-31 12:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 12:12:21 --> Database Driver Class Initialized
DEBUG - 2011-07-31 12:12:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 12:12:21 --> Helper loaded: url_helper
DEBUG - 2011-07-31 12:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 12:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 12:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 12:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 12:12:21 --> Final output sent to browser
DEBUG - 2011-07-31 12:12:21 --> Total execution time: 0.0875
DEBUG - 2011-07-31 12:13:23 --> Config Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:13:23 --> URI Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Router Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Output Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Input Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:13:23 --> Language Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Loader Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Controller Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Model Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Model Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Model Class Initialized
DEBUG - 2011-07-31 12:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 12:13:23 --> Database Driver Class Initialized
DEBUG - 2011-07-31 12:13:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 12:13:23 --> Helper loaded: url_helper
DEBUG - 2011-07-31 12:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 12:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 12:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 12:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 12:13:23 --> Final output sent to browser
DEBUG - 2011-07-31 12:13:23 --> Total execution time: 0.0441
DEBUG - 2011-07-31 12:43:34 --> Config Class Initialized
DEBUG - 2011-07-31 12:43:34 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:43:34 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:43:34 --> URI Class Initialized
DEBUG - 2011-07-31 12:43:34 --> Router Class Initialized
DEBUG - 2011-07-31 12:43:34 --> No URI present. Default controller set.
DEBUG - 2011-07-31 12:43:34 --> Output Class Initialized
DEBUG - 2011-07-31 12:43:34 --> Input Class Initialized
DEBUG - 2011-07-31 12:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:43:34 --> Language Class Initialized
DEBUG - 2011-07-31 12:43:34 --> Loader Class Initialized
DEBUG - 2011-07-31 12:43:34 --> Controller Class Initialized
DEBUG - 2011-07-31 12:43:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-31 12:43:34 --> Helper loaded: url_helper
DEBUG - 2011-07-31 12:43:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 12:43:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 12:43:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 12:43:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 12:43:34 --> Final output sent to browser
DEBUG - 2011-07-31 12:43:34 --> Total execution time: 0.0981
DEBUG - 2011-07-31 12:43:44 --> Config Class Initialized
DEBUG - 2011-07-31 12:43:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:43:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:43:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:43:44 --> URI Class Initialized
DEBUG - 2011-07-31 12:43:44 --> Router Class Initialized
ERROR - 2011-07-31 12:43:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 12:43:48 --> Config Class Initialized
DEBUG - 2011-07-31 12:43:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:43:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:43:48 --> URI Class Initialized
DEBUG - 2011-07-31 12:43:48 --> Router Class Initialized
ERROR - 2011-07-31 12:43:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 12:59:44 --> Config Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:59:44 --> URI Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Router Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Output Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Input Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:59:44 --> Language Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Loader Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Controller Class Initialized
ERROR - 2011-07-31 12:59:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 12:59:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 12:59:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 12:59:44 --> Model Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Model Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 12:59:44 --> Database Driver Class Initialized
DEBUG - 2011-07-31 12:59:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 12:59:44 --> Helper loaded: url_helper
DEBUG - 2011-07-31 12:59:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 12:59:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 12:59:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 12:59:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 12:59:44 --> Final output sent to browser
DEBUG - 2011-07-31 12:59:44 --> Total execution time: 0.0300
DEBUG - 2011-07-31 12:59:44 --> Config Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:59:44 --> URI Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Router Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Output Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Input Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 12:59:44 --> Language Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Loader Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Controller Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Model Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Model Class Initialized
DEBUG - 2011-07-31 12:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 12:59:45 --> Database Driver Class Initialized
DEBUG - 2011-07-31 12:59:45 --> Final output sent to browser
DEBUG - 2011-07-31 12:59:45 --> Total execution time: 0.7414
DEBUG - 2011-07-31 12:59:47 --> Config Class Initialized
DEBUG - 2011-07-31 12:59:47 --> Hooks Class Initialized
DEBUG - 2011-07-31 12:59:47 --> Utf8 Class Initialized
DEBUG - 2011-07-31 12:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 12:59:47 --> URI Class Initialized
DEBUG - 2011-07-31 12:59:47 --> Router Class Initialized
ERROR - 2011-07-31 12:59:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:00:37 --> Config Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:00:37 --> URI Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Router Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Output Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Input Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:00:37 --> Language Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Loader Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Controller Class Initialized
ERROR - 2011-07-31 13:00:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:00:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:00:37 --> Model Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Model Class Initialized
DEBUG - 2011-07-31 13:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:00:37 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:00:37 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:00:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:00:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:00:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:00:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:00:37 --> Final output sent to browser
DEBUG - 2011-07-31 13:00:37 --> Total execution time: 0.0663
DEBUG - 2011-07-31 13:00:38 --> Config Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:00:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:00:38 --> URI Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Router Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Output Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Input Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:00:38 --> Language Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Loader Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Controller Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Model Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Model Class Initialized
DEBUG - 2011-07-31 13:00:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:00:38 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:00:39 --> Final output sent to browser
DEBUG - 2011-07-31 13:00:39 --> Total execution time: 0.6821
DEBUG - 2011-07-31 13:00:40 --> Config Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:00:40 --> URI Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Router Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Output Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Input Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:00:40 --> Language Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Loader Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Controller Class Initialized
ERROR - 2011-07-31 13:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:00:40 --> Model Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Model Class Initialized
DEBUG - 2011-07-31 13:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:00:40 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:00:40 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:00:40 --> Final output sent to browser
DEBUG - 2011-07-31 13:00:40 --> Total execution time: 0.3474
DEBUG - 2011-07-31 13:00:41 --> Config Class Initialized
DEBUG - 2011-07-31 13:00:41 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:00:41 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:00:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:00:41 --> URI Class Initialized
DEBUG - 2011-07-31 13:00:41 --> Router Class Initialized
ERROR - 2011-07-31 13:00:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:01:40 --> Config Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:01:40 --> URI Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Router Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Output Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Input Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:01:40 --> Language Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Loader Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Controller Class Initialized
ERROR - 2011-07-31 13:01:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:01:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:01:40 --> Model Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Model Class Initialized
DEBUG - 2011-07-31 13:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:01:40 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:01:40 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:01:40 --> Final output sent to browser
DEBUG - 2011-07-31 13:01:40 --> Total execution time: 0.0275
DEBUG - 2011-07-31 13:01:41 --> Config Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:01:41 --> URI Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Router Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Output Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Input Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:01:41 --> Language Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Loader Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Controller Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Model Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Model Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:01:41 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:01:41 --> Final output sent to browser
DEBUG - 2011-07-31 13:01:41 --> Total execution time: 0.5861
DEBUG - 2011-07-31 13:01:42 --> Config Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:01:42 --> URI Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Router Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Output Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Input Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:01:42 --> Language Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Loader Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Controller Class Initialized
ERROR - 2011-07-31 13:01:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:01:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:01:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:01:42 --> Model Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Model Class Initialized
DEBUG - 2011-07-31 13:01:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:01:42 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:01:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:01:42 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:01:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:01:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:01:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:01:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:01:42 --> Final output sent to browser
DEBUG - 2011-07-31 13:01:42 --> Total execution time: 0.0354
DEBUG - 2011-07-31 13:01:44 --> Config Class Initialized
DEBUG - 2011-07-31 13:01:44 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:01:44 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:01:44 --> URI Class Initialized
DEBUG - 2011-07-31 13:01:44 --> Router Class Initialized
ERROR - 2011-07-31 13:01:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:02:01 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:01 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:01 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:01 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:01 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:01 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:01 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:01 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:02 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:02 --> Controller Class Initialized
ERROR - 2011-07-31 13:02:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:02:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:02:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:02 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:02 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:02 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:02 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:02:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:02:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:02:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:02:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:02:02 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:02 --> Total execution time: 0.0923
DEBUG - 2011-07-31 13:02:03 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:03 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:03 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Controller Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:03 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:03 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:03 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Controller Class Initialized
ERROR - 2011-07-31 13:02:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:02:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:02:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:03 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:03 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:03 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:02:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:02:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:02:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:02:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:02:03 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:03 --> Total execution time: 0.0375
DEBUG - 2011-07-31 13:02:03 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:03 --> Total execution time: 0.5643
DEBUG - 2011-07-31 13:02:05 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:05 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:05 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:05 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:05 --> Router Class Initialized
ERROR - 2011-07-31 13:02:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:02:24 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:24 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:24 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Controller Class Initialized
ERROR - 2011-07-31 13:02:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:02:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:02:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:24 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:24 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:24 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:02:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:02:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:02:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:02:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:02:24 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:24 --> Total execution time: 0.0347
DEBUG - 2011-07-31 13:02:25 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:25 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:25 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Controller Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:25 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:26 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:26 --> Total execution time: 0.5112
DEBUG - 2011-07-31 13:02:28 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:28 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:28 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:28 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:28 --> Router Class Initialized
ERROR - 2011-07-31 13:02:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:02:48 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:48 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:48 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Controller Class Initialized
ERROR - 2011-07-31 13:02:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:02:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:02:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:48 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:48 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:48 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:02:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:02:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:02:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:02:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:02:48 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:48 --> Total execution time: 0.0426
DEBUG - 2011-07-31 13:02:49 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:49 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:49 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:49 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:49 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:49 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Controller Class Initialized
ERROR - 2011-07-31 13:02:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:02:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:02:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:49 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:49 --> Controller Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:49 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:49 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:49 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:02:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:02:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:02:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:02:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:02:49 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:49 --> Total execution time: 0.0289
DEBUG - 2011-07-31 13:02:50 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:50 --> Total execution time: 0.6677
DEBUG - 2011-07-31 13:02:52 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:52 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:52 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:52 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:52 --> Router Class Initialized
ERROR - 2011-07-31 13:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:02:54 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:54 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:54 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Controller Class Initialized
ERROR - 2011-07-31 13:02:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:02:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:02:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:54 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:55 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:02:55 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:02:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:02:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:02:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:02:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:02:55 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:55 --> Total execution time: 0.0276
DEBUG - 2011-07-31 13:02:55 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:55 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Router Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Output Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Input Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:02:55 --> Language Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Loader Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Controller Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Model Class Initialized
DEBUG - 2011-07-31 13:02:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:02:55 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:02:56 --> Final output sent to browser
DEBUG - 2011-07-31 13:02:56 --> Total execution time: 0.5222
DEBUG - 2011-07-31 13:02:58 --> Config Class Initialized
DEBUG - 2011-07-31 13:02:58 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:02:58 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:02:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:02:58 --> URI Class Initialized
DEBUG - 2011-07-31 13:02:58 --> Router Class Initialized
ERROR - 2011-07-31 13:02:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:03:17 --> Config Class Initialized
DEBUG - 2011-07-31 13:03:17 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:03:17 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:03:17 --> URI Class Initialized
DEBUG - 2011-07-31 13:03:17 --> Router Class Initialized
DEBUG - 2011-07-31 13:03:17 --> No URI present. Default controller set.
DEBUG - 2011-07-31 13:03:17 --> Output Class Initialized
DEBUG - 2011-07-31 13:03:17 --> Input Class Initialized
DEBUG - 2011-07-31 13:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:03:17 --> Language Class Initialized
DEBUG - 2011-07-31 13:03:17 --> Loader Class Initialized
DEBUG - 2011-07-31 13:03:17 --> Controller Class Initialized
DEBUG - 2011-07-31 13:03:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-31 13:03:17 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:03:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:03:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:03:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:03:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:03:17 --> Final output sent to browser
DEBUG - 2011-07-31 13:03:17 --> Total execution time: 0.0144
DEBUG - 2011-07-31 13:03:18 --> Config Class Initialized
DEBUG - 2011-07-31 13:03:18 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:03:18 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:03:18 --> URI Class Initialized
DEBUG - 2011-07-31 13:03:18 --> Router Class Initialized
ERROR - 2011-07-31 13:03:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:03:20 --> Config Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:03:20 --> URI Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Router Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Output Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Input Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:03:20 --> Language Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Loader Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Controller Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Model Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Model Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Model Class Initialized
DEBUG - 2011-07-31 13:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:03:20 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:03:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 13:03:20 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:03:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:03:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:03:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:03:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:03:20 --> Final output sent to browser
DEBUG - 2011-07-31 13:03:20 --> Total execution time: 0.2566
DEBUG - 2011-07-31 13:03:23 --> Config Class Initialized
DEBUG - 2011-07-31 13:03:23 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:03:23 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:03:23 --> URI Class Initialized
DEBUG - 2011-07-31 13:03:23 --> Router Class Initialized
ERROR - 2011-07-31 13:03:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:03:33 --> Config Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:03:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:03:33 --> URI Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Router Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Output Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Input Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:03:33 --> Language Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Loader Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Controller Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Model Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Model Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Model Class Initialized
DEBUG - 2011-07-31 13:03:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:03:33 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:03:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 13:03:33 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:03:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:03:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:03:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:03:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:03:33 --> Final output sent to browser
DEBUG - 2011-07-31 13:03:33 --> Total execution time: 0.0548
DEBUG - 2011-07-31 13:03:35 --> Config Class Initialized
DEBUG - 2011-07-31 13:03:35 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:03:35 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:03:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:03:35 --> URI Class Initialized
DEBUG - 2011-07-31 13:03:35 --> Router Class Initialized
ERROR - 2011-07-31 13:03:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:04:53 --> Config Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:04:53 --> URI Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Router Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Output Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Input Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:04:53 --> Language Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Loader Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Controller Class Initialized
ERROR - 2011-07-31 13:04:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:04:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:04:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:04:53 --> Model Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Model Class Initialized
DEBUG - 2011-07-31 13:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:04:53 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:04:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:04:53 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:04:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:04:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:04:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:04:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:04:53 --> Final output sent to browser
DEBUG - 2011-07-31 13:04:53 --> Total execution time: 0.0295
DEBUG - 2011-07-31 13:04:56 --> Config Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:04:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:04:56 --> URI Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Router Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Output Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Input Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:04:56 --> Language Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Loader Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Controller Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Model Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Model Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:04:56 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:04:56 --> Final output sent to browser
DEBUG - 2011-07-31 13:04:56 --> Total execution time: 0.5179
DEBUG - 2011-07-31 13:04:59 --> Config Class Initialized
DEBUG - 2011-07-31 13:04:59 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:04:59 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:04:59 --> URI Class Initialized
DEBUG - 2011-07-31 13:04:59 --> Router Class Initialized
ERROR - 2011-07-31 13:04:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:08:38 --> Config Class Initialized
DEBUG - 2011-07-31 13:08:38 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:08:38 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:08:38 --> URI Class Initialized
DEBUG - 2011-07-31 13:08:38 --> Router Class Initialized
DEBUG - 2011-07-31 13:08:38 --> No URI present. Default controller set.
DEBUG - 2011-07-31 13:08:38 --> Output Class Initialized
DEBUG - 2011-07-31 13:08:38 --> Input Class Initialized
DEBUG - 2011-07-31 13:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:08:38 --> Language Class Initialized
DEBUG - 2011-07-31 13:08:38 --> Loader Class Initialized
DEBUG - 2011-07-31 13:08:38 --> Controller Class Initialized
DEBUG - 2011-07-31 13:08:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-31 13:08:38 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:08:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:08:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:08:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:08:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:08:38 --> Final output sent to browser
DEBUG - 2011-07-31 13:08:38 --> Total execution time: 0.0120
DEBUG - 2011-07-31 13:08:40 --> Config Class Initialized
DEBUG - 2011-07-31 13:08:40 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:08:40 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:08:40 --> URI Class Initialized
DEBUG - 2011-07-31 13:08:40 --> Router Class Initialized
ERROR - 2011-07-31 13:08:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:34:32 --> Config Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:34:32 --> URI Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Router Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Output Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Input Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:34:32 --> Language Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Loader Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Controller Class Initialized
ERROR - 2011-07-31 13:34:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:34:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:34:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:34:32 --> Model Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Model Class Initialized
DEBUG - 2011-07-31 13:34:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:34:32 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:34:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:34:32 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:34:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:34:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:34:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:34:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:34:32 --> Final output sent to browser
DEBUG - 2011-07-31 13:34:32 --> Total execution time: 0.0326
DEBUG - 2011-07-31 13:34:34 --> Config Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:34:34 --> URI Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Router Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Output Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Input Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:34:34 --> Language Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Loader Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Controller Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Model Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Model Class Initialized
DEBUG - 2011-07-31 13:34:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:34:34 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:34:35 --> Final output sent to browser
DEBUG - 2011-07-31 13:34:35 --> Total execution time: 0.5932
DEBUG - 2011-07-31 13:35:33 --> Config Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:35:33 --> URI Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Router Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Output Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Input Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:35:33 --> Language Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Loader Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Controller Class Initialized
ERROR - 2011-07-31 13:35:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:35:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:35:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:35:33 --> Model Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Model Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:35:33 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:35:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:35:33 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:35:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:35:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:35:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:35:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:35:33 --> Final output sent to browser
DEBUG - 2011-07-31 13:35:33 --> Total execution time: 0.0630
DEBUG - 2011-07-31 13:35:33 --> Config Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:35:33 --> URI Class Initialized
DEBUG - 2011-07-31 13:35:33 --> Router Class Initialized
ERROR - 2011-07-31 13:35:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:35:34 --> Config Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:35:34 --> URI Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Router Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Output Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Input Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:35:34 --> Language Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Loader Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Controller Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Model Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Model Class Initialized
DEBUG - 2011-07-31 13:35:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:35:34 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:35:36 --> Final output sent to browser
DEBUG - 2011-07-31 13:35:36 --> Total execution time: 1.8812
DEBUG - 2011-07-31 13:36:09 --> Config Class Initialized
DEBUG - 2011-07-31 13:36:09 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:36:09 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:36:09 --> URI Class Initialized
DEBUG - 2011-07-31 13:36:09 --> Router Class Initialized
ERROR - 2011-07-31 13:36:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:42:11 --> Config Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:42:11 --> URI Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Router Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Output Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Input Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:42:11 --> Language Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Loader Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Controller Class Initialized
ERROR - 2011-07-31 13:42:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 13:42:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 13:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:42:11 --> Model Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Model Class Initialized
DEBUG - 2011-07-31 13:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:42:11 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 13:42:11 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:42:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:42:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:42:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:42:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:42:11 --> Final output sent to browser
DEBUG - 2011-07-31 13:42:11 --> Total execution time: 0.0351
DEBUG - 2011-07-31 13:42:14 --> Config Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:42:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:42:14 --> URI Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Router Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Output Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Input Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:42:14 --> Language Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Loader Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Controller Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Model Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Model Class Initialized
DEBUG - 2011-07-31 13:42:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:42:14 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:42:15 --> Final output sent to browser
DEBUG - 2011-07-31 13:42:15 --> Total execution time: 0.4732
DEBUG - 2011-07-31 13:42:19 --> Config Class Initialized
DEBUG - 2011-07-31 13:42:19 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:42:19 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:42:19 --> URI Class Initialized
DEBUG - 2011-07-31 13:42:19 --> Router Class Initialized
ERROR - 2011-07-31 13:42:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 13:47:48 --> Config Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 13:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 13:47:48 --> URI Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Router Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Output Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Input Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 13:47:48 --> Language Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Loader Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Controller Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Model Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Model Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Model Class Initialized
DEBUG - 2011-07-31 13:47:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 13:47:48 --> Database Driver Class Initialized
DEBUG - 2011-07-31 13:47:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 13:47:48 --> Helper loaded: url_helper
DEBUG - 2011-07-31 13:47:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 13:47:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 13:47:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 13:47:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 13:47:48 --> Final output sent to browser
DEBUG - 2011-07-31 13:47:48 --> Total execution time: 0.2104
DEBUG - 2011-07-31 14:46:42 --> Config Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:46:42 --> URI Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Router Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Output Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Input Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:46:42 --> Language Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Loader Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Controller Class Initialized
ERROR - 2011-07-31 14:46:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 14:46:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 14:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:46:42 --> Model Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Model Class Initialized
DEBUG - 2011-07-31 14:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:46:42 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:46:42 --> Helper loaded: url_helper
DEBUG - 2011-07-31 14:46:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 14:46:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 14:46:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 14:46:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 14:46:42 --> Final output sent to browser
DEBUG - 2011-07-31 14:46:42 --> Total execution time: 0.0666
DEBUG - 2011-07-31 14:46:46 --> Config Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:46:46 --> URI Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Router Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Output Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Input Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:46:46 --> Language Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Loader Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Controller Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Model Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Model Class Initialized
DEBUG - 2011-07-31 14:46:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:46:46 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:46:47 --> Final output sent to browser
DEBUG - 2011-07-31 14:46:47 --> Total execution time: 0.6797
DEBUG - 2011-07-31 14:46:49 --> Config Class Initialized
DEBUG - 2011-07-31 14:46:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:46:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:46:49 --> URI Class Initialized
DEBUG - 2011-07-31 14:46:49 --> Router Class Initialized
ERROR - 2011-07-31 14:46:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 14:47:10 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:10 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Router Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Output Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Input Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:47:10 --> Language Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Loader Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Controller Class Initialized
ERROR - 2011-07-31 14:47:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 14:47:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 14:47:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:47:10 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:47:10 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:47:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:47:10 --> Helper loaded: url_helper
DEBUG - 2011-07-31 14:47:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 14:47:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 14:47:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 14:47:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 14:47:10 --> Final output sent to browser
DEBUG - 2011-07-31 14:47:10 --> Total execution time: 0.0266
DEBUG - 2011-07-31 14:47:11 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:11 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Router Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Output Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Input Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:47:11 --> Language Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Loader Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Controller Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:47:11 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:47:12 --> Final output sent to browser
DEBUG - 2011-07-31 14:47:12 --> Total execution time: 0.5105
DEBUG - 2011-07-31 14:47:13 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:13 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:13 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:13 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:13 --> Router Class Initialized
ERROR - 2011-07-31 14:47:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 14:47:22 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:22 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Router Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Output Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Input Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:47:22 --> Language Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Loader Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Controller Class Initialized
ERROR - 2011-07-31 14:47:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 14:47:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 14:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:47:22 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:47:22 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:47:22 --> Helper loaded: url_helper
DEBUG - 2011-07-31 14:47:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 14:47:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 14:47:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 14:47:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 14:47:22 --> Final output sent to browser
DEBUG - 2011-07-31 14:47:22 --> Total execution time: 0.0261
DEBUG - 2011-07-31 14:47:23 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:23 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Router Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Output Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Input Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:47:23 --> Language Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Loader Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Controller Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:47:23 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:47:23 --> Final output sent to browser
DEBUG - 2011-07-31 14:47:23 --> Total execution time: 0.6516
DEBUG - 2011-07-31 14:47:25 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:25 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:25 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:25 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:25 --> Router Class Initialized
ERROR - 2011-07-31 14:47:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 14:47:54 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:54 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Router Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Output Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Input Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:47:54 --> Language Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Loader Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Controller Class Initialized
ERROR - 2011-07-31 14:47:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 14:47:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 14:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:47:54 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:47:54 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:47:54 --> Helper loaded: url_helper
DEBUG - 2011-07-31 14:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 14:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 14:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 14:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 14:47:54 --> Final output sent to browser
DEBUG - 2011-07-31 14:47:54 --> Total execution time: 0.0279
DEBUG - 2011-07-31 14:47:54 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:54 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Router Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Output Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Input Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:47:54 --> Language Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Loader Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Controller Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Model Class Initialized
DEBUG - 2011-07-31 14:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:47:54 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:47:55 --> Final output sent to browser
DEBUG - 2011-07-31 14:47:55 --> Total execution time: 0.5231
DEBUG - 2011-07-31 14:47:56 --> Config Class Initialized
DEBUG - 2011-07-31 14:47:56 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:47:56 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:47:56 --> URI Class Initialized
DEBUG - 2011-07-31 14:47:56 --> Router Class Initialized
ERROR - 2011-07-31 14:47:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 14:48:08 --> Config Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:48:08 --> URI Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Router Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Output Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Input Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:48:08 --> Language Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Loader Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Controller Class Initialized
ERROR - 2011-07-31 14:48:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 14:48:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 14:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:48:08 --> Model Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Model Class Initialized
DEBUG - 2011-07-31 14:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:48:08 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:48:08 --> Helper loaded: url_helper
DEBUG - 2011-07-31 14:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 14:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 14:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 14:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 14:48:08 --> Final output sent to browser
DEBUG - 2011-07-31 14:48:08 --> Total execution time: 0.0269
DEBUG - 2011-07-31 14:48:09 --> Config Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:48:09 --> URI Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Router Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Output Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Input Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:48:09 --> Language Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Loader Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Controller Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Model Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Model Class Initialized
DEBUG - 2011-07-31 14:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:48:09 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:48:10 --> Final output sent to browser
DEBUG - 2011-07-31 14:48:10 --> Total execution time: 0.6470
DEBUG - 2011-07-31 14:48:11 --> Config Class Initialized
DEBUG - 2011-07-31 14:48:11 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:48:11 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:48:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:48:11 --> URI Class Initialized
DEBUG - 2011-07-31 14:48:11 --> Router Class Initialized
ERROR - 2011-07-31 14:48:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 14:48:18 --> Config Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:48:18 --> URI Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Router Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Output Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Input Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:48:18 --> Language Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Loader Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Controller Class Initialized
ERROR - 2011-07-31 14:48:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 14:48:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 14:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:48:18 --> Model Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Model Class Initialized
DEBUG - 2011-07-31 14:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:48:18 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 14:48:18 --> Helper loaded: url_helper
DEBUG - 2011-07-31 14:48:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 14:48:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 14:48:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 14:48:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 14:48:18 --> Final output sent to browser
DEBUG - 2011-07-31 14:48:18 --> Total execution time: 0.0267
DEBUG - 2011-07-31 14:48:19 --> Config Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:48:19 --> URI Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Router Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Output Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Input Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 14:48:19 --> Language Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Loader Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Controller Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Model Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Model Class Initialized
DEBUG - 2011-07-31 14:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 14:48:19 --> Database Driver Class Initialized
DEBUG - 2011-07-31 14:48:20 --> Final output sent to browser
DEBUG - 2011-07-31 14:48:20 --> Total execution time: 0.6506
DEBUG - 2011-07-31 14:48:21 --> Config Class Initialized
DEBUG - 2011-07-31 14:48:21 --> Hooks Class Initialized
DEBUG - 2011-07-31 14:48:21 --> Utf8 Class Initialized
DEBUG - 2011-07-31 14:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 14:48:21 --> URI Class Initialized
DEBUG - 2011-07-31 14:48:21 --> Router Class Initialized
ERROR - 2011-07-31 14:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 15:40:39 --> Config Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Hooks Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Utf8 Class Initialized
DEBUG - 2011-07-31 15:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 15:40:39 --> URI Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Router Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Output Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Input Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 15:40:39 --> Language Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Loader Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Controller Class Initialized
ERROR - 2011-07-31 15:40:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 15:40:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 15:40:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 15:40:39 --> Model Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Model Class Initialized
DEBUG - 2011-07-31 15:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 15:40:39 --> Database Driver Class Initialized
DEBUG - 2011-07-31 15:40:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 15:40:39 --> Helper loaded: url_helper
DEBUG - 2011-07-31 15:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 15:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 15:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 15:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 15:40:39 --> Final output sent to browser
DEBUG - 2011-07-31 15:40:39 --> Total execution time: 0.0366
DEBUG - 2011-07-31 15:40:40 --> Config Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Hooks Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Utf8 Class Initialized
DEBUG - 2011-07-31 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 15:40:40 --> URI Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Router Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Output Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Input Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 15:40:40 --> Language Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Loader Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Controller Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Model Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Model Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 15:40:40 --> Database Driver Class Initialized
DEBUG - 2011-07-31 15:40:40 --> Final output sent to browser
DEBUG - 2011-07-31 15:40:40 --> Total execution time: 0.5278
DEBUG - 2011-07-31 15:40:41 --> Config Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Hooks Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Utf8 Class Initialized
DEBUG - 2011-07-31 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 15:40:41 --> URI Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Router Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Output Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Input Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 15:40:41 --> Language Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Loader Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Controller Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Model Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Model Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Model Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 15:40:41 --> Database Driver Class Initialized
DEBUG - 2011-07-31 15:40:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 15:40:41 --> Helper loaded: url_helper
DEBUG - 2011-07-31 15:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 15:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 15:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 15:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 15:40:41 --> Final output sent to browser
DEBUG - 2011-07-31 15:40:41 --> Total execution time: 0.4190
DEBUG - 2011-07-31 15:40:41 --> Config Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Hooks Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Utf8 Class Initialized
DEBUG - 2011-07-31 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 15:40:41 --> URI Class Initialized
DEBUG - 2011-07-31 15:40:41 --> Router Class Initialized
ERROR - 2011-07-31 15:40:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 15:41:57 --> Config Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Hooks Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Utf8 Class Initialized
DEBUG - 2011-07-31 15:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 15:41:57 --> URI Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Router Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Output Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Input Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 15:41:57 --> Language Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Loader Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Controller Class Initialized
ERROR - 2011-07-31 15:41:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 15:41:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 15:41:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 15:41:57 --> Model Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Model Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 15:41:57 --> Database Driver Class Initialized
DEBUG - 2011-07-31 15:41:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 15:41:57 --> Helper loaded: url_helper
DEBUG - 2011-07-31 15:41:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 15:41:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 15:41:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 15:41:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 15:41:57 --> Final output sent to browser
DEBUG - 2011-07-31 15:41:57 --> Total execution time: 0.0275
DEBUG - 2011-07-31 15:41:57 --> Config Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Hooks Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Utf8 Class Initialized
DEBUG - 2011-07-31 15:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 15:41:57 --> URI Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Router Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Output Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Input Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 15:41:57 --> Language Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Loader Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Controller Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Model Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Model Class Initialized
DEBUG - 2011-07-31 15:41:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 15:41:57 --> Database Driver Class Initialized
DEBUG - 2011-07-31 15:41:58 --> Final output sent to browser
DEBUG - 2011-07-31 15:41:58 --> Total execution time: 0.4997
DEBUG - 2011-07-31 16:34:05 --> Config Class Initialized
DEBUG - 2011-07-31 16:34:05 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:34:05 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:34:05 --> URI Class Initialized
DEBUG - 2011-07-31 16:34:05 --> Router Class Initialized
DEBUG - 2011-07-31 16:34:05 --> No URI present. Default controller set.
DEBUG - 2011-07-31 16:34:05 --> Output Class Initialized
DEBUG - 2011-07-31 16:34:05 --> Input Class Initialized
DEBUG - 2011-07-31 16:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 16:34:05 --> Language Class Initialized
DEBUG - 2011-07-31 16:34:05 --> Loader Class Initialized
DEBUG - 2011-07-31 16:34:05 --> Controller Class Initialized
DEBUG - 2011-07-31 16:34:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-31 16:34:05 --> Helper loaded: url_helper
DEBUG - 2011-07-31 16:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 16:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 16:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 16:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 16:34:05 --> Final output sent to browser
DEBUG - 2011-07-31 16:34:05 --> Total execution time: 0.0515
DEBUG - 2011-07-31 16:39:14 --> Config Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:39:14 --> URI Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Router Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Output Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Input Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 16:39:14 --> Language Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Config Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Loader Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Controller Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:39:14 --> URI Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Router Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Output Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Input Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 16:39:14 --> Language Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Loader Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Controller Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Model Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Model Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Model Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-07-31 16:39:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 16:39:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 16:39:14 --> Model Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Model Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 16:39:14 --> Database Driver Class Initialized
DEBUG - 2011-07-31 16:39:14 --> Database Driver Class Initialized
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 16:39:14 --> Helper loaded: url_helper
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 16:39:14 --> Final output sent to browser
DEBUG - 2011-07-31 16:39:14 --> Total execution time: 0.0733
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 16:39:14 --> Helper loaded: url_helper
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 16:39:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 16:39:14 --> Final output sent to browser
DEBUG - 2011-07-31 16:39:14 --> Total execution time: 0.2821
DEBUG - 2011-07-31 16:51:30 --> Config Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:51:30 --> URI Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Router Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Output Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Input Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 16:51:30 --> Language Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Loader Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Controller Class Initialized
ERROR - 2011-07-31 16:51:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 16:51:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 16:51:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 16:51:30 --> Model Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Model Class Initialized
DEBUG - 2011-07-31 16:51:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 16:51:30 --> Database Driver Class Initialized
DEBUG - 2011-07-31 16:51:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 16:51:30 --> Helper loaded: url_helper
DEBUG - 2011-07-31 16:51:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 16:51:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 16:51:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 16:51:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 16:51:30 --> Final output sent to browser
DEBUG - 2011-07-31 16:51:30 --> Total execution time: 0.0287
DEBUG - 2011-07-31 16:51:32 --> Config Class Initialized
DEBUG - 2011-07-31 16:51:32 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:51:32 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:51:32 --> URI Class Initialized
DEBUG - 2011-07-31 16:51:32 --> Router Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Output Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Input Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 16:51:33 --> Language Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Loader Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Controller Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Model Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Model Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 16:51:33 --> Database Driver Class Initialized
DEBUG - 2011-07-31 16:51:33 --> Final output sent to browser
DEBUG - 2011-07-31 16:51:33 --> Total execution time: 0.5755
DEBUG - 2011-07-31 16:51:37 --> Config Class Initialized
DEBUG - 2011-07-31 16:51:37 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:51:37 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:51:37 --> URI Class Initialized
DEBUG - 2011-07-31 16:51:37 --> Router Class Initialized
ERROR - 2011-07-31 16:51:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 16:51:57 --> Config Class Initialized
DEBUG - 2011-07-31 16:51:57 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:51:57 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:51:57 --> URI Class Initialized
DEBUG - 2011-07-31 16:51:57 --> Router Class Initialized
DEBUG - 2011-07-31 16:51:57 --> No URI present. Default controller set.
DEBUG - 2011-07-31 16:51:57 --> Output Class Initialized
DEBUG - 2011-07-31 16:51:57 --> Input Class Initialized
DEBUG - 2011-07-31 16:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 16:51:57 --> Language Class Initialized
DEBUG - 2011-07-31 16:51:57 --> Loader Class Initialized
DEBUG - 2011-07-31 16:51:57 --> Controller Class Initialized
DEBUG - 2011-07-31 16:51:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-31 16:51:57 --> Helper loaded: url_helper
DEBUG - 2011-07-31 16:51:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 16:51:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 16:51:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 16:51:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 16:51:57 --> Final output sent to browser
DEBUG - 2011-07-31 16:51:57 --> Total execution time: 0.0126
DEBUG - 2011-07-31 16:52:07 --> Config Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:52:07 --> URI Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Router Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Output Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Input Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 16:52:07 --> Language Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Loader Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Controller Class Initialized
ERROR - 2011-07-31 16:52:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 16:52:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 16:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 16:52:07 --> Model Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Model Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 16:52:07 --> Database Driver Class Initialized
DEBUG - 2011-07-31 16:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 16:52:07 --> Helper loaded: url_helper
DEBUG - 2011-07-31 16:52:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 16:52:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 16:52:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 16:52:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 16:52:07 --> Final output sent to browser
DEBUG - 2011-07-31 16:52:07 --> Total execution time: 0.0280
DEBUG - 2011-07-31 16:52:07 --> Config Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Hooks Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Utf8 Class Initialized
DEBUG - 2011-07-31 16:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 16:52:07 --> URI Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Router Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Output Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Input Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 16:52:07 --> Language Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Loader Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Controller Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Model Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Model Class Initialized
DEBUG - 2011-07-31 16:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 16:52:07 --> Database Driver Class Initialized
DEBUG - 2011-07-31 16:52:08 --> Final output sent to browser
DEBUG - 2011-07-31 16:52:08 --> Total execution time: 0.5064
DEBUG - 2011-07-31 17:42:54 --> Config Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Hooks Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Utf8 Class Initialized
DEBUG - 2011-07-31 17:42:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 17:42:54 --> URI Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Router Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Output Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Input Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 17:42:54 --> Language Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Loader Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Controller Class Initialized
ERROR - 2011-07-31 17:42:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 17:42:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 17:42:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 17:42:54 --> Model Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Model Class Initialized
DEBUG - 2011-07-31 17:42:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 17:42:54 --> Database Driver Class Initialized
DEBUG - 2011-07-31 17:42:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 17:42:54 --> Helper loaded: url_helper
DEBUG - 2011-07-31 17:42:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 17:42:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 17:42:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 17:42:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 17:42:54 --> Final output sent to browser
DEBUG - 2011-07-31 17:42:54 --> Total execution time: 0.1085
DEBUG - 2011-07-31 20:10:46 --> Config Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:10:46 --> URI Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Router Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Output Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Input Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:10:46 --> Language Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Loader Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Controller Class Initialized
ERROR - 2011-07-31 20:10:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 20:10:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 20:10:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 20:10:46 --> Model Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Model Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:10:46 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:10:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 20:10:46 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:10:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:10:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:10:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:10:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:10:46 --> Final output sent to browser
DEBUG - 2011-07-31 20:10:46 --> Total execution time: 0.3743
DEBUG - 2011-07-31 20:10:46 --> Config Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:10:46 --> URI Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Router Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Output Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Input Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:10:46 --> Language Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Loader Class Initialized
DEBUG - 2011-07-31 20:10:46 --> Controller Class Initialized
DEBUG - 2011-07-31 20:10:47 --> Model Class Initialized
DEBUG - 2011-07-31 20:10:47 --> Model Class Initialized
DEBUG - 2011-07-31 20:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:10:47 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:10:47 --> Final output sent to browser
DEBUG - 2011-07-31 20:10:47 --> Total execution time: 0.8041
DEBUG - 2011-07-31 20:10:48 --> Config Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:10:48 --> URI Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Router Class Initialized
ERROR - 2011-07-31 20:10:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 20:10:48 --> Config Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:10:48 --> URI Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Router Class Initialized
ERROR - 2011-07-31 20:10:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 20:10:48 --> Config Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:10:48 --> URI Class Initialized
DEBUG - 2011-07-31 20:10:48 --> Router Class Initialized
ERROR - 2011-07-31 20:10:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 20:10:54 --> Config Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:10:54 --> URI Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Router Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Output Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Input Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:10:54 --> Language Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Loader Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Controller Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Model Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Model Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Model Class Initialized
DEBUG - 2011-07-31 20:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:10:54 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:10:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:10:55 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:10:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:10:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:10:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:10:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:10:55 --> Final output sent to browser
DEBUG - 2011-07-31 20:10:55 --> Total execution time: 0.3108
DEBUG - 2011-07-31 20:11:00 --> Config Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:11:00 --> URI Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Router Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Output Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Input Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:11:00 --> Language Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Loader Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Controller Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:11:00 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:11:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:11:00 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:11:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:11:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:11:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:11:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:11:00 --> Final output sent to browser
DEBUG - 2011-07-31 20:11:00 --> Total execution time: 0.0429
DEBUG - 2011-07-31 20:11:12 --> Config Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:11:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:11:12 --> URI Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Router Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Output Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Input Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:11:12 --> Language Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Loader Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Controller Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:11:12 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:11:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:11:12 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:11:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:11:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:11:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:11:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:11:12 --> Final output sent to browser
DEBUG - 2011-07-31 20:11:12 --> Total execution time: 0.3184
DEBUG - 2011-07-31 20:11:27 --> Config Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:11:27 --> URI Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Router Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Output Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Input Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:11:27 --> Language Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Loader Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Controller Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:11:27 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:11:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:11:27 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:11:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:11:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:11:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:11:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:11:27 --> Final output sent to browser
DEBUG - 2011-07-31 20:11:27 --> Total execution time: 0.2728
DEBUG - 2011-07-31 20:11:37 --> Config Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:11:37 --> URI Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Router Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Output Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Input Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:11:37 --> Language Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Loader Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Controller Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:11:37 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:11:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:11:38 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:11:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:11:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:11:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:11:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:11:38 --> Final output sent to browser
DEBUG - 2011-07-31 20:11:38 --> Total execution time: 0.3038
DEBUG - 2011-07-31 20:11:49 --> Config Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:11:49 --> URI Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Router Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Output Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Input Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:11:49 --> Language Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Loader Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Controller Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:11:49 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:11:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:11:50 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:11:50 --> Final output sent to browser
DEBUG - 2011-07-31 20:11:50 --> Total execution time: 0.8392
DEBUG - 2011-07-31 20:11:59 --> Config Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:11:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:11:59 --> URI Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Router Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Output Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Input Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:11:59 --> Language Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Loader Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Controller Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Model Class Initialized
DEBUG - 2011-07-31 20:11:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:11:59 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:12:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:12:00 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:12:00 --> Final output sent to browser
DEBUG - 2011-07-31 20:12:00 --> Total execution time: 0.2966
DEBUG - 2011-07-31 20:12:11 --> Config Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:12:11 --> URI Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Router Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Output Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Input Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:12:11 --> Language Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Loader Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Controller Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:12:11 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:12:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:12:12 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:12:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:12:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:12:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:12:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:12:12 --> Final output sent to browser
DEBUG - 2011-07-31 20:12:12 --> Total execution time: 0.3886
DEBUG - 2011-07-31 20:12:23 --> Config Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:12:23 --> URI Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Router Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Output Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Input Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:12:23 --> Language Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Loader Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Controller Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:12:23 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:12:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:12:23 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:12:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:12:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:12:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:12:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:12:23 --> Final output sent to browser
DEBUG - 2011-07-31 20:12:23 --> Total execution time: 0.4708
DEBUG - 2011-07-31 20:12:31 --> Config Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:12:31 --> URI Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Router Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Output Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Input Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:12:31 --> Language Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Loader Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Controller Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:12:31 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:12:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:12:32 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:12:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:12:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:12:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:12:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:12:32 --> Final output sent to browser
DEBUG - 2011-07-31 20:12:32 --> Total execution time: 0.2943
DEBUG - 2011-07-31 20:12:39 --> Config Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:12:39 --> URI Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Router Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Output Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Input Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:12:39 --> Language Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Loader Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Controller Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:12:39 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:12:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:12:39 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:12:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:12:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:12:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:12:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:12:39 --> Final output sent to browser
DEBUG - 2011-07-31 20:12:39 --> Total execution time: 0.3433
DEBUG - 2011-07-31 20:12:48 --> Config Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:12:48 --> URI Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Router Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Output Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Input Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:12:48 --> Language Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Loader Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Controller Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:12:48 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:12:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:12:49 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:12:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:12:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:12:49 --> Final output sent to browser
DEBUG - 2011-07-31 20:12:49 --> Total execution time: 1.0074
DEBUG - 2011-07-31 20:12:57 --> Config Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:12:57 --> URI Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Router Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Output Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Input Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:12:57 --> Language Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Loader Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Controller Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Model Class Initialized
DEBUG - 2011-07-31 20:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:12:57 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:12:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:12:58 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:12:58 --> Final output sent to browser
DEBUG - 2011-07-31 20:12:58 --> Total execution time: 0.6368
DEBUG - 2011-07-31 20:13:16 --> Config Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:13:16 --> URI Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Router Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Output Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Input Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:13:16 --> Language Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Loader Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Controller Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:13:16 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:13:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:13:16 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:13:16 --> Final output sent to browser
DEBUG - 2011-07-31 20:13:16 --> Total execution time: 0.0963
DEBUG - 2011-07-31 20:13:21 --> Config Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:13:21 --> URI Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Router Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Output Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Input Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:13:21 --> Language Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Loader Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Controller Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:13:21 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:13:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:13:21 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:13:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:13:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:13:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:13:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:13:21 --> Final output sent to browser
DEBUG - 2011-07-31 20:13:21 --> Total execution time: 0.2314
DEBUG - 2011-07-31 20:13:31 --> Config Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:13:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:13:31 --> URI Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Router Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Output Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Input Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:13:31 --> Language Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Loader Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Controller Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:13:31 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:13:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:13:32 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:13:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:13:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:13:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:13:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:13:32 --> Final output sent to browser
DEBUG - 2011-07-31 20:13:32 --> Total execution time: 0.7143
DEBUG - 2011-07-31 20:13:40 --> Config Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:13:40 --> URI Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Router Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Output Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Input Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:13:40 --> Language Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Loader Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Controller Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:13:40 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:13:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:13:41 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:13:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:13:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:13:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:13:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:13:41 --> Final output sent to browser
DEBUG - 2011-07-31 20:13:41 --> Total execution time: 0.3501
DEBUG - 2011-07-31 20:13:49 --> Config Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:13:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:13:49 --> URI Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Router Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Output Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Input Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:13:49 --> Language Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Loader Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Controller Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:13:49 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:13:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:13:50 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:13:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:13:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:13:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:13:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:13:50 --> Final output sent to browser
DEBUG - 2011-07-31 20:13:50 --> Total execution time: 0.4609
DEBUG - 2011-07-31 20:13:59 --> Config Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:13:59 --> URI Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Router Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Output Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Input Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:13:59 --> Language Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Loader Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Controller Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Model Class Initialized
DEBUG - 2011-07-31 20:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:13:59 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:13:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:13:59 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:13:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:13:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:13:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:13:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:13:59 --> Final output sent to browser
DEBUG - 2011-07-31 20:13:59 --> Total execution time: 0.3223
DEBUG - 2011-07-31 20:14:08 --> Config Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:14:08 --> URI Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Router Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Output Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Input Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:14:08 --> Language Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Loader Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Controller Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Model Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Model Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Model Class Initialized
DEBUG - 2011-07-31 20:14:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:14:08 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:14:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:14:09 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:14:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:14:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:14:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:14:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:14:09 --> Final output sent to browser
DEBUG - 2011-07-31 20:14:09 --> Total execution time: 0.5783
DEBUG - 2011-07-31 20:14:24 --> Config Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Hooks Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Utf8 Class Initialized
DEBUG - 2011-07-31 20:14:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 20:14:24 --> URI Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Router Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Output Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Input Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 20:14:24 --> Language Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Loader Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Controller Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Model Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Model Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Model Class Initialized
DEBUG - 2011-07-31 20:14:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 20:14:24 --> Database Driver Class Initialized
DEBUG - 2011-07-31 20:14:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 20:14:24 --> Helper loaded: url_helper
DEBUG - 2011-07-31 20:14:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 20:14:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 20:14:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 20:14:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 20:14:24 --> Final output sent to browser
DEBUG - 2011-07-31 20:14:24 --> Total execution time: 0.0639
DEBUG - 2011-07-31 21:20:31 --> Config Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Hooks Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Utf8 Class Initialized
DEBUG - 2011-07-31 21:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 21:20:31 --> URI Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Router Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Output Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Input Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 21:20:31 --> Language Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Loader Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Controller Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Model Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Model Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Model Class Initialized
DEBUG - 2011-07-31 21:20:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 21:20:31 --> Database Driver Class Initialized
DEBUG - 2011-07-31 21:20:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-31 21:20:31 --> Helper loaded: url_helper
DEBUG - 2011-07-31 21:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 21:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 21:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 21:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 21:20:31 --> Final output sent to browser
DEBUG - 2011-07-31 21:20:31 --> Total execution time: 0.7455
DEBUG - 2011-07-31 21:20:33 --> Config Class Initialized
DEBUG - 2011-07-31 21:20:33 --> Hooks Class Initialized
DEBUG - 2011-07-31 21:20:33 --> Utf8 Class Initialized
DEBUG - 2011-07-31 21:20:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 21:20:33 --> URI Class Initialized
DEBUG - 2011-07-31 21:20:33 --> Router Class Initialized
ERROR - 2011-07-31 21:20:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 22:41:54 --> Config Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:41:54 --> URI Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Router Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Output Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Input Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 22:41:54 --> Language Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Loader Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Controller Class Initialized
ERROR - 2011-07-31 22:41:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 22:41:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 22:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 22:41:54 --> Model Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Model Class Initialized
DEBUG - 2011-07-31 22:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 22:41:54 --> Database Driver Class Initialized
DEBUG - 2011-07-31 22:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 22:41:54 --> Helper loaded: url_helper
DEBUG - 2011-07-31 22:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 22:41:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 22:41:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 22:41:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 22:41:54 --> Final output sent to browser
DEBUG - 2011-07-31 22:41:54 --> Total execution time: 0.0551
DEBUG - 2011-07-31 22:41:55 --> Config Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:41:55 --> URI Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Router Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Output Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Input Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 22:41:55 --> Language Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Loader Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Controller Class Initialized
DEBUG - 2011-07-31 22:41:55 --> Model Class Initialized
DEBUG - 2011-07-31 22:41:56 --> Model Class Initialized
DEBUG - 2011-07-31 22:41:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 22:41:56 --> Database Driver Class Initialized
DEBUG - 2011-07-31 22:41:56 --> Final output sent to browser
DEBUG - 2011-07-31 22:41:56 --> Total execution time: 0.5456
DEBUG - 2011-07-31 22:41:59 --> Config Class Initialized
DEBUG - 2011-07-31 22:41:59 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:41:59 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:41:59 --> URI Class Initialized
DEBUG - 2011-07-31 22:41:59 --> Router Class Initialized
ERROR - 2011-07-31 22:41:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 22:41:59 --> Config Class Initialized
DEBUG - 2011-07-31 22:41:59 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:41:59 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:41:59 --> URI Class Initialized
DEBUG - 2011-07-31 22:41:59 --> Router Class Initialized
ERROR - 2011-07-31 22:41:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-31 22:42:08 --> Config Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:42:08 --> URI Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Router Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Output Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Input Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 22:42:08 --> Language Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Loader Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Controller Class Initialized
ERROR - 2011-07-31 22:42:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 22:42:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 22:42:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 22:42:08 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 22:42:08 --> Database Driver Class Initialized
DEBUG - 2011-07-31 22:42:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 22:42:08 --> Helper loaded: url_helper
DEBUG - 2011-07-31 22:42:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 22:42:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 22:42:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 22:42:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 22:42:08 --> Final output sent to browser
DEBUG - 2011-07-31 22:42:08 --> Total execution time: 0.0535
DEBUG - 2011-07-31 22:42:09 --> Config Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:42:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:42:09 --> URI Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Router Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Output Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Input Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 22:42:09 --> Language Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Loader Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Controller Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 22:42:09 --> Database Driver Class Initialized
DEBUG - 2011-07-31 22:42:09 --> Final output sent to browser
DEBUG - 2011-07-31 22:42:09 --> Total execution time: 0.5065
DEBUG - 2011-07-31 22:42:16 --> Config Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:42:16 --> URI Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Router Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Output Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Input Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 22:42:16 --> Language Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Loader Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Controller Class Initialized
ERROR - 2011-07-31 22:42:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 22:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 22:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 22:42:16 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 22:42:16 --> Database Driver Class Initialized
DEBUG - 2011-07-31 22:42:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 22:42:17 --> Helper loaded: url_helper
DEBUG - 2011-07-31 22:42:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 22:42:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 22:42:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 22:42:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 22:42:17 --> Final output sent to browser
DEBUG - 2011-07-31 22:42:17 --> Total execution time: 0.4061
DEBUG - 2011-07-31 22:42:18 --> Config Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:42:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:42:18 --> URI Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Router Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Output Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Input Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 22:42:18 --> Language Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Loader Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Controller Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 22:42:18 --> Database Driver Class Initialized
DEBUG - 2011-07-31 22:42:19 --> Final output sent to browser
DEBUG - 2011-07-31 22:42:19 --> Total execution time: 0.5812
DEBUG - 2011-07-31 22:42:49 --> Config Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:42:49 --> URI Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Router Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Output Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Input Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 22:42:49 --> Language Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Loader Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Controller Class Initialized
ERROR - 2011-07-31 22:42:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-31 22:42:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-31 22:42:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 22:42:49 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 22:42:49 --> Database Driver Class Initialized
DEBUG - 2011-07-31 22:42:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-31 22:42:49 --> Helper loaded: url_helper
DEBUG - 2011-07-31 22:42:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 22:42:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 22:42:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 22:42:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 22:42:49 --> Final output sent to browser
DEBUG - 2011-07-31 22:42:49 --> Total execution time: 0.0318
DEBUG - 2011-07-31 22:42:49 --> Config Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Hooks Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Utf8 Class Initialized
DEBUG - 2011-07-31 22:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 22:42:49 --> URI Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Router Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Output Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Input Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 22:42:49 --> Language Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Loader Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Controller Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Model Class Initialized
DEBUG - 2011-07-31 22:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-31 22:42:49 --> Database Driver Class Initialized
DEBUG - 2011-07-31 22:42:50 --> Final output sent to browser
DEBUG - 2011-07-31 22:42:50 --> Total execution time: 0.5303
DEBUG - 2011-07-31 23:48:32 --> Config Class Initialized
DEBUG - 2011-07-31 23:48:32 --> Hooks Class Initialized
DEBUG - 2011-07-31 23:48:32 --> Utf8 Class Initialized
DEBUG - 2011-07-31 23:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-31 23:48:32 --> URI Class Initialized
DEBUG - 2011-07-31 23:48:32 --> Router Class Initialized
DEBUG - 2011-07-31 23:48:32 --> No URI present. Default controller set.
DEBUG - 2011-07-31 23:48:32 --> Output Class Initialized
DEBUG - 2011-07-31 23:48:32 --> Input Class Initialized
DEBUG - 2011-07-31 23:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-31 23:48:32 --> Language Class Initialized
DEBUG - 2011-07-31 23:48:32 --> Loader Class Initialized
DEBUG - 2011-07-31 23:48:32 --> Controller Class Initialized
DEBUG - 2011-07-31 23:48:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-31 23:48:32 --> Helper loaded: url_helper
DEBUG - 2011-07-31 23:48:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-31 23:48:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-31 23:48:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-31 23:48:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-31 23:48:32 --> Final output sent to browser
DEBUG - 2011-07-31 23:48:32 --> Total execution time: 0.0784

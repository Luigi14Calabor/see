<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-27 01:10:21 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:21 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Router Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Output Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Input Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:10:21 --> Language Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Loader Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Controller Class Initialized
ERROR - 2011-08-27 01:10:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 01:10:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 01:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 01:10:21 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:10:21 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 01:10:21 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:10:21 --> Final output sent to browser
DEBUG - 2011-08-27 01:10:21 --> Total execution time: 0.3620
DEBUG - 2011-08-27 01:10:24 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:24 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Router Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Output Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Input Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:10:24 --> Language Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Loader Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Controller Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:10:24 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:10:25 --> Final output sent to browser
DEBUG - 2011-08-27 01:10:25 --> Total execution time: 0.5410
DEBUG - 2011-08-27 01:10:28 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:28 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:28 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:28 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:28 --> Router Class Initialized
ERROR - 2011-08-27 01:10:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 01:10:29 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:29 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:29 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:29 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:29 --> Router Class Initialized
ERROR - 2011-08-27 01:10:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 01:10:32 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:32 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Router Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Output Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Input Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:10:32 --> Language Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Loader Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Controller Class Initialized
ERROR - 2011-08-27 01:10:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 01:10:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 01:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 01:10:32 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:10:32 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 01:10:32 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:10:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:10:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:10:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:10:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:10:32 --> Final output sent to browser
DEBUG - 2011-08-27 01:10:32 --> Total execution time: 0.0283
DEBUG - 2011-08-27 01:10:32 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:32 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Router Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Output Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Input Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:10:32 --> Language Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Loader Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Controller Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:10:33 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:10:33 --> Final output sent to browser
DEBUG - 2011-08-27 01:10:33 --> Total execution time: 0.6453
DEBUG - 2011-08-27 01:10:36 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:36 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:36 --> Router Class Initialized
ERROR - 2011-08-27 01:10:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 01:10:53 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:53 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Router Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Output Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Input Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:10:53 --> Language Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Loader Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Controller Class Initialized
ERROR - 2011-08-27 01:10:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 01:10:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 01:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 01:10:53 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:10:53 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 01:10:53 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:10:53 --> Final output sent to browser
DEBUG - 2011-08-27 01:10:53 --> Total execution time: 0.0279
DEBUG - 2011-08-27 01:10:54 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:54 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Router Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Output Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Input Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:10:54 --> Language Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Loader Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Controller Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Model Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:10:54 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:10:54 --> Final output sent to browser
DEBUG - 2011-08-27 01:10:54 --> Total execution time: 0.5414
DEBUG - 2011-08-27 01:10:57 --> Config Class Initialized
DEBUG - 2011-08-27 01:10:57 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:10:57 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:10:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:10:57 --> URI Class Initialized
DEBUG - 2011-08-27 01:10:57 --> Router Class Initialized
ERROR - 2011-08-27 01:10:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 01:20:16 --> Config Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:20:16 --> URI Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Router Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Output Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Input Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:20:16 --> Language Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Loader Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Controller Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Model Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Model Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Model Class Initialized
DEBUG - 2011-08-27 01:20:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:20:16 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:20:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:20:16 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:20:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:20:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:20:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:20:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:20:16 --> Final output sent to browser
DEBUG - 2011-08-27 01:20:16 --> Total execution time: 0.3108
DEBUG - 2011-08-27 01:20:20 --> Config Class Initialized
DEBUG - 2011-08-27 01:20:20 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:20:20 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:20:20 --> URI Class Initialized
DEBUG - 2011-08-27 01:20:20 --> Router Class Initialized
ERROR - 2011-08-27 01:20:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 01:21:00 --> Config Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:21:00 --> URI Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Router Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Output Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Input Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:21:00 --> Language Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Loader Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Controller Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:21:00 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:21:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:21:00 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:21:00 --> Final output sent to browser
DEBUG - 2011-08-27 01:21:00 --> Total execution time: 0.2480
DEBUG - 2011-08-27 01:21:06 --> Config Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:21:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:21:06 --> URI Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Router Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Output Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Input Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:21:06 --> Language Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Loader Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Controller Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:21:06 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:21:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:21:06 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:21:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:21:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:21:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:21:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:21:06 --> Final output sent to browser
DEBUG - 2011-08-27 01:21:06 --> Total execution time: 0.0422
DEBUG - 2011-08-27 01:21:12 --> Config Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:21:12 --> URI Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Router Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Output Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Input Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:21:12 --> Language Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Loader Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Controller Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:21:12 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:21:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:21:13 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:21:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:21:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:21:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:21:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:21:13 --> Final output sent to browser
DEBUG - 2011-08-27 01:21:13 --> Total execution time: 0.8645
DEBUG - 2011-08-27 01:21:14 --> Config Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:21:14 --> URI Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Router Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Output Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Input Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:21:14 --> Language Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Loader Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Controller Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:21:14 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:21:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:21:14 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:21:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:21:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:21:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:21:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:21:14 --> Final output sent to browser
DEBUG - 2011-08-27 01:21:14 --> Total execution time: 0.0456
DEBUG - 2011-08-27 01:21:26 --> Config Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:21:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:21:26 --> URI Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Router Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Output Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Input Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:21:26 --> Language Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Loader Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Controller Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:21:26 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:21:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:21:26 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:21:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:21:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:21:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:21:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:21:26 --> Final output sent to browser
DEBUG - 2011-08-27 01:21:26 --> Total execution time: 0.1913
DEBUG - 2011-08-27 01:21:27 --> Config Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:21:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:21:27 --> URI Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Router Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Output Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Input Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:21:27 --> Language Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Loader Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Controller Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:21:27 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:21:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:21:28 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:21:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:21:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:21:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:21:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:21:28 --> Final output sent to browser
DEBUG - 2011-08-27 01:21:28 --> Total execution time: 0.4534
DEBUG - 2011-08-27 01:21:58 --> Config Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:21:58 --> URI Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Router Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Output Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Input Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:21:58 --> Language Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Loader Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Controller Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Model Class Initialized
DEBUG - 2011-08-27 01:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:21:58 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:21:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:21:58 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:21:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:21:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:21:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:21:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:21:58 --> Final output sent to browser
DEBUG - 2011-08-27 01:21:58 --> Total execution time: 0.2444
DEBUG - 2011-08-27 01:22:00 --> Config Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:22:00 --> URI Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Router Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Output Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Input Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:22:00 --> Language Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Loader Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Controller Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:22:00 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:22:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:22:00 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:22:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:22:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:22:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:22:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:22:00 --> Final output sent to browser
DEBUG - 2011-08-27 01:22:00 --> Total execution time: 0.0538
DEBUG - 2011-08-27 01:22:20 --> Config Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:22:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:22:20 --> URI Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Router Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Output Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Input Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:22:20 --> Language Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Loader Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Controller Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:22:20 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:22:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:22:20 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:22:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:22:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:22:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:22:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:22:20 --> Final output sent to browser
DEBUG - 2011-08-27 01:22:20 --> Total execution time: 0.1819
DEBUG - 2011-08-27 01:22:22 --> Config Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:22:22 --> URI Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Router Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Output Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Input Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:22:22 --> Language Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Loader Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Controller Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:22:22 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:22:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:22:22 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:22:22 --> Final output sent to browser
DEBUG - 2011-08-27 01:22:22 --> Total execution time: 0.0451
DEBUG - 2011-08-27 01:22:34 --> Config Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:22:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:22:34 --> URI Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Router Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Output Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Input Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:22:34 --> Language Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Loader Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Controller Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:22:34 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:22:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:22:38 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:22:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:22:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:22:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:22:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:22:38 --> Final output sent to browser
DEBUG - 2011-08-27 01:22:38 --> Total execution time: 3.9656
DEBUG - 2011-08-27 01:22:39 --> Config Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Hooks Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Utf8 Class Initialized
DEBUG - 2011-08-27 01:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 01:22:39 --> URI Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Router Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Output Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Input Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 01:22:39 --> Language Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Loader Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Controller Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Model Class Initialized
DEBUG - 2011-08-27 01:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 01:22:39 --> Database Driver Class Initialized
DEBUG - 2011-08-27 01:22:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 01:22:39 --> Helper loaded: url_helper
DEBUG - 2011-08-27 01:22:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 01:22:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 01:22:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 01:22:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 01:22:39 --> Final output sent to browser
DEBUG - 2011-08-27 01:22:39 --> Total execution time: 0.0447
DEBUG - 2011-08-27 02:01:31 --> Config Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:01:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:01:31 --> URI Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Router Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Output Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Input Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:01:31 --> Language Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Loader Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Controller Class Initialized
ERROR - 2011-08-27 02:01:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 02:01:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 02:01:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 02:01:31 --> Model Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Model Class Initialized
DEBUG - 2011-08-27 02:01:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:01:31 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:01:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 02:01:31 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:01:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:01:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:01:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:01:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:01:32 --> Final output sent to browser
DEBUG - 2011-08-27 02:01:32 --> Total execution time: 0.4158
DEBUG - 2011-08-27 02:01:32 --> Config Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:01:32 --> URI Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Router Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Output Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Input Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:01:32 --> Language Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Loader Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Controller Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Model Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Model Class Initialized
DEBUG - 2011-08-27 02:01:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:01:32 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:01:34 --> Final output sent to browser
DEBUG - 2011-08-27 02:01:34 --> Total execution time: 1.6885
DEBUG - 2011-08-27 02:04:38 --> Config Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:04:38 --> URI Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Router Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Output Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Input Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:04:38 --> Language Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Loader Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Controller Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Model Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Model Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Model Class Initialized
DEBUG - 2011-08-27 02:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:04:38 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:04:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:04:38 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:04:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:04:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:04:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:04:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:04:38 --> Final output sent to browser
DEBUG - 2011-08-27 02:04:38 --> Total execution time: 0.8349
DEBUG - 2011-08-27 02:04:46 --> Config Class Initialized
DEBUG - 2011-08-27 02:04:46 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:04:46 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:04:46 --> URI Class Initialized
DEBUG - 2011-08-27 02:04:46 --> Router Class Initialized
ERROR - 2011-08-27 02:04:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 02:04:49 --> Config Class Initialized
DEBUG - 2011-08-27 02:04:49 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:04:49 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:04:49 --> URI Class Initialized
DEBUG - 2011-08-27 02:04:49 --> Router Class Initialized
ERROR - 2011-08-27 02:04:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 02:04:58 --> Config Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:04:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:04:58 --> URI Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Router Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Output Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Input Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:04:58 --> Language Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Loader Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Controller Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Model Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Model Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Model Class Initialized
DEBUG - 2011-08-27 02:04:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:04:58 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:00 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:00 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:00 --> Total execution time: 1.5655
DEBUG - 2011-08-27 02:05:09 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:09 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Router Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Output Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Input Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:05:09 --> Language Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Loader Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Controller Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:05:09 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:10 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:10 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:10 --> Total execution time: 0.5440
DEBUG - 2011-08-27 02:05:13 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:13 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Router Class Initialized
ERROR - 2011-08-27 02:05:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-27 02:05:13 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:13 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Router Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Output Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Input Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:05:13 --> Language Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Loader Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Controller Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:05:13 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:13 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:13 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:13 --> Total execution time: 0.1018
DEBUG - 2011-08-27 02:05:24 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:24 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Router Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Output Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Input Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:05:24 --> Language Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Loader Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Controller Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:05:24 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:25 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:25 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:25 --> Total execution time: 0.4952
DEBUG - 2011-08-27 02:05:28 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:28 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Router Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Output Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Input Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:05:28 --> Language Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Loader Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Controller Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:05:28 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:28 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:28 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:28 --> Total execution time: 0.0461
DEBUG - 2011-08-27 02:05:37 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:37 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Router Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Output Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Input Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:05:37 --> Language Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Loader Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Controller Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:05:37 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:38 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:38 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:38 --> Total execution time: 0.7070
DEBUG - 2011-08-27 02:05:39 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:39 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Router Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Output Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Input Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:05:39 --> Language Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Loader Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Controller Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:05:39 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:39 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:39 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:39 --> Total execution time: 0.0464
DEBUG - 2011-08-27 02:05:50 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:50 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Router Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Output Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Input Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:05:50 --> Language Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Loader Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Controller Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:05:50 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:51 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:51 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:51 --> Total execution time: 0.5210
DEBUG - 2011-08-27 02:05:52 --> Config Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:05:52 --> URI Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Router Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Output Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Input Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:05:52 --> Language Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Loader Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Controller Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Model Class Initialized
DEBUG - 2011-08-27 02:05:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:05:52 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:05:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:05:52 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:05:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:05:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:05:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:05:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:05:52 --> Final output sent to browser
DEBUG - 2011-08-27 02:05:52 --> Total execution time: 0.1537
DEBUG - 2011-08-27 02:06:05 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:05 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:05 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:05 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:10 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:10 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:10 --> Total execution time: 4.7433
DEBUG - 2011-08-27 02:06:11 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:11 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:11 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:11 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:11 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:11 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:11 --> Total execution time: 0.0638
DEBUG - 2011-08-27 02:06:19 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:19 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:19 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:19 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:19 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:19 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:19 --> Total execution time: 0.7066
DEBUG - 2011-08-27 02:06:20 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:20 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:20 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:20 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:20 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:20 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:20 --> Total execution time: 0.1510
DEBUG - 2011-08-27 02:06:27 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:27 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:27 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:27 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:27 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:27 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:27 --> Total execution time: 0.6476
DEBUG - 2011-08-27 02:06:29 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:29 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:29 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:29 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:29 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:29 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:29 --> Total execution time: 0.0543
DEBUG - 2011-08-27 02:06:34 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:34 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:34 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:34 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:35 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:35 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:35 --> Total execution time: 0.7065
DEBUG - 2011-08-27 02:06:36 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:36 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:36 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:36 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:36 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:36 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:36 --> Total execution time: 0.0565
DEBUG - 2011-08-27 02:06:43 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:43 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:43 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:43 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:44 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:44 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:44 --> Total execution time: 0.4525
DEBUG - 2011-08-27 02:06:47 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:47 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:47 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:47 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:47 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:47 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:47 --> Total execution time: 0.1008
DEBUG - 2011-08-27 02:06:51 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:51 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:51 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:51 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:52 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:52 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:52 --> Total execution time: 0.3055
DEBUG - 2011-08-27 02:06:53 --> Config Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:06:53 --> URI Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Router Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Output Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Input Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:06:53 --> Language Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Loader Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Controller Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Model Class Initialized
DEBUG - 2011-08-27 02:06:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:06:53 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:06:54 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:06:54 --> Final output sent to browser
DEBUG - 2011-08-27 02:06:54 --> Total execution time: 0.0500
DEBUG - 2011-08-27 02:14:38 --> Config Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:14:38 --> URI Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Router Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Output Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Input Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:14:38 --> Language Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Loader Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Controller Class Initialized
ERROR - 2011-08-27 02:14:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 02:14:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 02:14:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 02:14:38 --> Model Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Model Class Initialized
DEBUG - 2011-08-27 02:14:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:14:38 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:14:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 02:14:38 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:14:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:14:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:14:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:14:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:14:38 --> Final output sent to browser
DEBUG - 2011-08-27 02:14:38 --> Total execution time: 0.0403
DEBUG - 2011-08-27 02:14:39 --> Config Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:14:39 --> URI Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Router Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Output Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Input Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:14:39 --> Language Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Loader Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Controller Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Model Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Model Class Initialized
DEBUG - 2011-08-27 02:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:14:39 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:14:40 --> Final output sent to browser
DEBUG - 2011-08-27 02:14:40 --> Total execution time: 0.5489
DEBUG - 2011-08-27 02:14:44 --> Config Class Initialized
DEBUG - 2011-08-27 02:14:44 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:14:44 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:14:44 --> URI Class Initialized
DEBUG - 2011-08-27 02:14:44 --> Router Class Initialized
ERROR - 2011-08-27 02:14:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 02:14:45 --> Config Class Initialized
DEBUG - 2011-08-27 02:14:45 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:14:45 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:14:45 --> URI Class Initialized
DEBUG - 2011-08-27 02:14:45 --> Router Class Initialized
ERROR - 2011-08-27 02:14:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 02:14:45 --> Config Class Initialized
DEBUG - 2011-08-27 02:14:45 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:14:45 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:14:45 --> URI Class Initialized
DEBUG - 2011-08-27 02:14:45 --> Router Class Initialized
ERROR - 2011-08-27 02:14:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 02:27:45 --> Config Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:27:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:27:45 --> URI Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Router Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Output Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Input Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:27:45 --> Language Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Loader Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Controller Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Model Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Model Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Model Class Initialized
DEBUG - 2011-08-27 02:27:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:27:45 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:27:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 02:27:45 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:27:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:27:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:27:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:27:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:27:45 --> Final output sent to browser
DEBUG - 2011-08-27 02:27:45 --> Total execution time: 0.1599
DEBUG - 2011-08-27 02:27:46 --> Config Class Initialized
DEBUG - 2011-08-27 02:27:46 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:27:46 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:27:46 --> URI Class Initialized
DEBUG - 2011-08-27 02:27:46 --> Router Class Initialized
ERROR - 2011-08-27 02:27:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 02:27:54 --> Config Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:27:54 --> URI Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Router Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Output Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Input Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:27:54 --> Language Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Loader Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Controller Class Initialized
ERROR - 2011-08-27 02:27:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 02:27:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 02:27:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 02:27:54 --> Model Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Model Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:27:54 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:27:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 02:27:54 --> Helper loaded: url_helper
DEBUG - 2011-08-27 02:27:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 02:27:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 02:27:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 02:27:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 02:27:54 --> Final output sent to browser
DEBUG - 2011-08-27 02:27:54 --> Total execution time: 0.0293
DEBUG - 2011-08-27 02:27:54 --> Config Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:27:54 --> URI Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Router Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Output Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Input Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 02:27:54 --> Language Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Loader Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Controller Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Model Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Model Class Initialized
DEBUG - 2011-08-27 02:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 02:27:54 --> Database Driver Class Initialized
DEBUG - 2011-08-27 02:27:55 --> Final output sent to browser
DEBUG - 2011-08-27 02:27:55 --> Total execution time: 0.5485
DEBUG - 2011-08-27 02:27:55 --> Config Class Initialized
DEBUG - 2011-08-27 02:27:55 --> Hooks Class Initialized
DEBUG - 2011-08-27 02:27:55 --> Utf8 Class Initialized
DEBUG - 2011-08-27 02:27:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 02:27:55 --> URI Class Initialized
DEBUG - 2011-08-27 02:27:55 --> Router Class Initialized
ERROR - 2011-08-27 02:27:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 03:14:49 --> Config Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:14:49 --> URI Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Router Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Output Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Input Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:14:49 --> Language Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Loader Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Controller Class Initialized
ERROR - 2011-08-27 03:14:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 03:14:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 03:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:14:49 --> Model Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Model Class Initialized
DEBUG - 2011-08-27 03:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:14:49 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:14:50 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:14:50 --> Final output sent to browser
DEBUG - 2011-08-27 03:14:50 --> Total execution time: 0.7764
DEBUG - 2011-08-27 03:14:51 --> Config Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:14:51 --> URI Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Router Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Output Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Input Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:14:51 --> Language Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Loader Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Controller Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Model Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Model Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Model Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:14:51 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Config Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:14:51 --> URI Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Router Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Output Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Input Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:14:51 --> Language Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Loader Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Controller Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Model Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Model Class Initialized
DEBUG - 2011-08-27 03:14:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:14:51 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:14:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 03:14:52 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:14:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:14:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:14:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:14:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:14:52 --> Final output sent to browser
DEBUG - 2011-08-27 03:14:52 --> Total execution time: 1.4901
DEBUG - 2011-08-27 03:14:53 --> Final output sent to browser
DEBUG - 2011-08-27 03:14:53 --> Total execution time: 1.1686
DEBUG - 2011-08-27 03:14:54 --> Config Class Initialized
DEBUG - 2011-08-27 03:14:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:14:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:14:54 --> URI Class Initialized
DEBUG - 2011-08-27 03:14:54 --> Router Class Initialized
ERROR - 2011-08-27 03:14:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 03:14:54 --> Config Class Initialized
DEBUG - 2011-08-27 03:14:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:14:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:14:54 --> URI Class Initialized
DEBUG - 2011-08-27 03:14:54 --> Router Class Initialized
ERROR - 2011-08-27 03:14:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 03:15:19 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:19 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Router Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Output Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Input Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:15:19 --> Language Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Loader Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Controller Class Initialized
ERROR - 2011-08-27 03:15:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 03:15:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 03:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:15:19 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:15:19 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:15:19 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:15:19 --> Final output sent to browser
DEBUG - 2011-08-27 03:15:19 --> Total execution time: 0.0271
DEBUG - 2011-08-27 03:15:19 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:19 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Router Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Output Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Input Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:15:19 --> Language Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Loader Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Controller Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:15:19 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:15:24 --> Final output sent to browser
DEBUG - 2011-08-27 03:15:24 --> Total execution time: 4.4066
DEBUG - 2011-08-27 03:15:25 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:25 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:25 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:25 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:25 --> Router Class Initialized
ERROR - 2011-08-27 03:15:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 03:15:31 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:31 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Router Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Output Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Input Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:15:31 --> Language Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Loader Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Controller Class Initialized
ERROR - 2011-08-27 03:15:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 03:15:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 03:15:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:15:31 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:15:31 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:15:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:15:31 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:15:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:15:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:15:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:15:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:15:31 --> Final output sent to browser
DEBUG - 2011-08-27 03:15:31 --> Total execution time: 0.1096
DEBUG - 2011-08-27 03:15:32 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:32 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Router Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Output Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Input Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:15:32 --> Language Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Loader Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Controller Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:15:32 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:15:33 --> Final output sent to browser
DEBUG - 2011-08-27 03:15:33 --> Total execution time: 1.1913
DEBUG - 2011-08-27 03:15:35 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:35 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:35 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:35 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:35 --> Router Class Initialized
ERROR - 2011-08-27 03:15:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 03:15:43 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:43 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Router Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Output Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Input Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:15:43 --> Language Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Loader Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Controller Class Initialized
ERROR - 2011-08-27 03:15:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 03:15:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 03:15:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:15:43 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:15:43 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:15:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:15:43 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:15:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:15:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:15:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:15:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:15:43 --> Final output sent to browser
DEBUG - 2011-08-27 03:15:43 --> Total execution time: 0.0600
DEBUG - 2011-08-27 03:15:44 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:44 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Router Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Output Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Input Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:15:44 --> Language Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Loader Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Controller Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:15:44 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:15:45 --> Final output sent to browser
DEBUG - 2011-08-27 03:15:45 --> Total execution time: 0.8177
DEBUG - 2011-08-27 03:15:46 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:46 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:46 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:46 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:46 --> Router Class Initialized
ERROR - 2011-08-27 03:15:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 03:15:56 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:56 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Router Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Output Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Input Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:15:56 --> Language Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Loader Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Controller Class Initialized
ERROR - 2011-08-27 03:15:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 03:15:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 03:15:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:15:56 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:15:56 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:15:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 03:15:56 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:15:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:15:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:15:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:15:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:15:56 --> Final output sent to browser
DEBUG - 2011-08-27 03:15:56 --> Total execution time: 0.0537
DEBUG - 2011-08-27 03:15:57 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:57 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Router Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Output Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Input Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:15:57 --> Language Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Loader Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Controller Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Model Class Initialized
DEBUG - 2011-08-27 03:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:15:57 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:15:58 --> Final output sent to browser
DEBUG - 2011-08-27 03:15:58 --> Total execution time: 0.5707
DEBUG - 2011-08-27 03:15:59 --> Config Class Initialized
DEBUG - 2011-08-27 03:15:59 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:15:59 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:15:59 --> URI Class Initialized
DEBUG - 2011-08-27 03:15:59 --> Router Class Initialized
ERROR - 2011-08-27 03:15:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 03:16:13 --> Config Class Initialized
DEBUG - 2011-08-27 03:16:13 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:16:13 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:16:13 --> URI Class Initialized
DEBUG - 2011-08-27 03:16:13 --> Router Class Initialized
DEBUG - 2011-08-27 03:16:13 --> No URI present. Default controller set.
DEBUG - 2011-08-27 03:16:13 --> Output Class Initialized
DEBUG - 2011-08-27 03:16:13 --> Input Class Initialized
DEBUG - 2011-08-27 03:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:16:13 --> Language Class Initialized
DEBUG - 2011-08-27 03:16:13 --> Loader Class Initialized
DEBUG - 2011-08-27 03:16:13 --> Controller Class Initialized
DEBUG - 2011-08-27 03:16:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-27 03:16:13 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:16:13 --> Final output sent to browser
DEBUG - 2011-08-27 03:16:13 --> Total execution time: 0.2731
DEBUG - 2011-08-27 03:16:15 --> Config Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:16:15 --> URI Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Router Class Initialized
ERROR - 2011-08-27 03:16:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 03:16:15 --> Config Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:16:15 --> URI Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Router Class Initialized
DEBUG - 2011-08-27 03:16:15 --> No URI present. Default controller set.
DEBUG - 2011-08-27 03:16:15 --> Output Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Input Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:16:15 --> Language Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Loader Class Initialized
DEBUG - 2011-08-27 03:16:15 --> Controller Class Initialized
DEBUG - 2011-08-27 03:16:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-27 03:16:15 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:16:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:16:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:16:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:16:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:16:15 --> Final output sent to browser
DEBUG - 2011-08-27 03:16:15 --> Total execution time: 0.0596
DEBUG - 2011-08-27 03:16:18 --> Config Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:16:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:16:18 --> URI Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Router Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Output Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Input Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 03:16:18 --> Language Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Loader Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Controller Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Model Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Model Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Model Class Initialized
DEBUG - 2011-08-27 03:16:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 03:16:18 --> Database Driver Class Initialized
DEBUG - 2011-08-27 03:16:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 03:16:18 --> Helper loaded: url_helper
DEBUG - 2011-08-27 03:16:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 03:16:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 03:16:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 03:16:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 03:16:18 --> Final output sent to browser
DEBUG - 2011-08-27 03:16:18 --> Total execution time: 0.0611
DEBUG - 2011-08-27 03:16:19 --> Config Class Initialized
DEBUG - 2011-08-27 03:16:19 --> Hooks Class Initialized
DEBUG - 2011-08-27 03:16:19 --> Utf8 Class Initialized
DEBUG - 2011-08-27 03:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 03:16:19 --> URI Class Initialized
DEBUG - 2011-08-27 03:16:19 --> Router Class Initialized
ERROR - 2011-08-27 03:16:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 04:18:26 --> Config Class Initialized
DEBUG - 2011-08-27 04:18:26 --> Hooks Class Initialized
DEBUG - 2011-08-27 04:18:26 --> Utf8 Class Initialized
DEBUG - 2011-08-27 04:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 04:18:26 --> URI Class Initialized
DEBUG - 2011-08-27 04:18:26 --> Router Class Initialized
DEBUG - 2011-08-27 04:18:26 --> No URI present. Default controller set.
DEBUG - 2011-08-27 04:18:26 --> Output Class Initialized
DEBUG - 2011-08-27 04:18:26 --> Input Class Initialized
DEBUG - 2011-08-27 04:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 04:18:26 --> Language Class Initialized
DEBUG - 2011-08-27 04:18:26 --> Loader Class Initialized
DEBUG - 2011-08-27 04:18:26 --> Controller Class Initialized
DEBUG - 2011-08-27 04:18:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-27 04:18:26 --> Helper loaded: url_helper
DEBUG - 2011-08-27 04:18:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 04:18:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 04:18:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 04:18:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 04:18:26 --> Final output sent to browser
DEBUG - 2011-08-27 04:18:26 --> Total execution time: 0.2256
DEBUG - 2011-08-27 04:53:42 --> Config Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Hooks Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Utf8 Class Initialized
DEBUG - 2011-08-27 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 04:53:42 --> URI Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Router Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Output Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Input Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 04:53:42 --> Language Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Loader Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Controller Class Initialized
DEBUG - 2011-08-27 04:53:42 --> Model Class Initialized
DEBUG - 2011-08-27 04:53:43 --> Model Class Initialized
DEBUG - 2011-08-27 04:53:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 04:53:43 --> Database Driver Class Initialized
DEBUG - 2011-08-27 04:53:43 --> Final output sent to browser
DEBUG - 2011-08-27 04:53:43 --> Total execution time: 0.8453
DEBUG - 2011-08-27 05:18:52 --> Config Class Initialized
DEBUG - 2011-08-27 05:18:52 --> Hooks Class Initialized
DEBUG - 2011-08-27 05:18:52 --> Utf8 Class Initialized
DEBUG - 2011-08-27 05:18:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 05:18:52 --> URI Class Initialized
DEBUG - 2011-08-27 05:18:52 --> Router Class Initialized
ERROR - 2011-08-27 05:18:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-27 08:13:52 --> Config Class Initialized
DEBUG - 2011-08-27 08:13:52 --> Hooks Class Initialized
DEBUG - 2011-08-27 08:13:52 --> Utf8 Class Initialized
DEBUG - 2011-08-27 08:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 08:13:52 --> URI Class Initialized
DEBUG - 2011-08-27 08:13:52 --> Router Class Initialized
ERROR - 2011-08-27 08:13:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-27 08:13:53 --> Config Class Initialized
DEBUG - 2011-08-27 08:13:53 --> Hooks Class Initialized
DEBUG - 2011-08-27 08:13:53 --> Utf8 Class Initialized
DEBUG - 2011-08-27 08:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 08:13:53 --> URI Class Initialized
DEBUG - 2011-08-27 08:13:53 --> Router Class Initialized
DEBUG - 2011-08-27 08:13:53 --> No URI present. Default controller set.
DEBUG - 2011-08-27 08:13:53 --> Output Class Initialized
DEBUG - 2011-08-27 08:13:53 --> Input Class Initialized
DEBUG - 2011-08-27 08:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 08:13:53 --> Language Class Initialized
DEBUG - 2011-08-27 08:13:53 --> Loader Class Initialized
DEBUG - 2011-08-27 08:13:53 --> Controller Class Initialized
DEBUG - 2011-08-27 08:13:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-27 08:13:53 --> Helper loaded: url_helper
DEBUG - 2011-08-27 08:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 08:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 08:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 08:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 08:13:53 --> Final output sent to browser
DEBUG - 2011-08-27 08:13:53 --> Total execution time: 0.1671
DEBUG - 2011-08-27 08:19:42 --> Config Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Hooks Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Utf8 Class Initialized
DEBUG - 2011-08-27 08:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 08:19:42 --> URI Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Router Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Output Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Input Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 08:19:42 --> Language Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Loader Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Controller Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Model Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Model Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Model Class Initialized
DEBUG - 2011-08-27 08:19:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 08:19:42 --> Database Driver Class Initialized
DEBUG - 2011-08-27 08:19:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 08:19:43 --> Helper loaded: url_helper
DEBUG - 2011-08-27 08:19:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 08:19:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 08:19:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 08:19:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 08:19:43 --> Final output sent to browser
DEBUG - 2011-08-27 08:19:43 --> Total execution time: 1.1398
DEBUG - 2011-08-27 09:13:21 --> Config Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Hooks Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Config Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Hooks Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Utf8 Class Initialized
DEBUG - 2011-08-27 09:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 09:13:21 --> Utf8 Class Initialized
DEBUG - 2011-08-27 09:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 09:13:21 --> URI Class Initialized
DEBUG - 2011-08-27 09:13:21 --> URI Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Router Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Router Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Output Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Output Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Input Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 09:13:21 --> Input Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 09:13:21 --> Language Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Language Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Loader Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Loader Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Controller Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Controller Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Model Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Model Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Model Class Initialized
ERROR - 2011-08-27 09:13:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 09:13:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 09:13:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 09:13:21 --> Model Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Model Class Initialized
DEBUG - 2011-08-27 09:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 09:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 09:13:22 --> Database Driver Class Initialized
DEBUG - 2011-08-27 09:13:22 --> Database Driver Class Initialized
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 09:13:22 --> Helper loaded: url_helper
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 09:13:22 --> Final output sent to browser
DEBUG - 2011-08-27 09:13:22 --> Total execution time: 1.2423
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 09:13:22 --> Helper loaded: url_helper
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 09:13:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 09:13:22 --> Final output sent to browser
DEBUG - 2011-08-27 09:13:22 --> Total execution time: 1.4233
DEBUG - 2011-08-27 10:00:52 --> Config Class Initialized
DEBUG - 2011-08-27 10:00:52 --> Hooks Class Initialized
DEBUG - 2011-08-27 10:00:52 --> Utf8 Class Initialized
DEBUG - 2011-08-27 10:00:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 10:00:52 --> URI Class Initialized
DEBUG - 2011-08-27 10:00:52 --> Router Class Initialized
ERROR - 2011-08-27 10:00:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-27 10:30:48 --> Config Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Hooks Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Utf8 Class Initialized
DEBUG - 2011-08-27 10:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 10:30:48 --> URI Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Router Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Output Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Input Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 10:30:48 --> Language Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Loader Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Controller Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Model Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Model Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Model Class Initialized
DEBUG - 2011-08-27 10:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 10:30:48 --> Database Driver Class Initialized
DEBUG - 2011-08-27 10:30:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 10:30:48 --> Helper loaded: url_helper
DEBUG - 2011-08-27 10:30:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 10:30:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 10:30:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 10:30:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 10:30:48 --> Final output sent to browser
DEBUG - 2011-08-27 10:30:48 --> Total execution time: 0.4911
DEBUG - 2011-08-27 11:18:03 --> Config Class Initialized
DEBUG - 2011-08-27 11:18:03 --> Hooks Class Initialized
DEBUG - 2011-08-27 11:18:03 --> Utf8 Class Initialized
DEBUG - 2011-08-27 11:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 11:18:03 --> URI Class Initialized
DEBUG - 2011-08-27 11:18:03 --> Router Class Initialized
DEBUG - 2011-08-27 11:18:03 --> No URI present. Default controller set.
DEBUG - 2011-08-27 11:18:03 --> Output Class Initialized
DEBUG - 2011-08-27 11:18:03 --> Input Class Initialized
DEBUG - 2011-08-27 11:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 11:18:03 --> Language Class Initialized
DEBUG - 2011-08-27 11:18:03 --> Loader Class Initialized
DEBUG - 2011-08-27 11:18:03 --> Controller Class Initialized
DEBUG - 2011-08-27 11:18:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-27 11:18:03 --> Helper loaded: url_helper
DEBUG - 2011-08-27 11:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 11:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 11:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 11:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 11:18:03 --> Final output sent to browser
DEBUG - 2011-08-27 11:18:03 --> Total execution time: 0.1718
DEBUG - 2011-08-27 13:35:47 --> Config Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:35:47 --> URI Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Router Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Output Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Input Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:35:47 --> Language Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Loader Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Controller Class Initialized
ERROR - 2011-08-27 13:35:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 13:35:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 13:35:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:35:47 --> Model Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Model Class Initialized
DEBUG - 2011-08-27 13:35:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:35:47 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:35:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:35:48 --> Helper loaded: url_helper
DEBUG - 2011-08-27 13:35:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 13:35:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 13:35:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 13:35:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 13:35:48 --> Final output sent to browser
DEBUG - 2011-08-27 13:35:48 --> Total execution time: 1.3084
DEBUG - 2011-08-27 13:35:51 --> Config Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:35:51 --> URI Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Router Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Output Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Input Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:35:51 --> Language Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Loader Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Controller Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Model Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Model Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:35:51 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:35:51 --> Final output sent to browser
DEBUG - 2011-08-27 13:35:51 --> Total execution time: 0.7434
DEBUG - 2011-08-27 13:35:54 --> Config Class Initialized
DEBUG - 2011-08-27 13:35:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:35:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:35:54 --> URI Class Initialized
DEBUG - 2011-08-27 13:35:54 --> Router Class Initialized
ERROR - 2011-08-27 13:35:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 13:36:05 --> Config Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:36:05 --> URI Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Router Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Output Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Input Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:36:05 --> Language Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Loader Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Controller Class Initialized
ERROR - 2011-08-27 13:36:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 13:36:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 13:36:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:36:05 --> Model Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Model Class Initialized
DEBUG - 2011-08-27 13:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:36:05 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:36:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:36:05 --> Helper loaded: url_helper
DEBUG - 2011-08-27 13:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 13:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 13:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 13:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 13:36:05 --> Final output sent to browser
DEBUG - 2011-08-27 13:36:05 --> Total execution time: 0.0315
DEBUG - 2011-08-27 13:36:06 --> Config Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:36:06 --> URI Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Router Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Output Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Input Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:36:06 --> Language Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Loader Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Controller Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Model Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Model Class Initialized
DEBUG - 2011-08-27 13:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:36:06 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:36:07 --> Final output sent to browser
DEBUG - 2011-08-27 13:36:07 --> Total execution time: 0.6784
DEBUG - 2011-08-27 13:36:08 --> Config Class Initialized
DEBUG - 2011-08-27 13:36:08 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:36:08 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:36:08 --> URI Class Initialized
DEBUG - 2011-08-27 13:36:08 --> Router Class Initialized
ERROR - 2011-08-27 13:36:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 13:36:17 --> Config Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:36:17 --> URI Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Router Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Output Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Input Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:36:17 --> Language Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Loader Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Controller Class Initialized
ERROR - 2011-08-27 13:36:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 13:36:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 13:36:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:36:17 --> Model Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Model Class Initialized
DEBUG - 2011-08-27 13:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:36:17 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:36:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:36:17 --> Helper loaded: url_helper
DEBUG - 2011-08-27 13:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 13:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 13:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 13:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 13:36:17 --> Final output sent to browser
DEBUG - 2011-08-27 13:36:17 --> Total execution time: 0.0269
DEBUG - 2011-08-27 13:36:18 --> Config Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:36:18 --> URI Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Router Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Output Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Input Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:36:18 --> Language Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Loader Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Controller Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Model Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Model Class Initialized
DEBUG - 2011-08-27 13:36:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:36:18 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:36:19 --> Final output sent to browser
DEBUG - 2011-08-27 13:36:19 --> Total execution time: 0.5146
DEBUG - 2011-08-27 13:36:20 --> Config Class Initialized
DEBUG - 2011-08-27 13:36:20 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:36:20 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:36:20 --> URI Class Initialized
DEBUG - 2011-08-27 13:36:20 --> Router Class Initialized
ERROR - 2011-08-27 13:36:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 13:41:08 --> Config Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:41:08 --> URI Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Router Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Output Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Input Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:41:08 --> Language Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Loader Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Controller Class Initialized
ERROR - 2011-08-27 13:41:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 13:41:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 13:41:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:41:08 --> Model Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Model Class Initialized
DEBUG - 2011-08-27 13:41:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:41:08 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:41:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:41:08 --> Helper loaded: url_helper
DEBUG - 2011-08-27 13:41:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 13:41:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 13:41:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 13:41:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 13:41:08 --> Final output sent to browser
DEBUG - 2011-08-27 13:41:08 --> Total execution time: 0.0485
DEBUG - 2011-08-27 13:41:09 --> Config Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:41:09 --> URI Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Router Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Output Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Input Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:41:09 --> Language Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Loader Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Controller Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Model Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Model Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:41:09 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:41:09 --> Final output sent to browser
DEBUG - 2011-08-27 13:41:09 --> Total execution time: 0.5075
DEBUG - 2011-08-27 13:41:16 --> Config Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:41:16 --> URI Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Router Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Output Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Input Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:41:16 --> Language Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Loader Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Controller Class Initialized
ERROR - 2011-08-27 13:41:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 13:41:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 13:41:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:41:16 --> Model Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Model Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:41:16 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:41:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 13:41:16 --> Helper loaded: url_helper
DEBUG - 2011-08-27 13:41:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 13:41:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 13:41:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 13:41:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 13:41:16 --> Final output sent to browser
DEBUG - 2011-08-27 13:41:16 --> Total execution time: 0.0278
DEBUG - 2011-08-27 13:41:16 --> Config Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Hooks Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Utf8 Class Initialized
DEBUG - 2011-08-27 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 13:41:16 --> URI Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Router Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Output Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Input Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 13:41:16 --> Language Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Loader Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Controller Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Model Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Model Class Initialized
DEBUG - 2011-08-27 13:41:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 13:41:16 --> Database Driver Class Initialized
DEBUG - 2011-08-27 13:41:17 --> Final output sent to browser
DEBUG - 2011-08-27 13:41:17 --> Total execution time: 0.4673
DEBUG - 2011-08-27 14:11:08 --> Config Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Hooks Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Utf8 Class Initialized
DEBUG - 2011-08-27 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 14:11:08 --> URI Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Router Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Output Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Input Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 14:11:08 --> Language Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Loader Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Controller Class Initialized
ERROR - 2011-08-27 14:11:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 14:11:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 14:11:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 14:11:08 --> Model Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Model Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 14:11:08 --> Database Driver Class Initialized
DEBUG - 2011-08-27 14:11:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 14:11:08 --> Helper loaded: url_helper
DEBUG - 2011-08-27 14:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 14:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 14:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 14:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 14:11:08 --> Final output sent to browser
DEBUG - 2011-08-27 14:11:08 --> Total execution time: 0.0308
DEBUG - 2011-08-27 14:11:08 --> Config Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Hooks Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Utf8 Class Initialized
DEBUG - 2011-08-27 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 14:11:08 --> URI Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Router Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Output Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Input Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 14:11:08 --> Language Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Loader Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Controller Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Model Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Model Class Initialized
DEBUG - 2011-08-27 14:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 14:11:08 --> Database Driver Class Initialized
DEBUG - 2011-08-27 14:11:09 --> Final output sent to browser
DEBUG - 2011-08-27 14:11:09 --> Total execution time: 0.7098
DEBUG - 2011-08-27 15:13:17 --> Config Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Hooks Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Utf8 Class Initialized
DEBUG - 2011-08-27 15:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 15:13:17 --> URI Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Router Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Output Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Input Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 15:13:17 --> Language Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Loader Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Controller Class Initialized
ERROR - 2011-08-27 15:13:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 15:13:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 15:13:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 15:13:17 --> Model Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Model Class Initialized
DEBUG - 2011-08-27 15:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 15:13:17 --> Database Driver Class Initialized
DEBUG - 2011-08-27 15:13:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 15:13:17 --> Helper loaded: url_helper
DEBUG - 2011-08-27 15:13:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 15:13:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 15:13:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 15:13:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 15:13:17 --> Final output sent to browser
DEBUG - 2011-08-27 15:13:17 --> Total execution time: 0.1050
DEBUG - 2011-08-27 15:13:18 --> Config Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Hooks Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Utf8 Class Initialized
DEBUG - 2011-08-27 15:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 15:13:18 --> URI Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Router Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Output Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Input Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 15:13:18 --> Language Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Loader Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Controller Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Model Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Model Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 15:13:18 --> Database Driver Class Initialized
DEBUG - 2011-08-27 15:13:18 --> Final output sent to browser
DEBUG - 2011-08-27 15:13:18 --> Total execution time: 0.7742
DEBUG - 2011-08-27 15:13:21 --> Config Class Initialized
DEBUG - 2011-08-27 15:13:21 --> Hooks Class Initialized
DEBUG - 2011-08-27 15:13:21 --> Utf8 Class Initialized
DEBUG - 2011-08-27 15:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 15:13:21 --> URI Class Initialized
DEBUG - 2011-08-27 15:13:21 --> Router Class Initialized
ERROR - 2011-08-27 15:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 15:13:36 --> Config Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 15:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 15:13:36 --> URI Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Router Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Output Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Input Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 15:13:36 --> Language Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Loader Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Controller Class Initialized
ERROR - 2011-08-27 15:13:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 15:13:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 15:13:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 15:13:36 --> Model Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Model Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 15:13:36 --> Database Driver Class Initialized
DEBUG - 2011-08-27 15:13:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 15:13:36 --> Helper loaded: url_helper
DEBUG - 2011-08-27 15:13:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 15:13:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 15:13:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 15:13:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 15:13:36 --> Final output sent to browser
DEBUG - 2011-08-27 15:13:36 --> Total execution time: 0.0280
DEBUG - 2011-08-27 15:13:36 --> Config Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 15:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 15:13:36 --> URI Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Router Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Output Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Input Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 15:13:36 --> Language Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Loader Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Controller Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Model Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Model Class Initialized
DEBUG - 2011-08-27 15:13:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 15:13:36 --> Database Driver Class Initialized
DEBUG - 2011-08-27 15:13:37 --> Final output sent to browser
DEBUG - 2011-08-27 15:13:37 --> Total execution time: 0.6477
DEBUG - 2011-08-27 15:58:34 --> Config Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Hooks Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Utf8 Class Initialized
DEBUG - 2011-08-27 15:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 15:58:34 --> URI Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Router Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Output Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Input Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 15:58:34 --> Language Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Loader Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Controller Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 15:58:34 --> Database Driver Class Initialized
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 15:58:35 --> Helper loaded: url_helper
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 15:58:35 --> Final output sent to browser
DEBUG - 2011-08-27 15:58:35 --> Total execution time: 0.4586
DEBUG - 2011-08-27 15:58:35 --> Config Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Hooks Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Utf8 Class Initialized
DEBUG - 2011-08-27 15:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 15:58:35 --> URI Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Router Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Output Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Input Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 15:58:35 --> Language Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Loader Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Controller Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 15:58:35 --> Database Driver Class Initialized
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 15:58:35 --> Helper loaded: url_helper
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 15:58:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 15:58:35 --> Final output sent to browser
DEBUG - 2011-08-27 15:58:35 --> Total execution time: 0.1954
DEBUG - 2011-08-27 15:58:36 --> Config Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 15:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 15:58:36 --> URI Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Router Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Output Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Input Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 15:58:36 --> Language Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Loader Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Controller Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Model Class Initialized
DEBUG - 2011-08-27 15:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 15:58:36 --> Database Driver Class Initialized
DEBUG - 2011-08-27 15:58:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 15:58:36 --> Helper loaded: url_helper
DEBUG - 2011-08-27 15:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 15:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 15:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 15:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 15:58:36 --> Final output sent to browser
DEBUG - 2011-08-27 15:58:36 --> Total execution time: 0.2179
DEBUG - 2011-08-27 16:04:21 --> Config Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:04:21 --> URI Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Router Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Output Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Input Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:04:21 --> Language Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Loader Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Controller Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:04:22 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:04:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:04:22 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:04:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:04:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:04:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:04:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:04:22 --> Final output sent to browser
DEBUG - 2011-08-27 16:04:22 --> Total execution time: 0.0532
DEBUG - 2011-08-27 16:04:52 --> Config Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:04:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:04:52 --> URI Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Router Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Output Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Input Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:04:52 --> Language Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Loader Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Controller Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:04:52 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:04:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:04:52 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:04:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:04:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:04:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:04:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:04:52 --> Final output sent to browser
DEBUG - 2011-08-27 16:04:52 --> Total execution time: 0.0665
DEBUG - 2011-08-27 16:04:54 --> Config Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:04:54 --> URI Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Router Class Initialized
ERROR - 2011-08-27 16:04:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-27 16:04:54 --> Config Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:04:54 --> URI Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Router Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Output Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Input Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:04:54 --> Language Class Initialized
DEBUG - 2011-08-27 16:04:54 --> Loader Class Initialized
DEBUG - 2011-08-27 16:04:55 --> Controller Class Initialized
DEBUG - 2011-08-27 16:04:55 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:55 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:55 --> Model Class Initialized
DEBUG - 2011-08-27 16:04:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:04:55 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:04:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:04:55 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:04:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:04:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:04:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:04:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:04:55 --> Final output sent to browser
DEBUG - 2011-08-27 16:04:55 --> Total execution time: 0.0469
DEBUG - 2011-08-27 16:05:12 --> Config Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:05:12 --> URI Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Router Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Output Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Input Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:05:12 --> Language Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Loader Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Controller Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Model Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Model Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Model Class Initialized
DEBUG - 2011-08-27 16:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:05:12 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:05:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:05:12 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:05:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:05:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:05:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:05:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:05:12 --> Final output sent to browser
DEBUG - 2011-08-27 16:05:12 --> Total execution time: 0.0481
DEBUG - 2011-08-27 16:05:44 --> Config Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:05:44 --> URI Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Router Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Output Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Input Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:05:44 --> Language Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Loader Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Controller Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Model Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Model Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Model Class Initialized
DEBUG - 2011-08-27 16:05:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:05:44 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:05:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:05:44 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:05:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:05:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:05:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:05:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:05:44 --> Final output sent to browser
DEBUG - 2011-08-27 16:05:44 --> Total execution time: 0.3454
DEBUG - 2011-08-27 16:06:03 --> Config Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:06:03 --> URI Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Router Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Output Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Input Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:06:03 --> Language Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Loader Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Controller Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Model Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Model Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Model Class Initialized
DEBUG - 2011-08-27 16:06:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:06:03 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:06:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:06:04 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:06:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:06:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:06:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:06:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:06:04 --> Final output sent to browser
DEBUG - 2011-08-27 16:06:04 --> Total execution time: 0.5429
DEBUG - 2011-08-27 16:06:38 --> Config Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:06:38 --> URI Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Router Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Output Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Input Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:06:38 --> Language Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Loader Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Controller Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Model Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Model Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Model Class Initialized
DEBUG - 2011-08-27 16:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:06:38 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:06:38 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:06:38 --> Final output sent to browser
DEBUG - 2011-08-27 16:06:38 --> Total execution time: 0.1794
DEBUG - 2011-08-27 16:07:10 --> Config Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:07:10 --> URI Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Router Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Output Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Input Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:07:10 --> Language Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Loader Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Controller Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:07:10 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:07:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:07:11 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:07:11 --> Final output sent to browser
DEBUG - 2011-08-27 16:07:11 --> Total execution time: 0.2069
DEBUG - 2011-08-27 16:07:36 --> Config Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:07:36 --> URI Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Router Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Output Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Input Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:07:36 --> Language Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Loader Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Controller Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:07:36 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:07:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:07:36 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:07:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:07:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:07:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:07:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:07:36 --> Final output sent to browser
DEBUG - 2011-08-27 16:07:36 --> Total execution time: 0.5174
DEBUG - 2011-08-27 16:07:38 --> Config Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:07:38 --> URI Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Router Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Output Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Input Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:07:38 --> Language Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Loader Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Controller Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:07:38 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:07:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:07:38 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:07:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:07:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:07:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:07:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:07:38 --> Final output sent to browser
DEBUG - 2011-08-27 16:07:38 --> Total execution time: 0.0580
DEBUG - 2011-08-27 16:07:58 --> Config Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:07:58 --> URI Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Router Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Output Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Input Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:07:58 --> Language Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Loader Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Controller Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Model Class Initialized
DEBUG - 2011-08-27 16:07:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:07:58 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:07:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:07:58 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:07:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:07:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:07:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:07:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:07:58 --> Final output sent to browser
DEBUG - 2011-08-27 16:07:58 --> Total execution time: 0.3107
DEBUG - 2011-08-27 16:08:00 --> Config Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:08:00 --> URI Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Router Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Output Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Input Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:08:00 --> Language Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Loader Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Controller Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:08:00 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:08:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:08:00 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:08:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:08:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:08:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:08:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:08:00 --> Final output sent to browser
DEBUG - 2011-08-27 16:08:00 --> Total execution time: 0.1251
DEBUG - 2011-08-27 16:08:26 --> Config Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:08:26 --> URI Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Router Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Output Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Input Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:08:26 --> Language Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Loader Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Controller Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:08:26 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:08:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:08:28 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:08:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:08:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:08:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:08:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:08:28 --> Final output sent to browser
DEBUG - 2011-08-27 16:08:28 --> Total execution time: 1.4372
DEBUG - 2011-08-27 16:08:30 --> Config Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:08:30 --> URI Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Router Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Output Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Input Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:08:30 --> Language Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Loader Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Controller Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Model Class Initialized
DEBUG - 2011-08-27 16:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:08:30 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:08:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 16:08:31 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:08:31 --> Final output sent to browser
DEBUG - 2011-08-27 16:08:31 --> Total execution time: 0.1595
DEBUG - 2011-08-27 16:10:02 --> Config Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:10:02 --> URI Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Router Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Output Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Input Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:10:02 --> Language Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Loader Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Controller Class Initialized
ERROR - 2011-08-27 16:10:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 16:10:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 16:10:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 16:10:02 --> Model Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Model Class Initialized
DEBUG - 2011-08-27 16:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:10:02 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:10:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 16:10:02 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:10:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:10:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:10:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:10:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:10:02 --> Final output sent to browser
DEBUG - 2011-08-27 16:10:02 --> Total execution time: 0.0473
DEBUG - 2011-08-27 16:10:04 --> Config Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:10:04 --> URI Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Router Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Output Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Input Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:10:04 --> Language Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Loader Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Controller Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Model Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Model Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:10:04 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:10:04 --> Final output sent to browser
DEBUG - 2011-08-27 16:10:04 --> Total execution time: 0.5525
DEBUG - 2011-08-27 16:10:22 --> Config Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:10:22 --> URI Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Router Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Output Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Input Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:10:22 --> Language Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Loader Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Controller Class Initialized
ERROR - 2011-08-27 16:10:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 16:10:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 16:10:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 16:10:22 --> Model Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Model Class Initialized
DEBUG - 2011-08-27 16:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:10:22 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:10:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 16:10:22 --> Helper loaded: url_helper
DEBUG - 2011-08-27 16:10:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 16:10:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 16:10:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 16:10:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 16:10:22 --> Final output sent to browser
DEBUG - 2011-08-27 16:10:22 --> Total execution time: 0.0372
DEBUG - 2011-08-27 16:10:24 --> Config Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Hooks Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Utf8 Class Initialized
DEBUG - 2011-08-27 16:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 16:10:24 --> URI Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Router Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Output Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Input Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 16:10:24 --> Language Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Loader Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Controller Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Model Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Model Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 16:10:24 --> Database Driver Class Initialized
DEBUG - 2011-08-27 16:10:24 --> Final output sent to browser
DEBUG - 2011-08-27 16:10:24 --> Total execution time: 0.5493
DEBUG - 2011-08-27 17:18:13 --> Config Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Hooks Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Utf8 Class Initialized
DEBUG - 2011-08-27 17:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 17:18:13 --> URI Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Router Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Output Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Input Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 17:18:13 --> Language Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Loader Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Controller Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Model Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Model Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Model Class Initialized
DEBUG - 2011-08-27 17:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 17:18:13 --> Database Driver Class Initialized
DEBUG - 2011-08-27 17:18:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 17:18:13 --> Helper loaded: url_helper
DEBUG - 2011-08-27 17:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 17:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 17:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 17:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 17:18:13 --> Final output sent to browser
DEBUG - 2011-08-27 17:18:13 --> Total execution time: 0.3935
DEBUG - 2011-08-27 17:18:16 --> Config Class Initialized
DEBUG - 2011-08-27 17:18:16 --> Hooks Class Initialized
DEBUG - 2011-08-27 17:18:16 --> Utf8 Class Initialized
DEBUG - 2011-08-27 17:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 17:18:16 --> URI Class Initialized
DEBUG - 2011-08-27 17:18:16 --> Router Class Initialized
ERROR - 2011-08-27 17:18:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 17:18:17 --> Config Class Initialized
DEBUG - 2011-08-27 17:18:17 --> Hooks Class Initialized
DEBUG - 2011-08-27 17:18:17 --> Utf8 Class Initialized
DEBUG - 2011-08-27 17:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 17:18:17 --> URI Class Initialized
DEBUG - 2011-08-27 17:18:17 --> Router Class Initialized
ERROR - 2011-08-27 17:18:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 18:12:02 --> Config Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Hooks Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Utf8 Class Initialized
DEBUG - 2011-08-27 18:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 18:12:02 --> URI Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Router Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Output Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Input Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 18:12:02 --> Language Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Loader Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Controller Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Model Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Model Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Model Class Initialized
DEBUG - 2011-08-27 18:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 18:12:02 --> Database Driver Class Initialized
DEBUG - 2011-08-27 18:12:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 18:12:02 --> Helper loaded: url_helper
DEBUG - 2011-08-27 18:12:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 18:12:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 18:12:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 18:12:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 18:12:02 --> Final output sent to browser
DEBUG - 2011-08-27 18:12:02 --> Total execution time: 0.2523
DEBUG - 2011-08-27 18:12:04 --> Config Class Initialized
DEBUG - 2011-08-27 18:12:04 --> Hooks Class Initialized
DEBUG - 2011-08-27 18:12:04 --> Utf8 Class Initialized
DEBUG - 2011-08-27 18:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 18:12:04 --> URI Class Initialized
DEBUG - 2011-08-27 18:12:04 --> Router Class Initialized
ERROR - 2011-08-27 18:12:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 18:12:04 --> Config Class Initialized
DEBUG - 2011-08-27 18:12:04 --> Hooks Class Initialized
DEBUG - 2011-08-27 18:12:04 --> Utf8 Class Initialized
DEBUG - 2011-08-27 18:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 18:12:04 --> URI Class Initialized
DEBUG - 2011-08-27 18:12:04 --> Router Class Initialized
ERROR - 2011-08-27 18:12:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 18:14:31 --> Config Class Initialized
DEBUG - 2011-08-27 18:14:31 --> Hooks Class Initialized
DEBUG - 2011-08-27 18:14:31 --> Utf8 Class Initialized
DEBUG - 2011-08-27 18:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 18:14:31 --> URI Class Initialized
DEBUG - 2011-08-27 18:14:31 --> Router Class Initialized
DEBUG - 2011-08-27 18:14:31 --> No URI present. Default controller set.
DEBUG - 2011-08-27 18:14:31 --> Output Class Initialized
DEBUG - 2011-08-27 18:14:31 --> Input Class Initialized
DEBUG - 2011-08-27 18:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 18:14:31 --> Language Class Initialized
DEBUG - 2011-08-27 18:14:31 --> Loader Class Initialized
DEBUG - 2011-08-27 18:14:31 --> Controller Class Initialized
DEBUG - 2011-08-27 18:14:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-27 18:14:31 --> Helper loaded: url_helper
DEBUG - 2011-08-27 18:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 18:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 18:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 18:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 18:14:31 --> Final output sent to browser
DEBUG - 2011-08-27 18:14:31 --> Total execution time: 0.0792
DEBUG - 2011-08-27 18:19:35 --> Config Class Initialized
DEBUG - 2011-08-27 18:19:35 --> Hooks Class Initialized
DEBUG - 2011-08-27 18:19:35 --> Utf8 Class Initialized
DEBUG - 2011-08-27 18:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 18:19:35 --> URI Class Initialized
DEBUG - 2011-08-27 18:19:35 --> Router Class Initialized
ERROR - 2011-08-27 18:19:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-27 19:21:38 --> Config Class Initialized
DEBUG - 2011-08-27 19:21:38 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:21:38 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:21:38 --> URI Class Initialized
DEBUG - 2011-08-27 19:21:38 --> Router Class Initialized
ERROR - 2011-08-27 19:21:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-27 19:38:59 --> Config Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:38:59 --> URI Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Router Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Output Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Input Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:38:59 --> Language Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Loader Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Controller Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Model Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Model Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Model Class Initialized
DEBUG - 2011-08-27 19:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:38:59 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:38:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:38:59 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:38:59 --> Final output sent to browser
DEBUG - 2011-08-27 19:38:59 --> Total execution time: 0.2909
DEBUG - 2011-08-27 19:39:06 --> Config Class Initialized
DEBUG - 2011-08-27 19:39:06 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:39:06 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:39:06 --> URI Class Initialized
DEBUG - 2011-08-27 19:39:06 --> Router Class Initialized
ERROR - 2011-08-27 19:39:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 19:40:34 --> Config Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:40:34 --> URI Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Router Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Output Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Input Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:40:34 --> Language Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Loader Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Controller Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Model Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Model Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Model Class Initialized
DEBUG - 2011-08-27 19:40:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:40:34 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:40:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:40:35 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:40:35 --> Final output sent to browser
DEBUG - 2011-08-27 19:40:35 --> Total execution time: 0.2230
DEBUG - 2011-08-27 19:40:39 --> Config Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:40:39 --> URI Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Router Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Output Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Input Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:40:39 --> Language Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Loader Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Controller Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Model Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Model Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Model Class Initialized
DEBUG - 2011-08-27 19:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:40:39 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:40:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:40:39 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:40:39 --> Final output sent to browser
DEBUG - 2011-08-27 19:40:39 --> Total execution time: 0.0464
DEBUG - 2011-08-27 19:42:51 --> Config Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:42:51 --> URI Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Router Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Output Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Input Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:42:51 --> Language Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Loader Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Controller Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Model Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Model Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Model Class Initialized
DEBUG - 2011-08-27 19:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:42:51 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:42:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:42:52 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:42:52 --> Final output sent to browser
DEBUG - 2011-08-27 19:42:52 --> Total execution time: 0.2439
DEBUG - 2011-08-27 19:42:56 --> Config Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:42:56 --> URI Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Router Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Output Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Input Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:42:56 --> Language Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Loader Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Controller Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Model Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Model Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Model Class Initialized
DEBUG - 2011-08-27 19:42:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:42:56 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:42:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:42:56 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:42:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:42:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:42:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:42:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:42:56 --> Final output sent to browser
DEBUG - 2011-08-27 19:42:56 --> Total execution time: 0.0461
DEBUG - 2011-08-27 19:43:02 --> Config Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:43:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:43:02 --> URI Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Router Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Output Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Input Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:43:02 --> Language Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Loader Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Controller Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:43:02 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:43:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:43:02 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:43:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:43:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:43:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:43:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:43:02 --> Final output sent to browser
DEBUG - 2011-08-27 19:43:02 --> Total execution time: 0.0639
DEBUG - 2011-08-27 19:43:23 --> Config Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:43:23 --> URI Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Router Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Output Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Input Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:43:23 --> Language Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Loader Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Controller Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:43:23 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:43:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:43:23 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:43:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:43:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:43:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:43:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:43:23 --> Final output sent to browser
DEBUG - 2011-08-27 19:43:23 --> Total execution time: 0.2177
DEBUG - 2011-08-27 19:43:28 --> Config Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:43:28 --> URI Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Router Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Output Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Input Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:43:28 --> Language Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Loader Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Controller Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Model Class Initialized
DEBUG - 2011-08-27 19:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:43:28 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:43:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:43:28 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:43:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:43:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:43:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:43:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:43:28 --> Final output sent to browser
DEBUG - 2011-08-27 19:43:28 --> Total execution time: 0.1749
DEBUG - 2011-08-27 19:44:03 --> Config Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:44:03 --> URI Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Router Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Output Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Input Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:44:03 --> Language Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Loader Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Controller Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:44:03 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:44:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:44:03 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:44:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:44:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:44:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:44:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:44:03 --> Final output sent to browser
DEBUG - 2011-08-27 19:44:03 --> Total execution time: 0.2650
DEBUG - 2011-08-27 19:44:06 --> Config Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:44:06 --> URI Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Router Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Output Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Input Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:44:06 --> Language Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Loader Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Controller Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:44:06 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:44:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:44:06 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:44:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:44:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:44:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:44:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:44:06 --> Final output sent to browser
DEBUG - 2011-08-27 19:44:06 --> Total execution time: 0.0440
DEBUG - 2011-08-27 19:44:35 --> Config Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:44:35 --> URI Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Router Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Output Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Input Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:44:35 --> Language Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Loader Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Controller Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:44:35 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:44:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:44:35 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:44:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:44:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:44:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:44:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:44:35 --> Final output sent to browser
DEBUG - 2011-08-27 19:44:35 --> Total execution time: 0.2902
DEBUG - 2011-08-27 19:44:38 --> Config Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:44:38 --> URI Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Router Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Output Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Input Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:44:38 --> Language Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Loader Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Controller Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Model Class Initialized
DEBUG - 2011-08-27 19:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:44:38 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:44:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:44:38 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:44:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:44:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:44:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:44:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:44:38 --> Final output sent to browser
DEBUG - 2011-08-27 19:44:38 --> Total execution time: 0.0421
DEBUG - 2011-08-27 19:45:49 --> Config Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:45:49 --> URI Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Router Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Output Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Input Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:45:49 --> Language Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Loader Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Controller Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Model Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Model Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Model Class Initialized
DEBUG - 2011-08-27 19:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:45:49 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:45:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:45:50 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:45:50 --> Final output sent to browser
DEBUG - 2011-08-27 19:45:50 --> Total execution time: 0.1977
DEBUG - 2011-08-27 19:45:53 --> Config Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:45:53 --> URI Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Router Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Output Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Input Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:45:53 --> Language Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Loader Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Controller Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Model Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Model Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Model Class Initialized
DEBUG - 2011-08-27 19:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:45:53 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:45:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:45:53 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:45:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:45:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:45:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:45:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:45:53 --> Final output sent to browser
DEBUG - 2011-08-27 19:45:53 --> Total execution time: 0.0452
DEBUG - 2011-08-27 19:46:22 --> Config Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:46:22 --> URI Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Router Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Output Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Input Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:46:22 --> Language Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Loader Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Controller Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:46:22 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:46:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:46:22 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:46:22 --> Final output sent to browser
DEBUG - 2011-08-27 19:46:22 --> Total execution time: 0.2618
DEBUG - 2011-08-27 19:46:25 --> Config Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:46:25 --> URI Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Router Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Output Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Input Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:46:25 --> Language Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Loader Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Controller Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:46:25 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:46:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:46:25 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:46:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:46:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:46:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:46:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:46:25 --> Final output sent to browser
DEBUG - 2011-08-27 19:46:25 --> Total execution time: 0.0844
DEBUG - 2011-08-27 19:46:51 --> Config Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:46:51 --> URI Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Router Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Output Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Input Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:46:51 --> Language Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Loader Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Controller Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:46:51 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:46:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:46:52 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:46:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:46:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:46:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:46:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:46:52 --> Final output sent to browser
DEBUG - 2011-08-27 19:46:52 --> Total execution time: 0.3782
DEBUG - 2011-08-27 19:46:56 --> Config Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:46:56 --> URI Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Router Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Output Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Input Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:46:56 --> Language Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Loader Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Controller Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Model Class Initialized
DEBUG - 2011-08-27 19:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:46:56 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:46:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:46:56 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:46:56 --> Final output sent to browser
DEBUG - 2011-08-27 19:46:56 --> Total execution time: 0.0444
DEBUG - 2011-08-27 19:48:39 --> Config Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:48:39 --> URI Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Router Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Output Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Input Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:48:39 --> Language Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Loader Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Controller Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Model Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Model Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Model Class Initialized
DEBUG - 2011-08-27 19:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:48:39 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:48:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:48:40 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:48:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:48:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:48:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:48:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:48:40 --> Final output sent to browser
DEBUG - 2011-08-27 19:48:40 --> Total execution time: 0.3253
DEBUG - 2011-08-27 19:48:42 --> Config Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:48:42 --> URI Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Router Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Output Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Input Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:48:42 --> Language Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Loader Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Controller Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-27 19:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:48:42 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:48:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:48:42 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:48:42 --> Final output sent to browser
DEBUG - 2011-08-27 19:48:42 --> Total execution time: 0.0428
DEBUG - 2011-08-27 19:49:01 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:01 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:01 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Controller Class Initialized
ERROR - 2011-08-27 19:49:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 19:49:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 19:49:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:01 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:01 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:01 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:01 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:01 --> Total execution time: 0.0922
DEBUG - 2011-08-27 19:49:02 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:02 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:02 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:02 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:02 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:02 --> Total execution time: 0.6390
DEBUG - 2011-08-27 19:49:03 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:03 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Router Class Initialized
ERROR - 2011-08-27 19:49:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 19:49:03 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:03 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Router Class Initialized
ERROR - 2011-08-27 19:49:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 19:49:03 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:03 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:03 --> Router Class Initialized
ERROR - 2011-08-27 19:49:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 19:49:08 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:08 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:08 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:08 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:49:08 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:08 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:08 --> Total execution time: 0.1814
DEBUG - 2011-08-27 19:49:09 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:09 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:09 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:09 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:49:09 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:09 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:09 --> Total execution time: 0.0450
DEBUG - 2011-08-27 19:49:12 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:12 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:12 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:12 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:49:12 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:12 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:12 --> Total execution time: 0.0451
DEBUG - 2011-08-27 19:49:14 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:14 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:14 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Controller Class Initialized
ERROR - 2011-08-27 19:49:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 19:49:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 19:49:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:14 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:14 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:14 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:14 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:14 --> Total execution time: 0.0278
DEBUG - 2011-08-27 19:49:14 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:14 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:14 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:14 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:15 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:15 --> Total execution time: 0.5652
DEBUG - 2011-08-27 19:49:20 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:20 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:20 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Controller Class Initialized
ERROR - 2011-08-27 19:49:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 19:49:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 19:49:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:20 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:20 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:20 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:20 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:20 --> Total execution time: 0.0325
DEBUG - 2011-08-27 19:49:20 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:20 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:20 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:20 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:21 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:21 --> Total execution time: 0.5026
DEBUG - 2011-08-27 19:49:28 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:28 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:28 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Controller Class Initialized
ERROR - 2011-08-27 19:49:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 19:49:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 19:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:28 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:28 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:28 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:28 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:28 --> Total execution time: 0.0274
DEBUG - 2011-08-27 19:49:28 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:28 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:28 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:28 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:29 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:29 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Controller Class Initialized
ERROR - 2011-08-27 19:49:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 19:49:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 19:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:29 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:29 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:29 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:29 --> Total execution time: 0.0296
DEBUG - 2011-08-27 19:49:29 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:29 --> Total execution time: 0.6141
DEBUG - 2011-08-27 19:49:36 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:36 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:36 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Controller Class Initialized
ERROR - 2011-08-27 19:49:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 19:49:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 19:49:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:36 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:36 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 19:49:36 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:36 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:36 --> Total execution time: 0.0290
DEBUG - 2011-08-27 19:49:36 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:36 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:36 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:36 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:36 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:36 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:36 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:49:37 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:37 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:37 --> Total execution time: 0.2755
DEBUG - 2011-08-27 19:49:37 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:37 --> Total execution time: 0.6990
DEBUG - 2011-08-27 19:49:40 --> Config Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Hooks Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Utf8 Class Initialized
DEBUG - 2011-08-27 19:49:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 19:49:40 --> URI Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Router Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Output Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Input Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 19:49:40 --> Language Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Loader Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Controller Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Model Class Initialized
DEBUG - 2011-08-27 19:49:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 19:49:40 --> Database Driver Class Initialized
DEBUG - 2011-08-27 19:49:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 19:49:40 --> Helper loaded: url_helper
DEBUG - 2011-08-27 19:49:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 19:49:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 19:49:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 19:49:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 19:49:40 --> Final output sent to browser
DEBUG - 2011-08-27 19:49:40 --> Total execution time: 0.0432
DEBUG - 2011-08-27 20:51:48 --> Config Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Hooks Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Utf8 Class Initialized
DEBUG - 2011-08-27 20:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 20:51:48 --> URI Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Router Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Output Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Input Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 20:51:48 --> Language Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Loader Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Controller Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Model Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Model Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Model Class Initialized
DEBUG - 2011-08-27 20:51:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 20:51:48 --> Database Driver Class Initialized
DEBUG - 2011-08-27 20:51:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 20:51:49 --> Helper loaded: url_helper
DEBUG - 2011-08-27 20:51:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 20:51:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 20:51:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 20:51:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 20:51:49 --> Final output sent to browser
DEBUG - 2011-08-27 20:51:49 --> Total execution time: 0.7513
DEBUG - 2011-08-27 20:51:49 --> Config Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Hooks Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Utf8 Class Initialized
DEBUG - 2011-08-27 20:51:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 20:51:49 --> URI Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Router Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Output Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Input Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 20:51:49 --> Language Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Loader Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Controller Class Initialized
ERROR - 2011-08-27 20:51:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 20:51:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 20:51:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 20:51:49 --> Model Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Model Class Initialized
DEBUG - 2011-08-27 20:51:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 20:51:49 --> Database Driver Class Initialized
DEBUG - 2011-08-27 20:51:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 20:51:50 --> Helper loaded: url_helper
DEBUG - 2011-08-27 20:51:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 20:51:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 20:51:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 20:51:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 20:51:50 --> Final output sent to browser
DEBUG - 2011-08-27 20:51:50 --> Total execution time: 0.1091
DEBUG - 2011-08-27 21:38:33 --> Config Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:38:33 --> URI Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Router Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Output Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Input Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:38:33 --> Language Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Loader Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Controller Class Initialized
ERROR - 2011-08-27 21:38:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 21:38:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 21:38:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 21:38:33 --> Model Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Model Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:38:33 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:38:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 21:38:33 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:38:33 --> Final output sent to browser
DEBUG - 2011-08-27 21:38:33 --> Total execution time: 0.0632
DEBUG - 2011-08-27 21:38:33 --> Config Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:38:33 --> URI Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Router Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Output Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Input Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:38:33 --> Language Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Loader Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Controller Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Model Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Model Class Initialized
DEBUG - 2011-08-27 21:38:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:38:34 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:38:34 --> Final output sent to browser
DEBUG - 2011-08-27 21:38:34 --> Total execution time: 0.6718
DEBUG - 2011-08-27 21:51:05 --> Config Class Initialized
DEBUG - 2011-08-27 21:51:05 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:51:05 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:51:05 --> URI Class Initialized
DEBUG - 2011-08-27 21:51:05 --> Router Class Initialized
ERROR - 2011-08-27 21:51:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-27 21:51:06 --> Config Class Initialized
DEBUG - 2011-08-27 21:51:06 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:51:06 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:51:06 --> URI Class Initialized
DEBUG - 2011-08-27 21:51:06 --> Router Class Initialized
DEBUG - 2011-08-27 21:51:06 --> No URI present. Default controller set.
DEBUG - 2011-08-27 21:51:06 --> Output Class Initialized
DEBUG - 2011-08-27 21:51:06 --> Input Class Initialized
DEBUG - 2011-08-27 21:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:51:06 --> Language Class Initialized
DEBUG - 2011-08-27 21:51:06 --> Loader Class Initialized
DEBUG - 2011-08-27 21:51:06 --> Controller Class Initialized
DEBUG - 2011-08-27 21:51:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-27 21:51:06 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:51:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:51:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:51:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:51:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:51:06 --> Final output sent to browser
DEBUG - 2011-08-27 21:51:06 --> Total execution time: 0.0256
DEBUG - 2011-08-27 21:51:07 --> Config Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:51:07 --> URI Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Router Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Output Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Input Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:51:07 --> Language Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Loader Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Controller Class Initialized
ERROR - 2011-08-27 21:51:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 21:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 21:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 21:51:07 --> Model Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Model Class Initialized
DEBUG - 2011-08-27 21:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:51:07 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 21:51:07 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:51:07 --> Final output sent to browser
DEBUG - 2011-08-27 21:51:07 --> Total execution time: 0.0296
DEBUG - 2011-08-27 21:51:08 --> Config Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:51:08 --> URI Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Router Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Output Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Input Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:51:08 --> Language Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Loader Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Controller Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Model Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Model Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Model Class Initialized
DEBUG - 2011-08-27 21:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:51:08 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:51:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:51:09 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:51:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:51:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:51:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:51:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:51:09 --> Final output sent to browser
DEBUG - 2011-08-27 21:51:09 --> Total execution time: 0.3561
DEBUG - 2011-08-27 21:54:43 --> Config Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:54:43 --> URI Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Router Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Output Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Input Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:54:43 --> Language Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Loader Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Controller Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Model Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Model Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Model Class Initialized
DEBUG - 2011-08-27 21:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:54:43 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:54:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:54:43 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:54:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:54:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:54:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:54:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:54:43 --> Final output sent to browser
DEBUG - 2011-08-27 21:54:43 --> Total execution time: 0.0468
DEBUG - 2011-08-27 21:54:46 --> Config Class Initialized
DEBUG - 2011-08-27 21:54:46 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:54:46 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:54:46 --> URI Class Initialized
DEBUG - 2011-08-27 21:54:46 --> Router Class Initialized
ERROR - 2011-08-27 21:54:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 21:54:54 --> Config Class Initialized
DEBUG - 2011-08-27 21:54:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:54:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:54:54 --> URI Class Initialized
DEBUG - 2011-08-27 21:54:54 --> Router Class Initialized
DEBUG - 2011-08-27 21:54:54 --> Output Class Initialized
DEBUG - 2011-08-27 21:54:54 --> Input Class Initialized
DEBUG - 2011-08-27 21:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:54:54 --> Language Class Initialized
DEBUG - 2011-08-27 21:54:55 --> Loader Class Initialized
DEBUG - 2011-08-27 21:54:55 --> Controller Class Initialized
DEBUG - 2011-08-27 21:54:55 --> Model Class Initialized
DEBUG - 2011-08-27 21:54:55 --> Model Class Initialized
DEBUG - 2011-08-27 21:54:55 --> Model Class Initialized
DEBUG - 2011-08-27 21:54:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:54:55 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:54:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:54:55 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:54:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:54:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:54:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:54:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:54:55 --> Final output sent to browser
DEBUG - 2011-08-27 21:54:55 --> Total execution time: 0.4701
DEBUG - 2011-08-27 21:55:14 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:14 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Router Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Output Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Input Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:55:14 --> Language Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Loader Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Controller Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:55:14 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:55:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:55:15 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:55:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:55:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:55:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:55:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:55:15 --> Final output sent to browser
DEBUG - 2011-08-27 21:55:15 --> Total execution time: 0.5981
DEBUG - 2011-08-27 21:55:28 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:28 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Router Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Output Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Input Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:55:28 --> Language Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Loader Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Controller Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:55:28 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:55:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:55:28 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:55:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:55:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:55:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:55:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:55:28 --> Final output sent to browser
DEBUG - 2011-08-27 21:55:28 --> Total execution time: 0.3597
DEBUG - 2011-08-27 21:55:32 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:32 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Router Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Output Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Input Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:55:32 --> Language Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Loader Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Controller Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:55:32 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:55:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:55:33 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:55:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:55:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:55:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:55:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:55:33 --> Final output sent to browser
DEBUG - 2011-08-27 21:55:33 --> Total execution time: 0.5861
DEBUG - 2011-08-27 21:55:37 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:37 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Router Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Output Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Input Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:55:37 --> Language Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Loader Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Controller Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:55:37 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:55:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:55:37 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:55:37 --> Final output sent to browser
DEBUG - 2011-08-27 21:55:37 --> Total execution time: 0.2671
DEBUG - 2011-08-27 21:55:47 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:47 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Router Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Output Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Input Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:55:47 --> Language Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Loader Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Controller Class Initialized
ERROR - 2011-08-27 21:55:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 21:55:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 21:55:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 21:55:47 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:55:47 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:55:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 21:55:47 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:55:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:55:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:55:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:55:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:55:47 --> Final output sent to browser
DEBUG - 2011-08-27 21:55:47 --> Total execution time: 0.0327
DEBUG - 2011-08-27 21:55:48 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:48 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Router Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Output Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Input Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:55:48 --> Language Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Loader Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Controller Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:55:48 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:55:49 --> Final output sent to browser
DEBUG - 2011-08-27 21:55:49 --> Total execution time: 0.6816
DEBUG - 2011-08-27 21:55:50 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:50 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:50 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:50 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:50 --> Router Class Initialized
ERROR - 2011-08-27 21:55:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 21:55:51 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:51 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:51 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:51 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:51 --> Router Class Initialized
ERROR - 2011-08-27 21:55:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 21:55:51 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:51 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:51 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:51 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:51 --> Router Class Initialized
ERROR - 2011-08-27 21:55:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 21:55:56 --> Config Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:55:56 --> URI Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Router Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Output Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Input Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:55:56 --> Language Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Loader Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Controller Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Model Class Initialized
DEBUG - 2011-08-27 21:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:55:56 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:55:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:55:56 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:55:56 --> Final output sent to browser
DEBUG - 2011-08-27 21:55:56 --> Total execution time: 0.3100
DEBUG - 2011-08-27 21:56:00 --> Config Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:56:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:56:00 --> URI Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Router Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Output Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Input Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:56:00 --> Language Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Loader Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Controller Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:56:00 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:56:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:56:01 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:56:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:56:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:56:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:56:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:56:01 --> Final output sent to browser
DEBUG - 2011-08-27 21:56:01 --> Total execution time: 0.4876
DEBUG - 2011-08-27 21:56:06 --> Config Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:56:06 --> URI Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Router Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Output Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Input Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:56:06 --> Language Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Loader Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Controller Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:56:06 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:56:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:56:06 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:56:06 --> Final output sent to browser
DEBUG - 2011-08-27 21:56:06 --> Total execution time: 0.2488
DEBUG - 2011-08-27 21:56:10 --> Config Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:56:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:56:10 --> URI Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Router Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Output Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Input Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:56:10 --> Language Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Loader Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Controller Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:56:10 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:56:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:56:10 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:56:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:56:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:56:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:56:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:56:10 --> Final output sent to browser
DEBUG - 2011-08-27 21:56:10 --> Total execution time: 0.3452
DEBUG - 2011-08-27 21:56:16 --> Config Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:56:16 --> URI Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Router Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Output Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Input Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:56:16 --> Language Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Loader Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Controller Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:56:16 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:56:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:56:17 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:56:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:56:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:56:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:56:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:56:17 --> Final output sent to browser
DEBUG - 2011-08-27 21:56:17 --> Total execution time: 0.5204
DEBUG - 2011-08-27 21:56:22 --> Config Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:56:22 --> URI Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Router Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Output Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Input Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:56:22 --> Language Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Loader Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Controller Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:56:22 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:56:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:56:22 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:56:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:56:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:56:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:56:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:56:22 --> Final output sent to browser
DEBUG - 2011-08-27 21:56:22 --> Total execution time: 0.3157
DEBUG - 2011-08-27 21:56:39 --> Config Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:56:39 --> URI Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Router Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Output Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Input Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:56:39 --> Language Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Loader Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Controller Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:56:39 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:56:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:56:39 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:56:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:56:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:56:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:56:39 --> Final output sent to browser
DEBUG - 2011-08-27 21:56:39 --> Total execution time: 0.2669
DEBUG - 2011-08-27 21:56:45 --> Config Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:56:45 --> URI Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Router Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Output Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Input Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:56:45 --> Language Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Loader Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Controller Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:56:45 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:56:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:56:45 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:56:45 --> Final output sent to browser
DEBUG - 2011-08-27 21:56:45 --> Total execution time: 0.3163
DEBUG - 2011-08-27 21:56:52 --> Config Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:56:52 --> URI Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Router Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Output Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Input Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:56:52 --> Language Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Loader Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Controller Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Model Class Initialized
DEBUG - 2011-08-27 21:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:56:52 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:56:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:56:52 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:56:52 --> Final output sent to browser
DEBUG - 2011-08-27 21:56:52 --> Total execution time: 0.2612
DEBUG - 2011-08-27 21:57:01 --> Config Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:57:01 --> URI Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Router Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Output Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Input Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:57:01 --> Language Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Loader Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Controller Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:57:01 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:57:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:57:01 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:57:01 --> Final output sent to browser
DEBUG - 2011-08-27 21:57:01 --> Total execution time: 0.6369
DEBUG - 2011-08-27 21:57:02 --> Config Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:57:02 --> URI Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Router Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Output Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Input Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:57:02 --> Language Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Loader Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Controller Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:57:02 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:57:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:57:02 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:57:02 --> Final output sent to browser
DEBUG - 2011-08-27 21:57:02 --> Total execution time: 0.0844
DEBUG - 2011-08-27 21:57:06 --> Config Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:57:06 --> URI Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Router Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Output Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Input Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:57:06 --> Language Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Loader Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Controller Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:57:06 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:57:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:57:06 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:57:06 --> Final output sent to browser
DEBUG - 2011-08-27 21:57:06 --> Total execution time: 0.2827
DEBUG - 2011-08-27 21:57:07 --> Config Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:57:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:57:07 --> URI Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Router Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Output Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Input Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:57:07 --> Language Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Loader Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Controller Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:57:07 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:57:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:57:07 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:57:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:57:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:57:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:57:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:57:07 --> Final output sent to browser
DEBUG - 2011-08-27 21:57:07 --> Total execution time: 0.0674
DEBUG - 2011-08-27 21:57:10 --> Config Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Hooks Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Utf8 Class Initialized
DEBUG - 2011-08-27 21:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 21:57:10 --> URI Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Router Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Output Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Input Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 21:57:10 --> Language Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Loader Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Controller Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Model Class Initialized
DEBUG - 2011-08-27 21:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 21:57:10 --> Database Driver Class Initialized
DEBUG - 2011-08-27 21:57:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-27 21:57:10 --> Helper loaded: url_helper
DEBUG - 2011-08-27 21:57:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 21:57:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 21:57:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 21:57:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 21:57:10 --> Final output sent to browser
DEBUG - 2011-08-27 21:57:10 --> Total execution time: 0.0988
DEBUG - 2011-08-27 23:19:21 --> Config Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:19:21 --> URI Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Router Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Output Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Input Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 23:19:21 --> Language Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Loader Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Controller Class Initialized
ERROR - 2011-08-27 23:19:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 23:19:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 23:19:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 23:19:21 --> Model Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Model Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 23:19:21 --> Database Driver Class Initialized
DEBUG - 2011-08-27 23:19:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 23:19:21 --> Helper loaded: url_helper
DEBUG - 2011-08-27 23:19:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 23:19:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 23:19:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 23:19:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 23:19:21 --> Final output sent to browser
DEBUG - 2011-08-27 23:19:21 --> Total execution time: 0.0980
DEBUG - 2011-08-27 23:19:21 --> Config Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:19:21 --> URI Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Router Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Output Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Input Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 23:19:21 --> Language Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Loader Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Controller Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Model Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Model Class Initialized
DEBUG - 2011-08-27 23:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 23:19:21 --> Database Driver Class Initialized
DEBUG - 2011-08-27 23:19:22 --> Final output sent to browser
DEBUG - 2011-08-27 23:19:22 --> Total execution time: 0.7308
DEBUG - 2011-08-27 23:19:22 --> Config Class Initialized
DEBUG - 2011-08-27 23:19:22 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:19:22 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:19:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:19:22 --> URI Class Initialized
DEBUG - 2011-08-27 23:19:22 --> Router Class Initialized
ERROR - 2011-08-27 23:19:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 23:19:23 --> Config Class Initialized
DEBUG - 2011-08-27 23:19:23 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:19:23 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:19:23 --> URI Class Initialized
DEBUG - 2011-08-27 23:19:23 --> Router Class Initialized
ERROR - 2011-08-27 23:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 23:19:23 --> Config Class Initialized
DEBUG - 2011-08-27 23:19:23 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:19:23 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:19:23 --> URI Class Initialized
DEBUG - 2011-08-27 23:19:23 --> Router Class Initialized
ERROR - 2011-08-27 23:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 23:19:28 --> Config Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:19:28 --> URI Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Router Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Output Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Input Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 23:19:28 --> Language Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Loader Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Controller Class Initialized
ERROR - 2011-08-27 23:19:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 23:19:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 23:19:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 23:19:28 --> Model Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Model Class Initialized
DEBUG - 2011-08-27 23:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 23:19:28 --> Database Driver Class Initialized
DEBUG - 2011-08-27 23:19:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 23:19:28 --> Helper loaded: url_helper
DEBUG - 2011-08-27 23:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 23:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 23:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 23:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 23:19:28 --> Final output sent to browser
DEBUG - 2011-08-27 23:19:28 --> Total execution time: 0.0284
DEBUG - 2011-08-27 23:19:29 --> Config Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:19:29 --> URI Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Router Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Output Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Input Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 23:19:29 --> Language Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Loader Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Controller Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Model Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Model Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 23:19:29 --> Database Driver Class Initialized
DEBUG - 2011-08-27 23:19:29 --> Final output sent to browser
DEBUG - 2011-08-27 23:19:29 --> Total execution time: 0.5665
DEBUG - 2011-08-27 23:56:52 --> Config Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:56:52 --> URI Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Router Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Output Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Input Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 23:56:52 --> Language Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Loader Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Controller Class Initialized
ERROR - 2011-08-27 23:56:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-27 23:56:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-27 23:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 23:56:52 --> Model Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Model Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 23:56:52 --> Database Driver Class Initialized
DEBUG - 2011-08-27 23:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-27 23:56:52 --> Helper loaded: url_helper
DEBUG - 2011-08-27 23:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-27 23:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-27 23:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-27 23:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-27 23:56:52 --> Final output sent to browser
DEBUG - 2011-08-27 23:56:52 --> Total execution time: 0.0304
DEBUG - 2011-08-27 23:56:52 --> Config Class Initialized
DEBUG - 2011-08-27 23:56:52 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:56:53 --> URI Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Router Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Output Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Input Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-27 23:56:53 --> Language Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Loader Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Controller Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Model Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Model Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-27 23:56:53 --> Database Driver Class Initialized
DEBUG - 2011-08-27 23:56:53 --> Final output sent to browser
DEBUG - 2011-08-27 23:56:53 --> Total execution time: 0.6651
DEBUG - 2011-08-27 23:56:54 --> Config Class Initialized
DEBUG - 2011-08-27 23:56:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:56:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:56:54 --> URI Class Initialized
DEBUG - 2011-08-27 23:56:54 --> Router Class Initialized
ERROR - 2011-08-27 23:56:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-27 23:56:54 --> Config Class Initialized
DEBUG - 2011-08-27 23:56:54 --> Hooks Class Initialized
DEBUG - 2011-08-27 23:56:54 --> Utf8 Class Initialized
DEBUG - 2011-08-27 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-27 23:56:54 --> URI Class Initialized
DEBUG - 2011-08-27 23:56:54 --> Router Class Initialized
ERROR - 2011-08-27 23:56:54 --> 404 Page Not Found --> favicon.ico

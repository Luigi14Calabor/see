<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-24 01:10:19 --> Config Class Initialized
DEBUG - 2011-06-24 01:10:19 --> Hooks Class Initialized
DEBUG - 2011-06-24 01:10:19 --> Utf8 Class Initialized
DEBUG - 2011-06-24 01:10:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 01:10:19 --> URI Class Initialized
DEBUG - 2011-06-24 01:10:19 --> Router Class Initialized
ERROR - 2011-06-24 01:10:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-24 01:10:20 --> Config Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Hooks Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Utf8 Class Initialized
DEBUG - 2011-06-24 01:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 01:10:20 --> URI Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Router Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Output Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Input Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 01:10:20 --> Language Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Loader Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Controller Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Model Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Model Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Model Class Initialized
DEBUG - 2011-06-24 01:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 01:10:21 --> Database Driver Class Initialized
DEBUG - 2011-06-24 01:10:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 01:10:22 --> Helper loaded: url_helper
DEBUG - 2011-06-24 01:10:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 01:10:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 01:10:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 01:10:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 01:10:22 --> Final output sent to browser
DEBUG - 2011-06-24 01:10:22 --> Total execution time: 2.0971
DEBUG - 2011-06-24 01:10:52 --> Config Class Initialized
DEBUG - 2011-06-24 01:10:52 --> Hooks Class Initialized
DEBUG - 2011-06-24 01:10:52 --> Utf8 Class Initialized
DEBUG - 2011-06-24 01:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 01:10:52 --> URI Class Initialized
DEBUG - 2011-06-24 01:10:52 --> Router Class Initialized
DEBUG - 2011-06-24 01:10:53 --> Output Class Initialized
DEBUG - 2011-06-24 01:10:53 --> Input Class Initialized
DEBUG - 2011-06-24 01:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 01:10:53 --> Language Class Initialized
DEBUG - 2011-06-24 01:10:53 --> Loader Class Initialized
DEBUG - 2011-06-24 01:10:53 --> Controller Class Initialized
ERROR - 2011-06-24 01:10:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 01:10:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 01:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 01:10:53 --> Model Class Initialized
DEBUG - 2011-06-24 01:10:53 --> Model Class Initialized
DEBUG - 2011-06-24 01:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 01:10:53 --> Database Driver Class Initialized
DEBUG - 2011-06-24 01:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 01:10:53 --> Helper loaded: url_helper
DEBUG - 2011-06-24 01:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 01:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 01:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 01:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 01:10:53 --> Final output sent to browser
DEBUG - 2011-06-24 01:10:53 --> Total execution time: 0.3892
DEBUG - 2011-06-24 01:26:46 --> Config Class Initialized
DEBUG - 2011-06-24 01:26:46 --> Hooks Class Initialized
DEBUG - 2011-06-24 01:26:46 --> Utf8 Class Initialized
DEBUG - 2011-06-24 01:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 01:26:46 --> URI Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Router Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Output Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Input Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 01:26:47 --> Language Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Loader Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Controller Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Model Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Model Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Model Class Initialized
DEBUG - 2011-06-24 01:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 01:26:47 --> Database Driver Class Initialized
DEBUG - 2011-06-24 01:26:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 01:26:47 --> Helper loaded: url_helper
DEBUG - 2011-06-24 01:26:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 01:26:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 01:26:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 01:26:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 01:26:47 --> Final output sent to browser
DEBUG - 2011-06-24 01:26:47 --> Total execution time: 0.2157
DEBUG - 2011-06-24 01:26:49 --> Config Class Initialized
DEBUG - 2011-06-24 01:26:49 --> Hooks Class Initialized
DEBUG - 2011-06-24 01:26:49 --> Utf8 Class Initialized
DEBUG - 2011-06-24 01:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 01:26:49 --> URI Class Initialized
DEBUG - 2011-06-24 01:26:49 --> Router Class Initialized
ERROR - 2011-06-24 01:26:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-24 02:00:03 --> Config Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Hooks Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Utf8 Class Initialized
DEBUG - 2011-06-24 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 02:00:03 --> URI Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Router Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Output Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Input Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 02:00:03 --> Language Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Loader Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Controller Class Initialized
ERROR - 2011-06-24 02:00:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 02:00:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 02:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 02:00:03 --> Model Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Model Class Initialized
DEBUG - 2011-06-24 02:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 02:00:03 --> Database Driver Class Initialized
DEBUG - 2011-06-24 02:00:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 02:00:05 --> Helper loaded: url_helper
DEBUG - 2011-06-24 02:00:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 02:00:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 02:00:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 02:00:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 02:00:05 --> Final output sent to browser
DEBUG - 2011-06-24 02:00:05 --> Total execution time: 2.4917
DEBUG - 2011-06-24 04:44:06 --> Config Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Hooks Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Utf8 Class Initialized
DEBUG - 2011-06-24 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 04:44:06 --> URI Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Router Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Output Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Input Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 04:44:06 --> Language Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Loader Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Controller Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Model Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Model Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Model Class Initialized
DEBUG - 2011-06-24 04:44:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 04:44:06 --> Database Driver Class Initialized
DEBUG - 2011-06-24 04:44:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 04:44:10 --> Helper loaded: url_helper
DEBUG - 2011-06-24 04:44:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 04:44:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 04:44:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 04:44:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 04:44:10 --> Final output sent to browser
DEBUG - 2011-06-24 04:44:10 --> Total execution time: 3.6048
DEBUG - 2011-06-24 04:55:08 --> Config Class Initialized
DEBUG - 2011-06-24 04:55:08 --> Hooks Class Initialized
DEBUG - 2011-06-24 04:55:08 --> Utf8 Class Initialized
DEBUG - 2011-06-24 04:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 04:55:08 --> URI Class Initialized
DEBUG - 2011-06-24 04:55:08 --> Router Class Initialized
DEBUG - 2011-06-24 04:55:08 --> No URI present. Default controller set.
DEBUG - 2011-06-24 04:55:08 --> Output Class Initialized
DEBUG - 2011-06-24 04:55:08 --> Input Class Initialized
DEBUG - 2011-06-24 04:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 04:55:08 --> Language Class Initialized
DEBUG - 2011-06-24 04:55:08 --> Loader Class Initialized
DEBUG - 2011-06-24 04:55:08 --> Controller Class Initialized
DEBUG - 2011-06-24 04:55:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-24 04:55:08 --> Helper loaded: url_helper
DEBUG - 2011-06-24 04:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 04:55:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 04:55:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 04:55:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 04:55:08 --> Final output sent to browser
DEBUG - 2011-06-24 04:55:08 --> Total execution time: 0.4389
DEBUG - 2011-06-24 07:23:56 --> Config Class Initialized
DEBUG - 2011-06-24 07:23:56 --> Hooks Class Initialized
DEBUG - 2011-06-24 07:23:56 --> Utf8 Class Initialized
DEBUG - 2011-06-24 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 07:23:56 --> URI Class Initialized
DEBUG - 2011-06-24 07:23:56 --> Router Class Initialized
ERROR - 2011-06-24 07:23:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-24 09:44:52 --> Config Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Hooks Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Utf8 Class Initialized
DEBUG - 2011-06-24 09:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 09:44:52 --> URI Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Router Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Output Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Input Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 09:44:52 --> Language Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Loader Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Controller Class Initialized
DEBUG - 2011-06-24 09:44:52 --> Model Class Initialized
DEBUG - 2011-06-24 09:44:53 --> Model Class Initialized
DEBUG - 2011-06-24 09:44:53 --> Model Class Initialized
DEBUG - 2011-06-24 09:44:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 09:44:53 --> Database Driver Class Initialized
DEBUG - 2011-06-24 09:44:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 09:44:54 --> Helper loaded: url_helper
DEBUG - 2011-06-24 09:44:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 09:44:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 09:44:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 09:44:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 09:44:54 --> Final output sent to browser
DEBUG - 2011-06-24 09:44:54 --> Total execution time: 1.5192
DEBUG - 2011-06-24 09:44:55 --> Config Class Initialized
DEBUG - 2011-06-24 09:44:55 --> Hooks Class Initialized
DEBUG - 2011-06-24 09:44:55 --> Utf8 Class Initialized
DEBUG - 2011-06-24 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 09:44:55 --> URI Class Initialized
DEBUG - 2011-06-24 09:44:55 --> Router Class Initialized
DEBUG - 2011-06-24 09:44:56 --> Output Class Initialized
DEBUG - 2011-06-24 09:44:56 --> Input Class Initialized
DEBUG - 2011-06-24 09:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 09:44:56 --> Language Class Initialized
DEBUG - 2011-06-24 09:44:56 --> Loader Class Initialized
DEBUG - 2011-06-24 09:44:56 --> Controller Class Initialized
ERROR - 2011-06-24 09:44:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 09:44:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 09:44:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 09:44:56 --> Model Class Initialized
DEBUG - 2011-06-24 09:44:56 --> Model Class Initialized
DEBUG - 2011-06-24 09:44:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 09:44:56 --> Database Driver Class Initialized
DEBUG - 2011-06-24 09:44:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 09:44:56 --> Helper loaded: url_helper
DEBUG - 2011-06-24 09:44:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 09:44:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 09:44:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 09:44:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 09:44:56 --> Final output sent to browser
DEBUG - 2011-06-24 09:44:56 --> Total execution time: 0.1057
DEBUG - 2011-06-24 11:00:02 --> Config Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Hooks Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Utf8 Class Initialized
DEBUG - 2011-06-24 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 11:00:02 --> URI Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Router Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Output Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Input Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 11:00:02 --> Language Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Loader Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Controller Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Model Class Initialized
DEBUG - 2011-06-24 11:00:02 --> Model Class Initialized
DEBUG - 2011-06-24 11:00:03 --> Model Class Initialized
DEBUG - 2011-06-24 11:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 11:00:03 --> Database Driver Class Initialized
DEBUG - 2011-06-24 11:00:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 11:00:09 --> Helper loaded: url_helper
DEBUG - 2011-06-24 11:00:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 11:00:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 11:00:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 11:00:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 11:00:09 --> Final output sent to browser
DEBUG - 2011-06-24 11:00:09 --> Total execution time: 6.5052
DEBUG - 2011-06-24 11:00:10 --> Config Class Initialized
DEBUG - 2011-06-24 11:00:10 --> Hooks Class Initialized
DEBUG - 2011-06-24 11:00:10 --> Utf8 Class Initialized
DEBUG - 2011-06-24 11:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 11:00:10 --> URI Class Initialized
DEBUG - 2011-06-24 11:00:10 --> Router Class Initialized
DEBUG - 2011-06-24 11:00:10 --> Output Class Initialized
DEBUG - 2011-06-24 11:00:10 --> Input Class Initialized
DEBUG - 2011-06-24 11:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 11:00:10 --> Language Class Initialized
DEBUG - 2011-06-24 11:00:10 --> Loader Class Initialized
DEBUG - 2011-06-24 11:00:10 --> Controller Class Initialized
ERROR - 2011-06-24 11:00:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 11:00:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 11:00:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 11:00:11 --> Model Class Initialized
DEBUG - 2011-06-24 11:00:11 --> Model Class Initialized
DEBUG - 2011-06-24 11:00:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 11:00:11 --> Database Driver Class Initialized
DEBUG - 2011-06-24 11:00:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 11:00:11 --> Helper loaded: url_helper
DEBUG - 2011-06-24 11:00:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 11:00:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 11:00:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 11:00:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 11:00:11 --> Final output sent to browser
DEBUG - 2011-06-24 11:00:11 --> Total execution time: 0.5162
DEBUG - 2011-06-24 12:14:47 --> Config Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Hooks Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Utf8 Class Initialized
DEBUG - 2011-06-24 12:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 12:14:47 --> URI Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Router Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Output Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Input Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 12:14:47 --> Language Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Loader Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Controller Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Model Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Model Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Model Class Initialized
DEBUG - 2011-06-24 12:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 12:14:47 --> Database Driver Class Initialized
DEBUG - 2011-06-24 12:14:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 12:14:48 --> Helper loaded: url_helper
DEBUG - 2011-06-24 12:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 12:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 12:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 12:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 12:14:48 --> Final output sent to browser
DEBUG - 2011-06-24 12:14:48 --> Total execution time: 0.8549
DEBUG - 2011-06-24 12:14:49 --> Config Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Hooks Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Utf8 Class Initialized
DEBUG - 2011-06-24 12:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 12:14:49 --> URI Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Router Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Output Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Input Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 12:14:49 --> Language Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Loader Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Controller Class Initialized
ERROR - 2011-06-24 12:14:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 12:14:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 12:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 12:14:49 --> Model Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Model Class Initialized
DEBUG - 2011-06-24 12:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 12:14:49 --> Database Driver Class Initialized
DEBUG - 2011-06-24 12:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 12:14:49 --> Helper loaded: url_helper
DEBUG - 2011-06-24 12:14:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 12:14:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 12:14:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 12:14:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 12:14:49 --> Final output sent to browser
DEBUG - 2011-06-24 12:14:49 --> Total execution time: 0.1860
DEBUG - 2011-06-24 13:30:23 --> Config Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Hooks Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Utf8 Class Initialized
DEBUG - 2011-06-24 13:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 13:30:23 --> URI Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Router Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Output Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Input Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 13:30:23 --> Language Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Loader Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Controller Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Model Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Model Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Model Class Initialized
DEBUG - 2011-06-24 13:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 13:30:23 --> Database Driver Class Initialized
DEBUG - 2011-06-24 13:30:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 13:30:23 --> Helper loaded: url_helper
DEBUG - 2011-06-24 13:30:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 13:30:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 13:30:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 13:30:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 13:30:23 --> Final output sent to browser
DEBUG - 2011-06-24 13:30:23 --> Total execution time: 0.7155
DEBUG - 2011-06-24 13:30:24 --> Config Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Hooks Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Utf8 Class Initialized
DEBUG - 2011-06-24 13:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 13:30:24 --> URI Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Router Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Output Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Input Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 13:30:24 --> Language Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Loader Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Controller Class Initialized
ERROR - 2011-06-24 13:30:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 13:30:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 13:30:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 13:30:24 --> Model Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Model Class Initialized
DEBUG - 2011-06-24 13:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 13:30:24 --> Database Driver Class Initialized
DEBUG - 2011-06-24 13:30:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 13:30:24 --> Helper loaded: url_helper
DEBUG - 2011-06-24 13:30:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 13:30:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 13:30:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 13:30:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 13:30:24 --> Final output sent to browser
DEBUG - 2011-06-24 13:30:24 --> Total execution time: 0.1771
DEBUG - 2011-06-24 13:37:21 --> Config Class Initialized
DEBUG - 2011-06-24 13:37:21 --> Hooks Class Initialized
DEBUG - 2011-06-24 13:37:21 --> Utf8 Class Initialized
DEBUG - 2011-06-24 13:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 13:37:21 --> URI Class Initialized
DEBUG - 2011-06-24 13:37:21 --> Router Class Initialized
ERROR - 2011-06-24 13:37:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-24 13:37:22 --> Config Class Initialized
DEBUG - 2011-06-24 13:37:22 --> Hooks Class Initialized
DEBUG - 2011-06-24 13:37:22 --> Utf8 Class Initialized
DEBUG - 2011-06-24 13:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 13:37:22 --> URI Class Initialized
DEBUG - 2011-06-24 13:37:22 --> Router Class Initialized
DEBUG - 2011-06-24 13:37:22 --> No URI present. Default controller set.
DEBUG - 2011-06-24 13:37:22 --> Output Class Initialized
DEBUG - 2011-06-24 13:37:22 --> Input Class Initialized
DEBUG - 2011-06-24 13:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 13:37:22 --> Language Class Initialized
DEBUG - 2011-06-24 13:37:22 --> Loader Class Initialized
DEBUG - 2011-06-24 13:37:22 --> Controller Class Initialized
DEBUG - 2011-06-24 13:37:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-24 13:37:22 --> Helper loaded: url_helper
DEBUG - 2011-06-24 13:37:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 13:37:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 13:37:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 13:37:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 13:37:22 --> Final output sent to browser
DEBUG - 2011-06-24 13:37:22 --> Total execution time: 0.0614
DEBUG - 2011-06-24 14:44:48 --> Config Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Hooks Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Utf8 Class Initialized
DEBUG - 2011-06-24 14:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 14:44:48 --> URI Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Router Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Output Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Input Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 14:44:48 --> Language Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Loader Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Controller Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Model Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Model Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Model Class Initialized
DEBUG - 2011-06-24 14:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 14:44:49 --> Database Driver Class Initialized
DEBUG - 2011-06-24 14:44:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 14:44:49 --> Helper loaded: url_helper
DEBUG - 2011-06-24 14:44:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 14:44:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 14:44:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 14:44:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 14:44:49 --> Final output sent to browser
DEBUG - 2011-06-24 14:44:49 --> Total execution time: 1.3027
DEBUG - 2011-06-24 14:45:04 --> Config Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Hooks Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Utf8 Class Initialized
DEBUG - 2011-06-24 14:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 14:45:04 --> URI Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Router Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Output Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Input Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 14:45:04 --> Language Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Loader Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Controller Class Initialized
ERROR - 2011-06-24 14:45:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 14:45:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 14:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 14:45:04 --> Model Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Model Class Initialized
DEBUG - 2011-06-24 14:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 14:45:04 --> Database Driver Class Initialized
DEBUG - 2011-06-24 14:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 14:45:04 --> Helper loaded: url_helper
DEBUG - 2011-06-24 14:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 14:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 14:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 14:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 14:45:04 --> Final output sent to browser
DEBUG - 2011-06-24 14:45:04 --> Total execution time: 0.1226
DEBUG - 2011-06-24 14:57:46 --> Config Class Initialized
DEBUG - 2011-06-24 14:57:46 --> Hooks Class Initialized
DEBUG - 2011-06-24 14:57:46 --> Utf8 Class Initialized
DEBUG - 2011-06-24 14:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 14:57:46 --> URI Class Initialized
DEBUG - 2011-06-24 14:57:46 --> Router Class Initialized
DEBUG - 2011-06-24 14:57:46 --> No URI present. Default controller set.
DEBUG - 2011-06-24 14:57:46 --> Output Class Initialized
DEBUG - 2011-06-24 14:57:46 --> Input Class Initialized
DEBUG - 2011-06-24 14:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 14:57:46 --> Language Class Initialized
DEBUG - 2011-06-24 14:57:46 --> Loader Class Initialized
DEBUG - 2011-06-24 14:57:46 --> Controller Class Initialized
DEBUG - 2011-06-24 14:57:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-24 14:57:46 --> Helper loaded: url_helper
DEBUG - 2011-06-24 14:57:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 14:57:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 14:57:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 14:57:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 14:57:46 --> Final output sent to browser
DEBUG - 2011-06-24 14:57:46 --> Total execution time: 0.0681
DEBUG - 2011-06-24 15:03:26 --> Config Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Hooks Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Utf8 Class Initialized
DEBUG - 2011-06-24 15:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 15:03:26 --> URI Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Router Class Initialized
ERROR - 2011-06-24 15:03:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-24 15:03:26 --> Config Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Hooks Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Utf8 Class Initialized
DEBUG - 2011-06-24 15:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 15:03:26 --> URI Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Router Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Output Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Input Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 15:03:26 --> Language Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Loader Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Controller Class Initialized
ERROR - 2011-06-24 15:03:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 15:03:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 15:03:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 15:03:26 --> Model Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Model Class Initialized
DEBUG - 2011-06-24 15:03:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 15:03:26 --> Database Driver Class Initialized
DEBUG - 2011-06-24 15:03:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 15:03:26 --> Helper loaded: url_helper
DEBUG - 2011-06-24 15:03:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 15:03:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 15:03:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 15:03:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 15:03:26 --> Final output sent to browser
DEBUG - 2011-06-24 15:03:26 --> Total execution time: 0.0558
DEBUG - 2011-06-24 15:03:37 --> Config Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Hooks Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Utf8 Class Initialized
DEBUG - 2011-06-24 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 15:03:37 --> URI Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Router Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Output Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Input Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 15:03:37 --> Language Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Loader Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Controller Class Initialized
ERROR - 2011-06-24 15:03:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 15:03:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 15:03:37 --> Model Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Model Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 15:03:37 --> Config Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Hooks Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Utf8 Class Initialized
DEBUG - 2011-06-24 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 15:03:37 --> URI Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Router Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Database Driver Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Output Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Input Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 15:03:37 --> Language Class Initialized
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 15:03:37 --> Helper loaded: url_helper
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 15:03:37 --> Final output sent to browser
DEBUG - 2011-06-24 15:03:37 --> Total execution time: 0.0286
DEBUG - 2011-06-24 15:03:37 --> Loader Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Controller Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Model Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Model Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Model Class Initialized
DEBUG - 2011-06-24 15:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 15:03:37 --> Database Driver Class Initialized
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 15:03:37 --> Helper loaded: url_helper
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 15:03:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 15:03:37 --> Final output sent to browser
DEBUG - 2011-06-24 15:03:37 --> Total execution time: 0.0850
DEBUG - 2011-06-24 15:37:18 --> Config Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Hooks Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Utf8 Class Initialized
DEBUG - 2011-06-24 15:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 15:37:18 --> URI Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Router Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Output Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Input Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 15:37:18 --> Language Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Loader Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Controller Class Initialized
ERROR - 2011-06-24 15:37:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 15:37:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 15:37:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 15:37:18 --> Model Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Model Class Initialized
DEBUG - 2011-06-24 15:37:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 15:37:18 --> Database Driver Class Initialized
DEBUG - 2011-06-24 15:37:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 15:37:18 --> Helper loaded: url_helper
DEBUG - 2011-06-24 15:37:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 15:37:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 15:37:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 15:37:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 15:37:18 --> Final output sent to browser
DEBUG - 2011-06-24 15:37:18 --> Total execution time: 0.2331
DEBUG - 2011-06-24 15:55:56 --> Config Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Hooks Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Utf8 Class Initialized
DEBUG - 2011-06-24 15:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 15:55:56 --> URI Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Router Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Output Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Input Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 15:55:56 --> Language Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Loader Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Controller Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Model Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Model Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Model Class Initialized
DEBUG - 2011-06-24 15:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 15:55:56 --> Database Driver Class Initialized
DEBUG - 2011-06-24 15:55:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 15:55:57 --> Helper loaded: url_helper
DEBUG - 2011-06-24 15:55:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 15:55:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 15:55:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 15:55:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 15:55:57 --> Final output sent to browser
DEBUG - 2011-06-24 15:55:57 --> Total execution time: 0.7270
DEBUG - 2011-06-24 15:56:03 --> Config Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Hooks Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Utf8 Class Initialized
DEBUG - 2011-06-24 15:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 15:56:03 --> URI Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Router Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Output Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Input Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 15:56:03 --> Language Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Loader Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Controller Class Initialized
ERROR - 2011-06-24 15:56:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 15:56:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 15:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 15:56:03 --> Model Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Model Class Initialized
DEBUG - 2011-06-24 15:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 15:56:03 --> Database Driver Class Initialized
DEBUG - 2011-06-24 15:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 15:56:03 --> Helper loaded: url_helper
DEBUG - 2011-06-24 15:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 15:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 15:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 15:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 15:56:03 --> Final output sent to browser
DEBUG - 2011-06-24 15:56:03 --> Total execution time: 0.0483
DEBUG - 2011-06-24 18:18:14 --> Config Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Hooks Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Utf8 Class Initialized
DEBUG - 2011-06-24 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 18:18:14 --> URI Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Router Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Output Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Input Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 18:18:14 --> Language Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Loader Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Controller Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Model Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Model Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Model Class Initialized
DEBUG - 2011-06-24 18:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 18:18:14 --> Database Driver Class Initialized
DEBUG - 2011-06-24 18:18:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 18:18:14 --> Helper loaded: url_helper
DEBUG - 2011-06-24 18:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 18:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 18:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 18:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 18:18:14 --> Final output sent to browser
DEBUG - 2011-06-24 18:18:14 --> Total execution time: 0.6396
DEBUG - 2011-06-24 19:37:46 --> Config Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Hooks Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Utf8 Class Initialized
DEBUG - 2011-06-24 19:37:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 19:37:46 --> URI Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Router Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Output Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Input Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 19:37:46 --> Language Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Loader Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Controller Class Initialized
ERROR - 2011-06-24 19:37:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 19:37:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 19:37:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 19:37:46 --> Model Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Model Class Initialized
DEBUG - 2011-06-24 19:37:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 19:37:46 --> Database Driver Class Initialized
DEBUG - 2011-06-24 19:37:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 19:37:46 --> Helper loaded: url_helper
DEBUG - 2011-06-24 19:37:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 19:37:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 19:37:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 19:37:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 19:37:46 --> Final output sent to browser
DEBUG - 2011-06-24 19:37:46 --> Total execution time: 0.3656
DEBUG - 2011-06-24 19:37:50 --> Config Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Hooks Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Utf8 Class Initialized
DEBUG - 2011-06-24 19:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 19:37:50 --> URI Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Router Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Output Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Input Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 19:37:50 --> Language Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Loader Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Controller Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Model Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Model Class Initialized
DEBUG - 2011-06-24 19:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 19:37:50 --> Database Driver Class Initialized
DEBUG - 2011-06-24 19:37:51 --> Final output sent to browser
DEBUG - 2011-06-24 19:37:51 --> Total execution time: 0.7296
DEBUG - 2011-06-24 19:37:52 --> Config Class Initialized
DEBUG - 2011-06-24 19:37:52 --> Hooks Class Initialized
DEBUG - 2011-06-24 19:37:52 --> Utf8 Class Initialized
DEBUG - 2011-06-24 19:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 19:37:52 --> URI Class Initialized
DEBUG - 2011-06-24 19:37:52 --> Router Class Initialized
ERROR - 2011-06-24 19:37:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-24 19:38:57 --> Config Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Hooks Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Utf8 Class Initialized
DEBUG - 2011-06-24 19:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 19:38:57 --> URI Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Router Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Output Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Input Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 19:38:57 --> Language Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Loader Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Controller Class Initialized
ERROR - 2011-06-24 19:38:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 19:38:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 19:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 19:38:57 --> Model Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Model Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 19:38:57 --> Database Driver Class Initialized
DEBUG - 2011-06-24 19:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 19:38:57 --> Helper loaded: url_helper
DEBUG - 2011-06-24 19:38:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 19:38:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 19:38:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 19:38:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 19:38:57 --> Final output sent to browser
DEBUG - 2011-06-24 19:38:57 --> Total execution time: 0.0289
DEBUG - 2011-06-24 19:38:57 --> Config Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Hooks Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Utf8 Class Initialized
DEBUG - 2011-06-24 19:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 19:38:57 --> URI Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Router Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Output Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Input Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 19:38:57 --> Language Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Loader Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Controller Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Model Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Model Class Initialized
DEBUG - 2011-06-24 19:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 19:38:57 --> Database Driver Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Config Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Hooks Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Utf8 Class Initialized
DEBUG - 2011-06-24 19:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 19:38:58 --> URI Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Router Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Output Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Input Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 19:38:58 --> Language Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Loader Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Controller Class Initialized
ERROR - 2011-06-24 19:38:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-24 19:38:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-24 19:38:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 19:38:58 --> Model Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Model Class Initialized
DEBUG - 2011-06-24 19:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 19:38:58 --> Database Driver Class Initialized
DEBUG - 2011-06-24 19:38:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-24 19:38:58 --> Helper loaded: url_helper
DEBUG - 2011-06-24 19:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 19:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 19:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 19:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 19:38:58 --> Final output sent to browser
DEBUG - 2011-06-24 19:38:58 --> Total execution time: 0.0298
DEBUG - 2011-06-24 19:38:58 --> Final output sent to browser
DEBUG - 2011-06-24 19:38:58 --> Total execution time: 0.6522
DEBUG - 2011-06-24 21:39:05 --> Config Class Initialized
DEBUG - 2011-06-24 21:39:05 --> Hooks Class Initialized
DEBUG - 2011-06-24 21:39:05 --> Utf8 Class Initialized
DEBUG - 2011-06-24 21:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 21:39:05 --> URI Class Initialized
DEBUG - 2011-06-24 21:39:05 --> Router Class Initialized
ERROR - 2011-06-24 21:39:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-24 21:39:08 --> Config Class Initialized
DEBUG - 2011-06-24 21:39:08 --> Hooks Class Initialized
DEBUG - 2011-06-24 21:39:08 --> Utf8 Class Initialized
DEBUG - 2011-06-24 21:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 21:39:08 --> URI Class Initialized
DEBUG - 2011-06-24 21:39:08 --> Router Class Initialized
DEBUG - 2011-06-24 21:39:08 --> No URI present. Default controller set.
DEBUG - 2011-06-24 21:39:08 --> Output Class Initialized
DEBUG - 2011-06-24 21:39:08 --> Input Class Initialized
DEBUG - 2011-06-24 21:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 21:39:08 --> Language Class Initialized
DEBUG - 2011-06-24 21:39:08 --> Loader Class Initialized
DEBUG - 2011-06-24 21:39:08 --> Controller Class Initialized
DEBUG - 2011-06-24 21:39:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-24 21:39:08 --> Helper loaded: url_helper
DEBUG - 2011-06-24 21:39:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 21:39:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 21:39:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 21:39:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 21:39:08 --> Final output sent to browser
DEBUG - 2011-06-24 21:39:08 --> Total execution time: 0.1763
DEBUG - 2011-06-24 22:30:13 --> Config Class Initialized
DEBUG - 2011-06-24 22:30:13 --> Hooks Class Initialized
DEBUG - 2011-06-24 22:30:13 --> Utf8 Class Initialized
DEBUG - 2011-06-24 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 22:30:13 --> URI Class Initialized
DEBUG - 2011-06-24 22:30:13 --> Router Class Initialized
DEBUG - 2011-06-24 22:30:13 --> No URI present. Default controller set.
DEBUG - 2011-06-24 22:30:13 --> Output Class Initialized
DEBUG - 2011-06-24 22:30:13 --> Input Class Initialized
DEBUG - 2011-06-24 22:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 22:30:13 --> Language Class Initialized
DEBUG - 2011-06-24 22:30:13 --> Loader Class Initialized
DEBUG - 2011-06-24 22:30:13 --> Controller Class Initialized
DEBUG - 2011-06-24 22:30:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-24 22:30:13 --> Helper loaded: url_helper
DEBUG - 2011-06-24 22:30:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 22:30:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 22:30:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 22:30:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 22:30:13 --> Final output sent to browser
DEBUG - 2011-06-24 22:30:13 --> Total execution time: 0.1831
DEBUG - 2011-06-24 23:35:02 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:02 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:02 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:02 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:02 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:02 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:03 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:03 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:03 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:03 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:03 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:03 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:03 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:03 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:03 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:03 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:03 --> Total execution time: 0.8010
DEBUG - 2011-06-24 23:35:05 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:05 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:05 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:05 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:05 --> Router Class Initialized
ERROR - 2011-06-24 23:35:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-24 23:35:08 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:08 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:08 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:08 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:08 --> Router Class Initialized
ERROR - 2011-06-24 23:35:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-24 23:35:12 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:12 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:12 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:12 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:12 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:12 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:12 --> Total execution time: 0.2468
DEBUG - 2011-06-24 23:35:15 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:15 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:15 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:15 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:15 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:15 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:15 --> Total execution time: 0.0422
DEBUG - 2011-06-24 23:35:18 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:18 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:18 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:18 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:19 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:19 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:19 --> Total execution time: 0.3611
DEBUG - 2011-06-24 23:35:22 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:22 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:22 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:22 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:22 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:22 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:22 --> Total execution time: 0.0431
DEBUG - 2011-06-24 23:35:30 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:30 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:30 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:30 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:30 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:30 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:30 --> Total execution time: 0.2000
DEBUG - 2011-06-24 23:35:37 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:37 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:37 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:37 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:38 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:38 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:38 --> Total execution time: 0.6132
DEBUG - 2011-06-24 23:35:46 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:46 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:46 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:46 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:46 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:46 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:46 --> Total execution time: 0.3643
DEBUG - 2011-06-24 23:35:56 --> Config Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:35:56 --> URI Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Router Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Output Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Input Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:35:56 --> Language Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Loader Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Controller Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Model Class Initialized
DEBUG - 2011-06-24 23:35:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:35:56 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:35:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:35:56 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:35:56 --> Final output sent to browser
DEBUG - 2011-06-24 23:35:56 --> Total execution time: 0.0500
DEBUG - 2011-06-24 23:36:03 --> Config Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:36:03 --> URI Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Router Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Output Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Input Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:36:03 --> Language Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Loader Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Controller Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:36:04 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:36:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:36:04 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:36:04 --> Final output sent to browser
DEBUG - 2011-06-24 23:36:04 --> Total execution time: 0.8053
DEBUG - 2011-06-24 23:36:05 --> Config Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:36:05 --> URI Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Router Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Output Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Input Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:36:05 --> Language Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Loader Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Controller Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:36:05 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:36:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:36:05 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:36:05 --> Final output sent to browser
DEBUG - 2011-06-24 23:36:05 --> Total execution time: 0.0522
DEBUG - 2011-06-24 23:36:06 --> Config Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:36:06 --> URI Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Router Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Output Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Input Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:36:06 --> Language Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Loader Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Controller Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Model Class Initialized
DEBUG - 2011-06-24 23:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:36:06 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:36:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:36:06 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:36:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:36:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:36:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:36:06 --> Final output sent to browser
DEBUG - 2011-06-24 23:36:06 --> Total execution time: 0.0566
DEBUG - 2011-06-24 23:48:45 --> Config Class Initialized
DEBUG - 2011-06-24 23:48:45 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:48:45 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:48:45 --> URI Class Initialized
DEBUG - 2011-06-24 23:48:45 --> Router Class Initialized
ERROR - 2011-06-24 23:48:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-24 23:49:36 --> Config Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Hooks Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Utf8 Class Initialized
DEBUG - 2011-06-24 23:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-24 23:49:36 --> URI Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Router Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Output Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Input Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-24 23:49:36 --> Language Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Loader Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Controller Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Model Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Model Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Model Class Initialized
DEBUG - 2011-06-24 23:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-24 23:49:36 --> Database Driver Class Initialized
DEBUG - 2011-06-24 23:49:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-24 23:49:37 --> Helper loaded: url_helper
DEBUG - 2011-06-24 23:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-24 23:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-24 23:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-24 23:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-24 23:49:37 --> Final output sent to browser
DEBUG - 2011-06-24 23:49:37 --> Total execution time: 0.0906

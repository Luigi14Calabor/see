<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-13 00:48:39 --> Config Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Hooks Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Utf8 Class Initialized
DEBUG - 2011-08-13 00:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 00:48:39 --> URI Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Router Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Output Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Input Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 00:48:39 --> Language Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Loader Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Controller Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Model Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Model Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Model Class Initialized
DEBUG - 2011-08-13 00:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 00:48:39 --> Database Driver Class Initialized
DEBUG - 2011-08-13 00:48:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 00:48:39 --> Helper loaded: url_helper
DEBUG - 2011-08-13 00:48:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 00:48:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 00:48:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 00:48:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 00:48:39 --> Final output sent to browser
DEBUG - 2011-08-13 00:48:39 --> Total execution time: 0.2275
DEBUG - 2011-08-13 00:48:49 --> Config Class Initialized
DEBUG - 2011-08-13 00:48:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 00:48:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 00:48:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 00:48:49 --> URI Class Initialized
DEBUG - 2011-08-13 00:48:49 --> Router Class Initialized
DEBUG - 2011-08-13 00:48:49 --> Output Class Initialized
DEBUG - 2011-08-13 00:48:49 --> Input Class Initialized
DEBUG - 2011-08-13 00:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 00:48:49 --> Language Class Initialized
DEBUG - 2011-08-13 00:48:49 --> Loader Class Initialized
DEBUG - 2011-08-13 00:48:49 --> Controller Class Initialized
ERROR - 2011-08-13 00:48:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 00:48:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 00:48:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 00:48:50 --> Model Class Initialized
DEBUG - 2011-08-13 00:48:50 --> Model Class Initialized
DEBUG - 2011-08-13 00:48:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 00:48:50 --> Database Driver Class Initialized
DEBUG - 2011-08-13 00:48:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 00:48:50 --> Helper loaded: url_helper
DEBUG - 2011-08-13 00:48:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 00:48:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 00:48:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 00:48:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 00:48:50 --> Final output sent to browser
DEBUG - 2011-08-13 00:48:50 --> Total execution time: 0.3550
DEBUG - 2011-08-13 01:43:17 --> Config Class Initialized
DEBUG - 2011-08-13 01:43:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:43:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:43:17 --> URI Class Initialized
DEBUG - 2011-08-13 01:43:17 --> Router Class Initialized
DEBUG - 2011-08-13 01:43:17 --> Output Class Initialized
DEBUG - 2011-08-13 01:43:17 --> Input Class Initialized
DEBUG - 2011-08-13 01:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:43:17 --> Language Class Initialized
DEBUG - 2011-08-13 01:43:18 --> Loader Class Initialized
DEBUG - 2011-08-13 01:43:18 --> Controller Class Initialized
ERROR - 2011-08-13 01:43:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:43:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:43:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:43:18 --> Model Class Initialized
DEBUG - 2011-08-13 01:43:18 --> Model Class Initialized
DEBUG - 2011-08-13 01:43:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:43:18 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:43:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:43:18 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:43:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:43:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:43:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:43:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:43:18 --> Final output sent to browser
DEBUG - 2011-08-13 01:43:18 --> Total execution time: 0.4853
DEBUG - 2011-08-13 01:43:20 --> Config Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:43:20 --> URI Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Router Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Output Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Input Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:43:20 --> Language Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Loader Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Controller Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Model Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Model Class Initialized
DEBUG - 2011-08-13 01:43:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:43:20 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:43:21 --> Final output sent to browser
DEBUG - 2011-08-13 01:43:21 --> Total execution time: 1.0439
DEBUG - 2011-08-13 01:43:23 --> Config Class Initialized
DEBUG - 2011-08-13 01:43:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:43:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:43:23 --> URI Class Initialized
DEBUG - 2011-08-13 01:43:23 --> Router Class Initialized
ERROR - 2011-08-13 01:43:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:43:23 --> Config Class Initialized
DEBUG - 2011-08-13 01:43:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:43:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:43:23 --> URI Class Initialized
DEBUG - 2011-08-13 01:43:23 --> Router Class Initialized
ERROR - 2011-08-13 01:43:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:44:22 --> Config Class Initialized
DEBUG - 2011-08-13 01:44:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:44:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:44:22 --> URI Class Initialized
DEBUG - 2011-08-13 01:44:22 --> Router Class Initialized
ERROR - 2011-08-13 01:44:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:44:26 --> Config Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:44:26 --> URI Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Router Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Output Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Input Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:44:26 --> Language Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Loader Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Controller Class Initialized
ERROR - 2011-08-13 01:44:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:44:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:44:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:44:26 --> Model Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Model Class Initialized
DEBUG - 2011-08-13 01:44:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:44:26 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:44:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:44:26 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:44:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:44:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:44:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:44:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:44:26 --> Final output sent to browser
DEBUG - 2011-08-13 01:44:26 --> Total execution time: 0.0292
DEBUG - 2011-08-13 01:44:27 --> Config Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:44:27 --> URI Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Router Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Output Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Input Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:44:27 --> Language Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Loader Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Controller Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Model Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Model Class Initialized
DEBUG - 2011-08-13 01:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:44:27 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:44:28 --> Final output sent to browser
DEBUG - 2011-08-13 01:44:28 --> Total execution time: 1.7181
DEBUG - 2011-08-13 01:44:29 --> Config Class Initialized
DEBUG - 2011-08-13 01:44:29 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:44:29 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:44:29 --> URI Class Initialized
DEBUG - 2011-08-13 01:44:29 --> Router Class Initialized
ERROR - 2011-08-13 01:44:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:44:37 --> Config Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:44:37 --> URI Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Router Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Output Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Input Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:44:37 --> Language Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Loader Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Controller Class Initialized
ERROR - 2011-08-13 01:44:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:44:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:44:37 --> Model Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Model Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:44:37 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:44:37 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:44:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:44:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:44:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:44:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:44:37 --> Final output sent to browser
DEBUG - 2011-08-13 01:44:37 --> Total execution time: 0.0311
DEBUG - 2011-08-13 01:44:37 --> Config Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:44:37 --> URI Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Router Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Output Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Input Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:44:37 --> Language Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Loader Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Controller Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Model Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Model Class Initialized
DEBUG - 2011-08-13 01:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:44:37 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:44:42 --> Final output sent to browser
DEBUG - 2011-08-13 01:44:42 --> Total execution time: 4.6673
DEBUG - 2011-08-13 01:44:46 --> Config Class Initialized
DEBUG - 2011-08-13 01:44:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:44:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:44:46 --> URI Class Initialized
DEBUG - 2011-08-13 01:44:46 --> Router Class Initialized
ERROR - 2011-08-13 01:44:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:45:11 --> Config Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:45:11 --> URI Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Router Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Output Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Input Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:45:11 --> Language Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Loader Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Controller Class Initialized
ERROR - 2011-08-13 01:45:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:45:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:45:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:45:11 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:45:11 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:45:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:45:11 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:45:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:45:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:45:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:45:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:45:11 --> Final output sent to browser
DEBUG - 2011-08-13 01:45:11 --> Total execution time: 0.0280
DEBUG - 2011-08-13 01:45:12 --> Config Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:45:12 --> URI Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Router Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Output Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Input Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:45:12 --> Language Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Loader Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Controller Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:45:12 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:45:13 --> Final output sent to browser
DEBUG - 2011-08-13 01:45:13 --> Total execution time: 0.8927
DEBUG - 2011-08-13 01:45:14 --> Config Class Initialized
DEBUG - 2011-08-13 01:45:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:45:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:45:14 --> URI Class Initialized
DEBUG - 2011-08-13 01:45:14 --> Router Class Initialized
ERROR - 2011-08-13 01:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:45:38 --> Config Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:45:38 --> URI Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Router Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Output Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Input Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:45:38 --> Language Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Loader Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Controller Class Initialized
ERROR - 2011-08-13 01:45:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:45:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:45:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:45:38 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:45:38 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:45:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:45:38 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:45:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:45:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:45:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:45:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:45:38 --> Final output sent to browser
DEBUG - 2011-08-13 01:45:38 --> Total execution time: 0.0313
DEBUG - 2011-08-13 01:45:39 --> Config Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:45:39 --> URI Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Router Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Output Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Input Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:45:39 --> Language Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Loader Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Controller Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:45:39 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:45:39 --> Final output sent to browser
DEBUG - 2011-08-13 01:45:39 --> Total execution time: 0.6976
DEBUG - 2011-08-13 01:45:41 --> Config Class Initialized
DEBUG - 2011-08-13 01:45:41 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:45:41 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:45:41 --> URI Class Initialized
DEBUG - 2011-08-13 01:45:41 --> Router Class Initialized
ERROR - 2011-08-13 01:45:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:45:59 --> Config Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:45:59 --> URI Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Router Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Output Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Input Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:45:59 --> Language Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Loader Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Controller Class Initialized
ERROR - 2011-08-13 01:45:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:45:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:45:59 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:45:59 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:45:59 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:45:59 --> Final output sent to browser
DEBUG - 2011-08-13 01:45:59 --> Total execution time: 0.0311
DEBUG - 2011-08-13 01:45:59 --> Config Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:45:59 --> URI Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Router Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Output Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Input Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:45:59 --> Language Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Loader Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Controller Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Model Class Initialized
DEBUG - 2011-08-13 01:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:45:59 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:46:01 --> Final output sent to browser
DEBUG - 2011-08-13 01:46:01 --> Total execution time: 1.3961
DEBUG - 2011-08-13 01:46:02 --> Config Class Initialized
DEBUG - 2011-08-13 01:46:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:46:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:46:02 --> URI Class Initialized
DEBUG - 2011-08-13 01:46:02 --> Router Class Initialized
ERROR - 2011-08-13 01:46:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:46:10 --> Config Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:46:10 --> URI Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Router Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Output Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Input Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:46:10 --> Language Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Loader Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Controller Class Initialized
ERROR - 2011-08-13 01:46:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:46:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:46:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:46:10 --> Model Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Model Class Initialized
DEBUG - 2011-08-13 01:46:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:46:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:46:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:46:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:46:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:46:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:46:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:46:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:46:10 --> Final output sent to browser
DEBUG - 2011-08-13 01:46:10 --> Total execution time: 0.1381
DEBUG - 2011-08-13 01:46:11 --> Config Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:46:11 --> URI Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Router Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Output Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Input Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:46:11 --> Language Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Loader Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Controller Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Model Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Model Class Initialized
DEBUG - 2011-08-13 01:46:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:46:11 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:46:12 --> Final output sent to browser
DEBUG - 2011-08-13 01:46:12 --> Total execution time: 0.7263
DEBUG - 2011-08-13 01:46:14 --> Config Class Initialized
DEBUG - 2011-08-13 01:46:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:46:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:46:14 --> URI Class Initialized
DEBUG - 2011-08-13 01:46:14 --> Router Class Initialized
ERROR - 2011-08-13 01:46:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:46:16 --> Config Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:46:16 --> URI Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Router Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Output Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Input Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:46:16 --> Language Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Loader Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Controller Class Initialized
ERROR - 2011-08-13 01:46:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:46:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:46:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:46:16 --> Model Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Model Class Initialized
DEBUG - 2011-08-13 01:46:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:46:16 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:46:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:46:16 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:46:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:46:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:46:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:46:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:46:16 --> Final output sent to browser
DEBUG - 2011-08-13 01:46:16 --> Total execution time: 0.0310
DEBUG - 2011-08-13 01:46:17 --> Config Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:46:17 --> URI Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Router Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Output Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Input Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:46:17 --> Language Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Loader Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Controller Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Model Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Model Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:46:17 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:46:17 --> Final output sent to browser
DEBUG - 2011-08-13 01:46:17 --> Total execution time: 0.6130
DEBUG - 2011-08-13 01:46:18 --> Config Class Initialized
DEBUG - 2011-08-13 01:46:18 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:46:18 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:46:18 --> URI Class Initialized
DEBUG - 2011-08-13 01:46:18 --> Router Class Initialized
ERROR - 2011-08-13 01:46:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 01:47:44 --> Config Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:47:44 --> URI Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Router Class Initialized
ERROR - 2011-08-13 01:47:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 01:47:44 --> Config Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 01:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 01:47:44 --> URI Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Router Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Output Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Input Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 01:47:44 --> Language Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Loader Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Controller Class Initialized
ERROR - 2011-08-13 01:47:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 01:47:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 01:47:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:47:44 --> Model Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Model Class Initialized
DEBUG - 2011-08-13 01:47:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 01:47:44 --> Database Driver Class Initialized
DEBUG - 2011-08-13 01:47:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 01:47:44 --> Helper loaded: url_helper
DEBUG - 2011-08-13 01:47:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 01:47:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 01:47:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 01:47:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 01:47:44 --> Final output sent to browser
DEBUG - 2011-08-13 01:47:44 --> Total execution time: 0.1169
DEBUG - 2011-08-13 02:34:37 --> Config Class Initialized
DEBUG - 2011-08-13 02:34:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:34:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:34:37 --> URI Class Initialized
DEBUG - 2011-08-13 02:34:37 --> Router Class Initialized
DEBUG - 2011-08-13 02:34:37 --> No URI present. Default controller set.
DEBUG - 2011-08-13 02:34:37 --> Output Class Initialized
DEBUG - 2011-08-13 02:34:37 --> Input Class Initialized
DEBUG - 2011-08-13 02:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:34:37 --> Language Class Initialized
DEBUG - 2011-08-13 02:34:37 --> Loader Class Initialized
DEBUG - 2011-08-13 02:34:37 --> Controller Class Initialized
DEBUG - 2011-08-13 02:34:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-13 02:34:37 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:34:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:34:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:34:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:34:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:34:37 --> Final output sent to browser
DEBUG - 2011-08-13 02:34:37 --> Total execution time: 0.2016
DEBUG - 2011-08-13 02:34:39 --> Config Class Initialized
DEBUG - 2011-08-13 02:34:39 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:34:39 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:34:39 --> URI Class Initialized
DEBUG - 2011-08-13 02:34:39 --> Router Class Initialized
ERROR - 2011-08-13 02:34:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:34:43 --> Config Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:34:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:34:43 --> URI Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Router Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Output Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Input Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:34:43 --> Language Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Loader Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Controller Class Initialized
ERROR - 2011-08-13 02:34:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:34:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:34:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:34:43 --> Model Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Model Class Initialized
DEBUG - 2011-08-13 02:34:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:34:43 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:34:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:34:43 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:34:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:34:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:34:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:34:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:34:43 --> Final output sent to browser
DEBUG - 2011-08-13 02:34:43 --> Total execution time: 0.8434
DEBUG - 2011-08-13 02:34:44 --> Config Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:34:44 --> URI Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Router Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Output Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Input Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:34:44 --> Language Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Loader Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Controller Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Model Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Model Class Initialized
DEBUG - 2011-08-13 02:34:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:34:44 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:34:45 --> Final output sent to browser
DEBUG - 2011-08-13 02:34:45 --> Total execution time: 0.6798
DEBUG - 2011-08-13 02:34:46 --> Config Class Initialized
DEBUG - 2011-08-13 02:34:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:34:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:34:46 --> URI Class Initialized
DEBUG - 2011-08-13 02:34:46 --> Router Class Initialized
ERROR - 2011-08-13 02:34:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:34:51 --> Config Class Initialized
DEBUG - 2011-08-13 02:34:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:34:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:34:51 --> URI Class Initialized
DEBUG - 2011-08-13 02:34:51 --> Router Class Initialized
DEBUG - 2011-08-13 02:34:51 --> No URI present. Default controller set.
DEBUG - 2011-08-13 02:34:51 --> Output Class Initialized
DEBUG - 2011-08-13 02:34:51 --> Input Class Initialized
DEBUG - 2011-08-13 02:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:34:51 --> Language Class Initialized
DEBUG - 2011-08-13 02:34:51 --> Loader Class Initialized
DEBUG - 2011-08-13 02:34:51 --> Controller Class Initialized
DEBUG - 2011-08-13 02:34:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-13 02:34:51 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:34:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:34:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:34:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:34:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:34:51 --> Final output sent to browser
DEBUG - 2011-08-13 02:34:51 --> Total execution time: 0.0172
DEBUG - 2011-08-13 02:35:24 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:24 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Router Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Output Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Input Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:35:24 --> Language Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Loader Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Controller Class Initialized
ERROR - 2011-08-13 02:35:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:35:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:35:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:35:24 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:35:24 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:35:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:35:24 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:35:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:35:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:35:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:35:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:35:24 --> Final output sent to browser
DEBUG - 2011-08-13 02:35:24 --> Total execution time: 0.0526
DEBUG - 2011-08-13 02:35:25 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:25 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Router Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Output Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Input Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:35:25 --> Language Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Loader Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Controller Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:35:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:35:26 --> Final output sent to browser
DEBUG - 2011-08-13 02:35:26 --> Total execution time: 0.5010
DEBUG - 2011-08-13 02:35:27 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:27 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:27 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:27 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:27 --> Router Class Initialized
ERROR - 2011-08-13 02:35:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:35:29 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:29 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Router Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Output Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Input Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:35:29 --> Language Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Loader Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Controller Class Initialized
ERROR - 2011-08-13 02:35:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:35:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:35:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:35:29 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:35:29 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:35:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:35:30 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:35:30 --> Final output sent to browser
DEBUG - 2011-08-13 02:35:30 --> Total execution time: 0.0303
DEBUG - 2011-08-13 02:35:30 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:30 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Router Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Output Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Input Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:35:30 --> Language Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Loader Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Controller Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:35:30 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:35:31 --> Final output sent to browser
DEBUG - 2011-08-13 02:35:31 --> Total execution time: 1.2800
DEBUG - 2011-08-13 02:35:33 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:33 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:33 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:33 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:33 --> Router Class Initialized
ERROR - 2011-08-13 02:35:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:35:45 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:45 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Router Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Output Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Input Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:35:45 --> Language Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Loader Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Controller Class Initialized
ERROR - 2011-08-13 02:35:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:35:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:35:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:35:45 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:35:45 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:35:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:35:45 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:35:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:35:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:35:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:35:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:35:45 --> Final output sent to browser
DEBUG - 2011-08-13 02:35:45 --> Total execution time: 0.0268
DEBUG - 2011-08-13 02:35:46 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:46 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Router Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Output Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Input Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:35:46 --> Language Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Loader Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Controller Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:35:46 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:35:47 --> Final output sent to browser
DEBUG - 2011-08-13 02:35:47 --> Total execution time: 0.7376
DEBUG - 2011-08-13 02:35:48 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:48 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:48 --> Router Class Initialized
ERROR - 2011-08-13 02:35:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:35:59 --> Config Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:35:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:35:59 --> URI Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Router Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Output Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Input Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:35:59 --> Language Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Loader Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Controller Class Initialized
ERROR - 2011-08-13 02:35:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:35:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:35:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:35:59 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Model Class Initialized
DEBUG - 2011-08-13 02:35:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:35:59 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:35:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:35:59 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:35:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:35:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:35:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:35:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:35:59 --> Final output sent to browser
DEBUG - 2011-08-13 02:35:59 --> Total execution time: 0.0401
DEBUG - 2011-08-13 02:36:00 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:00 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:01 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Router Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Output Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Input Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:36:01 --> Language Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Loader Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Controller Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:36:01 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:02 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Router Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Output Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Input Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:36:02 --> Language Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Loader Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Controller Class Initialized
ERROR - 2011-08-13 02:36:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:36:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:36:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:02 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:36:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:36:02 --> Final output sent to browser
DEBUG - 2011-08-13 02:36:02 --> Total execution time: 1.3173
DEBUG - 2011-08-13 02:36:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:02 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:36:02 --> Final output sent to browser
DEBUG - 2011-08-13 02:36:02 --> Total execution time: 0.0622
DEBUG - 2011-08-13 02:36:03 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:03 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:03 --> Router Class Initialized
ERROR - 2011-08-13 02:36:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:36:04 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:04 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Router Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Output Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Input Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:36:04 --> Language Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Loader Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Controller Class Initialized
ERROR - 2011-08-13 02:36:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:36:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:36:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:04 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:36:04 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:36:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:04 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:36:04 --> Final output sent to browser
DEBUG - 2011-08-13 02:36:04 --> Total execution time: 0.0369
DEBUG - 2011-08-13 02:36:05 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:05 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Router Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Output Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Input Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:36:05 --> Language Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Loader Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Controller Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:36:05 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:05 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Router Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Output Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Input Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:36:05 --> Language Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Loader Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Controller Class Initialized
ERROR - 2011-08-13 02:36:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:36:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:36:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:05 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:36:05 --> Final output sent to browser
DEBUG - 2011-08-13 02:36:05 --> Total execution time: 0.6878
DEBUG - 2011-08-13 02:36:05 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:36:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:05 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:36:05 --> Final output sent to browser
DEBUG - 2011-08-13 02:36:05 --> Total execution time: 0.0632
DEBUG - 2011-08-13 02:36:07 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:07 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:07 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:07 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:07 --> Router Class Initialized
ERROR - 2011-08-13 02:36:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:36:09 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:09 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Router Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Output Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Input Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:36:09 --> Language Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Loader Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Controller Class Initialized
ERROR - 2011-08-13 02:36:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:36:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:36:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:09 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:36:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:36:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:09 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:36:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:36:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:36:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:36:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:36:09 --> Final output sent to browser
DEBUG - 2011-08-13 02:36:09 --> Total execution time: 0.0342
DEBUG - 2011-08-13 02:36:10 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:10 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Router Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Output Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Input Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:36:10 --> Language Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Loader Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Controller Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:36:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:10 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Router Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Output Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Input Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:36:10 --> Language Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Loader Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Controller Class Initialized
ERROR - 2011-08-13 02:36:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:36:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:36:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:10 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Model Class Initialized
DEBUG - 2011-08-13 02:36:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:36:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:36:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:36:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:36:10 --> Final output sent to browser
DEBUG - 2011-08-13 02:36:10 --> Total execution time: 0.0454
DEBUG - 2011-08-13 02:36:11 --> Final output sent to browser
DEBUG - 2011-08-13 02:36:11 --> Total execution time: 1.2466
DEBUG - 2011-08-13 02:36:12 --> Config Class Initialized
DEBUG - 2011-08-13 02:36:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:36:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:36:12 --> URI Class Initialized
DEBUG - 2011-08-13 02:36:12 --> Router Class Initialized
ERROR - 2011-08-13 02:36:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:40:49 --> Config Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:40:49 --> URI Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Router Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Output Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Input Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:40:49 --> Language Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Loader Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Controller Class Initialized
ERROR - 2011-08-13 02:40:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 02:40:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 02:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:40:49 --> Model Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Model Class Initialized
DEBUG - 2011-08-13 02:40:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:40:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 02:40:49 --> Helper loaded: url_helper
DEBUG - 2011-08-13 02:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 02:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 02:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 02:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 02:40:49 --> Final output sent to browser
DEBUG - 2011-08-13 02:40:49 --> Total execution time: 0.0426
DEBUG - 2011-08-13 02:40:50 --> Config Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:40:50 --> URI Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Router Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Output Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Input Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 02:40:50 --> Language Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Loader Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Controller Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Model Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Model Class Initialized
DEBUG - 2011-08-13 02:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 02:40:50 --> Database Driver Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Final output sent to browser
DEBUG - 2011-08-13 02:40:51 --> Total execution time: 0.5830
DEBUG - 2011-08-13 02:40:51 --> Config Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:40:51 --> URI Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Router Class Initialized
ERROR - 2011-08-13 02:40:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:40:51 --> Config Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:40:51 --> URI Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Router Class Initialized
ERROR - 2011-08-13 02:40:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 02:40:51 --> Config Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 02:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 02:40:51 --> URI Class Initialized
DEBUG - 2011-08-13 02:40:51 --> Router Class Initialized
ERROR - 2011-08-13 02:40:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 03:02:24 --> Config Class Initialized
DEBUG - 2011-08-13 03:02:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 03:02:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 03:02:24 --> URI Class Initialized
DEBUG - 2011-08-13 03:02:24 --> Router Class Initialized
ERROR - 2011-08-13 03:02:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 03:02:24 --> Config Class Initialized
DEBUG - 2011-08-13 03:02:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 03:02:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 03:02:24 --> URI Class Initialized
DEBUG - 2011-08-13 03:02:24 --> Router Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Output Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Input Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 03:02:25 --> Language Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Loader Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Controller Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Model Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Model Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Model Class Initialized
DEBUG - 2011-08-13 03:02:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 03:02:26 --> Database Driver Class Initialized
DEBUG - 2011-08-13 03:02:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 03:02:43 --> Helper loaded: url_helper
DEBUG - 2011-08-13 03:02:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 03:02:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 03:02:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 03:02:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 03:02:43 --> Final output sent to browser
DEBUG - 2011-08-13 03:02:43 --> Total execution time: 18.7197
DEBUG - 2011-08-13 03:55:23 --> Config Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 03:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 03:55:23 --> URI Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Router Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Output Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Input Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 03:55:23 --> Language Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Loader Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Controller Class Initialized
ERROR - 2011-08-13 03:55:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 03:55:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 03:55:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 03:55:23 --> Model Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Model Class Initialized
DEBUG - 2011-08-13 03:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 03:55:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 03:55:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 03:55:24 --> Helper loaded: url_helper
DEBUG - 2011-08-13 03:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 03:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 03:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 03:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 03:55:24 --> Final output sent to browser
DEBUG - 2011-08-13 03:55:24 --> Total execution time: 0.7504
DEBUG - 2011-08-13 03:55:26 --> Config Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Hooks Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Utf8 Class Initialized
DEBUG - 2011-08-13 03:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 03:55:26 --> URI Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Router Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Output Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Input Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 03:55:26 --> Language Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Loader Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Controller Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Model Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Model Class Initialized
DEBUG - 2011-08-13 03:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 03:55:26 --> Database Driver Class Initialized
DEBUG - 2011-08-13 03:55:27 --> Final output sent to browser
DEBUG - 2011-08-13 03:55:27 --> Total execution time: 0.8768
DEBUG - 2011-08-13 03:55:29 --> Config Class Initialized
DEBUG - 2011-08-13 03:55:29 --> Hooks Class Initialized
DEBUG - 2011-08-13 03:55:29 --> Utf8 Class Initialized
DEBUG - 2011-08-13 03:55:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 03:55:29 --> URI Class Initialized
DEBUG - 2011-08-13 03:55:29 --> Router Class Initialized
ERROR - 2011-08-13 03:55:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 05:17:55 --> Config Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:17:55 --> URI Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Router Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Output Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Input Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:17:55 --> Language Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Loader Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Controller Class Initialized
ERROR - 2011-08-13 05:17:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 05:17:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 05:17:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:17:55 --> Model Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Model Class Initialized
DEBUG - 2011-08-13 05:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:17:55 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:17:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:17:55 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:17:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:17:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:17:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:17:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:17:55 --> Final output sent to browser
DEBUG - 2011-08-13 05:17:55 --> Total execution time: 0.2335
DEBUG - 2011-08-13 05:17:57 --> Config Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:17:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:17:57 --> URI Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Router Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Output Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Input Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:17:57 --> Language Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Loader Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Controller Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Model Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Model Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:17:57 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:17:57 --> Final output sent to browser
DEBUG - 2011-08-13 05:17:57 --> Total execution time: 0.6755
DEBUG - 2011-08-13 05:37:33 --> Config Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:37:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:37:33 --> URI Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Router Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Output Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Input Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:37:33 --> Language Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Loader Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Controller Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:37:33 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Config Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:37:34 --> URI Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Router Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Output Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Input Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:37:34 --> Language Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Loader Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Controller Class Initialized
ERROR - 2011-08-13 05:37:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 05:37:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 05:37:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:37:34 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:37:34 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:37:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:37:34 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:37:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:37:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:37:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:37:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:37:34 --> Final output sent to browser
DEBUG - 2011-08-13 05:37:34 --> Total execution time: 0.1874
DEBUG - 2011-08-13 05:37:35 --> Config Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:37:35 --> URI Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Router Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Output Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Input Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:37:35 --> Language Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Loader Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Controller Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:37:35 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:37:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:37:35 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:37:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:37:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:37:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:37:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:37:35 --> Final output sent to browser
DEBUG - 2011-08-13 05:37:35 --> Total execution time: 2.4329
DEBUG - 2011-08-13 05:37:35 --> Final output sent to browser
DEBUG - 2011-08-13 05:37:35 --> Total execution time: 0.4994
DEBUG - 2011-08-13 05:37:36 --> Config Class Initialized
DEBUG - 2011-08-13 05:37:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:37:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:37:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:37:36 --> URI Class Initialized
DEBUG - 2011-08-13 05:37:36 --> Router Class Initialized
ERROR - 2011-08-13 05:37:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 05:37:37 --> Config Class Initialized
DEBUG - 2011-08-13 05:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:37:37 --> URI Class Initialized
DEBUG - 2011-08-13 05:37:37 --> Router Class Initialized
ERROR - 2011-08-13 05:37:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 05:37:37 --> Config Class Initialized
DEBUG - 2011-08-13 05:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:37:37 --> URI Class Initialized
DEBUG - 2011-08-13 05:37:37 --> Router Class Initialized
ERROR - 2011-08-13 05:37:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 05:37:55 --> Config Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:37:55 --> URI Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Router Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Output Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Input Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:37:55 --> Language Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Loader Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Controller Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Model Class Initialized
DEBUG - 2011-08-13 05:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:37:55 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:37:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:37:56 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:37:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:37:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:37:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:37:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:37:56 --> Final output sent to browser
DEBUG - 2011-08-13 05:37:56 --> Total execution time: 0.2921
DEBUG - 2011-08-13 05:38:04 --> Config Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:38:04 --> URI Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Router Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Output Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Input Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:38:04 --> Language Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Loader Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Controller Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:38:04 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:38:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:38:05 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:38:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:38:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:38:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:38:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:38:05 --> Final output sent to browser
DEBUG - 2011-08-13 05:38:05 --> Total execution time: 0.2622
DEBUG - 2011-08-13 05:38:14 --> Config Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:38:14 --> URI Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Router Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Output Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Input Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:38:14 --> Language Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Loader Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Controller Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:38:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:38:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:38:14 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:38:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:38:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:38:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:38:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:38:14 --> Final output sent to browser
DEBUG - 2011-08-13 05:38:14 --> Total execution time: 0.2970
DEBUG - 2011-08-13 05:38:25 --> Config Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:38:25 --> URI Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Router Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Output Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Input Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:38:25 --> Language Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Loader Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Controller Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:38:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:38:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:38:25 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:38:25 --> Final output sent to browser
DEBUG - 2011-08-13 05:38:25 --> Total execution time: 0.2687
DEBUG - 2011-08-13 05:38:28 --> Config Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:38:28 --> URI Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Router Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Output Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Input Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:38:28 --> Language Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Loader Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Controller Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:38:28 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:38:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:38:28 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:38:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:38:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:38:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:38:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:38:28 --> Final output sent to browser
DEBUG - 2011-08-13 05:38:28 --> Total execution time: 0.0436
DEBUG - 2011-08-13 05:38:36 --> Config Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:38:36 --> URI Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Router Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Output Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Input Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:38:36 --> Language Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Loader Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Controller Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:38:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:38:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:38:36 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:38:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:38:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:38:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:38:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:38:36 --> Final output sent to browser
DEBUG - 2011-08-13 05:38:36 --> Total execution time: 0.2419
DEBUG - 2011-08-13 05:38:43 --> Config Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:38:43 --> URI Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Router Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Output Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Input Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:38:43 --> Language Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Loader Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Controller Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:38:43 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:38:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:38:43 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:38:43 --> Final output sent to browser
DEBUG - 2011-08-13 05:38:43 --> Total execution time: 0.2192
DEBUG - 2011-08-13 05:38:50 --> Config Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:38:50 --> URI Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Router Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Output Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Input Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:38:50 --> Language Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Loader Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Controller Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Model Class Initialized
DEBUG - 2011-08-13 05:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:38:50 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:38:50 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:38:50 --> Final output sent to browser
DEBUG - 2011-08-13 05:38:50 --> Total execution time: 0.2091
DEBUG - 2011-08-13 05:39:00 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:00 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:00 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:00 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:00 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:00 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:00 --> Total execution time: 0.3030
DEBUG - 2011-08-13 05:39:05 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:05 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:05 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:05 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:05 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:05 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:05 --> Total execution time: 0.2176
DEBUG - 2011-08-13 05:39:13 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:13 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:13 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:13 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:13 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:13 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:13 --> Total execution time: 0.2297
DEBUG - 2011-08-13 05:39:17 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:17 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:17 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:17 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:18 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:18 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:18 --> Total execution time: 0.2068
DEBUG - 2011-08-13 05:39:22 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:22 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:22 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:22 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:22 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:22 --> Total execution time: 0.0483
DEBUG - 2011-08-13 05:39:28 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:28 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:28 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:28 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:29 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:29 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:29 --> Total execution time: 0.2102
DEBUG - 2011-08-13 05:39:33 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:33 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:33 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:33 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:33 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:33 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:33 --> Total execution time: 0.2024
DEBUG - 2011-08-13 05:39:40 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:40 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:40 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:40 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:41 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:41 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:41 --> Total execution time: 0.2104
DEBUG - 2011-08-13 05:39:43 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:43 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:43 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:43 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:44 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:44 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:44 --> Total execution time: 0.0464
DEBUG - 2011-08-13 05:39:51 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:51 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:51 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:51 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:52 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:52 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:52 --> Total execution time: 0.0504
DEBUG - 2011-08-13 05:39:58 --> Config Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:39:58 --> URI Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Router Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Output Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Input Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:39:58 --> Language Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Loader Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Controller Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Model Class Initialized
DEBUG - 2011-08-13 05:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:39:58 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:39:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:39:58 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:39:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:39:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:39:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:39:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:39:58 --> Final output sent to browser
DEBUG - 2011-08-13 05:39:58 --> Total execution time: 0.2714
DEBUG - 2011-08-13 05:40:08 --> Config Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:40:08 --> URI Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Router Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Output Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Input Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:40:08 --> Language Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Loader Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Controller Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:40:08 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:40:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:40:09 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:40:09 --> Final output sent to browser
DEBUG - 2011-08-13 05:40:09 --> Total execution time: 1.1187
DEBUG - 2011-08-13 05:40:16 --> Config Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:40:16 --> URI Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Router Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Output Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Input Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:40:16 --> Language Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Loader Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Controller Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:40:16 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:40:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:40:17 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:40:17 --> Final output sent to browser
DEBUG - 2011-08-13 05:40:17 --> Total execution time: 0.5982
DEBUG - 2011-08-13 05:40:24 --> Config Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:40:24 --> URI Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Router Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Output Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Input Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:40:24 --> Language Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Loader Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Controller Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:40:24 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:40:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:40:24 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:40:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:40:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:40:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:40:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:40:24 --> Final output sent to browser
DEBUG - 2011-08-13 05:40:24 --> Total execution time: 0.2399
DEBUG - 2011-08-13 05:40:30 --> Config Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:40:30 --> URI Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Router Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Output Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Input Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:40:30 --> Language Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Loader Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Controller Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:40:30 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:40:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 05:40:30 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:40:30 --> Final output sent to browser
DEBUG - 2011-08-13 05:40:30 --> Total execution time: 0.1929
DEBUG - 2011-08-13 05:40:49 --> Config Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:40:49 --> URI Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Router Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Output Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Input Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:40:49 --> Language Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Loader Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Controller Class Initialized
ERROR - 2011-08-13 05:40:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 05:40:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 05:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:40:49 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:40:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:40:49 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:40:49 --> Final output sent to browser
DEBUG - 2011-08-13 05:40:49 --> Total execution time: 0.0266
DEBUG - 2011-08-13 05:40:50 --> Config Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:40:50 --> URI Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Router Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Output Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Input Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:40:50 --> Language Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Loader Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Controller Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:40:50 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:40:50 --> Final output sent to browser
DEBUG - 2011-08-13 05:40:50 --> Total execution time: 0.6169
DEBUG - 2011-08-13 05:40:54 --> Config Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:40:54 --> URI Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Router Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Output Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Input Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:40:54 --> Language Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Loader Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Controller Class Initialized
ERROR - 2011-08-13 05:40:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 05:40:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 05:40:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:40:54 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:40:54 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:40:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:40:54 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:40:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:40:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:40:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:40:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:40:54 --> Final output sent to browser
DEBUG - 2011-08-13 05:40:54 --> Total execution time: 0.0292
DEBUG - 2011-08-13 05:40:54 --> Config Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:40:54 --> URI Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Router Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Output Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Input Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:40:54 --> Language Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Loader Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Controller Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Model Class Initialized
DEBUG - 2011-08-13 05:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:40:54 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:40:55 --> Final output sent to browser
DEBUG - 2011-08-13 05:40:55 --> Total execution time: 0.5119
DEBUG - 2011-08-13 05:41:02 --> Config Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:41:02 --> URI Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Router Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Output Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Input Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:41:02 --> Language Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Loader Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Controller Class Initialized
ERROR - 2011-08-13 05:41:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 05:41:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 05:41:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:41:02 --> Model Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Model Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:41:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:41:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:41:02 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:41:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:41:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:41:02 --> Final output sent to browser
DEBUG - 2011-08-13 05:41:02 --> Total execution time: 0.0309
DEBUG - 2011-08-13 05:41:02 --> Config Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:41:02 --> URI Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Router Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Output Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Input Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:41:02 --> Language Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Loader Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Controller Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Model Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Model Class Initialized
DEBUG - 2011-08-13 05:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:41:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:41:04 --> Final output sent to browser
DEBUG - 2011-08-13 05:41:04 --> Total execution time: 1.4802
DEBUG - 2011-08-13 05:41:12 --> Config Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:41:12 --> URI Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Router Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Output Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Input Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:41:12 --> Language Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Loader Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Controller Class Initialized
ERROR - 2011-08-13 05:41:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 05:41:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 05:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:41:12 --> Model Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Model Class Initialized
DEBUG - 2011-08-13 05:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:41:12 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 05:41:12 --> Helper loaded: url_helper
DEBUG - 2011-08-13 05:41:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 05:41:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 05:41:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 05:41:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 05:41:12 --> Final output sent to browser
DEBUG - 2011-08-13 05:41:12 --> Total execution time: 0.0287
DEBUG - 2011-08-13 05:41:13 --> Config Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 05:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 05:41:13 --> URI Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Router Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Output Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Input Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 05:41:13 --> Language Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Loader Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Controller Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Model Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Model Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 05:41:13 --> Database Driver Class Initialized
DEBUG - 2011-08-13 05:41:13 --> Final output sent to browser
DEBUG - 2011-08-13 05:41:13 --> Total execution time: 0.5541
DEBUG - 2011-08-13 06:02:31 --> Config Class Initialized
DEBUG - 2011-08-13 06:02:31 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:02:31 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:02:31 --> URI Class Initialized
DEBUG - 2011-08-13 06:02:31 --> Router Class Initialized
ERROR - 2011-08-13 06:02:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 06:03:19 --> Config Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:03:19 --> URI Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Router Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Output Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Input Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:03:19 --> Language Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Loader Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Controller Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Model Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Model Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Model Class Initialized
DEBUG - 2011-08-13 06:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:03:19 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:03:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 06:03:19 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:03:19 --> Final output sent to browser
DEBUG - 2011-08-13 06:03:19 --> Total execution time: 0.1955
DEBUG - 2011-08-13 06:12:19 --> Config Class Initialized
DEBUG - 2011-08-13 06:12:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:12:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:12:19 --> URI Class Initialized
DEBUG - 2011-08-13 06:12:19 --> Router Class Initialized
DEBUG - 2011-08-13 06:12:19 --> No URI present. Default controller set.
DEBUG - 2011-08-13 06:12:19 --> Output Class Initialized
DEBUG - 2011-08-13 06:12:19 --> Input Class Initialized
DEBUG - 2011-08-13 06:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:12:19 --> Language Class Initialized
DEBUG - 2011-08-13 06:12:19 --> Loader Class Initialized
DEBUG - 2011-08-13 06:12:19 --> Controller Class Initialized
DEBUG - 2011-08-13 06:12:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-13 06:12:19 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:12:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:12:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:12:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:12:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:12:19 --> Final output sent to browser
DEBUG - 2011-08-13 06:12:19 --> Total execution time: 0.2717
DEBUG - 2011-08-13 06:31:31 --> Config Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:31:31 --> URI Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Router Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Output Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Input Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:31:31 --> Language Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Loader Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Controller Class Initialized
ERROR - 2011-08-13 06:31:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 06:31:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 06:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:31:31 --> Model Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Model Class Initialized
DEBUG - 2011-08-13 06:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:31:31 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:31:31 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:31:31 --> Final output sent to browser
DEBUG - 2011-08-13 06:31:31 --> Total execution time: 0.2167
DEBUG - 2011-08-13 06:31:32 --> Config Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:31:32 --> URI Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Router Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Output Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Input Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:31:32 --> Language Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Loader Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Controller Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Model Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Model Class Initialized
DEBUG - 2011-08-13 06:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:31:32 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Final output sent to browser
DEBUG - 2011-08-13 06:31:33 --> Total execution time: 0.6915
DEBUG - 2011-08-13 06:31:33 --> Config Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:31:33 --> URI Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Router Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Output Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Input Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:31:33 --> Language Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Loader Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Controller Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Model Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Model Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Model Class Initialized
DEBUG - 2011-08-13 06:31:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:31:33 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:31:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 06:31:34 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:31:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:31:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:31:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:31:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:31:34 --> Final output sent to browser
DEBUG - 2011-08-13 06:31:34 --> Total execution time: 0.6688
DEBUG - 2011-08-13 06:31:36 --> Config Class Initialized
DEBUG - 2011-08-13 06:31:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:31:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:31:36 --> URI Class Initialized
DEBUG - 2011-08-13 06:31:36 --> Router Class Initialized
ERROR - 2011-08-13 06:31:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:31:37 --> Config Class Initialized
DEBUG - 2011-08-13 06:31:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:31:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:31:37 --> URI Class Initialized
DEBUG - 2011-08-13 06:31:37 --> Router Class Initialized
ERROR - 2011-08-13 06:31:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:31:37 --> Config Class Initialized
DEBUG - 2011-08-13 06:31:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:31:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:31:37 --> URI Class Initialized
DEBUG - 2011-08-13 06:31:37 --> Router Class Initialized
ERROR - 2011-08-13 06:31:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:31:38 --> Config Class Initialized
DEBUG - 2011-08-13 06:31:38 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:31:38 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:31:38 --> URI Class Initialized
DEBUG - 2011-08-13 06:31:38 --> Router Class Initialized
ERROR - 2011-08-13 06:31:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:31:38 --> Config Class Initialized
DEBUG - 2011-08-13 06:31:38 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:31:38 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:31:38 --> URI Class Initialized
DEBUG - 2011-08-13 06:31:38 --> Router Class Initialized
ERROR - 2011-08-13 06:31:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:39:30 --> Config Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:39:30 --> URI Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Router Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Output Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Input Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:39:30 --> Language Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Loader Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Controller Class Initialized
ERROR - 2011-08-13 06:39:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 06:39:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 06:39:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:39:30 --> Model Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Model Class Initialized
DEBUG - 2011-08-13 06:39:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:39:31 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:39:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:39:31 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:39:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:39:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:39:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:39:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:39:31 --> Final output sent to browser
DEBUG - 2011-08-13 06:39:31 --> Total execution time: 0.5355
DEBUG - 2011-08-13 06:39:32 --> Config Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:39:32 --> URI Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Router Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Output Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Input Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:39:32 --> Language Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Loader Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Controller Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Model Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Model Class Initialized
DEBUG - 2011-08-13 06:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:39:32 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:39:33 --> Final output sent to browser
DEBUG - 2011-08-13 06:39:33 --> Total execution time: 0.5706
DEBUG - 2011-08-13 06:39:34 --> Config Class Initialized
DEBUG - 2011-08-13 06:39:34 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:39:34 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:39:34 --> URI Class Initialized
DEBUG - 2011-08-13 06:39:34 --> Router Class Initialized
ERROR - 2011-08-13 06:39:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:40:40 --> Config Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:40:40 --> URI Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Router Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Output Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Input Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:40:40 --> Language Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Loader Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Controller Class Initialized
ERROR - 2011-08-13 06:40:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 06:40:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 06:40:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:40:40 --> Model Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Model Class Initialized
DEBUG - 2011-08-13 06:40:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:40:40 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:40:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:40:40 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:40:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:40:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:40:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:40:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:40:40 --> Final output sent to browser
DEBUG - 2011-08-13 06:40:40 --> Total execution time: 0.0319
DEBUG - 2011-08-13 06:40:41 --> Config Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:40:41 --> URI Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Router Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Output Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Input Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:40:41 --> Language Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Loader Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Controller Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Model Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Model Class Initialized
DEBUG - 2011-08-13 06:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:40:41 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:40:42 --> Final output sent to browser
DEBUG - 2011-08-13 06:40:42 --> Total execution time: 0.6422
DEBUG - 2011-08-13 06:40:43 --> Config Class Initialized
DEBUG - 2011-08-13 06:40:43 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:40:43 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:40:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:40:43 --> URI Class Initialized
DEBUG - 2011-08-13 06:40:43 --> Router Class Initialized
ERROR - 2011-08-13 06:40:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:40:56 --> Config Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:40:56 --> URI Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Router Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Output Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Input Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:40:56 --> Language Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Loader Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Controller Class Initialized
ERROR - 2011-08-13 06:40:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 06:40:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 06:40:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:40:56 --> Model Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Model Class Initialized
DEBUG - 2011-08-13 06:40:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:40:56 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:40:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:40:56 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:40:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:40:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:40:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:40:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:40:56 --> Final output sent to browser
DEBUG - 2011-08-13 06:40:56 --> Total execution time: 0.0287
DEBUG - 2011-08-13 06:40:57 --> Config Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:40:57 --> URI Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Router Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Output Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Input Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:40:57 --> Language Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Loader Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Controller Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Model Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Model Class Initialized
DEBUG - 2011-08-13 06:40:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:40:57 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:40:58 --> Final output sent to browser
DEBUG - 2011-08-13 06:40:58 --> Total execution time: 0.6615
DEBUG - 2011-08-13 06:40:59 --> Config Class Initialized
DEBUG - 2011-08-13 06:40:59 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:40:59 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:40:59 --> URI Class Initialized
DEBUG - 2011-08-13 06:40:59 --> Router Class Initialized
ERROR - 2011-08-13 06:40:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:41:15 --> Config Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:41:15 --> URI Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Router Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Output Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Input Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:41:15 --> Language Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Loader Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Controller Class Initialized
ERROR - 2011-08-13 06:41:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 06:41:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 06:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:41:15 --> Model Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Model Class Initialized
DEBUG - 2011-08-13 06:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:41:15 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:41:15 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:41:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:41:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:41:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:41:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:41:15 --> Final output sent to browser
DEBUG - 2011-08-13 06:41:15 --> Total execution time: 0.0271
DEBUG - 2011-08-13 06:41:16 --> Config Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:41:16 --> URI Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Router Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Output Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Input Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:41:16 --> Language Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Loader Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Controller Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Model Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Model Class Initialized
DEBUG - 2011-08-13 06:41:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:41:16 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:41:17 --> Final output sent to browser
DEBUG - 2011-08-13 06:41:17 --> Total execution time: 0.5911
DEBUG - 2011-08-13 06:41:18 --> Config Class Initialized
DEBUG - 2011-08-13 06:41:18 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:41:18 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:41:18 --> URI Class Initialized
DEBUG - 2011-08-13 06:41:18 --> Router Class Initialized
ERROR - 2011-08-13 06:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:41:21 --> Config Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:41:21 --> URI Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Router Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Output Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Input Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:41:21 --> Language Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Loader Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Controller Class Initialized
ERROR - 2011-08-13 06:41:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 06:41:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 06:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:41:21 --> Model Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Model Class Initialized
DEBUG - 2011-08-13 06:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:41:21 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:41:21 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:41:21 --> Final output sent to browser
DEBUG - 2011-08-13 06:41:21 --> Total execution time: 0.0299
DEBUG - 2011-08-13 06:41:22 --> Config Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:41:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:41:22 --> URI Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Router Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Output Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Input Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:41:22 --> Language Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Loader Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Controller Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Model Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Model Class Initialized
DEBUG - 2011-08-13 06:41:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:41:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:41:27 --> Final output sent to browser
DEBUG - 2011-08-13 06:41:27 --> Total execution time: 5.5675
DEBUG - 2011-08-13 06:41:28 --> Config Class Initialized
DEBUG - 2011-08-13 06:41:28 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:41:28 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:41:28 --> URI Class Initialized
DEBUG - 2011-08-13 06:41:28 --> Router Class Initialized
ERROR - 2011-08-13 06:41:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:41:49 --> Config Class Initialized
DEBUG - 2011-08-13 06:41:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:41:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:41:49 --> URI Class Initialized
DEBUG - 2011-08-13 06:41:49 --> Router Class Initialized
ERROR - 2011-08-13 06:41:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:41:51 --> Config Class Initialized
DEBUG - 2011-08-13 06:41:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:41:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:41:51 --> URI Class Initialized
DEBUG - 2011-08-13 06:41:51 --> Router Class Initialized
ERROR - 2011-08-13 06:41:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:42:59 --> Config Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:42:59 --> URI Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Router Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Output Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Input Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:42:59 --> Language Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Loader Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Controller Class Initialized
ERROR - 2011-08-13 06:42:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 06:42:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 06:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:42:59 --> Model Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Model Class Initialized
DEBUG - 2011-08-13 06:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:42:59 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:42:59 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:42:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:42:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:42:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:42:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:42:59 --> Final output sent to browser
DEBUG - 2011-08-13 06:42:59 --> Total execution time: 0.0293
DEBUG - 2011-08-13 06:43:01 --> Config Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:43:01 --> URI Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Router Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Output Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Input Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:43:01 --> Language Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Loader Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Controller Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Model Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Model Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:43:01 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:43:01 --> Final output sent to browser
DEBUG - 2011-08-13 06:43:01 --> Total execution time: 0.5756
DEBUG - 2011-08-13 06:43:03 --> Config Class Initialized
DEBUG - 2011-08-13 06:43:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:43:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:43:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:43:03 --> URI Class Initialized
DEBUG - 2011-08-13 06:43:03 --> Router Class Initialized
ERROR - 2011-08-13 06:43:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 06:43:06 --> Config Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:43:06 --> URI Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Router Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Output Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Input Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:43:06 --> Language Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Loader Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Controller Class Initialized
ERROR - 2011-08-13 06:43:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 06:43:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 06:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:43:06 --> Model Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Model Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:43:06 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 06:43:06 --> Helper loaded: url_helper
DEBUG - 2011-08-13 06:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 06:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 06:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 06:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 06:43:06 --> Final output sent to browser
DEBUG - 2011-08-13 06:43:06 --> Total execution time: 0.0324
DEBUG - 2011-08-13 06:43:06 --> Config Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:43:06 --> URI Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Router Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Output Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Input Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 06:43:06 --> Language Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Loader Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Controller Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Model Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Model Class Initialized
DEBUG - 2011-08-13 06:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 06:43:06 --> Database Driver Class Initialized
DEBUG - 2011-08-13 06:43:07 --> Final output sent to browser
DEBUG - 2011-08-13 06:43:07 --> Total execution time: 0.5984
DEBUG - 2011-08-13 06:43:09 --> Config Class Initialized
DEBUG - 2011-08-13 06:43:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 06:43:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 06:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 06:43:09 --> URI Class Initialized
DEBUG - 2011-08-13 06:43:09 --> Router Class Initialized
ERROR - 2011-08-13 06:43:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 07:04:08 --> Config Class Initialized
DEBUG - 2011-08-13 07:04:08 --> Hooks Class Initialized
DEBUG - 2011-08-13 07:04:08 --> Utf8 Class Initialized
DEBUG - 2011-08-13 07:04:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 07:04:08 --> URI Class Initialized
DEBUG - 2011-08-13 07:04:08 --> Router Class Initialized
DEBUG - 2011-08-13 07:04:09 --> Output Class Initialized
DEBUG - 2011-08-13 07:04:09 --> Input Class Initialized
DEBUG - 2011-08-13 07:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 07:04:09 --> Language Class Initialized
DEBUG - 2011-08-13 07:04:09 --> Loader Class Initialized
DEBUG - 2011-08-13 07:04:09 --> Controller Class Initialized
ERROR - 2011-08-13 07:04:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 07:04:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 07:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 07:04:09 --> Model Class Initialized
DEBUG - 2011-08-13 07:04:09 --> Model Class Initialized
DEBUG - 2011-08-13 07:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 07:04:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 07:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 07:04:09 --> Helper loaded: url_helper
DEBUG - 2011-08-13 07:04:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 07:04:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 07:04:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 07:04:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 07:04:09 --> Final output sent to browser
DEBUG - 2011-08-13 07:04:09 --> Total execution time: 0.2056
DEBUG - 2011-08-13 07:04:32 --> Config Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Hooks Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Utf8 Class Initialized
DEBUG - 2011-08-13 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 07:04:32 --> URI Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Router Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Output Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Input Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 07:04:32 --> Language Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Loader Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Controller Class Initialized
ERROR - 2011-08-13 07:04:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 07:04:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 07:04:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 07:04:32 --> Model Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Model Class Initialized
DEBUG - 2011-08-13 07:04:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 07:04:32 --> Database Driver Class Initialized
DEBUG - 2011-08-13 07:04:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 07:04:32 --> Helper loaded: url_helper
DEBUG - 2011-08-13 07:04:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 07:04:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 07:04:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 07:04:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 07:04:32 --> Final output sent to browser
DEBUG - 2011-08-13 07:04:32 --> Total execution time: 0.0329
DEBUG - 2011-08-13 07:29:14 --> Config Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 07:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 07:29:14 --> URI Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Router Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Output Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Input Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 07:29:14 --> Language Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Loader Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Controller Class Initialized
ERROR - 2011-08-13 07:29:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 07:29:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 07:29:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 07:29:14 --> Model Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Model Class Initialized
DEBUG - 2011-08-13 07:29:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 07:29:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 07:29:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 07:29:14 --> Helper loaded: url_helper
DEBUG - 2011-08-13 07:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 07:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 07:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 07:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 07:29:14 --> Final output sent to browser
DEBUG - 2011-08-13 07:29:14 --> Total execution time: 0.0442
DEBUG - 2011-08-13 11:10:52 --> Config Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:10:52 --> URI Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Router Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Output Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Input Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:10:52 --> Language Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Loader Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Controller Class Initialized
ERROR - 2011-08-13 11:10:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:10:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:10:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:10:52 --> Model Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Model Class Initialized
DEBUG - 2011-08-13 11:10:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:10:52 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:10:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:10:52 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:10:52 --> Final output sent to browser
DEBUG - 2011-08-13 11:10:52 --> Total execution time: 0.2987
DEBUG - 2011-08-13 11:10:53 --> Config Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:10:53 --> URI Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Router Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Output Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Input Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:10:53 --> Language Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Loader Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Controller Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Model Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Model Class Initialized
DEBUG - 2011-08-13 11:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:10:53 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:10:54 --> Final output sent to browser
DEBUG - 2011-08-13 11:10:54 --> Total execution time: 0.6835
DEBUG - 2011-08-13 11:38:17 --> Config Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:38:17 --> URI Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Router Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Output Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Input Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:38:17 --> Language Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Loader Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Controller Class Initialized
ERROR - 2011-08-13 11:38:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:38:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:38:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:38:17 --> Model Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Model Class Initialized
DEBUG - 2011-08-13 11:38:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:38:17 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:38:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:38:17 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:38:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:38:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:38:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:38:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:38:17 --> Final output sent to browser
DEBUG - 2011-08-13 11:38:17 --> Total execution time: 0.0695
DEBUG - 2011-08-13 11:38:22 --> Config Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:38:22 --> URI Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Router Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Output Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Input Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:38:22 --> Language Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Loader Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Controller Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Model Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Model Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Model Class Initialized
DEBUG - 2011-08-13 11:38:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:38:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:38:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 11:38:22 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:38:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:38:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:38:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:38:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:38:22 --> Final output sent to browser
DEBUG - 2011-08-13 11:38:22 --> Total execution time: 0.3018
DEBUG - 2011-08-13 11:41:03 --> Config Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:41:03 --> URI Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Router Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Output Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Input Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:41:03 --> Language Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Loader Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Controller Class Initialized
ERROR - 2011-08-13 11:41:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:41:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:41:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:41:03 --> Model Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Model Class Initialized
DEBUG - 2011-08-13 11:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:41:03 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:41:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:41:03 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:41:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:41:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:41:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:41:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:41:03 --> Final output sent to browser
DEBUG - 2011-08-13 11:41:03 --> Total execution time: 0.0767
DEBUG - 2011-08-13 11:41:09 --> Config Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:41:09 --> URI Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Router Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Output Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Input Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:41:09 --> Language Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Loader Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Controller Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Model Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Model Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Model Class Initialized
DEBUG - 2011-08-13 11:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:41:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:41:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 11:41:09 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:41:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:41:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:41:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:41:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:41:09 --> Final output sent to browser
DEBUG - 2011-08-13 11:41:09 --> Total execution time: 0.0492
DEBUG - 2011-08-13 11:43:27 --> Config Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:43:27 --> URI Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Router Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Output Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Input Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:43:27 --> Language Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Loader Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Controller Class Initialized
ERROR - 2011-08-13 11:43:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:43:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:43:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:43:27 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:43:27 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:43:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:43:27 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:43:27 --> Final output sent to browser
DEBUG - 2011-08-13 11:43:27 --> Total execution time: 0.0344
DEBUG - 2011-08-13 11:43:33 --> Config Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:43:33 --> URI Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Router Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Output Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Input Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:43:33 --> Language Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Loader Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Controller Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:43:33 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:43:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 11:43:33 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:43:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:43:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:43:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:43:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:43:33 --> Final output sent to browser
DEBUG - 2011-08-13 11:43:33 --> Total execution time: 0.0596
DEBUG - 2011-08-13 11:43:51 --> Config Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:43:51 --> URI Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Router Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Output Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Input Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:43:51 --> Language Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Loader Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Controller Class Initialized
ERROR - 2011-08-13 11:43:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:43:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:43:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:43:51 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:43:51 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:43:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:43:51 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:43:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:43:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:43:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:43:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:43:51 --> Final output sent to browser
DEBUG - 2011-08-13 11:43:51 --> Total execution time: 0.0465
DEBUG - 2011-08-13 11:43:56 --> Config Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:43:56 --> URI Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Router Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Output Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Input Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:43:56 --> Language Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Loader Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Controller Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Model Class Initialized
DEBUG - 2011-08-13 11:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:43:57 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:43:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 11:43:57 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:43:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:43:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:43:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:43:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:43:57 --> Final output sent to browser
DEBUG - 2011-08-13 11:43:57 --> Total execution time: 0.1203
DEBUG - 2011-08-13 11:45:36 --> Config Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:45:36 --> URI Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Router Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Output Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Input Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:45:36 --> Language Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Loader Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Controller Class Initialized
ERROR - 2011-08-13 11:45:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:45:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:45:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:45:36 --> Model Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Model Class Initialized
DEBUG - 2011-08-13 11:45:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:45:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:45:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:45:36 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:45:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:45:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:45:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:45:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:45:36 --> Final output sent to browser
DEBUG - 2011-08-13 11:45:36 --> Total execution time: 0.0280
DEBUG - 2011-08-13 11:45:42 --> Config Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:45:42 --> URI Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Router Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Output Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Input Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:45:42 --> Language Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Loader Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Controller Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Model Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Model Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Model Class Initialized
DEBUG - 2011-08-13 11:45:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:45:42 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:45:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 11:45:42 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:45:42 --> Final output sent to browser
DEBUG - 2011-08-13 11:45:42 --> Total execution time: 0.0427
DEBUG - 2011-08-13 11:46:46 --> Config Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:46:46 --> URI Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Router Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Output Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Input Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:46:46 --> Language Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Loader Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Controller Class Initialized
ERROR - 2011-08-13 11:46:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:46:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:46:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:46:46 --> Model Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Model Class Initialized
DEBUG - 2011-08-13 11:46:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:46:46 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:46:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:46:46 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:46:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:46:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:46:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:46:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:46:46 --> Final output sent to browser
DEBUG - 2011-08-13 11:46:46 --> Total execution time: 0.0348
DEBUG - 2011-08-13 11:46:51 --> Config Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:46:51 --> URI Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Router Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Output Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Input Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:46:51 --> Language Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Loader Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Controller Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Model Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Model Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Model Class Initialized
DEBUG - 2011-08-13 11:46:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:46:51 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:46:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 11:46:52 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:46:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:46:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:46:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:46:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:46:52 --> Final output sent to browser
DEBUG - 2011-08-13 11:46:52 --> Total execution time: 0.0957
DEBUG - 2011-08-13 11:52:20 --> Config Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:52:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:52:20 --> URI Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Router Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Output Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Input Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:52:20 --> Language Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Loader Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Controller Class Initialized
ERROR - 2011-08-13 11:52:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:52:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:52:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:52:20 --> Model Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Model Class Initialized
DEBUG - 2011-08-13 11:52:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:52:20 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:52:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:52:20 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:52:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:52:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:52:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:52:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:52:20 --> Final output sent to browser
DEBUG - 2011-08-13 11:52:20 --> Total execution time: 0.0271
DEBUG - 2011-08-13 11:52:25 --> Config Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:52:25 --> URI Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Router Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Output Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Input Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:52:25 --> Language Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Loader Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Controller Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Model Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Model Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Model Class Initialized
DEBUG - 2011-08-13 11:52:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:52:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:52:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 11:52:25 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:52:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:52:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:52:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:52:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:52:25 --> Final output sent to browser
DEBUG - 2011-08-13 11:52:25 --> Total execution time: 0.0477
DEBUG - 2011-08-13 11:59:13 --> Config Class Initialized
DEBUG - 2011-08-13 11:59:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:59:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:59:13 --> URI Class Initialized
DEBUG - 2011-08-13 11:59:13 --> Router Class Initialized
ERROR - 2011-08-13 11:59:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 11:59:14 --> Config Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:59:14 --> URI Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Router Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Output Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Input Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:59:14 --> Language Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Loader Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Controller Class Initialized
ERROR - 2011-08-13 11:59:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 11:59:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 11:59:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:59:14 --> Model Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Model Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:59:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:59:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 11:59:14 --> Helper loaded: url_helper
DEBUG - 2011-08-13 11:59:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 11:59:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 11:59:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 11:59:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 11:59:14 --> Final output sent to browser
DEBUG - 2011-08-13 11:59:14 --> Total execution time: 0.0294
DEBUG - 2011-08-13 11:59:14 --> Config Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 11:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 11:59:14 --> URI Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Router Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Output Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Input Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 11:59:14 --> Language Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Loader Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Controller Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Model Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Model Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 11:59:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 11:59:14 --> Final output sent to browser
DEBUG - 2011-08-13 11:59:14 --> Total execution time: 0.3660
DEBUG - 2011-08-13 12:30:25 --> Config Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:30:25 --> URI Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Router Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Output Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Input Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:30:25 --> Language Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Loader Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Controller Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Model Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Model Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Model Class Initialized
DEBUG - 2011-08-13 12:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:30:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:30:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 12:30:25 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:30:25 --> Final output sent to browser
DEBUG - 2011-08-13 12:30:25 --> Total execution time: 0.2572
DEBUG - 2011-08-13 12:30:27 --> Config Class Initialized
DEBUG - 2011-08-13 12:30:27 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:30:27 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:30:27 --> URI Class Initialized
DEBUG - 2011-08-13 12:30:27 --> Router Class Initialized
ERROR - 2011-08-13 12:30:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 12:31:46 --> Config Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:31:46 --> URI Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Router Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Output Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Input Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:31:46 --> Language Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Loader Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Controller Class Initialized
ERROR - 2011-08-13 12:31:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 12:31:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 12:31:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:31:46 --> Model Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Model Class Initialized
DEBUG - 2011-08-13 12:31:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:31:46 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:31:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:31:46 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:31:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:31:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:31:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:31:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:31:46 --> Final output sent to browser
DEBUG - 2011-08-13 12:31:46 --> Total execution time: 0.0263
DEBUG - 2011-08-13 12:31:48 --> Config Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:31:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:31:48 --> URI Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Router Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Output Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Input Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:31:48 --> Language Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Loader Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Controller Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Model Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Model Class Initialized
DEBUG - 2011-08-13 12:31:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:31:48 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:31:49 --> Final output sent to browser
DEBUG - 2011-08-13 12:31:49 --> Total execution time: 0.6915
DEBUG - 2011-08-13 12:31:51 --> Config Class Initialized
DEBUG - 2011-08-13 12:31:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:31:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:31:51 --> URI Class Initialized
DEBUG - 2011-08-13 12:31:51 --> Router Class Initialized
ERROR - 2011-08-13 12:31:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 12:34:56 --> Config Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:34:56 --> URI Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Router Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Output Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Input Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:34:56 --> Language Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Loader Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Controller Class Initialized
ERROR - 2011-08-13 12:34:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 12:34:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 12:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:34:56 --> Model Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Model Class Initialized
DEBUG - 2011-08-13 12:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:34:56 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:34:56 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:34:56 --> Final output sent to browser
DEBUG - 2011-08-13 12:34:56 --> Total execution time: 0.0984
DEBUG - 2011-08-13 12:34:59 --> Config Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:34:59 --> URI Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Router Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Output Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Input Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:34:59 --> Language Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Loader Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Controller Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Model Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Model Class Initialized
DEBUG - 2011-08-13 12:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:34:59 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:35:00 --> Final output sent to browser
DEBUG - 2011-08-13 12:35:00 --> Total execution time: 0.6950
DEBUG - 2011-08-13 12:35:03 --> Config Class Initialized
DEBUG - 2011-08-13 12:35:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:35:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:35:03 --> URI Class Initialized
DEBUG - 2011-08-13 12:35:03 --> Router Class Initialized
ERROR - 2011-08-13 12:35:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 12:35:54 --> Config Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:35:54 --> URI Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Router Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Output Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Input Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:35:54 --> Language Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Loader Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Controller Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Model Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Model Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Model Class Initialized
DEBUG - 2011-08-13 12:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:35:54 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:35:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 12:35:54 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:35:54 --> Final output sent to browser
DEBUG - 2011-08-13 12:35:54 --> Total execution time: 0.0489
DEBUG - 2011-08-13 12:35:55 --> Config Class Initialized
DEBUG - 2011-08-13 12:35:55 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:35:55 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:35:55 --> URI Class Initialized
DEBUG - 2011-08-13 12:35:55 --> Router Class Initialized
ERROR - 2011-08-13 12:35:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 12:37:37 --> Config Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:37:37 --> URI Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Router Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Output Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Input Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:37:37 --> Language Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Loader Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Controller Class Initialized
ERROR - 2011-08-13 12:37:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 12:37:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 12:37:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:37:37 --> Model Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Model Class Initialized
DEBUG - 2011-08-13 12:37:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:37:37 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:37:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:37:37 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:37:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:37:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:37:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:37:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:37:37 --> Final output sent to browser
DEBUG - 2011-08-13 12:37:37 --> Total execution time: 0.0526
DEBUG - 2011-08-13 12:37:38 --> Config Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:37:38 --> URI Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Router Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Output Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Input Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:37:38 --> Language Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Loader Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Controller Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Model Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Model Class Initialized
DEBUG - 2011-08-13 12:37:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:37:38 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:37:39 --> Final output sent to browser
DEBUG - 2011-08-13 12:37:39 --> Total execution time: 0.5678
DEBUG - 2011-08-13 12:37:42 --> Config Class Initialized
DEBUG - 2011-08-13 12:37:42 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:37:42 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:37:42 --> URI Class Initialized
DEBUG - 2011-08-13 12:37:42 --> Router Class Initialized
ERROR - 2011-08-13 12:37:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 12:37:43 --> Config Class Initialized
DEBUG - 2011-08-13 12:37:43 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:37:43 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:37:43 --> URI Class Initialized
DEBUG - 2011-08-13 12:37:43 --> Router Class Initialized
ERROR - 2011-08-13 12:37:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 12:37:45 --> Config Class Initialized
DEBUG - 2011-08-13 12:37:45 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:37:45 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:37:45 --> URI Class Initialized
DEBUG - 2011-08-13 12:37:45 --> Router Class Initialized
ERROR - 2011-08-13 12:37:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 12:37:49 --> Config Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:37:49 --> URI Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Router Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Output Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Input Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:37:49 --> Language Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Loader Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Controller Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Model Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Model Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Model Class Initialized
DEBUG - 2011-08-13 12:37:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:37:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:37:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 12:37:49 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:37:49 --> Final output sent to browser
DEBUG - 2011-08-13 12:37:49 --> Total execution time: 0.0488
DEBUG - 2011-08-13 12:38:09 --> Config Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:38:09 --> URI Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Router Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Output Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Input Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:38:09 --> Language Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Loader Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Controller Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:38:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Config Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:38:09 --> URI Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Router Class Initialized
ERROR - 2011-08-13 12:38:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 12:38:09 --> Final output sent to browser
DEBUG - 2011-08-13 12:38:09 --> Total execution time: 0.3853
DEBUG - 2011-08-13 12:38:09 --> Config Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:38:09 --> URI Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Router Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Output Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Input Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:38:09 --> Language Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Loader Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Controller Class Initialized
ERROR - 2011-08-13 12:38:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 12:38:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 12:38:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:38:09 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:38:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:38:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:38:09 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:38:09 --> Final output sent to browser
DEBUG - 2011-08-13 12:38:09 --> Total execution time: 0.0358
DEBUG - 2011-08-13 12:38:19 --> Config Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:38:19 --> URI Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Router Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Output Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Input Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:38:19 --> Language Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Loader Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Controller Class Initialized
ERROR - 2011-08-13 12:38:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 12:38:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 12:38:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:38:19 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:38:19 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:38:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 12:38:19 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:38:19 --> Final output sent to browser
DEBUG - 2011-08-13 12:38:19 --> Total execution time: 0.0283
DEBUG - 2011-08-13 12:38:19 --> Config Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:38:19 --> URI Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Router Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Output Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Input Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:38:19 --> Language Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Loader Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Controller Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:38:19 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Final output sent to browser
DEBUG - 2011-08-13 12:38:20 --> Total execution time: 0.5078
DEBUG - 2011-08-13 12:38:20 --> Config Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:38:20 --> URI Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Router Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Output Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Input Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 12:38:20 --> Language Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Loader Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Controller Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Model Class Initialized
DEBUG - 2011-08-13 12:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 12:38:20 --> Database Driver Class Initialized
DEBUG - 2011-08-13 12:38:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 12:38:20 --> Helper loaded: url_helper
DEBUG - 2011-08-13 12:38:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 12:38:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 12:38:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 12:38:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 12:38:20 --> Final output sent to browser
DEBUG - 2011-08-13 12:38:20 --> Total execution time: 0.0437
DEBUG - 2011-08-13 12:38:21 --> Config Class Initialized
DEBUG - 2011-08-13 12:38:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:38:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:38:21 --> URI Class Initialized
DEBUG - 2011-08-13 12:38:21 --> Router Class Initialized
ERROR - 2011-08-13 12:38:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 12:38:25 --> Config Class Initialized
DEBUG - 2011-08-13 12:38:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 12:38:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 12:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 12:38:25 --> URI Class Initialized
DEBUG - 2011-08-13 12:38:25 --> Router Class Initialized
ERROR - 2011-08-13 12:38:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:13:10 --> Config Class Initialized
DEBUG - 2011-08-13 13:13:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:13:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:13:10 --> URI Class Initialized
DEBUG - 2011-08-13 13:13:10 --> Router Class Initialized
DEBUG - 2011-08-13 13:13:10 --> No URI present. Default controller set.
DEBUG - 2011-08-13 13:13:10 --> Output Class Initialized
DEBUG - 2011-08-13 13:13:10 --> Input Class Initialized
DEBUG - 2011-08-13 13:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:13:10 --> Language Class Initialized
DEBUG - 2011-08-13 13:13:10 --> Loader Class Initialized
DEBUG - 2011-08-13 13:13:10 --> Controller Class Initialized
DEBUG - 2011-08-13 13:13:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-13 13:13:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:13:10 --> Final output sent to browser
DEBUG - 2011-08-13 13:13:10 --> Total execution time: 0.1342
DEBUG - 2011-08-13 13:28:09 --> Config Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:28:09 --> URI Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Router Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Output Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Input Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:28:09 --> Language Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Loader Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Controller Class Initialized
ERROR - 2011-08-13 13:28:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:28:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:28:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:28:09 --> Model Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Model Class Initialized
DEBUG - 2011-08-13 13:28:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:28:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:28:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:28:09 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:28:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:28:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:28:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:28:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:28:09 --> Final output sent to browser
DEBUG - 2011-08-13 13:28:09 --> Total execution time: 0.0577
DEBUG - 2011-08-13 13:28:12 --> Config Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:28:12 --> URI Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Router Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Output Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Input Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:28:12 --> Language Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Loader Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Controller Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Model Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Model Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:28:12 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:28:12 --> Final output sent to browser
DEBUG - 2011-08-13 13:28:12 --> Total execution time: 0.5191
DEBUG - 2011-08-13 13:28:14 --> Config Class Initialized
DEBUG - 2011-08-13 13:28:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:28:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:28:14 --> URI Class Initialized
DEBUG - 2011-08-13 13:28:14 --> Router Class Initialized
ERROR - 2011-08-13 13:28:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:29:23 --> Config Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:29:23 --> URI Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Router Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Output Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Input Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:29:23 --> Language Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Loader Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Controller Class Initialized
ERROR - 2011-08-13 13:29:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:29:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:29:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:29:23 --> Model Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Model Class Initialized
DEBUG - 2011-08-13 13:29:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:29:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:29:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:29:23 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:29:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:29:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:29:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:29:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:29:23 --> Final output sent to browser
DEBUG - 2011-08-13 13:29:23 --> Total execution time: 0.0277
DEBUG - 2011-08-13 13:29:24 --> Config Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:29:24 --> URI Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Router Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Output Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Input Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:29:24 --> Language Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Loader Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Controller Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Model Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Model Class Initialized
DEBUG - 2011-08-13 13:29:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:29:24 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:29:25 --> Final output sent to browser
DEBUG - 2011-08-13 13:29:25 --> Total execution time: 0.5357
DEBUG - 2011-08-13 13:29:26 --> Config Class Initialized
DEBUG - 2011-08-13 13:29:26 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:29:26 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:29:26 --> URI Class Initialized
DEBUG - 2011-08-13 13:29:26 --> Router Class Initialized
ERROR - 2011-08-13 13:29:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:30:04 --> Config Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:30:04 --> URI Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Router Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Output Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Input Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:30:04 --> Language Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Loader Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Controller Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:30:04 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 13:30:05 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:30:05 --> Final output sent to browser
DEBUG - 2011-08-13 13:30:05 --> Total execution time: 0.8358
DEBUG - 2011-08-13 13:30:06 --> Config Class Initialized
DEBUG - 2011-08-13 13:30:06 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:30:06 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:30:06 --> URI Class Initialized
DEBUG - 2011-08-13 13:30:06 --> Router Class Initialized
ERROR - 2011-08-13 13:30:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:30:25 --> Config Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:30:25 --> URI Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Router Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Output Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Input Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:30:25 --> Language Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Loader Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Controller Class Initialized
ERROR - 2011-08-13 13:30:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:30:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:30:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:30:25 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:30:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:30:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:30:25 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:30:25 --> Final output sent to browser
DEBUG - 2011-08-13 13:30:25 --> Total execution time: 0.0331
DEBUG - 2011-08-13 13:30:26 --> Config Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:30:26 --> URI Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Router Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Output Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Input Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:30:26 --> Language Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Loader Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Controller Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:30:26 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:30:26 --> Final output sent to browser
DEBUG - 2011-08-13 13:30:26 --> Total execution time: 0.5711
DEBUG - 2011-08-13 13:30:44 --> Config Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:30:44 --> URI Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Router Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Output Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Input Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:30:44 --> Language Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Loader Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Controller Class Initialized
ERROR - 2011-08-13 13:30:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:30:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:30:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:30:44 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:30:44 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:30:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:30:44 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:30:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:30:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:30:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:30:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:30:44 --> Final output sent to browser
DEBUG - 2011-08-13 13:30:44 --> Total execution time: 0.0306
DEBUG - 2011-08-13 13:30:45 --> Config Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:30:45 --> URI Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Router Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Output Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Input Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:30:45 --> Language Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Loader Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Controller Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:30:45 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:30:45 --> Final output sent to browser
DEBUG - 2011-08-13 13:30:45 --> Total execution time: 0.4603
DEBUG - 2011-08-13 13:30:57 --> Config Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:30:57 --> URI Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Router Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Output Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Input Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:30:57 --> Language Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Loader Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Controller Class Initialized
ERROR - 2011-08-13 13:30:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:30:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:30:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:30:57 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:30:57 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:30:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:30:57 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:30:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:30:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:30:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:30:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:30:57 --> Final output sent to browser
DEBUG - 2011-08-13 13:30:57 --> Total execution time: 0.0276
DEBUG - 2011-08-13 13:30:58 --> Config Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:30:58 --> URI Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Router Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Output Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Input Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:30:58 --> Language Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Loader Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Controller Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Model Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:30:58 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:30:58 --> Final output sent to browser
DEBUG - 2011-08-13 13:30:58 --> Total execution time: 0.5318
DEBUG - 2011-08-13 13:31:10 --> Config Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:31:10 --> URI Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Router Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Output Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Input Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:31:10 --> Language Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Loader Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Controller Class Initialized
ERROR - 2011-08-13 13:31:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:31:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:31:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:31:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:31:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:31:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:31:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:31:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:31:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:31:10 --> Final output sent to browser
DEBUG - 2011-08-13 13:31:10 --> Total execution time: 0.0339
DEBUG - 2011-08-13 13:31:10 --> Config Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:31:10 --> URI Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Router Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Output Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Input Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:31:10 --> Language Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Loader Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Controller Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:31:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:31:11 --> Final output sent to browser
DEBUG - 2011-08-13 13:31:11 --> Total execution time: 0.5784
DEBUG - 2011-08-13 13:31:18 --> Config Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:31:18 --> URI Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Router Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Output Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Input Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:31:18 --> Language Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Loader Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Controller Class Initialized
ERROR - 2011-08-13 13:31:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:31:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:31:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:18 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:31:18 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:31:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:18 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:31:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:31:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:31:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:31:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:31:18 --> Final output sent to browser
DEBUG - 2011-08-13 13:31:18 --> Total execution time: 0.0285
DEBUG - 2011-08-13 13:31:19 --> Config Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:31:19 --> URI Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Router Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Output Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Input Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:31:19 --> Language Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Loader Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Controller Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:31:19 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:31:19 --> Final output sent to browser
DEBUG - 2011-08-13 13:31:19 --> Total execution time: 0.5203
DEBUG - 2011-08-13 13:31:20 --> Config Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:31:20 --> URI Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Router Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Output Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Input Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:31:20 --> Language Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Loader Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Controller Class Initialized
ERROR - 2011-08-13 13:31:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:31:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:31:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:20 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:31:20 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:31:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:20 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:31:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:31:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:31:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:31:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:31:20 --> Final output sent to browser
DEBUG - 2011-08-13 13:31:20 --> Total execution time: 0.0371
DEBUG - 2011-08-13 13:31:23 --> Config Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:31:23 --> URI Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Router Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Output Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Input Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:31:23 --> Language Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Loader Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Controller Class Initialized
ERROR - 2011-08-13 13:31:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:31:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:31:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:23 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:31:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:31:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:23 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:31:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:31:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:31:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:31:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:31:23 --> Final output sent to browser
DEBUG - 2011-08-13 13:31:23 --> Total execution time: 0.0306
DEBUG - 2011-08-13 13:31:23 --> Config Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:31:23 --> URI Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Router Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Output Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Input Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:31:23 --> Language Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Loader Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Controller Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:31:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:31:24 --> Final output sent to browser
DEBUG - 2011-08-13 13:31:24 --> Total execution time: 0.5611
DEBUG - 2011-08-13 13:31:28 --> Config Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:31:28 --> URI Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Router Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Output Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Input Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:31:28 --> Language Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Loader Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Controller Class Initialized
ERROR - 2011-08-13 13:31:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:31:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:31:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:28 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Model Class Initialized
DEBUG - 2011-08-13 13:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:31:28 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:31:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:31:28 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:31:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:31:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:31:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:31:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:31:28 --> Final output sent to browser
DEBUG - 2011-08-13 13:31:28 --> Total execution time: 0.0305
DEBUG - 2011-08-13 13:32:04 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:04 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Router Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Output Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Input Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:32:04 --> Language Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Loader Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Controller Class Initialized
ERROR - 2011-08-13 13:32:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:32:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:32:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:32:04 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:32:04 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:32:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:32:04 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:32:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:32:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:32:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:32:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:32:04 --> Final output sent to browser
DEBUG - 2011-08-13 13:32:04 --> Total execution time: 0.0290
DEBUG - 2011-08-13 13:32:05 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:05 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Router Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Output Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Input Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:32:05 --> Language Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Loader Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Controller Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:32:05 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:32:05 --> Final output sent to browser
DEBUG - 2011-08-13 13:32:05 --> Total execution time: 0.4633
DEBUG - 2011-08-13 13:32:07 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:07 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:07 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:07 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:07 --> Router Class Initialized
ERROR - 2011-08-13 13:32:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:32:09 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:09 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Router Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Output Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Input Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:32:09 --> Language Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Loader Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Controller Class Initialized
ERROR - 2011-08-13 13:32:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:32:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:32:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:32:09 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:32:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:32:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:32:09 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:32:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:32:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:32:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:32:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:32:09 --> Final output sent to browser
DEBUG - 2011-08-13 13:32:09 --> Total execution time: 0.0272
DEBUG - 2011-08-13 13:32:10 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:10 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Router Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Output Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Input Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:32:10 --> Language Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Loader Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Controller Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:32:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:32:10 --> Final output sent to browser
DEBUG - 2011-08-13 13:32:10 --> Total execution time: 0.6052
DEBUG - 2011-08-13 13:32:11 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:11 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:11 --> Router Class Initialized
ERROR - 2011-08-13 13:32:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:32:53 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:53 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Router Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Output Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Input Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:32:53 --> Language Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Loader Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Controller Class Initialized
ERROR - 2011-08-13 13:32:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:32:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:32:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:32:53 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:32:53 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:32:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:32:53 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:32:53 --> Final output sent to browser
DEBUG - 2011-08-13 13:32:53 --> Total execution time: 0.0289
DEBUG - 2011-08-13 13:32:54 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:54 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Router Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Output Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Input Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:32:54 --> Language Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Loader Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Controller Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Model Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:32:54 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:32:54 --> Final output sent to browser
DEBUG - 2011-08-13 13:32:54 --> Total execution time: 0.5903
DEBUG - 2011-08-13 13:32:58 --> Config Class Initialized
DEBUG - 2011-08-13 13:32:58 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:32:58 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:32:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:32:58 --> URI Class Initialized
DEBUG - 2011-08-13 13:32:58 --> Router Class Initialized
ERROR - 2011-08-13 13:32:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:33:10 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:10 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Router Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Output Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Input Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:33:10 --> Language Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Loader Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Controller Class Initialized
ERROR - 2011-08-13 13:33:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:33:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:33:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:33:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:33:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:33:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:33:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:33:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:33:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:33:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:33:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:33:10 --> Final output sent to browser
DEBUG - 2011-08-13 13:33:10 --> Total execution time: 0.0280
DEBUG - 2011-08-13 13:33:11 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:11 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Router Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Output Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Input Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:33:11 --> Language Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Loader Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Controller Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:33:11 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:33:11 --> Final output sent to browser
DEBUG - 2011-08-13 13:33:11 --> Total execution time: 0.5735
DEBUG - 2011-08-13 13:33:14 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:14 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:14 --> Router Class Initialized
ERROR - 2011-08-13 13:33:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:33:25 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:25 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Router Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Output Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Input Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:33:25 --> Language Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Loader Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Controller Class Initialized
ERROR - 2011-08-13 13:33:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:33:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:33:25 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:33:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:33:25 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:33:25 --> Final output sent to browser
DEBUG - 2011-08-13 13:33:25 --> Total execution time: 0.0317
DEBUG - 2011-08-13 13:33:26 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:26 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Router Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Output Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Input Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:33:26 --> Language Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Loader Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Controller Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:33:26 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:33:26 --> Final output sent to browser
DEBUG - 2011-08-13 13:33:26 --> Total execution time: 0.4882
DEBUG - 2011-08-13 13:33:27 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:27 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:27 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:27 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:27 --> Router Class Initialized
ERROR - 2011-08-13 13:33:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:33:41 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:41 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Router Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Output Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Input Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:33:41 --> Language Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Loader Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Controller Class Initialized
ERROR - 2011-08-13 13:33:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:33:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:33:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:33:41 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:33:41 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:33:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:33:41 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:33:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:33:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:33:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:33:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:33:41 --> Final output sent to browser
DEBUG - 2011-08-13 13:33:41 --> Total execution time: 0.0277
DEBUG - 2011-08-13 13:33:41 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:41 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Router Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Output Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Input Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:33:41 --> Language Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Loader Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Controller Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:33:41 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:33:42 --> Final output sent to browser
DEBUG - 2011-08-13 13:33:42 --> Total execution time: 0.6208
DEBUG - 2011-08-13 13:33:44 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:44 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:44 --> Router Class Initialized
ERROR - 2011-08-13 13:33:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:33:54 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:54 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Router Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Output Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Input Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:33:54 --> Language Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Loader Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Controller Class Initialized
ERROR - 2011-08-13 13:33:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:33:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:33:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:33:54 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:33:54 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:33:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:33:54 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:33:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:33:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:33:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:33:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:33:54 --> Final output sent to browser
DEBUG - 2011-08-13 13:33:54 --> Total execution time: 0.0274
DEBUG - 2011-08-13 13:33:55 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:55 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Router Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Output Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Input Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:33:55 --> Language Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Loader Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Controller Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Model Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:33:55 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:33:55 --> Final output sent to browser
DEBUG - 2011-08-13 13:33:55 --> Total execution time: 0.5608
DEBUG - 2011-08-13 13:33:58 --> Config Class Initialized
DEBUG - 2011-08-13 13:33:58 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:33:58 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:33:58 --> URI Class Initialized
DEBUG - 2011-08-13 13:33:58 --> Router Class Initialized
ERROR - 2011-08-13 13:33:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:34:12 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:12 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:12 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Controller Class Initialized
ERROR - 2011-08-13 13:34:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:34:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:34:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:12 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:12 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:12 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:34:12 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:12 --> Total execution time: 0.0262
DEBUG - 2011-08-13 13:34:12 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:12 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:12 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Controller Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:12 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:13 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:13 --> Total execution time: 0.4824
DEBUG - 2011-08-13 13:34:14 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:14 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:14 --> Router Class Initialized
ERROR - 2011-08-13 13:34:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:34:21 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:21 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:21 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Controller Class Initialized
ERROR - 2011-08-13 13:34:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:34:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:34:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:21 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:21 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:21 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:34:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:34:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:34:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:34:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:34:21 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:21 --> Total execution time: 0.0280
DEBUG - 2011-08-13 13:34:22 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:22 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:22 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Controller Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:22 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:22 --> Total execution time: 0.5385
DEBUG - 2011-08-13 13:34:23 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:23 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:23 --> Router Class Initialized
ERROR - 2011-08-13 13:34:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:34:26 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:26 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:26 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Controller Class Initialized
ERROR - 2011-08-13 13:34:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:34:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:34:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:26 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:26 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:26 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:34:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:34:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:34:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:34:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:34:26 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:26 --> Total execution time: 0.0268
DEBUG - 2011-08-13 13:34:26 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:26 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:26 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Controller Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:26 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:27 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:27 --> Total execution time: 0.5121
DEBUG - 2011-08-13 13:34:28 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:28 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:28 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:28 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:28 --> Router Class Initialized
ERROR - 2011-08-13 13:34:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:34:40 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:40 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:40 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Controller Class Initialized
ERROR - 2011-08-13 13:34:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:34:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:34:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:40 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:40 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:40 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:34:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:34:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:34:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:34:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:34:40 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:40 --> Total execution time: 0.0269
DEBUG - 2011-08-13 13:34:41 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:41 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:41 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Controller Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:41 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:41 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:41 --> Total execution time: 0.5449
DEBUG - 2011-08-13 13:34:42 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:42 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:42 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:42 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:42 --> Router Class Initialized
ERROR - 2011-08-13 13:34:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:34:45 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:45 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:45 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Controller Class Initialized
ERROR - 2011-08-13 13:34:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:34:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:34:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:45 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:45 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:34:45 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:34:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:34:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:34:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:34:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:34:45 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:45 --> Total execution time: 0.0343
DEBUG - 2011-08-13 13:34:46 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:46 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Router Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Output Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Input Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:34:46 --> Language Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Loader Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Controller Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Model Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:34:46 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:34:46 --> Final output sent to browser
DEBUG - 2011-08-13 13:34:46 --> Total execution time: 0.5041
DEBUG - 2011-08-13 13:34:47 --> Config Class Initialized
DEBUG - 2011-08-13 13:34:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:34:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:34:47 --> URI Class Initialized
DEBUG - 2011-08-13 13:34:47 --> Router Class Initialized
ERROR - 2011-08-13 13:34:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:35:02 --> Config Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:35:02 --> URI Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Router Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Output Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Input Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:35:02 --> Language Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Loader Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Controller Class Initialized
ERROR - 2011-08-13 13:35:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:35:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:35:02 --> Model Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Model Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:35:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:35:02 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:35:02 --> Final output sent to browser
DEBUG - 2011-08-13 13:35:02 --> Total execution time: 0.0334
DEBUG - 2011-08-13 13:35:02 --> Config Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:35:02 --> URI Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Router Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Output Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Input Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:35:02 --> Language Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Loader Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Controller Class Initialized
ERROR - 2011-08-13 13:35:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:35:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:35:02 --> Model Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Model Class Initialized
DEBUG - 2011-08-13 13:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:35:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:35:02 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:35:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:35:02 --> Final output sent to browser
DEBUG - 2011-08-13 13:35:02 --> Total execution time: 0.0285
DEBUG - 2011-08-13 13:37:16 --> Config Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:37:16 --> URI Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Router Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Output Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Input Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:37:16 --> Language Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Loader Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Controller Class Initialized
ERROR - 2011-08-13 13:37:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:37:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:37:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:37:16 --> Model Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Model Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:37:16 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:37:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:37:16 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:37:16 --> Final output sent to browser
DEBUG - 2011-08-13 13:37:16 --> Total execution time: 0.0414
DEBUG - 2011-08-13 13:37:16 --> Config Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:37:16 --> URI Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Router Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Output Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Input Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:37:16 --> Language Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Loader Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Controller Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Model Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Model Class Initialized
DEBUG - 2011-08-13 13:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:37:16 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:37:17 --> Final output sent to browser
DEBUG - 2011-08-13 13:37:17 --> Total execution time: 0.5324
DEBUG - 2011-08-13 13:37:17 --> Config Class Initialized
DEBUG - 2011-08-13 13:37:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:37:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:37:17 --> URI Class Initialized
DEBUG - 2011-08-13 13:37:17 --> Router Class Initialized
ERROR - 2011-08-13 13:37:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:37:18 --> Config Class Initialized
DEBUG - 2011-08-13 13:37:18 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:37:18 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:37:18 --> URI Class Initialized
DEBUG - 2011-08-13 13:37:18 --> Router Class Initialized
ERROR - 2011-08-13 13:37:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:48:06 --> Config Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:48:06 --> URI Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Router Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Output Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Input Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:48:06 --> Language Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Loader Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Controller Class Initialized
ERROR - 2011-08-13 13:48:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:48:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:48:06 --> Model Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Model Class Initialized
DEBUG - 2011-08-13 13:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:48:06 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:48:06 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:48:06 --> Final output sent to browser
DEBUG - 2011-08-13 13:48:06 --> Total execution time: 0.0314
DEBUG - 2011-08-13 13:49:10 --> Config Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:49:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:49:10 --> URI Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Router Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Output Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Input Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:49:10 --> Language Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Loader Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Controller Class Initialized
ERROR - 2011-08-13 13:49:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:49:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:49:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:49:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Model Class Initialized
DEBUG - 2011-08-13 13:49:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:49:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:49:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:49:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:49:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:49:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:49:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:49:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:49:10 --> Final output sent to browser
DEBUG - 2011-08-13 13:49:10 --> Total execution time: 0.0332
DEBUG - 2011-08-13 13:49:11 --> Config Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:49:11 --> URI Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Router Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Output Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Input Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:49:11 --> Language Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Loader Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Controller Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Model Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Model Class Initialized
DEBUG - 2011-08-13 13:49:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:49:11 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:49:12 --> Final output sent to browser
DEBUG - 2011-08-13 13:49:12 --> Total execution time: 0.4497
DEBUG - 2011-08-13 13:49:13 --> Config Class Initialized
DEBUG - 2011-08-13 13:49:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:49:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:49:13 --> URI Class Initialized
DEBUG - 2011-08-13 13:49:13 --> Router Class Initialized
ERROR - 2011-08-13 13:49:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:49:14 --> Config Class Initialized
DEBUG - 2011-08-13 13:49:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:49:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:49:14 --> URI Class Initialized
DEBUG - 2011-08-13 13:49:14 --> Router Class Initialized
ERROR - 2011-08-13 13:49:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:51:54 --> Config Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:51:54 --> URI Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Router Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Output Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Input Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:51:54 --> Language Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Loader Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Controller Class Initialized
ERROR - 2011-08-13 13:51:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:51:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:51:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:51:54 --> Model Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Model Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:51:54 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:51:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:51:54 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:51:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:51:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:51:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:51:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:51:54 --> Final output sent to browser
DEBUG - 2011-08-13 13:51:54 --> Total execution time: 0.0275
DEBUG - 2011-08-13 13:51:54 --> Config Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:51:54 --> URI Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Router Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Output Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Input Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:51:54 --> Language Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Loader Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Controller Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Model Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Model Class Initialized
DEBUG - 2011-08-13 13:51:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:51:54 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:51:55 --> Final output sent to browser
DEBUG - 2011-08-13 13:51:55 --> Total execution time: 0.4930
DEBUG - 2011-08-13 13:51:57 --> Config Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:51:57 --> URI Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Router Class Initialized
ERROR - 2011-08-13 13:51:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:51:57 --> Config Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:51:57 --> URI Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Router Class Initialized
ERROR - 2011-08-13 13:51:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:51:57 --> Config Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:51:57 --> URI Class Initialized
DEBUG - 2011-08-13 13:51:57 --> Router Class Initialized
ERROR - 2011-08-13 13:51:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 13:52:40 --> Config Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:52:40 --> URI Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Router Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Output Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Input Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:52:40 --> Language Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Loader Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Controller Class Initialized
ERROR - 2011-08-13 13:52:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:52:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:52:40 --> Model Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Model Class Initialized
DEBUG - 2011-08-13 13:52:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:52:40 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:52:40 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:52:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:52:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:52:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:52:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:52:40 --> Final output sent to browser
DEBUG - 2011-08-13 13:52:40 --> Total execution time: 0.0276
DEBUG - 2011-08-13 13:52:41 --> Config Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:52:41 --> URI Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Router Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Output Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Input Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:52:41 --> Language Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Loader Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Controller Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Model Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Model Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:52:41 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:52:41 --> Final output sent to browser
DEBUG - 2011-08-13 13:52:41 --> Total execution time: 0.5245
DEBUG - 2011-08-13 13:52:48 --> Config Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:52:48 --> URI Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Router Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Output Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Input Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:52:48 --> Language Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Loader Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Controller Class Initialized
ERROR - 2011-08-13 13:52:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:52:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:52:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:52:48 --> Model Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Model Class Initialized
DEBUG - 2011-08-13 13:52:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:52:48 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:52:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:52:48 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:52:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:52:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:52:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:52:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:52:48 --> Final output sent to browser
DEBUG - 2011-08-13 13:52:48 --> Total execution time: 0.0271
DEBUG - 2011-08-13 13:52:49 --> Config Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:52:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:52:49 --> URI Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Router Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Output Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Input Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:52:49 --> Language Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Loader Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Controller Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Model Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Model Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:52:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:52:49 --> Final output sent to browser
DEBUG - 2011-08-13 13:52:49 --> Total execution time: 0.5275
DEBUG - 2011-08-13 13:53:02 --> Config Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:53:02 --> URI Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Router Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Output Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Input Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:53:02 --> Language Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Loader Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Controller Class Initialized
ERROR - 2011-08-13 13:53:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 13:53:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 13:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:53:02 --> Model Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Model Class Initialized
DEBUG - 2011-08-13 13:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:53:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 13:53:02 --> Helper loaded: url_helper
DEBUG - 2011-08-13 13:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 13:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 13:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 13:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 13:53:02 --> Final output sent to browser
DEBUG - 2011-08-13 13:53:02 --> Total execution time: 0.0284
DEBUG - 2011-08-13 13:53:03 --> Config Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 13:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 13:53:03 --> URI Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Router Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Output Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Input Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 13:53:03 --> Language Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Loader Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Controller Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Model Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Model Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 13:53:03 --> Database Driver Class Initialized
DEBUG - 2011-08-13 13:53:03 --> Final output sent to browser
DEBUG - 2011-08-13 13:53:03 --> Total execution time: 0.5431
DEBUG - 2011-08-13 14:08:47 --> Config Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:08:47 --> URI Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Router Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Output Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Input Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:08:47 --> Language Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Loader Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Controller Class Initialized
ERROR - 2011-08-13 14:08:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:08:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:08:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:08:47 --> Model Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Model Class Initialized
DEBUG - 2011-08-13 14:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:08:47 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:08:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:08:47 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:08:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:08:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:08:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:08:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:08:47 --> Final output sent to browser
DEBUG - 2011-08-13 14:08:47 --> Total execution time: 0.0306
DEBUG - 2011-08-13 14:08:56 --> Config Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:08:56 --> URI Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Router Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Output Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Input Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:08:56 --> Language Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Loader Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Controller Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Model Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Model Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:08:56 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:08:56 --> Final output sent to browser
DEBUG - 2011-08-13 14:08:56 --> Total execution time: 0.5192
DEBUG - 2011-08-13 14:09:16 --> Config Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:09:16 --> URI Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Router Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Output Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Input Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:09:16 --> Language Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Loader Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Controller Class Initialized
ERROR - 2011-08-13 14:09:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:09:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:09:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:09:16 --> Model Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Model Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:09:16 --> Config Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:09:16 --> URI Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Router Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Database Driver Class Initialized
ERROR - 2011-08-13 14:09:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:09:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:09:16 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:09:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:09:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:09:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:09:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:09:16 --> Final output sent to browser
DEBUG - 2011-08-13 14:09:16 --> Total execution time: 0.0319
DEBUG - 2011-08-13 14:09:16 --> Config Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:09:16 --> URI Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Router Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Output Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Input Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:09:16 --> Language Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Loader Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Controller Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Model Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Model Class Initialized
DEBUG - 2011-08-13 14:09:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:09:16 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:09:17 --> Final output sent to browser
DEBUG - 2011-08-13 14:09:17 --> Total execution time: 0.6319
DEBUG - 2011-08-13 14:09:28 --> Config Class Initialized
DEBUG - 2011-08-13 14:09:28 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:09:28 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:09:28 --> URI Class Initialized
DEBUG - 2011-08-13 14:09:28 --> Router Class Initialized
ERROR - 2011-08-13 14:09:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:12:06 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:06 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:06 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Controller Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:06 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:12:06 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:12:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:12:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:12:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:12:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:12:06 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:06 --> Total execution time: 0.2802
DEBUG - 2011-08-13 14:12:08 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:08 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:08 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:08 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:08 --> Router Class Initialized
ERROR - 2011-08-13 14:12:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:12:15 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:15 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:15 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Controller Class Initialized
ERROR - 2011-08-13 14:12:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:12:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:12:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:12:15 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:15 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:12:15 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:12:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:12:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:12:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:12:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:12:15 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:15 --> Total execution time: 0.0891
DEBUG - 2011-08-13 14:12:15 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:15 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:15 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Controller Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:15 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:16 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:16 --> Total execution time: 0.5630
DEBUG - 2011-08-13 14:12:16 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:16 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:16 --> Router Class Initialized
ERROR - 2011-08-13 14:12:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:12:16 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:16 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:16 --> Router Class Initialized
ERROR - 2011-08-13 14:12:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:12:34 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:34 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:34 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Controller Class Initialized
ERROR - 2011-08-13 14:12:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:12:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:12:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:12:34 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:34 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:12:34 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:12:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:12:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:12:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:12:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:12:34 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:34 --> Total execution time: 0.0294
DEBUG - 2011-08-13 14:12:34 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:34 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:34 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Controller Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:34 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:35 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:35 --> Total execution time: 0.4965
DEBUG - 2011-08-13 14:12:42 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:42 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:42 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Controller Class Initialized
ERROR - 2011-08-13 14:12:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:12:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:12:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:12:42 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:42 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:12:42 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:12:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:12:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:12:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:12:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:12:42 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:42 --> Total execution time: 0.0327
DEBUG - 2011-08-13 14:12:42 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:42 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:42 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Controller Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:42 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:42 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:42 --> Total execution time: 0.5512
DEBUG - 2011-08-13 14:12:57 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:57 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:57 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Controller Class Initialized
ERROR - 2011-08-13 14:12:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:12:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:12:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:12:57 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:57 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:12:57 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:12:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:12:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:12:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:12:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:12:57 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:57 --> Total execution time: 0.0284
DEBUG - 2011-08-13 14:12:57 --> Config Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:12:57 --> URI Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Router Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Output Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Input Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:12:57 --> Language Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Loader Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Controller Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Model Class Initialized
DEBUG - 2011-08-13 14:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:12:57 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:12:58 --> Final output sent to browser
DEBUG - 2011-08-13 14:12:58 --> Total execution time: 0.5873
DEBUG - 2011-08-13 14:13:10 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:10 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:10 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:13:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:10 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:10 --> Total execution time: 0.3013
DEBUG - 2011-08-13 14:13:11 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:11 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:11 --> Router Class Initialized
ERROR - 2011-08-13 14:13:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:13:12 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:12 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:12 --> Router Class Initialized
ERROR - 2011-08-13 14:13:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:13:14 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:14 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:14 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Controller Class Initialized
ERROR - 2011-08-13 14:13:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:13:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:13:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:13:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:13:14 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:14 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:14 --> Total execution time: 0.0301
DEBUG - 2011-08-13 14:13:14 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:14 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:14 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:15 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:15 --> Total execution time: 0.5765
DEBUG - 2011-08-13 14:13:30 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:30 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:30 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Controller Class Initialized
ERROR - 2011-08-13 14:13:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:13:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:13:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:13:30 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:30 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:13:30 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:30 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:30 --> Total execution time: 0.0281
DEBUG - 2011-08-13 14:13:30 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:30 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:30 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:30 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:30 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:30 --> Total execution time: 0.5594
DEBUG - 2011-08-13 14:13:36 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:36 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:36 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Controller Class Initialized
ERROR - 2011-08-13 14:13:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:13:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:13:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:13:36 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:13:36 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:36 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:36 --> Total execution time: 0.0311
DEBUG - 2011-08-13 14:13:36 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:36 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:36 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:36 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:36 --> Total execution time: 0.4449
DEBUG - 2011-08-13 14:13:44 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:44 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:44 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:44 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:13:45 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:45 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:45 --> Total execution time: 0.4815
DEBUG - 2011-08-13 14:13:47 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:47 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:47 --> Router Class Initialized
ERROR - 2011-08-13 14:13:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:13:47 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:47 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:47 --> Router Class Initialized
ERROR - 2011-08-13 14:13:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:13:48 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:48 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Router Class Initialized
ERROR - 2011-08-13 14:13:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 14:13:48 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:48 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:48 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:48 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:13:48 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:48 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:48 --> Total execution time: 0.0460
DEBUG - 2011-08-13 14:13:52 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:52 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:52 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Controller Class Initialized
ERROR - 2011-08-13 14:13:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:13:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:13:52 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:52 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:13:52 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:52 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:52 --> Total execution time: 0.0349
DEBUG - 2011-08-13 14:13:52 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:52 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:52 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:52 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:13:52 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:52 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:52 --> Total execution time: 0.1175
DEBUG - 2011-08-13 14:13:56 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:56 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:56 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:56 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:13:56 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:56 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:56 --> Total execution time: 0.3703
DEBUG - 2011-08-13 14:13:58 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:58 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Router Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Output Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Input Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:13:58 --> Language Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Loader Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Controller Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Model Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:13:58 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:13:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:13:58 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:13:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:13:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:13:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:13:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:13:58 --> Final output sent to browser
DEBUG - 2011-08-13 14:13:58 --> Total execution time: 0.0598
DEBUG - 2011-08-13 14:13:58 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:58 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Router Class Initialized
ERROR - 2011-08-13 14:13:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:13:58 --> Config Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:13:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:13:58 --> URI Class Initialized
DEBUG - 2011-08-13 14:13:58 --> Router Class Initialized
ERROR - 2011-08-13 14:13:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:17:12 --> Config Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:17:12 --> URI Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Router Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Output Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Input Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:17:12 --> Language Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Loader Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Controller Class Initialized
ERROR - 2011-08-13 14:17:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:17:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:17:12 --> Model Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Model Class Initialized
DEBUG - 2011-08-13 14:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:17:12 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:17:12 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:17:12 --> Final output sent to browser
DEBUG - 2011-08-13 14:17:12 --> Total execution time: 0.0280
DEBUG - 2011-08-13 14:17:14 --> Config Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:17:14 --> URI Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Router Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Output Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Input Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:17:14 --> Language Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Loader Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Controller Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:17:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:17:15 --> Final output sent to browser
DEBUG - 2011-08-13 14:17:15 --> Total execution time: 0.4981
DEBUG - 2011-08-13 14:17:23 --> Config Class Initialized
DEBUG - 2011-08-13 14:17:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:17:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:17:23 --> URI Class Initialized
DEBUG - 2011-08-13 14:17:23 --> Router Class Initialized
ERROR - 2011-08-13 14:17:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:18:24 --> Config Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:18:24 --> URI Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Router Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Output Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Input Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:18:24 --> Language Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Loader Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Controller Class Initialized
ERROR - 2011-08-13 14:18:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:18:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:18:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:18:24 --> Model Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Model Class Initialized
DEBUG - 2011-08-13 14:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:18:24 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:18:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:18:24 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:18:24 --> Final output sent to browser
DEBUG - 2011-08-13 14:18:24 --> Total execution time: 0.0339
DEBUG - 2011-08-13 14:18:25 --> Config Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:18:25 --> URI Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Router Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Output Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Input Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:18:25 --> Language Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Loader Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Controller Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Model Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Model Class Initialized
DEBUG - 2011-08-13 14:18:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:18:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:18:26 --> Final output sent to browser
DEBUG - 2011-08-13 14:18:26 --> Total execution time: 0.6601
DEBUG - 2011-08-13 14:18:29 --> Config Class Initialized
DEBUG - 2011-08-13 14:18:29 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:18:29 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:18:29 --> URI Class Initialized
DEBUG - 2011-08-13 14:18:29 --> Router Class Initialized
ERROR - 2011-08-13 14:18:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:18:34 --> Config Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:18:34 --> URI Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Router Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Output Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Input Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:18:34 --> Language Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Loader Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Controller Class Initialized
ERROR - 2011-08-13 14:18:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:18:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:18:34 --> Model Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Model Class Initialized
DEBUG - 2011-08-13 14:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:18:34 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:18:34 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:18:34 --> Final output sent to browser
DEBUG - 2011-08-13 14:18:34 --> Total execution time: 0.0290
DEBUG - 2011-08-13 14:18:36 --> Config Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:18:36 --> URI Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Router Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Output Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Input Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:18:36 --> Language Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Loader Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Controller Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Model Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Model Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:18:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:18:36 --> Final output sent to browser
DEBUG - 2011-08-13 14:18:36 --> Total execution time: 0.5142
DEBUG - 2011-08-13 14:18:38 --> Config Class Initialized
DEBUG - 2011-08-13 14:18:38 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:18:38 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:18:38 --> URI Class Initialized
DEBUG - 2011-08-13 14:18:38 --> Router Class Initialized
ERROR - 2011-08-13 14:18:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:20:49 --> Config Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:20:49 --> URI Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Router Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Output Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Input Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:20:49 --> Language Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Loader Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Controller Class Initialized
ERROR - 2011-08-13 14:20:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:20:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:20:49 --> Model Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Model Class Initialized
DEBUG - 2011-08-13 14:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:20:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:20:49 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:20:49 --> Final output sent to browser
DEBUG - 2011-08-13 14:20:49 --> Total execution time: 0.0307
DEBUG - 2011-08-13 14:20:50 --> Config Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:20:50 --> URI Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Router Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Output Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Input Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:20:50 --> Language Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Loader Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Controller Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Model Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Model Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:20:50 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:20:50 --> Final output sent to browser
DEBUG - 2011-08-13 14:20:50 --> Total execution time: 0.4733
DEBUG - 2011-08-13 14:20:51 --> Config Class Initialized
DEBUG - 2011-08-13 14:20:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:20:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:20:51 --> URI Class Initialized
DEBUG - 2011-08-13 14:20:51 --> Router Class Initialized
ERROR - 2011-08-13 14:20:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:21:14 --> Config Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:21:14 --> URI Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Router Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Output Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Input Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:21:14 --> Language Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Loader Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Controller Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Model Class Initialized
DEBUG - 2011-08-13 14:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:21:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:21:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:21:14 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:21:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:21:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:21:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:21:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:21:14 --> Final output sent to browser
DEBUG - 2011-08-13 14:21:14 --> Total execution time: 0.0569
DEBUG - 2011-08-13 14:28:13 --> Config Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:28:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:28:13 --> URI Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Router Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Output Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Input Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:28:13 --> Language Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Loader Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Controller Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Model Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Model Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Model Class Initialized
DEBUG - 2011-08-13 14:28:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:28:13 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:28:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:28:13 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:28:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:28:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:28:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:28:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:28:13 --> Final output sent to browser
DEBUG - 2011-08-13 14:28:13 --> Total execution time: 0.1125
DEBUG - 2011-08-13 14:28:25 --> Config Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:28:25 --> URI Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Router Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Output Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Input Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:28:25 --> Language Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Loader Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Controller Class Initialized
ERROR - 2011-08-13 14:28:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:28:25 --> Model Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Model Class Initialized
DEBUG - 2011-08-13 14:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:28:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:28:25 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:28:25 --> Final output sent to browser
DEBUG - 2011-08-13 14:28:25 --> Total execution time: 0.0609
DEBUG - 2011-08-13 14:30:43 --> Config Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:30:43 --> URI Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Router Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Output Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Input Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:30:43 --> Language Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Loader Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Controller Class Initialized
ERROR - 2011-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:30:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:30:43 --> Model Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Model Class Initialized
DEBUG - 2011-08-13 14:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:30:43 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:30:43 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:30:43 --> Final output sent to browser
DEBUG - 2011-08-13 14:30:43 --> Total execution time: 0.0295
DEBUG - 2011-08-13 14:30:44 --> Config Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:30:44 --> URI Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Router Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Output Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Input Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:30:44 --> Language Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Loader Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Controller Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Model Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Model Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:30:44 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:30:44 --> Final output sent to browser
DEBUG - 2011-08-13 14:30:44 --> Total execution time: 0.5343
DEBUG - 2011-08-13 14:30:46 --> Config Class Initialized
DEBUG - 2011-08-13 14:30:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:30:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:30:46 --> URI Class Initialized
DEBUG - 2011-08-13 14:30:46 --> Router Class Initialized
ERROR - 2011-08-13 14:30:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:30:46 --> Config Class Initialized
DEBUG - 2011-08-13 14:30:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:30:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:30:46 --> URI Class Initialized
DEBUG - 2011-08-13 14:30:46 --> Router Class Initialized
ERROR - 2011-08-13 14:30:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:30:47 --> Config Class Initialized
DEBUG - 2011-08-13 14:30:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:30:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:30:47 --> URI Class Initialized
DEBUG - 2011-08-13 14:30:47 --> Router Class Initialized
ERROR - 2011-08-13 14:30:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:30:54 --> Config Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:30:54 --> URI Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Router Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Output Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Input Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:30:54 --> Language Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Loader Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Controller Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Model Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Model Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Model Class Initialized
DEBUG - 2011-08-13 14:30:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:30:54 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:30:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:30:54 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:30:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:30:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:30:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:30:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:30:54 --> Final output sent to browser
DEBUG - 2011-08-13 14:30:54 --> Total execution time: 0.0451
DEBUG - 2011-08-13 14:31:02 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:02 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:02 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:03 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:03 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:03 --> Total execution time: 0.6734
DEBUG - 2011-08-13 14:31:05 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:05 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:05 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:05 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:05 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:05 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:05 --> Total execution time: 0.0467
DEBUG - 2011-08-13 14:31:13 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:13 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:13 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:13 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:14 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:14 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:14 --> Total execution time: 0.2675
DEBUG - 2011-08-13 14:31:17 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:17 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:17 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:17 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:17 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:17 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:17 --> Total execution time: 0.0407
DEBUG - 2011-08-13 14:31:21 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:21 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:21 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:21 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:21 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:21 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:21 --> Total execution time: 0.2887
DEBUG - 2011-08-13 14:31:22 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:22 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:22 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:22 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:22 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:22 --> Total execution time: 0.0715
DEBUG - 2011-08-13 14:31:28 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:28 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:28 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:28 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:28 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:28 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:28 --> Total execution time: 0.2427
DEBUG - 2011-08-13 14:31:43 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:43 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:43 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:43 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:43 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:43 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:43 --> Total execution time: 0.2082
DEBUG - 2011-08-13 14:31:57 --> Config Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:31:57 --> URI Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Router Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Output Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Input Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:31:57 --> Language Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Loader Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Controller Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Model Class Initialized
DEBUG - 2011-08-13 14:31:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:31:57 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:31:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:31:57 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:31:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:31:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:31:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:31:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:31:57 --> Final output sent to browser
DEBUG - 2011-08-13 14:31:57 --> Total execution time: 0.3070
DEBUG - 2011-08-13 14:32:22 --> Config Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:32:22 --> URI Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Router Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Output Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Input Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:32:22 --> Language Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Loader Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Controller Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:32:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:32:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:32:22 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:32:22 --> Final output sent to browser
DEBUG - 2011-08-13 14:32:22 --> Total execution time: 0.0472
DEBUG - 2011-08-13 14:32:23 --> Config Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:32:23 --> URI Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Router Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Output Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Input Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:32:23 --> Language Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Loader Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Controller Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:32:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:32:23 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:32:23 --> Final output sent to browser
DEBUG - 2011-08-13 14:32:23 --> Total execution time: 0.0446
DEBUG - 2011-08-13 14:32:26 --> Config Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:32:26 --> URI Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Router Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Output Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Input Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:32:26 --> Language Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Loader Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Controller Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Model Class Initialized
DEBUG - 2011-08-13 14:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:32:26 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:32:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:32:26 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:32:26 --> Final output sent to browser
DEBUG - 2011-08-13 14:32:26 --> Total execution time: 0.0605
DEBUG - 2011-08-13 14:58:50 --> Config Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:58:50 --> URI Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Router Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Output Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Input Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:58:50 --> Language Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Loader Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Controller Class Initialized
ERROR - 2011-08-13 14:58:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:58:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:58:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:58:50 --> Model Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Model Class Initialized
DEBUG - 2011-08-13 14:58:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:58:50 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:58:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:58:50 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:58:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:58:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:58:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:58:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:58:50 --> Final output sent to browser
DEBUG - 2011-08-13 14:58:50 --> Total execution time: 0.0320
DEBUG - 2011-08-13 14:58:52 --> Config Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:58:52 --> URI Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Router Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Output Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Input Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:58:52 --> Language Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Loader Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Controller Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Model Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Model Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:58:52 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:58:52 --> Final output sent to browser
DEBUG - 2011-08-13 14:58:52 --> Total execution time: 0.7021
DEBUG - 2011-08-13 14:58:56 --> Config Class Initialized
DEBUG - 2011-08-13 14:58:56 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:58:56 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:58:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:58:56 --> URI Class Initialized
DEBUG - 2011-08-13 14:58:56 --> Router Class Initialized
ERROR - 2011-08-13 14:58:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:59:10 --> Config Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:59:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:59:10 --> URI Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Router Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Output Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Input Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:59:10 --> Language Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Loader Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Controller Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Model Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Model Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Model Class Initialized
DEBUG - 2011-08-13 14:59:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:59:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:59:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 14:59:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:59:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:59:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:59:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:59:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:59:10 --> Final output sent to browser
DEBUG - 2011-08-13 14:59:10 --> Total execution time: 0.3439
DEBUG - 2011-08-13 14:59:11 --> Config Class Initialized
DEBUG - 2011-08-13 14:59:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:59:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:59:11 --> URI Class Initialized
DEBUG - 2011-08-13 14:59:11 --> Router Class Initialized
ERROR - 2011-08-13 14:59:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:59:11 --> Config Class Initialized
DEBUG - 2011-08-13 14:59:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:59:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:59:11 --> URI Class Initialized
DEBUG - 2011-08-13 14:59:11 --> Router Class Initialized
ERROR - 2011-08-13 14:59:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:59:13 --> Config Class Initialized
DEBUG - 2011-08-13 14:59:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:59:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:59:13 --> URI Class Initialized
DEBUG - 2011-08-13 14:59:13 --> Router Class Initialized
ERROR - 2011-08-13 14:59:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 14:59:17 --> Config Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:59:17 --> URI Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Router Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Output Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Input Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:59:17 --> Language Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Loader Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Controller Class Initialized
ERROR - 2011-08-13 14:59:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 14:59:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 14:59:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:59:17 --> Model Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Model Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:59:17 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:59:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 14:59:17 --> Helper loaded: url_helper
DEBUG - 2011-08-13 14:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 14:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 14:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 14:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 14:59:17 --> Final output sent to browser
DEBUG - 2011-08-13 14:59:17 --> Total execution time: 0.0336
DEBUG - 2011-08-13 14:59:17 --> Config Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 14:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 14:59:17 --> URI Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Router Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Output Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Input Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 14:59:17 --> Language Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Loader Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Controller Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Model Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Model Class Initialized
DEBUG - 2011-08-13 14:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 14:59:17 --> Database Driver Class Initialized
DEBUG - 2011-08-13 14:59:18 --> Final output sent to browser
DEBUG - 2011-08-13 14:59:18 --> Total execution time: 0.6314
DEBUG - 2011-08-13 15:00:49 --> Config Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:00:49 --> URI Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Router Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Output Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Input Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:00:49 --> Language Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Loader Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Controller Class Initialized
ERROR - 2011-08-13 15:00:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:00:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:00:49 --> Model Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Model Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:00:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:00:49 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:00:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:00:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:00:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:00:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:00:49 --> Final output sent to browser
DEBUG - 2011-08-13 15:00:49 --> Total execution time: 0.0307
DEBUG - 2011-08-13 15:00:49 --> Config Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:00:49 --> URI Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Router Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Output Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Input Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:00:49 --> Language Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Loader Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Controller Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Model Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Model Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:00:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:00:49 --> Final output sent to browser
DEBUG - 2011-08-13 15:00:49 --> Total execution time: 0.4925
DEBUG - 2011-08-13 15:00:51 --> Config Class Initialized
DEBUG - 2011-08-13 15:00:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:00:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:00:51 --> URI Class Initialized
DEBUG - 2011-08-13 15:00:51 --> Router Class Initialized
ERROR - 2011-08-13 15:00:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:01:10 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:10 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Router Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Output Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Input Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:01:10 --> Language Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Loader Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Controller Class Initialized
ERROR - 2011-08-13 15:01:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:01:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:01:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:01:10 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:01:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:01:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:01:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:01:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:01:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:01:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:01:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:01:10 --> Final output sent to browser
DEBUG - 2011-08-13 15:01:10 --> Total execution time: 0.0282
DEBUG - 2011-08-13 15:01:11 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:11 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Router Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Output Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Input Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:01:11 --> Language Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Loader Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Controller Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:01:11 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:01:12 --> Final output sent to browser
DEBUG - 2011-08-13 15:01:12 --> Total execution time: 0.7012
DEBUG - 2011-08-13 15:01:13 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:13 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:13 --> Router Class Initialized
ERROR - 2011-08-13 15:01:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:01:34 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:34 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Router Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Output Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Input Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:01:34 --> Language Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Loader Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Controller Class Initialized
ERROR - 2011-08-13 15:01:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:01:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:01:34 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:01:34 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:01:35 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:01:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:01:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:01:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:01:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:01:35 --> Final output sent to browser
DEBUG - 2011-08-13 15:01:35 --> Total execution time: 0.0276
DEBUG - 2011-08-13 15:01:35 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:35 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Router Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Output Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Input Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:01:35 --> Language Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Loader Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Controller Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:01:35 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:01:36 --> Final output sent to browser
DEBUG - 2011-08-13 15:01:36 --> Total execution time: 0.4855
DEBUG - 2011-08-13 15:01:37 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:37 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:37 --> Router Class Initialized
ERROR - 2011-08-13 15:01:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:01:52 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:52 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Router Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Output Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Input Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:01:52 --> Language Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Loader Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Controller Class Initialized
ERROR - 2011-08-13 15:01:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:01:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:01:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:01:52 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:01:52 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:01:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:01:52 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:01:52 --> Final output sent to browser
DEBUG - 2011-08-13 15:01:52 --> Total execution time: 0.0276
DEBUG - 2011-08-13 15:01:53 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:53 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Router Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Output Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Input Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:01:53 --> Language Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Loader Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Controller Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Model Class Initialized
DEBUG - 2011-08-13 15:01:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:01:53 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:01:54 --> Final output sent to browser
DEBUG - 2011-08-13 15:01:54 --> Total execution time: 0.6119
DEBUG - 2011-08-13 15:01:55 --> Config Class Initialized
DEBUG - 2011-08-13 15:01:55 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:01:55 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:01:55 --> URI Class Initialized
DEBUG - 2011-08-13 15:01:55 --> Router Class Initialized
ERROR - 2011-08-13 15:01:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:02:05 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:05 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Router Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Output Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Input Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:02:05 --> Language Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Loader Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Controller Class Initialized
ERROR - 2011-08-13 15:02:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:02:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:02:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:02:05 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:02:05 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:02:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:02:05 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:02:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:02:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:02:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:02:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:02:05 --> Final output sent to browser
DEBUG - 2011-08-13 15:02:05 --> Total execution time: 0.0285
DEBUG - 2011-08-13 15:02:06 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:06 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Router Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Output Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Input Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:02:06 --> Language Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Loader Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Controller Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:02:06 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:02:07 --> Final output sent to browser
DEBUG - 2011-08-13 15:02:07 --> Total execution time: 0.5528
DEBUG - 2011-08-13 15:02:08 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:08 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:08 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:08 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:08 --> Router Class Initialized
ERROR - 2011-08-13 15:02:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:02:21 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:21 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Router Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Output Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Input Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:02:21 --> Language Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Loader Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Controller Class Initialized
ERROR - 2011-08-13 15:02:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:02:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:02:21 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:02:21 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:02:21 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:02:21 --> Final output sent to browser
DEBUG - 2011-08-13 15:02:21 --> Total execution time: 0.0285
DEBUG - 2011-08-13 15:02:22 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:22 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Router Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Output Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Input Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:02:22 --> Language Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Loader Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Controller Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:02:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:02:22 --> Final output sent to browser
DEBUG - 2011-08-13 15:02:22 --> Total execution time: 0.5507
DEBUG - 2011-08-13 15:02:24 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:24 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:24 --> Router Class Initialized
ERROR - 2011-08-13 15:02:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:02:40 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:40 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Router Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Output Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Input Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:02:40 --> Language Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Loader Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Controller Class Initialized
ERROR - 2011-08-13 15:02:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:02:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:02:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:02:40 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:02:40 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:02:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:02:40 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:02:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:02:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:02:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:02:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:02:40 --> Final output sent to browser
DEBUG - 2011-08-13 15:02:40 --> Total execution time: 0.0285
DEBUG - 2011-08-13 15:02:41 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:41 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Router Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Output Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Input Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:02:41 --> Language Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Loader Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Controller Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Model Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:02:41 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:02:41 --> Final output sent to browser
DEBUG - 2011-08-13 15:02:41 --> Total execution time: 0.5674
DEBUG - 2011-08-13 15:02:43 --> Config Class Initialized
DEBUG - 2011-08-13 15:02:43 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:02:43 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:02:43 --> URI Class Initialized
DEBUG - 2011-08-13 15:02:43 --> Router Class Initialized
ERROR - 2011-08-13 15:02:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:03:03 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:03 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:03 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Controller Class Initialized
ERROR - 2011-08-13 15:03:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:03:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:03 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:03 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:03 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:03:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:03:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:03:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:03:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:03:03 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:03 --> Total execution time: 0.0309
DEBUG - 2011-08-13 15:03:03 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:03 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:03 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:04 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:04 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:04 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:04 --> Controller Class Initialized
DEBUG - 2011-08-13 15:03:04 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:04 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:04 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:04 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:04 --> Total execution time: 0.7776
DEBUG - 2011-08-13 15:03:06 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:06 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:06 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:06 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:06 --> Router Class Initialized
ERROR - 2011-08-13 15:03:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:03:19 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:19 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:19 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Controller Class Initialized
ERROR - 2011-08-13 15:03:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:03:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:03:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:19 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:19 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:19 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:03:19 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:19 --> Total execution time: 0.0277
DEBUG - 2011-08-13 15:03:19 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:19 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:19 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Controller Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:19 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:20 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:20 --> Total execution time: 0.5324
DEBUG - 2011-08-13 15:03:21 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:21 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:21 --> Router Class Initialized
ERROR - 2011-08-13 15:03:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:03:29 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:29 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:29 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Controller Class Initialized
ERROR - 2011-08-13 15:03:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:03:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:03:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:29 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:29 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:29 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:03:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:03:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:03:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:03:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:03:29 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:29 --> Total execution time: 0.0289
DEBUG - 2011-08-13 15:03:29 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:29 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:29 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Controller Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:29 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:30 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:30 --> Total execution time: 0.5323
DEBUG - 2011-08-13 15:03:31 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:31 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:31 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:31 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:31 --> Router Class Initialized
ERROR - 2011-08-13 15:03:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:03:37 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:37 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:37 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Controller Class Initialized
ERROR - 2011-08-13 15:03:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:03:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:03:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:37 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:37 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:37 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:03:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:03:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:03:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:03:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:03:37 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:37 --> Total execution time: 0.0271
DEBUG - 2011-08-13 15:03:37 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:37 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:37 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Controller Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:37 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:38 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:38 --> Total execution time: 0.5896
DEBUG - 2011-08-13 15:03:39 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:39 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:39 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:39 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:39 --> Router Class Initialized
ERROR - 2011-08-13 15:03:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:03:45 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:45 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:45 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Controller Class Initialized
ERROR - 2011-08-13 15:03:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:03:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:03:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:45 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:45 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:03:45 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:03:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:03:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:03:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:03:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:03:45 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:45 --> Total execution time: 0.0301
DEBUG - 2011-08-13 15:03:46 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:46 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Router Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Output Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Input Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:03:46 --> Language Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Loader Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Controller Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Model Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:03:46 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:03:46 --> Final output sent to browser
DEBUG - 2011-08-13 15:03:46 --> Total execution time: 0.5471
DEBUG - 2011-08-13 15:03:48 --> Config Class Initialized
DEBUG - 2011-08-13 15:03:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:03:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:03:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:03:48 --> URI Class Initialized
DEBUG - 2011-08-13 15:03:48 --> Router Class Initialized
ERROR - 2011-08-13 15:03:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:04:09 --> Config Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:04:09 --> URI Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Router Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Output Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Input Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:04:09 --> Language Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Loader Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Controller Class Initialized
ERROR - 2011-08-13 15:04:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:04:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:04:09 --> Model Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Model Class Initialized
DEBUG - 2011-08-13 15:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:04:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:04:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:04:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:04:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:04:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:04:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:04:10 --> Final output sent to browser
DEBUG - 2011-08-13 15:04:10 --> Total execution time: 0.0278
DEBUG - 2011-08-13 15:04:22 --> Config Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:04:22 --> URI Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Router Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Output Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Input Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:04:22 --> Language Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Loader Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Controller Class Initialized
ERROR - 2011-08-13 15:04:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:04:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:04:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:04:22 --> Model Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Model Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:04:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:04:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:04:22 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:04:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:04:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:04:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:04:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:04:22 --> Final output sent to browser
DEBUG - 2011-08-13 15:04:22 --> Total execution time: 0.0399
DEBUG - 2011-08-13 15:04:22 --> Config Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:04:22 --> URI Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Router Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Output Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Input Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:04:22 --> Language Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Loader Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Controller Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Model Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Model Class Initialized
DEBUG - 2011-08-13 15:04:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:04:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Final output sent to browser
DEBUG - 2011-08-13 15:04:23 --> Total execution time: 0.5635
DEBUG - 2011-08-13 15:04:23 --> Config Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:04:23 --> URI Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Router Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Output Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Input Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:04:23 --> Language Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Loader Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Controller Class Initialized
ERROR - 2011-08-13 15:04:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:04:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:04:23 --> Model Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Model Class Initialized
DEBUG - 2011-08-13 15:04:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:04:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:04:23 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:04:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:04:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:04:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:04:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:04:23 --> Final output sent to browser
DEBUG - 2011-08-13 15:04:23 --> Total execution time: 0.0332
DEBUG - 2011-08-13 15:04:24 --> Config Class Initialized
DEBUG - 2011-08-13 15:04:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:04:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:04:24 --> URI Class Initialized
DEBUG - 2011-08-13 15:04:24 --> Router Class Initialized
ERROR - 2011-08-13 15:04:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:05:00 --> Config Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:05:00 --> URI Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Router Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Output Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Input Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:05:00 --> Language Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Loader Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Controller Class Initialized
ERROR - 2011-08-13 15:05:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 15:05:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 15:05:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:05:00 --> Model Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Model Class Initialized
DEBUG - 2011-08-13 15:05:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:05:00 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:05:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 15:05:00 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:05:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:05:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:05:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:05:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:05:00 --> Final output sent to browser
DEBUG - 2011-08-13 15:05:00 --> Total execution time: 0.2554
DEBUG - 2011-08-13 15:05:01 --> Config Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:05:01 --> URI Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Router Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Output Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Input Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:05:01 --> Language Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Loader Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Controller Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Model Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Model Class Initialized
DEBUG - 2011-08-13 15:05:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:05:01 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:05:02 --> Final output sent to browser
DEBUG - 2011-08-13 15:05:02 --> Total execution time: 0.8921
DEBUG - 2011-08-13 15:05:04 --> Config Class Initialized
DEBUG - 2011-08-13 15:05:04 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:05:04 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:05:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:05:04 --> URI Class Initialized
DEBUG - 2011-08-13 15:05:04 --> Router Class Initialized
ERROR - 2011-08-13 15:05:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 15:33:02 --> Config Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:33:02 --> URI Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Router Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Output Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Input Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 15:33:02 --> Language Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Loader Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Controller Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Model Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Model Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Model Class Initialized
DEBUG - 2011-08-13 15:33:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 15:33:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 15:33:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 15:33:03 --> Helper loaded: url_helper
DEBUG - 2011-08-13 15:33:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 15:33:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 15:33:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 15:33:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 15:33:03 --> Final output sent to browser
DEBUG - 2011-08-13 15:33:03 --> Total execution time: 0.2607
DEBUG - 2011-08-13 15:33:05 --> Config Class Initialized
DEBUG - 2011-08-13 15:33:05 --> Hooks Class Initialized
DEBUG - 2011-08-13 15:33:05 --> Utf8 Class Initialized
DEBUG - 2011-08-13 15:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 15:33:05 --> URI Class Initialized
DEBUG - 2011-08-13 15:33:05 --> Router Class Initialized
ERROR - 2011-08-13 15:33:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 16:23:38 --> Config Class Initialized
DEBUG - 2011-08-13 16:23:38 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:23:38 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:23:38 --> URI Class Initialized
DEBUG - 2011-08-13 16:23:38 --> Router Class Initialized
DEBUG - 2011-08-13 16:23:38 --> No URI present. Default controller set.
DEBUG - 2011-08-13 16:23:38 --> Output Class Initialized
DEBUG - 2011-08-13 16:23:38 --> Input Class Initialized
DEBUG - 2011-08-13 16:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 16:23:38 --> Language Class Initialized
DEBUG - 2011-08-13 16:23:38 --> Loader Class Initialized
DEBUG - 2011-08-13 16:23:38 --> Controller Class Initialized
DEBUG - 2011-08-13 16:23:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-13 16:23:38 --> Helper loaded: url_helper
DEBUG - 2011-08-13 16:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 16:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 16:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 16:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 16:23:38 --> Final output sent to browser
DEBUG - 2011-08-13 16:23:38 --> Total execution time: 0.0870
DEBUG - 2011-08-13 16:23:39 --> Config Class Initialized
DEBUG - 2011-08-13 16:23:39 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:23:39 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:23:39 --> URI Class Initialized
DEBUG - 2011-08-13 16:23:39 --> Router Class Initialized
ERROR - 2011-08-13 16:23:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 16:27:01 --> Config Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:27:01 --> URI Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Router Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Output Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Input Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 16:27:01 --> Language Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Loader Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Controller Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Model Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Model Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Model Class Initialized
DEBUG - 2011-08-13 16:27:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 16:27:01 --> Database Driver Class Initialized
DEBUG - 2011-08-13 16:27:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 16:27:01 --> Helper loaded: url_helper
DEBUG - 2011-08-13 16:27:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 16:27:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 16:27:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 16:27:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 16:27:01 --> Final output sent to browser
DEBUG - 2011-08-13 16:27:01 --> Total execution time: 0.5189
DEBUG - 2011-08-13 16:27:03 --> Config Class Initialized
DEBUG - 2011-08-13 16:27:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:27:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:27:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:27:03 --> URI Class Initialized
DEBUG - 2011-08-13 16:27:03 --> Router Class Initialized
ERROR - 2011-08-13 16:27:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 16:27:04 --> Config Class Initialized
DEBUG - 2011-08-13 16:27:04 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:27:04 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:27:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:27:04 --> URI Class Initialized
DEBUG - 2011-08-13 16:27:04 --> Router Class Initialized
ERROR - 2011-08-13 16:27:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 16:47:27 --> Config Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:47:27 --> URI Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Router Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Output Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Input Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 16:47:27 --> Language Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Loader Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Controller Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Model Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Model Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Model Class Initialized
DEBUG - 2011-08-13 16:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 16:47:27 --> Database Driver Class Initialized
DEBUG - 2011-08-13 16:47:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 16:47:27 --> Helper loaded: url_helper
DEBUG - 2011-08-13 16:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 16:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 16:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 16:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 16:47:27 --> Final output sent to browser
DEBUG - 2011-08-13 16:47:27 --> Total execution time: 0.1932
DEBUG - 2011-08-13 16:47:51 --> Config Class Initialized
DEBUG - 2011-08-13 16:47:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:47:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:47:51 --> URI Class Initialized
DEBUG - 2011-08-13 16:47:51 --> Router Class Initialized
ERROR - 2011-08-13 16:47:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 16:47:51 --> Config Class Initialized
DEBUG - 2011-08-13 16:47:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:47:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:47:51 --> URI Class Initialized
DEBUG - 2011-08-13 16:47:51 --> Router Class Initialized
ERROR - 2011-08-13 16:47:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 16:48:12 --> Config Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 16:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 16:48:12 --> URI Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Router Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Output Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Input Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 16:48:12 --> Language Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Loader Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Controller Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Model Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Model Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Model Class Initialized
DEBUG - 2011-08-13 16:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 16:48:12 --> Database Driver Class Initialized
DEBUG - 2011-08-13 16:48:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 16:48:13 --> Helper loaded: url_helper
DEBUG - 2011-08-13 16:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 16:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 16:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 16:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 16:48:13 --> Final output sent to browser
DEBUG - 2011-08-13 16:48:13 --> Total execution time: 0.2495
DEBUG - 2011-08-13 17:13:48 --> Config Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:13:48 --> URI Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Router Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Output Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Input Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:13:48 --> Language Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Loader Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Controller Class Initialized
ERROR - 2011-08-13 17:13:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:13:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:13:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:13:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:13:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:13:48 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:13:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:13:48 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:13:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:13:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:13:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:13:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:13:48 --> Final output sent to browser
DEBUG - 2011-08-13 17:13:48 --> Total execution time: 0.0591
DEBUG - 2011-08-13 17:13:49 --> Config Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:13:49 --> URI Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Router Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Output Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Input Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:13:49 --> Language Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Loader Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Controller Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Model Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Model Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:13:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:13:49 --> Final output sent to browser
DEBUG - 2011-08-13 17:13:49 --> Total execution time: 0.6510
DEBUG - 2011-08-13 17:13:50 --> Config Class Initialized
DEBUG - 2011-08-13 17:13:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:13:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:13:50 --> URI Class Initialized
DEBUG - 2011-08-13 17:13:50 --> Router Class Initialized
ERROR - 2011-08-13 17:13:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 17:14:21 --> Config Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:14:21 --> URI Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Router Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Output Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Input Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:14:21 --> Language Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Loader Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Controller Class Initialized
ERROR - 2011-08-13 17:14:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:14:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:14:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:14:21 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:14:21 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:14:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:14:21 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:14:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:14:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:14:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:14:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:14:21 --> Final output sent to browser
DEBUG - 2011-08-13 17:14:21 --> Total execution time: 0.0294
DEBUG - 2011-08-13 17:14:22 --> Config Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:14:22 --> URI Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Router Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Output Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Input Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:14:22 --> Language Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Loader Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Controller Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:14:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:14:22 --> Final output sent to browser
DEBUG - 2011-08-13 17:14:22 --> Total execution time: 0.7515
DEBUG - 2011-08-13 17:14:31 --> Config Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:14:31 --> URI Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Router Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Output Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Input Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:14:31 --> Language Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Loader Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Controller Class Initialized
ERROR - 2011-08-13 17:14:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:14:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:14:31 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:14:31 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:14:31 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:14:31 --> Final output sent to browser
DEBUG - 2011-08-13 17:14:31 --> Total execution time: 0.0306
DEBUG - 2011-08-13 17:14:32 --> Config Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:14:32 --> URI Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Router Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Output Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Input Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:14:32 --> Language Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Loader Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Controller Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:14:32 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:14:32 --> Final output sent to browser
DEBUG - 2011-08-13 17:14:32 --> Total execution time: 0.5042
DEBUG - 2011-08-13 17:14:48 --> Config Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:14:48 --> URI Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Router Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Output Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Input Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:14:48 --> Language Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Loader Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Controller Class Initialized
ERROR - 2011-08-13 17:14:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:14:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:14:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:14:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:14:48 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:14:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:14:48 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:14:48 --> Final output sent to browser
DEBUG - 2011-08-13 17:14:48 --> Total execution time: 0.0279
DEBUG - 2011-08-13 17:14:48 --> Config Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:14:48 --> URI Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Router Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Output Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Input Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:14:48 --> Language Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Loader Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Controller Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:14:48 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:14:49 --> Final output sent to browser
DEBUG - 2011-08-13 17:14:49 --> Total execution time: 0.6442
DEBUG - 2011-08-13 17:14:59 --> Config Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:14:59 --> URI Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Router Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Output Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Input Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:14:59 --> Language Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Loader Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Controller Class Initialized
ERROR - 2011-08-13 17:14:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:14:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:14:59 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:14:59 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:14:59 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:14:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:14:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:14:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:14:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:14:59 --> Final output sent to browser
DEBUG - 2011-08-13 17:14:59 --> Total execution time: 0.0338
DEBUG - 2011-08-13 17:14:59 --> Config Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:14:59 --> URI Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Router Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Output Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Input Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:14:59 --> Language Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Loader Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Controller Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Model Class Initialized
DEBUG - 2011-08-13 17:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:14:59 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:15:00 --> Final output sent to browser
DEBUG - 2011-08-13 17:15:00 --> Total execution time: 0.5379
DEBUG - 2011-08-13 17:15:14 --> Config Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:15:14 --> URI Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Router Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Output Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Input Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:15:14 --> Language Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Loader Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Controller Class Initialized
ERROR - 2011-08-13 17:15:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:15:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:15:14 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:15:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:15:14 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:15:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:15:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:15:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:15:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:15:14 --> Final output sent to browser
DEBUG - 2011-08-13 17:15:14 --> Total execution time: 0.0291
DEBUG - 2011-08-13 17:15:14 --> Config Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:15:14 --> URI Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Router Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Output Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Input Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:15:14 --> Language Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Loader Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Controller Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:15:14 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:15:15 --> Final output sent to browser
DEBUG - 2011-08-13 17:15:15 --> Total execution time: 0.5551
DEBUG - 2011-08-13 17:15:36 --> Config Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:15:36 --> URI Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Router Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Output Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Input Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:15:36 --> Language Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Loader Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Controller Class Initialized
ERROR - 2011-08-13 17:15:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:15:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:15:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:15:36 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:15:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:15:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:15:36 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:15:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:15:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:15:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:15:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:15:36 --> Final output sent to browser
DEBUG - 2011-08-13 17:15:36 --> Total execution time: 0.0296
DEBUG - 2011-08-13 17:15:36 --> Config Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:15:36 --> URI Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Router Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Output Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Input Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:15:36 --> Language Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Loader Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Controller Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:15:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:15:37 --> Final output sent to browser
DEBUG - 2011-08-13 17:15:37 --> Total execution time: 0.5521
DEBUG - 2011-08-13 17:15:47 --> Config Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:15:47 --> URI Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Router Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Output Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Input Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:15:47 --> Language Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Loader Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Controller Class Initialized
ERROR - 2011-08-13 17:15:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:15:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:15:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:15:47 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:15:47 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:15:47 --> Final output sent to browser
DEBUG - 2011-08-13 17:15:47 --> Total execution time: 0.0308
DEBUG - 2011-08-13 17:15:47 --> Config Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:15:47 --> URI Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Router Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Output Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Input Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:15:47 --> Language Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Loader Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Controller Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:15:47 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:15:48 --> Final output sent to browser
DEBUG - 2011-08-13 17:15:48 --> Total execution time: 0.5616
DEBUG - 2011-08-13 17:16:18 --> Config Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:16:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:16:18 --> URI Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Router Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Output Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Input Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:16:18 --> Language Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Loader Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Controller Class Initialized
ERROR - 2011-08-13 17:16:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:16:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:16:18 --> Model Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Model Class Initialized
DEBUG - 2011-08-13 17:16:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:16:18 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:16:18 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:16:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:16:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:16:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:16:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:16:18 --> Final output sent to browser
DEBUG - 2011-08-13 17:16:18 --> Total execution time: 0.0275
DEBUG - 2011-08-13 17:16:19 --> Config Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:16:19 --> URI Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Router Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Output Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Input Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:16:19 --> Language Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Loader Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Controller Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Model Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Model Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:16:19 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:16:19 --> Final output sent to browser
DEBUG - 2011-08-13 17:16:19 --> Total execution time: 0.5584
DEBUG - 2011-08-13 17:17:01 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:01 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:01 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Controller Class Initialized
ERROR - 2011-08-13 17:17:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:17:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:01 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:01 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:01 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:17:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:17:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:17:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:17:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:17:01 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:01 --> Total execution time: 0.0797
DEBUG - 2011-08-13 17:17:01 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:01 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:01 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Controller Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:01 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:02 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:02 --> Total execution time: 0.6323
DEBUG - 2011-08-13 17:17:23 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:23 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:23 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Controller Class Initialized
ERROR - 2011-08-13 17:17:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:17:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:17:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:23 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:23 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:17:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:17:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:17:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:17:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:17:23 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:23 --> Total execution time: 0.0275
DEBUG - 2011-08-13 17:17:23 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:23 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:23 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Controller Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:24 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:24 --> Total execution time: 0.5409
DEBUG - 2011-08-13 17:17:35 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:36 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:36 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Controller Class Initialized
ERROR - 2011-08-13 17:17:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:17:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:17:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:36 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:36 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:17:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:17:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:17:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:17:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:17:36 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:36 --> Total execution time: 0.4381
DEBUG - 2011-08-13 17:17:36 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:36 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:36 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Controller Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:36 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:37 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:37 --> Total execution time: 0.4973
DEBUG - 2011-08-13 17:17:44 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:44 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:44 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Controller Class Initialized
ERROR - 2011-08-13 17:17:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:17:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:44 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:44 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:44 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:17:44 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:44 --> Total execution time: 0.0423
DEBUG - 2011-08-13 17:17:44 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:44 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:44 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Controller Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:44 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:44 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:44 --> Total execution time: 0.4897
DEBUG - 2011-08-13 17:17:56 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:56 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:56 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Controller Class Initialized
ERROR - 2011-08-13 17:17:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:17:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:56 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:56 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:17:56 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:17:56 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:56 --> Total execution time: 0.0280
DEBUG - 2011-08-13 17:17:56 --> Config Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:17:56 --> URI Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Router Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Output Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Input Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:17:56 --> Language Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Loader Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Controller Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Model Class Initialized
DEBUG - 2011-08-13 17:17:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:17:56 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:17:57 --> Final output sent to browser
DEBUG - 2011-08-13 17:17:57 --> Total execution time: 0.6024
DEBUG - 2011-08-13 17:18:20 --> Config Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:18:20 --> URI Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Router Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Output Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Input Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:18:20 --> Language Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Loader Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Controller Class Initialized
ERROR - 2011-08-13 17:18:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:18:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:18:20 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:18:20 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:18:20 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:18:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:18:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:18:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:18:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:18:20 --> Final output sent to browser
DEBUG - 2011-08-13 17:18:20 --> Total execution time: 0.0913
DEBUG - 2011-08-13 17:18:20 --> Config Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:18:20 --> URI Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Router Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Output Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Input Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:18:20 --> Language Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Loader Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Controller Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:18:20 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:18:21 --> Final output sent to browser
DEBUG - 2011-08-13 17:18:21 --> Total execution time: 0.6618
DEBUG - 2011-08-13 17:18:32 --> Config Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:18:32 --> URI Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Router Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Output Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Input Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:18:32 --> Language Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Loader Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Controller Class Initialized
ERROR - 2011-08-13 17:18:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:18:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:18:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:18:32 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:18:32 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:18:32 --> Final output sent to browser
DEBUG - 2011-08-13 17:18:32 --> Total execution time: 0.0311
DEBUG - 2011-08-13 17:18:33 --> Config Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:18:33 --> URI Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Router Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Output Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Input Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:18:33 --> Language Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Loader Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Controller Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:18:33 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:18:33 --> Final output sent to browser
DEBUG - 2011-08-13 17:18:33 --> Total execution time: 0.5590
DEBUG - 2011-08-13 17:18:48 --> Config Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:18:48 --> URI Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Router Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Output Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Input Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:18:48 --> Language Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Loader Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Controller Class Initialized
ERROR - 2011-08-13 17:18:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:18:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:18:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:18:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:18:48 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:18:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:18:48 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:18:48 --> Final output sent to browser
DEBUG - 2011-08-13 17:18:48 --> Total execution time: 0.0285
DEBUG - 2011-08-13 17:18:48 --> Config Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:18:48 --> URI Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Router Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Output Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Input Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:18:48 --> Language Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Loader Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Controller Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Model Class Initialized
DEBUG - 2011-08-13 17:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:18:48 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:18:49 --> Final output sent to browser
DEBUG - 2011-08-13 17:18:49 --> Total execution time: 0.5626
DEBUG - 2011-08-13 17:19:31 --> Config Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:19:31 --> URI Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Router Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Output Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Input Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:19:31 --> Language Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Loader Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Controller Class Initialized
ERROR - 2011-08-13 17:19:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:19:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:19:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:19:31 --> Model Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Model Class Initialized
DEBUG - 2011-08-13 17:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:19:31 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:19:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:19:31 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:19:31 --> Final output sent to browser
DEBUG - 2011-08-13 17:19:31 --> Total execution time: 0.0272
DEBUG - 2011-08-13 17:19:32 --> Config Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:19:32 --> URI Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Router Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Output Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Input Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:19:32 --> Language Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Loader Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Controller Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:19:32 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:19:33 --> Final output sent to browser
DEBUG - 2011-08-13 17:19:33 --> Total execution time: 0.5559
DEBUG - 2011-08-13 17:30:12 --> Config Class Initialized
DEBUG - 2011-08-13 17:30:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:30:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:30:12 --> URI Class Initialized
DEBUG - 2011-08-13 17:30:12 --> Router Class Initialized
ERROR - 2011-08-13 17:30:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 17:30:13 --> Config Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:30:13 --> URI Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Router Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Output Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Input Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:30:13 --> Language Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Loader Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Controller Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Model Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Model Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Model Class Initialized
DEBUG - 2011-08-13 17:30:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:30:13 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:30:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:30:13 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:30:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:30:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:30:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:30:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:30:13 --> Final output sent to browser
DEBUG - 2011-08-13 17:30:13 --> Total execution time: 0.3437
DEBUG - 2011-08-13 17:31:12 --> Config Class Initialized
DEBUG - 2011-08-13 17:31:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:31:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:31:12 --> URI Class Initialized
DEBUG - 2011-08-13 17:31:12 --> Router Class Initialized
ERROR - 2011-08-13 17:31:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 17:38:50 --> Config Class Initialized
DEBUG - 2011-08-13 17:38:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:38:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:38:50 --> URI Class Initialized
DEBUG - 2011-08-13 17:38:50 --> Router Class Initialized
DEBUG - 2011-08-13 17:38:50 --> No URI present. Default controller set.
DEBUG - 2011-08-13 17:38:50 --> Output Class Initialized
DEBUG - 2011-08-13 17:38:50 --> Input Class Initialized
DEBUG - 2011-08-13 17:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:38:50 --> Language Class Initialized
DEBUG - 2011-08-13 17:38:50 --> Loader Class Initialized
DEBUG - 2011-08-13 17:38:50 --> Controller Class Initialized
DEBUG - 2011-08-13 17:38:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-13 17:38:50 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:38:50 --> Final output sent to browser
DEBUG - 2011-08-13 17:38:50 --> Total execution time: 0.0385
DEBUG - 2011-08-13 17:38:53 --> Config Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:38:53 --> URI Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Router Class Initialized
ERROR - 2011-08-13 17:38:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 17:38:53 --> Config Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:38:53 --> URI Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Router Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Output Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Input Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:38:53 --> Language Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Loader Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Controller Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Model Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Model Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Model Class Initialized
DEBUG - 2011-08-13 17:38:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:38:53 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:38:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:38:53 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:38:53 --> Final output sent to browser
DEBUG - 2011-08-13 17:38:53 --> Total execution time: 0.0493
DEBUG - 2011-08-13 17:39:07 --> Config Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:39:07 --> URI Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Router Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Output Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Input Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:39:07 --> Language Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Loader Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Controller Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:39:07 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:39:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:39:08 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:39:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:39:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:39:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:39:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:39:08 --> Final output sent to browser
DEBUG - 2011-08-13 17:39:08 --> Total execution time: 0.1821
DEBUG - 2011-08-13 17:39:09 --> Config Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:39:09 --> URI Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Router Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Output Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Input Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:39:09 --> Language Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Loader Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Controller Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:39:09 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:39:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:39:09 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:39:09 --> Final output sent to browser
DEBUG - 2011-08-13 17:39:09 --> Total execution time: 0.0466
DEBUG - 2011-08-13 17:39:21 --> Config Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:39:21 --> URI Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Router Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Output Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Input Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:39:21 --> Language Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Loader Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Controller Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:39:21 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:39:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:39:21 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:39:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:39:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:39:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:39:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:39:21 --> Final output sent to browser
DEBUG - 2011-08-13 17:39:21 --> Total execution time: 0.2328
DEBUG - 2011-08-13 17:39:24 --> Config Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:39:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:39:24 --> URI Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Router Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Output Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Input Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:39:24 --> Language Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Loader Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Controller Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:39:24 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:39:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:39:24 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:39:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:39:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:39:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:39:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:39:24 --> Final output sent to browser
DEBUG - 2011-08-13 17:39:24 --> Total execution time: 0.0435
DEBUG - 2011-08-13 17:39:32 --> Config Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:39:32 --> URI Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Router Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Output Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Input Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:39:32 --> Language Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Loader Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Controller Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:39:32 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:39:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:39:33 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:39:33 --> Final output sent to browser
DEBUG - 2011-08-13 17:39:33 --> Total execution time: 0.3974
DEBUG - 2011-08-13 17:39:34 --> Config Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:39:34 --> URI Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Router Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Output Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Input Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:39:34 --> Language Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Loader Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Controller Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:39:34 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:39:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:39:34 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:39:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:39:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:39:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:39:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:39:34 --> Final output sent to browser
DEBUG - 2011-08-13 17:39:34 --> Total execution time: 0.0415
DEBUG - 2011-08-13 17:39:47 --> Config Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:39:47 --> URI Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Router Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Output Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Input Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:39:47 --> Language Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Loader Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Controller Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:39:47 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:39:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:39:47 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:39:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:39:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:39:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:39:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:39:47 --> Final output sent to browser
DEBUG - 2011-08-13 17:39:47 --> Total execution time: 0.2605
DEBUG - 2011-08-13 17:39:49 --> Config Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:39:49 --> URI Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Router Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Output Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Input Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:39:49 --> Language Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Loader Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Controller Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Model Class Initialized
DEBUG - 2011-08-13 17:39:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:39:49 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:39:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:39:49 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:39:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:39:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:39:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:39:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:39:49 --> Final output sent to browser
DEBUG - 2011-08-13 17:39:49 --> Total execution time: 0.0793
DEBUG - 2011-08-13 17:50:57 --> Config Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:50:57 --> URI Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Router Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Output Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Input Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:50:57 --> Language Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Loader Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Controller Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Model Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Model Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Model Class Initialized
DEBUG - 2011-08-13 17:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:50:57 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:50:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 17:50:57 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:50:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:50:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:50:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:50:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:50:57 --> Final output sent to browser
DEBUG - 2011-08-13 17:50:57 --> Total execution time: 0.0843
DEBUG - 2011-08-13 17:51:28 --> Config Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:51:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:51:28 --> URI Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Router Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Output Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Input Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:51:28 --> Language Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Loader Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Controller Class Initialized
ERROR - 2011-08-13 17:51:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:51:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:51:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:51:28 --> Model Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Model Class Initialized
DEBUG - 2011-08-13 17:51:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:51:28 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:51:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:51:28 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:51:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:51:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:51:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:51:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:51:28 --> Final output sent to browser
DEBUG - 2011-08-13 17:51:28 --> Total execution time: 0.0316
DEBUG - 2011-08-13 17:51:30 --> Config Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:51:30 --> URI Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Router Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Output Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Input Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:51:30 --> Language Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Loader Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Controller Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Model Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Model Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:51:30 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:51:30 --> Final output sent to browser
DEBUG - 2011-08-13 17:51:30 --> Total execution time: 0.5108
DEBUG - 2011-08-13 17:51:46 --> Config Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:51:46 --> URI Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Router Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Output Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Input Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:51:46 --> Language Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Loader Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Controller Class Initialized
ERROR - 2011-08-13 17:51:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:51:46 --> Model Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Model Class Initialized
DEBUG - 2011-08-13 17:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:51:46 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:51:46 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:51:46 --> Final output sent to browser
DEBUG - 2011-08-13 17:51:46 --> Total execution time: 0.0282
DEBUG - 2011-08-13 17:51:47 --> Config Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:51:47 --> URI Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Router Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Output Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Input Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:51:47 --> Language Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Loader Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Controller Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Model Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:51:47 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:51:47 --> Final output sent to browser
DEBUG - 2011-08-13 17:51:47 --> Total execution time: 0.5579
DEBUG - 2011-08-13 17:52:10 --> Config Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:52:10 --> URI Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Router Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Output Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Input Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:52:10 --> Language Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Loader Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Controller Class Initialized
ERROR - 2011-08-13 17:52:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:52:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:52:10 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:52:10 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:52:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:52:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:52:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:52:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:52:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:52:10 --> Final output sent to browser
DEBUG - 2011-08-13 17:52:10 --> Total execution time: 0.0274
DEBUG - 2011-08-13 17:52:11 --> Config Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:52:11 --> URI Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Router Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Output Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Input Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:52:11 --> Language Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Loader Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Controller Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:52:11 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:52:12 --> Final output sent to browser
DEBUG - 2011-08-13 17:52:12 --> Total execution time: 0.4973
DEBUG - 2011-08-13 17:52:23 --> Config Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:52:23 --> URI Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Router Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Output Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Input Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:52:23 --> Language Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Loader Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Controller Class Initialized
ERROR - 2011-08-13 17:52:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:52:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:52:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:52:23 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:52:23 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:52:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:52:23 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:52:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:52:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:52:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:52:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:52:23 --> Final output sent to browser
DEBUG - 2011-08-13 17:52:23 --> Total execution time: 0.0279
DEBUG - 2011-08-13 17:52:24 --> Config Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:52:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:52:24 --> URI Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Router Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Output Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Input Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:52:24 --> Language Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Loader Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Controller Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:52:24 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:52:24 --> Final output sent to browser
DEBUG - 2011-08-13 17:52:24 --> Total execution time: 0.5219
DEBUG - 2011-08-13 17:52:45 --> Config Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:52:45 --> URI Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Router Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Output Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Input Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:52:45 --> Language Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Loader Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Controller Class Initialized
ERROR - 2011-08-13 17:52:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:52:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:52:45 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:52:45 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:52:45 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:52:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:52:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:52:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:52:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:52:45 --> Final output sent to browser
DEBUG - 2011-08-13 17:52:45 --> Total execution time: 0.0314
DEBUG - 2011-08-13 17:52:46 --> Config Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:52:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:52:46 --> URI Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Router Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Output Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Input Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:52:46 --> Language Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Loader Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Controller Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Model Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:52:46 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:52:46 --> Final output sent to browser
DEBUG - 2011-08-13 17:52:46 --> Total execution time: 0.5005
DEBUG - 2011-08-13 17:53:02 --> Config Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:53:02 --> URI Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Router Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Output Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Input Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:53:02 --> Language Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Loader Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Controller Class Initialized
ERROR - 2011-08-13 17:53:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:53:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:53:02 --> Model Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Model Class Initialized
DEBUG - 2011-08-13 17:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:53:02 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:53:02 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:53:02 --> Final output sent to browser
DEBUG - 2011-08-13 17:53:02 --> Total execution time: 0.0286
DEBUG - 2011-08-13 17:53:03 --> Config Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:53:03 --> URI Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Router Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Output Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Input Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:53:03 --> Language Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Loader Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Controller Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Model Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Model Class Initialized
DEBUG - 2011-08-13 17:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:53:03 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:53:04 --> Final output sent to browser
DEBUG - 2011-08-13 17:53:04 --> Total execution time: 0.5100
DEBUG - 2011-08-13 17:53:20 --> Config Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:53:20 --> URI Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Router Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Output Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Input Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:53:20 --> Language Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Loader Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Controller Class Initialized
ERROR - 2011-08-13 17:53:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 17:53:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 17:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:53:20 --> Model Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Model Class Initialized
DEBUG - 2011-08-13 17:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:53:20 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 17:53:20 --> Helper loaded: url_helper
DEBUG - 2011-08-13 17:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 17:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 17:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 17:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 17:53:20 --> Final output sent to browser
DEBUG - 2011-08-13 17:53:20 --> Total execution time: 0.0276
DEBUG - 2011-08-13 17:53:21 --> Config Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 17:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 17:53:21 --> URI Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Router Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Output Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Input Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 17:53:21 --> Language Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Loader Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Controller Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Model Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Model Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 17:53:21 --> Database Driver Class Initialized
DEBUG - 2011-08-13 17:53:21 --> Final output sent to browser
DEBUG - 2011-08-13 17:53:21 --> Total execution time: 0.5310
DEBUG - 2011-08-13 18:15:00 --> Config Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:15:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:15:00 --> URI Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Router Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Output Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Input Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 18:15:00 --> Language Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Loader Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Controller Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Model Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Model Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Model Class Initialized
DEBUG - 2011-08-13 18:15:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 18:15:00 --> Database Driver Class Initialized
DEBUG - 2011-08-13 18:15:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 18:15:00 --> Helper loaded: url_helper
DEBUG - 2011-08-13 18:15:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 18:15:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 18:15:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 18:15:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 18:15:00 --> Final output sent to browser
DEBUG - 2011-08-13 18:15:00 --> Total execution time: 0.0460
DEBUG - 2011-08-13 18:32:50 --> Config Class Initialized
DEBUG - 2011-08-13 18:32:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:32:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:32:50 --> URI Class Initialized
DEBUG - 2011-08-13 18:32:50 --> Router Class Initialized
ERROR - 2011-08-13 18:32:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 18:37:12 --> Config Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:37:12 --> URI Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Router Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Output Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Input Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 18:37:12 --> Language Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Loader Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Controller Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Model Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Model Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Model Class Initialized
DEBUG - 2011-08-13 18:37:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 18:37:12 --> Database Driver Class Initialized
DEBUG - 2011-08-13 18:37:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 18:37:12 --> Helper loaded: url_helper
DEBUG - 2011-08-13 18:37:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 18:37:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 18:37:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 18:37:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 18:37:12 --> Final output sent to browser
DEBUG - 2011-08-13 18:37:12 --> Total execution time: 0.0431
DEBUG - 2011-08-13 18:37:15 --> Config Class Initialized
DEBUG - 2011-08-13 18:37:15 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:37:15 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:37:15 --> URI Class Initialized
DEBUG - 2011-08-13 18:37:15 --> Router Class Initialized
ERROR - 2011-08-13 18:37:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 18:37:15 --> Config Class Initialized
DEBUG - 2011-08-13 18:37:15 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:37:15 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:37:15 --> URI Class Initialized
DEBUG - 2011-08-13 18:37:15 --> Router Class Initialized
ERROR - 2011-08-13 18:37:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 18:37:17 --> Config Class Initialized
DEBUG - 2011-08-13 18:37:17 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:37:17 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:37:17 --> URI Class Initialized
DEBUG - 2011-08-13 18:37:17 --> Router Class Initialized
ERROR - 2011-08-13 18:37:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 18:58:29 --> Config Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:58:29 --> URI Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Router Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Output Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Input Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 18:58:29 --> Language Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Loader Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Controller Class Initialized
ERROR - 2011-08-13 18:58:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 18:58:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 18:58:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 18:58:29 --> Model Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Model Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 18:58:29 --> Database Driver Class Initialized
DEBUG - 2011-08-13 18:58:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 18:58:29 --> Helper loaded: url_helper
DEBUG - 2011-08-13 18:58:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 18:58:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 18:58:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 18:58:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 18:58:29 --> Final output sent to browser
DEBUG - 2011-08-13 18:58:29 --> Total execution time: 0.0338
DEBUG - 2011-08-13 18:58:29 --> Config Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:58:29 --> URI Class Initialized
DEBUG - 2011-08-13 18:58:29 --> Router Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Output Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Input Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 18:58:30 --> Language Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Loader Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Controller Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Model Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Model Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 18:58:30 --> Database Driver Class Initialized
DEBUG - 2011-08-13 18:58:30 --> Final output sent to browser
DEBUG - 2011-08-13 18:58:30 --> Total execution time: 0.7230
DEBUG - 2011-08-13 18:58:31 --> Config Class Initialized
DEBUG - 2011-08-13 18:58:31 --> Hooks Class Initialized
DEBUG - 2011-08-13 18:58:31 --> Utf8 Class Initialized
DEBUG - 2011-08-13 18:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 18:58:31 --> URI Class Initialized
DEBUG - 2011-08-13 18:58:31 --> Router Class Initialized
ERROR - 2011-08-13 18:58:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 19:07:24 --> Config Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:07:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:07:24 --> URI Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Router Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Output Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Input Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 19:07:24 --> Language Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Loader Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Controller Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 19:07:24 --> Database Driver Class Initialized
DEBUG - 2011-08-13 19:07:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 19:07:24 --> Helper loaded: url_helper
DEBUG - 2011-08-13 19:07:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 19:07:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 19:07:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 19:07:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 19:07:24 --> Final output sent to browser
DEBUG - 2011-08-13 19:07:24 --> Total execution time: 0.1902
DEBUG - 2011-08-13 19:07:27 --> Config Class Initialized
DEBUG - 2011-08-13 19:07:27 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:07:27 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:07:27 --> URI Class Initialized
DEBUG - 2011-08-13 19:07:27 --> Router Class Initialized
ERROR - 2011-08-13 19:07:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 19:07:40 --> Config Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:07:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:07:40 --> URI Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Router Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Output Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Input Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 19:07:40 --> Language Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Loader Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Controller Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 19:07:40 --> Database Driver Class Initialized
DEBUG - 2011-08-13 19:07:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 19:07:40 --> Helper loaded: url_helper
DEBUG - 2011-08-13 19:07:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 19:07:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 19:07:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 19:07:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 19:07:40 --> Final output sent to browser
DEBUG - 2011-08-13 19:07:40 --> Total execution time: 0.2214
DEBUG - 2011-08-13 19:07:41 --> Config Class Initialized
DEBUG - 2011-08-13 19:07:41 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:07:41 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:07:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:07:41 --> URI Class Initialized
DEBUG - 2011-08-13 19:07:41 --> Router Class Initialized
ERROR - 2011-08-13 19:07:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 19:07:50 --> Config Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:07:50 --> URI Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Router Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Output Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Input Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 19:07:50 --> Language Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Loader Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Controller Class Initialized
ERROR - 2011-08-13 19:07:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 19:07:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 19:07:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 19:07:50 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 19:07:50 --> Database Driver Class Initialized
DEBUG - 2011-08-13 19:07:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 19:07:50 --> Helper loaded: url_helper
DEBUG - 2011-08-13 19:07:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 19:07:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 19:07:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 19:07:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 19:07:50 --> Final output sent to browser
DEBUG - 2011-08-13 19:07:50 --> Total execution time: 0.0572
DEBUG - 2011-08-13 19:07:51 --> Config Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:07:51 --> URI Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Router Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Output Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Input Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 19:07:51 --> Language Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Loader Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Controller Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Model Class Initialized
DEBUG - 2011-08-13 19:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 19:07:51 --> Database Driver Class Initialized
DEBUG - 2011-08-13 19:07:52 --> Final output sent to browser
DEBUG - 2011-08-13 19:07:52 --> Total execution time: 0.5360
DEBUG - 2011-08-13 19:07:53 --> Config Class Initialized
DEBUG - 2011-08-13 19:07:53 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:07:53 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:07:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:07:53 --> URI Class Initialized
DEBUG - 2011-08-13 19:07:53 --> Router Class Initialized
ERROR - 2011-08-13 19:07:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 19:08:22 --> Config Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:08:22 --> URI Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Router Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Output Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Input Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 19:08:22 --> Language Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Loader Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Controller Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Model Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Model Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Model Class Initialized
DEBUG - 2011-08-13 19:08:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 19:08:22 --> Database Driver Class Initialized
DEBUG - 2011-08-13 19:08:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 19:08:22 --> Helper loaded: url_helper
DEBUG - 2011-08-13 19:08:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 19:08:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 19:08:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 19:08:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 19:08:22 --> Final output sent to browser
DEBUG - 2011-08-13 19:08:22 --> Total execution time: 0.0456
DEBUG - 2011-08-13 19:11:21 --> Config Class Initialized
DEBUG - 2011-08-13 19:11:21 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:11:21 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:11:21 --> URI Class Initialized
DEBUG - 2011-08-13 19:11:21 --> Router Class Initialized
ERROR - 2011-08-13 19:11:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-13 19:47:08 --> Config Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:47:08 --> URI Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Router Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Output Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Input Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 19:47:08 --> Language Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Loader Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Controller Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 19:47:08 --> Database Driver Class Initialized
DEBUG - 2011-08-13 19:47:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 19:47:08 --> Helper loaded: url_helper
DEBUG - 2011-08-13 19:47:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 19:47:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 19:47:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 19:47:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 19:47:08 --> Final output sent to browser
DEBUG - 2011-08-13 19:47:08 --> Total execution time: 0.2567
DEBUG - 2011-08-13 19:47:12 --> Config Class Initialized
DEBUG - 2011-08-13 19:47:12 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:47:12 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:47:12 --> URI Class Initialized
DEBUG - 2011-08-13 19:47:12 --> Router Class Initialized
ERROR - 2011-08-13 19:47:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 19:47:25 --> Config Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:47:25 --> URI Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Router Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Output Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Input Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 19:47:25 --> Language Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Loader Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Controller Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 19:47:25 --> Database Driver Class Initialized
DEBUG - 2011-08-13 19:47:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 19:47:25 --> Helper loaded: url_helper
DEBUG - 2011-08-13 19:47:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 19:47:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 19:47:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 19:47:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 19:47:25 --> Final output sent to browser
DEBUG - 2011-08-13 19:47:25 --> Total execution time: 0.0554
DEBUG - 2011-08-13 19:47:27 --> Config Class Initialized
DEBUG - 2011-08-13 19:47:27 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:47:27 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:47:27 --> URI Class Initialized
DEBUG - 2011-08-13 19:47:27 --> Router Class Initialized
ERROR - 2011-08-13 19:47:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-13 19:47:37 --> Config Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Hooks Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Utf8 Class Initialized
DEBUG - 2011-08-13 19:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 19:47:37 --> URI Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Router Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Output Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Input Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 19:47:37 --> Language Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Loader Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Controller Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Model Class Initialized
DEBUG - 2011-08-13 19:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 19:47:37 --> Database Driver Class Initialized
DEBUG - 2011-08-13 19:47:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-13 19:47:37 --> Helper loaded: url_helper
DEBUG - 2011-08-13 19:47:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 19:47:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 19:47:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 19:47:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 19:47:37 --> Final output sent to browser
DEBUG - 2011-08-13 19:47:37 --> Total execution time: 0.0434
DEBUG - 2011-08-13 20:07:34 --> Config Class Initialized
DEBUG - 2011-08-13 20:07:34 --> Hooks Class Initialized
DEBUG - 2011-08-13 20:07:34 --> Utf8 Class Initialized
DEBUG - 2011-08-13 20:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 20:07:34 --> URI Class Initialized
DEBUG - 2011-08-13 20:07:34 --> Router Class Initialized
DEBUG - 2011-08-13 20:07:34 --> No URI present. Default controller set.
DEBUG - 2011-08-13 20:07:34 --> Output Class Initialized
DEBUG - 2011-08-13 20:07:34 --> Input Class Initialized
DEBUG - 2011-08-13 20:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 20:07:34 --> Language Class Initialized
DEBUG - 2011-08-13 20:07:34 --> Loader Class Initialized
DEBUG - 2011-08-13 20:07:34 --> Controller Class Initialized
DEBUG - 2011-08-13 20:07:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-13 20:07:34 --> Helper loaded: url_helper
DEBUG - 2011-08-13 20:07:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 20:07:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 20:07:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 20:07:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 20:07:34 --> Final output sent to browser
DEBUG - 2011-08-13 20:07:34 --> Total execution time: 0.0157
DEBUG - 2011-08-13 22:12:10 --> Config Class Initialized
DEBUG - 2011-08-13 22:12:10 --> Hooks Class Initialized
DEBUG - 2011-08-13 22:12:10 --> Utf8 Class Initialized
DEBUG - 2011-08-13 22:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 22:12:10 --> URI Class Initialized
DEBUG - 2011-08-13 22:12:10 --> Router Class Initialized
DEBUG - 2011-08-13 22:12:10 --> No URI present. Default controller set.
DEBUG - 2011-08-13 22:12:10 --> Output Class Initialized
DEBUG - 2011-08-13 22:12:10 --> Input Class Initialized
DEBUG - 2011-08-13 22:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 22:12:10 --> Language Class Initialized
DEBUG - 2011-08-13 22:12:10 --> Loader Class Initialized
DEBUG - 2011-08-13 22:12:10 --> Controller Class Initialized
DEBUG - 2011-08-13 22:12:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-13 22:12:10 --> Helper loaded: url_helper
DEBUG - 2011-08-13 22:12:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 22:12:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 22:12:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 22:12:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 22:12:10 --> Final output sent to browser
DEBUG - 2011-08-13 22:12:10 --> Total execution time: 0.0906
DEBUG - 2011-08-13 23:07:16 --> Config Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Hooks Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Utf8 Class Initialized
DEBUG - 2011-08-13 23:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 23:07:16 --> URI Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Router Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Output Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Input Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 23:07:16 --> Language Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Loader Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Controller Class Initialized
ERROR - 2011-08-13 23:07:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-13 23:07:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-13 23:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 23:07:16 --> Model Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Model Class Initialized
DEBUG - 2011-08-13 23:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 23:07:17 --> Database Driver Class Initialized
DEBUG - 2011-08-13 23:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-13 23:07:17 --> Helper loaded: url_helper
DEBUG - 2011-08-13 23:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-13 23:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-13 23:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-13 23:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-13 23:07:17 --> Final output sent to browser
DEBUG - 2011-08-13 23:07:17 --> Total execution time: 1.0074
DEBUG - 2011-08-13 23:07:19 --> Config Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Hooks Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Utf8 Class Initialized
DEBUG - 2011-08-13 23:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 23:07:19 --> URI Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Router Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Output Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Input Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-13 23:07:19 --> Language Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Loader Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Controller Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Model Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Model Class Initialized
DEBUG - 2011-08-13 23:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-13 23:07:19 --> Database Driver Class Initialized
DEBUG - 2011-08-13 23:07:20 --> Final output sent to browser
DEBUG - 2011-08-13 23:07:20 --> Total execution time: 0.8278
DEBUG - 2011-08-13 23:07:25 --> Config Class Initialized
DEBUG - 2011-08-13 23:07:25 --> Hooks Class Initialized
DEBUG - 2011-08-13 23:07:25 --> Utf8 Class Initialized
DEBUG - 2011-08-13 23:07:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-13 23:07:25 --> URI Class Initialized
DEBUG - 2011-08-13 23:07:25 --> Router Class Initialized
ERROR - 2011-08-13 23:07:25 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-23 00:09:18 --> Config Class Initialized
DEBUG - 2011-05-23 00:09:18 --> Hooks Class Initialized
DEBUG - 2011-05-23 00:09:18 --> Utf8 Class Initialized
DEBUG - 2011-05-23 00:09:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 00:09:18 --> URI Class Initialized
DEBUG - 2011-05-23 00:09:18 --> Router Class Initialized
ERROR - 2011-05-23 00:09:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-23 00:09:19 --> Config Class Initialized
DEBUG - 2011-05-23 00:09:19 --> Hooks Class Initialized
DEBUG - 2011-05-23 00:09:19 --> Utf8 Class Initialized
DEBUG - 2011-05-23 00:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 00:09:19 --> URI Class Initialized
DEBUG - 2011-05-23 00:09:19 --> Router Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Output Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Input Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 00:09:20 --> Language Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Loader Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Controller Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Model Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Model Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Model Class Initialized
DEBUG - 2011-05-23 00:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 00:09:20 --> Database Driver Class Initialized
DEBUG - 2011-05-23 00:09:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 00:09:21 --> Helper loaded: url_helper
DEBUG - 2011-05-23 00:09:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 00:09:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 00:09:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 00:09:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 00:09:21 --> Final output sent to browser
DEBUG - 2011-05-23 00:09:21 --> Total execution time: 1.3965
DEBUG - 2011-05-23 00:56:25 --> Config Class Initialized
DEBUG - 2011-05-23 00:56:25 --> Hooks Class Initialized
DEBUG - 2011-05-23 00:56:25 --> Utf8 Class Initialized
DEBUG - 2011-05-23 00:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 00:56:25 --> URI Class Initialized
DEBUG - 2011-05-23 00:56:25 --> Router Class Initialized
DEBUG - 2011-05-23 00:56:25 --> Output Class Initialized
DEBUG - 2011-05-23 00:56:26 --> Input Class Initialized
DEBUG - 2011-05-23 00:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 00:56:26 --> Language Class Initialized
DEBUG - 2011-05-23 00:56:26 --> Loader Class Initialized
DEBUG - 2011-05-23 00:56:26 --> Controller Class Initialized
DEBUG - 2011-05-23 00:56:26 --> Model Class Initialized
DEBUG - 2011-05-23 00:56:26 --> Model Class Initialized
DEBUG - 2011-05-23 00:56:26 --> Model Class Initialized
DEBUG - 2011-05-23 00:56:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 00:56:26 --> Database Driver Class Initialized
DEBUG - 2011-05-23 00:56:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 00:56:26 --> Helper loaded: url_helper
DEBUG - 2011-05-23 00:56:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 00:56:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 00:56:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 00:56:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 00:56:26 --> Final output sent to browser
DEBUG - 2011-05-23 00:56:26 --> Total execution time: 0.5532
DEBUG - 2011-05-23 06:10:08 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:08 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:08 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:08 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:08 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:08 --> No URI present. Default controller set.
DEBUG - 2011-05-23 06:10:09 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:09 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:09 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:09 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:09 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-23 06:10:09 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:10 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:10 --> Total execution time: 1.6300
DEBUG - 2011-05-23 06:10:13 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:13 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Router Class Initialized
ERROR - 2011-05-23 06:10:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 06:10:13 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:13 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Router Class Initialized
ERROR - 2011-05-23 06:10:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 06:10:13 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:13 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:13 --> Router Class Initialized
ERROR - 2011-05-23 06:10:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 06:10:23 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:23 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:23 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:10:23 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:10:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:10:25 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:25 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:25 --> Total execution time: 2.1233
DEBUG - 2011-05-23 06:10:47 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:47 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:47 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:10:47 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:10:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:10:48 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:48 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:48 --> Total execution time: 0.6493
DEBUG - 2011-05-23 06:10:49 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:49 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:49 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:10:49 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:10:49 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:49 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:49 --> Total execution time: 0.0482
DEBUG - 2011-05-23 06:10:52 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:52 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:52 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:52 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:52 --> Router Class Initialized
ERROR - 2011-05-23 06:10:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-23 06:10:53 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:53 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:53 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:10:53 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:53 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:53 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:10:53 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:10:53 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:53 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:53 --> Total execution time: 0.3056
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:10:53 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:53 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:53 --> Total execution time: 0.2513
DEBUG - 2011-05-23 06:10:57 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:57 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:57 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:10:57 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:10:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:10:58 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:58 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:58 --> Total execution time: 0.2278
DEBUG - 2011-05-23 06:10:59 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:59 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:59 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:10:59 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:10:59 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:59 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:59 --> Total execution time: 0.0566
DEBUG - 2011-05-23 06:10:59 --> Config Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:10:59 --> URI Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Router Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Output Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Input Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:10:59 --> Language Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Loader Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Controller Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Model Class Initialized
DEBUG - 2011-05-23 06:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:10:59 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:10:59 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:10:59 --> Final output sent to browser
DEBUG - 2011-05-23 06:10:59 --> Total execution time: 0.0910
DEBUG - 2011-05-23 06:11:00 --> Config Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:11:00 --> URI Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Router Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Output Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Input Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:11:00 --> Language Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Loader Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Controller Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:11:00 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:11:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:11:00 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:11:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:11:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:11:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:11:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:11:00 --> Final output sent to browser
DEBUG - 2011-05-23 06:11:00 --> Total execution time: 0.0885
DEBUG - 2011-05-23 06:11:15 --> Config Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:11:15 --> URI Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Router Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Output Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Input Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:11:15 --> Language Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Loader Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Controller Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:11:15 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:11:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:11:15 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:11:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:11:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:11:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:11:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:11:15 --> Final output sent to browser
DEBUG - 2011-05-23 06:11:15 --> Total execution time: 0.2462
DEBUG - 2011-05-23 06:11:17 --> Config Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:11:17 --> URI Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Router Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Output Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Input Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:11:17 --> Language Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Loader Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Controller Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:11:17 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:11:17 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:11:17 --> Final output sent to browser
DEBUG - 2011-05-23 06:11:17 --> Total execution time: 0.0489
DEBUG - 2011-05-23 06:11:17 --> Config Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:11:17 --> URI Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Router Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Output Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Input Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:11:17 --> Language Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Loader Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Controller Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:11:17 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:11:17 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:11:17 --> Final output sent to browser
DEBUG - 2011-05-23 06:11:17 --> Total execution time: 0.1174
DEBUG - 2011-05-23 06:11:17 --> Config Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:11:17 --> URI Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Router Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Output Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Input Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:11:17 --> Language Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Loader Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Controller Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:11:17 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:11:17 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:11:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:11:17 --> Final output sent to browser
DEBUG - 2011-05-23 06:11:17 --> Total execution time: 0.0971
DEBUG - 2011-05-23 06:11:25 --> Config Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:11:25 --> URI Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Router Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Output Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Input Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:11:25 --> Language Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Loader Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Controller Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:11:25 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:11:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:11:25 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:11:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:11:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:11:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:11:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:11:25 --> Final output sent to browser
DEBUG - 2011-05-23 06:11:25 --> Total execution time: 0.3530
DEBUG - 2011-05-23 06:11:28 --> Config Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Hooks Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Utf8 Class Initialized
DEBUG - 2011-05-23 06:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 06:11:28 --> URI Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Router Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Output Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Input Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 06:11:28 --> Language Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Loader Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Controller Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Model Class Initialized
DEBUG - 2011-05-23 06:11:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 06:11:28 --> Database Driver Class Initialized
DEBUG - 2011-05-23 06:11:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 06:11:28 --> Helper loaded: url_helper
DEBUG - 2011-05-23 06:11:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 06:11:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 06:11:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 06:11:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 06:11:28 --> Final output sent to browser
DEBUG - 2011-05-23 06:11:28 --> Total execution time: 0.0544
DEBUG - 2011-05-23 07:37:12 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:12 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:12 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:12 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:12 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:12 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:12 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:12 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:13 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:13 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:13 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:13 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:13 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:14 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:15 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:15 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:15 --> Total execution time: 3.1698
DEBUG - 2011-05-23 07:37:15 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:15 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:15 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:15 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:15 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:15 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:15 --> Total execution time: 0.0759
DEBUG - 2011-05-23 07:37:18 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:18 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:18 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:18 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:18 --> Router Class Initialized
ERROR - 2011-05-23 07:37:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 07:37:20 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:20 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:20 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:20 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:20 --> Router Class Initialized
ERROR - 2011-05-23 07:37:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 07:37:34 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:34 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:34 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:34 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:34 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:34 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:34 --> Total execution time: 0.3049
DEBUG - 2011-05-23 07:37:35 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:35 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:35 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:35 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:35 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:35 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:35 --> Total execution time: 0.0470
DEBUG - 2011-05-23 07:37:36 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:36 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:36 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:36 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:36 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:36 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:36 --> Total execution time: 0.0493
DEBUG - 2011-05-23 07:37:51 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:51 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:51 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:51 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:52 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:52 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:52 --> Total execution time: 0.2277
DEBUG - 2011-05-23 07:37:53 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:53 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:53 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:53 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:53 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:53 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:53 --> Total execution time: 0.0511
DEBUG - 2011-05-23 07:37:53 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:53 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:53 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:53 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:53 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:53 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:53 --> Total execution time: 0.0560
DEBUG - 2011-05-23 07:37:53 --> Config Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:37:53 --> URI Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Router Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Output Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Input Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:37:53 --> Language Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Loader Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Controller Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Model Class Initialized
DEBUG - 2011-05-23 07:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:37:53 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:37:53 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:37:53 --> Final output sent to browser
DEBUG - 2011-05-23 07:37:53 --> Total execution time: 0.0447
DEBUG - 2011-05-23 07:38:01 --> Config Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:38:01 --> URI Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Router Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Output Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Input Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:38:01 --> Language Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Loader Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Controller Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:38:01 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:38:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:38:01 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:38:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:38:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:38:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:38:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:38:01 --> Final output sent to browser
DEBUG - 2011-05-23 07:38:01 --> Total execution time: 0.3306
DEBUG - 2011-05-23 07:38:02 --> Config Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:38:02 --> URI Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Router Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Output Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Input Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:38:02 --> Language Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Loader Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Controller Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:38:02 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:38:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:38:02 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:38:02 --> Final output sent to browser
DEBUG - 2011-05-23 07:38:02 --> Total execution time: 0.0840
DEBUG - 2011-05-23 07:38:03 --> Config Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:38:03 --> URI Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Router Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Output Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Input Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:38:03 --> Language Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Loader Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Controller Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:38:03 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:38:03 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:38:03 --> Final output sent to browser
DEBUG - 2011-05-23 07:38:03 --> Total execution time: 0.0559
DEBUG - 2011-05-23 07:38:03 --> Config Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Hooks Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Utf8 Class Initialized
DEBUG - 2011-05-23 07:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 07:38:03 --> URI Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Router Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Output Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Input Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 07:38:03 --> Language Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Loader Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Controller Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Model Class Initialized
DEBUG - 2011-05-23 07:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 07:38:03 --> Database Driver Class Initialized
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 07:38:03 --> Helper loaded: url_helper
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 07:38:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 07:38:03 --> Final output sent to browser
DEBUG - 2011-05-23 07:38:03 --> Total execution time: 0.0557
DEBUG - 2011-05-23 08:31:56 --> Config Class Initialized
DEBUG - 2011-05-23 08:31:56 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:31:56 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:31:57 --> URI Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Router Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Output Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Input Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:31:57 --> Language Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Loader Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Controller Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Model Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Model Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Model Class Initialized
DEBUG - 2011-05-23 08:31:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:31:58 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:31:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:31:58 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:31:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:31:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:31:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:31:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:31:58 --> Final output sent to browser
DEBUG - 2011-05-23 08:31:58 --> Total execution time: 2.8873
DEBUG - 2011-05-23 08:32:03 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:03 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:03 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:03 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:03 --> Router Class Initialized
ERROR - 2011-05-23 08:32:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 08:32:03 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:03 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:03 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:03 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:03 --> Router Class Initialized
ERROR - 2011-05-23 08:32:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 08:32:09 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:09 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Router Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Output Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Input Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:32:09 --> Language Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Loader Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Controller Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:32:09 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:32:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:32:09 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:32:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:32:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:32:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:32:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:32:09 --> Final output sent to browser
DEBUG - 2011-05-23 08:32:09 --> Total execution time: 0.7094
DEBUG - 2011-05-23 08:32:11 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:11 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Router Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Output Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Input Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:32:11 --> Language Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Loader Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Controller Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:32:11 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:32:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:32:11 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:32:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:32:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:32:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:32:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:32:11 --> Final output sent to browser
DEBUG - 2011-05-23 08:32:11 --> Total execution time: 0.0602
DEBUG - 2011-05-23 08:32:20 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:20 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Router Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Output Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Input Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:32:20 --> Language Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Loader Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Controller Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:32:20 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:32:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:32:21 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:32:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:32:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:32:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:32:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:32:21 --> Final output sent to browser
DEBUG - 2011-05-23 08:32:21 --> Total execution time: 0.7699
DEBUG - 2011-05-23 08:32:26 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:26 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Router Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Output Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Input Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:32:26 --> Language Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Loader Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Controller Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:32:26 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:32:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:32:26 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:32:26 --> Final output sent to browser
DEBUG - 2011-05-23 08:32:26 --> Total execution time: 0.1757
DEBUG - 2011-05-23 08:32:35 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:35 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Router Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Output Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Input Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:32:35 --> Language Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Loader Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Controller Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:32:35 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:32:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:32:35 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:32:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:32:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:32:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:32:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:32:35 --> Final output sent to browser
DEBUG - 2011-05-23 08:32:35 --> Total execution time: 0.3086
DEBUG - 2011-05-23 08:32:38 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:38 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Router Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Output Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Input Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:32:38 --> Language Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Loader Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Controller Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:32:38 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:32:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:32:38 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:32:38 --> Final output sent to browser
DEBUG - 2011-05-23 08:32:38 --> Total execution time: 0.0601
DEBUG - 2011-05-23 08:32:50 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:50 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Router Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Output Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Input Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:32:50 --> Language Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Loader Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Controller Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:32:50 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:32:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:32:50 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:32:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:32:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:32:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:32:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:32:50 --> Final output sent to browser
DEBUG - 2011-05-23 08:32:50 --> Total execution time: 0.2074
DEBUG - 2011-05-23 08:32:52 --> Config Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:32:52 --> URI Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Router Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Output Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Input Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:32:52 --> Language Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Loader Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Controller Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Model Class Initialized
DEBUG - 2011-05-23 08:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:32:52 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:32:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:32:52 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:32:52 --> Final output sent to browser
DEBUG - 2011-05-23 08:32:52 --> Total execution time: 0.0509
DEBUG - 2011-05-23 08:33:06 --> Config Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:33:06 --> URI Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Router Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Output Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Input Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:33:06 --> Language Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Loader Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Controller Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:33:06 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:33:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:33:07 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:33:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:33:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:33:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:33:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:33:07 --> Final output sent to browser
DEBUG - 2011-05-23 08:33:07 --> Total execution time: 1.1261
DEBUG - 2011-05-23 08:33:08 --> Config Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:33:08 --> URI Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Router Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Output Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Input Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:33:08 --> Language Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Loader Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Controller Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:33:08 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:33:08 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:33:08 --> Final output sent to browser
DEBUG - 2011-05-23 08:33:08 --> Total execution time: 0.0463
DEBUG - 2011-05-23 08:33:08 --> Config Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Hooks Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Utf8 Class Initialized
DEBUG - 2011-05-23 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 08:33:08 --> URI Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Router Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Output Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Input Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 08:33:08 --> Language Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Loader Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Controller Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Model Class Initialized
DEBUG - 2011-05-23 08:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 08:33:08 --> Database Driver Class Initialized
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 08:33:08 --> Helper loaded: url_helper
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 08:33:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 08:33:08 --> Final output sent to browser
DEBUG - 2011-05-23 08:33:08 --> Total execution time: 0.0456
DEBUG - 2011-05-23 10:46:48 --> Config Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Hooks Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Utf8 Class Initialized
DEBUG - 2011-05-23 10:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 10:46:48 --> URI Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Router Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Output Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Input Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 10:46:48 --> Language Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Loader Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Controller Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Model Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Model Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Model Class Initialized
DEBUG - 2011-05-23 10:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 10:46:48 --> Database Driver Class Initialized
DEBUG - 2011-05-23 10:46:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 10:46:49 --> Helper loaded: url_helper
DEBUG - 2011-05-23 10:46:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 10:46:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 10:46:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 10:46:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 10:46:49 --> Final output sent to browser
DEBUG - 2011-05-23 10:46:49 --> Total execution time: 1.2474
DEBUG - 2011-05-23 10:46:50 --> Config Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Hooks Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Utf8 Class Initialized
DEBUG - 2011-05-23 10:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 10:46:50 --> URI Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Router Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Output Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Input Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 10:46:50 --> Language Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Loader Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Controller Class Initialized
ERROR - 2011-05-23 10:46:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-23 10:46:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-23 10:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 10:46:50 --> Model Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Model Class Initialized
DEBUG - 2011-05-23 10:46:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 10:46:50 --> Database Driver Class Initialized
DEBUG - 2011-05-23 10:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 10:46:50 --> Helper loaded: url_helper
DEBUG - 2011-05-23 10:46:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 10:46:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 10:46:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 10:46:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 10:46:50 --> Final output sent to browser
DEBUG - 2011-05-23 10:46:50 --> Total execution time: 0.1070
DEBUG - 2011-05-23 13:17:40 --> Config Class Initialized
DEBUG - 2011-05-23 13:17:40 --> Hooks Class Initialized
DEBUG - 2011-05-23 13:17:40 --> Utf8 Class Initialized
DEBUG - 2011-05-23 13:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 13:17:40 --> URI Class Initialized
DEBUG - 2011-05-23 13:17:40 --> Router Class Initialized
ERROR - 2011-05-23 13:17:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-23 13:17:40 --> Config Class Initialized
DEBUG - 2011-05-23 13:17:40 --> Hooks Class Initialized
DEBUG - 2011-05-23 13:17:40 --> Utf8 Class Initialized
DEBUG - 2011-05-23 13:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 13:17:40 --> URI Class Initialized
DEBUG - 2011-05-23 13:17:40 --> Router Class Initialized
DEBUG - 2011-05-23 13:17:40 --> Output Class Initialized
DEBUG - 2011-05-23 13:17:41 --> Input Class Initialized
DEBUG - 2011-05-23 13:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 13:17:41 --> Language Class Initialized
DEBUG - 2011-05-23 13:17:41 --> Loader Class Initialized
DEBUG - 2011-05-23 13:17:41 --> Controller Class Initialized
DEBUG - 2011-05-23 13:17:41 --> Model Class Initialized
DEBUG - 2011-05-23 13:17:41 --> Model Class Initialized
DEBUG - 2011-05-23 13:17:41 --> Model Class Initialized
DEBUG - 2011-05-23 13:17:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 13:17:41 --> Database Driver Class Initialized
DEBUG - 2011-05-23 13:17:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 13:17:42 --> Helper loaded: url_helper
DEBUG - 2011-05-23 13:17:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 13:17:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 13:17:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 13:17:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 13:17:42 --> Final output sent to browser
DEBUG - 2011-05-23 13:17:42 --> Total execution time: 1.2438
DEBUG - 2011-05-23 13:18:12 --> Config Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Hooks Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Utf8 Class Initialized
DEBUG - 2011-05-23 13:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 13:18:12 --> URI Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Router Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Output Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Input Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 13:18:12 --> Language Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Loader Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Controller Class Initialized
ERROR - 2011-05-23 13:18:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-23 13:18:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-23 13:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 13:18:12 --> Model Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Model Class Initialized
DEBUG - 2011-05-23 13:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 13:18:12 --> Database Driver Class Initialized
DEBUG - 2011-05-23 13:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 13:18:12 --> Helper loaded: url_helper
DEBUG - 2011-05-23 13:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 13:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 13:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 13:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 13:18:12 --> Final output sent to browser
DEBUG - 2011-05-23 13:18:12 --> Total execution time: 0.0960
DEBUG - 2011-05-23 14:26:41 --> Config Class Initialized
DEBUG - 2011-05-23 14:26:41 --> Hooks Class Initialized
DEBUG - 2011-05-23 14:26:41 --> Utf8 Class Initialized
DEBUG - 2011-05-23 14:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 14:26:41 --> URI Class Initialized
DEBUG - 2011-05-23 14:26:41 --> Router Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Output Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Input Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 14:26:42 --> Language Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Loader Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Controller Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Model Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Model Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Model Class Initialized
DEBUG - 2011-05-23 14:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 14:26:42 --> Database Driver Class Initialized
DEBUG - 2011-05-23 14:26:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 14:26:43 --> Helper loaded: url_helper
DEBUG - 2011-05-23 14:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 14:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 14:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 14:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 14:26:43 --> Final output sent to browser
DEBUG - 2011-05-23 14:26:43 --> Total execution time: 1.2897
DEBUG - 2011-05-23 14:26:52 --> Config Class Initialized
DEBUG - 2011-05-23 14:26:52 --> Hooks Class Initialized
DEBUG - 2011-05-23 14:26:52 --> Utf8 Class Initialized
DEBUG - 2011-05-23 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 14:26:52 --> URI Class Initialized
DEBUG - 2011-05-23 14:26:52 --> Router Class Initialized
ERROR - 2011-05-23 14:26:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 14:27:03 --> Config Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Hooks Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Utf8 Class Initialized
DEBUG - 2011-05-23 14:27:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 14:27:03 --> URI Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Router Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Output Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Input Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 14:27:03 --> Language Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Loader Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Controller Class Initialized
ERROR - 2011-05-23 14:27:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-23 14:27:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-23 14:27:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 14:27:03 --> Model Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Model Class Initialized
DEBUG - 2011-05-23 14:27:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 14:27:03 --> Database Driver Class Initialized
DEBUG - 2011-05-23 14:27:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 14:27:03 --> Helper loaded: url_helper
DEBUG - 2011-05-23 14:27:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 14:27:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 14:27:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 14:27:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 14:27:03 --> Final output sent to browser
DEBUG - 2011-05-23 14:27:03 --> Total execution time: 0.1549
DEBUG - 2011-05-23 14:27:05 --> Config Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Hooks Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Utf8 Class Initialized
DEBUG - 2011-05-23 14:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 14:27:05 --> URI Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Router Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Output Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Input Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 14:27:05 --> Language Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Loader Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Controller Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Model Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Model Class Initialized
DEBUG - 2011-05-23 14:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 14:27:05 --> Database Driver Class Initialized
DEBUG - 2011-05-23 14:27:06 --> Final output sent to browser
DEBUG - 2011-05-23 14:27:06 --> Total execution time: 0.9044
DEBUG - 2011-05-23 14:27:09 --> Config Class Initialized
DEBUG - 2011-05-23 14:27:09 --> Hooks Class Initialized
DEBUG - 2011-05-23 14:27:09 --> Utf8 Class Initialized
DEBUG - 2011-05-23 14:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 14:27:09 --> URI Class Initialized
DEBUG - 2011-05-23 14:27:09 --> Router Class Initialized
ERROR - 2011-05-23 14:27:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 14:28:06 --> Config Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Hooks Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Utf8 Class Initialized
DEBUG - 2011-05-23 14:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 14:28:06 --> URI Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Router Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Output Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Input Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 14:28:06 --> Language Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Loader Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Controller Class Initialized
ERROR - 2011-05-23 14:28:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-23 14:28:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-23 14:28:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 14:28:06 --> Model Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Model Class Initialized
DEBUG - 2011-05-23 14:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 14:28:06 --> Database Driver Class Initialized
DEBUG - 2011-05-23 14:28:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 14:28:06 --> Helper loaded: url_helper
DEBUG - 2011-05-23 14:28:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 14:28:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 14:28:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 14:28:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 14:28:06 --> Final output sent to browser
DEBUG - 2011-05-23 14:28:06 --> Total execution time: 0.0409
DEBUG - 2011-05-23 14:28:10 --> Config Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Hooks Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Utf8 Class Initialized
DEBUG - 2011-05-23 14:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 14:28:10 --> URI Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Router Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Output Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Input Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 14:28:10 --> Language Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Loader Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Controller Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Model Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Model Class Initialized
DEBUG - 2011-05-23 14:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 14:28:10 --> Database Driver Class Initialized
DEBUG - 2011-05-23 14:28:11 --> Final output sent to browser
DEBUG - 2011-05-23 14:28:11 --> Total execution time: 1.0344
DEBUG - 2011-05-23 15:12:54 --> Config Class Initialized
DEBUG - 2011-05-23 15:12:54 --> Hooks Class Initialized
DEBUG - 2011-05-23 15:12:54 --> Utf8 Class Initialized
DEBUG - 2011-05-23 15:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 15:12:54 --> URI Class Initialized
DEBUG - 2011-05-23 15:12:54 --> Router Class Initialized
DEBUG - 2011-05-23 15:12:54 --> No URI present. Default controller set.
DEBUG - 2011-05-23 15:12:54 --> Output Class Initialized
DEBUG - 2011-05-23 15:12:54 --> Input Class Initialized
DEBUG - 2011-05-23 15:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 15:12:54 --> Language Class Initialized
DEBUG - 2011-05-23 15:12:54 --> Loader Class Initialized
DEBUG - 2011-05-23 15:12:54 --> Controller Class Initialized
DEBUG - 2011-05-23 15:12:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-23 15:12:54 --> Helper loaded: url_helper
DEBUG - 2011-05-23 15:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 15:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 15:12:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 15:12:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 15:12:55 --> Final output sent to browser
DEBUG - 2011-05-23 15:12:55 --> Total execution time: 0.8772
DEBUG - 2011-05-23 15:43:45 --> Config Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Hooks Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Utf8 Class Initialized
DEBUG - 2011-05-23 15:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 15:43:45 --> URI Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Router Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Output Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Input Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 15:43:45 --> Language Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Loader Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Controller Class Initialized
DEBUG - 2011-05-23 15:43:45 --> Model Class Initialized
DEBUG - 2011-05-23 15:43:46 --> Model Class Initialized
DEBUG - 2011-05-23 15:43:46 --> Model Class Initialized
DEBUG - 2011-05-23 15:43:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 15:43:46 --> Database Driver Class Initialized
DEBUG - 2011-05-23 15:43:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 15:43:46 --> Helper loaded: url_helper
DEBUG - 2011-05-23 15:43:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 15:43:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 15:43:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 15:43:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 15:43:46 --> Final output sent to browser
DEBUG - 2011-05-23 15:43:46 --> Total execution time: 0.9384
DEBUG - 2011-05-23 18:00:31 --> Config Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Hooks Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Utf8 Class Initialized
DEBUG - 2011-05-23 18:00:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 18:00:31 --> URI Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Router Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Output Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Input Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 18:00:31 --> Language Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Loader Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Controller Class Initialized
ERROR - 2011-05-23 18:00:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-23 18:00:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-23 18:00:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 18:00:31 --> Model Class Initialized
DEBUG - 2011-05-23 18:00:31 --> Model Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 18:00:32 --> Database Driver Class Initialized
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 18:00:32 --> Helper loaded: url_helper
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 18:00:32 --> Final output sent to browser
DEBUG - 2011-05-23 18:00:32 --> Total execution time: 0.9147
DEBUG - 2011-05-23 18:00:32 --> Config Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Hooks Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Utf8 Class Initialized
DEBUG - 2011-05-23 18:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 18:00:32 --> URI Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Router Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Output Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Input Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 18:00:32 --> Language Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Loader Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Controller Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Model Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Model Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Model Class Initialized
DEBUG - 2011-05-23 18:00:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 18:00:32 --> Database Driver Class Initialized
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 18:00:32 --> Helper loaded: url_helper
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 18:00:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 18:00:32 --> Final output sent to browser
DEBUG - 2011-05-23 18:00:32 --> Total execution time: 0.3300
DEBUG - 2011-05-23 19:33:19 --> Config Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Hooks Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Utf8 Class Initialized
DEBUG - 2011-05-23 19:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 19:33:19 --> URI Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Router Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Output Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Input Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 19:33:19 --> Language Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Loader Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Controller Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Model Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Model Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Model Class Initialized
DEBUG - 2011-05-23 19:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 19:33:19 --> Database Driver Class Initialized
DEBUG - 2011-05-23 19:33:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 19:33:19 --> Helper loaded: url_helper
DEBUG - 2011-05-23 19:33:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 19:33:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 19:33:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 19:33:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 19:33:19 --> Final output sent to browser
DEBUG - 2011-05-23 19:33:19 --> Total execution time: 0.6138
DEBUG - 2011-05-23 19:33:20 --> Config Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Hooks Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Utf8 Class Initialized
DEBUG - 2011-05-23 19:33:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 19:33:20 --> URI Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Router Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Output Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Input Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 19:33:20 --> Language Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Loader Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Controller Class Initialized
ERROR - 2011-05-23 19:33:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-23 19:33:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-23 19:33:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 19:33:20 --> Model Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Model Class Initialized
DEBUG - 2011-05-23 19:33:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 19:33:20 --> Database Driver Class Initialized
DEBUG - 2011-05-23 19:33:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 19:33:21 --> Helper loaded: url_helper
DEBUG - 2011-05-23 19:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 19:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 19:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 19:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 19:33:21 --> Final output sent to browser
DEBUG - 2011-05-23 19:33:21 --> Total execution time: 0.1502
DEBUG - 2011-05-23 21:26:02 --> Config Class Initialized
DEBUG - 2011-05-23 21:26:02 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:26:02 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:26:02 --> URI Class Initialized
DEBUG - 2011-05-23 21:26:02 --> Router Class Initialized
DEBUG - 2011-05-23 21:26:02 --> No URI present. Default controller set.
DEBUG - 2011-05-23 21:26:02 --> Output Class Initialized
DEBUG - 2011-05-23 21:26:02 --> Input Class Initialized
DEBUG - 2011-05-23 21:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 21:26:02 --> Language Class Initialized
DEBUG - 2011-05-23 21:26:02 --> Loader Class Initialized
DEBUG - 2011-05-23 21:26:02 --> Controller Class Initialized
DEBUG - 2011-05-23 21:26:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-23 21:26:03 --> Helper loaded: url_helper
DEBUG - 2011-05-23 21:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 21:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 21:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 21:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 21:26:03 --> Final output sent to browser
DEBUG - 2011-05-23 21:26:03 --> Total execution time: 0.2485
DEBUG - 2011-05-23 21:26:04 --> Config Class Initialized
DEBUG - 2011-05-23 21:26:04 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:26:04 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:26:04 --> URI Class Initialized
DEBUG - 2011-05-23 21:26:04 --> Router Class Initialized
ERROR - 2011-05-23 21:26:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 21:26:04 --> Config Class Initialized
DEBUG - 2011-05-23 21:26:04 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:26:04 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:26:04 --> URI Class Initialized
DEBUG - 2011-05-23 21:26:04 --> Router Class Initialized
ERROR - 2011-05-23 21:26:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-23 21:26:07 --> Config Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:26:07 --> URI Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Router Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Output Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Input Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 21:26:07 --> Language Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Loader Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Controller Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 21:26:07 --> Database Driver Class Initialized
DEBUG - 2011-05-23 21:26:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 21:26:07 --> Helper loaded: url_helper
DEBUG - 2011-05-23 21:26:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 21:26:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 21:26:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 21:26:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 21:26:07 --> Final output sent to browser
DEBUG - 2011-05-23 21:26:07 --> Total execution time: 0.3972
DEBUG - 2011-05-23 21:26:24 --> Config Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:26:24 --> URI Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Router Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Output Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Input Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 21:26:24 --> Language Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Loader Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Controller Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 21:26:24 --> Database Driver Class Initialized
DEBUG - 2011-05-23 21:26:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 21:26:25 --> Helper loaded: url_helper
DEBUG - 2011-05-23 21:26:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 21:26:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 21:26:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 21:26:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 21:26:25 --> Final output sent to browser
DEBUG - 2011-05-23 21:26:25 --> Total execution time: 0.5553
DEBUG - 2011-05-23 21:26:48 --> Config Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:26:48 --> URI Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Router Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Output Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Input Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 21:26:48 --> Language Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Loader Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Controller Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Model Class Initialized
DEBUG - 2011-05-23 21:26:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 21:26:48 --> Database Driver Class Initialized
DEBUG - 2011-05-23 21:26:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 21:26:48 --> Helper loaded: url_helper
DEBUG - 2011-05-23 21:26:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 21:26:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 21:26:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 21:26:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 21:26:48 --> Final output sent to browser
DEBUG - 2011-05-23 21:26:48 --> Total execution time: 0.3780
DEBUG - 2011-05-23 21:27:08 --> Config Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:27:08 --> URI Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Router Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Output Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Input Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 21:27:08 --> Language Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Loader Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Controller Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 21:27:08 --> Database Driver Class Initialized
DEBUG - 2011-05-23 21:27:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 21:27:08 --> Helper loaded: url_helper
DEBUG - 2011-05-23 21:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 21:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 21:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 21:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 21:27:08 --> Final output sent to browser
DEBUG - 2011-05-23 21:27:08 --> Total execution time: 0.3833
DEBUG - 2011-05-23 21:27:24 --> Config Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:27:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:27:24 --> URI Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Router Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Output Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Input Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 21:27:24 --> Language Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Loader Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Controller Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 21:27:24 --> Database Driver Class Initialized
DEBUG - 2011-05-23 21:27:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 21:27:25 --> Helper loaded: url_helper
DEBUG - 2011-05-23 21:27:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 21:27:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 21:27:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 21:27:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 21:27:25 --> Final output sent to browser
DEBUG - 2011-05-23 21:27:25 --> Total execution time: 0.0741
DEBUG - 2011-05-23 21:27:31 --> Config Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:27:31 --> URI Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Router Class Initialized
ERROR - 2011-05-23 21:27:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-23 21:27:31 --> Config Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:27:31 --> URI Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Router Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Output Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Input Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 21:27:31 --> Language Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Loader Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Controller Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 21:27:31 --> Database Driver Class Initialized
DEBUG - 2011-05-23 21:27:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 21:27:31 --> Helper loaded: url_helper
DEBUG - 2011-05-23 21:27:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 21:27:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 21:27:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 21:27:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 21:27:31 --> Final output sent to browser
DEBUG - 2011-05-23 21:27:31 --> Total execution time: 0.0417
DEBUG - 2011-05-23 21:27:39 --> Config Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Hooks Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Utf8 Class Initialized
DEBUG - 2011-05-23 21:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 21:27:39 --> URI Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Router Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Output Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Input Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 21:27:39 --> Language Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Loader Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Controller Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Model Class Initialized
DEBUG - 2011-05-23 21:27:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 21:27:39 --> Database Driver Class Initialized
DEBUG - 2011-05-23 21:27:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 21:27:39 --> Helper loaded: url_helper
DEBUG - 2011-05-23 21:27:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 21:27:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 21:27:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 21:27:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 21:27:39 --> Final output sent to browser
DEBUG - 2011-05-23 21:27:39 --> Total execution time: 0.0733
DEBUG - 2011-05-23 22:14:49 --> Config Class Initialized
DEBUG - 2011-05-23 22:14:49 --> Hooks Class Initialized
DEBUG - 2011-05-23 22:14:49 --> Utf8 Class Initialized
DEBUG - 2011-05-23 22:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 22:14:49 --> URI Class Initialized
DEBUG - 2011-05-23 22:14:49 --> Router Class Initialized
DEBUG - 2011-05-23 22:14:49 --> No URI present. Default controller set.
DEBUG - 2011-05-23 22:14:49 --> Output Class Initialized
DEBUG - 2011-05-23 22:14:49 --> Input Class Initialized
DEBUG - 2011-05-23 22:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 22:14:49 --> Language Class Initialized
DEBUG - 2011-05-23 22:14:49 --> Loader Class Initialized
DEBUG - 2011-05-23 22:14:49 --> Controller Class Initialized
DEBUG - 2011-05-23 22:14:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-23 22:14:49 --> Helper loaded: url_helper
DEBUG - 2011-05-23 22:14:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 22:14:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 22:14:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 22:14:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 22:14:49 --> Final output sent to browser
DEBUG - 2011-05-23 22:14:49 --> Total execution time: 0.2020
DEBUG - 2011-05-23 22:27:12 --> Config Class Initialized
DEBUG - 2011-05-23 22:27:12 --> Hooks Class Initialized
DEBUG - 2011-05-23 22:27:12 --> Utf8 Class Initialized
DEBUG - 2011-05-23 22:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 22:27:12 --> URI Class Initialized
DEBUG - 2011-05-23 22:27:12 --> Router Class Initialized
DEBUG - 2011-05-23 22:27:12 --> No URI present. Default controller set.
DEBUG - 2011-05-23 22:27:12 --> Output Class Initialized
DEBUG - 2011-05-23 22:27:12 --> Input Class Initialized
DEBUG - 2011-05-23 22:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 22:27:12 --> Language Class Initialized
DEBUG - 2011-05-23 22:27:12 --> Loader Class Initialized
DEBUG - 2011-05-23 22:27:12 --> Controller Class Initialized
DEBUG - 2011-05-23 22:27:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-23 22:27:12 --> Helper loaded: url_helper
DEBUG - 2011-05-23 22:27:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 22:27:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 22:27:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 22:27:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 22:27:12 --> Final output sent to browser
DEBUG - 2011-05-23 22:27:12 --> Total execution time: 0.1421
DEBUG - 2011-05-23 23:56:30 --> Config Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Hooks Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Utf8 Class Initialized
DEBUG - 2011-05-23 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 23:56:30 --> URI Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Router Class Initialized
ERROR - 2011-05-23 23:56:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-23 23:56:30 --> Config Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Hooks Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Utf8 Class Initialized
DEBUG - 2011-05-23 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 23:56:30 --> URI Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Router Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Output Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Input Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 23:56:30 --> Language Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Loader Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Controller Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Model Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Model Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Model Class Initialized
DEBUG - 2011-05-23 23:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 23:56:30 --> Database Driver Class Initialized
DEBUG - 2011-05-23 23:56:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-23 23:56:31 --> Helper loaded: url_helper
DEBUG - 2011-05-23 23:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 23:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 23:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 23:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 23:56:31 --> Final output sent to browser
DEBUG - 2011-05-23 23:56:31 --> Total execution time: 0.5340
DEBUG - 2011-05-23 23:57:01 --> Config Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Hooks Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Utf8 Class Initialized
DEBUG - 2011-05-23 23:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-23 23:57:01 --> URI Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Router Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Output Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Input Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-23 23:57:01 --> Language Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Loader Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Controller Class Initialized
ERROR - 2011-05-23 23:57:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-23 23:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-23 23:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 23:57:01 --> Model Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Model Class Initialized
DEBUG - 2011-05-23 23:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-23 23:57:01 --> Database Driver Class Initialized
DEBUG - 2011-05-23 23:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-23 23:57:01 --> Helper loaded: url_helper
DEBUG - 2011-05-23 23:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-23 23:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-23 23:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-23 23:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-23 23:57:01 --> Final output sent to browser
DEBUG - 2011-05-23 23:57:01 --> Total execution time: 0.1147

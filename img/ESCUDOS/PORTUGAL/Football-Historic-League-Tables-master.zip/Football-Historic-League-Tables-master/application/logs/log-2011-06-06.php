<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-06 00:15:16 --> Config Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Hooks Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Utf8 Class Initialized
DEBUG - 2011-06-06 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 00:15:16 --> URI Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Router Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Output Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Input Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 00:15:16 --> Language Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Loader Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Controller Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Model Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Model Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Model Class Initialized
DEBUG - 2011-06-06 00:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 00:15:16 --> Database Driver Class Initialized
DEBUG - 2011-06-06 00:15:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 00:15:16 --> Helper loaded: url_helper
DEBUG - 2011-06-06 00:15:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 00:15:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 00:15:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 00:15:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 00:15:16 --> Final output sent to browser
DEBUG - 2011-06-06 00:15:16 --> Total execution time: 0.5369
DEBUG - 2011-06-06 00:15:19 --> Config Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Hooks Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Utf8 Class Initialized
DEBUG - 2011-06-06 00:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 00:15:19 --> URI Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Router Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Output Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Input Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 00:15:19 --> Language Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Loader Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Controller Class Initialized
ERROR - 2011-06-06 00:15:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 00:15:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 00:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 00:15:19 --> Model Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Model Class Initialized
DEBUG - 2011-06-06 00:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 00:15:19 --> Database Driver Class Initialized
DEBUG - 2011-06-06 00:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 00:15:19 --> Helper loaded: url_helper
DEBUG - 2011-06-06 00:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 00:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 00:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 00:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 00:15:19 --> Final output sent to browser
DEBUG - 2011-06-06 00:15:19 --> Total execution time: 0.0370
DEBUG - 2011-06-06 01:11:34 --> Config Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Hooks Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Utf8 Class Initialized
DEBUG - 2011-06-06 01:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 01:11:34 --> URI Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Router Class Initialized
ERROR - 2011-06-06 01:11:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-06 01:11:34 --> Config Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Hooks Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Utf8 Class Initialized
DEBUG - 2011-06-06 01:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 01:11:34 --> URI Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Router Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Output Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Input Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 01:11:34 --> Language Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Loader Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Controller Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Model Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Model Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Model Class Initialized
DEBUG - 2011-06-06 01:11:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 01:11:34 --> Database Driver Class Initialized
DEBUG - 2011-06-06 01:11:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 01:11:35 --> Helper loaded: url_helper
DEBUG - 2011-06-06 01:11:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 01:11:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 01:11:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 01:11:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 01:11:35 --> Final output sent to browser
DEBUG - 2011-06-06 01:11:35 --> Total execution time: 0.3971
DEBUG - 2011-06-06 01:12:05 --> Config Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Hooks Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Utf8 Class Initialized
DEBUG - 2011-06-06 01:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 01:12:05 --> URI Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Router Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Output Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Input Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 01:12:05 --> Language Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Loader Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Controller Class Initialized
ERROR - 2011-06-06 01:12:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 01:12:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 01:12:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 01:12:05 --> Model Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Model Class Initialized
DEBUG - 2011-06-06 01:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 01:12:05 --> Database Driver Class Initialized
DEBUG - 2011-06-06 01:12:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 01:12:05 --> Helper loaded: url_helper
DEBUG - 2011-06-06 01:12:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 01:12:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 01:12:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 01:12:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 01:12:05 --> Final output sent to browser
DEBUG - 2011-06-06 01:12:05 --> Total execution time: 0.1011
DEBUG - 2011-06-06 01:17:07 --> Config Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Hooks Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Utf8 Class Initialized
DEBUG - 2011-06-06 01:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 01:17:07 --> URI Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Router Class Initialized
ERROR - 2011-06-06 01:17:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-06 01:17:07 --> Config Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Hooks Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Utf8 Class Initialized
DEBUG - 2011-06-06 01:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 01:17:07 --> URI Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Router Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Output Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Input Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 01:17:07 --> Language Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Loader Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Controller Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Model Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Model Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Model Class Initialized
DEBUG - 2011-06-06 01:17:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 01:17:07 --> Database Driver Class Initialized
DEBUG - 2011-06-06 01:17:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 01:17:07 --> Helper loaded: url_helper
DEBUG - 2011-06-06 01:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 01:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 01:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 01:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 01:17:07 --> Final output sent to browser
DEBUG - 2011-06-06 01:17:07 --> Total execution time: 0.0535
DEBUG - 2011-06-06 01:17:38 --> Config Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Hooks Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Utf8 Class Initialized
DEBUG - 2011-06-06 01:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 01:17:38 --> URI Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Router Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Output Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Input Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 01:17:38 --> Language Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Loader Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Controller Class Initialized
ERROR - 2011-06-06 01:17:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 01:17:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 01:17:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 01:17:38 --> Model Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Model Class Initialized
DEBUG - 2011-06-06 01:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 01:17:38 --> Database Driver Class Initialized
DEBUG - 2011-06-06 01:17:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 01:17:38 --> Helper loaded: url_helper
DEBUG - 2011-06-06 01:17:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 01:17:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 01:17:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 01:17:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 01:17:38 --> Final output sent to browser
DEBUG - 2011-06-06 01:17:38 --> Total execution time: 0.0650
DEBUG - 2011-06-06 02:24:24 --> Config Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Hooks Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Utf8 Class Initialized
DEBUG - 2011-06-06 02:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 02:24:24 --> URI Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Router Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Output Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Input Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 02:24:24 --> Language Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Loader Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Controller Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Model Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Model Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Model Class Initialized
DEBUG - 2011-06-06 02:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 02:24:24 --> Database Driver Class Initialized
DEBUG - 2011-06-06 02:24:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 02:24:34 --> Helper loaded: url_helper
DEBUG - 2011-06-06 02:24:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 02:24:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 02:24:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 02:24:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 02:24:34 --> Final output sent to browser
DEBUG - 2011-06-06 02:24:34 --> Total execution time: 10.1926
DEBUG - 2011-06-06 02:24:40 --> Config Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Hooks Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Utf8 Class Initialized
DEBUG - 2011-06-06 02:24:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 02:24:40 --> URI Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Router Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Output Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Input Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 02:24:40 --> Language Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Loader Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Controller Class Initialized
ERROR - 2011-06-06 02:24:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 02:24:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 02:24:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 02:24:40 --> Model Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Model Class Initialized
DEBUG - 2011-06-06 02:24:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 02:24:40 --> Database Driver Class Initialized
DEBUG - 2011-06-06 02:24:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 02:24:40 --> Helper loaded: url_helper
DEBUG - 2011-06-06 02:24:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 02:24:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 02:24:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 02:24:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 02:24:40 --> Final output sent to browser
DEBUG - 2011-06-06 02:24:40 --> Total execution time: 0.1301
DEBUG - 2011-06-06 02:42:53 --> Config Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Hooks Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Utf8 Class Initialized
DEBUG - 2011-06-06 02:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 02:42:53 --> URI Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Router Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Output Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Input Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 02:42:53 --> Language Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Loader Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Controller Class Initialized
ERROR - 2011-06-06 02:42:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 02:42:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 02:42:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 02:42:53 --> Model Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Model Class Initialized
DEBUG - 2011-06-06 02:42:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 02:42:53 --> Database Driver Class Initialized
DEBUG - 2011-06-06 02:42:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 02:42:53 --> Helper loaded: url_helper
DEBUG - 2011-06-06 02:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 02:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 02:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 02:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 02:42:53 --> Final output sent to browser
DEBUG - 2011-06-06 02:42:53 --> Total execution time: 0.4862
DEBUG - 2011-06-06 02:42:56 --> Config Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Hooks Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Utf8 Class Initialized
DEBUG - 2011-06-06 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 02:42:56 --> URI Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Router Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Output Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Input Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 02:42:56 --> Language Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Loader Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Controller Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Model Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Model Class Initialized
DEBUG - 2011-06-06 02:42:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 02:42:56 --> Database Driver Class Initialized
DEBUG - 2011-06-06 02:42:58 --> Final output sent to browser
DEBUG - 2011-06-06 02:42:58 --> Total execution time: 2.3092
DEBUG - 2011-06-06 02:43:20 --> Config Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Hooks Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Utf8 Class Initialized
DEBUG - 2011-06-06 02:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 02:43:20 --> URI Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Router Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Output Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Input Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 02:43:20 --> Language Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Loader Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Controller Class Initialized
ERROR - 2011-06-06 02:43:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 02:43:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 02:43:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 02:43:20 --> Model Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Model Class Initialized
DEBUG - 2011-06-06 02:43:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 02:43:20 --> Database Driver Class Initialized
DEBUG - 2011-06-06 02:43:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 02:43:20 --> Helper loaded: url_helper
DEBUG - 2011-06-06 02:43:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 02:43:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 02:43:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 02:43:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 02:43:20 --> Final output sent to browser
DEBUG - 2011-06-06 02:43:20 --> Total execution time: 0.0308
DEBUG - 2011-06-06 02:43:21 --> Config Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Hooks Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Utf8 Class Initialized
DEBUG - 2011-06-06 02:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 02:43:21 --> URI Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Router Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Output Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Input Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 02:43:21 --> Language Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Loader Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Controller Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Model Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Model Class Initialized
DEBUG - 2011-06-06 02:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 02:43:21 --> Database Driver Class Initialized
DEBUG - 2011-06-06 02:43:22 --> Final output sent to browser
DEBUG - 2011-06-06 02:43:22 --> Total execution time: 0.5463
DEBUG - 2011-06-06 03:05:05 --> Config Class Initialized
DEBUG - 2011-06-06 03:05:05 --> Hooks Class Initialized
DEBUG - 2011-06-06 03:05:05 --> Utf8 Class Initialized
DEBUG - 2011-06-06 03:05:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 03:05:05 --> URI Class Initialized
DEBUG - 2011-06-06 03:05:05 --> Router Class Initialized
DEBUG - 2011-06-06 03:05:05 --> No URI present. Default controller set.
DEBUG - 2011-06-06 03:05:05 --> Output Class Initialized
DEBUG - 2011-06-06 03:05:05 --> Input Class Initialized
DEBUG - 2011-06-06 03:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 03:05:05 --> Language Class Initialized
DEBUG - 2011-06-06 03:05:05 --> Loader Class Initialized
DEBUG - 2011-06-06 03:05:05 --> Controller Class Initialized
DEBUG - 2011-06-06 03:05:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-06 03:05:07 --> Helper loaded: url_helper
DEBUG - 2011-06-06 03:05:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 03:05:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 03:05:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 03:05:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 03:05:07 --> Final output sent to browser
DEBUG - 2011-06-06 03:05:07 --> Total execution time: 2.8302
DEBUG - 2011-06-06 03:10:21 --> Config Class Initialized
DEBUG - 2011-06-06 03:10:21 --> Hooks Class Initialized
DEBUG - 2011-06-06 03:10:21 --> Utf8 Class Initialized
DEBUG - 2011-06-06 03:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 03:10:21 --> URI Class Initialized
DEBUG - 2011-06-06 03:10:21 --> Router Class Initialized
DEBUG - 2011-06-06 03:10:21 --> No URI present. Default controller set.
DEBUG - 2011-06-06 03:10:21 --> Output Class Initialized
DEBUG - 2011-06-06 03:10:21 --> Input Class Initialized
DEBUG - 2011-06-06 03:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 03:10:21 --> Language Class Initialized
DEBUG - 2011-06-06 03:10:21 --> Loader Class Initialized
DEBUG - 2011-06-06 03:10:21 --> Controller Class Initialized
DEBUG - 2011-06-06 03:10:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-06 03:10:21 --> Helper loaded: url_helper
DEBUG - 2011-06-06 03:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 03:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 03:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 03:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 03:10:21 --> Final output sent to browser
DEBUG - 2011-06-06 03:10:21 --> Total execution time: 0.2050
DEBUG - 2011-06-06 03:37:08 --> Config Class Initialized
DEBUG - 2011-06-06 03:37:08 --> Hooks Class Initialized
DEBUG - 2011-06-06 03:37:08 --> Utf8 Class Initialized
DEBUG - 2011-06-06 03:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 03:37:08 --> URI Class Initialized
DEBUG - 2011-06-06 03:37:08 --> Router Class Initialized
ERROR - 2011-06-06 03:37:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-06 03:37:09 --> Config Class Initialized
DEBUG - 2011-06-06 03:37:09 --> Hooks Class Initialized
DEBUG - 2011-06-06 03:37:09 --> Utf8 Class Initialized
DEBUG - 2011-06-06 03:37:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 03:37:09 --> URI Class Initialized
DEBUG - 2011-06-06 03:37:09 --> Router Class Initialized
DEBUG - 2011-06-06 03:37:09 --> No URI present. Default controller set.
DEBUG - 2011-06-06 03:37:09 --> Output Class Initialized
DEBUG - 2011-06-06 03:37:09 --> Input Class Initialized
DEBUG - 2011-06-06 03:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 03:37:09 --> Language Class Initialized
DEBUG - 2011-06-06 03:37:09 --> Loader Class Initialized
DEBUG - 2011-06-06 03:37:09 --> Controller Class Initialized
DEBUG - 2011-06-06 03:37:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-06 03:37:09 --> Helper loaded: url_helper
DEBUG - 2011-06-06 03:37:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 03:37:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 03:37:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 03:37:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 03:37:09 --> Final output sent to browser
DEBUG - 2011-06-06 03:37:09 --> Total execution time: 0.1129
DEBUG - 2011-06-06 04:37:39 --> Config Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Hooks Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Utf8 Class Initialized
DEBUG - 2011-06-06 04:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 04:37:39 --> URI Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Router Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Output Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Input Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 04:37:39 --> Language Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Loader Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Controller Class Initialized
DEBUG - 2011-06-06 04:37:39 --> Model Class Initialized
DEBUG - 2011-06-06 04:37:40 --> Model Class Initialized
DEBUG - 2011-06-06 04:37:40 --> Model Class Initialized
DEBUG - 2011-06-06 04:37:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 04:37:40 --> Database Driver Class Initialized
DEBUG - 2011-06-06 04:37:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 04:37:45 --> Helper loaded: url_helper
DEBUG - 2011-06-06 04:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 04:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 04:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 04:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 04:37:45 --> Final output sent to browser
DEBUG - 2011-06-06 04:37:45 --> Total execution time: 6.1311
DEBUG - 2011-06-06 04:37:48 --> Config Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Hooks Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Utf8 Class Initialized
DEBUG - 2011-06-06 04:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 04:37:48 --> URI Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Router Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Output Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Input Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 04:37:48 --> Language Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Loader Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Controller Class Initialized
ERROR - 2011-06-06 04:37:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 04:37:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 04:37:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 04:37:48 --> Model Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Model Class Initialized
DEBUG - 2011-06-06 04:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 04:37:48 --> Database Driver Class Initialized
DEBUG - 2011-06-06 04:37:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 04:37:48 --> Helper loaded: url_helper
DEBUG - 2011-06-06 04:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 04:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 04:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 04:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 04:37:48 --> Final output sent to browser
DEBUG - 2011-06-06 04:37:48 --> Total execution time: 0.1256
DEBUG - 2011-06-06 07:34:03 --> Config Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Hooks Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Utf8 Class Initialized
DEBUG - 2011-06-06 07:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 07:34:03 --> URI Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Router Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Output Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Input Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 07:34:03 --> Language Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Loader Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Controller Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Model Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Model Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Model Class Initialized
DEBUG - 2011-06-06 07:34:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 07:34:03 --> Database Driver Class Initialized
DEBUG - 2011-06-06 07:34:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 07:34:04 --> Helper loaded: url_helper
DEBUG - 2011-06-06 07:34:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 07:34:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 07:34:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 07:34:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 07:34:04 --> Final output sent to browser
DEBUG - 2011-06-06 07:34:04 --> Total execution time: 0.5677
DEBUG - 2011-06-06 07:34:13 --> Config Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Hooks Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Utf8 Class Initialized
DEBUG - 2011-06-06 07:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 07:34:13 --> URI Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Router Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Output Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Input Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 07:34:13 --> Language Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Loader Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Controller Class Initialized
ERROR - 2011-06-06 07:34:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 07:34:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 07:34:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 07:34:13 --> Model Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Model Class Initialized
DEBUG - 2011-06-06 07:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 07:34:13 --> Database Driver Class Initialized
DEBUG - 2011-06-06 07:34:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 07:34:13 --> Helper loaded: url_helper
DEBUG - 2011-06-06 07:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 07:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 07:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 07:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 07:34:13 --> Final output sent to browser
DEBUG - 2011-06-06 07:34:13 --> Total execution time: 0.0950
DEBUG - 2011-06-06 09:27:28 --> Config Class Initialized
DEBUG - 2011-06-06 09:27:28 --> Hooks Class Initialized
DEBUG - 2011-06-06 09:27:28 --> Utf8 Class Initialized
DEBUG - 2011-06-06 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 09:27:28 --> URI Class Initialized
DEBUG - 2011-06-06 09:27:28 --> Router Class Initialized
ERROR - 2011-06-06 09:27:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-06 09:27:29 --> Config Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Hooks Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Utf8 Class Initialized
DEBUG - 2011-06-06 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 09:27:29 --> URI Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Router Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Output Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Input Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 09:27:29 --> Language Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Loader Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Controller Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Model Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Model Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Model Class Initialized
DEBUG - 2011-06-06 09:27:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 09:27:29 --> Database Driver Class Initialized
DEBUG - 2011-06-06 09:27:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 09:27:30 --> Helper loaded: url_helper
DEBUG - 2011-06-06 09:27:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 09:27:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 09:27:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 09:27:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 09:27:30 --> Final output sent to browser
DEBUG - 2011-06-06 09:27:30 --> Total execution time: 1.0207
DEBUG - 2011-06-06 09:40:17 --> Config Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Hooks Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Utf8 Class Initialized
DEBUG - 2011-06-06 09:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 09:40:17 --> URI Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Router Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Output Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Input Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 09:40:17 --> Language Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Loader Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Controller Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Model Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Model Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Model Class Initialized
DEBUG - 2011-06-06 09:40:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 09:40:17 --> Database Driver Class Initialized
DEBUG - 2011-06-06 09:40:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 09:40:17 --> Helper loaded: url_helper
DEBUG - 2011-06-06 09:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 09:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 09:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 09:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 09:40:17 --> Final output sent to browser
DEBUG - 2011-06-06 09:40:17 --> Total execution time: 0.8507
DEBUG - 2011-06-06 09:40:19 --> Config Class Initialized
DEBUG - 2011-06-06 09:40:19 --> Hooks Class Initialized
DEBUG - 2011-06-06 09:40:19 --> Utf8 Class Initialized
DEBUG - 2011-06-06 09:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 09:40:19 --> URI Class Initialized
DEBUG - 2011-06-06 09:40:19 --> Router Class Initialized
DEBUG - 2011-06-06 09:40:19 --> Output Class Initialized
DEBUG - 2011-06-06 09:40:19 --> Input Class Initialized
DEBUG - 2011-06-06 09:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 09:40:19 --> Language Class Initialized
DEBUG - 2011-06-06 09:40:19 --> Loader Class Initialized
DEBUG - 2011-06-06 09:40:19 --> Controller Class Initialized
ERROR - 2011-06-06 09:40:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 09:40:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 09:40:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 09:40:20 --> Model Class Initialized
DEBUG - 2011-06-06 09:40:20 --> Model Class Initialized
DEBUG - 2011-06-06 09:40:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 09:40:20 --> Database Driver Class Initialized
DEBUG - 2011-06-06 09:40:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 09:40:20 --> Helper loaded: url_helper
DEBUG - 2011-06-06 09:40:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 09:40:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 09:40:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 09:40:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 09:40:20 --> Final output sent to browser
DEBUG - 2011-06-06 09:40:20 --> Total execution time: 0.1467
DEBUG - 2011-06-06 11:06:25 --> Config Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Hooks Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Utf8 Class Initialized
DEBUG - 2011-06-06 11:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 11:06:25 --> URI Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Router Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Output Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Input Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 11:06:25 --> Language Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Loader Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Controller Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Model Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Model Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Model Class Initialized
DEBUG - 2011-06-06 11:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 11:06:25 --> Database Driver Class Initialized
DEBUG - 2011-06-06 11:06:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 11:06:25 --> Helper loaded: url_helper
DEBUG - 2011-06-06 11:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 11:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 11:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 11:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 11:06:25 --> Final output sent to browser
DEBUG - 2011-06-06 11:06:25 --> Total execution time: 0.5295
DEBUG - 2011-06-06 11:06:27 --> Config Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Hooks Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Utf8 Class Initialized
DEBUG - 2011-06-06 11:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 11:06:27 --> URI Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Router Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Output Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Input Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 11:06:27 --> Language Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Loader Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Controller Class Initialized
ERROR - 2011-06-06 11:06:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 11:06:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 11:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 11:06:27 --> Model Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Model Class Initialized
DEBUG - 2011-06-06 11:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 11:06:27 --> Database Driver Class Initialized
DEBUG - 2011-06-06 11:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 11:06:27 --> Helper loaded: url_helper
DEBUG - 2011-06-06 11:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 11:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 11:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 11:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 11:06:27 --> Final output sent to browser
DEBUG - 2011-06-06 11:06:27 --> Total execution time: 0.1029
DEBUG - 2011-06-06 11:54:01 --> Config Class Initialized
DEBUG - 2011-06-06 11:54:01 --> Hooks Class Initialized
DEBUG - 2011-06-06 11:54:01 --> Utf8 Class Initialized
DEBUG - 2011-06-06 11:54:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 11:54:01 --> URI Class Initialized
DEBUG - 2011-06-06 11:54:01 --> Router Class Initialized
DEBUG - 2011-06-06 11:54:01 --> No URI present. Default controller set.
DEBUG - 2011-06-06 11:54:01 --> Output Class Initialized
DEBUG - 2011-06-06 11:54:01 --> Input Class Initialized
DEBUG - 2011-06-06 11:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 11:54:01 --> Language Class Initialized
DEBUG - 2011-06-06 11:54:01 --> Loader Class Initialized
DEBUG - 2011-06-06 11:54:01 --> Controller Class Initialized
DEBUG - 2011-06-06 11:54:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-06 11:54:01 --> Helper loaded: url_helper
DEBUG - 2011-06-06 11:54:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 11:54:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 11:54:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 11:54:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 11:54:01 --> Final output sent to browser
DEBUG - 2011-06-06 11:54:01 --> Total execution time: 0.3036
DEBUG - 2011-06-06 12:04:11 --> Config Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:04:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:04:11 --> URI Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Router Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Output Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Input Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:04:11 --> Language Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Loader Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Controller Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Model Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Model Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Model Class Initialized
DEBUG - 2011-06-06 12:04:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:04:11 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:04:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 12:04:12 --> Helper loaded: url_helper
DEBUG - 2011-06-06 12:04:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 12:04:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 12:04:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 12:04:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 12:04:12 --> Final output sent to browser
DEBUG - 2011-06-06 12:04:12 --> Total execution time: 0.5657
DEBUG - 2011-06-06 12:05:09 --> Config Class Initialized
DEBUG - 2011-06-06 12:05:09 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:05:09 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:05:09 --> URI Class Initialized
DEBUG - 2011-06-06 12:05:09 --> Router Class Initialized
DEBUG - 2011-06-06 12:05:09 --> Output Class Initialized
DEBUG - 2011-06-06 12:05:09 --> Input Class Initialized
DEBUG - 2011-06-06 12:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:05:09 --> Language Class Initialized
DEBUG - 2011-06-06 12:05:09 --> Loader Class Initialized
DEBUG - 2011-06-06 12:05:09 --> Controller Class Initialized
ERROR - 2011-06-06 12:05:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 12:05:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 12:05:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:05:10 --> Model Class Initialized
DEBUG - 2011-06-06 12:05:10 --> Model Class Initialized
DEBUG - 2011-06-06 12:05:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:05:10 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:05:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:05:10 --> Helper loaded: url_helper
DEBUG - 2011-06-06 12:05:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 12:05:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 12:05:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 12:05:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 12:05:10 --> Final output sent to browser
DEBUG - 2011-06-06 12:05:10 --> Total execution time: 0.1391
DEBUG - 2011-06-06 12:11:31 --> Config Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:11:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:11:31 --> URI Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Router Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Output Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Input Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:11:31 --> Language Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Loader Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Controller Class Initialized
ERROR - 2011-06-06 12:11:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 12:11:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 12:11:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:11:31 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:11:31 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:11:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:11:31 --> Helper loaded: url_helper
DEBUG - 2011-06-06 12:11:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 12:11:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 12:11:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 12:11:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 12:11:31 --> Final output sent to browser
DEBUG - 2011-06-06 12:11:31 --> Total execution time: 0.1141
DEBUG - 2011-06-06 12:11:33 --> Config Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:11:33 --> URI Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Router Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Output Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Input Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:11:33 --> Language Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Loader Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Controller Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:11:33 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:11:34 --> Final output sent to browser
DEBUG - 2011-06-06 12:11:34 --> Total execution time: 0.5849
DEBUG - 2011-06-06 12:11:36 --> Config Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:11:36 --> URI Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Router Class Initialized
ERROR - 2011-06-06 12:11:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-06 12:11:36 --> Config Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:11:36 --> URI Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Router Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Output Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Input Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:11:36 --> Language Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Loader Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Controller Class Initialized
ERROR - 2011-06-06 12:11:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 12:11:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 12:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:11:36 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:11:36 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:11:36 --> Helper loaded: url_helper
DEBUG - 2011-06-06 12:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 12:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 12:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 12:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 12:11:36 --> Final output sent to browser
DEBUG - 2011-06-06 12:11:36 --> Total execution time: 0.0297
DEBUG - 2011-06-06 12:11:49 --> Config Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:11:49 --> URI Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Router Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Output Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Input Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:11:49 --> Language Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Loader Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Controller Class Initialized
ERROR - 2011-06-06 12:11:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 12:11:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 12:11:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:11:49 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:11:49 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:11:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:11:49 --> Helper loaded: url_helper
DEBUG - 2011-06-06 12:11:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 12:11:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 12:11:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 12:11:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 12:11:49 --> Final output sent to browser
DEBUG - 2011-06-06 12:11:49 --> Total execution time: 0.0337
DEBUG - 2011-06-06 12:11:51 --> Config Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:11:51 --> URI Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Router Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Output Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Input Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:11:51 --> Language Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Loader Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Controller Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Model Class Initialized
DEBUG - 2011-06-06 12:11:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:11:51 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:11:53 --> Final output sent to browser
DEBUG - 2011-06-06 12:11:53 --> Total execution time: 2.3201
DEBUG - 2011-06-06 12:37:53 --> Config Class Initialized
DEBUG - 2011-06-06 12:37:53 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:37:53 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:37:54 --> URI Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Router Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Output Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Input Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:37:54 --> Language Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Loader Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Controller Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Model Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Model Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Model Class Initialized
DEBUG - 2011-06-06 12:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:37:54 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:37:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 12:37:54 --> Helper loaded: url_helper
DEBUG - 2011-06-06 12:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 12:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 12:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 12:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 12:37:54 --> Final output sent to browser
DEBUG - 2011-06-06 12:37:54 --> Total execution time: 0.9741
DEBUG - 2011-06-06 12:37:57 --> Config Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Hooks Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Utf8 Class Initialized
DEBUG - 2011-06-06 12:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 12:37:57 --> URI Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Router Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Output Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Input Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 12:37:57 --> Language Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Loader Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Controller Class Initialized
ERROR - 2011-06-06 12:37:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 12:37:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 12:37:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:37:57 --> Model Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Model Class Initialized
DEBUG - 2011-06-06 12:37:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 12:37:57 --> Database Driver Class Initialized
DEBUG - 2011-06-06 12:37:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 12:37:57 --> Helper loaded: url_helper
DEBUG - 2011-06-06 12:37:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 12:37:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 12:37:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 12:37:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 12:37:57 --> Final output sent to browser
DEBUG - 2011-06-06 12:37:57 --> Total execution time: 0.1033
DEBUG - 2011-06-06 13:27:55 --> Config Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:27:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:27:55 --> URI Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Router Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Output Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Input Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:27:55 --> Language Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Loader Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Controller Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:27:55 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:27:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:27:56 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:27:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:27:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:27:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:27:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:27:56 --> Final output sent to browser
DEBUG - 2011-06-06 13:27:56 --> Total execution time: 0.6564
DEBUG - 2011-06-06 13:27:57 --> Config Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:27:57 --> URI Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Router Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Output Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Input Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:27:57 --> Language Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Loader Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Controller Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:27:57 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:27:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:27:57 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:27:57 --> Final output sent to browser
DEBUG - 2011-06-06 13:27:57 --> Total execution time: 0.0772
DEBUG - 2011-06-06 13:27:58 --> Config Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:27:58 --> URI Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Router Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Output Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Input Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:27:58 --> Language Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Loader Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Controller Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Model Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:27:58 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:27:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:27:58 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:27:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:27:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:27:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:27:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:27:58 --> Final output sent to browser
DEBUG - 2011-06-06 13:27:58 --> Total execution time: 0.0491
DEBUG - 2011-06-06 13:27:58 --> Config Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:27:58 --> URI Class Initialized
DEBUG - 2011-06-06 13:27:58 --> Router Class Initialized
ERROR - 2011-06-06 13:27:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 13:28:11 --> Config Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:28:11 --> URI Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Router Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Output Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Input Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:28:11 --> Language Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Loader Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Controller Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Model Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Model Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Model Class Initialized
DEBUG - 2011-06-06 13:28:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:28:11 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:28:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:28:11 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:28:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:28:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:28:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:28:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:28:11 --> Final output sent to browser
DEBUG - 2011-06-06 13:28:11 --> Total execution time: 0.3430
DEBUG - 2011-06-06 13:28:12 --> Config Class Initialized
DEBUG - 2011-06-06 13:28:12 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:28:12 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:28:12 --> URI Class Initialized
DEBUG - 2011-06-06 13:28:12 --> Router Class Initialized
DEBUG - 2011-06-06 13:28:12 --> Output Class Initialized
DEBUG - 2011-06-06 13:28:12 --> Input Class Initialized
DEBUG - 2011-06-06 13:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:28:13 --> Language Class Initialized
DEBUG - 2011-06-06 13:28:13 --> Loader Class Initialized
DEBUG - 2011-06-06 13:28:13 --> Controller Class Initialized
DEBUG - 2011-06-06 13:28:13 --> Model Class Initialized
DEBUG - 2011-06-06 13:28:13 --> Model Class Initialized
DEBUG - 2011-06-06 13:28:13 --> Model Class Initialized
DEBUG - 2011-06-06 13:28:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:28:13 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:28:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:28:13 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:28:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:28:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:28:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:28:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:28:13 --> Final output sent to browser
DEBUG - 2011-06-06 13:28:13 --> Total execution time: 0.0445
DEBUG - 2011-06-06 13:47:32 --> Config Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:47:32 --> URI Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Router Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Output Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Input Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:47:32 --> Language Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Loader Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Controller Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:47:32 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:47:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:47:32 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:47:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:47:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:47:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:47:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:47:32 --> Final output sent to browser
DEBUG - 2011-06-06 13:47:32 --> Total execution time: 0.1189
DEBUG - 2011-06-06 13:47:35 --> Config Class Initialized
DEBUG - 2011-06-06 13:47:35 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:47:35 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:47:35 --> URI Class Initialized
DEBUG - 2011-06-06 13:47:35 --> Router Class Initialized
ERROR - 2011-06-06 13:47:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 13:47:36 --> Config Class Initialized
DEBUG - 2011-06-06 13:47:36 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:47:36 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:47:36 --> URI Class Initialized
DEBUG - 2011-06-06 13:47:36 --> Router Class Initialized
ERROR - 2011-06-06 13:47:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 13:47:51 --> Config Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:47:51 --> URI Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Router Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Output Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Input Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:47:51 --> Language Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Loader Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Controller Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:47:51 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:47:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:47:52 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:47:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:47:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:47:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:47:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:47:52 --> Final output sent to browser
DEBUG - 2011-06-06 13:47:52 --> Total execution time: 1.7457
DEBUG - 2011-06-06 13:47:54 --> Config Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:47:54 --> URI Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Router Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Output Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Input Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:47:54 --> Language Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Loader Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Controller Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:47:54 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:47:54 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:47:54 --> Final output sent to browser
DEBUG - 2011-06-06 13:47:54 --> Total execution time: 0.2029
DEBUG - 2011-06-06 13:47:54 --> Config Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:47:54 --> URI Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Router Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Output Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Input Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:47:54 --> Language Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Loader Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Controller Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Model Class Initialized
DEBUG - 2011-06-06 13:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:47:54 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:47:54 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:47:54 --> Final output sent to browser
DEBUG - 2011-06-06 13:47:54 --> Total execution time: 0.1558
DEBUG - 2011-06-06 13:48:05 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:05 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:05 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:05 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:06 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:06 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:06 --> Total execution time: 0.7360
DEBUG - 2011-06-06 13:48:07 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:07 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:07 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:07 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:07 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:07 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:07 --> Total execution time: 0.1277
DEBUG - 2011-06-06 13:48:17 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:17 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:17 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:17 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:17 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:17 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:17 --> Total execution time: 0.2811
DEBUG - 2011-06-06 13:48:20 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:20 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:20 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:20 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:20 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:20 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:20 --> Total execution time: 0.0667
DEBUG - 2011-06-06 13:48:28 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:28 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:28 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:28 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:29 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:29 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:29 --> Total execution time: 0.3813
DEBUG - 2011-06-06 13:48:29 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:29 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:29 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:29 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:30 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:30 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:30 --> Total execution time: 0.0694
DEBUG - 2011-06-06 13:48:30 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:30 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:30 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:30 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:30 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:30 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:30 --> Total execution time: 0.0485
DEBUG - 2011-06-06 13:48:30 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:30 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:30 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:30 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:30 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:30 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:30 --> Total execution time: 0.0892
DEBUG - 2011-06-06 13:48:33 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:33 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:33 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:33 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:33 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:33 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:33 --> Total execution time: 0.3729
DEBUG - 2011-06-06 13:48:34 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:34 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:34 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:34 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:34 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:34 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:34 --> Total execution time: 0.1005
DEBUG - 2011-06-06 13:48:34 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:34 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:34 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:34 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:34 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:34 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:34 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:34 --> Total execution time: 0.1174
DEBUG - 2011-06-06 13:48:34 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:34 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:34 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:34 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:34 --> Total execution time: 0.1075
DEBUG - 2011-06-06 13:48:42 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:42 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:42 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:42 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:42 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:42 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:42 --> Total execution time: 0.4547
DEBUG - 2011-06-06 13:48:43 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:43 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:43 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:43 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:43 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:43 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:43 --> Total execution time: 0.0458
DEBUG - 2011-06-06 13:48:44 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:44 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:44 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:44 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:44 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:44 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:44 --> Total execution time: 0.0570
DEBUG - 2011-06-06 13:48:53 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:53 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:53 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:53 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:53 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:53 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:53 --> Total execution time: 0.4168
DEBUG - 2011-06-06 13:48:55 --> Config Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:48:55 --> URI Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Router Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Output Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Input Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:48:55 --> Language Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Loader Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Controller Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Model Class Initialized
DEBUG - 2011-06-06 13:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:48:55 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:48:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:48:55 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:48:55 --> Final output sent to browser
DEBUG - 2011-06-06 13:48:55 --> Total execution time: 0.0553
DEBUG - 2011-06-06 13:49:06 --> Config Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:49:06 --> URI Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Router Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Output Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Input Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:49:06 --> Language Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Loader Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Controller Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Model Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Model Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Model Class Initialized
DEBUG - 2011-06-06 13:49:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:49:06 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:49:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:49:06 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:49:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:49:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:49:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:49:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:49:06 --> Final output sent to browser
DEBUG - 2011-06-06 13:49:06 --> Total execution time: 0.6025
DEBUG - 2011-06-06 13:49:07 --> Config Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Hooks Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Utf8 Class Initialized
DEBUG - 2011-06-06 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 13:49:07 --> URI Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Router Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Output Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Input Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 13:49:07 --> Language Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Loader Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Controller Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Model Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Model Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Model Class Initialized
DEBUG - 2011-06-06 13:49:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 13:49:07 --> Database Driver Class Initialized
DEBUG - 2011-06-06 13:49:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 13:49:07 --> Helper loaded: url_helper
DEBUG - 2011-06-06 13:49:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 13:49:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 13:49:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 13:49:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 13:49:07 --> Final output sent to browser
DEBUG - 2011-06-06 13:49:07 --> Total execution time: 0.0650
DEBUG - 2011-06-06 14:14:26 --> Config Class Initialized
DEBUG - 2011-06-06 14:14:26 --> Hooks Class Initialized
DEBUG - 2011-06-06 14:14:26 --> Utf8 Class Initialized
DEBUG - 2011-06-06 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 14:14:26 --> URI Class Initialized
DEBUG - 2011-06-06 14:14:26 --> Router Class Initialized
DEBUG - 2011-06-06 14:14:26 --> Output Class Initialized
DEBUG - 2011-06-06 14:14:26 --> Input Class Initialized
DEBUG - 2011-06-06 14:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 14:14:26 --> Language Class Initialized
DEBUG - 2011-06-06 14:14:26 --> Loader Class Initialized
DEBUG - 2011-06-06 14:14:26 --> Controller Class Initialized
DEBUG - 2011-06-06 14:14:27 --> Model Class Initialized
DEBUG - 2011-06-06 14:14:27 --> Model Class Initialized
DEBUG - 2011-06-06 14:14:27 --> Model Class Initialized
DEBUG - 2011-06-06 14:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 14:14:27 --> Database Driver Class Initialized
DEBUG - 2011-06-06 14:14:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 14:14:27 --> Helper loaded: url_helper
DEBUG - 2011-06-06 14:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 14:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 14:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 14:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 14:14:27 --> Final output sent to browser
DEBUG - 2011-06-06 14:14:27 --> Total execution time: 0.6729
DEBUG - 2011-06-06 14:14:29 --> Config Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Hooks Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Utf8 Class Initialized
DEBUG - 2011-06-06 14:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 14:14:29 --> URI Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Router Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Output Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Input Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 14:14:29 --> Language Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Loader Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Controller Class Initialized
ERROR - 2011-06-06 14:14:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 14:14:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 14:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 14:14:29 --> Model Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Model Class Initialized
DEBUG - 2011-06-06 14:14:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 14:14:29 --> Database Driver Class Initialized
DEBUG - 2011-06-06 14:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 14:14:29 --> Helper loaded: url_helper
DEBUG - 2011-06-06 14:14:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 14:14:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 14:14:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 14:14:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 14:14:29 --> Final output sent to browser
DEBUG - 2011-06-06 14:14:29 --> Total execution time: 0.1317
DEBUG - 2011-06-06 14:59:54 --> Config Class Initialized
DEBUG - 2011-06-06 14:59:54 --> Hooks Class Initialized
DEBUG - 2011-06-06 14:59:54 --> Utf8 Class Initialized
DEBUG - 2011-06-06 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 14:59:54 --> URI Class Initialized
DEBUG - 2011-06-06 14:59:54 --> Router Class Initialized
DEBUG - 2011-06-06 14:59:54 --> No URI present. Default controller set.
DEBUG - 2011-06-06 14:59:54 --> Output Class Initialized
DEBUG - 2011-06-06 14:59:54 --> Input Class Initialized
DEBUG - 2011-06-06 14:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 14:59:54 --> Language Class Initialized
DEBUG - 2011-06-06 14:59:54 --> Loader Class Initialized
DEBUG - 2011-06-06 14:59:54 --> Controller Class Initialized
DEBUG - 2011-06-06 14:59:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-06 14:59:54 --> Helper loaded: url_helper
DEBUG - 2011-06-06 14:59:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 14:59:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 14:59:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 14:59:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 14:59:54 --> Final output sent to browser
DEBUG - 2011-06-06 14:59:54 --> Total execution time: 0.3482
DEBUG - 2011-06-06 15:00:00 --> Config Class Initialized
DEBUG - 2011-06-06 15:00:00 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:00:00 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:00:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:00:00 --> URI Class Initialized
DEBUG - 2011-06-06 15:00:00 --> Router Class Initialized
DEBUG - 2011-06-06 15:00:00 --> No URI present. Default controller set.
DEBUG - 2011-06-06 15:00:00 --> Output Class Initialized
DEBUG - 2011-06-06 15:00:00 --> Input Class Initialized
DEBUG - 2011-06-06 15:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:00:00 --> Language Class Initialized
DEBUG - 2011-06-06 15:00:00 --> Loader Class Initialized
DEBUG - 2011-06-06 15:00:00 --> Controller Class Initialized
DEBUG - 2011-06-06 15:00:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-06 15:00:00 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:00:00 --> Final output sent to browser
DEBUG - 2011-06-06 15:00:00 --> Total execution time: 0.0346
DEBUG - 2011-06-06 15:00:02 --> Config Class Initialized
DEBUG - 2011-06-06 15:00:02 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:00:02 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:00:02 --> URI Class Initialized
DEBUG - 2011-06-06 15:00:02 --> Router Class Initialized
ERROR - 2011-06-06 15:00:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 15:00:05 --> Config Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:00:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:00:05 --> Config Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:00:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:00:05 --> URI Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Router Class Initialized
ERROR - 2011-06-06 15:00:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 15:00:05 --> URI Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Router Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Output Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Input Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:00:05 --> Language Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Loader Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Controller Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Model Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Model Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Model Class Initialized
DEBUG - 2011-06-06 15:00:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:00:05 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:00:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:00:07 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:00:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:00:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:00:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:00:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:00:07 --> Final output sent to browser
DEBUG - 2011-06-06 15:00:07 --> Total execution time: 1.9284
DEBUG - 2011-06-06 15:01:02 --> Config Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:01:02 --> URI Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Router Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Output Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Input Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:01:02 --> Language Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Loader Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Controller Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:01:02 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:01:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:01:03 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:01:03 --> Final output sent to browser
DEBUG - 2011-06-06 15:01:03 --> Total execution time: 0.3810
DEBUG - 2011-06-06 15:01:06 --> Config Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:01:06 --> URI Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Router Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Output Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Input Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:01:06 --> Language Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Loader Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Controller Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:01:06 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:01:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:01:06 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:01:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:01:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:01:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:01:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:01:06 --> Final output sent to browser
DEBUG - 2011-06-06 15:01:06 --> Total execution time: 0.0593
DEBUG - 2011-06-06 15:01:07 --> Config Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:01:07 --> URI Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Router Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Output Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Input Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:01:07 --> Language Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Loader Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Controller Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Model Class Initialized
DEBUG - 2011-06-06 15:01:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:01:07 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:01:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:01:07 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:01:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:01:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:01:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:01:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:01:07 --> Final output sent to browser
DEBUG - 2011-06-06 15:01:07 --> Total execution time: 0.0956
DEBUG - 2011-06-06 15:02:52 --> Config Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:02:52 --> URI Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Router Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Output Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Input Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:02:52 --> Language Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Loader Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Controller Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Model Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Model Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Model Class Initialized
DEBUG - 2011-06-06 15:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:02:52 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:02:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:02:52 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:02:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:02:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:02:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:02:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:02:52 --> Final output sent to browser
DEBUG - 2011-06-06 15:02:52 --> Total execution time: 0.2249
DEBUG - 2011-06-06 15:02:56 --> Config Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:02:56 --> URI Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Router Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Output Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Input Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:02:56 --> Language Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Loader Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Controller Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Model Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Model Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Model Class Initialized
DEBUG - 2011-06-06 15:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:02:56 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:02:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:02:56 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:02:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:02:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:02:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:02:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:02:56 --> Final output sent to browser
DEBUG - 2011-06-06 15:02:56 --> Total execution time: 0.0717
DEBUG - 2011-06-06 15:03:07 --> Config Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:03:07 --> URI Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Router Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Output Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Input Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:03:07 --> Language Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Loader Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Controller Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:03:07 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:03:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:03:07 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:03:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:03:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:03:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:03:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:03:07 --> Final output sent to browser
DEBUG - 2011-06-06 15:03:07 --> Total execution time: 0.2637
DEBUG - 2011-06-06 15:03:43 --> Config Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:03:43 --> URI Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Router Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Output Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Input Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:03:43 --> Language Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Loader Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Controller Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:03:43 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:03:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:03:43 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:03:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:03:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:03:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:03:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:03:43 --> Final output sent to browser
DEBUG - 2011-06-06 15:03:43 --> Total execution time: 0.3180
DEBUG - 2011-06-06 15:03:54 --> Config Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:03:54 --> URI Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Router Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Output Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Input Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:03:54 --> Language Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Loader Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Controller Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Model Class Initialized
DEBUG - 2011-06-06 15:03:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:03:54 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:03:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:03:55 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:03:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:03:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:03:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:03:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:03:55 --> Final output sent to browser
DEBUG - 2011-06-06 15:03:55 --> Total execution time: 0.0741
DEBUG - 2011-06-06 15:04:06 --> Config Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:04:06 --> URI Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Router Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Output Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Input Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:04:06 --> Language Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Loader Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Controller Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:04:06 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:04:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:04:07 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:04:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:04:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:04:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:04:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:04:07 --> Final output sent to browser
DEBUG - 2011-06-06 15:04:07 --> Total execution time: 0.6584
DEBUG - 2011-06-06 15:04:11 --> Config Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:04:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:04:11 --> URI Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Router Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Output Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Input Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:04:11 --> Language Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Loader Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Controller Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:04:11 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:04:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:04:11 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:04:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:04:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:04:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:04:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:04:11 --> Final output sent to browser
DEBUG - 2011-06-06 15:04:11 --> Total execution time: 0.0813
DEBUG - 2011-06-06 15:04:22 --> Config Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:04:22 --> URI Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Router Class Initialized
ERROR - 2011-06-06 15:04:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-06 15:04:22 --> Config Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:04:22 --> URI Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Router Class Initialized
DEBUG - 2011-06-06 15:04:22 --> No URI present. Default controller set.
DEBUG - 2011-06-06 15:04:22 --> Output Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Input Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:04:22 --> Language Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Loader Class Initialized
DEBUG - 2011-06-06 15:04:22 --> Controller Class Initialized
DEBUG - 2011-06-06 15:04:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-06 15:04:22 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:04:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:04:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:04:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:04:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:04:22 --> Final output sent to browser
DEBUG - 2011-06-06 15:04:22 --> Total execution time: 0.0308
DEBUG - 2011-06-06 15:04:31 --> Config Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:04:31 --> URI Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Router Class Initialized
ERROR - 2011-06-06 15:04:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-06 15:04:31 --> Config Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:04:31 --> URI Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Router Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Output Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Input Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:04:31 --> Language Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Loader Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Controller Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Model Class Initialized
DEBUG - 2011-06-06 15:04:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:04:31 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:04:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:04:32 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:04:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:04:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:04:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:04:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:04:32 --> Final output sent to browser
DEBUG - 2011-06-06 15:04:32 --> Total execution time: 0.0898
DEBUG - 2011-06-06 15:40:29 --> Config Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:40:29 --> URI Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Router Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Output Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Input Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:40:29 --> Language Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Loader Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Controller Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Model Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Model Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Model Class Initialized
DEBUG - 2011-06-06 15:40:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:40:29 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:40:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:40:30 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:40:30 --> Final output sent to browser
DEBUG - 2011-06-06 15:40:30 --> Total execution time: 0.4910
DEBUG - 2011-06-06 15:40:31 --> Config Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:40:31 --> URI Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Router Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Output Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Input Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:40:31 --> Language Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Loader Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Controller Class Initialized
ERROR - 2011-06-06 15:40:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 15:40:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 15:40:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 15:40:31 --> Model Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Model Class Initialized
DEBUG - 2011-06-06 15:40:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:40:31 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:40:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 15:40:31 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:40:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:40:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:40:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:40:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:40:31 --> Final output sent to browser
DEBUG - 2011-06-06 15:40:31 --> Total execution time: 0.1006
DEBUG - 2011-06-06 15:57:34 --> Config Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:57:34 --> URI Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Router Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Output Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Input Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:57:34 --> Language Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Loader Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Controller Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Model Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Model Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Model Class Initialized
DEBUG - 2011-06-06 15:57:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:57:34 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:57:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:57:34 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:57:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:57:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:57:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:57:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:57:34 --> Final output sent to browser
DEBUG - 2011-06-06 15:57:34 --> Total execution time: 0.1228
DEBUG - 2011-06-06 15:58:14 --> Config Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:58:14 --> URI Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Router Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Output Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Input Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:58:14 --> Language Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Loader Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Controller Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:58:14 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:58:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:58:14 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:58:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:58:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:58:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:58:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:58:14 --> Final output sent to browser
DEBUG - 2011-06-06 15:58:14 --> Total execution time: 0.2088
DEBUG - 2011-06-06 15:58:49 --> Config Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:58:49 --> URI Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Router Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Output Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Input Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:58:49 --> Language Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Loader Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Controller Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:58:49 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:58:49 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:58:49 --> Final output sent to browser
DEBUG - 2011-06-06 15:58:49 --> Total execution time: 0.1943
DEBUG - 2011-06-06 15:58:51 --> Config Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:58:51 --> URI Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Router Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Output Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Input Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:58:51 --> Language Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Loader Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Controller Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Model Class Initialized
DEBUG - 2011-06-06 15:58:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:58:51 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:58:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:58:51 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:58:51 --> Final output sent to browser
DEBUG - 2011-06-06 15:58:51 --> Total execution time: 0.0661
DEBUG - 2011-06-06 15:59:23 --> Config Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:59:23 --> URI Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Router Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Output Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Input Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:59:23 --> Language Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Loader Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Controller Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:59:23 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:59:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:59:23 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:59:23 --> Final output sent to browser
DEBUG - 2011-06-06 15:59:23 --> Total execution time: 0.5643
DEBUG - 2011-06-06 15:59:25 --> Config Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:59:25 --> URI Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Router Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Output Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Input Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:59:25 --> Language Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Loader Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Controller Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:59:25 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:59:25 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:59:25 --> Final output sent to browser
DEBUG - 2011-06-06 15:59:25 --> Total execution time: 0.0580
DEBUG - 2011-06-06 15:59:25 --> Config Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:59:25 --> URI Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Router Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Output Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Input Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:59:25 --> Language Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Loader Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Controller Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:59:25 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:59:25 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:59:25 --> Final output sent to browser
DEBUG - 2011-06-06 15:59:25 --> Total execution time: 0.1134
DEBUG - 2011-06-06 15:59:25 --> Config Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:59:25 --> URI Class Initialized
DEBUG - 2011-06-06 15:59:25 --> Router Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Output Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Input Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:59:26 --> Language Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Loader Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Controller Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:59:26 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:59:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:59:26 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:59:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:59:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:59:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:59:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:59:26 --> Final output sent to browser
DEBUG - 2011-06-06 15:59:26 --> Total execution time: 0.1124
DEBUG - 2011-06-06 15:59:59 --> Config Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Hooks Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Utf8 Class Initialized
DEBUG - 2011-06-06 15:59:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 15:59:59 --> URI Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Router Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Output Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Input Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 15:59:59 --> Language Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Loader Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Controller Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Model Class Initialized
DEBUG - 2011-06-06 15:59:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 15:59:59 --> Database Driver Class Initialized
DEBUG - 2011-06-06 15:59:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 15:59:59 --> Helper loaded: url_helper
DEBUG - 2011-06-06 15:59:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 15:59:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 15:59:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 15:59:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 15:59:59 --> Final output sent to browser
DEBUG - 2011-06-06 15:59:59 --> Total execution time: 0.2314
DEBUG - 2011-06-06 16:00:01 --> Config Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:00:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:00:01 --> URI Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Router Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Output Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Input Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:00:01 --> Language Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Loader Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Controller Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:00:01 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:00:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:00:01 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:00:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:00:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:00:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:00:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:00:01 --> Final output sent to browser
DEBUG - 2011-06-06 16:00:01 --> Total execution time: 0.0560
DEBUG - 2011-06-06 16:00:11 --> Config Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:00:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:00:11 --> URI Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Router Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Output Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Input Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:00:11 --> Language Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Loader Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Controller Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:00:11 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:00:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:00:11 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:00:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:00:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:00:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:00:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:00:11 --> Final output sent to browser
DEBUG - 2011-06-06 16:00:11 --> Total execution time: 0.2030
DEBUG - 2011-06-06 16:00:32 --> Config Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:00:32 --> URI Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Router Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Output Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Input Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:00:32 --> Language Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Loader Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Controller Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:00:32 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:00:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:00:33 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:00:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:00:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:00:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:00:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:00:33 --> Final output sent to browser
DEBUG - 2011-06-06 16:00:33 --> Total execution time: 0.3392
DEBUG - 2011-06-06 16:00:34 --> Config Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:00:34 --> URI Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Router Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Output Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Input Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:00:34 --> Language Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Loader Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Controller Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Model Class Initialized
DEBUG - 2011-06-06 16:00:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:00:34 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:00:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:00:34 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:00:34 --> Final output sent to browser
DEBUG - 2011-06-06 16:00:34 --> Total execution time: 0.0456
DEBUG - 2011-06-06 16:01:09 --> Config Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:01:09 --> URI Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Router Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Output Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Input Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:01:09 --> Language Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Loader Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Controller Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:01:09 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:01:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:01:09 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:01:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:01:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:01:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:01:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:01:09 --> Final output sent to browser
DEBUG - 2011-06-06 16:01:09 --> Total execution time: 0.3617
DEBUG - 2011-06-06 16:01:21 --> Config Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:01:21 --> URI Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Router Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Output Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Input Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:01:21 --> Language Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Loader Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Controller Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:01:21 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:01:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:01:21 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:01:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:01:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:01:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:01:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:01:21 --> Final output sent to browser
DEBUG - 2011-06-06 16:01:21 --> Total execution time: 0.0448
DEBUG - 2011-06-06 16:01:48 --> Config Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:01:48 --> URI Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Router Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Output Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Input Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:01:48 --> Language Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Loader Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Controller Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Model Class Initialized
DEBUG - 2011-06-06 16:01:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:01:48 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:01:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:01:48 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:01:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:01:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:01:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:01:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:01:48 --> Final output sent to browser
DEBUG - 2011-06-06 16:01:48 --> Total execution time: 0.4780
DEBUG - 2011-06-06 16:02:15 --> Config Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:02:15 --> URI Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Router Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Output Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Input Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:02:15 --> Language Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Loader Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Controller Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:02:15 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:02:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:02:16 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:02:16 --> Final output sent to browser
DEBUG - 2011-06-06 16:02:16 --> Total execution time: 0.7788
DEBUG - 2011-06-06 16:02:17 --> Config Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:02:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:02:17 --> URI Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Router Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Output Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Input Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:02:17 --> Language Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Loader Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Controller Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:02:17 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:02:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:02:17 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:02:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:02:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:02:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:02:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:02:17 --> Final output sent to browser
DEBUG - 2011-06-06 16:02:17 --> Total execution time: 0.0470
DEBUG - 2011-06-06 16:02:26 --> Config Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:02:26 --> URI Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Router Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Output Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Input Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:02:26 --> Language Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Loader Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Controller Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:02:26 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:02:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:02:26 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:02:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:02:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:02:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:02:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:02:26 --> Final output sent to browser
DEBUG - 2011-06-06 16:02:26 --> Total execution time: 0.1404
DEBUG - 2011-06-06 16:02:32 --> Config Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:02:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:02:32 --> URI Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Router Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Output Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Input Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:02:32 --> Language Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Loader Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Controller Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:02:32 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:02:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:02:32 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:02:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:02:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:02:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:02:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:02:32 --> Final output sent to browser
DEBUG - 2011-06-06 16:02:32 --> Total execution time: 0.3838
DEBUG - 2011-06-06 16:02:34 --> Config Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:02:34 --> URI Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Router Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Output Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Input Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:02:34 --> Language Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Loader Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Controller Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:02:34 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:02:34 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:02:34 --> Final output sent to browser
DEBUG - 2011-06-06 16:02:34 --> Total execution time: 0.1114
DEBUG - 2011-06-06 16:02:50 --> Config Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:02:50 --> URI Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Router Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Output Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Input Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:02:50 --> Language Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Loader Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Controller Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:02:50 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:02:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:02:51 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:02:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:02:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:02:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:02:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:02:51 --> Final output sent to browser
DEBUG - 2011-06-06 16:02:51 --> Total execution time: 0.4197
DEBUG - 2011-06-06 16:02:52 --> Config Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:02:52 --> URI Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Router Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Output Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Input Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:02:52 --> Language Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Loader Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Controller Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Model Class Initialized
DEBUG - 2011-06-06 16:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:02:52 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:02:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:02:52 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:02:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:02:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:02:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:02:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:02:52 --> Final output sent to browser
DEBUG - 2011-06-06 16:02:52 --> Total execution time: 0.0984
DEBUG - 2011-06-06 16:03:02 --> Config Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:03:02 --> URI Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Router Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Output Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Input Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:03:02 --> Language Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Loader Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Controller Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:03:02 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:03:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:03:02 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:03:02 --> Final output sent to browser
DEBUG - 2011-06-06 16:03:02 --> Total execution time: 0.0609
DEBUG - 2011-06-06 16:03:21 --> Config Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:03:21 --> URI Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Router Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Output Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Input Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:03:21 --> Language Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Loader Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Controller Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:03:21 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:03:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:03:21 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:03:21 --> Final output sent to browser
DEBUG - 2011-06-06 16:03:21 --> Total execution time: 0.3216
DEBUG - 2011-06-06 16:03:25 --> Config Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:03:25 --> URI Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Router Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Output Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Input Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:03:25 --> Language Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Loader Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Controller Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:03:25 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:03:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:03:25 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:03:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:03:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:03:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:03:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:03:25 --> Final output sent to browser
DEBUG - 2011-06-06 16:03:25 --> Total execution time: 0.1542
DEBUG - 2011-06-06 16:03:36 --> Config Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:03:36 --> URI Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Router Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Output Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Input Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:03:36 --> Language Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Loader Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Controller Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:03:36 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:03:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:03:36 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:03:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:03:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:03:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:03:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:03:36 --> Final output sent to browser
DEBUG - 2011-06-06 16:03:36 --> Total execution time: 0.4075
DEBUG - 2011-06-06 16:03:38 --> Config Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:03:38 --> URI Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Router Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Output Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Input Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:03:38 --> Language Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Loader Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Controller Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Model Class Initialized
DEBUG - 2011-06-06 16:03:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:03:38 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:03:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:03:38 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:03:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:03:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:03:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:03:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:03:38 --> Final output sent to browser
DEBUG - 2011-06-06 16:03:38 --> Total execution time: 0.0787
DEBUG - 2011-06-06 16:54:44 --> Config Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:54:44 --> URI Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Router Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Output Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Input Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:54:44 --> Language Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Loader Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Controller Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Model Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Model Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Model Class Initialized
DEBUG - 2011-06-06 16:54:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:54:44 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:54:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:54:45 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:54:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:54:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:54:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:54:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:54:45 --> Final output sent to browser
DEBUG - 2011-06-06 16:54:45 --> Total execution time: 1.2143
DEBUG - 2011-06-06 16:54:46 --> Config Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:54:46 --> URI Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Router Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Output Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Input Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:54:46 --> Language Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Loader Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Controller Class Initialized
ERROR - 2011-06-06 16:54:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 16:54:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 16:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 16:54:46 --> Model Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Model Class Initialized
DEBUG - 2011-06-06 16:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:54:46 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 16:54:46 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:54:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:54:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:54:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:54:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:54:46 --> Final output sent to browser
DEBUG - 2011-06-06 16:54:46 --> Total execution time: 0.0852
DEBUG - 2011-06-06 16:56:42 --> Config Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:56:42 --> URI Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Router Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Output Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Input Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:56:42 --> Language Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Loader Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Controller Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:56:42 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:56:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:56:43 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:56:43 --> Final output sent to browser
DEBUG - 2011-06-06 16:56:43 --> Total execution time: 0.1101
DEBUG - 2011-06-06 16:56:47 --> Config Class Initialized
DEBUG - 2011-06-06 16:56:47 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:56:47 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:56:47 --> URI Class Initialized
DEBUG - 2011-06-06 16:56:47 --> Router Class Initialized
ERROR - 2011-06-06 16:56:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 16:56:48 --> Config Class Initialized
DEBUG - 2011-06-06 16:56:48 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:56:48 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:56:48 --> URI Class Initialized
DEBUG - 2011-06-06 16:56:48 --> Router Class Initialized
ERROR - 2011-06-06 16:56:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 16:56:53 --> Config Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:56:53 --> URI Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Router Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Output Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Input Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:56:53 --> Language Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Loader Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Controller Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:56:53 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:56:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:56:53 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:56:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:56:53 --> Final output sent to browser
DEBUG - 2011-06-06 16:56:53 --> Total execution time: 0.2006
DEBUG - 2011-06-06 16:56:54 --> Config Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:56:54 --> URI Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Router Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Output Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Input Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:56:54 --> Language Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Loader Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Controller Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Model Class Initialized
DEBUG - 2011-06-06 16:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:56:54 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:56:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:56:54 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:56:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:56:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:56:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:56:54 --> Final output sent to browser
DEBUG - 2011-06-06 16:56:54 --> Total execution time: 0.0493
DEBUG - 2011-06-06 16:57:00 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:00 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:00 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:00 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:00 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:00 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:00 --> Total execution time: 0.2090
DEBUG - 2011-06-06 16:57:01 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:01 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:01 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:01 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:02 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:02 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:02 --> Total execution time: 0.0794
DEBUG - 2011-06-06 16:57:02 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:02 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:02 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:02 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:02 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:02 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:02 --> Total execution time: 0.0477
DEBUG - 2011-06-06 16:57:02 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:02 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:02 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:02 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:02 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:02 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:02 --> Total execution time: 0.0516
DEBUG - 2011-06-06 16:57:08 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:08 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:08 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:08 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:08 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:08 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:08 --> Total execution time: 0.2139
DEBUG - 2011-06-06 16:57:09 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:09 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:09 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:09 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:09 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:09 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:09 --> Total execution time: 0.0460
DEBUG - 2011-06-06 16:57:15 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:15 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:15 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:15 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:16 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:16 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:16 --> Total execution time: 0.4283
DEBUG - 2011-06-06 16:57:23 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:23 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:23 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:23 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:23 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:23 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:23 --> Total execution time: 0.2197
DEBUG - 2011-06-06 16:57:35 --> Config Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:57:35 --> URI Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Router Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Output Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Input Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:57:35 --> Language Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Loader Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Controller Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Model Class Initialized
DEBUG - 2011-06-06 16:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:57:35 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:57:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:57:35 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:57:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:57:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:57:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:57:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:57:35 --> Final output sent to browser
DEBUG - 2011-06-06 16:57:35 --> Total execution time: 0.2723
DEBUG - 2011-06-06 16:58:04 --> Config Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:58:04 --> URI Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Router Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Output Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Input Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:58:04 --> Language Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Loader Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Controller Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Model Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Model Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Model Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:58:04 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:58:04 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:58:04 --> Final output sent to browser
DEBUG - 2011-06-06 16:58:04 --> Total execution time: 0.0522
DEBUG - 2011-06-06 16:58:04 --> Config Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Hooks Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Utf8 Class Initialized
DEBUG - 2011-06-06 16:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 16:58:04 --> URI Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Router Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Output Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Input Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 16:58:04 --> Language Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Loader Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Controller Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Model Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Model Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Model Class Initialized
DEBUG - 2011-06-06 16:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 16:58:04 --> Database Driver Class Initialized
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 16:58:04 --> Helper loaded: url_helper
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 16:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 16:58:04 --> Final output sent to browser
DEBUG - 2011-06-06 16:58:04 --> Total execution time: 0.0500
DEBUG - 2011-06-06 20:23:35 --> Config Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Hooks Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Utf8 Class Initialized
DEBUG - 2011-06-06 20:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 20:23:35 --> URI Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Router Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Output Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Input Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 20:23:35 --> Language Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Loader Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Controller Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Model Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Model Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Model Class Initialized
DEBUG - 2011-06-06 20:23:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 20:23:35 --> Database Driver Class Initialized
DEBUG - 2011-06-06 20:23:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 20:23:35 --> Helper loaded: url_helper
DEBUG - 2011-06-06 20:23:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 20:23:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 20:23:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 20:23:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 20:23:35 --> Final output sent to browser
DEBUG - 2011-06-06 20:23:35 --> Total execution time: 0.6135
DEBUG - 2011-06-06 20:23:40 --> Config Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Hooks Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Utf8 Class Initialized
DEBUG - 2011-06-06 20:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 20:23:40 --> URI Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Router Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Output Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Input Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 20:23:40 --> Language Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Loader Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Controller Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Model Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Model Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Model Class Initialized
DEBUG - 2011-06-06 20:23:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 20:23:40 --> Database Driver Class Initialized
DEBUG - 2011-06-06 20:23:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-06 20:23:40 --> Helper loaded: url_helper
DEBUG - 2011-06-06 20:23:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 20:23:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 20:23:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 20:23:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 20:23:40 --> Final output sent to browser
DEBUG - 2011-06-06 20:23:40 --> Total execution time: 0.3106
DEBUG - 2011-06-06 21:04:16 --> Config Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Hooks Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Utf8 Class Initialized
DEBUG - 2011-06-06 21:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 21:04:16 --> URI Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Router Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Output Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Input Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 21:04:16 --> Language Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Loader Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Controller Class Initialized
ERROR - 2011-06-06 21:04:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 21:04:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 21:04:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 21:04:16 --> Model Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Model Class Initialized
DEBUG - 2011-06-06 21:04:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 21:04:16 --> Database Driver Class Initialized
DEBUG - 2011-06-06 21:04:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 21:04:16 --> Helper loaded: url_helper
DEBUG - 2011-06-06 21:04:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 21:04:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 21:04:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 21:04:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 21:04:16 --> Final output sent to browser
DEBUG - 2011-06-06 21:04:16 --> Total execution time: 0.2352
DEBUG - 2011-06-06 21:04:18 --> Config Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Hooks Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Utf8 Class Initialized
DEBUG - 2011-06-06 21:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 21:04:18 --> URI Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Router Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Output Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Input Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 21:04:18 --> Language Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Loader Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Controller Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Model Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Model Class Initialized
DEBUG - 2011-06-06 21:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 21:04:18 --> Database Driver Class Initialized
DEBUG - 2011-06-06 21:04:19 --> Final output sent to browser
DEBUG - 2011-06-06 21:04:19 --> Total execution time: 0.7022
DEBUG - 2011-06-06 21:04:19 --> Config Class Initialized
DEBUG - 2011-06-06 21:04:19 --> Hooks Class Initialized
DEBUG - 2011-06-06 21:04:19 --> Utf8 Class Initialized
DEBUG - 2011-06-06 21:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 21:04:19 --> URI Class Initialized
DEBUG - 2011-06-06 21:04:19 --> Router Class Initialized
ERROR - 2011-06-06 21:04:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 21:04:20 --> Config Class Initialized
DEBUG - 2011-06-06 21:04:20 --> Hooks Class Initialized
DEBUG - 2011-06-06 21:04:20 --> Utf8 Class Initialized
DEBUG - 2011-06-06 21:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 21:04:20 --> URI Class Initialized
DEBUG - 2011-06-06 21:04:20 --> Router Class Initialized
ERROR - 2011-06-06 21:04:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-06 21:39:17 --> Config Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Hooks Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Utf8 Class Initialized
DEBUG - 2011-06-06 21:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 21:39:17 --> URI Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Router Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Output Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Input Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 21:39:17 --> Language Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Loader Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Controller Class Initialized
ERROR - 2011-06-06 21:39:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-06 21:39:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-06 21:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 21:39:17 --> Model Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Model Class Initialized
DEBUG - 2011-06-06 21:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 21:39:17 --> Database Driver Class Initialized
DEBUG - 2011-06-06 21:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-06 21:39:17 --> Helper loaded: url_helper
DEBUG - 2011-06-06 21:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 21:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 21:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 21:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 21:39:17 --> Final output sent to browser
DEBUG - 2011-06-06 21:39:17 --> Total execution time: 0.3491
DEBUG - 2011-06-06 22:31:25 --> Config Class Initialized
DEBUG - 2011-06-06 22:31:25 --> Hooks Class Initialized
DEBUG - 2011-06-06 22:31:25 --> Utf8 Class Initialized
DEBUG - 2011-06-06 22:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 22:31:25 --> URI Class Initialized
DEBUG - 2011-06-06 22:31:25 --> Router Class Initialized
DEBUG - 2011-06-06 22:31:25 --> No URI present. Default controller set.
DEBUG - 2011-06-06 22:31:25 --> Output Class Initialized
DEBUG - 2011-06-06 22:31:25 --> Input Class Initialized
DEBUG - 2011-06-06 22:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 22:31:25 --> Language Class Initialized
DEBUG - 2011-06-06 22:31:25 --> Loader Class Initialized
DEBUG - 2011-06-06 22:31:25 --> Controller Class Initialized
DEBUG - 2011-06-06 22:31:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-06 22:31:25 --> Helper loaded: url_helper
DEBUG - 2011-06-06 22:31:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-06 22:31:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-06 22:31:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-06 22:31:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-06 22:31:25 --> Final output sent to browser
DEBUG - 2011-06-06 22:31:25 --> Total execution time: 0.2830
DEBUG - 2011-06-06 22:58:10 --> Config Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Hooks Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Utf8 Class Initialized
DEBUG - 2011-06-06 22:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-06 22:58:10 --> URI Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Router Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Output Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Input Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-06 22:58:10 --> Language Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Loader Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Controller Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Model Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Model Class Initialized
DEBUG - 2011-06-06 22:58:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-06 22:58:10 --> Database Driver Class Initialized
DEBUG - 2011-06-06 22:58:11 --> Final output sent to browser
DEBUG - 2011-06-06 22:58:11 --> Total execution time: 0.7803

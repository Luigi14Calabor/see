<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-19 00:35:01 --> Config Class Initialized
DEBUG - 2011-04-19 00:35:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 00:35:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 00:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 00:35:01 --> URI Class Initialized
DEBUG - 2011-04-19 00:35:02 --> Router Class Initialized
ERROR - 2011-04-19 00:35:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 01:41:14 --> Config Class Initialized
DEBUG - 2011-04-19 01:41:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 01:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 01:41:15 --> URI Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Router Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Output Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Input Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 01:41:15 --> Language Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Loader Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Controller Class Initialized
ERROR - 2011-04-19 01:41:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 01:41:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 01:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 01:41:15 --> Model Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Model Class Initialized
DEBUG - 2011-04-19 01:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 01:41:15 --> Database Driver Class Initialized
DEBUG - 2011-04-19 01:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 01:41:15 --> Helper loaded: url_helper
DEBUG - 2011-04-19 01:41:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 01:41:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 01:41:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 01:41:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 01:41:15 --> Final output sent to browser
DEBUG - 2011-04-19 01:41:15 --> Total execution time: 1.1998
DEBUG - 2011-04-19 01:41:16 --> Config Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 01:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 01:41:16 --> URI Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Router Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Output Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Input Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 01:41:16 --> Language Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Loader Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Controller Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Model Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Model Class Initialized
DEBUG - 2011-04-19 01:41:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 01:41:16 --> Database Driver Class Initialized
DEBUG - 2011-04-19 01:41:17 --> Final output sent to browser
DEBUG - 2011-04-19 01:41:17 --> Total execution time: 1.0228
DEBUG - 2011-04-19 01:41:18 --> Config Class Initialized
DEBUG - 2011-04-19 01:41:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 01:41:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 01:41:18 --> URI Class Initialized
DEBUG - 2011-04-19 01:41:18 --> Router Class Initialized
ERROR - 2011-04-19 01:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 01:41:19 --> Config Class Initialized
DEBUG - 2011-04-19 01:41:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 01:41:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 01:41:19 --> URI Class Initialized
DEBUG - 2011-04-19 01:41:19 --> Router Class Initialized
ERROR - 2011-04-19 01:41:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:19:58 --> Config Class Initialized
DEBUG - 2011-04-19 02:19:58 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:19:59 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:19:59 --> URI Class Initialized
DEBUG - 2011-04-19 02:19:59 --> Router Class Initialized
DEBUG - 2011-04-19 02:20:00 --> Output Class Initialized
DEBUG - 2011-04-19 02:20:00 --> Input Class Initialized
DEBUG - 2011-04-19 02:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:20:00 --> Language Class Initialized
DEBUG - 2011-04-19 02:20:01 --> Loader Class Initialized
DEBUG - 2011-04-19 02:20:02 --> Controller Class Initialized
DEBUG - 2011-04-19 02:20:02 --> Model Class Initialized
DEBUG - 2011-04-19 02:20:02 --> Model Class Initialized
DEBUG - 2011-04-19 02:20:02 --> Model Class Initialized
DEBUG - 2011-04-19 02:20:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:20:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:20:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 02:20:24 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:20:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:20:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:20:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:20:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:20:24 --> Final output sent to browser
DEBUG - 2011-04-19 02:20:24 --> Total execution time: 26.9718
DEBUG - 2011-04-19 02:20:34 --> Config Class Initialized
DEBUG - 2011-04-19 02:20:34 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:20:34 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:20:34 --> URI Class Initialized
DEBUG - 2011-04-19 02:20:34 --> Router Class Initialized
DEBUG - 2011-04-19 02:20:35 --> Output Class Initialized
DEBUG - 2011-04-19 02:20:35 --> Input Class Initialized
DEBUG - 2011-04-19 02:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:20:35 --> Language Class Initialized
DEBUG - 2011-04-19 02:20:35 --> Loader Class Initialized
DEBUG - 2011-04-19 02:20:35 --> Controller Class Initialized
ERROR - 2011-04-19 02:20:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:20:40 --> Model Class Initialized
DEBUG - 2011-04-19 02:20:40 --> Model Class Initialized
DEBUG - 2011-04-19 02:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:20:40 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:20:40 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:20:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:20:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:20:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:20:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:20:40 --> Final output sent to browser
DEBUG - 2011-04-19 02:20:40 --> Total execution time: 6.8712
DEBUG - 2011-04-19 02:47:32 --> Config Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:47:32 --> URI Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Router Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Output Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Input Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:47:32 --> Language Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Loader Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Controller Class Initialized
ERROR - 2011-04-19 02:47:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:47:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:47:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:47:32 --> Model Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Model Class Initialized
DEBUG - 2011-04-19 02:47:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:47:32 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:47:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:47:32 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:47:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:47:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:47:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:47:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:47:32 --> Final output sent to browser
DEBUG - 2011-04-19 02:47:32 --> Total execution time: 0.4788
DEBUG - 2011-04-19 02:47:34 --> Config Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:47:34 --> URI Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Router Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Output Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Input Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:47:34 --> Language Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Loader Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Controller Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Model Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Model Class Initialized
DEBUG - 2011-04-19 02:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:47:34 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:47:37 --> Final output sent to browser
DEBUG - 2011-04-19 02:47:37 --> Total execution time: 2.6132
DEBUG - 2011-04-19 02:47:39 --> Config Class Initialized
DEBUG - 2011-04-19 02:47:39 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:47:39 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:47:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:47:39 --> URI Class Initialized
DEBUG - 2011-04-19 02:47:39 --> Router Class Initialized
ERROR - 2011-04-19 02:47:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:47:43 --> Config Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:47:43 --> URI Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Router Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Output Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Input Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:47:43 --> Language Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Loader Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Controller Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Model Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Model Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Model Class Initialized
DEBUG - 2011-04-19 02:47:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:47:43 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:47:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 02:47:55 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:47:55 --> Final output sent to browser
DEBUG - 2011-04-19 02:47:55 --> Total execution time: 12.0059
DEBUG - 2011-04-19 02:47:57 --> Config Class Initialized
DEBUG - 2011-04-19 02:47:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:47:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:47:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:47:57 --> URI Class Initialized
DEBUG - 2011-04-19 02:47:57 --> Router Class Initialized
ERROR - 2011-04-19 02:47:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:48:47 --> Config Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:48:47 --> URI Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Router Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Output Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Input Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:48:47 --> Language Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Loader Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Controller Class Initialized
ERROR - 2011-04-19 02:48:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:48:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:48:47 --> Model Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Model Class Initialized
DEBUG - 2011-04-19 02:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:48:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:48:47 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:48:47 --> Final output sent to browser
DEBUG - 2011-04-19 02:48:47 --> Total execution time: 0.0371
DEBUG - 2011-04-19 02:48:48 --> Config Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:48:48 --> URI Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Router Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Output Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Input Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:48:48 --> Language Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Loader Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Controller Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Model Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Model Class Initialized
DEBUG - 2011-04-19 02:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:48:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:48:49 --> Final output sent to browser
DEBUG - 2011-04-19 02:48:49 --> Total execution time: 1.2384
DEBUG - 2011-04-19 02:48:52 --> Config Class Initialized
DEBUG - 2011-04-19 02:48:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:48:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:48:52 --> URI Class Initialized
DEBUG - 2011-04-19 02:48:52 --> Router Class Initialized
ERROR - 2011-04-19 02:48:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:49:28 --> Config Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:49:28 --> URI Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Router Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Output Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Input Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:49:28 --> Language Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Loader Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Controller Class Initialized
ERROR - 2011-04-19 02:49:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:49:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:49:28 --> Model Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Model Class Initialized
DEBUG - 2011-04-19 02:49:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:49:28 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:49:28 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:49:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:49:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:49:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:49:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:49:28 --> Final output sent to browser
DEBUG - 2011-04-19 02:49:28 --> Total execution time: 0.0327
DEBUG - 2011-04-19 02:49:30 --> Config Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:49:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:49:30 --> URI Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Router Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Output Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Input Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:49:30 --> Language Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Loader Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Controller Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Model Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Model Class Initialized
DEBUG - 2011-04-19 02:49:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:49:30 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:49:31 --> Final output sent to browser
DEBUG - 2011-04-19 02:49:31 --> Total execution time: 1.3625
DEBUG - 2011-04-19 02:49:34 --> Config Class Initialized
DEBUG - 2011-04-19 02:49:34 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:49:34 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:49:34 --> URI Class Initialized
DEBUG - 2011-04-19 02:49:34 --> Router Class Initialized
ERROR - 2011-04-19 02:49:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:50:09 --> Config Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:50:09 --> URI Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Router Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Output Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Input Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:50:09 --> Language Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Loader Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Controller Class Initialized
ERROR - 2011-04-19 02:50:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:50:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:50:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:50:09 --> Model Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Model Class Initialized
DEBUG - 2011-04-19 02:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:50:09 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:50:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:50:09 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:50:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:50:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:50:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:50:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:50:09 --> Final output sent to browser
DEBUG - 2011-04-19 02:50:09 --> Total execution time: 0.0480
DEBUG - 2011-04-19 02:50:10 --> Config Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:50:10 --> URI Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Router Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Output Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Input Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:50:10 --> Language Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Loader Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Controller Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Model Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Model Class Initialized
DEBUG - 2011-04-19 02:50:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:50:10 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:50:25 --> Final output sent to browser
DEBUG - 2011-04-19 02:50:25 --> Total execution time: 15.1003
DEBUG - 2011-04-19 02:50:28 --> Config Class Initialized
DEBUG - 2011-04-19 02:50:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:50:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:50:28 --> URI Class Initialized
DEBUG - 2011-04-19 02:50:28 --> Router Class Initialized
ERROR - 2011-04-19 02:50:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:51:10 --> Config Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:51:10 --> URI Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Router Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Output Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Input Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:51:10 --> Language Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Loader Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Controller Class Initialized
ERROR - 2011-04-19 02:51:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:51:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:51:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:51:10 --> Model Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Model Class Initialized
DEBUG - 2011-04-19 02:51:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:51:10 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:51:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:51:10 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:51:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:51:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:51:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:51:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:51:10 --> Final output sent to browser
DEBUG - 2011-04-19 02:51:10 --> Total execution time: 0.0346
DEBUG - 2011-04-19 02:51:12 --> Config Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:51:12 --> URI Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Router Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Output Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Input Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:51:12 --> Language Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Loader Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Controller Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Model Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Model Class Initialized
DEBUG - 2011-04-19 02:51:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:51:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:51:15 --> Final output sent to browser
DEBUG - 2011-04-19 02:51:15 --> Total execution time: 2.7218
DEBUG - 2011-04-19 02:51:19 --> Config Class Initialized
DEBUG - 2011-04-19 02:51:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:51:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:51:19 --> URI Class Initialized
DEBUG - 2011-04-19 02:51:19 --> Router Class Initialized
ERROR - 2011-04-19 02:51:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:52:21 --> Config Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:52:21 --> URI Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Router Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Output Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Input Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:52:21 --> Language Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Loader Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Controller Class Initialized
ERROR - 2011-04-19 02:52:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:52:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:52:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:52:21 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:52:21 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:52:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:52:21 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:52:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:52:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:52:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:52:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:52:21 --> Final output sent to browser
DEBUG - 2011-04-19 02:52:21 --> Total execution time: 0.0440
DEBUG - 2011-04-19 02:52:22 --> Config Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:52:22 --> URI Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Router Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Output Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Input Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:52:22 --> Language Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Loader Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Controller Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:52:22 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:52:23 --> Final output sent to browser
DEBUG - 2011-04-19 02:52:23 --> Total execution time: 1.2924
DEBUG - 2011-04-19 02:52:44 --> Config Class Initialized
DEBUG - 2011-04-19 02:52:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:52:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:52:44 --> URI Class Initialized
DEBUG - 2011-04-19 02:52:44 --> Router Class Initialized
ERROR - 2011-04-19 02:52:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:52:54 --> Config Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:52:54 --> URI Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Router Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Output Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Input Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:52:54 --> Language Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Loader Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Controller Class Initialized
ERROR - 2011-04-19 02:52:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:52:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:52:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:52:54 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:52:54 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:52:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:52:54 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:52:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:52:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:52:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:52:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:52:54 --> Final output sent to browser
DEBUG - 2011-04-19 02:52:54 --> Total execution time: 0.0348
DEBUG - 2011-04-19 02:52:55 --> Config Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:52:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:52:55 --> URI Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Router Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Output Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Input Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:52:55 --> Language Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Loader Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Controller Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:52:55 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:52:55 --> Final output sent to browser
DEBUG - 2011-04-19 02:52:55 --> Total execution time: 0.8105
DEBUG - 2011-04-19 02:52:57 --> Config Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:52:57 --> URI Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Router Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Output Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Input Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:52:57 --> Language Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Loader Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Controller Class Initialized
ERROR - 2011-04-19 02:52:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:52:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:52:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:52:57 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Model Class Initialized
DEBUG - 2011-04-19 02:52:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:52:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:52:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:52:58 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:52:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:52:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:52:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:52:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:52:58 --> Final output sent to browser
DEBUG - 2011-04-19 02:52:58 --> Total execution time: 0.0283
DEBUG - 2011-04-19 02:53:01 --> Config Class Initialized
DEBUG - 2011-04-19 02:53:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:53:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:53:01 --> URI Class Initialized
DEBUG - 2011-04-19 02:53:01 --> Router Class Initialized
ERROR - 2011-04-19 02:53:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:53:11 --> Config Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:53:11 --> URI Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Router Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Output Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Input Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:53:11 --> Language Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Loader Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Controller Class Initialized
ERROR - 2011-04-19 02:53:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:53:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:53:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:53:11 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:53:11 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:53:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:53:11 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:53:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:53:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:53:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:53:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:53:11 --> Final output sent to browser
DEBUG - 2011-04-19 02:53:11 --> Total execution time: 0.0821
DEBUG - 2011-04-19 02:53:13 --> Config Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:53:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:53:13 --> URI Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Router Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Output Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Input Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:53:13 --> Language Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Loader Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Controller Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:53:13 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:53:15 --> Final output sent to browser
DEBUG - 2011-04-19 02:53:15 --> Total execution time: 2.1153
DEBUG - 2011-04-19 02:53:19 --> Config Class Initialized
DEBUG - 2011-04-19 02:53:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:53:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:53:19 --> URI Class Initialized
DEBUG - 2011-04-19 02:53:19 --> Router Class Initialized
ERROR - 2011-04-19 02:53:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:53:47 --> Config Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:53:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:53:47 --> URI Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Router Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Output Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Input Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:53:47 --> Language Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Loader Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Controller Class Initialized
ERROR - 2011-04-19 02:53:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:53:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:53:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:53:47 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:53:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:53:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:53:47 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:53:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:53:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:53:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:53:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:53:47 --> Final output sent to browser
DEBUG - 2011-04-19 02:53:47 --> Total execution time: 0.1006
DEBUG - 2011-04-19 02:53:49 --> Config Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:53:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:53:49 --> URI Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Router Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Output Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Input Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:53:49 --> Language Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Loader Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Controller Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:53:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:53:49 --> Final output sent to browser
DEBUG - 2011-04-19 02:53:49 --> Total execution time: 0.7538
DEBUG - 2011-04-19 02:53:52 --> Config Class Initialized
DEBUG - 2011-04-19 02:53:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:53:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:53:52 --> URI Class Initialized
DEBUG - 2011-04-19 02:53:52 --> Router Class Initialized
ERROR - 2011-04-19 02:53:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:53:57 --> Config Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:53:57 --> URI Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Router Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Output Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Input Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:53:57 --> Language Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Loader Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Controller Class Initialized
ERROR - 2011-04-19 02:53:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:53:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:53:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:53:57 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Model Class Initialized
DEBUG - 2011-04-19 02:53:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:53:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:53:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:53:57 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:53:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:53:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:53:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:53:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:53:57 --> Final output sent to browser
DEBUG - 2011-04-19 02:53:57 --> Total execution time: 0.0310
DEBUG - 2011-04-19 02:54:04 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:04 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:04 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Controller Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:04 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:05 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:05 --> Total execution time: 0.7166
DEBUG - 2011-04-19 02:54:09 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:09 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:09 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:09 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:09 --> Router Class Initialized
ERROR - 2011-04-19 02:54:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:54:12 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:12 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:12 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Controller Class Initialized
ERROR - 2011-04-19 02:54:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:12 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:12 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:54:12 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:12 --> Total execution time: 0.0291
DEBUG - 2011-04-19 02:54:13 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:13 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:13 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Controller Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:13 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:13 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:13 --> Total execution time: 0.5072
DEBUG - 2011-04-19 02:54:16 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:16 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:16 --> Router Class Initialized
ERROR - 2011-04-19 02:54:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:54:35 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:35 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:35 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Controller Class Initialized
ERROR - 2011-04-19 02:54:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:54:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:54:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:35 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:35 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:54:35 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:35 --> Total execution time: 0.0303
DEBUG - 2011-04-19 02:54:37 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:37 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:37 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Controller Class Initialized
ERROR - 2011-04-19 02:54:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:54:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:54:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:37 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:37 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:37 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:54:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:54:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:54:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:54:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:54:37 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:37 --> Total execution time: 0.0296
DEBUG - 2011-04-19 02:54:37 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:37 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:37 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Controller Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:37 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:38 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:38 --> Total execution time: 0.5488
DEBUG - 2011-04-19 02:54:41 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:41 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:41 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:41 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:41 --> Router Class Initialized
ERROR - 2011-04-19 02:54:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:54:45 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:45 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:45 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Controller Class Initialized
ERROR - 2011-04-19 02:54:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:54:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:54:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:45 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:45 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:45 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:54:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:54:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:54:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:54:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:54:45 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:45 --> Total execution time: 0.1065
DEBUG - 2011-04-19 02:54:48 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:48 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:48 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Controller Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:49 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:49 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Controller Class Initialized
ERROR - 2011-04-19 02:54:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:54:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:54:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:49 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:49 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:54:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:54:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:54:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:54:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:54:49 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:49 --> Total execution time: 0.0288
DEBUG - 2011-04-19 02:54:50 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:50 --> Total execution time: 2.0119
DEBUG - 2011-04-19 02:54:55 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:55 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:55 --> Router Class Initialized
ERROR - 2011-04-19 02:54:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:54:56 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:56 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:56 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Controller Class Initialized
ERROR - 2011-04-19 02:54:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:54:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:56 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:56 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:56 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:54:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:54:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:54:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:54:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:54:56 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:56 --> Total execution time: 0.0297
DEBUG - 2011-04-19 02:54:57 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:57 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:57 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Controller Class Initialized
ERROR - 2011-04-19 02:54:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:54:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:54:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:57 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:54:57 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:54:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:54:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:54:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:54:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:54:57 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:57 --> Total execution time: 0.0303
DEBUG - 2011-04-19 02:54:57 --> Config Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:54:57 --> URI Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Router Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Output Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Input Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:54:57 --> Language Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Loader Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Controller Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Model Class Initialized
DEBUG - 2011-04-19 02:54:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:54:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:54:58 --> Final output sent to browser
DEBUG - 2011-04-19 02:54:58 --> Total execution time: 0.7385
DEBUG - 2011-04-19 02:55:01 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:01 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:01 --> Router Class Initialized
ERROR - 2011-04-19 02:55:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:55:04 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:04 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:04 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Controller Class Initialized
ERROR - 2011-04-19 02:55:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:55:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:04 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:04 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:04 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:55:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:55:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:55:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:55:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:55:04 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:04 --> Total execution time: 0.1311
DEBUG - 2011-04-19 02:55:05 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:05 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:05 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Controller Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:05 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:06 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:06 --> Total execution time: 1.1457
DEBUG - 2011-04-19 02:55:07 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:07 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:07 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Controller Class Initialized
ERROR - 2011-04-19 02:55:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:55:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:55:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:07 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:07 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:07 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:55:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:55:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:55:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:55:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:55:07 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:07 --> Total execution time: 0.0312
DEBUG - 2011-04-19 02:55:13 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:13 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:13 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Controller Class Initialized
ERROR - 2011-04-19 02:55:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:55:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:55:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:13 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:13 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:13 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:13 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:13 --> File loaded: application/views/snakes/main.php
ERROR - 2011-04-19 02:55:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:55:13 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:55:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:55:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:55:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:55:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:55:13 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:13 --> Total execution time: 0.0286
DEBUG - 2011-04-19 02:55:15 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:19 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:19 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Controller Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:19 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:21 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:21 --> Total execution time: 6.6875
DEBUG - 2011-04-19 02:55:24 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:24 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:24 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:24 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:24 --> Router Class Initialized
ERROR - 2011-04-19 02:55:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:55:30 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:30 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:30 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Controller Class Initialized
ERROR - 2011-04-19 02:55:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:55:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:55:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:30 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:30 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:30 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:55:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:55:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:55:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:55:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:55:30 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:30 --> Total execution time: 0.0323
DEBUG - 2011-04-19 02:55:31 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:31 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:31 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Controller Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:31 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:31 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:31 --> Total execution time: 0.5647
DEBUG - 2011-04-19 02:55:34 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:34 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:34 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:34 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:34 --> Router Class Initialized
ERROR - 2011-04-19 02:55:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:55:45 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:45 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:45 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Controller Class Initialized
ERROR - 2011-04-19 02:55:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:55:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:45 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:45 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:55:45 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:55:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:55:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:55:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:55:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:55:45 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:45 --> Total execution time: 0.0325
DEBUG - 2011-04-19 02:55:46 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:46 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Router Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Output Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Input Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:55:46 --> Language Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Loader Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Controller Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Model Class Initialized
DEBUG - 2011-04-19 02:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:55:46 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:55:47 --> Final output sent to browser
DEBUG - 2011-04-19 02:55:47 --> Total execution time: 0.5035
DEBUG - 2011-04-19 02:55:51 --> Config Class Initialized
DEBUG - 2011-04-19 02:55:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:55:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:55:51 --> URI Class Initialized
DEBUG - 2011-04-19 02:55:51 --> Router Class Initialized
ERROR - 2011-04-19 02:55:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:56:02 --> Config Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:56:02 --> URI Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Router Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Output Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Input Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:56:02 --> Language Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Loader Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Controller Class Initialized
ERROR - 2011-04-19 02:56:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:56:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:56:02 --> Model Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Model Class Initialized
DEBUG - 2011-04-19 02:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:56:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:56:02 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:56:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:56:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:56:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:56:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:56:02 --> Final output sent to browser
DEBUG - 2011-04-19 02:56:02 --> Total execution time: 0.0305
DEBUG - 2011-04-19 02:56:03 --> Config Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:56:03 --> URI Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Router Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Output Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Input Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:56:03 --> Language Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Loader Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Controller Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Model Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Model Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:56:03 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:56:03 --> Final output sent to browser
DEBUG - 2011-04-19 02:56:03 --> Total execution time: 0.4521
DEBUG - 2011-04-19 02:56:06 --> Config Class Initialized
DEBUG - 2011-04-19 02:56:06 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:56:06 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:56:06 --> URI Class Initialized
DEBUG - 2011-04-19 02:56:06 --> Router Class Initialized
ERROR - 2011-04-19 02:56:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:56:44 --> Config Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:56:44 --> URI Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Router Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Output Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Input Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:56:44 --> Language Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Loader Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Controller Class Initialized
ERROR - 2011-04-19 02:56:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:56:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:56:44 --> Model Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Model Class Initialized
DEBUG - 2011-04-19 02:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:56:44 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:56:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:56:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:56:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:56:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:56:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:56:44 --> Final output sent to browser
DEBUG - 2011-04-19 02:56:44 --> Total execution time: 0.0662
DEBUG - 2011-04-19 02:56:45 --> Config Class Initialized
DEBUG - 2011-04-19 02:56:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:56:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:56:46 --> URI Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Router Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Output Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Input Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:56:46 --> Language Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Loader Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Controller Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Model Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Model Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:56:46 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:56:46 --> Final output sent to browser
DEBUG - 2011-04-19 02:56:46 --> Total execution time: 0.5955
DEBUG - 2011-04-19 02:56:49 --> Config Class Initialized
DEBUG - 2011-04-19 02:56:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:56:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:56:49 --> URI Class Initialized
DEBUG - 2011-04-19 02:56:49 --> Router Class Initialized
ERROR - 2011-04-19 02:56:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:57:06 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:06 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Router Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Output Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Input Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:57:06 --> Language Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Loader Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Controller Class Initialized
ERROR - 2011-04-19 02:57:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:57:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:57:06 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:57:06 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:57:06 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:57:06 --> Final output sent to browser
DEBUG - 2011-04-19 02:57:06 --> Total execution time: 0.0422
DEBUG - 2011-04-19 02:57:07 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:07 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Router Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Output Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Input Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:57:07 --> Language Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Loader Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Controller Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:57:07 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:57:08 --> Final output sent to browser
DEBUG - 2011-04-19 02:57:08 --> Total execution time: 0.6322
DEBUG - 2011-04-19 02:57:12 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:12 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:12 --> Router Class Initialized
ERROR - 2011-04-19 02:57:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:57:26 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:26 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Router Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Output Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Input Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:57:26 --> Language Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Loader Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Controller Class Initialized
ERROR - 2011-04-19 02:57:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:57:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:57:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:57:26 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:57:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:57:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:57:26 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:57:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:57:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:57:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:57:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:57:26 --> Final output sent to browser
DEBUG - 2011-04-19 02:57:26 --> Total execution time: 0.0312
DEBUG - 2011-04-19 02:57:28 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:28 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Router Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Output Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Input Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:57:28 --> Language Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Loader Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Controller Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:57:28 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:57:28 --> Final output sent to browser
DEBUG - 2011-04-19 02:57:28 --> Total execution time: 0.5814
DEBUG - 2011-04-19 02:57:32 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:32 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:32 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:32 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:32 --> Router Class Initialized
ERROR - 2011-04-19 02:57:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:57:46 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:46 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Router Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Output Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Input Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:57:46 --> Language Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Loader Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Controller Class Initialized
ERROR - 2011-04-19 02:57:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:57:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:57:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:57:46 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:57:46 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:57:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:57:46 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:57:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:57:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:57:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:57:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:57:46 --> Final output sent to browser
DEBUG - 2011-04-19 02:57:46 --> Total execution time: 0.0308
DEBUG - 2011-04-19 02:57:47 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:47 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Router Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Output Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Input Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:57:47 --> Language Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Loader Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Controller Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:57:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:57:48 --> Final output sent to browser
DEBUG - 2011-04-19 02:57:48 --> Total execution time: 1.1281
DEBUG - 2011-04-19 02:57:50 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:50 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:50 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:50 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:50 --> Router Class Initialized
ERROR - 2011-04-19 02:57:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:57:58 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:58 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Router Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Output Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Input Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:57:58 --> Language Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Loader Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Controller Class Initialized
ERROR - 2011-04-19 02:57:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:57:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:57:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:57:58 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:57:58 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:57:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:57:58 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:57:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:57:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:57:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:57:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:57:58 --> Final output sent to browser
DEBUG - 2011-04-19 02:57:58 --> Total execution time: 0.0316
DEBUG - 2011-04-19 02:57:59 --> Config Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:57:59 --> URI Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Router Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Output Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Input Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:57:59 --> Language Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Loader Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Controller Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Model Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:57:59 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:57:59 --> Final output sent to browser
DEBUG - 2011-04-19 02:57:59 --> Total execution time: 0.5962
DEBUG - 2011-04-19 02:58:01 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:01 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:01 --> Router Class Initialized
ERROR - 2011-04-19 02:58:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:58:12 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:12 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Router Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Output Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Input Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:58:12 --> Language Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Loader Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Controller Class Initialized
ERROR - 2011-04-19 02:58:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:58:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:58:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:58:12 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:58:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:58:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:58:12 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:58:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:58:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:58:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:58:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:58:12 --> Final output sent to browser
DEBUG - 2011-04-19 02:58:12 --> Total execution time: 0.0349
DEBUG - 2011-04-19 02:58:14 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:14 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Router Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Output Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Input Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:58:14 --> Language Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Loader Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Controller Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:58:14 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:58:14 --> Final output sent to browser
DEBUG - 2011-04-19 02:58:14 --> Total execution time: 0.5436
DEBUG - 2011-04-19 02:58:16 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:16 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:16 --> Router Class Initialized
ERROR - 2011-04-19 02:58:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:58:26 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:26 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Router Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Output Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Input Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:58:26 --> Language Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Loader Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Controller Class Initialized
ERROR - 2011-04-19 02:58:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:58:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:58:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:58:26 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:58:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:58:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:58:26 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:58:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:58:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:58:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:58:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:58:26 --> Final output sent to browser
DEBUG - 2011-04-19 02:58:26 --> Total execution time: 0.0316
DEBUG - 2011-04-19 02:58:27 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:27 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Router Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Output Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Input Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:58:27 --> Language Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Loader Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Controller Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:58:27 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:58:27 --> Final output sent to browser
DEBUG - 2011-04-19 02:58:27 --> Total execution time: 0.7996
DEBUG - 2011-04-19 02:58:29 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:29 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:29 --> Router Class Initialized
ERROR - 2011-04-19 02:58:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:58:47 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:47 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Router Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Output Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Input Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:58:47 --> Language Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Loader Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Controller Class Initialized
ERROR - 2011-04-19 02:58:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:58:47 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:58:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:58:47 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:58:47 --> Final output sent to browser
DEBUG - 2011-04-19 02:58:47 --> Total execution time: 0.0381
DEBUG - 2011-04-19 02:58:48 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:48 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Router Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Output Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Input Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:58:48 --> Language Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Loader Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Controller Class Initialized
ERROR - 2011-04-19 02:58:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:58:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:58:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:58:48 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:58:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:58:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:58:48 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:58:48 --> Final output sent to browser
DEBUG - 2011-04-19 02:58:48 --> Total execution time: 0.0328
DEBUG - 2011-04-19 02:58:48 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:48 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Router Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Output Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Input Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:58:48 --> Language Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Loader Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Controller Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Model Class Initialized
DEBUG - 2011-04-19 02:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:58:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:58:49 --> Final output sent to browser
DEBUG - 2011-04-19 02:58:49 --> Total execution time: 0.5927
DEBUG - 2011-04-19 02:58:51 --> Config Class Initialized
DEBUG - 2011-04-19 02:58:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:58:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:58:51 --> URI Class Initialized
DEBUG - 2011-04-19 02:58:51 --> Router Class Initialized
ERROR - 2011-04-19 02:58:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:59:00 --> Config Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:59:00 --> URI Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Router Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Output Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Input Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:59:00 --> Language Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Loader Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Controller Class Initialized
ERROR - 2011-04-19 02:59:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:59:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:59:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:59:00 --> Model Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Model Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:59:00 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:59:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:59:00 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:59:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:59:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:59:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:59:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:59:00 --> Final output sent to browser
DEBUG - 2011-04-19 02:59:00 --> Total execution time: 0.0299
DEBUG - 2011-04-19 02:59:00 --> Config Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:59:00 --> URI Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Router Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Output Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Input Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:59:00 --> Language Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Loader Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Controller Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Model Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Model Class Initialized
DEBUG - 2011-04-19 02:59:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:59:00 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:59:01 --> Final output sent to browser
DEBUG - 2011-04-19 02:59:01 --> Total execution time: 0.5119
DEBUG - 2011-04-19 02:59:03 --> Config Class Initialized
DEBUG - 2011-04-19 02:59:03 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:59:03 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:59:03 --> URI Class Initialized
DEBUG - 2011-04-19 02:59:03 --> Router Class Initialized
ERROR - 2011-04-19 02:59:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 02:59:17 --> Config Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:59:17 --> URI Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Router Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Output Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Input Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:59:17 --> Language Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Loader Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Controller Class Initialized
ERROR - 2011-04-19 02:59:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 02:59:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 02:59:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:59:17 --> Model Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Model Class Initialized
DEBUG - 2011-04-19 02:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:59:17 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:59:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 02:59:17 --> Helper loaded: url_helper
DEBUG - 2011-04-19 02:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 02:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 02:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 02:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 02:59:17 --> Final output sent to browser
DEBUG - 2011-04-19 02:59:17 --> Total execution time: 0.0309
DEBUG - 2011-04-19 02:59:18 --> Config Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:59:18 --> URI Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Router Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Output Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Input Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 02:59:18 --> Language Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Loader Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Controller Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Model Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Model Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 02:59:18 --> Database Driver Class Initialized
DEBUG - 2011-04-19 02:59:18 --> Final output sent to browser
DEBUG - 2011-04-19 02:59:18 --> Total execution time: 0.5201
DEBUG - 2011-04-19 02:59:21 --> Config Class Initialized
DEBUG - 2011-04-19 02:59:21 --> Hooks Class Initialized
DEBUG - 2011-04-19 02:59:21 --> Utf8 Class Initialized
DEBUG - 2011-04-19 02:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 02:59:21 --> URI Class Initialized
DEBUG - 2011-04-19 02:59:21 --> Router Class Initialized
ERROR - 2011-04-19 02:59:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 03:38:55 --> Config Class Initialized
DEBUG - 2011-04-19 03:38:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 03:38:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 03:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 03:38:55 --> URI Class Initialized
DEBUG - 2011-04-19 03:38:55 --> Router Class Initialized
DEBUG - 2011-04-19 03:38:55 --> No URI present. Default controller set.
DEBUG - 2011-04-19 03:38:55 --> Output Class Initialized
DEBUG - 2011-04-19 03:38:55 --> Input Class Initialized
DEBUG - 2011-04-19 03:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 03:38:55 --> Language Class Initialized
DEBUG - 2011-04-19 03:38:55 --> Loader Class Initialized
DEBUG - 2011-04-19 03:38:55 --> Controller Class Initialized
DEBUG - 2011-04-19 03:38:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 03:38:55 --> Helper loaded: url_helper
DEBUG - 2011-04-19 03:38:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 03:38:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 03:38:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 03:38:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 03:38:55 --> Final output sent to browser
DEBUG - 2011-04-19 03:38:55 --> Total execution time: 0.4223
DEBUG - 2011-04-19 07:44:02 --> Config Class Initialized
DEBUG - 2011-04-19 07:44:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:44:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:44:02 --> URI Class Initialized
DEBUG - 2011-04-19 07:44:02 --> Router Class Initialized
DEBUG - 2011-04-19 07:44:02 --> No URI present. Default controller set.
DEBUG - 2011-04-19 07:44:02 --> Output Class Initialized
DEBUG - 2011-04-19 07:44:02 --> Input Class Initialized
DEBUG - 2011-04-19 07:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 07:44:02 --> Language Class Initialized
DEBUG - 2011-04-19 07:44:02 --> Loader Class Initialized
DEBUG - 2011-04-19 07:44:02 --> Controller Class Initialized
DEBUG - 2011-04-19 07:44:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 07:44:02 --> Helper loaded: url_helper
DEBUG - 2011-04-19 07:44:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 07:44:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 07:44:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 07:44:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 07:44:02 --> Final output sent to browser
DEBUG - 2011-04-19 07:44:02 --> Total execution time: 0.4229
DEBUG - 2011-04-19 07:44:05 --> Config Class Initialized
DEBUG - 2011-04-19 07:44:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:44:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:44:05 --> URI Class Initialized
DEBUG - 2011-04-19 07:44:05 --> Router Class Initialized
ERROR - 2011-04-19 07:44:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 07:44:36 --> Config Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:44:36 --> URI Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Router Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Output Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Input Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 07:44:36 --> Language Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Loader Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Controller Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Model Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Model Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Model Class Initialized
DEBUG - 2011-04-19 07:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 07:44:37 --> Database Driver Class Initialized
DEBUG - 2011-04-19 07:44:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 07:44:38 --> Helper loaded: url_helper
DEBUG - 2011-04-19 07:44:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 07:44:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 07:44:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 07:44:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 07:44:38 --> Final output sent to browser
DEBUG - 2011-04-19 07:44:38 --> Total execution time: 1.1895
DEBUG - 2011-04-19 07:44:39 --> Config Class Initialized
DEBUG - 2011-04-19 07:44:39 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:44:39 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:44:39 --> URI Class Initialized
DEBUG - 2011-04-19 07:44:39 --> Router Class Initialized
ERROR - 2011-04-19 07:44:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 07:44:51 --> Config Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:44:51 --> URI Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Router Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Output Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Input Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 07:44:51 --> Language Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Loader Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Controller Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Model Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Model Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Model Class Initialized
DEBUG - 2011-04-19 07:44:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 07:44:51 --> Database Driver Class Initialized
DEBUG - 2011-04-19 07:44:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 07:44:52 --> Helper loaded: url_helper
DEBUG - 2011-04-19 07:44:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 07:44:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 07:44:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 07:44:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 07:44:52 --> Final output sent to browser
DEBUG - 2011-04-19 07:44:52 --> Total execution time: 0.1716
DEBUG - 2011-04-19 07:44:53 --> Config Class Initialized
DEBUG - 2011-04-19 07:44:53 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:44:53 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:44:53 --> URI Class Initialized
DEBUG - 2011-04-19 07:44:53 --> Router Class Initialized
ERROR - 2011-04-19 07:44:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 07:45:01 --> Config Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:45:01 --> URI Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Router Class Initialized
ERROR - 2011-04-19 07:45:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 07:45:01 --> Config Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:45:01 --> URI Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Router Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Output Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Input Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 07:45:01 --> Language Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Loader Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Controller Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 07:45:01 --> Database Driver Class Initialized
DEBUG - 2011-04-19 07:45:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 07:45:01 --> Helper loaded: url_helper
DEBUG - 2011-04-19 07:45:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 07:45:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 07:45:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 07:45:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 07:45:01 --> Final output sent to browser
DEBUG - 2011-04-19 07:45:01 --> Total execution time: 0.0606
DEBUG - 2011-04-19 07:45:22 --> Config Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:45:22 --> URI Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Router Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Output Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Input Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 07:45:22 --> Language Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Loader Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Controller Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 07:45:22 --> Database Driver Class Initialized
DEBUG - 2011-04-19 07:45:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 07:45:22 --> Helper loaded: url_helper
DEBUG - 2011-04-19 07:45:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 07:45:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 07:45:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 07:45:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 07:45:22 --> Final output sent to browser
DEBUG - 2011-04-19 07:45:22 --> Total execution time: 0.2241
DEBUG - 2011-04-19 07:45:23 --> Config Class Initialized
DEBUG - 2011-04-19 07:45:23 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:45:23 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:45:23 --> URI Class Initialized
DEBUG - 2011-04-19 07:45:23 --> Router Class Initialized
ERROR - 2011-04-19 07:45:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 07:45:25 --> Config Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 07:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 07:45:25 --> URI Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Router Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Output Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Input Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 07:45:25 --> Language Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Loader Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Controller Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Model Class Initialized
DEBUG - 2011-04-19 07:45:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 07:45:25 --> Database Driver Class Initialized
DEBUG - 2011-04-19 07:45:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 07:45:25 --> Helper loaded: url_helper
DEBUG - 2011-04-19 07:45:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 07:45:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 07:45:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 07:45:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 07:45:25 --> Final output sent to browser
DEBUG - 2011-04-19 07:45:25 --> Total execution time: 0.0446
DEBUG - 2011-04-19 08:58:52 --> Config Class Initialized
DEBUG - 2011-04-19 08:58:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 08:58:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 08:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 08:58:52 --> URI Class Initialized
DEBUG - 2011-04-19 08:58:52 --> Router Class Initialized
DEBUG - 2011-04-19 08:58:52 --> No URI present. Default controller set.
DEBUG - 2011-04-19 08:58:52 --> Output Class Initialized
DEBUG - 2011-04-19 08:58:52 --> Input Class Initialized
DEBUG - 2011-04-19 08:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 08:58:52 --> Language Class Initialized
DEBUG - 2011-04-19 08:58:52 --> Loader Class Initialized
DEBUG - 2011-04-19 08:58:52 --> Controller Class Initialized
DEBUG - 2011-04-19 08:58:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 08:58:52 --> Helper loaded: url_helper
DEBUG - 2011-04-19 08:58:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 08:58:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 08:58:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 08:58:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 08:58:52 --> Final output sent to browser
DEBUG - 2011-04-19 08:58:52 --> Total execution time: 0.2420
DEBUG - 2011-04-19 09:18:05 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:05 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Router Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Output Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Input Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:18:05 --> Language Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Loader Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Controller Class Initialized
ERROR - 2011-04-19 09:18:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:18:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:18:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:18:05 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:18:05 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:18:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:18:05 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:18:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:18:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:18:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:18:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:18:05 --> Final output sent to browser
DEBUG - 2011-04-19 09:18:05 --> Total execution time: 0.2883
DEBUG - 2011-04-19 09:18:06 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:06 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Router Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Output Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Input Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:18:06 --> Language Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Loader Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Controller Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:18:06 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:18:07 --> Final output sent to browser
DEBUG - 2011-04-19 09:18:07 --> Total execution time: 0.7579
DEBUG - 2011-04-19 09:18:08 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:08 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:08 --> Router Class Initialized
ERROR - 2011-04-19 09:18:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 09:18:09 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:09 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:09 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:09 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:09 --> Router Class Initialized
ERROR - 2011-04-19 09:18:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 09:18:16 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:16 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Router Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Output Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Input Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:18:16 --> Language Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Loader Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Controller Class Initialized
ERROR - 2011-04-19 09:18:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:18:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:18:16 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:18:16 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:18:16 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:18:16 --> Final output sent to browser
DEBUG - 2011-04-19 09:18:16 --> Total execution time: 0.0658
DEBUG - 2011-04-19 09:18:17 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:17 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Router Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Output Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Input Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:18:17 --> Language Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Loader Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Controller Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:18:17 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:17 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Router Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Output Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Input Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:18:17 --> Language Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Loader Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Controller Class Initialized
ERROR - 2011-04-19 09:18:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:18:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:18:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:18:17 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:18:17 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:18:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:18:17 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:18:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:18:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:18:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:18:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:18:17 --> Final output sent to browser
DEBUG - 2011-04-19 09:18:17 --> Total execution time: 0.0311
DEBUG - 2011-04-19 09:18:18 --> Final output sent to browser
DEBUG - 2011-04-19 09:18:18 --> Total execution time: 0.9137
DEBUG - 2011-04-19 09:18:33 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:33 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Router Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Output Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Input Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:18:33 --> Language Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Loader Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Controller Class Initialized
ERROR - 2011-04-19 09:18:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:18:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:18:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:18:33 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:18:33 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:18:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:18:33 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:18:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:18:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:18:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:18:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:18:33 --> Final output sent to browser
DEBUG - 2011-04-19 09:18:33 --> Total execution time: 0.0292
DEBUG - 2011-04-19 09:18:34 --> Config Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:18:34 --> URI Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Router Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Output Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Input Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:18:34 --> Language Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Loader Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Controller Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Model Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:18:34 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:18:34 --> Final output sent to browser
DEBUG - 2011-04-19 09:18:34 --> Total execution time: 0.7587
DEBUG - 2011-04-19 09:19:12 --> Config Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:19:12 --> URI Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Router Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Output Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Input Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:19:12 --> Language Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Loader Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Controller Class Initialized
ERROR - 2011-04-19 09:19:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:19:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:19:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:19:12 --> Model Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Model Class Initialized
DEBUG - 2011-04-19 09:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:19:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:19:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:19:12 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:19:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:19:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:19:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:19:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:19:12 --> Final output sent to browser
DEBUG - 2011-04-19 09:19:12 --> Total execution time: 0.0460
DEBUG - 2011-04-19 09:19:13 --> Config Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:19:13 --> URI Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Router Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Output Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Input Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:19:13 --> Language Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Loader Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Controller Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Model Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Model Class Initialized
DEBUG - 2011-04-19 09:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:19:13 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:19:14 --> Final output sent to browser
DEBUG - 2011-04-19 09:19:14 --> Total execution time: 0.6940
DEBUG - 2011-04-19 09:19:57 --> Config Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:19:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:19:57 --> URI Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Router Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Output Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Input Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:19:57 --> Language Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Loader Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Controller Class Initialized
ERROR - 2011-04-19 09:19:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:19:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:19:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:19:57 --> Model Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Model Class Initialized
DEBUG - 2011-04-19 09:19:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:19:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:19:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:19:57 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:19:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:19:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:19:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:19:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:19:57 --> Final output sent to browser
DEBUG - 2011-04-19 09:19:57 --> Total execution time: 0.0960
DEBUG - 2011-04-19 09:19:58 --> Config Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:19:58 --> URI Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Router Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Output Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Input Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:19:58 --> Language Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Loader Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Controller Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Model Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Model Class Initialized
DEBUG - 2011-04-19 09:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:19:58 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:19:59 --> Final output sent to browser
DEBUG - 2011-04-19 09:19:59 --> Total execution time: 0.9234
DEBUG - 2011-04-19 09:20:08 --> Config Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:20:08 --> URI Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Router Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Output Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Input Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:20:08 --> Language Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Loader Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Controller Class Initialized
ERROR - 2011-04-19 09:20:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:20:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:20:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:20:08 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:20:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:20:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:20:08 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:20:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:20:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:20:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:20:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:20:08 --> Final output sent to browser
DEBUG - 2011-04-19 09:20:08 --> Total execution time: 0.0355
DEBUG - 2011-04-19 09:20:08 --> Config Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:20:08 --> URI Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Router Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Output Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Input Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:20:08 --> Language Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Loader Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Controller Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:20:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:20:09 --> Final output sent to browser
DEBUG - 2011-04-19 09:20:09 --> Total execution time: 0.4946
DEBUG - 2011-04-19 09:20:14 --> Config Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:20:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:20:14 --> URI Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Router Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Output Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Input Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:20:14 --> Language Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Loader Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Controller Class Initialized
ERROR - 2011-04-19 09:20:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:20:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:20:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:20:14 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:20:14 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:20:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:20:14 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:20:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:20:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:20:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:20:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:20:14 --> Final output sent to browser
DEBUG - 2011-04-19 09:20:14 --> Total execution time: 0.0313
DEBUG - 2011-04-19 09:20:15 --> Config Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:20:15 --> URI Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Router Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Output Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Input Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:20:15 --> Language Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Loader Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Controller Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:20:15 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:20:16 --> Final output sent to browser
DEBUG - 2011-04-19 09:20:16 --> Total execution time: 1.1123
DEBUG - 2011-04-19 09:20:40 --> Config Class Initialized
DEBUG - 2011-04-19 09:20:40 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:20:40 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:20:40 --> URI Class Initialized
DEBUG - 2011-04-19 09:20:40 --> Router Class Initialized
DEBUG - 2011-04-19 09:20:40 --> Output Class Initialized
DEBUG - 2011-04-19 09:20:40 --> Input Class Initialized
DEBUG - 2011-04-19 09:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:20:40 --> Language Class Initialized
DEBUG - 2011-04-19 09:20:40 --> Loader Class Initialized
DEBUG - 2011-04-19 09:20:40 --> Controller Class Initialized
ERROR - 2011-04-19 09:20:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:20:41 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:41 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:20:41 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:20:41 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:20:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:20:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:20:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:20:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:20:41 --> Final output sent to browser
DEBUG - 2011-04-19 09:20:41 --> Total execution time: 0.9521
DEBUG - 2011-04-19 09:20:43 --> Config Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:20:43 --> URI Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Router Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Output Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Input Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:20:43 --> Language Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Loader Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Controller Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:20:43 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:20:44 --> Final output sent to browser
DEBUG - 2011-04-19 09:20:44 --> Total execution time: 1.7557
DEBUG - 2011-04-19 09:20:57 --> Config Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:20:57 --> URI Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Router Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Output Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Input Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:20:57 --> Language Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Loader Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Controller Class Initialized
ERROR - 2011-04-19 09:20:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:20:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:20:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:20:57 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:20:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:20:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:20:58 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:20:58 --> Final output sent to browser
DEBUG - 2011-04-19 09:20:58 --> Total execution time: 0.6799
DEBUG - 2011-04-19 09:20:59 --> Config Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:20:59 --> URI Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Router Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Output Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Input Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:20:59 --> Language Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Loader Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Controller Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Model Class Initialized
DEBUG - 2011-04-19 09:20:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:20:59 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:21:01 --> Final output sent to browser
DEBUG - 2011-04-19 09:21:01 --> Total execution time: 2.0016
DEBUG - 2011-04-19 09:21:22 --> Config Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:21:22 --> URI Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Router Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Output Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Input Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:21:22 --> Language Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Loader Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Controller Class Initialized
ERROR - 2011-04-19 09:21:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:21:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:21:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:21:22 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:21:22 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:21:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:21:22 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:21:22 --> Final output sent to browser
DEBUG - 2011-04-19 09:21:22 --> Total execution time: 0.3713
DEBUG - 2011-04-19 09:21:24 --> Config Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:21:24 --> URI Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Router Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Output Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Input Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:21:24 --> Language Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Loader Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Controller Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:21:24 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:21:25 --> Final output sent to browser
DEBUG - 2011-04-19 09:21:25 --> Total execution time: 1.3001
DEBUG - 2011-04-19 09:21:48 --> Config Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:21:48 --> URI Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Router Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Output Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Input Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:21:48 --> Language Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Loader Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Controller Class Initialized
ERROR - 2011-04-19 09:21:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:21:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:21:48 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:21:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:21:48 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:21:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:21:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:21:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:21:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:21:48 --> Final output sent to browser
DEBUG - 2011-04-19 09:21:48 --> Total execution time: 0.1943
DEBUG - 2011-04-19 09:21:49 --> Config Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:21:49 --> URI Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Router Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Output Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Input Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:21:49 --> Language Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Loader Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Controller Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:21:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:21:50 --> Final output sent to browser
DEBUG - 2011-04-19 09:21:50 --> Total execution time: 0.6296
DEBUG - 2011-04-19 09:21:51 --> Config Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 09:21:51 --> URI Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Router Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Output Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Input Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 09:21:51 --> Language Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Loader Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Controller Class Initialized
ERROR - 2011-04-19 09:21:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 09:21:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 09:21:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:21:51 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Model Class Initialized
DEBUG - 2011-04-19 09:21:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 09:21:51 --> Database Driver Class Initialized
DEBUG - 2011-04-19 09:21:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 09:21:51 --> Helper loaded: url_helper
DEBUG - 2011-04-19 09:21:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 09:21:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 09:21:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 09:21:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 09:21:51 --> Final output sent to browser
DEBUG - 2011-04-19 09:21:51 --> Total execution time: 0.1660
DEBUG - 2011-04-19 10:35:00 --> Config Class Initialized
DEBUG - 2011-04-19 10:35:00 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:35:00 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:35:01 --> URI Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Router Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Output Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Input Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:35:01 --> Language Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Loader Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Controller Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:01 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:35:09 --> Config Class Initialized
DEBUG - 2011-04-19 10:35:09 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:35:09 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:35:09 --> URI Class Initialized
DEBUG - 2011-04-19 10:35:09 --> Router Class Initialized
DEBUG - 2011-04-19 10:35:10 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:35:11 --> Output Class Initialized
DEBUG - 2011-04-19 10:35:11 --> Input Class Initialized
DEBUG - 2011-04-19 10:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:35:11 --> Language Class Initialized
DEBUG - 2011-04-19 10:35:12 --> Loader Class Initialized
DEBUG - 2011-04-19 10:35:12 --> Controller Class Initialized
DEBUG - 2011-04-19 10:35:14 --> File loaded: application/views/table/main.php
ERROR - 2011-04-19 10:35:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 10:35:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 10:35:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 10:35:19 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:19 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:35:19 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:35:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 10:35:20 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:35:20 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:35:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:35:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:35:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:35:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:35:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:35:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:35:20 --> Final output sent to browser
DEBUG - 2011-04-19 10:35:20 --> Total execution time: 11.2480
DEBUG - 2011-04-19 10:35:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:35:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:35:20 --> Final output sent to browser
DEBUG - 2011-04-19 10:35:20 --> Total execution time: 19.7347
DEBUG - 2011-04-19 10:35:23 --> Config Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:35:23 --> URI Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Router Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Output Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Input Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:35:23 --> Language Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Loader Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Controller Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:35:23 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:35:24 --> Final output sent to browser
DEBUG - 2011-04-19 10:35:24 --> Total execution time: 1.9980
DEBUG - 2011-04-19 10:35:26 --> Config Class Initialized
DEBUG - 2011-04-19 10:35:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:35:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:35:26 --> URI Class Initialized
DEBUG - 2011-04-19 10:35:26 --> Router Class Initialized
ERROR - 2011-04-19 10:35:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 10:35:55 --> Config Class Initialized
DEBUG - 2011-04-19 10:35:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:35:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:35:55 --> URI Class Initialized
DEBUG - 2011-04-19 10:35:55 --> Router Class Initialized
DEBUG - 2011-04-19 10:35:55 --> Output Class Initialized
DEBUG - 2011-04-19 10:35:55 --> Input Class Initialized
DEBUG - 2011-04-19 10:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:35:56 --> Language Class Initialized
DEBUG - 2011-04-19 10:35:56 --> Loader Class Initialized
DEBUG - 2011-04-19 10:35:56 --> Controller Class Initialized
DEBUG - 2011-04-19 10:35:56 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:56 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:56 --> Model Class Initialized
DEBUG - 2011-04-19 10:35:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:35:56 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:35:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:35:56 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:35:56 --> Final output sent to browser
DEBUG - 2011-04-19 10:35:56 --> Total execution time: 0.4637
DEBUG - 2011-04-19 10:35:58 --> Config Class Initialized
DEBUG - 2011-04-19 10:35:58 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:35:58 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:35:58 --> URI Class Initialized
DEBUG - 2011-04-19 10:35:58 --> Router Class Initialized
ERROR - 2011-04-19 10:35:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 10:36:05 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:05 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Router Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Output Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Input Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:36:05 --> Language Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Loader Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Controller Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:36:05 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:36:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:36:07 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:36:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:36:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:36:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:36:07 --> Final output sent to browser
DEBUG - 2011-04-19 10:36:07 --> Total execution time: 1.6314
DEBUG - 2011-04-19 10:36:09 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:09 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:09 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:09 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:09 --> Router Class Initialized
ERROR - 2011-04-19 10:36:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 10:36:13 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:13 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Router Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Output Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Input Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:36:13 --> Language Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Loader Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Controller Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:36:13 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:36:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:36:13 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:36:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:36:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:36:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:36:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:36:13 --> Final output sent to browser
DEBUG - 2011-04-19 10:36:13 --> Total execution time: 0.1737
DEBUG - 2011-04-19 10:36:19 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:19 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Router Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Output Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Input Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:36:19 --> Language Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Loader Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Controller Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:36:19 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:36:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:36:21 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:36:21 --> Final output sent to browser
DEBUG - 2011-04-19 10:36:21 --> Total execution time: 2.1024
DEBUG - 2011-04-19 10:36:24 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:24 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:24 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:24 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:24 --> Router Class Initialized
ERROR - 2011-04-19 10:36:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 10:36:33 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:33 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Router Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Output Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Input Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:36:33 --> Language Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Loader Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Controller Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:36:33 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:36:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:36:33 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:36:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:36:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:36:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:36:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:36:33 --> Final output sent to browser
DEBUG - 2011-04-19 10:36:33 --> Total execution time: 0.0573
DEBUG - 2011-04-19 10:36:44 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:44 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Router Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Output Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Input Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:36:44 --> Language Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Loader Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Controller Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:36:44 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:36:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:36:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:36:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:36:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:36:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:36:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:36:44 --> Final output sent to browser
DEBUG - 2011-04-19 10:36:44 --> Total execution time: 0.6453
DEBUG - 2011-04-19 10:36:46 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:46 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:46 --> Router Class Initialized
ERROR - 2011-04-19 10:36:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 10:36:59 --> Config Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:36:59 --> URI Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Router Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Output Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Input Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:36:59 --> Language Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Loader Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Controller Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Model Class Initialized
DEBUG - 2011-04-19 10:36:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:36:59 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:36:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:36:59 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:36:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:36:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:36:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:36:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:36:59 --> Final output sent to browser
DEBUG - 2011-04-19 10:36:59 --> Total execution time: 0.3304
DEBUG - 2011-04-19 10:37:01 --> Config Class Initialized
DEBUG - 2011-04-19 10:37:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:37:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:37:01 --> URI Class Initialized
DEBUG - 2011-04-19 10:37:01 --> Router Class Initialized
ERROR - 2011-04-19 10:37:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 10:37:03 --> Config Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:37:03 --> URI Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Router Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Output Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Input Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:37:03 --> Language Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Loader Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Controller Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Model Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Model Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Model Class Initialized
DEBUG - 2011-04-19 10:37:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:37:04 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:37:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:37:04 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:37:04 --> Final output sent to browser
DEBUG - 2011-04-19 10:37:04 --> Total execution time: 0.3650
DEBUG - 2011-04-19 10:40:07 --> Config Class Initialized
DEBUG - 2011-04-19 10:40:07 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:40:07 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:40:07 --> URI Class Initialized
DEBUG - 2011-04-19 10:40:07 --> Router Class Initialized
DEBUG - 2011-04-19 10:40:07 --> No URI present. Default controller set.
DEBUG - 2011-04-19 10:40:07 --> Output Class Initialized
DEBUG - 2011-04-19 10:40:07 --> Input Class Initialized
DEBUG - 2011-04-19 10:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:40:07 --> Language Class Initialized
DEBUG - 2011-04-19 10:40:07 --> Loader Class Initialized
DEBUG - 2011-04-19 10:40:07 --> Controller Class Initialized
DEBUG - 2011-04-19 10:40:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 10:40:08 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:40:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:40:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:40:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:40:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:40:08 --> Final output sent to browser
DEBUG - 2011-04-19 10:40:08 --> Total execution time: 0.3555
DEBUG - 2011-04-19 10:40:21 --> Config Class Initialized
DEBUG - 2011-04-19 10:40:21 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:40:21 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:40:21 --> URI Class Initialized
DEBUG - 2011-04-19 10:40:21 --> Router Class Initialized
ERROR - 2011-04-19 10:40:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 10:50:01 --> Config Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:50:01 --> URI Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Router Class Initialized
ERROR - 2011-04-19 10:50:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 10:50:01 --> Config Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:50:01 --> URI Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Router Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Output Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Input Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:50:01 --> Language Class Initialized
DEBUG - 2011-04-19 10:50:01 --> Loader Class Initialized
DEBUG - 2011-04-19 10:50:02 --> Controller Class Initialized
DEBUG - 2011-04-19 10:50:02 --> Model Class Initialized
DEBUG - 2011-04-19 10:50:02 --> Model Class Initialized
DEBUG - 2011-04-19 10:50:02 --> Model Class Initialized
DEBUG - 2011-04-19 10:50:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:50:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:50:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:50:03 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:50:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:50:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:50:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:50:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:50:03 --> Final output sent to browser
DEBUG - 2011-04-19 10:50:03 --> Total execution time: 1.5278
DEBUG - 2011-04-19 10:50:34 --> Config Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:50:34 --> URI Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Router Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Output Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Input Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:50:34 --> Language Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Loader Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Controller Class Initialized
ERROR - 2011-04-19 10:50:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 10:50:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 10:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 10:50:34 --> Model Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Model Class Initialized
DEBUG - 2011-04-19 10:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:50:34 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 10:50:34 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:50:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:50:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:50:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:50:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:50:34 --> Final output sent to browser
DEBUG - 2011-04-19 10:50:34 --> Total execution time: 0.0657
DEBUG - 2011-04-19 10:55:02 --> Config Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:55:02 --> URI Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Router Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Output Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Input Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 10:55:02 --> Language Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Loader Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Controller Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Model Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Model Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Model Class Initialized
DEBUG - 2011-04-19 10:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 10:55:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 10:55:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 10:55:02 --> Helper loaded: url_helper
DEBUG - 2011-04-19 10:55:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 10:55:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 10:55:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 10:55:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 10:55:02 --> Final output sent to browser
DEBUG - 2011-04-19 10:55:02 --> Total execution time: 0.1672
DEBUG - 2011-04-19 10:55:03 --> Config Class Initialized
DEBUG - 2011-04-19 10:55:03 --> Hooks Class Initialized
DEBUG - 2011-04-19 10:55:03 --> Utf8 Class Initialized
DEBUG - 2011-04-19 10:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 10:55:03 --> URI Class Initialized
DEBUG - 2011-04-19 10:55:03 --> Router Class Initialized
ERROR - 2011-04-19 10:55:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 11:18:14 --> Config Class Initialized
DEBUG - 2011-04-19 11:18:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:18:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:18:14 --> URI Class Initialized
DEBUG - 2011-04-19 11:18:14 --> Router Class Initialized
DEBUG - 2011-04-19 11:18:14 --> No URI present. Default controller set.
DEBUG - 2011-04-19 11:18:14 --> Output Class Initialized
DEBUG - 2011-04-19 11:18:14 --> Input Class Initialized
DEBUG - 2011-04-19 11:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:18:14 --> Language Class Initialized
DEBUG - 2011-04-19 11:18:14 --> Loader Class Initialized
DEBUG - 2011-04-19 11:18:14 --> Controller Class Initialized
DEBUG - 2011-04-19 11:18:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 11:18:14 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:18:14 --> Final output sent to browser
DEBUG - 2011-04-19 11:18:14 --> Total execution time: 0.0991
DEBUG - 2011-04-19 11:20:06 --> Config Class Initialized
DEBUG - 2011-04-19 11:20:06 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:20:06 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:20:06 --> URI Class Initialized
DEBUG - 2011-04-19 11:20:06 --> Router Class Initialized
DEBUG - 2011-04-19 11:20:07 --> Output Class Initialized
DEBUG - 2011-04-19 11:20:07 --> Input Class Initialized
DEBUG - 2011-04-19 11:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:20:07 --> Language Class Initialized
DEBUG - 2011-04-19 11:20:07 --> Loader Class Initialized
DEBUG - 2011-04-19 11:20:07 --> Controller Class Initialized
ERROR - 2011-04-19 11:20:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:20:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:20:07 --> Model Class Initialized
DEBUG - 2011-04-19 11:20:07 --> Model Class Initialized
DEBUG - 2011-04-19 11:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:20:07 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:20:07 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:20:07 --> Final output sent to browser
DEBUG - 2011-04-19 11:20:07 --> Total execution time: 0.4155
DEBUG - 2011-04-19 11:20:08 --> Config Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:20:08 --> URI Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Router Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Output Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Input Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:20:08 --> Language Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Loader Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Controller Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Model Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Model Class Initialized
DEBUG - 2011-04-19 11:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:20:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:21:27 --> Config Class Initialized
DEBUG - 2011-04-19 11:21:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:21:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:21:27 --> URI Class Initialized
DEBUG - 2011-04-19 11:21:27 --> Router Class Initialized
ERROR - 2011-04-19 11:21:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 11:21:29 --> Config Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:21:29 --> URI Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Router Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Output Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Input Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:21:29 --> Language Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Loader Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Controller Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Model Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Model Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Model Class Initialized
DEBUG - 2011-04-19 11:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:21:29 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:21:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 11:21:30 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:21:30 --> Final output sent to browser
DEBUG - 2011-04-19 11:21:30 --> Total execution time: 0.6742
DEBUG - 2011-04-19 11:21:48 --> Config Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:21:48 --> URI Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Router Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Output Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Input Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:21:48 --> Language Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Loader Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Controller Class Initialized
ERROR - 2011-04-19 11:21:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:21:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:21:48 --> Model Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Model Class Initialized
DEBUG - 2011-04-19 11:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:21:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:21:48 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:21:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:21:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:21:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:21:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:21:48 --> Final output sent to browser
DEBUG - 2011-04-19 11:21:48 --> Total execution time: 0.0538
DEBUG - 2011-04-19 11:21:50 --> Config Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:21:50 --> URI Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Router Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Output Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Input Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:21:50 --> Language Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Loader Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Controller Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Model Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Model Class Initialized
DEBUG - 2011-04-19 11:21:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:21:50 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:21:51 --> Final output sent to browser
DEBUG - 2011-04-19 11:21:51 --> Total execution time: 0.8410
DEBUG - 2011-04-19 11:26:40 --> Config Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:26:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:26:40 --> URI Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Router Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Output Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Input Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:26:40 --> Language Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Loader Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Controller Class Initialized
ERROR - 2011-04-19 11:26:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:26:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:26:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:26:40 --> Model Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Model Class Initialized
DEBUG - 2011-04-19 11:26:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:26:40 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:26:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:26:40 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:26:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:26:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:26:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:26:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:26:40 --> Final output sent to browser
DEBUG - 2011-04-19 11:26:40 --> Total execution time: 0.1203
DEBUG - 2011-04-19 11:26:42 --> Config Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:26:42 --> URI Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Router Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Output Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Input Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:26:42 --> Language Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Loader Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Controller Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Model Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Model Class Initialized
DEBUG - 2011-04-19 11:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:26:42 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:26:43 --> Final output sent to browser
DEBUG - 2011-04-19 11:26:43 --> Total execution time: 1.0232
DEBUG - 2011-04-19 11:27:04 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:04 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:04 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Controller Class Initialized
ERROR - 2011-04-19 11:27:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:27:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:27:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:04 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:04 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:04 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:27:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:27:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:27:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:27:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:27:04 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:04 --> Total execution time: 0.0820
DEBUG - 2011-04-19 11:27:08 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:08 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:08 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Controller Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:09 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:09 --> Total execution time: 0.7870
DEBUG - 2011-04-19 11:27:19 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:19 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:19 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Controller Class Initialized
ERROR - 2011-04-19 11:27:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:27:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:27:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:19 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:19 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:19 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:27:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:27:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:27:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:27:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:27:19 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:19 --> Total execution time: 0.0388
DEBUG - 2011-04-19 11:27:26 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:26 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:26 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Controller Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:27 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:27 --> Total execution time: 0.8493
DEBUG - 2011-04-19 11:27:37 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:37 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:37 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Controller Class Initialized
ERROR - 2011-04-19 11:27:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:27:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:27:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:37 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:37 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:37 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:27:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:27:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:27:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:27:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:27:37 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:37 --> Total execution time: 0.1024
DEBUG - 2011-04-19 11:27:39 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:39 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:39 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Controller Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:39 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:40 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:40 --> Total execution time: 0.7227
DEBUG - 2011-04-19 11:27:52 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:52 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:52 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Controller Class Initialized
ERROR - 2011-04-19 11:27:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:27:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:27:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:52 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:52 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:52 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:27:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:27:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:27:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:27:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:27:52 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:52 --> Total execution time: 0.0846
DEBUG - 2011-04-19 11:27:53 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:53 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:53 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Controller Class Initialized
ERROR - 2011-04-19 11:27:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:27:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:27:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:53 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:53 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:27:53 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:27:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:27:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:27:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:27:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:27:53 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:53 --> Total execution time: 0.0356
DEBUG - 2011-04-19 11:27:56 --> Config Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:27:56 --> URI Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Router Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Output Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Input Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:27:56 --> Language Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Loader Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Controller Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Model Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:27:56 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:27:56 --> Final output sent to browser
DEBUG - 2011-04-19 11:27:56 --> Total execution time: 0.6174
DEBUG - 2011-04-19 11:28:07 --> Config Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:28:07 --> URI Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Router Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Output Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Input Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:28:07 --> Language Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Loader Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Controller Class Initialized
ERROR - 2011-04-19 11:28:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:28:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:28:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:28:07 --> Model Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Model Class Initialized
DEBUG - 2011-04-19 11:28:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:28:07 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:28:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:28:07 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:28:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:28:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:28:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:28:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:28:07 --> Final output sent to browser
DEBUG - 2011-04-19 11:28:07 --> Total execution time: 0.0345
DEBUG - 2011-04-19 11:28:20 --> Config Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:28:20 --> URI Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Router Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Output Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Input Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:28:20 --> Language Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Loader Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Controller Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Model Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Model Class Initialized
DEBUG - 2011-04-19 11:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:28:20 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:28:21 --> Final output sent to browser
DEBUG - 2011-04-19 11:28:21 --> Total execution time: 1.0714
DEBUG - 2011-04-19 11:28:35 --> Config Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:28:35 --> URI Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Router Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Output Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Input Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:28:35 --> Language Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Loader Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Controller Class Initialized
ERROR - 2011-04-19 11:28:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:28:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:28:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:28:35 --> Model Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Model Class Initialized
DEBUG - 2011-04-19 11:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:28:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:28:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:28:35 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:28:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:28:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:28:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:28:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:28:35 --> Final output sent to browser
DEBUG - 2011-04-19 11:28:35 --> Total execution time: 0.0377
DEBUG - 2011-04-19 11:28:37 --> Config Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:28:37 --> URI Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Router Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Output Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Input Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:28:37 --> Language Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Loader Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Controller Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Model Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Model Class Initialized
DEBUG - 2011-04-19 11:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:28:37 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:28:38 --> Final output sent to browser
DEBUG - 2011-04-19 11:28:38 --> Total execution time: 0.5787
DEBUG - 2011-04-19 11:29:02 --> Config Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:29:02 --> URI Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Router Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Output Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Input Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:29:02 --> Language Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Loader Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Controller Class Initialized
ERROR - 2011-04-19 11:29:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 11:29:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 11:29:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:29:02 --> Model Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Model Class Initialized
DEBUG - 2011-04-19 11:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:29:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:29:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 11:29:02 --> Helper loaded: url_helper
DEBUG - 2011-04-19 11:29:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 11:29:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 11:29:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 11:29:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 11:29:02 --> Final output sent to browser
DEBUG - 2011-04-19 11:29:02 --> Total execution time: 0.0625
DEBUG - 2011-04-19 11:29:05 --> Config Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 11:29:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 11:29:05 --> URI Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Router Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Output Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Input Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 11:29:05 --> Language Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Loader Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Controller Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Model Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Model Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 11:29:05 --> Database Driver Class Initialized
DEBUG - 2011-04-19 11:29:05 --> Final output sent to browser
DEBUG - 2011-04-19 11:29:05 --> Total execution time: 0.6493
DEBUG - 2011-04-19 12:04:24 --> Config Class Initialized
DEBUG - 2011-04-19 12:04:24 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:04:24 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:04:24 --> URI Class Initialized
DEBUG - 2011-04-19 12:04:24 --> Router Class Initialized
DEBUG - 2011-04-19 12:04:24 --> No URI present. Default controller set.
DEBUG - 2011-04-19 12:04:24 --> Output Class Initialized
DEBUG - 2011-04-19 12:04:24 --> Input Class Initialized
DEBUG - 2011-04-19 12:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:04:24 --> Language Class Initialized
DEBUG - 2011-04-19 12:04:24 --> Loader Class Initialized
DEBUG - 2011-04-19 12:04:24 --> Controller Class Initialized
DEBUG - 2011-04-19 12:04:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 12:04:24 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:04:24 --> Final output sent to browser
DEBUG - 2011-04-19 12:04:24 --> Total execution time: 0.1819
DEBUG - 2011-04-19 12:04:33 --> Config Class Initialized
DEBUG - 2011-04-19 12:04:33 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:04:33 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:04:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:04:33 --> URI Class Initialized
DEBUG - 2011-04-19 12:04:33 --> Router Class Initialized
DEBUG - 2011-04-19 12:04:34 --> Config Class Initialized
DEBUG - 2011-04-19 12:04:34 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:04:34 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:04:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:04:34 --> URI Class Initialized
DEBUG - 2011-04-19 12:04:34 --> Router Class Initialized
ERROR - 2011-04-19 12:04:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 12:04:34 --> Output Class Initialized
DEBUG - 2011-04-19 12:04:34 --> Input Class Initialized
DEBUG - 2011-04-19 12:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:04:34 --> Language Class Initialized
DEBUG - 2011-04-19 12:04:35 --> Loader Class Initialized
DEBUG - 2011-04-19 12:04:35 --> Controller Class Initialized
DEBUG - 2011-04-19 12:04:37 --> Model Class Initialized
DEBUG - 2011-04-19 12:04:37 --> Model Class Initialized
DEBUG - 2011-04-19 12:04:38 --> Model Class Initialized
DEBUG - 2011-04-19 12:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:04:38 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:04:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 12:04:38 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:04:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:04:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:04:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:04:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:04:38 --> Final output sent to browser
DEBUG - 2011-04-19 12:04:38 --> Total execution time: 3.9893
DEBUG - 2011-04-19 12:04:40 --> Config Class Initialized
DEBUG - 2011-04-19 12:04:40 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:04:40 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:04:40 --> URI Class Initialized
DEBUG - 2011-04-19 12:04:40 --> Router Class Initialized
ERROR - 2011-04-19 12:04:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 12:13:46 --> Config Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:13:46 --> URI Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Router Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Output Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Input Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:13:46 --> Language Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Loader Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Controller Class Initialized
ERROR - 2011-04-19 12:13:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 12:13:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 12:13:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:13:46 --> Model Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Model Class Initialized
DEBUG - 2011-04-19 12:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:13:46 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:13:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:13:46 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:13:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:13:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:13:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:13:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:13:46 --> Final output sent to browser
DEBUG - 2011-04-19 12:13:46 --> Total execution time: 0.2057
DEBUG - 2011-04-19 12:13:47 --> Config Class Initialized
DEBUG - 2011-04-19 12:13:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:13:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:13:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:13:48 --> URI Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Router Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Output Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Input Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:13:48 --> Language Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Loader Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Controller Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Model Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Model Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:13:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:13:48 --> Final output sent to browser
DEBUG - 2011-04-19 12:13:48 --> Total execution time: 0.9095
DEBUG - 2011-04-19 12:13:52 --> Config Class Initialized
DEBUG - 2011-04-19 12:13:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:13:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:13:52 --> URI Class Initialized
DEBUG - 2011-04-19 12:13:52 --> Router Class Initialized
ERROR - 2011-04-19 12:13:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 12:13:52 --> Config Class Initialized
DEBUG - 2011-04-19 12:13:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:13:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:13:52 --> URI Class Initialized
DEBUG - 2011-04-19 12:13:52 --> Router Class Initialized
ERROR - 2011-04-19 12:13:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 12:13:53 --> Config Class Initialized
DEBUG - 2011-04-19 12:13:53 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:13:53 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:13:53 --> URI Class Initialized
DEBUG - 2011-04-19 12:13:53 --> Router Class Initialized
ERROR - 2011-04-19 12:13:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 12:14:10 --> Config Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:14:10 --> URI Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Router Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Output Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Input Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:14:10 --> Language Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Loader Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Controller Class Initialized
ERROR - 2011-04-19 12:14:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 12:14:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 12:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:14:10 --> Model Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Model Class Initialized
DEBUG - 2011-04-19 12:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:14:10 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:14:10 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:14:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:14:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:14:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:14:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:14:10 --> Final output sent to browser
DEBUG - 2011-04-19 12:14:10 --> Total execution time: 0.0548
DEBUG - 2011-04-19 12:14:11 --> Config Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:14:11 --> URI Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Router Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Output Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Input Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:14:11 --> Language Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Loader Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Controller Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Model Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Model Class Initialized
DEBUG - 2011-04-19 12:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:14:11 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:14:24 --> Final output sent to browser
DEBUG - 2011-04-19 12:14:24 --> Total execution time: 12.5188
DEBUG - 2011-04-19 12:14:48 --> Config Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:14:48 --> URI Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Router Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Output Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Input Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:14:48 --> Language Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Loader Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Controller Class Initialized
ERROR - 2011-04-19 12:14:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 12:14:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 12:14:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:14:48 --> Model Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Model Class Initialized
DEBUG - 2011-04-19 12:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:14:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:14:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:14:48 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:14:48 --> Final output sent to browser
DEBUG - 2011-04-19 12:14:48 --> Total execution time: 0.2087
DEBUG - 2011-04-19 12:14:49 --> Config Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:14:49 --> URI Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Router Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Output Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Input Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:14:49 --> Language Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Loader Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Controller Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Model Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Model Class Initialized
DEBUG - 2011-04-19 12:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:14:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:14:50 --> Final output sent to browser
DEBUG - 2011-04-19 12:14:50 --> Total execution time: 0.8215
DEBUG - 2011-04-19 12:22:41 --> Config Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:22:41 --> URI Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Router Class Initialized
ERROR - 2011-04-19 12:22:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 12:22:41 --> Config Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:22:41 --> URI Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Router Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Output Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Input Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:22:41 --> Language Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Loader Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Controller Class Initialized
ERROR - 2011-04-19 12:22:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 12:22:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 12:22:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:22:41 --> Model Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Model Class Initialized
DEBUG - 2011-04-19 12:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:22:41 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:22:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:22:41 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:22:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:22:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:22:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:22:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:22:41 --> Final output sent to browser
DEBUG - 2011-04-19 12:22:41 --> Total execution time: 0.0718
DEBUG - 2011-04-19 12:28:13 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:13 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:13 --> Router Class Initialized
DEBUG - 2011-04-19 12:28:13 --> Output Class Initialized
DEBUG - 2011-04-19 12:28:13 --> Input Class Initialized
DEBUG - 2011-04-19 12:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:28:13 --> Language Class Initialized
DEBUG - 2011-04-19 12:28:14 --> Loader Class Initialized
DEBUG - 2011-04-19 12:28:14 --> Controller Class Initialized
ERROR - 2011-04-19 12:28:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 12:28:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 12:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:28:14 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:14 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:28:14 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:28:14 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:28:14 --> Final output sent to browser
DEBUG - 2011-04-19 12:28:14 --> Total execution time: 0.2217
DEBUG - 2011-04-19 12:28:15 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:15 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Router Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Output Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Input Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:28:15 --> Language Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Loader Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Controller Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:28:15 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:28:16 --> Final output sent to browser
DEBUG - 2011-04-19 12:28:16 --> Total execution time: 0.7202
DEBUG - 2011-04-19 12:28:17 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:17 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:17 --> Router Class Initialized
ERROR - 2011-04-19 12:28:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 12:28:26 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:26 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Router Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Output Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Input Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:28:26 --> Language Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Loader Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Controller Class Initialized
ERROR - 2011-04-19 12:28:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 12:28:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 12:28:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:28:26 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:28:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:28:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:28:26 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:28:26 --> Final output sent to browser
DEBUG - 2011-04-19 12:28:26 --> Total execution time: 0.0445
DEBUG - 2011-04-19 12:28:27 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:27 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Router Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Output Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Input Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:28:27 --> Language Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Loader Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Controller Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:28:27 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:28:28 --> Final output sent to browser
DEBUG - 2011-04-19 12:28:28 --> Total execution time: 0.9486
DEBUG - 2011-04-19 12:28:40 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:40 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Router Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Output Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Input Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:28:40 --> Language Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Loader Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Controller Class Initialized
ERROR - 2011-04-19 12:28:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 12:28:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 12:28:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:28:40 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:28:40 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:28:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:28:40 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:28:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:28:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:28:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:28:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:28:40 --> Final output sent to browser
DEBUG - 2011-04-19 12:28:40 --> Total execution time: 0.0318
DEBUG - 2011-04-19 12:28:41 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:41 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Router Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Output Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Input Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:28:41 --> Language Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Loader Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Controller Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:28:41 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:28:41 --> Final output sent to browser
DEBUG - 2011-04-19 12:28:41 --> Total execution time: 0.6188
DEBUG - 2011-04-19 12:28:49 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:49 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Router Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Output Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Input Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:28:49 --> Language Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Loader Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Controller Class Initialized
ERROR - 2011-04-19 12:28:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 12:28:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 12:28:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:28:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:28:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 12:28:49 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:28:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:28:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:28:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:28:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:28:49 --> Final output sent to browser
DEBUG - 2011-04-19 12:28:49 --> Total execution time: 0.2855
DEBUG - 2011-04-19 12:28:50 --> Config Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:28:50 --> URI Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Router Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Output Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Input Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:28:50 --> Language Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Loader Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Controller Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Model Class Initialized
DEBUG - 2011-04-19 12:28:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 12:28:50 --> Database Driver Class Initialized
DEBUG - 2011-04-19 12:28:51 --> Final output sent to browser
DEBUG - 2011-04-19 12:28:51 --> Total execution time: 1.0221
DEBUG - 2011-04-19 12:41:51 --> Config Class Initialized
DEBUG - 2011-04-19 12:41:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:41:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:41:51 --> URI Class Initialized
DEBUG - 2011-04-19 12:41:51 --> Router Class Initialized
ERROR - 2011-04-19 12:41:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 12:42:43 --> Config Class Initialized
DEBUG - 2011-04-19 12:42:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 12:42:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 12:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 12:42:43 --> URI Class Initialized
DEBUG - 2011-04-19 12:42:43 --> Router Class Initialized
DEBUG - 2011-04-19 12:42:43 --> No URI present. Default controller set.
DEBUG - 2011-04-19 12:42:43 --> Output Class Initialized
DEBUG - 2011-04-19 12:42:43 --> Input Class Initialized
DEBUG - 2011-04-19 12:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 12:42:43 --> Language Class Initialized
DEBUG - 2011-04-19 12:42:44 --> Loader Class Initialized
DEBUG - 2011-04-19 12:42:44 --> Controller Class Initialized
DEBUG - 2011-04-19 12:42:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 12:42:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 12:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 12:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 12:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 12:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 12:42:44 --> Final output sent to browser
DEBUG - 2011-04-19 12:42:44 --> Total execution time: 0.7546
DEBUG - 2011-04-19 13:09:45 --> Config Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 13:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 13:09:45 --> URI Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Router Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Output Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Input Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 13:09:45 --> Language Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Loader Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Controller Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Model Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Model Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Model Class Initialized
DEBUG - 2011-04-19 13:09:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 13:09:45 --> Database Driver Class Initialized
DEBUG - 2011-04-19 13:09:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 13:09:45 --> Helper loaded: url_helper
DEBUG - 2011-04-19 13:09:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 13:09:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 13:09:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 13:09:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 13:09:45 --> Final output sent to browser
DEBUG - 2011-04-19 13:09:45 --> Total execution time: 0.4914
DEBUG - 2011-04-19 13:18:10 --> Config Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Hooks Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Utf8 Class Initialized
DEBUG - 2011-04-19 13:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 13:18:10 --> URI Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Router Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Output Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Input Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 13:18:10 --> Language Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Loader Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Controller Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Model Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Model Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Model Class Initialized
DEBUG - 2011-04-19 13:18:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 13:18:10 --> Database Driver Class Initialized
DEBUG - 2011-04-19 13:18:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 13:18:10 --> Helper loaded: url_helper
DEBUG - 2011-04-19 13:18:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 13:18:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 13:18:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 13:18:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 13:18:10 --> Final output sent to browser
DEBUG - 2011-04-19 13:18:10 --> Total execution time: 0.3601
DEBUG - 2011-04-19 13:18:13 --> Config Class Initialized
DEBUG - 2011-04-19 13:18:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 13:18:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 13:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 13:18:13 --> URI Class Initialized
DEBUG - 2011-04-19 13:18:13 --> Router Class Initialized
ERROR - 2011-04-19 13:18:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 13:21:11 --> Config Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Hooks Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Utf8 Class Initialized
DEBUG - 2011-04-19 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 13:21:11 --> URI Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Router Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Output Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Input Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 13:21:11 --> Language Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Loader Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Controller Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Model Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Model Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Model Class Initialized
DEBUG - 2011-04-19 13:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 13:21:11 --> Database Driver Class Initialized
DEBUG - 2011-04-19 13:21:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 13:21:11 --> Helper loaded: url_helper
DEBUG - 2011-04-19 13:21:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 13:21:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 13:21:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 13:21:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 13:21:11 --> Final output sent to browser
DEBUG - 2011-04-19 13:21:11 --> Total execution time: 0.1804
DEBUG - 2011-04-19 14:45:28 --> Config Class Initialized
DEBUG - 2011-04-19 14:45:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:45:33 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:45:35 --> URI Class Initialized
DEBUG - 2011-04-19 14:45:35 --> Router Class Initialized
DEBUG - 2011-04-19 14:45:36 --> Output Class Initialized
DEBUG - 2011-04-19 14:45:36 --> Input Class Initialized
DEBUG - 2011-04-19 14:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:45:36 --> Language Class Initialized
DEBUG - 2011-04-19 14:45:37 --> Loader Class Initialized
DEBUG - 2011-04-19 14:45:37 --> Controller Class Initialized
ERROR - 2011-04-19 14:45:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:45:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:45:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:45:37 --> Model Class Initialized
DEBUG - 2011-04-19 14:45:37 --> Model Class Initialized
DEBUG - 2011-04-19 14:45:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:45:37 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:45:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:45:37 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:45:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:45:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:45:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:45:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:45:38 --> Final output sent to browser
DEBUG - 2011-04-19 14:45:38 --> Total execution time: 10.6562
DEBUG - 2011-04-19 14:45:39 --> Config Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:45:39 --> URI Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Router Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Output Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Input Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:45:39 --> Language Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Loader Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Controller Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Model Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Model Class Initialized
DEBUG - 2011-04-19 14:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:45:39 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:45:40 --> Final output sent to browser
DEBUG - 2011-04-19 14:45:40 --> Total execution time: 1.2870
DEBUG - 2011-04-19 14:46:41 --> Config Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:46:41 --> URI Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Router Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Output Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Input Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:46:41 --> Language Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Loader Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Controller Class Initialized
ERROR - 2011-04-19 14:46:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:46:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:46:41 --> Model Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Model Class Initialized
DEBUG - 2011-04-19 14:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:46:41 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:46:41 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:46:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:46:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:46:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:46:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:46:41 --> Final output sent to browser
DEBUG - 2011-04-19 14:46:41 --> Total execution time: 0.2035
DEBUG - 2011-04-19 14:46:42 --> Config Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:46:42 --> URI Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Router Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Output Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Input Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:46:42 --> Language Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Loader Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Controller Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Model Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Model Class Initialized
DEBUG - 2011-04-19 14:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:46:42 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:46:43 --> Final output sent to browser
DEBUG - 2011-04-19 14:46:43 --> Total execution time: 1.0719
DEBUG - 2011-04-19 14:48:36 --> Config Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:48:36 --> URI Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Router Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Output Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Input Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:48:36 --> Language Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Loader Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Controller Class Initialized
ERROR - 2011-04-19 14:48:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:48:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:48:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:48:36 --> Model Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Model Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:48:36 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:48:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:48:36 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:48:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:48:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:48:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:48:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:48:36 --> Final output sent to browser
DEBUG - 2011-04-19 14:48:36 --> Total execution time: 0.0382
DEBUG - 2011-04-19 14:48:36 --> Config Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:48:36 --> URI Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Router Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Output Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Input Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:48:36 --> Language Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Loader Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Controller Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Model Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Model Class Initialized
DEBUG - 2011-04-19 14:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:48:36 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:48:37 --> Final output sent to browser
DEBUG - 2011-04-19 14:48:37 --> Total execution time: 0.9508
DEBUG - 2011-04-19 14:49:05 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:05 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:05 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Controller Class Initialized
ERROR - 2011-04-19 14:49:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:49:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:49:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:05 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:05 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:05 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:49:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:49:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:49:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:49:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:49:05 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:05 --> Total execution time: 0.0328
DEBUG - 2011-04-19 14:49:06 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:06 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:06 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Controller Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:06 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:07 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:07 --> Total execution time: 0.8567
DEBUG - 2011-04-19 14:49:25 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:25 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:25 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Controller Class Initialized
ERROR - 2011-04-19 14:49:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:49:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:49:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:25 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:25 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:25 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:49:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:49:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:49:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:49:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:49:25 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:25 --> Total execution time: 0.1969
DEBUG - 2011-04-19 14:49:26 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:26 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:26 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Controller Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:27 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:27 --> Total execution time: 0.7133
DEBUG - 2011-04-19 14:49:29 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:29 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:29 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Controller Class Initialized
ERROR - 2011-04-19 14:49:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:49:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:29 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:29 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:29 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:49:29 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:29 --> Total execution time: 0.1276
DEBUG - 2011-04-19 14:49:29 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:29 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:29 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Controller Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:29 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:30 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:30 --> Total execution time: 0.7420
DEBUG - 2011-04-19 14:49:42 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:42 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:42 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Controller Class Initialized
ERROR - 2011-04-19 14:49:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:49:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:42 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:42 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:42 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:49:42 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:42 --> Total execution time: 0.0330
DEBUG - 2011-04-19 14:49:43 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:43 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:43 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Controller Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:43 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:44 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:44 --> Total execution time: 0.7527
DEBUG - 2011-04-19 14:49:52 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:52 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:52 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Controller Class Initialized
ERROR - 2011-04-19 14:49:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:49:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:52 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:52 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:52 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:49:52 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:52 --> Total execution time: 0.2173
DEBUG - 2011-04-19 14:49:53 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:53 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:53 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Controller Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:53 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:53 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:53 --> Total execution time: 0.9039
DEBUG - 2011-04-19 14:49:54 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:54 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:54 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Controller Class Initialized
ERROR - 2011-04-19 14:49:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:49:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:49:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:54 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:54 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:49:54 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:49:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:49:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:49:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:49:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:49:54 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:54 --> Total execution time: 0.0630
DEBUG - 2011-04-19 14:49:55 --> Config Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:49:55 --> URI Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Router Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Output Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Input Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:49:55 --> Language Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Loader Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Controller Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Model Class Initialized
DEBUG - 2011-04-19 14:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:49:55 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:49:56 --> Final output sent to browser
DEBUG - 2011-04-19 14:49:56 --> Total execution time: 0.6668
DEBUG - 2011-04-19 14:50:07 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:07 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:07 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Controller Class Initialized
ERROR - 2011-04-19 14:50:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:50:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:07 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:07 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:50:07 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:07 --> Total execution time: 0.0417
DEBUG - 2011-04-19 14:50:07 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:07 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:07 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Controller Class Initialized
ERROR - 2011-04-19 14:50:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:50:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:07 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:07 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:50:07 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:07 --> Total execution time: 0.0345
DEBUG - 2011-04-19 14:50:08 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:08 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:08 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Controller Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:08 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:08 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:08 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Controller Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:09 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:09 --> Total execution time: 0.8882
DEBUG - 2011-04-19 14:50:14 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:14 --> Total execution time: 5.9074
DEBUG - 2011-04-19 14:50:27 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:27 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:27 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Controller Class Initialized
ERROR - 2011-04-19 14:50:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:50:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:50:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:27 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:27 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:27 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:50:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:50:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:50:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:50:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:50:27 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:27 --> Total execution time: 0.0643
DEBUG - 2011-04-19 14:50:28 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:28 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:28 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Controller Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:28 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:30 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:30 --> Total execution time: 1.6387
DEBUG - 2011-04-19 14:50:32 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:32 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:32 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Controller Class Initialized
ERROR - 2011-04-19 14:50:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:50:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:50:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:32 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:32 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:32 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:50:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:50:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:50:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:50:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:50:32 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:32 --> Total execution time: 0.0413
DEBUG - 2011-04-19 14:50:33 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:33 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:33 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Controller Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:33 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:33 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:33 --> Total execution time: 0.5570
DEBUG - 2011-04-19 14:50:48 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:48 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:48 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Controller Class Initialized
ERROR - 2011-04-19 14:50:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:50:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:50:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:48 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:50:48 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:50:48 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:48 --> Total execution time: 0.0646
DEBUG - 2011-04-19 14:50:48 --> Config Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:50:48 --> URI Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Router Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Output Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Input Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:50:48 --> Language Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Loader Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Controller Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Model Class Initialized
DEBUG - 2011-04-19 14:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:50:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:50:49 --> Final output sent to browser
DEBUG - 2011-04-19 14:50:49 --> Total execution time: 0.6662
DEBUG - 2011-04-19 14:50:59 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:00 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:00 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Controller Class Initialized
ERROR - 2011-04-19 14:51:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:51:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:51:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:00 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:00 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:00 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:00 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:00 --> Total execution time: 0.2851
DEBUG - 2011-04-19 14:51:00 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:00 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:00 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:00 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:01 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:01 --> Total execution time: 0.6998
DEBUG - 2011-04-19 14:51:08 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:08 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:08 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Controller Class Initialized
ERROR - 2011-04-19 14:51:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:51:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:08 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:08 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:08 --> Total execution time: 0.0332
DEBUG - 2011-04-19 14:51:08 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:08 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:08 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Controller Class Initialized
ERROR - 2011-04-19 14:51:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:51:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:08 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:08 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:08 --> Total execution time: 0.0690
DEBUG - 2011-04-19 14:51:08 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:08 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:08 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:08 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:08 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:09 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:09 --> Total execution time: 0.6008
DEBUG - 2011-04-19 14:51:09 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:09 --> Total execution time: 0.6614
DEBUG - 2011-04-19 14:51:20 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:20 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:20 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Controller Class Initialized
ERROR - 2011-04-19 14:51:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:51:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:51:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:20 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:20 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:20 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:20 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:20 --> Total execution time: 0.0532
DEBUG - 2011-04-19 14:51:21 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:21 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:21 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:21 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:22 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:22 --> Total execution time: 0.5896
DEBUG - 2011-04-19 14:51:24 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:24 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:24 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Controller Class Initialized
ERROR - 2011-04-19 14:51:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:51:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:51:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:24 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:24 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:24 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:24 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:24 --> Total execution time: 0.0612
DEBUG - 2011-04-19 14:51:24 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:24 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:24 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:24 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:25 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:25 --> Total execution time: 0.4612
DEBUG - 2011-04-19 14:51:34 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:34 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:34 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Controller Class Initialized
ERROR - 2011-04-19 14:51:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:51:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:34 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:34 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:34 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:34 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:34 --> Total execution time: 0.0279
DEBUG - 2011-04-19 14:51:35 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:35 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:35 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:35 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:35 --> Total execution time: 0.4756
DEBUG - 2011-04-19 14:51:36 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:36 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:36 --> Router Class Initialized
ERROR - 2011-04-19 14:51:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:51:47 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:47 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:47 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Controller Class Initialized
ERROR - 2011-04-19 14:51:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:51:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:51:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:47 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:47 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:47 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:47 --> Total execution time: 0.1220
DEBUG - 2011-04-19 14:51:48 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:48 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:48 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:48 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:49 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:49 --> Total execution time: 0.8432
DEBUG - 2011-04-19 14:51:54 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:54 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:54 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Controller Class Initialized
ERROR - 2011-04-19 14:51:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:51:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:51:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:54 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:54 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:51:54 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:54 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:54 --> Total execution time: 0.0445
DEBUG - 2011-04-19 14:51:55 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:55 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:55 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:55 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:55 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:55 --> Total execution time: 0.6711
DEBUG - 2011-04-19 14:51:57 --> Config Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:51:57 --> URI Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Router Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Output Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Input Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:51:57 --> Language Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Loader Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Controller Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Model Class Initialized
DEBUG - 2011-04-19 14:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:51:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:51:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 14:51:58 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:51:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:51:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:51:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:51:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:51:58 --> Final output sent to browser
DEBUG - 2011-04-19 14:51:58 --> Total execution time: 0.3794
DEBUG - 2011-04-19 14:52:00 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:00 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:00 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:00 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:00 --> Router Class Initialized
ERROR - 2011-04-19 14:52:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:52:02 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:02 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:02 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Controller Class Initialized
ERROR - 2011-04-19 14:52:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:52:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:02 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:02 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:02 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:02 --> Total execution time: 0.0383
DEBUG - 2011-04-19 14:52:02 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:02 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:02 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Controller Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:03 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:03 --> Total execution time: 0.5979
DEBUG - 2011-04-19 14:52:13 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:13 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:13 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Controller Class Initialized
ERROR - 2011-04-19 14:52:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:52:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:52:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:13 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:13 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:13 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:13 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:13 --> Total execution time: 0.0997
DEBUG - 2011-04-19 14:52:14 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:14 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:14 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Controller Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:14 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:14 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:14 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Controller Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:14 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:14 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:14 --> Total execution time: 0.5376
DEBUG - 2011-04-19 14:52:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 14:52:15 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:15 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:15 --> Total execution time: 0.8508
DEBUG - 2011-04-19 14:52:16 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:16 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Router Class Initialized
ERROR - 2011-04-19 14:52:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:52:16 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:16 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:16 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Controller Class Initialized
ERROR - 2011-04-19 14:52:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:52:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:52:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:16 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:16 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:16 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:16 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:16 --> Total execution time: 0.0328
DEBUG - 2011-04-19 14:52:17 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:17 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:17 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Controller Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:17 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:18 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:18 --> Total execution time: 0.5546
DEBUG - 2011-04-19 14:52:20 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:20 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:20 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Controller Class Initialized
ERROR - 2011-04-19 14:52:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:52:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:52:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:20 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:20 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:20 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:20 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:20 --> Total execution time: 0.0283
DEBUG - 2011-04-19 14:52:21 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:21 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:21 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Controller Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:21 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:21 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:21 --> Total execution time: 0.4576
DEBUG - 2011-04-19 14:52:22 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:22 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:22 --> Router Class Initialized
ERROR - 2011-04-19 14:52:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:52:35 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:35 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:35 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Controller Class Initialized
ERROR - 2011-04-19 14:52:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:52:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:35 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:35 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:35 --> Total execution time: 0.0309
DEBUG - 2011-04-19 14:52:35 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:35 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:35 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Controller Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 14:52:35 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:35 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:35 --> Total execution time: 0.0479
DEBUG - 2011-04-19 14:52:44 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:44 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:44 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Controller Class Initialized
ERROR - 2011-04-19 14:52:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:52:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:52:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:44 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:44 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:44 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:44 --> Total execution time: 0.0322
DEBUG - 2011-04-19 14:52:44 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:44 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:44 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Controller Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:44 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:45 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:45 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Controller Class Initialized
ERROR - 2011-04-19 14:52:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:52:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:45 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:45 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:45 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:45 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:45 --> Total execution time: 0.0352
DEBUG - 2011-04-19 14:52:45 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:45 --> Total execution time: 0.6640
DEBUG - 2011-04-19 14:52:52 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:52 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:52 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Controller Class Initialized
ERROR - 2011-04-19 14:52:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:52:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:52:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:52 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:52 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:52:52 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:52:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:52:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:52:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:52:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:52:52 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:52 --> Total execution time: 0.0331
DEBUG - 2011-04-19 14:52:52 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:52 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Router Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Output Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Input Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:52:52 --> Language Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Loader Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Controller Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Model Class Initialized
DEBUG - 2011-04-19 14:52:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:52:52 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:52:53 --> Final output sent to browser
DEBUG - 2011-04-19 14:52:53 --> Total execution time: 0.5394
DEBUG - 2011-04-19 14:52:53 --> Config Class Initialized
DEBUG - 2011-04-19 14:52:53 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:52:53 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:52:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:52:53 --> URI Class Initialized
DEBUG - 2011-04-19 14:52:53 --> Router Class Initialized
ERROR - 2011-04-19 14:52:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:53:03 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:03 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:03 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Controller Class Initialized
ERROR - 2011-04-19 14:53:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:53:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:53:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:03 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:03 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:03 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:53:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:53:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:53:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:53:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:53:03 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:03 --> Total execution time: 0.0326
DEBUG - 2011-04-19 14:53:04 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:04 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:04 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Controller Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:04 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:04 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:04 --> Total execution time: 0.6817
DEBUG - 2011-04-19 14:53:05 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:05 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:05 --> Router Class Initialized
ERROR - 2011-04-19 14:53:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:53:11 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:11 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:11 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Controller Class Initialized
ERROR - 2011-04-19 14:53:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:53:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:53:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:11 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:11 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:11 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:53:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:53:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:53:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:53:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:53:11 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:11 --> Total execution time: 0.0417
DEBUG - 2011-04-19 14:53:12 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:12 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:12 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Controller Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:12 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:12 --> Total execution time: 0.6881
DEBUG - 2011-04-19 14:53:13 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:13 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:13 --> Router Class Initialized
ERROR - 2011-04-19 14:53:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:53:20 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:20 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:20 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Controller Class Initialized
ERROR - 2011-04-19 14:53:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:53:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:20 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:20 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:20 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:53:20 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:20 --> Total execution time: 0.0335
DEBUG - 2011-04-19 14:53:21 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:21 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:21 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Controller Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:21 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:21 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:21 --> Total execution time: 0.4607
DEBUG - 2011-04-19 14:53:22 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:22 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:22 --> Router Class Initialized
ERROR - 2011-04-19 14:53:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:53:29 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:29 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:29 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Controller Class Initialized
ERROR - 2011-04-19 14:53:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:53:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:53:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:29 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:29 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:29 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:53:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:53:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:53:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:53:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:53:29 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:29 --> Total execution time: 0.0492
DEBUG - 2011-04-19 14:53:30 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:30 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:30 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Controller Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:30 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:30 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:30 --> Total execution time: 0.4606
DEBUG - 2011-04-19 14:53:31 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:31 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:31 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:31 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:31 --> Router Class Initialized
ERROR - 2011-04-19 14:53:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:53:35 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:35 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:35 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Controller Class Initialized
ERROR - 2011-04-19 14:53:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:53:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:53:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:35 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:53:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:53:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:53:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:53:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:53:35 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:35 --> Total execution time: 0.0435
DEBUG - 2011-04-19 14:53:36 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:36 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:36 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Controller Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:36 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:36 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:36 --> Total execution time: 0.5217
DEBUG - 2011-04-19 14:53:37 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:37 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:37 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:37 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:37 --> Router Class Initialized
ERROR - 2011-04-19 14:53:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:53:44 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:44 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:44 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Controller Class Initialized
ERROR - 2011-04-19 14:53:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:53:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:53:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:44 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:44 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:53:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:53:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:53:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:53:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:53:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:53:44 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:44 --> Total execution time: 0.0953
DEBUG - 2011-04-19 14:53:45 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:45 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Router Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Output Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Input Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:53:45 --> Language Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Loader Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Controller Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Model Class Initialized
DEBUG - 2011-04-19 14:53:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:53:45 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:53:46 --> Final output sent to browser
DEBUG - 2011-04-19 14:53:46 --> Total execution time: 0.6117
DEBUG - 2011-04-19 14:53:46 --> Config Class Initialized
DEBUG - 2011-04-19 14:53:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:53:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:53:46 --> URI Class Initialized
DEBUG - 2011-04-19 14:53:46 --> Router Class Initialized
ERROR - 2011-04-19 14:53:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:54:15 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:15 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Router Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Output Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Input Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:54:15 --> Language Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Loader Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Controller Class Initialized
ERROR - 2011-04-19 14:54:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:54:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:54:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:54:15 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:54:15 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:54:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:54:15 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:54:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:54:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:54:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:54:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:54:15 --> Final output sent to browser
DEBUG - 2011-04-19 14:54:15 --> Total execution time: 0.0694
DEBUG - 2011-04-19 14:54:15 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:15 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Router Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Output Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Input Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:54:15 --> Language Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Loader Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Controller Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:54:15 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:54:16 --> Final output sent to browser
DEBUG - 2011-04-19 14:54:16 --> Total execution time: 0.6506
DEBUG - 2011-04-19 14:54:17 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:17 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:17 --> Router Class Initialized
ERROR - 2011-04-19 14:54:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:54:25 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:25 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Router Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Output Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Input Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:54:25 --> Language Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Loader Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Controller Class Initialized
ERROR - 2011-04-19 14:54:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:54:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:54:25 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:54:25 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:54:25 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:54:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:54:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:54:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:54:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:54:25 --> Final output sent to browser
DEBUG - 2011-04-19 14:54:25 --> Total execution time: 0.0789
DEBUG - 2011-04-19 14:54:26 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:26 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Router Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Output Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Input Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:54:26 --> Language Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Loader Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Controller Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:54:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:54:27 --> Final output sent to browser
DEBUG - 2011-04-19 14:54:27 --> Total execution time: 0.6228
DEBUG - 2011-04-19 14:54:27 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:27 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:27 --> Router Class Initialized
ERROR - 2011-04-19 14:54:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 14:54:35 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:35 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Router Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Output Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Input Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:54:35 --> Language Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Loader Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Controller Class Initialized
ERROR - 2011-04-19 14:54:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 14:54:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 14:54:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:54:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:54:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:54:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 14:54:35 --> Helper loaded: url_helper
DEBUG - 2011-04-19 14:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 14:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 14:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 14:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 14:54:35 --> Final output sent to browser
DEBUG - 2011-04-19 14:54:35 --> Total execution time: 0.0398
DEBUG - 2011-04-19 14:54:36 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:36 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Router Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Output Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Input Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 14:54:36 --> Language Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Loader Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Controller Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Model Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 14:54:36 --> Database Driver Class Initialized
DEBUG - 2011-04-19 14:54:36 --> Final output sent to browser
DEBUG - 2011-04-19 14:54:36 --> Total execution time: 0.7081
DEBUG - 2011-04-19 14:54:37 --> Config Class Initialized
DEBUG - 2011-04-19 14:54:37 --> Hooks Class Initialized
DEBUG - 2011-04-19 14:54:37 --> Utf8 Class Initialized
DEBUG - 2011-04-19 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 14:54:37 --> URI Class Initialized
DEBUG - 2011-04-19 14:54:37 --> Router Class Initialized
ERROR - 2011-04-19 14:54:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 15:33:13 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:13 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:13 --> Router Class Initialized
DEBUG - 2011-04-19 15:33:13 --> No URI present. Default controller set.
DEBUG - 2011-04-19 15:33:13 --> Output Class Initialized
DEBUG - 2011-04-19 15:33:13 --> Input Class Initialized
DEBUG - 2011-04-19 15:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:33:13 --> Language Class Initialized
DEBUG - 2011-04-19 15:33:13 --> Loader Class Initialized
DEBUG - 2011-04-19 15:33:13 --> Controller Class Initialized
DEBUG - 2011-04-19 15:33:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 15:33:14 --> Helper loaded: url_helper
DEBUG - 2011-04-19 15:33:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 15:33:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 15:33:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 15:33:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 15:33:14 --> Final output sent to browser
DEBUG - 2011-04-19 15:33:14 --> Total execution time: 0.2746
DEBUG - 2011-04-19 15:33:15 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:15 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:15 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:15 --> Router Class Initialized
ERROR - 2011-04-19 15:33:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 15:33:16 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:16 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:16 --> Router Class Initialized
ERROR - 2011-04-19 15:33:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 15:33:18 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:18 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Router Class Initialized
ERROR - 2011-04-19 15:33:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 15:33:18 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:18 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Router Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Output Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Input Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:33:18 --> Language Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Loader Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Controller Class Initialized
ERROR - 2011-04-19 15:33:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 15:33:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 15:33:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 15:33:18 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 15:33:18 --> Database Driver Class Initialized
DEBUG - 2011-04-19 15:33:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 15:33:18 --> Helper loaded: url_helper
DEBUG - 2011-04-19 15:33:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 15:33:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 15:33:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 15:33:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 15:33:18 --> Final output sent to browser
DEBUG - 2011-04-19 15:33:18 --> Total execution time: 0.1918
DEBUG - 2011-04-19 15:33:19 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:19 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Router Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Output Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Input Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:33:19 --> Language Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Loader Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Controller Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 15:33:19 --> Database Driver Class Initialized
DEBUG - 2011-04-19 15:33:20 --> Final output sent to browser
DEBUG - 2011-04-19 15:33:20 --> Total execution time: 0.6482
DEBUG - 2011-04-19 15:33:28 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:28 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Router Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Output Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Input Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:33:28 --> Language Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Loader Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Controller Class Initialized
ERROR - 2011-04-19 15:33:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 15:33:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 15:33:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 15:33:28 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 15:33:28 --> Database Driver Class Initialized
DEBUG - 2011-04-19 15:33:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 15:33:28 --> Helper loaded: url_helper
DEBUG - 2011-04-19 15:33:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 15:33:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 15:33:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 15:33:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 15:33:28 --> Final output sent to browser
DEBUG - 2011-04-19 15:33:28 --> Total execution time: 0.0447
DEBUG - 2011-04-19 15:33:29 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:29 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Router Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Output Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Input Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:33:29 --> Language Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Loader Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Controller Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 15:33:29 --> Database Driver Class Initialized
DEBUG - 2011-04-19 15:33:30 --> Final output sent to browser
DEBUG - 2011-04-19 15:33:30 --> Total execution time: 0.7862
DEBUG - 2011-04-19 15:33:54 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:54 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Router Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Output Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Input Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:33:54 --> Language Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Loader Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Controller Class Initialized
ERROR - 2011-04-19 15:33:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 15:33:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 15:33:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 15:33:54 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 15:33:54 --> Database Driver Class Initialized
DEBUG - 2011-04-19 15:33:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 15:33:54 --> Helper loaded: url_helper
DEBUG - 2011-04-19 15:33:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 15:33:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 15:33:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 15:33:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 15:33:54 --> Final output sent to browser
DEBUG - 2011-04-19 15:33:54 --> Total execution time: 0.0309
DEBUG - 2011-04-19 15:33:55 --> Config Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:33:55 --> URI Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Router Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Output Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Input Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:33:55 --> Language Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Loader Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Controller Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Model Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 15:33:55 --> Database Driver Class Initialized
DEBUG - 2011-04-19 15:33:55 --> Final output sent to browser
DEBUG - 2011-04-19 15:33:55 --> Total execution time: 0.8569
DEBUG - 2011-04-19 15:56:43 --> Config Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:56:43 --> URI Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Router Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Output Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Input Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:56:43 --> Language Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Loader Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Controller Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Model Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Model Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Model Class Initialized
DEBUG - 2011-04-19 15:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 15:56:43 --> Database Driver Class Initialized
DEBUG - 2011-04-19 15:56:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 15:56:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 15:56:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 15:56:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 15:56:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 15:56:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 15:56:44 --> Final output sent to browser
DEBUG - 2011-04-19 15:56:44 --> Total execution time: 0.9775
DEBUG - 2011-04-19 15:56:45 --> Config Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 15:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 15:56:45 --> URI Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Router Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Output Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Input Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 15:56:45 --> Language Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Loader Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Controller Class Initialized
ERROR - 2011-04-19 15:56:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 15:56:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 15:56:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 15:56:45 --> Model Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Model Class Initialized
DEBUG - 2011-04-19 15:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 15:56:45 --> Database Driver Class Initialized
DEBUG - 2011-04-19 15:56:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 15:56:45 --> Helper loaded: url_helper
DEBUG - 2011-04-19 15:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 15:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 15:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 15:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 15:56:45 --> Final output sent to browser
DEBUG - 2011-04-19 15:56:45 --> Total execution time: 0.0794
DEBUG - 2011-04-19 16:08:13 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:13 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:13 --> Router Class Initialized
DEBUG - 2011-04-19 16:08:13 --> No URI present. Default controller set.
DEBUG - 2011-04-19 16:08:13 --> Output Class Initialized
DEBUG - 2011-04-19 16:08:13 --> Input Class Initialized
DEBUG - 2011-04-19 16:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:08:13 --> Language Class Initialized
DEBUG - 2011-04-19 16:08:13 --> Loader Class Initialized
DEBUG - 2011-04-19 16:08:13 --> Controller Class Initialized
DEBUG - 2011-04-19 16:08:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 16:08:13 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:08:13 --> Final output sent to browser
DEBUG - 2011-04-19 16:08:13 --> Total execution time: 0.0857
DEBUG - 2011-04-19 16:08:14 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:14 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:14 --> Router Class Initialized
ERROR - 2011-04-19 16:08:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:08:16 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:16 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Router Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Output Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Input Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:08:16 --> Language Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Loader Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Controller Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:08:17 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:08:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 16:08:17 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:08:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:08:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:08:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:08:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:08:17 --> Final output sent to browser
DEBUG - 2011-04-19 16:08:17 --> Total execution time: 0.1099
DEBUG - 2011-04-19 16:08:18 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:18 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:18 --> Router Class Initialized
ERROR - 2011-04-19 16:08:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:08:26 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:26 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Router Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Output Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Input Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:08:26 --> Language Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Loader Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Controller Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:08:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:08:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 16:08:26 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:08:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:08:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:08:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:08:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:08:26 --> Final output sent to browser
DEBUG - 2011-04-19 16:08:26 --> Total execution time: 0.4479
DEBUG - 2011-04-19 16:08:28 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:28 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:28 --> Router Class Initialized
ERROR - 2011-04-19 16:08:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:08:28 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:28 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:28 --> Router Class Initialized
ERROR - 2011-04-19 16:08:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:08:39 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:39 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Router Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Output Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Input Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:08:39 --> Language Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Loader Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Controller Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:08:39 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:08:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 16:08:39 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:08:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:08:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:08:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:08:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:08:39 --> Final output sent to browser
DEBUG - 2011-04-19 16:08:39 --> Total execution time: 0.4105
DEBUG - 2011-04-19 16:08:41 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:41 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Router Class Initialized
ERROR - 2011-04-19 16:08:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:08:41 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:41 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Router Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Output Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Input Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:08:41 --> Language Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Loader Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Controller Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:08:41 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:08:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 16:08:41 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:08:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:08:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:08:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:08:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:08:41 --> Final output sent to browser
DEBUG - 2011-04-19 16:08:41 --> Total execution time: 0.0586
DEBUG - 2011-04-19 16:08:47 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:47 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Router Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Output Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Input Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:08:47 --> Language Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Loader Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Controller Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:08:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:08:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 16:08:47 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:08:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:08:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:08:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:08:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:08:47 --> Final output sent to browser
DEBUG - 2011-04-19 16:08:47 --> Total execution time: 0.4630
DEBUG - 2011-04-19 16:08:49 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:49 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Router Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Output Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Input Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:08:49 --> Language Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Loader Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Controller Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:08:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 16:08:49 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:08:49 --> Final output sent to browser
DEBUG - 2011-04-19 16:08:49 --> Total execution time: 0.1104
DEBUG - 2011-04-19 16:08:49 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:49 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Router Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Output Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Input Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:08:49 --> Language Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Loader Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Controller Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Model Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:08:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 16:08:49 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:08:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:08:49 --> Final output sent to browser
DEBUG - 2011-04-19 16:08:49 --> Total execution time: 0.0696
DEBUG - 2011-04-19 16:08:49 --> Config Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:08:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:08:49 --> URI Class Initialized
DEBUG - 2011-04-19 16:08:49 --> Router Class Initialized
ERROR - 2011-04-19 16:08:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:32:45 --> Config Class Initialized
DEBUG - 2011-04-19 16:32:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:32:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:32:45 --> URI Class Initialized
DEBUG - 2011-04-19 16:32:45 --> Router Class Initialized
DEBUG - 2011-04-19 16:32:45 --> No URI present. Default controller set.
DEBUG - 2011-04-19 16:32:45 --> Output Class Initialized
DEBUG - 2011-04-19 16:32:45 --> Input Class Initialized
DEBUG - 2011-04-19 16:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:32:45 --> Language Class Initialized
DEBUG - 2011-04-19 16:32:45 --> Loader Class Initialized
DEBUG - 2011-04-19 16:32:45 --> Controller Class Initialized
DEBUG - 2011-04-19 16:32:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-19 16:32:45 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:32:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:32:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:32:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:32:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:32:45 --> Final output sent to browser
DEBUG - 2011-04-19 16:32:45 --> Total execution time: 0.0535
DEBUG - 2011-04-19 16:32:46 --> Config Class Initialized
DEBUG - 2011-04-19 16:32:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:32:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:32:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:32:46 --> URI Class Initialized
DEBUG - 2011-04-19 16:32:46 --> Router Class Initialized
ERROR - 2011-04-19 16:32:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:32:47 --> Config Class Initialized
DEBUG - 2011-04-19 16:32:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:32:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:32:47 --> URI Class Initialized
DEBUG - 2011-04-19 16:32:47 --> Router Class Initialized
ERROR - 2011-04-19 16:32:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:32:54 --> Config Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:32:54 --> URI Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Router Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Output Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Input Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:32:54 --> Language Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Loader Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Controller Class Initialized
ERROR - 2011-04-19 16:32:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 16:32:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 16:32:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 16:32:54 --> Model Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Model Class Initialized
DEBUG - 2011-04-19 16:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:32:54 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:32:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 16:32:54 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:32:54 --> Final output sent to browser
DEBUG - 2011-04-19 16:32:54 --> Total execution time: 0.1376
DEBUG - 2011-04-19 16:32:55 --> Config Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:32:55 --> URI Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Router Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Output Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Input Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:32:55 --> Language Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Loader Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Controller Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Model Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Model Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:32:55 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:32:55 --> Final output sent to browser
DEBUG - 2011-04-19 16:32:55 --> Total execution time: 0.7494
DEBUG - 2011-04-19 16:32:57 --> Config Class Initialized
DEBUG - 2011-04-19 16:32:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:32:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:32:57 --> URI Class Initialized
DEBUG - 2011-04-19 16:32:57 --> Router Class Initialized
ERROR - 2011-04-19 16:32:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:33:07 --> Config Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:33:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:33:07 --> URI Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Router Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Output Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Input Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:33:07 --> Language Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Loader Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Controller Class Initialized
ERROR - 2011-04-19 16:33:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 16:33:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 16:33:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 16:33:07 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:33:07 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:33:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 16:33:07 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:33:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:33:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:33:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:33:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:33:07 --> Final output sent to browser
DEBUG - 2011-04-19 16:33:07 --> Total execution time: 0.0347
DEBUG - 2011-04-19 16:33:08 --> Config Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:33:08 --> URI Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Router Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Output Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Input Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:33:08 --> Language Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Loader Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Controller Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:33:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Config Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:33:08 --> URI Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Router Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Output Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Input Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:33:08 --> Language Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Loader Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Controller Class Initialized
ERROR - 2011-04-19 16:33:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 16:33:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 16:33:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 16:33:08 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:33:08 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:33:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 16:33:08 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:33:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:33:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:33:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:33:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:33:08 --> Final output sent to browser
DEBUG - 2011-04-19 16:33:08 --> Total execution time: 0.0740
DEBUG - 2011-04-19 16:33:09 --> Final output sent to browser
DEBUG - 2011-04-19 16:33:09 --> Total execution time: 0.7537
DEBUG - 2011-04-19 16:33:10 --> Config Class Initialized
DEBUG - 2011-04-19 16:33:10 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:33:10 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:33:10 --> URI Class Initialized
DEBUG - 2011-04-19 16:33:10 --> Router Class Initialized
ERROR - 2011-04-19 16:33:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:33:21 --> Config Class Initialized
DEBUG - 2011-04-19 16:33:21 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:33:21 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:33:21 --> URI Class Initialized
DEBUG - 2011-04-19 16:33:21 --> Router Class Initialized
ERROR - 2011-04-19 16:33:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:33:22 --> Config Class Initialized
DEBUG - 2011-04-19 16:33:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:33:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:33:22 --> URI Class Initialized
DEBUG - 2011-04-19 16:33:22 --> Router Class Initialized
ERROR - 2011-04-19 16:33:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 16:33:26 --> Config Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:33:26 --> URI Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Router Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Output Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Input Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 16:33:26 --> Language Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Loader Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Controller Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Model Class Initialized
DEBUG - 2011-04-19 16:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 16:33:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 16:33:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 16:33:26 --> Helper loaded: url_helper
DEBUG - 2011-04-19 16:33:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 16:33:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 16:33:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 16:33:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 16:33:26 --> Final output sent to browser
DEBUG - 2011-04-19 16:33:26 --> Total execution time: 0.2542
DEBUG - 2011-04-19 16:33:27 --> Config Class Initialized
DEBUG - 2011-04-19 16:33:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 16:33:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 16:33:27 --> URI Class Initialized
DEBUG - 2011-04-19 16:33:27 --> Router Class Initialized
ERROR - 2011-04-19 16:33:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:12:25 --> Config Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:12:25 --> URI Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Router Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Output Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Input Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:12:25 --> Language Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Loader Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Controller Class Initialized
ERROR - 2011-04-19 17:12:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 17:12:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 17:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:12:25 --> Model Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Model Class Initialized
DEBUG - 2011-04-19 17:12:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:12:25 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:12:25 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:12:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:12:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:12:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:12:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:12:25 --> Final output sent to browser
DEBUG - 2011-04-19 17:12:25 --> Total execution time: 0.3131
DEBUG - 2011-04-19 17:12:27 --> Config Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:12:27 --> URI Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Router Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Output Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Input Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:12:27 --> Language Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Loader Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Controller Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Model Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Model Class Initialized
DEBUG - 2011-04-19 17:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:12:27 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:12:28 --> Final output sent to browser
DEBUG - 2011-04-19 17:12:28 --> Total execution time: 0.9435
DEBUG - 2011-04-19 17:12:29 --> Config Class Initialized
DEBUG - 2011-04-19 17:12:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:12:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:12:29 --> URI Class Initialized
DEBUG - 2011-04-19 17:12:29 --> Router Class Initialized
ERROR - 2011-04-19 17:12:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:12:46 --> Config Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:12:46 --> URI Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Router Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Output Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Input Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:12:46 --> Language Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Loader Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Controller Class Initialized
ERROR - 2011-04-19 17:12:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 17:12:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 17:12:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:12:46 --> Model Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Model Class Initialized
DEBUG - 2011-04-19 17:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:12:46 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:12:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:12:46 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:12:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:12:46 --> Final output sent to browser
DEBUG - 2011-04-19 17:12:46 --> Total execution time: 0.1235
DEBUG - 2011-04-19 17:12:47 --> Config Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:12:47 --> URI Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Router Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Output Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Input Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:12:47 --> Language Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Loader Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Controller Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Model Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Model Class Initialized
DEBUG - 2011-04-19 17:12:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:12:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:12:48 --> Final output sent to browser
DEBUG - 2011-04-19 17:12:48 --> Total execution time: 0.8600
DEBUG - 2011-04-19 17:12:49 --> Config Class Initialized
DEBUG - 2011-04-19 17:12:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:12:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:12:49 --> URI Class Initialized
DEBUG - 2011-04-19 17:12:49 --> Router Class Initialized
ERROR - 2011-04-19 17:12:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:13:02 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:02 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Router Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Output Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Input Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:13:02 --> Language Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Loader Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Controller Class Initialized
ERROR - 2011-04-19 17:13:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 17:13:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 17:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:13:02 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:13:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:13:02 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:13:02 --> Final output sent to browser
DEBUG - 2011-04-19 17:13:02 --> Total execution time: 0.0318
DEBUG - 2011-04-19 17:13:03 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:03 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Router Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Output Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Input Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:13:03 --> Language Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Loader Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Controller Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:13:03 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:13:03 --> Final output sent to browser
DEBUG - 2011-04-19 17:13:03 --> Total execution time: 0.7140
DEBUG - 2011-04-19 17:13:05 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:05 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:05 --> Router Class Initialized
ERROR - 2011-04-19 17:13:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:13:25 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:25 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Router Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Output Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Input Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:13:25 --> Language Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Loader Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Controller Class Initialized
ERROR - 2011-04-19 17:13:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 17:13:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 17:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:13:25 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:13:25 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:13:25 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:13:25 --> Final output sent to browser
DEBUG - 2011-04-19 17:13:25 --> Total execution time: 0.0468
DEBUG - 2011-04-19 17:13:26 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:26 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Router Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Output Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Input Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:13:26 --> Language Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Loader Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Controller Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:13:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:13:27 --> Final output sent to browser
DEBUG - 2011-04-19 17:13:27 --> Total execution time: 0.6063
DEBUG - 2011-04-19 17:13:28 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:28 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:28 --> Router Class Initialized
ERROR - 2011-04-19 17:13:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:13:54 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:54 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Router Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Output Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Input Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:13:54 --> Language Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Loader Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Controller Class Initialized
ERROR - 2011-04-19 17:13:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 17:13:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 17:13:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:13:54 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:13:54 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:13:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:13:54 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:13:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:13:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:13:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:13:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:13:54 --> Final output sent to browser
DEBUG - 2011-04-19 17:13:54 --> Total execution time: 0.0669
DEBUG - 2011-04-19 17:13:55 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:55 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Router Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Output Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Input Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:13:55 --> Language Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Loader Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Controller Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Model Class Initialized
DEBUG - 2011-04-19 17:13:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:13:55 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:13:56 --> Final output sent to browser
DEBUG - 2011-04-19 17:13:56 --> Total execution time: 0.7190
DEBUG - 2011-04-19 17:13:58 --> Config Class Initialized
DEBUG - 2011-04-19 17:13:58 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:13:58 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:13:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:13:58 --> URI Class Initialized
DEBUG - 2011-04-19 17:13:58 --> Router Class Initialized
ERROR - 2011-04-19 17:13:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:14:25 --> Config Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:14:25 --> URI Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Router Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Output Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Input Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:14:25 --> Language Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Loader Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Controller Class Initialized
ERROR - 2011-04-19 17:14:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 17:14:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 17:14:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:14:25 --> Model Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Model Class Initialized
DEBUG - 2011-04-19 17:14:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:14:25 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:14:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 17:14:25 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:14:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:14:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:14:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:14:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:14:25 --> Final output sent to browser
DEBUG - 2011-04-19 17:14:25 --> Total execution time: 0.1209
DEBUG - 2011-04-19 17:45:09 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:09 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Router Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Output Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Input Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:45:09 --> Language Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Loader Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Controller Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:45:09 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:45:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:45:10 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:45:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:45:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:45:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:45:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:45:10 --> Final output sent to browser
DEBUG - 2011-04-19 17:45:10 --> Total execution time: 1.3735
DEBUG - 2011-04-19 17:45:13 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:13 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:13 --> Router Class Initialized
ERROR - 2011-04-19 17:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:45:14 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:14 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:14 --> Router Class Initialized
ERROR - 2011-04-19 17:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:45:15 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:15 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:15 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:15 --> Router Class Initialized
ERROR - 2011-04-19 17:45:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 17:45:18 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:18 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Router Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Output Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Input Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:45:18 --> Language Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Loader Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Controller Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:45:18 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:45:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:45:19 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:45:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:45:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:45:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:45:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:45:19 --> Final output sent to browser
DEBUG - 2011-04-19 17:45:19 --> Total execution time: 0.2698
DEBUG - 2011-04-19 17:45:26 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:26 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Router Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Output Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Input Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:45:26 --> Language Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Loader Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Controller Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:45:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:45:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:45:27 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:45:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:45:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:45:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:45:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:45:27 --> Final output sent to browser
DEBUG - 2011-04-19 17:45:27 --> Total execution time: 1.0548
DEBUG - 2011-04-19 17:45:39 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:39 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Router Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Output Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Input Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:45:39 --> Language Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Loader Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Controller Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:45:39 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:45:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:45:40 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:45:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:45:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:45:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:45:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:45:40 --> Final output sent to browser
DEBUG - 2011-04-19 17:45:40 --> Total execution time: 0.3939
DEBUG - 2011-04-19 17:45:43 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:43 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Router Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Output Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Input Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:45:43 --> Language Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Loader Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Controller Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:45:43 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:45:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:45:43 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:45:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:45:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:45:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:45:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:45:43 --> Final output sent to browser
DEBUG - 2011-04-19 17:45:43 --> Total execution time: 0.0545
DEBUG - 2011-04-19 17:45:59 --> Config Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:45:59 --> URI Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Router Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Output Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Input Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:45:59 --> Language Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Loader Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Controller Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Model Class Initialized
DEBUG - 2011-04-19 17:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:45:59 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:45:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:45:59 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:45:59 --> Final output sent to browser
DEBUG - 2011-04-19 17:45:59 --> Total execution time: 0.3735
DEBUG - 2011-04-19 17:46:01 --> Config Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:46:01 --> URI Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Router Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Output Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Input Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:46:01 --> Language Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Loader Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Controller Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:46:01 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:46:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:46:01 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:46:01 --> Final output sent to browser
DEBUG - 2011-04-19 17:46:01 --> Total execution time: 0.5217
DEBUG - 2011-04-19 17:46:35 --> Config Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:46:35 --> URI Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Router Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Output Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Input Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:46:35 --> Language Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Loader Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Controller Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:46:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:46:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:46:35 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:46:35 --> Final output sent to browser
DEBUG - 2011-04-19 17:46:35 --> Total execution time: 0.1069
DEBUG - 2011-04-19 17:46:49 --> Config Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:46:49 --> URI Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Router Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Output Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Input Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:46:49 --> Language Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Loader Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Controller Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Model Class Initialized
DEBUG - 2011-04-19 17:46:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:46:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:46:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:46:49 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:46:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:46:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:46:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:46:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:46:49 --> Final output sent to browser
DEBUG - 2011-04-19 17:46:49 --> Total execution time: 0.0980
DEBUG - 2011-04-19 17:47:12 --> Config Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:47:12 --> URI Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Router Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Output Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Input Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:47:12 --> Language Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Loader Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Controller Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:47:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:47:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:47:12 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:47:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:47:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:47:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:47:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:47:12 --> Final output sent to browser
DEBUG - 2011-04-19 17:47:12 --> Total execution time: 0.3012
DEBUG - 2011-04-19 17:47:15 --> Config Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:47:15 --> URI Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Router Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Output Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Input Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:47:15 --> Language Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Loader Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Controller Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:47:15 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:47:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:47:15 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:47:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:47:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:47:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:47:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:47:15 --> Final output sent to browser
DEBUG - 2011-04-19 17:47:15 --> Total execution time: 0.1077
DEBUG - 2011-04-19 17:47:37 --> Config Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:47:37 --> URI Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Router Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Output Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Input Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:47:37 --> Language Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Loader Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Controller Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:47:37 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:47:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:47:37 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:47:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:47:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:47:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:47:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:47:37 --> Final output sent to browser
DEBUG - 2011-04-19 17:47:37 --> Total execution time: 0.6554
DEBUG - 2011-04-19 17:47:39 --> Config Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:47:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:47:39 --> URI Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Router Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Output Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Input Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:47:39 --> Language Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Loader Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Controller Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:47:39 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:47:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:47:39 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:47:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:47:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:47:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:47:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:47:39 --> Final output sent to browser
DEBUG - 2011-04-19 17:47:39 --> Total execution time: 0.0507
DEBUG - 2011-04-19 17:47:49 --> Config Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:47:49 --> URI Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Router Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Output Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Input Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:47:49 --> Language Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Loader Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Controller Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:47:49 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:47:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:47:50 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:47:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:47:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:47:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:47:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:47:50 --> Final output sent to browser
DEBUG - 2011-04-19 17:47:50 --> Total execution time: 0.7104
DEBUG - 2011-04-19 17:47:51 --> Config Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:47:51 --> URI Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Router Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Output Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Input Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:47:51 --> Language Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Loader Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Controller Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Model Class Initialized
DEBUG - 2011-04-19 17:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:47:51 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:47:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:47:51 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:47:51 --> Final output sent to browser
DEBUG - 2011-04-19 17:47:51 --> Total execution time: 0.0457
DEBUG - 2011-04-19 17:48:20 --> Config Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:48:20 --> URI Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Router Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Output Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Input Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:48:20 --> Language Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Loader Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Controller Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:48:20 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:48:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:48:20 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:48:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:48:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:48:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:48:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:48:20 --> Final output sent to browser
DEBUG - 2011-04-19 17:48:20 --> Total execution time: 0.2333
DEBUG - 2011-04-19 17:48:29 --> Config Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:48:29 --> URI Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Router Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Output Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Input Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:48:29 --> Language Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Loader Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Controller Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:48:29 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:48:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:48:30 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:48:30 --> Final output sent to browser
DEBUG - 2011-04-19 17:48:30 --> Total execution time: 0.8886
DEBUG - 2011-04-19 17:48:32 --> Config Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:48:32 --> URI Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Router Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Output Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Input Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:48:32 --> Language Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Loader Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Controller Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Model Class Initialized
DEBUG - 2011-04-19 17:48:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:48:32 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:48:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:48:32 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:48:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:48:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:48:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:48:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:48:32 --> Final output sent to browser
DEBUG - 2011-04-19 17:48:32 --> Total execution time: 0.0494
DEBUG - 2011-04-19 17:49:01 --> Config Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:49:01 --> URI Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Router Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Output Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Input Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:49:01 --> Language Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Loader Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Controller Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:49:01 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:49:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:49:01 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:49:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:49:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:49:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:49:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:49:01 --> Final output sent to browser
DEBUG - 2011-04-19 17:49:01 --> Total execution time: 0.0892
DEBUG - 2011-04-19 17:49:30 --> Config Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:49:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:49:30 --> URI Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Router Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Output Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Input Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:49:30 --> Language Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Loader Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Controller Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:49:30 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:49:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:49:31 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:49:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:49:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:49:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:49:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:49:31 --> Final output sent to browser
DEBUG - 2011-04-19 17:49:31 --> Total execution time: 0.6506
DEBUG - 2011-04-19 17:49:32 --> Config Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Hooks Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Utf8 Class Initialized
DEBUG - 2011-04-19 17:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 17:49:32 --> URI Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Router Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Output Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Input Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 17:49:32 --> Language Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Loader Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Controller Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Model Class Initialized
DEBUG - 2011-04-19 17:49:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 17:49:32 --> Database Driver Class Initialized
DEBUG - 2011-04-19 17:49:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 17:49:32 --> Helper loaded: url_helper
DEBUG - 2011-04-19 17:49:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 17:49:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 17:49:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 17:49:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 17:49:32 --> Final output sent to browser
DEBUG - 2011-04-19 17:49:32 --> Total execution time: 0.0563
DEBUG - 2011-04-19 18:00:45 --> Config Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:00:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:00:45 --> URI Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Router Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Output Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Input Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:00:45 --> Language Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Loader Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Controller Class Initialized
ERROR - 2011-04-19 18:00:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:00:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:00:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:00:45 --> Model Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Model Class Initialized
DEBUG - 2011-04-19 18:00:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:00:45 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:00:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:00:45 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:00:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:00:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:00:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:00:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:00:45 --> Final output sent to browser
DEBUG - 2011-04-19 18:00:45 --> Total execution time: 0.1596
DEBUG - 2011-04-19 18:00:46 --> Config Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:00:46 --> URI Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Router Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Output Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Input Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:00:46 --> Language Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Loader Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Controller Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Model Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Model Class Initialized
DEBUG - 2011-04-19 18:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:00:46 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:00:47 --> Final output sent to browser
DEBUG - 2011-04-19 18:00:47 --> Total execution time: 0.8971
DEBUG - 2011-04-19 18:00:48 --> Config Class Initialized
DEBUG - 2011-04-19 18:00:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:00:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:00:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:00:48 --> URI Class Initialized
DEBUG - 2011-04-19 18:00:48 --> Router Class Initialized
ERROR - 2011-04-19 18:00:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:00:50 --> Config Class Initialized
DEBUG - 2011-04-19 18:00:50 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:00:50 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:00:50 --> URI Class Initialized
DEBUG - 2011-04-19 18:00:50 --> Router Class Initialized
ERROR - 2011-04-19 18:00:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:14:39 --> Config Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:14:39 --> URI Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Router Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Output Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Input Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:14:39 --> Language Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Loader Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Controller Class Initialized
ERROR - 2011-04-19 18:14:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:14:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:14:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:14:39 --> Model Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Model Class Initialized
DEBUG - 2011-04-19 18:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:14:39 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:14:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:14:39 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:14:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:14:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:14:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:14:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:14:39 --> Final output sent to browser
DEBUG - 2011-04-19 18:14:39 --> Total execution time: 0.1074
DEBUG - 2011-04-19 18:14:40 --> Config Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:14:40 --> URI Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Router Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Output Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Input Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:14:40 --> Language Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Loader Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Controller Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Model Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Model Class Initialized
DEBUG - 2011-04-19 18:14:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:14:40 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:14:41 --> Final output sent to browser
DEBUG - 2011-04-19 18:14:41 --> Total execution time: 0.8608
DEBUG - 2011-04-19 18:14:43 --> Config Class Initialized
DEBUG - 2011-04-19 18:14:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:14:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:14:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:14:43 --> URI Class Initialized
DEBUG - 2011-04-19 18:14:43 --> Router Class Initialized
ERROR - 2011-04-19 18:14:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:14:57 --> Config Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:14:57 --> URI Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Router Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Output Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Input Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:14:57 --> Language Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Loader Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Controller Class Initialized
ERROR - 2011-04-19 18:14:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:14:57 --> Model Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Model Class Initialized
DEBUG - 2011-04-19 18:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:14:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:14:57 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:14:57 --> Final output sent to browser
DEBUG - 2011-04-19 18:14:57 --> Total execution time: 0.0526
DEBUG - 2011-04-19 18:14:58 --> Config Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:14:58 --> URI Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Router Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Output Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Input Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:14:58 --> Language Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Loader Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Controller Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Model Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Model Class Initialized
DEBUG - 2011-04-19 18:14:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:14:58 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:14:59 --> Final output sent to browser
DEBUG - 2011-04-19 18:14:59 --> Total execution time: 0.6932
DEBUG - 2011-04-19 18:15:00 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:00 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:00 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:00 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:00 --> Router Class Initialized
ERROR - 2011-04-19 18:15:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:15:18 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:18 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:18 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Controller Class Initialized
ERROR - 2011-04-19 18:15:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:15:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:15:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:18 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:18 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:18 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:15:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:15:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:15:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:15:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:15:18 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:18 --> Total execution time: 0.0369
DEBUG - 2011-04-19 18:15:19 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:19 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:19 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Controller Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:19 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:19 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:19 --> Total execution time: 0.7105
DEBUG - 2011-04-19 18:15:20 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:20 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:20 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:20 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:20 --> Router Class Initialized
ERROR - 2011-04-19 18:15:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:15:29 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:29 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:29 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Controller Class Initialized
ERROR - 2011-04-19 18:15:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:15:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:15:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:29 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:29 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:29 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:15:29 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:29 --> Total execution time: 0.0487
DEBUG - 2011-04-19 18:15:30 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:30 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:30 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Controller Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:30 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:31 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:31 --> Total execution time: 0.7363
DEBUG - 2011-04-19 18:15:32 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:32 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:32 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:32 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:32 --> Router Class Initialized
ERROR - 2011-04-19 18:15:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:15:37 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:37 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:37 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Controller Class Initialized
ERROR - 2011-04-19 18:15:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:15:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:15:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:37 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:37 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:37 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:15:37 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:37 --> Total execution time: 0.0372
DEBUG - 2011-04-19 18:15:38 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:38 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:38 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Controller Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:38 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:39 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:39 --> Total execution time: 0.5423
DEBUG - 2011-04-19 18:15:40 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:40 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Router Class Initialized
ERROR - 2011-04-19 18:15:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:15:40 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:40 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:40 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Controller Class Initialized
ERROR - 2011-04-19 18:15:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:15:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:15:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:40 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:40 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:40 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:15:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:15:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:15:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:15:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:15:40 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:40 --> Total execution time: 0.0558
DEBUG - 2011-04-19 18:15:44 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:44 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:44 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Controller Class Initialized
ERROR - 2011-04-19 18:15:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:15:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:15:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:44 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:44 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:15:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:15:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:15:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:15:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:15:44 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:44 --> Total execution time: 0.0451
DEBUG - 2011-04-19 18:15:45 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:45 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:45 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Controller Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:45 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:46 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:46 --> Total execution time: 0.5632
DEBUG - 2011-04-19 18:15:47 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:47 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:47 --> Router Class Initialized
ERROR - 2011-04-19 18:15:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:15:52 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:52 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:52 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Controller Class Initialized
ERROR - 2011-04-19 18:15:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:15:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:15:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:52 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:52 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:15:52 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:15:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:15:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:15:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:15:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:15:52 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:52 --> Total execution time: 0.0361
DEBUG - 2011-04-19 18:15:53 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:53 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Router Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Output Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Input Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:15:53 --> Language Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Loader Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Controller Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Model Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:15:53 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:15:53 --> Final output sent to browser
DEBUG - 2011-04-19 18:15:53 --> Total execution time: 0.7080
DEBUG - 2011-04-19 18:15:54 --> Config Class Initialized
DEBUG - 2011-04-19 18:15:54 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:15:54 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:15:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:15:54 --> URI Class Initialized
DEBUG - 2011-04-19 18:15:54 --> Router Class Initialized
ERROR - 2011-04-19 18:15:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:16:05 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:05 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:06 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Controller Class Initialized
ERROR - 2011-04-19 18:16:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:16:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:16:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:06 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:06 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:06 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:16:06 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:06 --> Total execution time: 0.0537
DEBUG - 2011-04-19 18:16:06 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:06 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:06 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Controller Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:06 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:07 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:07 --> Total execution time: 0.5326
DEBUG - 2011-04-19 18:16:08 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:08 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:08 --> Router Class Initialized
ERROR - 2011-04-19 18:16:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:16:12 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:12 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:12 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Controller Class Initialized
ERROR - 2011-04-19 18:16:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:16:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:12 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:12 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:16:12 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:12 --> Total execution time: 0.0303
DEBUG - 2011-04-19 18:16:12 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:12 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:12 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Controller Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:13 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:13 --> Total execution time: 0.6597
DEBUG - 2011-04-19 18:16:14 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:14 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:14 --> Router Class Initialized
ERROR - 2011-04-19 18:16:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:16:18 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:18 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:18 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Controller Class Initialized
ERROR - 2011-04-19 18:16:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:16:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:18 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:18 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:18 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:16:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:16:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:16:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:16:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:16:18 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:18 --> Total execution time: 0.0516
DEBUG - 2011-04-19 18:16:19 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:19 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:19 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Controller Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:19 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:20 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:20 --> Total execution time: 0.6598
DEBUG - 2011-04-19 18:16:21 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:21 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:21 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:21 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:21 --> Router Class Initialized
ERROR - 2011-04-19 18:16:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:16:28 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:28 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:28 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Controller Class Initialized
ERROR - 2011-04-19 18:16:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:16:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:16:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:28 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:28 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:28 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:16:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:16:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:16:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:16:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:16:28 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:28 --> Total execution time: 0.0304
DEBUG - 2011-04-19 18:16:29 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:29 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:29 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Controller Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:29 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:30 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:30 --> Total execution time: 0.6336
DEBUG - 2011-04-19 18:16:31 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:31 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:31 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:31 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:31 --> Router Class Initialized
ERROR - 2011-04-19 18:16:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:16:36 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:36 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:36 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Controller Class Initialized
ERROR - 2011-04-19 18:16:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:16:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:16:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:36 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:36 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:16:36 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:16:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:16:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:16:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:16:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:16:36 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:36 --> Total execution time: 0.0514
DEBUG - 2011-04-19 18:16:36 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:36 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:36 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Controller Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:36 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:37 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:37 --> Total execution time: 0.5443
DEBUG - 2011-04-19 18:16:38 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:38 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:38 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:38 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:38 --> Router Class Initialized
ERROR - 2011-04-19 18:16:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:16:52 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:52 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Router Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Output Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Input Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:16:52 --> Language Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Loader Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Controller Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Model Class Initialized
DEBUG - 2011-04-19 18:16:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:16:52 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:16:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 18:16:52 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:16:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:16:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:16:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:16:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:16:52 --> Final output sent to browser
DEBUG - 2011-04-19 18:16:52 --> Total execution time: 0.3470
DEBUG - 2011-04-19 18:16:54 --> Config Class Initialized
DEBUG - 2011-04-19 18:16:54 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:16:54 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:16:54 --> URI Class Initialized
DEBUG - 2011-04-19 18:16:54 --> Router Class Initialized
ERROR - 2011-04-19 18:16:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:17:12 --> Config Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:17:12 --> URI Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Router Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Output Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Input Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:17:12 --> Language Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Loader Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Controller Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:17:12 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:17:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 18:17:12 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:17:12 --> Final output sent to browser
DEBUG - 2011-04-19 18:17:12 --> Total execution time: 0.3408
DEBUG - 2011-04-19 18:17:13 --> Config Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:17:13 --> URI Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Router Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Output Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Input Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:17:13 --> Language Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Loader Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Controller Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:17:13 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 18:17:13 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:17:13 --> Final output sent to browser
DEBUG - 2011-04-19 18:17:13 --> Total execution time: 0.0694
DEBUG - 2011-04-19 18:17:13 --> Config Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:17:13 --> URI Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Router Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Output Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Input Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:17:13 --> Language Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Loader Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Controller Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Model Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:17:13 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 18:17:13 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:17:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:17:13 --> Final output sent to browser
DEBUG - 2011-04-19 18:17:13 --> Total execution time: 0.0649
DEBUG - 2011-04-19 18:17:13 --> Config Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:17:13 --> URI Class Initialized
DEBUG - 2011-04-19 18:17:13 --> Router Class Initialized
ERROR - 2011-04-19 18:17:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:42:32 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:32 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:32 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:32 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:32 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:32 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:32 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:32 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:32 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:32 --> Controller Class Initialized
ERROR - 2011-04-19 18:42:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:42:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:42:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:42:33 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:33 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:42:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:42:33 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:42:33 --> Final output sent to browser
DEBUG - 2011-04-19 18:42:33 --> Total execution time: 0.1349
DEBUG - 2011-04-19 18:42:33 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:33 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:33 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Controller Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:33 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:42:34 --> Final output sent to browser
DEBUG - 2011-04-19 18:42:34 --> Total execution time: 0.8210
DEBUG - 2011-04-19 18:42:35 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:35 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:35 --> Router Class Initialized
ERROR - 2011-04-19 18:42:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:42:36 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:36 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:36 --> Router Class Initialized
ERROR - 2011-04-19 18:42:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 18:42:43 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:43 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:43 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Controller Class Initialized
ERROR - 2011-04-19 18:42:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:42:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:42:43 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:43 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:42:43 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:42:43 --> Final output sent to browser
DEBUG - 2011-04-19 18:42:43 --> Total execution time: 0.0954
DEBUG - 2011-04-19 18:42:43 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:43 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:43 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Controller Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:43 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:42:44 --> Final output sent to browser
DEBUG - 2011-04-19 18:42:44 --> Total execution time: 0.6692
DEBUG - 2011-04-19 18:42:47 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:47 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:47 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Controller Class Initialized
ERROR - 2011-04-19 18:42:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:42:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:42:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:42:47 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:42:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:42:47 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:42:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:42:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:42:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:42:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:42:47 --> Final output sent to browser
DEBUG - 2011-04-19 18:42:47 --> Total execution time: 0.0782
DEBUG - 2011-04-19 18:42:47 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:47 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:47 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Controller Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:47 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:42:48 --> Final output sent to browser
DEBUG - 2011-04-19 18:42:48 --> Total execution time: 0.6023
DEBUG - 2011-04-19 18:42:51 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:51 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:51 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Controller Class Initialized
ERROR - 2011-04-19 18:42:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:42:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:42:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:42:51 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:51 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:42:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:42:51 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:42:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:42:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:42:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:42:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:42:51 --> Final output sent to browser
DEBUG - 2011-04-19 18:42:51 --> Total execution time: 0.0332
DEBUG - 2011-04-19 18:42:51 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:51 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:51 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Controller Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:51 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Config Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:42:59 --> URI Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Router Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Output Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Input Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:42:59 --> Language Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Loader Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Controller Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Model Class Initialized
DEBUG - 2011-04-19 18:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:42:59 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:43:00 --> Final output sent to browser
DEBUG - 2011-04-19 18:43:00 --> Total execution time: 0.6797
DEBUG - 2011-04-19 18:43:01 --> Config Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:43:01 --> URI Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Router Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Output Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Input Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:43:01 --> Language Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Loader Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Controller Class Initialized
ERROR - 2011-04-19 18:43:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:43:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:43:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:43:01 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:43:01 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:43:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:43:01 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:43:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:43:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:43:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:43:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:43:01 --> Final output sent to browser
DEBUG - 2011-04-19 18:43:01 --> Total execution time: 0.1896
DEBUG - 2011-04-19 18:43:02 --> Config Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:43:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:43:02 --> URI Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Router Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Output Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Input Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:43:02 --> Language Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Loader Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Controller Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:43:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:43:03 --> Final output sent to browser
DEBUG - 2011-04-19 18:43:03 --> Total execution time: 1.1946
DEBUG - 2011-04-19 18:43:10 --> Config Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:43:10 --> URI Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Router Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Output Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Input Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:43:10 --> Language Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Loader Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Controller Class Initialized
ERROR - 2011-04-19 18:43:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:43:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:43:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:43:10 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:43:10 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:43:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:43:10 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:43:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:43:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:43:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:43:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:43:10 --> Final output sent to browser
DEBUG - 2011-04-19 18:43:10 --> Total execution time: 0.1572
DEBUG - 2011-04-19 18:43:10 --> Config Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:43:10 --> URI Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Router Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Output Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Input Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:43:10 --> Language Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Loader Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Controller Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:43:10 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:43:11 --> Final output sent to browser
DEBUG - 2011-04-19 18:43:11 --> Total execution time: 0.6790
DEBUG - 2011-04-19 18:43:17 --> Config Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:43:17 --> URI Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Router Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Output Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Input Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:43:17 --> Language Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Loader Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Controller Class Initialized
ERROR - 2011-04-19 18:43:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 18:43:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 18:43:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:43:17 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:43:17 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:43:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 18:43:17 --> Helper loaded: url_helper
DEBUG - 2011-04-19 18:43:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 18:43:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 18:43:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 18:43:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 18:43:17 --> Final output sent to browser
DEBUG - 2011-04-19 18:43:17 --> Total execution time: 0.0973
DEBUG - 2011-04-19 18:43:17 --> Config Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 18:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 18:43:17 --> URI Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Router Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Output Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Input Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 18:43:17 --> Language Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Loader Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Controller Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Model Class Initialized
DEBUG - 2011-04-19 18:43:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 18:43:17 --> Database Driver Class Initialized
DEBUG - 2011-04-19 18:43:18 --> Final output sent to browser
DEBUG - 2011-04-19 18:43:18 --> Total execution time: 0.5247
DEBUG - 2011-04-19 19:53:20 --> Config Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Hooks Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Utf8 Class Initialized
DEBUG - 2011-04-19 19:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 19:53:20 --> URI Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Router Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Output Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Input Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 19:53:20 --> Language Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Loader Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Controller Class Initialized
ERROR - 2011-04-19 19:53:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 19:53:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 19:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 19:53:20 --> Model Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Model Class Initialized
DEBUG - 2011-04-19 19:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 19:53:20 --> Database Driver Class Initialized
DEBUG - 2011-04-19 19:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 19:53:20 --> Helper loaded: url_helper
DEBUG - 2011-04-19 19:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 19:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 19:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 19:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 19:53:20 --> Final output sent to browser
DEBUG - 2011-04-19 19:53:20 --> Total execution time: 0.4904
DEBUG - 2011-04-19 19:53:22 --> Config Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 19:53:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 19:53:22 --> URI Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Router Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Output Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Input Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 19:53:22 --> Language Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Loader Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Controller Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Model Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Model Class Initialized
DEBUG - 2011-04-19 19:53:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 19:53:22 --> Database Driver Class Initialized
DEBUG - 2011-04-19 19:53:23 --> Final output sent to browser
DEBUG - 2011-04-19 19:53:23 --> Total execution time: 0.8245
DEBUG - 2011-04-19 19:53:24 --> Config Class Initialized
DEBUG - 2011-04-19 19:53:24 --> Hooks Class Initialized
DEBUG - 2011-04-19 19:53:24 --> Utf8 Class Initialized
DEBUG - 2011-04-19 19:53:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 19:53:24 --> URI Class Initialized
DEBUG - 2011-04-19 19:53:24 --> Router Class Initialized
ERROR - 2011-04-19 19:53:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 19:53:26 --> Config Class Initialized
DEBUG - 2011-04-19 19:53:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 19:53:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 19:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 19:53:26 --> URI Class Initialized
DEBUG - 2011-04-19 19:53:26 --> Router Class Initialized
ERROR - 2011-04-19 19:53:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 20:43:25 --> Config Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 20:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 20:43:25 --> URI Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Router Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Output Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Input Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 20:43:25 --> Language Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Loader Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Controller Class Initialized
ERROR - 2011-04-19 20:43:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 20:43:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 20:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 20:43:25 --> Model Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Model Class Initialized
DEBUG - 2011-04-19 20:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 20:43:25 --> Database Driver Class Initialized
DEBUG - 2011-04-19 20:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 20:43:25 --> Helper loaded: url_helper
DEBUG - 2011-04-19 20:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 20:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 20:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 20:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 20:43:25 --> Final output sent to browser
DEBUG - 2011-04-19 20:43:25 --> Total execution time: 0.4160
DEBUG - 2011-04-19 20:43:27 --> Config Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 20:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 20:43:27 --> URI Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Router Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Output Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Input Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 20:43:27 --> Language Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Loader Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Controller Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Model Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Model Class Initialized
DEBUG - 2011-04-19 20:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 20:43:27 --> Database Driver Class Initialized
DEBUG - 2011-04-19 20:43:28 --> Final output sent to browser
DEBUG - 2011-04-19 20:43:28 --> Total execution time: 0.8982
DEBUG - 2011-04-19 20:43:30 --> Config Class Initialized
DEBUG - 2011-04-19 20:43:30 --> Hooks Class Initialized
DEBUG - 2011-04-19 20:43:30 --> Utf8 Class Initialized
DEBUG - 2011-04-19 20:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 20:43:30 --> URI Class Initialized
DEBUG - 2011-04-19 20:43:30 --> Router Class Initialized
ERROR - 2011-04-19 20:43:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 21:02:16 --> Config Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:02:16 --> URI Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Router Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Output Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Input Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:02:16 --> Language Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Loader Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Controller Class Initialized
ERROR - 2011-04-19 21:02:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:02:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:02:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:02:16 --> Model Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Model Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:02:16 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:02:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:02:16 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:02:16 --> Final output sent to browser
DEBUG - 2011-04-19 21:02:16 --> Total execution time: 0.1373
DEBUG - 2011-04-19 21:02:16 --> Config Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:02:16 --> URI Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Router Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Output Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Input Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:02:16 --> Language Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Loader Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Controller Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Model Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Model Class Initialized
DEBUG - 2011-04-19 21:02:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:02:16 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:02:18 --> Final output sent to browser
DEBUG - 2011-04-19 21:02:18 --> Total execution time: 1.4285
DEBUG - 2011-04-19 21:02:22 --> Config Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:02:22 --> URI Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Router Class Initialized
ERROR - 2011-04-19 21:02:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 21:02:22 --> Config Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:02:22 --> URI Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Router Class Initialized
ERROR - 2011-04-19 21:02:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 21:02:22 --> Config Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:02:22 --> URI Class Initialized
DEBUG - 2011-04-19 21:02:22 --> Router Class Initialized
ERROR - 2011-04-19 21:02:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 21:03:01 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:01 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:01 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Controller Class Initialized
ERROR - 2011-04-19 21:03:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:03:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:03:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:01 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:01 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:01 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:03:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:03:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:03:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:03:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:03:01 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:01 --> Total execution time: 0.0397
DEBUG - 2011-04-19 21:03:02 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:02 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:02 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Controller Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:02 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:03 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:03 --> Total execution time: 1.1006
DEBUG - 2011-04-19 21:03:09 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:09 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:09 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Controller Class Initialized
ERROR - 2011-04-19 21:03:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:03:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:03:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:09 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:09 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:09 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:03:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:03:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:03:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:03:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:03:09 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:09 --> Total execution time: 0.0673
DEBUG - 2011-04-19 21:03:09 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:09 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:09 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Controller Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:09 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:10 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:10 --> Total execution time: 0.8209
DEBUG - 2011-04-19 21:03:18 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:18 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:18 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Controller Class Initialized
ERROR - 2011-04-19 21:03:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:03:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:03:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:18 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:18 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:18 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:03:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:03:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:03:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:03:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:03:18 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:18 --> Total execution time: 0.0606
DEBUG - 2011-04-19 21:03:18 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:18 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:18 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Controller Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:18 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:19 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:19 --> Total execution time: 1.1132
DEBUG - 2011-04-19 21:03:27 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:27 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:27 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Controller Class Initialized
ERROR - 2011-04-19 21:03:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:03:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:27 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:27 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:27 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:03:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:03:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:03:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:03:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:03:27 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:27 --> Total execution time: 0.0673
DEBUG - 2011-04-19 21:03:28 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:28 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:28 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Controller Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:28 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:28 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:28 --> Total execution time: 0.6684
DEBUG - 2011-04-19 21:03:42 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:42 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:42 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Controller Class Initialized
ERROR - 2011-04-19 21:03:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:03:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:03:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:42 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:42 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:42 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:03:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:03:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:03:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:03:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:03:42 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:42 --> Total execution time: 0.0396
DEBUG - 2011-04-19 21:03:42 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:42 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:42 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Controller Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:42 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:43 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:43 --> Total execution time: 0.7346
DEBUG - 2011-04-19 21:03:50 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:50 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:50 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Controller Class Initialized
ERROR - 2011-04-19 21:03:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:03:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:50 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:50 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:50 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:03:50 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:50 --> Total execution time: 0.0338
DEBUG - 2011-04-19 21:03:51 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:51 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:51 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Controller Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:51 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:52 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:52 --> Total execution time: 0.5785
DEBUG - 2011-04-19 21:03:59 --> Config Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:03:59 --> URI Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Router Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Output Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Input Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:03:59 --> Language Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Loader Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Controller Class Initialized
ERROR - 2011-04-19 21:03:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:03:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:59 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Model Class Initialized
DEBUG - 2011-04-19 21:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:03:59 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:03:59 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:03:59 --> Final output sent to browser
DEBUG - 2011-04-19 21:03:59 --> Total execution time: 0.0293
DEBUG - 2011-04-19 21:04:00 --> Config Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:04:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:04:00 --> URI Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Router Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Output Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Input Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:04:00 --> Language Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Loader Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Controller Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:04:00 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:04:01 --> Final output sent to browser
DEBUG - 2011-04-19 21:04:01 --> Total execution time: 0.5107
DEBUG - 2011-04-19 21:04:18 --> Config Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:04:18 --> URI Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Router Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Output Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Input Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:04:18 --> Language Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Loader Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Controller Class Initialized
ERROR - 2011-04-19 21:04:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:04:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:04:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:04:18 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:04:18 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:04:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:04:18 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:04:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:04:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:04:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:04:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:04:18 --> Final output sent to browser
DEBUG - 2011-04-19 21:04:18 --> Total execution time: 0.0336
DEBUG - 2011-04-19 21:04:19 --> Config Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:04:19 --> URI Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Router Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Output Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Input Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:04:19 --> Language Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Loader Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Controller Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:04:19 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:04:20 --> Final output sent to browser
DEBUG - 2011-04-19 21:04:20 --> Total execution time: 0.8279
DEBUG - 2011-04-19 21:04:22 --> Config Class Initialized
DEBUG - 2011-04-19 21:04:22 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:04:22 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:04:22 --> URI Class Initialized
DEBUG - 2011-04-19 21:04:22 --> Router Class Initialized
ERROR - 2011-04-19 21:04:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 21:04:23 --> Config Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:04:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:04:23 --> URI Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Router Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Output Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Input Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:04:23 --> Language Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Loader Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Controller Class Initialized
ERROR - 2011-04-19 21:04:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:04:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:04:23 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:04:23 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:04:23 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:04:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:04:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:04:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:04:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:04:23 --> Final output sent to browser
DEBUG - 2011-04-19 21:04:23 --> Total execution time: 0.0339
DEBUG - 2011-04-19 21:04:25 --> Config Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:04:25 --> URI Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Router Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Output Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Input Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:04:25 --> Language Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Loader Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Controller Class Initialized
ERROR - 2011-04-19 21:04:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:04:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:04:25 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:04:25 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:04:25 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:04:25 --> Final output sent to browser
DEBUG - 2011-04-19 21:04:25 --> Total execution time: 0.0313
DEBUG - 2011-04-19 21:04:26 --> Config Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:04:26 --> URI Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Router Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Output Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Input Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:04:26 --> Language Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Loader Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Controller Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Model Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:04:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:04:26 --> Final output sent to browser
DEBUG - 2011-04-19 21:04:26 --> Total execution time: 0.5085
DEBUG - 2011-04-19 21:38:14 --> Config Class Initialized
DEBUG - 2011-04-19 21:38:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:38:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:38:14 --> URI Class Initialized
DEBUG - 2011-04-19 21:38:14 --> Router Class Initialized
ERROR - 2011-04-19 21:38:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 21:39:04 --> Config Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Hooks Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Utf8 Class Initialized
DEBUG - 2011-04-19 21:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 21:39:04 --> URI Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Router Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Output Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Input Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 21:39:04 --> Language Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Loader Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Controller Class Initialized
ERROR - 2011-04-19 21:39:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 21:39:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 21:39:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:39:04 --> Model Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Model Class Initialized
DEBUG - 2011-04-19 21:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 21:39:04 --> Database Driver Class Initialized
DEBUG - 2011-04-19 21:39:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 21:39:04 --> Helper loaded: url_helper
DEBUG - 2011-04-19 21:39:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 21:39:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 21:39:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 21:39:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 21:39:04 --> Final output sent to browser
DEBUG - 2011-04-19 21:39:04 --> Total execution time: 0.2292
DEBUG - 2011-04-19 22:36:17 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:17 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:17 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:17 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:17 --> Router Class Initialized
DEBUG - 2011-04-19 22:36:18 --> Output Class Initialized
DEBUG - 2011-04-19 22:36:18 --> Input Class Initialized
DEBUG - 2011-04-19 22:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:36:18 --> Language Class Initialized
DEBUG - 2011-04-19 22:36:22 --> Loader Class Initialized
DEBUG - 2011-04-19 22:36:22 --> Controller Class Initialized
ERROR - 2011-04-19 22:36:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:36:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:36:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:36:23 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:23 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:36:23 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:36:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:36:24 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:36:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:36:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:36:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:36:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:36:24 --> Final output sent to browser
DEBUG - 2011-04-19 22:36:24 --> Total execution time: 10.0565
DEBUG - 2011-04-19 22:36:29 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:29 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:29 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:29 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:29 --> Router Class Initialized
DEBUG - 2011-04-19 22:36:29 --> Output Class Initialized
DEBUG - 2011-04-19 22:36:29 --> Input Class Initialized
DEBUG - 2011-04-19 22:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:36:29 --> Language Class Initialized
DEBUG - 2011-04-19 22:36:29 --> Loader Class Initialized
DEBUG - 2011-04-19 22:36:29 --> Controller Class Initialized
DEBUG - 2011-04-19 22:36:30 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:31 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:36:31 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:36:32 --> Final output sent to browser
DEBUG - 2011-04-19 22:36:32 --> Total execution time: 3.1886
DEBUG - 2011-04-19 22:36:35 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:35 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:35 --> Router Class Initialized
ERROR - 2011-04-19 22:36:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 22:36:44 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:44 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Router Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Output Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Input Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:36:44 --> Language Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Loader Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Controller Class Initialized
ERROR - 2011-04-19 22:36:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:36:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:36:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:36:44 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:36:44 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:36:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:36:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:36:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:36:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:36:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:36:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:36:44 --> Final output sent to browser
DEBUG - 2011-04-19 22:36:44 --> Total execution time: 0.0811
DEBUG - 2011-04-19 22:36:46 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:46 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Router Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Output Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Input Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:36:46 --> Language Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Loader Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Controller Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:36:46 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:36:47 --> Final output sent to browser
DEBUG - 2011-04-19 22:36:47 --> Total execution time: 0.8235
DEBUG - 2011-04-19 22:36:49 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:49 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:49 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:49 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:49 --> Router Class Initialized
ERROR - 2011-04-19 22:36:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 22:36:50 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:50 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Router Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Output Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Input Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:36:50 --> Language Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Loader Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Controller Class Initialized
ERROR - 2011-04-19 22:36:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:36:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:36:50 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:36:50 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:36:50 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:36:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:36:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:36:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:36:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:36:50 --> Final output sent to browser
DEBUG - 2011-04-19 22:36:50 --> Total execution time: 0.0703
DEBUG - 2011-04-19 22:36:57 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:57 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Router Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Output Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Input Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:36:57 --> Language Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Loader Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Controller Class Initialized
ERROR - 2011-04-19 22:36:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:36:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:36:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:36:57 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:36:57 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:36:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:36:57 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:36:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:36:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:36:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:36:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:36:57 --> Final output sent to browser
DEBUG - 2011-04-19 22:36:57 --> Total execution time: 0.0295
DEBUG - 2011-04-19 22:36:58 --> Config Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:36:58 --> URI Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Router Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Output Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Input Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:36:58 --> Language Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Loader Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Controller Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Model Class Initialized
DEBUG - 2011-04-19 22:36:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:36:58 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:36:59 --> Final output sent to browser
DEBUG - 2011-04-19 22:36:59 --> Total execution time: 0.5893
DEBUG - 2011-04-19 22:37:01 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:01 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:01 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:01 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:01 --> Router Class Initialized
ERROR - 2011-04-19 22:37:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 22:37:05 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:05 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:05 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Controller Class Initialized
ERROR - 2011-04-19 22:37:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:37:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:37:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:05 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:05 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:05 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:37:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:37:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:37:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:37:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:37:05 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:05 --> Total execution time: 0.0379
DEBUG - 2011-04-19 22:37:06 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:06 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:06 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Controller Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:06 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:07 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:07 --> Total execution time: 0.5259
DEBUG - 2011-04-19 22:37:08 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:08 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:08 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:08 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:08 --> Router Class Initialized
ERROR - 2011-04-19 22:37:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 22:37:10 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:10 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:10 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Controller Class Initialized
ERROR - 2011-04-19 22:37:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:37:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:10 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:10 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:10 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:37:10 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:10 --> Total execution time: 0.1573
DEBUG - 2011-04-19 22:37:14 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:14 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:14 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Controller Class Initialized
ERROR - 2011-04-19 22:37:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:37:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:37:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:14 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:14 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:14 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:37:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:37:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:37:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:37:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:37:14 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:14 --> Total execution time: 0.0492
DEBUG - 2011-04-19 22:37:15 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:15 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:15 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Controller Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:15 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:16 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:16 --> Total execution time: 0.5956
DEBUG - 2011-04-19 22:37:18 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:18 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:18 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:18 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:18 --> Router Class Initialized
ERROR - 2011-04-19 22:37:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 22:37:26 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:26 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:26 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Controller Class Initialized
ERROR - 2011-04-19 22:37:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:37:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:37:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:26 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:26 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:26 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:37:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:37:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:37:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:37:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:37:26 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:26 --> Total execution time: 0.0379
DEBUG - 2011-04-19 22:37:28 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:28 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:28 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Controller Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:28 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:29 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:29 --> Total execution time: 0.5972
DEBUG - 2011-04-19 22:37:31 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:31 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:31 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:31 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:31 --> Router Class Initialized
ERROR - 2011-04-19 22:37:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 22:37:36 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:36 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:36 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Controller Class Initialized
ERROR - 2011-04-19 22:37:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 22:37:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 22:37:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:36 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:36 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 22:37:36 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:37:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:37:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:37:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:37:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:37:36 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:36 --> Total execution time: 0.0329
DEBUG - 2011-04-19 22:37:38 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:38 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Router Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Output Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Input Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:37:38 --> Language Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Loader Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Controller Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Model Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:37:38 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:37:38 --> Final output sent to browser
DEBUG - 2011-04-19 22:37:38 --> Total execution time: 0.5460
DEBUG - 2011-04-19 22:37:40 --> Config Class Initialized
DEBUG - 2011-04-19 22:37:40 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:37:40 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:37:40 --> URI Class Initialized
DEBUG - 2011-04-19 22:37:40 --> Router Class Initialized
ERROR - 2011-04-19 22:37:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-19 22:50:25 --> Config Class Initialized
DEBUG - 2011-04-19 22:50:25 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:50:25 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:50:25 --> URI Class Initialized
DEBUG - 2011-04-19 22:50:25 --> Router Class Initialized
ERROR - 2011-04-19 22:50:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-19 22:50:35 --> Config Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Hooks Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Utf8 Class Initialized
DEBUG - 2011-04-19 22:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 22:50:35 --> URI Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Router Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Output Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Input Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 22:50:35 --> Language Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Loader Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Controller Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Model Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Model Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Model Class Initialized
DEBUG - 2011-04-19 22:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 22:50:35 --> Database Driver Class Initialized
DEBUG - 2011-04-19 22:50:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-19 22:50:35 --> Helper loaded: url_helper
DEBUG - 2011-04-19 22:50:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 22:50:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 22:50:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 22:50:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 22:50:35 --> Final output sent to browser
DEBUG - 2011-04-19 22:50:35 --> Total execution time: 0.2662
DEBUG - 2011-04-19 23:05:44 --> Config Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Hooks Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Utf8 Class Initialized
DEBUG - 2011-04-19 23:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 23:05:44 --> URI Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Router Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Output Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Input Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 23:05:44 --> Language Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Loader Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Controller Class Initialized
ERROR - 2011-04-19 23:05:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-19 23:05:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-19 23:05:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 23:05:44 --> Model Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Model Class Initialized
DEBUG - 2011-04-19 23:05:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 23:05:44 --> Database Driver Class Initialized
DEBUG - 2011-04-19 23:05:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-19 23:05:44 --> Helper loaded: url_helper
DEBUG - 2011-04-19 23:05:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-19 23:05:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-19 23:05:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-19 23:05:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-19 23:05:44 --> Final output sent to browser
DEBUG - 2011-04-19 23:05:44 --> Total execution time: 0.0538
DEBUG - 2011-04-19 23:05:46 --> Config Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Hooks Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Utf8 Class Initialized
DEBUG - 2011-04-19 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 23:05:46 --> URI Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Router Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Output Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Input Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-19 23:05:46 --> Language Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Loader Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Controller Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Model Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Model Class Initialized
DEBUG - 2011-04-19 23:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-19 23:05:46 --> Database Driver Class Initialized
DEBUG - 2011-04-19 23:05:47 --> Final output sent to browser
DEBUG - 2011-04-19 23:05:47 --> Total execution time: 0.6767
DEBUG - 2011-04-19 23:05:48 --> Config Class Initialized
DEBUG - 2011-04-19 23:05:48 --> Hooks Class Initialized
DEBUG - 2011-04-19 23:05:48 --> Utf8 Class Initialized
DEBUG - 2011-04-19 23:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-19 23:05:48 --> URI Class Initialized
DEBUG - 2011-04-19 23:05:48 --> Router Class Initialized
ERROR - 2011-04-19 23:05:48 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-28 01:10:08 --> Config Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Hooks Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Utf8 Class Initialized
DEBUG - 2011-06-28 01:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 01:10:08 --> URI Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Router Class Initialized
ERROR - 2011-06-28 01:10:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-28 01:10:08 --> Config Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Hooks Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Utf8 Class Initialized
DEBUG - 2011-06-28 01:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 01:10:08 --> URI Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Router Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Output Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Input Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 01:10:08 --> Language Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Loader Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Controller Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Model Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Model Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Model Class Initialized
DEBUG - 2011-06-28 01:10:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 01:10:08 --> Database Driver Class Initialized
DEBUG - 2011-06-28 01:10:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 01:10:09 --> Helper loaded: url_helper
DEBUG - 2011-06-28 01:10:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 01:10:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 01:10:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 01:10:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 01:10:09 --> Final output sent to browser
DEBUG - 2011-06-28 01:10:09 --> Total execution time: 0.4993
DEBUG - 2011-06-28 01:10:39 --> Config Class Initialized
DEBUG - 2011-06-28 01:10:39 --> Hooks Class Initialized
DEBUG - 2011-06-28 01:10:39 --> Utf8 Class Initialized
DEBUG - 2011-06-28 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 01:10:39 --> URI Class Initialized
DEBUG - 2011-06-28 01:10:39 --> Router Class Initialized
DEBUG - 2011-06-28 01:10:39 --> Output Class Initialized
DEBUG - 2011-06-28 01:10:39 --> Input Class Initialized
DEBUG - 2011-06-28 01:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 01:10:39 --> Language Class Initialized
DEBUG - 2011-06-28 01:10:39 --> Loader Class Initialized
DEBUG - 2011-06-28 01:10:39 --> Controller Class Initialized
ERROR - 2011-06-28 01:10:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 01:10:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 01:10:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 01:10:40 --> Model Class Initialized
DEBUG - 2011-06-28 01:10:40 --> Model Class Initialized
DEBUG - 2011-06-28 01:10:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 01:10:40 --> Database Driver Class Initialized
DEBUG - 2011-06-28 01:10:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 01:10:40 --> Helper loaded: url_helper
DEBUG - 2011-06-28 01:10:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 01:10:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 01:10:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 01:10:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 01:10:40 --> Final output sent to browser
DEBUG - 2011-06-28 01:10:40 --> Total execution time: 0.9351
DEBUG - 2011-06-28 02:07:32 --> Config Class Initialized
DEBUG - 2011-06-28 02:07:32 --> Hooks Class Initialized
DEBUG - 2011-06-28 02:07:32 --> Utf8 Class Initialized
DEBUG - 2011-06-28 02:07:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 02:07:32 --> URI Class Initialized
DEBUG - 2011-06-28 02:07:32 --> Router Class Initialized
ERROR - 2011-06-28 02:07:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-28 02:10:18 --> Config Class Initialized
DEBUG - 2011-06-28 02:10:18 --> Hooks Class Initialized
DEBUG - 2011-06-28 02:10:18 --> Utf8 Class Initialized
DEBUG - 2011-06-28 02:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 02:10:18 --> URI Class Initialized
DEBUG - 2011-06-28 02:10:18 --> Router Class Initialized
DEBUG - 2011-06-28 02:10:19 --> Output Class Initialized
DEBUG - 2011-06-28 02:10:19 --> Input Class Initialized
DEBUG - 2011-06-28 02:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 02:10:19 --> Language Class Initialized
DEBUG - 2011-06-28 02:10:19 --> Loader Class Initialized
DEBUG - 2011-06-28 02:10:19 --> Controller Class Initialized
ERROR - 2011-06-28 02:10:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 02:10:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 02:10:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 02:10:19 --> Model Class Initialized
DEBUG - 2011-06-28 02:10:19 --> Model Class Initialized
DEBUG - 2011-06-28 02:10:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 02:10:19 --> Database Driver Class Initialized
DEBUG - 2011-06-28 02:10:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 02:10:20 --> Helper loaded: url_helper
DEBUG - 2011-06-28 02:10:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 02:10:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 02:10:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 02:10:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 02:10:20 --> Final output sent to browser
DEBUG - 2011-06-28 02:10:20 --> Total execution time: 1.6650
DEBUG - 2011-06-28 03:13:27 --> Config Class Initialized
DEBUG - 2011-06-28 03:13:27 --> Hooks Class Initialized
DEBUG - 2011-06-28 03:13:27 --> Utf8 Class Initialized
DEBUG - 2011-06-28 03:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 03:13:27 --> URI Class Initialized
DEBUG - 2011-06-28 03:13:27 --> Router Class Initialized
DEBUG - 2011-06-28 03:13:27 --> No URI present. Default controller set.
DEBUG - 2011-06-28 03:13:27 --> Output Class Initialized
DEBUG - 2011-06-28 03:13:27 --> Input Class Initialized
DEBUG - 2011-06-28 03:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 03:13:27 --> Language Class Initialized
DEBUG - 2011-06-28 03:13:27 --> Loader Class Initialized
DEBUG - 2011-06-28 03:13:27 --> Controller Class Initialized
DEBUG - 2011-06-28 03:13:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-28 03:13:27 --> Helper loaded: url_helper
DEBUG - 2011-06-28 03:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 03:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 03:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 03:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 03:13:27 --> Final output sent to browser
DEBUG - 2011-06-28 03:13:27 --> Total execution time: 0.4228
DEBUG - 2011-06-28 03:27:46 --> Config Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Hooks Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Utf8 Class Initialized
DEBUG - 2011-06-28 03:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 03:27:46 --> URI Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Router Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Output Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Input Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 03:27:46 --> Language Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Loader Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Controller Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Model Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Model Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Model Class Initialized
DEBUG - 2011-06-28 03:27:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 03:27:46 --> Database Driver Class Initialized
DEBUG - 2011-06-28 03:27:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 03:27:47 --> Helper loaded: url_helper
DEBUG - 2011-06-28 03:27:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 03:27:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 03:27:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 03:27:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 03:27:47 --> Final output sent to browser
DEBUG - 2011-06-28 03:27:47 --> Total execution time: 1.0487
DEBUG - 2011-06-28 03:27:48 --> Config Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Hooks Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Utf8 Class Initialized
DEBUG - 2011-06-28 03:27:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 03:27:48 --> URI Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Router Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Output Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Input Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 03:27:48 --> Language Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Loader Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Controller Class Initialized
ERROR - 2011-06-28 03:27:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 03:27:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 03:27:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 03:27:48 --> Model Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Model Class Initialized
DEBUG - 2011-06-28 03:27:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 03:27:48 --> Database Driver Class Initialized
DEBUG - 2011-06-28 03:27:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 03:27:48 --> Helper loaded: url_helper
DEBUG - 2011-06-28 03:27:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 03:27:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 03:27:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 03:27:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 03:27:48 --> Final output sent to browser
DEBUG - 2011-06-28 03:27:48 --> Total execution time: 0.0885
DEBUG - 2011-06-28 04:14:31 --> Config Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 04:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 04:14:31 --> URI Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Router Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Output Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Input Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 04:14:31 --> Language Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Loader Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Controller Class Initialized
ERROR - 2011-06-28 04:14:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 04:14:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 04:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 04:14:31 --> Model Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Model Class Initialized
DEBUG - 2011-06-28 04:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 04:14:31 --> Database Driver Class Initialized
DEBUG - 2011-06-28 04:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 04:14:31 --> Helper loaded: url_helper
DEBUG - 2011-06-28 04:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 04:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 04:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 04:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 04:14:31 --> Final output sent to browser
DEBUG - 2011-06-28 04:14:31 --> Total execution time: 0.4519
DEBUG - 2011-06-28 04:14:33 --> Config Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Hooks Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Utf8 Class Initialized
DEBUG - 2011-06-28 04:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 04:14:33 --> URI Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Router Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Output Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Input Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 04:14:33 --> Language Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Loader Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Controller Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Model Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Model Class Initialized
DEBUG - 2011-06-28 04:14:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 04:14:33 --> Database Driver Class Initialized
DEBUG - 2011-06-28 04:14:35 --> Final output sent to browser
DEBUG - 2011-06-28 04:14:35 --> Total execution time: 1.7550
DEBUG - 2011-06-28 04:14:36 --> Config Class Initialized
DEBUG - 2011-06-28 04:14:36 --> Hooks Class Initialized
DEBUG - 2011-06-28 04:14:36 --> Utf8 Class Initialized
DEBUG - 2011-06-28 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 04:14:36 --> URI Class Initialized
DEBUG - 2011-06-28 04:14:36 --> Router Class Initialized
ERROR - 2011-06-28 04:14:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 05:22:28 --> Config Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Hooks Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Utf8 Class Initialized
DEBUG - 2011-06-28 05:22:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 05:22:28 --> URI Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Router Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Output Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Input Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 05:22:28 --> Language Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Loader Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Controller Class Initialized
ERROR - 2011-06-28 05:22:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 05:22:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 05:22:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 05:22:28 --> Model Class Initialized
DEBUG - 2011-06-28 05:22:28 --> Model Class Initialized
DEBUG - 2011-06-28 05:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 05:22:29 --> Database Driver Class Initialized
DEBUG - 2011-06-28 05:22:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 05:22:29 --> Helper loaded: url_helper
DEBUG - 2011-06-28 05:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 05:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 05:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 05:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 05:22:29 --> Final output sent to browser
DEBUG - 2011-06-28 05:22:29 --> Total execution time: 0.4478
DEBUG - 2011-06-28 05:22:30 --> Config Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Hooks Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Utf8 Class Initialized
DEBUG - 2011-06-28 05:22:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 05:22:30 --> URI Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Router Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Output Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Input Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 05:22:30 --> Language Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Loader Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Controller Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Model Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Model Class Initialized
DEBUG - 2011-06-28 05:22:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 05:22:30 --> Database Driver Class Initialized
DEBUG - 2011-06-28 05:22:31 --> Final output sent to browser
DEBUG - 2011-06-28 05:22:31 --> Total execution time: 1.1546
DEBUG - 2011-06-28 05:22:32 --> Config Class Initialized
DEBUG - 2011-06-28 05:22:32 --> Hooks Class Initialized
DEBUG - 2011-06-28 05:22:32 --> Utf8 Class Initialized
DEBUG - 2011-06-28 05:22:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 05:22:32 --> URI Class Initialized
DEBUG - 2011-06-28 05:22:32 --> Router Class Initialized
ERROR - 2011-06-28 05:22:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 05:38:47 --> Config Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Hooks Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Utf8 Class Initialized
DEBUG - 2011-06-28 05:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 05:38:47 --> URI Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Router Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Output Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Input Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 05:38:47 --> Language Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Loader Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Controller Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Model Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Model Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Model Class Initialized
DEBUG - 2011-06-28 05:38:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 05:38:47 --> Database Driver Class Initialized
DEBUG - 2011-06-28 05:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 05:38:50 --> Helper loaded: url_helper
DEBUG - 2011-06-28 05:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 05:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 05:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 05:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 05:38:50 --> Final output sent to browser
DEBUG - 2011-06-28 05:38:50 --> Total execution time: 2.8237
DEBUG - 2011-06-28 05:38:58 --> Config Class Initialized
DEBUG - 2011-06-28 05:38:58 --> Hooks Class Initialized
DEBUG - 2011-06-28 05:38:58 --> Utf8 Class Initialized
DEBUG - 2011-06-28 05:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 05:38:58 --> URI Class Initialized
DEBUG - 2011-06-28 05:38:58 --> Router Class Initialized
ERROR - 2011-06-28 05:38:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 05:38:59 --> Config Class Initialized
DEBUG - 2011-06-28 05:38:59 --> Hooks Class Initialized
DEBUG - 2011-06-28 05:38:59 --> Utf8 Class Initialized
DEBUG - 2011-06-28 05:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 05:38:59 --> URI Class Initialized
DEBUG - 2011-06-28 05:38:59 --> Router Class Initialized
ERROR - 2011-06-28 05:38:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 05:39:17 --> Config Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Hooks Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Utf8 Class Initialized
DEBUG - 2011-06-28 05:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 05:39:17 --> URI Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Router Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Output Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Input Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 05:39:17 --> Language Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Loader Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Controller Class Initialized
ERROR - 2011-06-28 05:39:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 05:39:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 05:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 05:39:17 --> Model Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Model Class Initialized
DEBUG - 2011-06-28 05:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 05:39:17 --> Database Driver Class Initialized
DEBUG - 2011-06-28 05:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 05:39:17 --> Helper loaded: url_helper
DEBUG - 2011-06-28 05:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 05:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 05:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 05:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 05:39:17 --> Final output sent to browser
DEBUG - 2011-06-28 05:39:17 --> Total execution time: 0.1443
DEBUG - 2011-06-28 05:39:19 --> Config Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Hooks Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Utf8 Class Initialized
DEBUG - 2011-06-28 05:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 05:39:19 --> URI Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Router Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Output Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Input Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 05:39:19 --> Language Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Loader Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Controller Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Model Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Model Class Initialized
DEBUG - 2011-06-28 05:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 05:39:19 --> Database Driver Class Initialized
DEBUG - 2011-06-28 05:39:20 --> Final output sent to browser
DEBUG - 2011-06-28 05:39:20 --> Total execution time: 0.9199
DEBUG - 2011-06-28 06:01:15 --> Config Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:01:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:01:15 --> URI Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Router Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Output Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Input Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:01:15 --> Language Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Loader Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Controller Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:01:15 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:01:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:01:15 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:01:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:01:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:01:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:01:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:01:15 --> Final output sent to browser
DEBUG - 2011-06-28 06:01:15 --> Total execution time: 0.3996
DEBUG - 2011-06-28 06:01:39 --> Config Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:01:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:01:39 --> URI Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Router Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Output Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Input Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:01:39 --> Language Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Loader Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Controller Class Initialized
ERROR - 2011-06-28 06:01:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 06:01:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 06:01:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 06:01:39 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:01:39 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:01:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 06:01:39 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:01:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:01:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:01:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:01:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:01:39 --> Final output sent to browser
DEBUG - 2011-06-28 06:01:39 --> Total execution time: 0.1107
DEBUG - 2011-06-28 06:01:40 --> Config Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:01:40 --> URI Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Router Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Output Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Input Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:01:40 --> Language Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Loader Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Controller Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:01:40 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:01:41 --> Final output sent to browser
DEBUG - 2011-06-28 06:01:41 --> Total execution time: 0.5624
DEBUG - 2011-06-28 06:01:42 --> Config Class Initialized
DEBUG - 2011-06-28 06:01:42 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:01:42 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:01:42 --> URI Class Initialized
DEBUG - 2011-06-28 06:01:42 --> Router Class Initialized
ERROR - 2011-06-28 06:01:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 06:01:42 --> Config Class Initialized
DEBUG - 2011-06-28 06:01:42 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:01:42 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:01:42 --> URI Class Initialized
DEBUG - 2011-06-28 06:01:42 --> Router Class Initialized
ERROR - 2011-06-28 06:01:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 06:01:45 --> Config Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:01:45 --> URI Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Router Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Output Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Input Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:01:45 --> Language Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Loader Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Controller Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Model Class Initialized
DEBUG - 2011-06-28 06:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:01:45 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:01:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:01:45 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:01:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:01:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:01:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:01:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:01:45 --> Final output sent to browser
DEBUG - 2011-06-28 06:01:45 --> Total execution time: 0.3035
DEBUG - 2011-06-28 06:02:19 --> Config Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:02:19 --> URI Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Router Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Output Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Input Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:02:19 --> Language Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Loader Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Controller Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:02:19 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:02:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:02:22 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:02:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:02:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:02:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:02:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:02:22 --> Final output sent to browser
DEBUG - 2011-06-28 06:02:22 --> Total execution time: 2.2482
DEBUG - 2011-06-28 06:02:28 --> Config Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:02:28 --> URI Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Router Class Initialized
ERROR - 2011-06-28 06:02:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-28 06:02:28 --> Config Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:02:28 --> URI Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Router Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Output Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Input Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:02:28 --> Language Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Loader Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Controller Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:02:28 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:02:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:02:28 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:02:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:02:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:02:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:02:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:02:28 --> Final output sent to browser
DEBUG - 2011-06-28 06:02:28 --> Total execution time: 0.0422
DEBUG - 2011-06-28 06:02:34 --> Config Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:02:34 --> URI Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Router Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Output Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Input Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:02:34 --> Language Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Loader Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Controller Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Model Class Initialized
DEBUG - 2011-06-28 06:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:02:34 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:02:34 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:02:34 --> Final output sent to browser
DEBUG - 2011-06-28 06:02:34 --> Total execution time: 0.0477
DEBUG - 2011-06-28 06:03:01 --> Config Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:03:01 --> URI Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Router Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Output Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Input Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:03:01 --> Language Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Loader Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Controller Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:03:01 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:03:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:03:02 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:03:02 --> Final output sent to browser
DEBUG - 2011-06-28 06:03:02 --> Total execution time: 0.8186
DEBUG - 2011-06-28 06:03:21 --> Config Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:03:21 --> URI Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Router Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Output Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Input Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:03:21 --> Language Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Loader Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Controller Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:03:21 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:03:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:03:21 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:03:21 --> Final output sent to browser
DEBUG - 2011-06-28 06:03:21 --> Total execution time: 0.4453
DEBUG - 2011-06-28 06:03:22 --> Config Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:03:22 --> URI Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Router Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Output Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Input Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:03:22 --> Language Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Loader Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Controller Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:03:22 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:03:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:03:22 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:03:22 --> Final output sent to browser
DEBUG - 2011-06-28 06:03:22 --> Total execution time: 0.0564
DEBUG - 2011-06-28 06:03:30 --> Config Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:03:30 --> URI Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Router Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Output Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Input Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:03:30 --> Language Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Loader Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Controller Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Model Class Initialized
DEBUG - 2011-06-28 06:03:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:03:30 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:03:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:03:30 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:03:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:03:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:03:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:03:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:03:30 --> Final output sent to browser
DEBUG - 2011-06-28 06:03:30 --> Total execution time: 0.0746
DEBUG - 2011-06-28 06:04:43 --> Config Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:04:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:04:43 --> URI Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Router Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Output Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Input Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:04:43 --> Language Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Loader Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Controller Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Model Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Model Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Model Class Initialized
DEBUG - 2011-06-28 06:04:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:04:43 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:04:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:04:44 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:04:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:04:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:04:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:04:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:04:44 --> Final output sent to browser
DEBUG - 2011-06-28 06:04:44 --> Total execution time: 0.2416
DEBUG - 2011-06-28 06:05:15 --> Config Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:05:15 --> URI Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Router Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Output Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Input Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:05:15 --> Language Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Loader Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Controller Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Model Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Model Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Model Class Initialized
DEBUG - 2011-06-28 06:05:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:05:15 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:05:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:05:15 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:05:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:05:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:05:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:05:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:05:15 --> Final output sent to browser
DEBUG - 2011-06-28 06:05:15 --> Total execution time: 0.0491
DEBUG - 2011-06-28 06:05:48 --> Config Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:05:48 --> URI Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Router Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Output Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Input Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:05:48 --> Language Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Loader Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Controller Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Model Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Model Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Model Class Initialized
DEBUG - 2011-06-28 06:05:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:05:48 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:05:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:05:48 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:05:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:05:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:05:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:05:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:05:48 --> Final output sent to browser
DEBUG - 2011-06-28 06:05:48 --> Total execution time: 0.3241
DEBUG - 2011-06-28 06:06:02 --> Config Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:06:02 --> URI Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Router Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Output Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Input Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:06:02 --> Language Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Loader Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Controller Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:06:02 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:06:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:06:02 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:06:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:06:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:06:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:06:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:06:02 --> Final output sent to browser
DEBUG - 2011-06-28 06:06:02 --> Total execution time: 0.3434
DEBUG - 2011-06-28 06:06:21 --> Config Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:06:21 --> URI Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Router Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Output Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Input Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:06:21 --> Language Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Loader Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Controller Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:06:21 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:06:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:06:21 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:06:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:06:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:06:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:06:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:06:21 --> Final output sent to browser
DEBUG - 2011-06-28 06:06:21 --> Total execution time: 0.1962
DEBUG - 2011-06-28 06:06:35 --> Config Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:06:35 --> URI Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Router Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Output Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Input Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:06:35 --> Language Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Loader Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Controller Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:06:35 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:06:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:06:35 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:06:35 --> Final output sent to browser
DEBUG - 2011-06-28 06:06:35 --> Total execution time: 0.2442
DEBUG - 2011-06-28 06:06:39 --> Config Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:06:39 --> URI Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Router Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Output Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Input Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:06:39 --> Language Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Loader Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Controller Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:06:39 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:06:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:06:39 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:06:39 --> Final output sent to browser
DEBUG - 2011-06-28 06:06:39 --> Total execution time: 0.0490
DEBUG - 2011-06-28 06:06:47 --> Config Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:06:47 --> URI Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Router Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Output Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Input Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:06:47 --> Language Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Loader Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Controller Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Model Class Initialized
DEBUG - 2011-06-28 06:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:06:47 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:06:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:06:48 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:06:48 --> Final output sent to browser
DEBUG - 2011-06-28 06:06:48 --> Total execution time: 0.3030
DEBUG - 2011-06-28 06:07:01 --> Config Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:07:01 --> URI Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Router Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Output Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Input Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:07:01 --> Language Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Loader Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Controller Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:07:01 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:07:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:07:01 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:07:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:07:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:07:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:07:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:07:01 --> Final output sent to browser
DEBUG - 2011-06-28 06:07:01 --> Total execution time: 0.0567
DEBUG - 2011-06-28 06:07:12 --> Config Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:07:12 --> URI Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Router Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Output Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Input Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:07:12 --> Language Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Loader Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Controller Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:07:12 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:07:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:07:12 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:07:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:07:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:07:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:07:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:07:12 --> Final output sent to browser
DEBUG - 2011-06-28 06:07:12 --> Total execution time: 0.0964
DEBUG - 2011-06-28 06:07:13 --> Config Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:07:13 --> URI Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Router Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Output Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Input Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:07:13 --> Language Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Loader Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Controller Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:07:13 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:07:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:07:13 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:07:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:07:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:07:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:07:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:07:13 --> Final output sent to browser
DEBUG - 2011-06-28 06:07:13 --> Total execution time: 0.0447
DEBUG - 2011-06-28 06:07:20 --> Config Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:07:20 --> URI Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Router Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Output Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Input Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:07:20 --> Language Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Loader Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Controller Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:07:20 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:07:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:07:20 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:07:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:07:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:07:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:07:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:07:20 --> Final output sent to browser
DEBUG - 2011-06-28 06:07:20 --> Total execution time: 0.0494
DEBUG - 2011-06-28 06:07:22 --> Config Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:07:22 --> URI Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Router Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Output Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Input Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:07:22 --> Language Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Loader Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Controller Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:07:22 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:07:22 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:07:22 --> Final output sent to browser
DEBUG - 2011-06-28 06:07:22 --> Total execution time: 0.0448
DEBUG - 2011-06-28 06:07:22 --> Config Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:07:22 --> URI Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Router Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Output Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Input Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:07:22 --> Language Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Loader Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Controller Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:07:22 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:07:22 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:07:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:07:22 --> Final output sent to browser
DEBUG - 2011-06-28 06:07:22 --> Total execution time: 0.0446
DEBUG - 2011-06-28 06:07:23 --> Config Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:07:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:07:23 --> URI Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Router Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Output Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Input Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:07:23 --> Language Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Loader Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Controller Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Model Class Initialized
DEBUG - 2011-06-28 06:07:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:07:23 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:07:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 06:07:23 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:07:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:07:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:07:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:07:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:07:23 --> Final output sent to browser
DEBUG - 2011-06-28 06:07:23 --> Total execution time: 0.0427
DEBUG - 2011-06-28 06:30:58 --> Config Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:30:58 --> URI Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Router Class Initialized
ERROR - 2011-06-28 06:30:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-28 06:30:58 --> Config Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:30:58 --> URI Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Router Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Output Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Input Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:30:58 --> Language Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Loader Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Controller Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Model Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Model Class Initialized
DEBUG - 2011-06-28 06:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:30:58 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:30:59 --> Final output sent to browser
DEBUG - 2011-06-28 06:30:59 --> Total execution time: 1.0232
DEBUG - 2011-06-28 06:31:00 --> Config Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 06:31:00 --> URI Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Router Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Output Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Input Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 06:31:00 --> Language Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Loader Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Controller Class Initialized
ERROR - 2011-06-28 06:31:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 06:31:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 06:31:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 06:31:00 --> Model Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Model Class Initialized
DEBUG - 2011-06-28 06:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 06:31:00 --> Database Driver Class Initialized
DEBUG - 2011-06-28 06:31:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 06:31:00 --> Helper loaded: url_helper
DEBUG - 2011-06-28 06:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 06:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 06:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 06:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 06:31:00 --> Final output sent to browser
DEBUG - 2011-06-28 06:31:00 --> Total execution time: 0.2232
DEBUG - 2011-06-28 07:33:04 --> Config Class Initialized
DEBUG - 2011-06-28 07:33:04 --> Hooks Class Initialized
DEBUG - 2011-06-28 07:33:04 --> Utf8 Class Initialized
DEBUG - 2011-06-28 07:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 07:33:04 --> URI Class Initialized
DEBUG - 2011-06-28 07:33:04 --> Router Class Initialized
ERROR - 2011-06-28 07:33:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-28 07:34:42 --> Config Class Initialized
DEBUG - 2011-06-28 07:34:42 --> Hooks Class Initialized
DEBUG - 2011-06-28 07:34:42 --> Utf8 Class Initialized
DEBUG - 2011-06-28 07:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 07:34:43 --> URI Class Initialized
DEBUG - 2011-06-28 07:34:43 --> Router Class Initialized
DEBUG - 2011-06-28 07:34:43 --> No URI present. Default controller set.
DEBUG - 2011-06-28 07:34:43 --> Output Class Initialized
DEBUG - 2011-06-28 07:34:43 --> Input Class Initialized
DEBUG - 2011-06-28 07:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 07:34:43 --> Language Class Initialized
DEBUG - 2011-06-28 07:34:43 --> Loader Class Initialized
DEBUG - 2011-06-28 07:34:43 --> Controller Class Initialized
DEBUG - 2011-06-28 07:34:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-28 07:34:43 --> Helper loaded: url_helper
DEBUG - 2011-06-28 07:34:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 07:34:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 07:34:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 07:34:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 07:34:43 --> Final output sent to browser
DEBUG - 2011-06-28 07:34:43 --> Total execution time: 0.2844
DEBUG - 2011-06-28 08:55:55 --> Config Class Initialized
DEBUG - 2011-06-28 08:55:55 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:55:55 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:55:55 --> URI Class Initialized
DEBUG - 2011-06-28 08:55:55 --> Router Class Initialized
DEBUG - 2011-06-28 08:55:55 --> Output Class Initialized
DEBUG - 2011-06-28 08:55:55 --> Input Class Initialized
DEBUG - 2011-06-28 08:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 08:55:55 --> Language Class Initialized
DEBUG - 2011-06-28 08:55:56 --> Loader Class Initialized
DEBUG - 2011-06-28 08:55:56 --> Controller Class Initialized
ERROR - 2011-06-28 08:55:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 08:55:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 08:55:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:55:56 --> Model Class Initialized
DEBUG - 2011-06-28 08:55:56 --> Model Class Initialized
DEBUG - 2011-06-28 08:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 08:55:56 --> Database Driver Class Initialized
DEBUG - 2011-06-28 08:55:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:55:56 --> Helper loaded: url_helper
DEBUG - 2011-06-28 08:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 08:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 08:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 08:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 08:55:56 --> Final output sent to browser
DEBUG - 2011-06-28 08:55:56 --> Total execution time: 1.2526
DEBUG - 2011-06-28 08:55:57 --> Config Class Initialized
DEBUG - 2011-06-28 08:55:57 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:55:57 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:55:57 --> URI Class Initialized
DEBUG - 2011-06-28 08:55:57 --> Router Class Initialized
DEBUG - 2011-06-28 08:55:57 --> Output Class Initialized
DEBUG - 2011-06-28 08:55:57 --> Input Class Initialized
DEBUG - 2011-06-28 08:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 08:55:57 --> Language Class Initialized
DEBUG - 2011-06-28 08:55:57 --> Loader Class Initialized
DEBUG - 2011-06-28 08:55:57 --> Controller Class Initialized
DEBUG - 2011-06-28 08:55:58 --> Model Class Initialized
DEBUG - 2011-06-28 08:55:58 --> Model Class Initialized
DEBUG - 2011-06-28 08:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 08:55:58 --> Database Driver Class Initialized
DEBUG - 2011-06-28 08:55:58 --> Final output sent to browser
DEBUG - 2011-06-28 08:55:58 --> Total execution time: 0.6286
DEBUG - 2011-06-28 08:55:59 --> Config Class Initialized
DEBUG - 2011-06-28 08:55:59 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:55:59 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:55:59 --> URI Class Initialized
DEBUG - 2011-06-28 08:55:59 --> Router Class Initialized
ERROR - 2011-06-28 08:55:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 08:56:08 --> Config Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:56:08 --> URI Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Router Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Output Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Input Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 08:56:08 --> Language Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Loader Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Controller Class Initialized
ERROR - 2011-06-28 08:56:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 08:56:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 08:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:56:08 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 08:56:08 --> Database Driver Class Initialized
DEBUG - 2011-06-28 08:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:56:08 --> Helper loaded: url_helper
DEBUG - 2011-06-28 08:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 08:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 08:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 08:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 08:56:08 --> Final output sent to browser
DEBUG - 2011-06-28 08:56:08 --> Total execution time: 0.0338
DEBUG - 2011-06-28 08:56:08 --> Config Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:56:08 --> URI Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Router Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Output Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Input Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 08:56:08 --> Language Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Loader Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Controller Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 08:56:08 --> Database Driver Class Initialized
DEBUG - 2011-06-28 08:56:09 --> Final output sent to browser
DEBUG - 2011-06-28 08:56:09 --> Total execution time: 0.6127
DEBUG - 2011-06-28 08:56:10 --> Config Class Initialized
DEBUG - 2011-06-28 08:56:10 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:56:10 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:56:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:56:10 --> URI Class Initialized
DEBUG - 2011-06-28 08:56:10 --> Router Class Initialized
ERROR - 2011-06-28 08:56:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 08:56:30 --> Config Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:56:30 --> URI Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Router Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Output Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Input Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 08:56:30 --> Language Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Loader Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Controller Class Initialized
ERROR - 2011-06-28 08:56:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 08:56:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 08:56:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:56:30 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 08:56:30 --> Database Driver Class Initialized
DEBUG - 2011-06-28 08:56:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:56:30 --> Helper loaded: url_helper
DEBUG - 2011-06-28 08:56:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 08:56:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 08:56:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 08:56:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 08:56:30 --> Final output sent to browser
DEBUG - 2011-06-28 08:56:30 --> Total execution time: 0.0437
DEBUG - 2011-06-28 08:56:30 --> Config Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:56:30 --> URI Class Initialized
DEBUG - 2011-06-28 08:56:30 --> Router Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Output Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Input Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 08:56:31 --> Language Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Loader Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Controller Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 08:56:31 --> Database Driver Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Config Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:56:31 --> URI Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Router Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Output Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Input Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 08:56:31 --> Language Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Loader Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Controller Class Initialized
ERROR - 2011-06-28 08:56:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 08:56:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:56:31 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 08:56:31 --> Database Driver Class Initialized
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:56:31 --> Helper loaded: url_helper
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 08:56:31 --> Final output sent to browser
DEBUG - 2011-06-28 08:56:31 --> Total execution time: 0.0520
DEBUG - 2011-06-28 08:56:31 --> Config Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:56:31 --> URI Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Router Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Output Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Input Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 08:56:31 --> Language Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Loader Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Controller Class Initialized
ERROR - 2011-06-28 08:56:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 08:56:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:56:31 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Model Class Initialized
DEBUG - 2011-06-28 08:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 08:56:31 --> Final output sent to browser
DEBUG - 2011-06-28 08:56:31 --> Total execution time: 0.6015
DEBUG - 2011-06-28 08:56:31 --> Database Driver Class Initialized
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 08:56:31 --> Helper loaded: url_helper
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 08:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 08:56:31 --> Final output sent to browser
DEBUG - 2011-06-28 08:56:31 --> Total execution time: 0.0294
DEBUG - 2011-06-28 08:56:32 --> Config Class Initialized
DEBUG - 2011-06-28 08:56:32 --> Hooks Class Initialized
DEBUG - 2011-06-28 08:56:32 --> Utf8 Class Initialized
DEBUG - 2011-06-28 08:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 08:56:32 --> URI Class Initialized
DEBUG - 2011-06-28 08:56:32 --> Router Class Initialized
ERROR - 2011-06-28 08:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 10:23:24 --> Config Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Hooks Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Utf8 Class Initialized
DEBUG - 2011-06-28 10:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 10:23:24 --> URI Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Router Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Output Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Input Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 10:23:24 --> Language Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Loader Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Controller Class Initialized
ERROR - 2011-06-28 10:23:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 10:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 10:23:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 10:23:24 --> Model Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Model Class Initialized
DEBUG - 2011-06-28 10:23:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 10:23:24 --> Database Driver Class Initialized
DEBUG - 2011-06-28 10:23:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 10:23:24 --> Helper loaded: url_helper
DEBUG - 2011-06-28 10:23:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 10:23:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 10:23:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 10:23:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 10:23:24 --> Final output sent to browser
DEBUG - 2011-06-28 10:23:24 --> Total execution time: 0.3767
DEBUG - 2011-06-28 10:23:25 --> Config Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Hooks Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Utf8 Class Initialized
DEBUG - 2011-06-28 10:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 10:23:25 --> URI Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Router Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Output Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Input Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 10:23:25 --> Language Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Loader Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Controller Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Model Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Model Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 10:23:25 --> Database Driver Class Initialized
DEBUG - 2011-06-28 10:23:25 --> Final output sent to browser
DEBUG - 2011-06-28 10:23:25 --> Total execution time: 0.6225
DEBUG - 2011-06-28 10:23:27 --> Config Class Initialized
DEBUG - 2011-06-28 10:23:27 --> Hooks Class Initialized
DEBUG - 2011-06-28 10:23:27 --> Utf8 Class Initialized
DEBUG - 2011-06-28 10:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 10:23:27 --> URI Class Initialized
DEBUG - 2011-06-28 10:23:27 --> Router Class Initialized
ERROR - 2011-06-28 10:23:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 10:23:27 --> Config Class Initialized
DEBUG - 2011-06-28 10:23:27 --> Hooks Class Initialized
DEBUG - 2011-06-28 10:23:27 --> Utf8 Class Initialized
DEBUG - 2011-06-28 10:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 10:23:27 --> URI Class Initialized
DEBUG - 2011-06-28 10:23:27 --> Router Class Initialized
ERROR - 2011-06-28 10:23:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 10:23:28 --> Config Class Initialized
DEBUG - 2011-06-28 10:23:28 --> Hooks Class Initialized
DEBUG - 2011-06-28 10:23:28 --> Utf8 Class Initialized
DEBUG - 2011-06-28 10:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 10:23:28 --> URI Class Initialized
DEBUG - 2011-06-28 10:23:28 --> Router Class Initialized
ERROR - 2011-06-28 10:23:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 13:09:39 --> Config Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Hooks Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Utf8 Class Initialized
DEBUG - 2011-06-28 13:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 13:09:39 --> URI Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Router Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Output Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Input Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 13:09:39 --> Language Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Loader Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Controller Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Model Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Model Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Model Class Initialized
DEBUG - 2011-06-28 13:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 13:09:39 --> Database Driver Class Initialized
DEBUG - 2011-06-28 13:09:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 13:09:40 --> Helper loaded: url_helper
DEBUG - 2011-06-28 13:09:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 13:09:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 13:09:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 13:09:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 13:09:40 --> Final output sent to browser
DEBUG - 2011-06-28 13:09:40 --> Total execution time: 0.7450
DEBUG - 2011-06-28 15:10:58 --> Config Class Initialized
DEBUG - 2011-06-28 15:10:58 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:10:58 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:10:58 --> URI Class Initialized
DEBUG - 2011-06-28 15:10:58 --> Router Class Initialized
ERROR - 2011-06-28 15:10:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-28 15:36:55 --> Config Class Initialized
DEBUG - 2011-06-28 15:36:55 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:36:55 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:36:55 --> URI Class Initialized
DEBUG - 2011-06-28 15:36:55 --> Router Class Initialized
DEBUG - 2011-06-28 15:36:56 --> Output Class Initialized
DEBUG - 2011-06-28 15:36:56 --> Input Class Initialized
DEBUG - 2011-06-28 15:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:36:56 --> Language Class Initialized
DEBUG - 2011-06-28 15:36:56 --> Loader Class Initialized
DEBUG - 2011-06-28 15:36:56 --> Controller Class Initialized
ERROR - 2011-06-28 15:36:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:36:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:36:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:36:56 --> Model Class Initialized
DEBUG - 2011-06-28 15:36:56 --> Model Class Initialized
DEBUG - 2011-06-28 15:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:36:56 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:36:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:36:56 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:36:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:36:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:36:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:36:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:36:56 --> Final output sent to browser
DEBUG - 2011-06-28 15:36:56 --> Total execution time: 0.3575
DEBUG - 2011-06-28 15:36:57 --> Config Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:36:57 --> URI Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Router Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Output Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Input Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:36:57 --> Language Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Loader Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Controller Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Model Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Model Class Initialized
DEBUG - 2011-06-28 15:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:36:57 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:36:58 --> Final output sent to browser
DEBUG - 2011-06-28 15:36:58 --> Total execution time: 0.5521
DEBUG - 2011-06-28 15:37:00 --> Config Class Initialized
DEBUG - 2011-06-28 15:37:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:37:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:37:00 --> URI Class Initialized
DEBUG - 2011-06-28 15:37:00 --> Router Class Initialized
ERROR - 2011-06-28 15:37:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:37:40 --> Config Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:37:40 --> URI Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Router Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Output Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Input Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:37:40 --> Language Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Loader Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Controller Class Initialized
ERROR - 2011-06-28 15:37:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:37:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:37:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:37:40 --> Model Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Model Class Initialized
DEBUG - 2011-06-28 15:37:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:37:40 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:37:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:37:40 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:37:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:37:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:37:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:37:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:37:40 --> Final output sent to browser
DEBUG - 2011-06-28 15:37:40 --> Total execution time: 0.0352
DEBUG - 2011-06-28 15:37:41 --> Config Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:37:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:37:41 --> URI Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Router Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Output Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Input Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:37:41 --> Language Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Loader Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Controller Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Model Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Model Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:37:41 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:37:41 --> Final output sent to browser
DEBUG - 2011-06-28 15:37:41 --> Total execution time: 0.5410
DEBUG - 2011-06-28 15:37:43 --> Config Class Initialized
DEBUG - 2011-06-28 15:37:43 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:37:43 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:37:43 --> URI Class Initialized
DEBUG - 2011-06-28 15:37:43 --> Router Class Initialized
ERROR - 2011-06-28 15:37:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:37:56 --> Config Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:37:56 --> URI Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Router Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Output Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Input Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:37:56 --> Language Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Loader Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Controller Class Initialized
ERROR - 2011-06-28 15:37:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:37:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:37:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:37:56 --> Model Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Model Class Initialized
DEBUG - 2011-06-28 15:37:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:37:56 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:37:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:37:56 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:37:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:37:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:37:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:37:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:37:56 --> Final output sent to browser
DEBUG - 2011-06-28 15:37:56 --> Total execution time: 0.0313
DEBUG - 2011-06-28 15:37:57 --> Config Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:37:57 --> URI Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Router Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Output Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Input Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:37:57 --> Language Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Loader Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Controller Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Model Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Model Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:37:57 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:37:57 --> Final output sent to browser
DEBUG - 2011-06-28 15:37:57 --> Total execution time: 0.5002
DEBUG - 2011-06-28 15:37:59 --> Config Class Initialized
DEBUG - 2011-06-28 15:37:59 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:37:59 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:37:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:37:59 --> URI Class Initialized
DEBUG - 2011-06-28 15:37:59 --> Router Class Initialized
ERROR - 2011-06-28 15:37:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:38:14 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:14 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Router Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Output Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Input Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:38:14 --> Language Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Loader Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Controller Class Initialized
ERROR - 2011-06-28 15:38:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:38:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:38:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:38:14 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:38:14 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:38:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:38:14 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:38:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:38:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:38:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:38:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:38:14 --> Final output sent to browser
DEBUG - 2011-06-28 15:38:14 --> Total execution time: 0.0312
DEBUG - 2011-06-28 15:38:15 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:15 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Router Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Output Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Input Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:38:15 --> Language Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Loader Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Controller Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:38:15 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:38:15 --> Final output sent to browser
DEBUG - 2011-06-28 15:38:15 --> Total execution time: 0.5840
DEBUG - 2011-06-28 15:38:17 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:17 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:17 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:17 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:17 --> Router Class Initialized
ERROR - 2011-06-28 15:38:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:38:28 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:28 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Router Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Output Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Input Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:38:28 --> Language Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Loader Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Controller Class Initialized
ERROR - 2011-06-28 15:38:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:38:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:38:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:38:28 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:38:28 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:38:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:38:28 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:38:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:38:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:38:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:38:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:38:28 --> Final output sent to browser
DEBUG - 2011-06-28 15:38:28 --> Total execution time: 0.0285
DEBUG - 2011-06-28 15:38:28 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:28 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Router Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Output Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Input Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:38:28 --> Language Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Loader Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Controller Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:38:28 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:38:29 --> Final output sent to browser
DEBUG - 2011-06-28 15:38:29 --> Total execution time: 0.6078
DEBUG - 2011-06-28 15:38:31 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:31 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:31 --> Router Class Initialized
ERROR - 2011-06-28 15:38:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:38:43 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:43 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Router Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Output Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Input Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:38:43 --> Language Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Loader Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Controller Class Initialized
ERROR - 2011-06-28 15:38:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:38:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:38:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:38:43 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:38:43 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:38:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:38:43 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:38:43 --> Final output sent to browser
DEBUG - 2011-06-28 15:38:43 --> Total execution time: 0.0283
DEBUG - 2011-06-28 15:38:44 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:44 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Router Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Output Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Input Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:38:44 --> Language Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Loader Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Controller Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:38:44 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:38:45 --> Final output sent to browser
DEBUG - 2011-06-28 15:38:45 --> Total execution time: 0.9818
DEBUG - 2011-06-28 15:38:52 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:52 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:52 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:52 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:52 --> Router Class Initialized
ERROR - 2011-06-28 15:38:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:38:59 --> Config Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:38:59 --> URI Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Router Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Output Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Input Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:38:59 --> Language Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Loader Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Controller Class Initialized
ERROR - 2011-06-28 15:38:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:38:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:38:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:38:59 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Model Class Initialized
DEBUG - 2011-06-28 15:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:38:59 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:38:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:38:59 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:38:59 --> Final output sent to browser
DEBUG - 2011-06-28 15:38:59 --> Total execution time: 0.0786
DEBUG - 2011-06-28 15:39:00 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:00 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:00 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Controller Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:00 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:00 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:00 --> Total execution time: 0.4957
DEBUG - 2011-06-28 15:39:02 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:02 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:02 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:02 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:02 --> Router Class Initialized
ERROR - 2011-06-28 15:39:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:39:15 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:15 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:15 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Controller Class Initialized
ERROR - 2011-06-28 15:39:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:15 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:15 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:15 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:39:15 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:15 --> Total execution time: 0.0276
DEBUG - 2011-06-28 15:39:15 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:15 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:15 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Controller Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:15 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:16 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:16 --> Total execution time: 0.6133
DEBUG - 2011-06-28 15:39:23 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:23 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:23 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:23 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:23 --> Router Class Initialized
ERROR - 2011-06-28 15:39:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:39:29 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:29 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:29 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Controller Class Initialized
ERROR - 2011-06-28 15:39:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:39:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:39:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:29 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:29 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:29 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:39:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:39:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:39:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:39:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:39:29 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:29 --> Total execution time: 0.0278
DEBUG - 2011-06-28 15:39:30 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:30 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:30 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Controller Class Initialized
ERROR - 2011-06-28 15:39:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:39:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:39:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:30 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:30 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:30 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:39:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:39:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:39:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:39:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:39:30 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:30 --> Total execution time: 0.0287
DEBUG - 2011-06-28 15:39:31 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:31 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:31 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Controller Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:31 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:31 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:31 --> Total execution time: 0.5455
DEBUG - 2011-06-28 15:39:32 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:32 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:32 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:32 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:32 --> Router Class Initialized
ERROR - 2011-06-28 15:39:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:39:40 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:40 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:40 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:40 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:40 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:40 --> No URI present. Default controller set.
DEBUG - 2011-06-28 15:39:40 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:40 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:40 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:40 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:40 --> Controller Class Initialized
DEBUG - 2011-06-28 15:39:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-28 15:39:40 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:39:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:39:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:39:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:39:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:39:40 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:40 --> Total execution time: 0.0584
DEBUG - 2011-06-28 15:39:42 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:42 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:42 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:42 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:42 --> Router Class Initialized
ERROR - 2011-06-28 15:39:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:39:44 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:44 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:44 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Controller Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:44 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 15:39:44 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:39:44 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:44 --> Total execution time: 0.3286
DEBUG - 2011-06-28 15:39:45 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:45 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:45 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Controller Class Initialized
ERROR - 2011-06-28 15:39:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:39:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:45 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:45 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:45 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:39:45 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:45 --> Total execution time: 0.0280
DEBUG - 2011-06-28 15:39:45 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:45 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:45 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Controller Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:45 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:46 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:46 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:46 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:46 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:46 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:46 --> Total execution time: 0.4979
DEBUG - 2011-06-28 15:39:46 --> Router Class Initialized
ERROR - 2011-06-28 15:39:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:39:47 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:47 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:47 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:47 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:47 --> Router Class Initialized
ERROR - 2011-06-28 15:39:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:39:51 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:51 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:51 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Controller Class Initialized
ERROR - 2011-06-28 15:39:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:39:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:39:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:51 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:51 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:39:51 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:39:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:39:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:39:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:39:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:39:51 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:51 --> Total execution time: 0.0279
DEBUG - 2011-06-28 15:39:51 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:51 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Router Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Output Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Input Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:39:51 --> Language Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Loader Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Controller Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Model Class Initialized
DEBUG - 2011-06-28 15:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:39:51 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:39:52 --> Final output sent to browser
DEBUG - 2011-06-28 15:39:52 --> Total execution time: 0.5514
DEBUG - 2011-06-28 15:39:53 --> Config Class Initialized
DEBUG - 2011-06-28 15:39:53 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:39:53 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:39:53 --> URI Class Initialized
DEBUG - 2011-06-28 15:39:53 --> Router Class Initialized
ERROR - 2011-06-28 15:39:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:40:01 --> Config Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:40:01 --> URI Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Router Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Output Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Input Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:40:01 --> Language Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Loader Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Controller Class Initialized
ERROR - 2011-06-28 15:40:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:40:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:40:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:40:01 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:40:01 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:40:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:40:01 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:40:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:40:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:40:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:40:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:40:01 --> Final output sent to browser
DEBUG - 2011-06-28 15:40:01 --> Total execution time: 0.0310
DEBUG - 2011-06-28 15:40:02 --> Config Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:40:02 --> URI Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Router Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Output Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Input Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:40:02 --> Language Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Loader Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Controller Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:40:02 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:40:03 --> Final output sent to browser
DEBUG - 2011-06-28 15:40:03 --> Total execution time: 0.8144
DEBUG - 2011-06-28 15:40:04 --> Config Class Initialized
DEBUG - 2011-06-28 15:40:04 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:40:04 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:40:04 --> URI Class Initialized
DEBUG - 2011-06-28 15:40:04 --> Router Class Initialized
ERROR - 2011-06-28 15:40:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:40:05 --> Config Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:40:05 --> URI Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Router Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Output Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Input Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:40:05 --> Language Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Loader Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Controller Class Initialized
ERROR - 2011-06-28 15:40:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:40:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:40:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:40:05 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:40:05 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:40:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:40:05 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:40:05 --> Final output sent to browser
DEBUG - 2011-06-28 15:40:05 --> Total execution time: 0.0259
DEBUG - 2011-06-28 15:40:30 --> Config Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:40:30 --> URI Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Router Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Output Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Input Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:40:30 --> Language Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Loader Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Controller Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:40:30 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:40:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 15:40:30 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:40:30 --> Final output sent to browser
DEBUG - 2011-06-28 15:40:30 --> Total execution time: 0.3359
DEBUG - 2011-06-28 15:40:31 --> Config Class Initialized
DEBUG - 2011-06-28 15:40:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:40:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:40:31 --> URI Class Initialized
DEBUG - 2011-06-28 15:40:31 --> Router Class Initialized
ERROR - 2011-06-28 15:40:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:40:53 --> Config Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:40:53 --> URI Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Router Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Output Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Input Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:40:53 --> Language Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Loader Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Controller Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Model Class Initialized
DEBUG - 2011-06-28 15:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:40:53 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:40:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 15:40:54 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:40:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:40:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:40:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:40:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:40:54 --> Final output sent to browser
DEBUG - 2011-06-28 15:40:54 --> Total execution time: 0.2423
DEBUG - 2011-06-28 15:40:55 --> Config Class Initialized
DEBUG - 2011-06-28 15:40:55 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:40:55 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:40:55 --> URI Class Initialized
DEBUG - 2011-06-28 15:40:55 --> Router Class Initialized
ERROR - 2011-06-28 15:40:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:41:35 --> Config Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:41:35 --> URI Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Router Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Output Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Input Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:41:35 --> Language Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Loader Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Controller Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Model Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Model Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Model Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:41:35 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:41:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 15:41:35 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:41:35 --> Final output sent to browser
DEBUG - 2011-06-28 15:41:35 --> Total execution time: 0.2165
DEBUG - 2011-06-28 15:41:35 --> Config Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:41:35 --> URI Class Initialized
DEBUG - 2011-06-28 15:41:35 --> Router Class Initialized
ERROR - 2011-06-28 15:41:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:41:49 --> Config Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:41:49 --> URI Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Router Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Output Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Input Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:41:49 --> Language Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Loader Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Controller Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Model Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Model Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Model Class Initialized
DEBUG - 2011-06-28 15:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:41:49 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:41:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 15:41:49 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:41:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:41:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:41:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:41:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:41:49 --> Final output sent to browser
DEBUG - 2011-06-28 15:41:49 --> Total execution time: 0.1890
DEBUG - 2011-06-28 15:41:50 --> Config Class Initialized
DEBUG - 2011-06-28 15:41:50 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:41:50 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:41:50 --> URI Class Initialized
DEBUG - 2011-06-28 15:41:50 --> Router Class Initialized
ERROR - 2011-06-28 15:41:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:42:11 --> Config Class Initialized
DEBUG - 2011-06-28 15:42:11 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:42:11 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:42:11 --> URI Class Initialized
DEBUG - 2011-06-28 15:42:11 --> Router Class Initialized
ERROR - 2011-06-28 15:42:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:42:12 --> Config Class Initialized
DEBUG - 2011-06-28 15:42:12 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:42:12 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:42:12 --> URI Class Initialized
DEBUG - 2011-06-28 15:42:12 --> Router Class Initialized
ERROR - 2011-06-28 15:42:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:42:12 --> Config Class Initialized
DEBUG - 2011-06-28 15:42:12 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:42:12 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:42:12 --> URI Class Initialized
DEBUG - 2011-06-28 15:42:12 --> Router Class Initialized
ERROR - 2011-06-28 15:42:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:42:13 --> Config Class Initialized
DEBUG - 2011-06-28 15:42:13 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:42:13 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:42:13 --> URI Class Initialized
DEBUG - 2011-06-28 15:42:13 --> Router Class Initialized
ERROR - 2011-06-28 15:42:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:42:16 --> Config Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:42:16 --> URI Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Router Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Output Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Input Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:42:16 --> Language Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Loader Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Controller Class Initialized
ERROR - 2011-06-28 15:42:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 15:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 15:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:42:16 --> Model Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Model Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:42:16 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 15:42:16 --> Helper loaded: url_helper
DEBUG - 2011-06-28 15:42:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 15:42:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 15:42:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 15:42:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 15:42:16 --> Final output sent to browser
DEBUG - 2011-06-28 15:42:16 --> Total execution time: 0.0279
DEBUG - 2011-06-28 15:42:16 --> Config Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:42:16 --> URI Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Router Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Output Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Input Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 15:42:16 --> Language Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Loader Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Controller Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Model Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Model Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 15:42:16 --> Database Driver Class Initialized
DEBUG - 2011-06-28 15:42:16 --> Final output sent to browser
DEBUG - 2011-06-28 15:42:16 --> Total execution time: 0.4607
DEBUG - 2011-06-28 15:42:18 --> Config Class Initialized
DEBUG - 2011-06-28 15:42:18 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:42:18 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:42:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:42:18 --> URI Class Initialized
DEBUG - 2011-06-28 15:42:18 --> Router Class Initialized
ERROR - 2011-06-28 15:42:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 15:42:52 --> Config Class Initialized
DEBUG - 2011-06-28 15:42:52 --> Hooks Class Initialized
DEBUG - 2011-06-28 15:42:52 --> Utf8 Class Initialized
DEBUG - 2011-06-28 15:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 15:42:52 --> URI Class Initialized
DEBUG - 2011-06-28 15:42:52 --> Router Class Initialized
ERROR - 2011-06-28 15:42:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 16:24:19 --> Config Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Hooks Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Utf8 Class Initialized
DEBUG - 2011-06-28 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 16:24:19 --> URI Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Router Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Output Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Input Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 16:24:19 --> Language Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Loader Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Controller Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Model Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Model Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Model Class Initialized
DEBUG - 2011-06-28 16:24:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 16:24:19 --> Database Driver Class Initialized
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 16:24:20 --> Helper loaded: url_helper
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 16:24:20 --> Final output sent to browser
DEBUG - 2011-06-28 16:24:20 --> Total execution time: 0.5406
DEBUG - 2011-06-28 16:24:20 --> Config Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Hooks Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Utf8 Class Initialized
DEBUG - 2011-06-28 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 16:24:20 --> URI Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Router Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Output Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Input Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 16:24:20 --> Language Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Loader Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Controller Class Initialized
ERROR - 2011-06-28 16:24:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 16:24:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 16:24:20 --> Model Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Model Class Initialized
DEBUG - 2011-06-28 16:24:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 16:24:20 --> Database Driver Class Initialized
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 16:24:20 --> Helper loaded: url_helper
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 16:24:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 16:24:20 --> Final output sent to browser
DEBUG - 2011-06-28 16:24:20 --> Total execution time: 0.0772
DEBUG - 2011-06-28 17:40:21 --> Config Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Hooks Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Utf8 Class Initialized
DEBUG - 2011-06-28 17:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 17:40:21 --> URI Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Router Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Output Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Input Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 17:40:21 --> Language Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Loader Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Controller Class Initialized
ERROR - 2011-06-28 17:40:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 17:40:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 17:40:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 17:40:21 --> Model Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Model Class Initialized
DEBUG - 2011-06-28 17:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 17:40:21 --> Database Driver Class Initialized
DEBUG - 2011-06-28 17:40:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 17:40:21 --> Helper loaded: url_helper
DEBUG - 2011-06-28 17:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 17:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 17:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 17:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 17:40:21 --> Final output sent to browser
DEBUG - 2011-06-28 17:40:21 --> Total execution time: 0.3563
DEBUG - 2011-06-28 17:40:24 --> Config Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Hooks Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Utf8 Class Initialized
DEBUG - 2011-06-28 17:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 17:40:24 --> URI Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Router Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Output Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Input Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 17:40:24 --> Language Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Loader Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Controller Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Model Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Model Class Initialized
DEBUG - 2011-06-28 17:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 17:40:24 --> Database Driver Class Initialized
DEBUG - 2011-06-28 17:40:25 --> Final output sent to browser
DEBUG - 2011-06-28 17:40:25 --> Total execution time: 0.8264
DEBUG - 2011-06-28 17:40:27 --> Config Class Initialized
DEBUG - 2011-06-28 17:40:27 --> Hooks Class Initialized
DEBUG - 2011-06-28 17:40:27 --> Utf8 Class Initialized
DEBUG - 2011-06-28 17:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 17:40:27 --> URI Class Initialized
DEBUG - 2011-06-28 17:40:27 --> Router Class Initialized
ERROR - 2011-06-28 17:40:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 17:40:49 --> Config Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Hooks Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Utf8 Class Initialized
DEBUG - 2011-06-28 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 17:40:49 --> URI Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Router Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Output Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Input Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 17:40:49 --> Language Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Loader Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Controller Class Initialized
ERROR - 2011-06-28 17:40:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 17:40:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 17:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 17:40:49 --> Model Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Model Class Initialized
DEBUG - 2011-06-28 17:40:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 17:40:49 --> Database Driver Class Initialized
DEBUG - 2011-06-28 17:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 17:40:49 --> Helper loaded: url_helper
DEBUG - 2011-06-28 17:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 17:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 17:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 17:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 17:40:49 --> Final output sent to browser
DEBUG - 2011-06-28 17:40:49 --> Total execution time: 0.3995
DEBUG - 2011-06-28 17:40:50 --> Config Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Hooks Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Utf8 Class Initialized
DEBUG - 2011-06-28 17:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 17:40:50 --> URI Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Router Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Output Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Input Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 17:40:50 --> Language Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Loader Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Controller Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Model Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Model Class Initialized
DEBUG - 2011-06-28 17:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 17:40:50 --> Database Driver Class Initialized
DEBUG - 2011-06-28 17:40:52 --> Final output sent to browser
DEBUG - 2011-06-28 17:40:52 --> Total execution time: 1.9443
DEBUG - 2011-06-28 17:40:54 --> Config Class Initialized
DEBUG - 2011-06-28 17:40:54 --> Hooks Class Initialized
DEBUG - 2011-06-28 17:40:54 --> Utf8 Class Initialized
DEBUG - 2011-06-28 17:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 17:40:54 --> URI Class Initialized
DEBUG - 2011-06-28 17:40:54 --> Router Class Initialized
ERROR - 2011-06-28 17:40:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 18:13:17 --> Config Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:13:17 --> URI Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Router Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Output Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Input Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:13:17 --> Language Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Loader Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Controller Class Initialized
ERROR - 2011-06-28 18:13:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:13:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:13:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:13:17 --> Model Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Model Class Initialized
DEBUG - 2011-06-28 18:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:13:17 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:13:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:13:17 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:13:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:13:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:13:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:13:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:13:17 --> Final output sent to browser
DEBUG - 2011-06-28 18:13:17 --> Total execution time: 0.2511
DEBUG - 2011-06-28 18:13:18 --> Config Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:13:18 --> URI Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Router Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Output Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Input Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:13:18 --> Language Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Loader Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Controller Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Model Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Model Class Initialized
DEBUG - 2011-06-28 18:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:13:18 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:13:19 --> Final output sent to browser
DEBUG - 2011-06-28 18:13:19 --> Total execution time: 0.5791
DEBUG - 2011-06-28 18:13:21 --> Config Class Initialized
DEBUG - 2011-06-28 18:13:21 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:13:21 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:13:21 --> URI Class Initialized
DEBUG - 2011-06-28 18:13:21 --> Router Class Initialized
ERROR - 2011-06-28 18:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 18:13:22 --> Config Class Initialized
DEBUG - 2011-06-28 18:13:22 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:13:22 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:13:22 --> URI Class Initialized
DEBUG - 2011-06-28 18:13:22 --> Router Class Initialized
ERROR - 2011-06-28 18:13:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 18:13:48 --> Config Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:13:48 --> URI Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Router Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Output Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Input Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:13:48 --> Language Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Loader Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Controller Class Initialized
ERROR - 2011-06-28 18:13:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:13:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:13:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:13:48 --> Model Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Model Class Initialized
DEBUG - 2011-06-28 18:13:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:13:48 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:13:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:13:48 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:13:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:13:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:13:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:13:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:13:48 --> Final output sent to browser
DEBUG - 2011-06-28 18:13:48 --> Total execution time: 0.0309
DEBUG - 2011-06-28 18:13:49 --> Config Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:13:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:13:49 --> URI Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Router Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Output Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Input Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:13:49 --> Language Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Loader Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Controller Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Model Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Model Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:13:49 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:13:49 --> Final output sent to browser
DEBUG - 2011-06-28 18:13:49 --> Total execution time: 0.6737
DEBUG - 2011-06-28 18:14:00 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:00 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:00 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Controller Class Initialized
ERROR - 2011-06-28 18:14:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:14:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:14:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:00 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:00 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:00 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:14:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:14:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:14:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:14:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:14:00 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:00 --> Total execution time: 0.0289
DEBUG - 2011-06-28 18:14:01 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:01 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:01 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Controller Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:01 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:01 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:01 --> Total execution time: 0.6166
DEBUG - 2011-06-28 18:14:12 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:12 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:12 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Controller Class Initialized
ERROR - 2011-06-28 18:14:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:14:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:14:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:12 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:12 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:12 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:14:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:14:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:14:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:14:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:14:12 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:12 --> Total execution time: 0.0286
DEBUG - 2011-06-28 18:14:13 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:13 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:13 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Controller Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:13 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:13 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:13 --> Total execution time: 0.5758
DEBUG - 2011-06-28 18:14:31 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:31 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:31 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Controller Class Initialized
ERROR - 2011-06-28 18:14:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:14:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:31 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:31 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:31 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:14:31 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:31 --> Total execution time: 0.0276
DEBUG - 2011-06-28 18:14:32 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:32 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:32 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Controller Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:32 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:32 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:32 --> Total execution time: 0.6367
DEBUG - 2011-06-28 18:14:47 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:47 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:47 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Controller Class Initialized
ERROR - 2011-06-28 18:14:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:14:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:14:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:47 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:47 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:47 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:14:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:14:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:14:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:14:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:14:47 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:47 --> Total execution time: 0.0272
DEBUG - 2011-06-28 18:14:47 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:47 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:47 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Controller Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:47 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:48 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:48 --> Total execution time: 0.5570
DEBUG - 2011-06-28 18:14:57 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:57 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:57 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Controller Class Initialized
ERROR - 2011-06-28 18:14:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:57 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:57 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:14:57 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:14:57 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:57 --> Total execution time: 0.0291
DEBUG - 2011-06-28 18:14:58 --> Config Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:14:58 --> URI Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Router Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Output Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Input Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:14:58 --> Language Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Loader Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Controller Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Model Class Initialized
DEBUG - 2011-06-28 18:14:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:14:58 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:14:59 --> Final output sent to browser
DEBUG - 2011-06-28 18:14:59 --> Total execution time: 0.4996
DEBUG - 2011-06-28 18:15:10 --> Config Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:15:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:15:10 --> URI Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Router Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Output Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Input Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:15:10 --> Language Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Loader Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Controller Class Initialized
ERROR - 2011-06-28 18:15:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:15:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:15:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:15:10 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:15:10 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:15:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:15:10 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:15:10 --> Final output sent to browser
DEBUG - 2011-06-28 18:15:10 --> Total execution time: 0.1630
DEBUG - 2011-06-28 18:15:11 --> Config Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:15:11 --> URI Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Router Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Output Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Input Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:15:11 --> Language Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Loader Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Controller Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:15:11 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:15:12 --> Final output sent to browser
DEBUG - 2011-06-28 18:15:12 --> Total execution time: 0.6482
DEBUG - 2011-06-28 18:15:29 --> Config Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:15:29 --> URI Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Router Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Output Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Input Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:15:29 --> Language Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Loader Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Controller Class Initialized
ERROR - 2011-06-28 18:15:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:15:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:15:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:15:29 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:15:29 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:15:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:15:29 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:15:29 --> Final output sent to browser
DEBUG - 2011-06-28 18:15:29 --> Total execution time: 0.0270
DEBUG - 2011-06-28 18:15:30 --> Config Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:15:30 --> URI Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Router Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Output Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Input Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:15:30 --> Language Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Loader Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Controller Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:15:30 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:15:30 --> Final output sent to browser
DEBUG - 2011-06-28 18:15:30 --> Total execution time: 0.5121
DEBUG - 2011-06-28 18:15:37 --> Config Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:15:37 --> URI Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Router Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Output Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Input Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:15:37 --> Language Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Loader Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Controller Class Initialized
ERROR - 2011-06-28 18:15:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 18:15:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 18:15:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:15:37 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:15:37 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:15:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 18:15:37 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:15:37 --> Final output sent to browser
DEBUG - 2011-06-28 18:15:37 --> Total execution time: 0.0323
DEBUG - 2011-06-28 18:15:38 --> Config Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:15:38 --> URI Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Router Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Output Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Input Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:15:38 --> Language Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Loader Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Controller Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:15:38 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:15:38 --> Final output sent to browser
DEBUG - 2011-06-28 18:15:38 --> Total execution time: 0.6946
DEBUG - 2011-06-28 18:15:57 --> Config Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:15:57 --> URI Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Router Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Output Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Input Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:15:57 --> Language Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Loader Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Controller Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Model Class Initialized
DEBUG - 2011-06-28 18:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:15:57 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:15:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 18:15:58 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:15:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:15:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:15:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:15:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:15:58 --> Final output sent to browser
DEBUG - 2011-06-28 18:15:58 --> Total execution time: 1.3031
DEBUG - 2011-06-28 18:16:15 --> Config Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:16:15 --> URI Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Router Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Output Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Input Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:16:15 --> Language Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Loader Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Controller Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:16:15 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:16:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 18:16:15 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:16:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:16:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:16:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:16:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:16:15 --> Final output sent to browser
DEBUG - 2011-06-28 18:16:15 --> Total execution time: 0.2373
DEBUG - 2011-06-28 18:16:32 --> Config Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:16:32 --> URI Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Router Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Output Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Input Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:16:32 --> Language Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Loader Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Controller Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:16:32 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:16:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 18:16:32 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:16:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:16:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:16:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:16:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:16:32 --> Final output sent to browser
DEBUG - 2011-06-28 18:16:32 --> Total execution time: 0.2410
DEBUG - 2011-06-28 18:16:57 --> Config Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:16:57 --> URI Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Router Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Output Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Input Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:16:57 --> Language Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Loader Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Controller Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Model Class Initialized
DEBUG - 2011-06-28 18:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:16:57 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:16:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 18:16:57 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:16:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:16:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:16:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:16:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:16:57 --> Final output sent to browser
DEBUG - 2011-06-28 18:16:57 --> Total execution time: 0.2297
DEBUG - 2011-06-28 18:17:28 --> Config Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Hooks Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Utf8 Class Initialized
DEBUG - 2011-06-28 18:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 18:17:28 --> URI Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Router Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Output Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Input Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 18:17:28 --> Language Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Loader Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Controller Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Model Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Model Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Model Class Initialized
DEBUG - 2011-06-28 18:17:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 18:17:28 --> Database Driver Class Initialized
DEBUG - 2011-06-28 18:17:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 18:17:29 --> Helper loaded: url_helper
DEBUG - 2011-06-28 18:17:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 18:17:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 18:17:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 18:17:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 18:17:29 --> Final output sent to browser
DEBUG - 2011-06-28 18:17:29 --> Total execution time: 0.3718
DEBUG - 2011-06-28 19:26:00 --> Config Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:26:00 --> URI Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Router Class Initialized
ERROR - 2011-06-28 19:26:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-28 19:26:00 --> Config Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:26:00 --> URI Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Router Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Output Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Input Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:26:00 --> Language Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Loader Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Controller Class Initialized
ERROR - 2011-06-28 19:26:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:26:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:26:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:26:00 --> Model Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Model Class Initialized
DEBUG - 2011-06-28 19:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:26:00 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:26:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:26:00 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:26:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:26:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:26:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:26:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:26:00 --> Final output sent to browser
DEBUG - 2011-06-28 19:26:00 --> Total execution time: 0.2827
DEBUG - 2011-06-28 19:48:52 --> Config Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:48:52 --> URI Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Router Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Output Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Input Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:48:52 --> Language Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Loader Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Controller Class Initialized
ERROR - 2011-06-28 19:48:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:48:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:48:52 --> Model Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Model Class Initialized
DEBUG - 2011-06-28 19:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:48:52 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:48:52 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:48:52 --> Final output sent to browser
DEBUG - 2011-06-28 19:48:52 --> Total execution time: 0.0851
DEBUG - 2011-06-28 19:48:53 --> Config Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:48:53 --> URI Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Router Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Output Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Input Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:48:53 --> Language Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Loader Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Controller Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Model Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Model Class Initialized
DEBUG - 2011-06-28 19:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:48:53 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:48:54 --> Final output sent to browser
DEBUG - 2011-06-28 19:48:54 --> Total execution time: 0.6953
DEBUG - 2011-06-28 19:48:56 --> Config Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:48:56 --> URI Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Router Class Initialized
ERROR - 2011-06-28 19:48:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 19:48:56 --> Config Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:48:56 --> URI Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Router Class Initialized
ERROR - 2011-06-28 19:48:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 19:48:56 --> Config Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:48:56 --> URI Class Initialized
DEBUG - 2011-06-28 19:48:56 --> Router Class Initialized
ERROR - 2011-06-28 19:48:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-28 19:49:35 --> Config Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:49:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:49:35 --> URI Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Router Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Output Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Input Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:49:35 --> Language Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Loader Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Controller Class Initialized
ERROR - 2011-06-28 19:49:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:49:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:49:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:49:35 --> Model Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Model Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:49:35 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:49:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:49:35 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:49:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:49:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:49:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:49:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:49:35 --> Final output sent to browser
DEBUG - 2011-06-28 19:49:35 --> Total execution time: 0.0298
DEBUG - 2011-06-28 19:49:35 --> Config Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:49:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:49:35 --> URI Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Router Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Output Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Input Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:49:35 --> Language Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Loader Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Controller Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Model Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Model Class Initialized
DEBUG - 2011-06-28 19:49:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:49:35 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:49:36 --> Final output sent to browser
DEBUG - 2011-06-28 19:49:36 --> Total execution time: 0.5693
DEBUG - 2011-06-28 19:49:56 --> Config Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:49:56 --> URI Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Router Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Output Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Input Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:49:56 --> Language Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Loader Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Controller Class Initialized
ERROR - 2011-06-28 19:49:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:49:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:49:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:49:56 --> Model Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Model Class Initialized
DEBUG - 2011-06-28 19:49:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:49:56 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:49:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:49:56 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:49:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:49:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:49:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:49:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:49:56 --> Final output sent to browser
DEBUG - 2011-06-28 19:49:56 --> Total execution time: 0.0269
DEBUG - 2011-06-28 19:49:58 --> Config Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:49:58 --> URI Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Router Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Output Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Input Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:49:58 --> Language Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Loader Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Controller Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Model Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Model Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:49:58 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:49:58 --> Final output sent to browser
DEBUG - 2011-06-28 19:49:58 --> Total execution time: 0.6171
DEBUG - 2011-06-28 19:50:00 --> Config Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:50:00 --> URI Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Router Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Output Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Input Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:50:00 --> Language Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Loader Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Controller Class Initialized
ERROR - 2011-06-28 19:50:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:50:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:50:00 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:50:00 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:50:00 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:50:00 --> Final output sent to browser
DEBUG - 2011-06-28 19:50:00 --> Total execution time: 0.0328
DEBUG - 2011-06-28 19:50:10 --> Config Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:50:10 --> URI Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Router Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Output Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Input Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:50:10 --> Language Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Loader Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Controller Class Initialized
ERROR - 2011-06-28 19:50:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:50:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:50:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:50:10 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:50:10 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:50:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:50:10 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:50:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:50:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:50:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:50:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:50:10 --> Final output sent to browser
DEBUG - 2011-06-28 19:50:10 --> Total execution time: 0.0286
DEBUG - 2011-06-28 19:50:11 --> Config Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:50:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:50:11 --> URI Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Router Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Output Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Input Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:50:11 --> Language Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Loader Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Controller Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:50:11 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:50:12 --> Final output sent to browser
DEBUG - 2011-06-28 19:50:12 --> Total execution time: 0.5821
DEBUG - 2011-06-28 19:50:25 --> Config Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:50:25 --> URI Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Router Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Output Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Input Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:50:25 --> Language Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Loader Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Controller Class Initialized
ERROR - 2011-06-28 19:50:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:50:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:50:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:50:25 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:50:25 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:50:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:50:25 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:50:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:50:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:50:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:50:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:50:25 --> Final output sent to browser
DEBUG - 2011-06-28 19:50:25 --> Total execution time: 0.0280
DEBUG - 2011-06-28 19:50:26 --> Config Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:50:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:50:26 --> URI Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Router Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Output Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Input Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:50:26 --> Language Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Loader Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Controller Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Model Class Initialized
DEBUG - 2011-06-28 19:50:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:50:26 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:50:27 --> Final output sent to browser
DEBUG - 2011-06-28 19:50:27 --> Total execution time: 0.7059
DEBUG - 2011-06-28 19:54:26 --> Config Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:54:26 --> URI Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Router Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Output Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Input Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:54:26 --> Language Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Loader Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Controller Class Initialized
ERROR - 2011-06-28 19:54:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:54:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:54:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:54:26 --> Model Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Model Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:54:26 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:54:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:54:26 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:54:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:54:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:54:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:54:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:54:26 --> Final output sent to browser
DEBUG - 2011-06-28 19:54:26 --> Total execution time: 0.0302
DEBUG - 2011-06-28 19:54:26 --> Config Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:54:26 --> URI Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Router Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Output Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Input Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:54:26 --> Language Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Loader Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Controller Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Model Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Model Class Initialized
DEBUG - 2011-06-28 19:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:54:26 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:54:27 --> Final output sent to browser
DEBUG - 2011-06-28 19:54:27 --> Total execution time: 0.5481
DEBUG - 2011-06-28 19:54:48 --> Config Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:54:48 --> URI Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Router Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Output Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Input Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:54:48 --> Language Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Loader Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Controller Class Initialized
ERROR - 2011-06-28 19:54:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:54:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:54:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:54:48 --> Model Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Model Class Initialized
DEBUG - 2011-06-28 19:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:54:48 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:54:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:54:48 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:54:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:54:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:54:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:54:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:54:48 --> Final output sent to browser
DEBUG - 2011-06-28 19:54:48 --> Total execution time: 0.0621
DEBUG - 2011-06-28 19:54:49 --> Config Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:54:49 --> URI Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Router Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Output Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Input Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:54:49 --> Language Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Loader Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Controller Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Model Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Model Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:54:49 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:54:49 --> Final output sent to browser
DEBUG - 2011-06-28 19:54:49 --> Total execution time: 0.5850
DEBUG - 2011-06-28 19:55:30 --> Config Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:55:30 --> URI Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Router Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Output Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Input Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:55:30 --> Language Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Loader Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Controller Class Initialized
ERROR - 2011-06-28 19:55:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:55:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:55:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:30 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:55:30 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:55:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:30 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:55:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:55:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:55:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:55:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:55:30 --> Final output sent to browser
DEBUG - 2011-06-28 19:55:30 --> Total execution time: 0.0312
DEBUG - 2011-06-28 19:55:31 --> Config Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:55:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:55:31 --> URI Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Router Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Output Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Input Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:55:31 --> Language Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Loader Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Controller Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:55:31 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:55:32 --> Final output sent to browser
DEBUG - 2011-06-28 19:55:32 --> Total execution time: 0.5075
DEBUG - 2011-06-28 19:55:54 --> Config Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:55:54 --> URI Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Router Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Output Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Input Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:55:54 --> Language Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Loader Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Controller Class Initialized
ERROR - 2011-06-28 19:55:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:55:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:55:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:54 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:55:54 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:55:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:54 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:55:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:55:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:55:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:55:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:55:54 --> Final output sent to browser
DEBUG - 2011-06-28 19:55:54 --> Total execution time: 0.1186
DEBUG - 2011-06-28 19:55:55 --> Config Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:55:55 --> URI Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Router Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Output Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Input Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:55:55 --> Language Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Loader Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Controller Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:55:55 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:55:55 --> Final output sent to browser
DEBUG - 2011-06-28 19:55:55 --> Total execution time: 0.5025
DEBUG - 2011-06-28 19:55:56 --> Config Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:55:56 --> URI Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Router Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Output Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Input Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:55:56 --> Language Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Loader Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Controller Class Initialized
ERROR - 2011-06-28 19:55:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:55:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:56 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:55:56 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:56 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:55:56 --> Final output sent to browser
DEBUG - 2011-06-28 19:55:56 --> Total execution time: 0.0283
DEBUG - 2011-06-28 19:55:56 --> Config Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:55:56 --> URI Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Router Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Output Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Input Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:55:56 --> Language Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Loader Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Controller Class Initialized
ERROR - 2011-06-28 19:55:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:55:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:56 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:55:56 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:56 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:55:56 --> Final output sent to browser
DEBUG - 2011-06-28 19:55:56 --> Total execution time: 0.0292
DEBUG - 2011-06-28 19:55:56 --> Config Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:55:56 --> URI Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Router Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Output Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Input Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:55:56 --> Language Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Loader Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Controller Class Initialized
ERROR - 2011-06-28 19:55:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:55:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:56 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Model Class Initialized
DEBUG - 2011-06-28 19:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:55:56 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:55:56 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:55:56 --> Final output sent to browser
DEBUG - 2011-06-28 19:55:56 --> Total execution time: 0.0291
DEBUG - 2011-06-28 19:56:23 --> Config Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:56:23 --> URI Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Router Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Output Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Input Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:56:23 --> Language Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Loader Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Controller Class Initialized
ERROR - 2011-06-28 19:56:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:56:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:56:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:56:23 --> Model Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Model Class Initialized
DEBUG - 2011-06-28 19:56:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:56:23 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:56:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:56:23 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:56:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:56:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:56:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:56:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:56:23 --> Final output sent to browser
DEBUG - 2011-06-28 19:56:23 --> Total execution time: 0.0290
DEBUG - 2011-06-28 19:56:24 --> Config Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:56:24 --> URI Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Router Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Output Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Input Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:56:24 --> Language Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Loader Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Controller Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Model Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Model Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:56:24 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:56:24 --> Final output sent to browser
DEBUG - 2011-06-28 19:56:24 --> Total execution time: 0.4891
DEBUG - 2011-06-28 19:56:32 --> Config Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:56:32 --> URI Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Router Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Output Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Input Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:56:32 --> Language Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Loader Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Controller Class Initialized
ERROR - 2011-06-28 19:56:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:56:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:56:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:56:32 --> Model Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Model Class Initialized
DEBUG - 2011-06-28 19:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:56:32 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:56:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:56:32 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:56:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:56:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:56:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:56:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:56:32 --> Final output sent to browser
DEBUG - 2011-06-28 19:56:32 --> Total execution time: 0.0321
DEBUG - 2011-06-28 19:56:59 --> Config Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:56:59 --> URI Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Router Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Output Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Input Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:56:59 --> Language Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Loader Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Controller Class Initialized
ERROR - 2011-06-28 19:56:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:56:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:56:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:56:59 --> Model Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Model Class Initialized
DEBUG - 2011-06-28 19:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:56:59 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:56:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:56:59 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:56:59 --> Final output sent to browser
DEBUG - 2011-06-28 19:56:59 --> Total execution time: 0.0280
DEBUG - 2011-06-28 19:57:00 --> Config Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:57:00 --> URI Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Router Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Output Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Input Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:57:00 --> Language Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Loader Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Controller Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:57:00 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Config Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:57:00 --> URI Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Router Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Output Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Final output sent to browser
DEBUG - 2011-06-28 19:57:00 --> Total execution time: 0.5547
DEBUG - 2011-06-28 19:57:00 --> Input Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:57:00 --> Language Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Loader Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Controller Class Initialized
ERROR - 2011-06-28 19:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:57:00 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:57:00 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:57:00 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:57:00 --> Final output sent to browser
DEBUG - 2011-06-28 19:57:00 --> Total execution time: 0.0273
DEBUG - 2011-06-28 19:57:21 --> Config Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:57:21 --> URI Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Router Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Output Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Input Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:57:21 --> Language Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Loader Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Controller Class Initialized
ERROR - 2011-06-28 19:57:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:57:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:57:21 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:57:21 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:57:21 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:57:21 --> Final output sent to browser
DEBUG - 2011-06-28 19:57:21 --> Total execution time: 0.0510
DEBUG - 2011-06-28 19:57:21 --> Config Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:57:21 --> URI Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Router Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Output Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Input Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:57:21 --> Language Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Loader Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Controller Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:57:21 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:57:22 --> Final output sent to browser
DEBUG - 2011-06-28 19:57:22 --> Total execution time: 0.5456
DEBUG - 2011-06-28 19:57:23 --> Config Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Hooks Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Utf8 Class Initialized
DEBUG - 2011-06-28 19:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 19:57:23 --> URI Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Router Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Output Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Input Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 19:57:23 --> Language Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Loader Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Controller Class Initialized
ERROR - 2011-06-28 19:57:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 19:57:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 19:57:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:57:23 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Model Class Initialized
DEBUG - 2011-06-28 19:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 19:57:23 --> Database Driver Class Initialized
DEBUG - 2011-06-28 19:57:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 19:57:23 --> Helper loaded: url_helper
DEBUG - 2011-06-28 19:57:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 19:57:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 19:57:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 19:57:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 19:57:23 --> Final output sent to browser
DEBUG - 2011-06-28 19:57:23 --> Total execution time: 0.0304
DEBUG - 2011-06-28 20:04:43 --> Config Class Initialized
DEBUG - 2011-06-28 20:04:43 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:04:43 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:04:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:04:43 --> URI Class Initialized
DEBUG - 2011-06-28 20:04:43 --> Router Class Initialized
DEBUG - 2011-06-28 20:04:43 --> No URI present. Default controller set.
DEBUG - 2011-06-28 20:04:43 --> Output Class Initialized
DEBUG - 2011-06-28 20:04:43 --> Input Class Initialized
DEBUG - 2011-06-28 20:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:04:43 --> Language Class Initialized
DEBUG - 2011-06-28 20:04:43 --> Loader Class Initialized
DEBUG - 2011-06-28 20:04:43 --> Controller Class Initialized
DEBUG - 2011-06-28 20:04:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-28 20:04:43 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:04:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:04:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:04:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:04:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:04:43 --> Final output sent to browser
DEBUG - 2011-06-28 20:04:43 --> Total execution time: 0.0896
DEBUG - 2011-06-28 20:05:53 --> Config Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:05:53 --> URI Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Router Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Output Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Input Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:05:53 --> Language Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Loader Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Controller Class Initialized
ERROR - 2011-06-28 20:05:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 20:05:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 20:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:05:53 --> Model Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Model Class Initialized
DEBUG - 2011-06-28 20:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:05:53 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:05:53 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:05:53 --> Final output sent to browser
DEBUG - 2011-06-28 20:05:53 --> Total execution time: 0.0688
DEBUG - 2011-06-28 20:05:54 --> Config Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:05:54 --> URI Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Router Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Output Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Input Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:05:54 --> Language Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Loader Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Controller Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Model Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Model Class Initialized
DEBUG - 2011-06-28 20:05:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:05:54 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:05:55 --> Final output sent to browser
DEBUG - 2011-06-28 20:05:55 --> Total execution time: 0.5871
DEBUG - 2011-06-28 20:06:19 --> Config Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:06:19 --> URI Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Router Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Output Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Input Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:06:19 --> Language Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Loader Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Controller Class Initialized
ERROR - 2011-06-28 20:06:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 20:06:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 20:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:06:19 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:06:19 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:06:19 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:06:19 --> Final output sent to browser
DEBUG - 2011-06-28 20:06:19 --> Total execution time: 0.0315
DEBUG - 2011-06-28 20:06:20 --> Config Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:06:20 --> URI Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Router Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Output Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Input Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:06:20 --> Language Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Loader Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Controller Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:06:20 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Final output sent to browser
DEBUG - 2011-06-28 20:06:21 --> Total execution time: 0.5697
DEBUG - 2011-06-28 20:06:21 --> Config Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:06:21 --> URI Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Router Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Output Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Input Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:06:21 --> Language Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Loader Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Controller Class Initialized
ERROR - 2011-06-28 20:06:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 20:06:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 20:06:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:06:21 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:06:21 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:06:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:06:21 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:06:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:06:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:06:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:06:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:06:21 --> Final output sent to browser
DEBUG - 2011-06-28 20:06:21 --> Total execution time: 0.0286
DEBUG - 2011-06-28 20:06:27 --> Config Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:06:27 --> URI Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Router Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Output Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Input Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:06:27 --> Language Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Loader Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Controller Class Initialized
ERROR - 2011-06-28 20:06:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 20:06:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 20:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:06:27 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:06:27 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:06:27 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:06:27 --> Final output sent to browser
DEBUG - 2011-06-28 20:06:27 --> Total execution time: 0.0274
DEBUG - 2011-06-28 20:06:28 --> Config Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:06:28 --> URI Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Router Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Output Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Input Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:06:28 --> Language Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Loader Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Controller Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:06:28 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:06:28 --> Final output sent to browser
DEBUG - 2011-06-28 20:06:28 --> Total execution time: 0.5046
DEBUG - 2011-06-28 20:06:59 --> Config Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:06:59 --> URI Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Router Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Output Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Input Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:06:59 --> Language Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Loader Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Controller Class Initialized
ERROR - 2011-06-28 20:06:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 20:06:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 20:06:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:06:59 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Model Class Initialized
DEBUG - 2011-06-28 20:06:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:06:59 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:06:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:06:59 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:06:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:06:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:06:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:06:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:06:59 --> Final output sent to browser
DEBUG - 2011-06-28 20:06:59 --> Total execution time: 0.0326
DEBUG - 2011-06-28 20:07:00 --> Config Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:07:00 --> URI Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Router Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Output Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Input Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:07:00 --> Language Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Loader Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Controller Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Model Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Model Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:07:00 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:07:00 --> Final output sent to browser
DEBUG - 2011-06-28 20:07:00 --> Total execution time: 0.4995
DEBUG - 2011-06-28 20:15:21 --> Config Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:15:21 --> URI Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Router Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Output Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Input Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:15:21 --> Language Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Loader Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Controller Class Initialized
ERROR - 2011-06-28 20:15:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 20:15:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 20:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:15:21 --> Model Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Model Class Initialized
DEBUG - 2011-06-28 20:15:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:15:21 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:15:21 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:15:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:15:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:15:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:15:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:15:21 --> Final output sent to browser
DEBUG - 2011-06-28 20:15:21 --> Total execution time: 0.0645
DEBUG - 2011-06-28 20:18:31 --> Config Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:18:31 --> URI Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Router Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Output Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Input Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:18:31 --> Language Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Loader Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Controller Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Model Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Model Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Model Class Initialized
DEBUG - 2011-06-28 20:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:18:31 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:18:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 20:18:31 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:18:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:18:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:18:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:18:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:18:31 --> Final output sent to browser
DEBUG - 2011-06-28 20:18:31 --> Total execution time: 0.3348
DEBUG - 2011-06-28 20:33:13 --> Config Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:33:13 --> URI Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Router Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Output Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Input Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:33:13 --> Language Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Loader Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Controller Class Initialized
ERROR - 2011-06-28 20:33:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-28 20:33:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-28 20:33:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:33:13 --> Model Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Model Class Initialized
DEBUG - 2011-06-28 20:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:33:13 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:33:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-28 20:33:13 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:33:13 --> Final output sent to browser
DEBUG - 2011-06-28 20:33:13 --> Total execution time: 0.0399
DEBUG - 2011-06-28 20:33:18 --> Config Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Hooks Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Utf8 Class Initialized
DEBUG - 2011-06-28 20:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 20:33:18 --> URI Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Router Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Output Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Input Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 20:33:18 --> Language Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Loader Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Controller Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Model Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Model Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Model Class Initialized
DEBUG - 2011-06-28 20:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-28 20:33:18 --> Database Driver Class Initialized
DEBUG - 2011-06-28 20:33:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-28 20:33:18 --> Helper loaded: url_helper
DEBUG - 2011-06-28 20:33:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 20:33:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 20:33:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 20:33:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 20:33:18 --> Final output sent to browser
DEBUG - 2011-06-28 20:33:18 --> Total execution time: 0.0486
DEBUG - 2011-06-28 22:26:26 --> Config Class Initialized
DEBUG - 2011-06-28 22:26:26 --> Hooks Class Initialized
DEBUG - 2011-06-28 22:26:26 --> Utf8 Class Initialized
DEBUG - 2011-06-28 22:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-28 22:26:26 --> URI Class Initialized
DEBUG - 2011-06-28 22:26:26 --> Router Class Initialized
DEBUG - 2011-06-28 22:26:26 --> No URI present. Default controller set.
DEBUG - 2011-06-28 22:26:27 --> Output Class Initialized
DEBUG - 2011-06-28 22:26:27 --> Input Class Initialized
DEBUG - 2011-06-28 22:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-28 22:26:27 --> Language Class Initialized
DEBUG - 2011-06-28 22:26:27 --> Loader Class Initialized
DEBUG - 2011-06-28 22:26:27 --> Controller Class Initialized
DEBUG - 2011-06-28 22:26:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-28 22:26:27 --> Helper loaded: url_helper
DEBUG - 2011-06-28 22:26:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-28 22:26:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-28 22:26:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-28 22:26:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-28 22:26:27 --> Final output sent to browser
DEBUG - 2011-06-28 22:26:27 --> Total execution time: 0.9006

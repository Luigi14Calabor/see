<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-27 02:20:47 --> Config Class Initialized
DEBUG - 2011-07-27 02:20:47 --> Hooks Class Initialized
DEBUG - 2011-07-27 02:20:47 --> Utf8 Class Initialized
DEBUG - 2011-07-27 02:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 02:20:47 --> URI Class Initialized
DEBUG - 2011-07-27 02:20:47 --> Router Class Initialized
DEBUG - 2011-07-27 02:20:47 --> Output Class Initialized
DEBUG - 2011-07-27 02:20:47 --> Input Class Initialized
DEBUG - 2011-07-27 02:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 02:20:47 --> Language Class Initialized
DEBUG - 2011-07-27 02:20:48 --> Loader Class Initialized
DEBUG - 2011-07-27 02:20:48 --> Controller Class Initialized
DEBUG - 2011-07-27 02:20:48 --> Model Class Initialized
DEBUG - 2011-07-27 02:20:48 --> Model Class Initialized
DEBUG - 2011-07-27 02:20:48 --> Model Class Initialized
DEBUG - 2011-07-27 02:20:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 02:20:48 --> Database Driver Class Initialized
DEBUG - 2011-07-27 02:20:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 02:20:49 --> Helper loaded: url_helper
DEBUG - 2011-07-27 02:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 02:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 02:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 02:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 02:20:49 --> Final output sent to browser
DEBUG - 2011-07-27 02:20:49 --> Total execution time: 1.6223
DEBUG - 2011-07-27 02:20:50 --> Config Class Initialized
DEBUG - 2011-07-27 02:20:50 --> Hooks Class Initialized
DEBUG - 2011-07-27 02:20:50 --> Utf8 Class Initialized
DEBUG - 2011-07-27 02:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 02:20:50 --> URI Class Initialized
DEBUG - 2011-07-27 02:20:50 --> Router Class Initialized
ERROR - 2011-07-27 02:20:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 02:21:38 --> Config Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Hooks Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Utf8 Class Initialized
DEBUG - 2011-07-27 02:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 02:21:38 --> URI Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Router Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Output Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Input Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 02:21:38 --> Language Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Loader Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Controller Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Model Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Model Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Model Class Initialized
DEBUG - 2011-07-27 02:21:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 02:21:38 --> Database Driver Class Initialized
DEBUG - 2011-07-27 02:21:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 02:21:38 --> Helper loaded: url_helper
DEBUG - 2011-07-27 02:21:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 02:21:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 02:21:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 02:21:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 02:21:38 --> Final output sent to browser
DEBUG - 2011-07-27 02:21:38 --> Total execution time: 0.1295
DEBUG - 2011-07-27 03:49:42 --> Config Class Initialized
DEBUG - 2011-07-27 03:49:42 --> Hooks Class Initialized
DEBUG - 2011-07-27 03:49:42 --> Utf8 Class Initialized
DEBUG - 2011-07-27 03:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 03:49:42 --> URI Class Initialized
DEBUG - 2011-07-27 03:49:42 --> Router Class Initialized
DEBUG - 2011-07-27 03:49:42 --> No URI present. Default controller set.
DEBUG - 2011-07-27 03:49:42 --> Output Class Initialized
DEBUG - 2011-07-27 03:49:42 --> Input Class Initialized
DEBUG - 2011-07-27 03:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 03:49:42 --> Language Class Initialized
DEBUG - 2011-07-27 03:49:42 --> Loader Class Initialized
DEBUG - 2011-07-27 03:49:42 --> Controller Class Initialized
DEBUG - 2011-07-27 03:49:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-27 03:49:42 --> Helper loaded: url_helper
DEBUG - 2011-07-27 03:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 03:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 03:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 03:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 03:49:42 --> Final output sent to browser
DEBUG - 2011-07-27 03:49:42 --> Total execution time: 0.0242
DEBUG - 2011-07-27 04:49:41 --> Config Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:49:41 --> URI Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Router Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Output Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Input Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:49:41 --> Language Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Loader Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Controller Class Initialized
ERROR - 2011-07-27 04:49:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:49:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:49:41 --> Model Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Model Class Initialized
DEBUG - 2011-07-27 04:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:49:41 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:49:42 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:49:42 --> Final output sent to browser
DEBUG - 2011-07-27 04:49:42 --> Total execution time: 1.2331
DEBUG - 2011-07-27 04:49:43 --> Config Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:49:43 --> URI Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Router Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Output Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Input Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:49:43 --> Language Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Loader Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Controller Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Model Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Model Class Initialized
DEBUG - 2011-07-27 04:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:49:43 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:49:44 --> Final output sent to browser
DEBUG - 2011-07-27 04:49:44 --> Total execution time: 0.8225
DEBUG - 2011-07-27 04:49:46 --> Config Class Initialized
DEBUG - 2011-07-27 04:49:46 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:49:46 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:49:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:49:46 --> URI Class Initialized
DEBUG - 2011-07-27 04:49:46 --> Router Class Initialized
ERROR - 2011-07-27 04:49:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 04:49:47 --> Config Class Initialized
DEBUG - 2011-07-27 04:49:47 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:49:47 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:49:47 --> URI Class Initialized
DEBUG - 2011-07-27 04:49:47 --> Router Class Initialized
ERROR - 2011-07-27 04:49:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 04:50:13 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:13 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:13 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Controller Class Initialized
ERROR - 2011-07-27 04:50:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:50:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:50:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:13 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:13 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:13 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:50:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:50:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:50:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:50:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:50:13 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:13 --> Total execution time: 0.0269
DEBUG - 2011-07-27 04:50:14 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:14 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:14 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Controller Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:14 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:15 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:15 --> Total execution time: 0.6618
DEBUG - 2011-07-27 04:50:24 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:24 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:24 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Controller Class Initialized
ERROR - 2011-07-27 04:50:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:50:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:50:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:24 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:24 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:24 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:50:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:50:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:50:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:50:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:50:24 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:24 --> Total execution time: 0.0292
DEBUG - 2011-07-27 04:50:25 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:25 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:25 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Controller Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:25 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:25 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:25 --> Total execution time: 0.5877
DEBUG - 2011-07-27 04:50:34 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:34 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:34 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Controller Class Initialized
ERROR - 2011-07-27 04:50:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:50:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:34 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:34 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:34 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:50:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:50:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:50:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:50:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:50:34 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:34 --> Total execution time: 0.1056
DEBUG - 2011-07-27 04:50:34 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:34 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:34 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Controller Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:34 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:35 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:35 --> Total execution time: 0.7162
DEBUG - 2011-07-27 04:50:42 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:42 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:42 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Controller Class Initialized
ERROR - 2011-07-27 04:50:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:50:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:42 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:42 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:42 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:50:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:50:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:50:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:50:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:50:42 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:42 --> Total execution time: 0.1757
DEBUG - 2011-07-27 04:50:43 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:43 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:43 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Controller Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:43 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:44 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:44 --> Total execution time: 0.8323
DEBUG - 2011-07-27 04:50:52 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:52 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:52 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Controller Class Initialized
ERROR - 2011-07-27 04:50:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:50:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:50:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:52 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:52 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:53 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:50:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:50:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:50:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:50:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:50:53 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:53 --> Total execution time: 0.0275
DEBUG - 2011-07-27 04:50:53 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:53 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:53 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Controller Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:53 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:54 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:54 --> Total execution time: 0.5397
DEBUG - 2011-07-27 04:50:57 --> Config Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:50:57 --> URI Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Router Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Output Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Input Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:50:57 --> Language Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Loader Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Controller Class Initialized
ERROR - 2011-07-27 04:50:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:50:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:50:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:57 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Model Class Initialized
DEBUG - 2011-07-27 04:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:50:57 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:50:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:50:57 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:50:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:50:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:50:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:50:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:50:57 --> Final output sent to browser
DEBUG - 2011-07-27 04:50:57 --> Total execution time: 0.0291
DEBUG - 2011-07-27 04:51:04 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:04 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:04 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:04 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:04 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:04 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:04 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:04 --> Total execution time: 0.0302
DEBUG - 2011-07-27 04:51:05 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:05 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:05 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Controller Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:05 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:06 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:06 --> Total execution time: 0.8319
DEBUG - 2011-07-27 04:51:07 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:07 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:07 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:07 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:07 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:08 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:08 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:08 --> Total execution time: 0.0708
DEBUG - 2011-07-27 04:51:12 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:12 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:12 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:12 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:12 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:12 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:12 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:12 --> Total execution time: 0.0886
DEBUG - 2011-07-27 04:51:13 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:13 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:13 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Controller Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:13 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:13 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:13 --> Total execution time: 0.5482
DEBUG - 2011-07-27 04:51:21 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:21 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:21 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:21 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:21 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:21 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:21 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:21 --> Total execution time: 0.1418
DEBUG - 2011-07-27 04:51:22 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:22 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:22 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Controller Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:22 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:23 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:23 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:23 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:23 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:23 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:23 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:23 --> Total execution time: 0.0459
DEBUG - 2011-07-27 04:51:23 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:23 --> Total execution time: 1.3527
DEBUG - 2011-07-27 04:51:37 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:37 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:37 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:37 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:37 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:37 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:37 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:37 --> Total execution time: 0.0675
DEBUG - 2011-07-27 04:51:37 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:37 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:37 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Controller Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:38 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:38 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:38 --> Total execution time: 0.8314
DEBUG - 2011-07-27 04:51:41 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:41 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:41 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:41 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:41 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:41 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:41 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:41 --> Total execution time: 0.0368
DEBUG - 2011-07-27 04:51:46 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:46 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:46 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:46 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:46 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:46 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:46 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:46 --> Total execution time: 0.0800
DEBUG - 2011-07-27 04:51:47 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:47 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:47 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Controller Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:47 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:47 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:47 --> Total execution time: 0.6841
DEBUG - 2011-07-27 04:51:52 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:52 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:52 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:52 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:52 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:52 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:52 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:52 --> Total execution time: 0.0276
DEBUG - 2011-07-27 04:51:52 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:52 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:52 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Controller Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:52 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:53 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:53 --> Total execution time: 0.6357
DEBUG - 2011-07-27 04:51:56 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:56 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:56 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Controller Class Initialized
ERROR - 2011-07-27 04:51:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:51:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:51:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:56 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:56 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:51:56 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:51:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:51:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:51:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:51:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:51:56 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:56 --> Total execution time: 0.0372
DEBUG - 2011-07-27 04:51:57 --> Config Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:51:57 --> URI Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Router Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Output Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Input Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:51:57 --> Language Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Loader Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Controller Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Model Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:51:57 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:51:57 --> Final output sent to browser
DEBUG - 2011-07-27 04:51:57 --> Total execution time: 0.6016
DEBUG - 2011-07-27 04:52:05 --> Config Class Initialized
DEBUG - 2011-07-27 04:52:05 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:52:05 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:52:05 --> URI Class Initialized
DEBUG - 2011-07-27 04:52:05 --> Router Class Initialized
DEBUG - 2011-07-27 04:52:05 --> Output Class Initialized
DEBUG - 2011-07-27 04:52:05 --> Input Class Initialized
DEBUG - 2011-07-27 04:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:52:06 --> Language Class Initialized
DEBUG - 2011-07-27 04:52:06 --> Loader Class Initialized
DEBUG - 2011-07-27 04:52:06 --> Controller Class Initialized
ERROR - 2011-07-27 04:52:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:52:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:52:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:52:06 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:06 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:52:06 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:52:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:52:06 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:52:06 --> Final output sent to browser
DEBUG - 2011-07-27 04:52:06 --> Total execution time: 0.0277
DEBUG - 2011-07-27 04:52:07 --> Config Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:52:07 --> URI Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Router Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Output Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Input Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:52:07 --> Language Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Loader Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Controller Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:52:07 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:52:07 --> Final output sent to browser
DEBUG - 2011-07-27 04:52:07 --> Total execution time: 0.6777
DEBUG - 2011-07-27 04:52:11 --> Config Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:52:11 --> URI Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Router Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Output Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Input Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:52:11 --> Language Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Loader Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Controller Class Initialized
ERROR - 2011-07-27 04:52:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:52:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:52:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:52:11 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:52:11 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:52:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:52:11 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:52:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:52:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:52:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:52:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:52:11 --> Final output sent to browser
DEBUG - 2011-07-27 04:52:11 --> Total execution time: 0.0370
DEBUG - 2011-07-27 04:52:12 --> Config Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:52:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:52:12 --> URI Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Router Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Output Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Input Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:52:12 --> Language Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Loader Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Controller Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:52:12 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:52:12 --> Final output sent to browser
DEBUG - 2011-07-27 04:52:12 --> Total execution time: 0.5688
DEBUG - 2011-07-27 04:52:28 --> Config Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:52:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:52:28 --> URI Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Router Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Output Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Input Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:52:28 --> Language Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Loader Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Controller Class Initialized
ERROR - 2011-07-27 04:52:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:52:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:52:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:52:28 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:52:28 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:52:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:52:28 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:52:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:52:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:52:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:52:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:52:28 --> Final output sent to browser
DEBUG - 2011-07-27 04:52:28 --> Total execution time: 0.0300
DEBUG - 2011-07-27 04:52:41 --> Config Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:52:41 --> URI Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Router Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Output Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Input Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:52:41 --> Language Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Loader Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Controller Class Initialized
ERROR - 2011-07-27 04:52:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:52:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:52:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:52:41 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Model Class Initialized
DEBUG - 2011-07-27 04:52:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:52:41 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:52:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:52:41 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:52:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:52:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:52:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:52:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:52:41 --> Final output sent to browser
DEBUG - 2011-07-27 04:52:41 --> Total execution time: 0.0387
DEBUG - 2011-07-27 04:53:01 --> Config Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Hooks Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Utf8 Class Initialized
DEBUG - 2011-07-27 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 04:53:01 --> URI Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Router Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Output Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Input Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 04:53:01 --> Language Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Loader Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Controller Class Initialized
ERROR - 2011-07-27 04:53:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 04:53:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 04:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:53:01 --> Model Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Model Class Initialized
DEBUG - 2011-07-27 04:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 04:53:01 --> Database Driver Class Initialized
DEBUG - 2011-07-27 04:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 04:53:01 --> Helper loaded: url_helper
DEBUG - 2011-07-27 04:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 04:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 04:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 04:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 04:53:01 --> Final output sent to browser
DEBUG - 2011-07-27 04:53:01 --> Total execution time: 0.0342
DEBUG - 2011-07-27 09:16:38 --> Config Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:16:38 --> URI Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Router Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Output Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Input Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 09:16:38 --> Language Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Loader Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Controller Class Initialized
ERROR - 2011-07-27 09:16:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 09:16:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 09:16:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 09:16:38 --> Model Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Model Class Initialized
DEBUG - 2011-07-27 09:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 09:16:38 --> Database Driver Class Initialized
DEBUG - 2011-07-27 09:16:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 09:16:39 --> Helper loaded: url_helper
DEBUG - 2011-07-27 09:16:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 09:16:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 09:16:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 09:16:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 09:16:39 --> Final output sent to browser
DEBUG - 2011-07-27 09:16:39 --> Total execution time: 0.9730
DEBUG - 2011-07-27 09:16:39 --> Config Class Initialized
DEBUG - 2011-07-27 09:16:39 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:16:39 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:16:40 --> URI Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Router Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Output Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Input Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 09:16:40 --> Language Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Loader Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Controller Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Model Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Model Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 09:16:40 --> Database Driver Class Initialized
DEBUG - 2011-07-27 09:16:40 --> Final output sent to browser
DEBUG - 2011-07-27 09:16:40 --> Total execution time: 0.9543
DEBUG - 2011-07-27 09:16:41 --> Config Class Initialized
DEBUG - 2011-07-27 09:16:41 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:16:41 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:16:41 --> URI Class Initialized
DEBUG - 2011-07-27 09:16:41 --> Router Class Initialized
ERROR - 2011-07-27 09:16:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 09:16:42 --> Config Class Initialized
DEBUG - 2011-07-27 09:16:42 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:16:42 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:16:42 --> URI Class Initialized
DEBUG - 2011-07-27 09:16:42 --> Router Class Initialized
ERROR - 2011-07-27 09:16:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 09:17:35 --> Config Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:17:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:17:35 --> URI Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Router Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Output Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Input Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 09:17:35 --> Language Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Loader Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Controller Class Initialized
ERROR - 2011-07-27 09:17:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 09:17:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 09:17:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 09:17:35 --> Model Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Model Class Initialized
DEBUG - 2011-07-27 09:17:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 09:17:35 --> Database Driver Class Initialized
DEBUG - 2011-07-27 09:17:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 09:17:35 --> Helper loaded: url_helper
DEBUG - 2011-07-27 09:17:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 09:17:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 09:17:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 09:17:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 09:17:35 --> Final output sent to browser
DEBUG - 2011-07-27 09:17:35 --> Total execution time: 0.0353
DEBUG - 2011-07-27 09:17:36 --> Config Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:17:36 --> URI Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Router Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Output Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Input Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 09:17:36 --> Language Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Loader Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Controller Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Model Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Model Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 09:17:36 --> Database Driver Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Final output sent to browser
DEBUG - 2011-07-27 09:17:36 --> Total execution time: 0.8616
DEBUG - 2011-07-27 09:17:36 --> Config Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:17:36 --> URI Class Initialized
DEBUG - 2011-07-27 09:17:36 --> Router Class Initialized
ERROR - 2011-07-27 09:17:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-27 09:17:37 --> Config Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:17:37 --> URI Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Router Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Output Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Input Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 09:17:37 --> Language Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Loader Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Controller Class Initialized
ERROR - 2011-07-27 09:17:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 09:17:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 09:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 09:17:37 --> Model Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Model Class Initialized
DEBUG - 2011-07-27 09:17:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 09:17:37 --> Database Driver Class Initialized
DEBUG - 2011-07-27 09:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 09:17:37 --> Helper loaded: url_helper
DEBUG - 2011-07-27 09:17:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 09:17:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 09:17:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 09:17:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 09:17:37 --> Final output sent to browser
DEBUG - 2011-07-27 09:17:37 --> Total execution time: 0.0279
DEBUG - 2011-07-27 09:19:34 --> Config Class Initialized
DEBUG - 2011-07-27 09:19:34 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:19:34 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:19:34 --> URI Class Initialized
DEBUG - 2011-07-27 09:19:34 --> Router Class Initialized
ERROR - 2011-07-27 09:19:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-27 09:19:37 --> Config Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Hooks Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Utf8 Class Initialized
DEBUG - 2011-07-27 09:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 09:19:37 --> URI Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Router Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Output Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Input Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 09:19:37 --> Language Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Loader Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Controller Class Initialized
ERROR - 2011-07-27 09:19:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 09:19:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 09:19:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 09:19:37 --> Model Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Model Class Initialized
DEBUG - 2011-07-27 09:19:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 09:19:37 --> Database Driver Class Initialized
DEBUG - 2011-07-27 09:19:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 09:19:37 --> Helper loaded: url_helper
DEBUG - 2011-07-27 09:19:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 09:19:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 09:19:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 09:19:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 09:19:37 --> Final output sent to browser
DEBUG - 2011-07-27 09:19:37 --> Total execution time: 0.1099
DEBUG - 2011-07-27 10:04:37 --> Config Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Hooks Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Utf8 Class Initialized
DEBUG - 2011-07-27 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 10:04:37 --> URI Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Router Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Output Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Input Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 10:04:37 --> Language Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Loader Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Controller Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Model Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Model Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Model Class Initialized
DEBUG - 2011-07-27 10:04:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 10:04:37 --> Database Driver Class Initialized
DEBUG - 2011-07-27 10:04:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 10:04:38 --> Helper loaded: url_helper
DEBUG - 2011-07-27 10:04:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 10:04:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 10:04:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 10:04:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 10:04:38 --> Final output sent to browser
DEBUG - 2011-07-27 10:04:38 --> Total execution time: 0.5919
DEBUG - 2011-07-27 10:04:40 --> Config Class Initialized
DEBUG - 2011-07-27 10:04:40 --> Hooks Class Initialized
DEBUG - 2011-07-27 10:04:40 --> Utf8 Class Initialized
DEBUG - 2011-07-27 10:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 10:04:40 --> URI Class Initialized
DEBUG - 2011-07-27 10:04:40 --> Router Class Initialized
ERROR - 2011-07-27 10:04:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 11:52:14 --> Config Class Initialized
DEBUG - 2011-07-27 11:52:14 --> Hooks Class Initialized
DEBUG - 2011-07-27 11:52:14 --> Utf8 Class Initialized
DEBUG - 2011-07-27 11:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 11:52:14 --> URI Class Initialized
DEBUG - 2011-07-27 11:52:14 --> Router Class Initialized
DEBUG - 2011-07-27 11:52:14 --> No URI present. Default controller set.
DEBUG - 2011-07-27 11:52:14 --> Output Class Initialized
DEBUG - 2011-07-27 11:52:14 --> Input Class Initialized
DEBUG - 2011-07-27 11:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 11:52:14 --> Language Class Initialized
DEBUG - 2011-07-27 11:52:14 --> Loader Class Initialized
DEBUG - 2011-07-27 11:52:14 --> Controller Class Initialized
DEBUG - 2011-07-27 11:52:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-27 11:52:14 --> Helper loaded: url_helper
DEBUG - 2011-07-27 11:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 11:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 11:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 11:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 11:52:14 --> Final output sent to browser
DEBUG - 2011-07-27 11:52:14 --> Total execution time: 0.0951
DEBUG - 2011-07-27 13:18:23 --> Config Class Initialized
DEBUG - 2011-07-27 13:18:23 --> Hooks Class Initialized
DEBUG - 2011-07-27 13:18:23 --> Utf8 Class Initialized
DEBUG - 2011-07-27 13:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 13:18:23 --> URI Class Initialized
DEBUG - 2011-07-27 13:18:23 --> Router Class Initialized
DEBUG - 2011-07-27 13:18:23 --> Output Class Initialized
DEBUG - 2011-07-27 13:18:23 --> Input Class Initialized
DEBUG - 2011-07-27 13:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 13:18:23 --> Language Class Initialized
DEBUG - 2011-07-27 13:18:23 --> Loader Class Initialized
DEBUG - 2011-07-27 13:18:23 --> Controller Class Initialized
ERROR - 2011-07-27 13:18:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 13:18:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 13:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 13:18:24 --> Model Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Model Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 13:18:24 --> Database Driver Class Initialized
DEBUG - 2011-07-27 13:18:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 13:18:24 --> Helper loaded: url_helper
DEBUG - 2011-07-27 13:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 13:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 13:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 13:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 13:18:24 --> Final output sent to browser
DEBUG - 2011-07-27 13:18:24 --> Total execution time: 0.1592
DEBUG - 2011-07-27 13:18:24 --> Config Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Hooks Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Utf8 Class Initialized
DEBUG - 2011-07-27 13:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 13:18:24 --> URI Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Router Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Output Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Input Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 13:18:24 --> Language Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Loader Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Controller Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Model Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Model Class Initialized
DEBUG - 2011-07-27 13:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 13:18:24 --> Database Driver Class Initialized
DEBUG - 2011-07-27 13:18:25 --> Final output sent to browser
DEBUG - 2011-07-27 13:18:25 --> Total execution time: 0.6163
DEBUG - 2011-07-27 13:18:25 --> Config Class Initialized
DEBUG - 2011-07-27 13:18:25 --> Hooks Class Initialized
DEBUG - 2011-07-27 13:18:25 --> Utf8 Class Initialized
DEBUG - 2011-07-27 13:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 13:18:25 --> URI Class Initialized
DEBUG - 2011-07-27 13:18:25 --> Router Class Initialized
ERROR - 2011-07-27 13:18:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 13:18:25 --> Config Class Initialized
DEBUG - 2011-07-27 13:18:25 --> Hooks Class Initialized
DEBUG - 2011-07-27 13:18:25 --> Utf8 Class Initialized
DEBUG - 2011-07-27 13:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 13:18:25 --> URI Class Initialized
DEBUG - 2011-07-27 13:18:25 --> Router Class Initialized
ERROR - 2011-07-27 13:18:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 13:18:26 --> Config Class Initialized
DEBUG - 2011-07-27 13:18:26 --> Hooks Class Initialized
DEBUG - 2011-07-27 13:18:26 --> Utf8 Class Initialized
DEBUG - 2011-07-27 13:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 13:18:26 --> URI Class Initialized
DEBUG - 2011-07-27 13:18:26 --> Router Class Initialized
ERROR - 2011-07-27 13:18:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 14:16:52 --> Config Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:16:52 --> URI Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Router Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Output Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Input Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 14:16:52 --> Language Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Loader Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Controller Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Model Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Model Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Model Class Initialized
DEBUG - 2011-07-27 14:16:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 14:16:52 --> Database Driver Class Initialized
DEBUG - 2011-07-27 14:16:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 14:16:53 --> Helper loaded: url_helper
DEBUG - 2011-07-27 14:16:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 14:16:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 14:16:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 14:16:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 14:16:53 --> Final output sent to browser
DEBUG - 2011-07-27 14:16:53 --> Total execution time: 0.3435
DEBUG - 2011-07-27 14:16:54 --> Config Class Initialized
DEBUG - 2011-07-27 14:16:54 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:16:54 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:16:54 --> URI Class Initialized
DEBUG - 2011-07-27 14:16:54 --> Router Class Initialized
ERROR - 2011-07-27 14:16:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 14:17:06 --> Config Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:17:06 --> URI Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Router Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Output Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Input Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 14:17:06 --> Language Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Loader Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Controller Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 14:17:06 --> Database Driver Class Initialized
DEBUG - 2011-07-27 14:17:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 14:17:07 --> Helper loaded: url_helper
DEBUG - 2011-07-27 14:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 14:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 14:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 14:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 14:17:07 --> Final output sent to browser
DEBUG - 2011-07-27 14:17:07 --> Total execution time: 1.1173
DEBUG - 2011-07-27 14:17:09 --> Config Class Initialized
DEBUG - 2011-07-27 14:17:09 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:17:09 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:17:09 --> URI Class Initialized
DEBUG - 2011-07-27 14:17:09 --> Router Class Initialized
ERROR - 2011-07-27 14:17:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 14:17:16 --> Config Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:17:16 --> URI Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Router Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Output Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Input Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 14:17:16 --> Language Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Loader Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Controller Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 14:17:16 --> Database Driver Class Initialized
DEBUG - 2011-07-27 14:17:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 14:17:16 --> Helper loaded: url_helper
DEBUG - 2011-07-27 14:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 14:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 14:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 14:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 14:17:16 --> Final output sent to browser
DEBUG - 2011-07-27 14:17:16 --> Total execution time: 0.2687
DEBUG - 2011-07-27 14:17:24 --> Config Class Initialized
DEBUG - 2011-07-27 14:17:24 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:17:24 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:17:24 --> URI Class Initialized
DEBUG - 2011-07-27 14:17:24 --> Router Class Initialized
ERROR - 2011-07-27 14:17:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 14:17:30 --> Config Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:17:30 --> URI Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Router Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Output Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Input Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 14:17:30 --> Language Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Loader Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Controller Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 14:17:30 --> Database Driver Class Initialized
DEBUG - 2011-07-27 14:17:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 14:17:30 --> Helper loaded: url_helper
DEBUG - 2011-07-27 14:17:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 14:17:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 14:17:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 14:17:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 14:17:30 --> Final output sent to browser
DEBUG - 2011-07-27 14:17:30 --> Total execution time: 0.2708
DEBUG - 2011-07-27 14:17:31 --> Config Class Initialized
DEBUG - 2011-07-27 14:17:31 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:17:31 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:17:31 --> URI Class Initialized
DEBUG - 2011-07-27 14:17:31 --> Router Class Initialized
ERROR - 2011-07-27 14:17:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 14:17:56 --> Config Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:17:56 --> URI Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Router Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Output Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Input Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 14:17:56 --> Language Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Loader Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Controller Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 14:17:56 --> Database Driver Class Initialized
DEBUG - 2011-07-27 14:17:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 14:17:56 --> Helper loaded: url_helper
DEBUG - 2011-07-27 14:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 14:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 14:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 14:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 14:17:56 --> Final output sent to browser
DEBUG - 2011-07-27 14:17:56 --> Total execution time: 0.0889
DEBUG - 2011-07-27 14:17:59 --> Config Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:17:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:17:59 --> URI Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Router Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Output Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Input Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 14:17:59 --> Language Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Loader Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Controller Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Model Class Initialized
DEBUG - 2011-07-27 14:17:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 14:17:59 --> Database Driver Class Initialized
DEBUG - 2011-07-27 14:17:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 14:17:59 --> Helper loaded: url_helper
DEBUG - 2011-07-27 14:17:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 14:17:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 14:17:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 14:17:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 14:17:59 --> Final output sent to browser
DEBUG - 2011-07-27 14:17:59 --> Total execution time: 0.0511
DEBUG - 2011-07-27 14:18:03 --> Config Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Hooks Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Utf8 Class Initialized
DEBUG - 2011-07-27 14:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 14:18:03 --> URI Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Router Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Output Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Input Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 14:18:03 --> Language Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Loader Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Controller Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Model Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Model Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Model Class Initialized
DEBUG - 2011-07-27 14:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 14:18:03 --> Database Driver Class Initialized
DEBUG - 2011-07-27 14:18:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 14:18:03 --> Helper loaded: url_helper
DEBUG - 2011-07-27 14:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 14:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 14:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 14:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 14:18:03 --> Final output sent to browser
DEBUG - 2011-07-27 14:18:03 --> Total execution time: 0.0479
DEBUG - 2011-07-27 15:11:14 --> Config Class Initialized
DEBUG - 2011-07-27 15:11:14 --> Hooks Class Initialized
DEBUG - 2011-07-27 15:11:14 --> Utf8 Class Initialized
DEBUG - 2011-07-27 15:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 15:11:14 --> URI Class Initialized
DEBUG - 2011-07-27 15:11:14 --> Router Class Initialized
ERROR - 2011-07-27 15:11:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 15:27:11 --> Config Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Hooks Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Utf8 Class Initialized
DEBUG - 2011-07-27 15:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 15:27:11 --> URI Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Router Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Output Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Input Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 15:27:11 --> Language Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Loader Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Controller Class Initialized
ERROR - 2011-07-27 15:27:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 15:27:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 15:27:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 15:27:11 --> Model Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Model Class Initialized
DEBUG - 2011-07-27 15:27:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 15:27:11 --> Database Driver Class Initialized
DEBUG - 2011-07-27 15:27:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 15:27:11 --> Helper loaded: url_helper
DEBUG - 2011-07-27 15:27:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 15:27:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 15:27:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 15:27:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 15:27:11 --> Final output sent to browser
DEBUG - 2011-07-27 15:27:11 --> Total execution time: 0.0855
DEBUG - 2011-07-27 15:53:19 --> Config Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Hooks Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Utf8 Class Initialized
DEBUG - 2011-07-27 15:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 15:53:19 --> URI Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Router Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Output Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Input Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 15:53:19 --> Language Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Loader Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Controller Class Initialized
ERROR - 2011-07-27 15:53:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 15:53:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 15:53:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 15:53:19 --> Model Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Model Class Initialized
DEBUG - 2011-07-27 15:53:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 15:53:19 --> Database Driver Class Initialized
DEBUG - 2011-07-27 15:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 15:53:20 --> Helper loaded: url_helper
DEBUG - 2011-07-27 15:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 15:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 15:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 15:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 15:53:20 --> Final output sent to browser
DEBUG - 2011-07-27 15:53:20 --> Total execution time: 0.0903
DEBUG - 2011-07-27 15:53:20 --> Config Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Hooks Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Utf8 Class Initialized
DEBUG - 2011-07-27 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 15:53:20 --> URI Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Router Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Output Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Input Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 15:53:20 --> Language Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Loader Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Controller Class Initialized
DEBUG - 2011-07-27 15:53:20 --> Model Class Initialized
DEBUG - 2011-07-27 15:53:21 --> Model Class Initialized
DEBUG - 2011-07-27 15:53:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 15:53:21 --> Database Driver Class Initialized
DEBUG - 2011-07-27 15:53:21 --> Final output sent to browser
DEBUG - 2011-07-27 15:53:21 --> Total execution time: 0.9158
DEBUG - 2011-07-27 15:53:22 --> Config Class Initialized
DEBUG - 2011-07-27 15:53:22 --> Hooks Class Initialized
DEBUG - 2011-07-27 15:53:22 --> Utf8 Class Initialized
DEBUG - 2011-07-27 15:53:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 15:53:22 --> URI Class Initialized
DEBUG - 2011-07-27 15:53:22 --> Router Class Initialized
ERROR - 2011-07-27 15:53:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 15:53:23 --> Config Class Initialized
DEBUG - 2011-07-27 15:53:23 --> Hooks Class Initialized
DEBUG - 2011-07-27 15:53:23 --> Utf8 Class Initialized
DEBUG - 2011-07-27 15:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 15:53:23 --> URI Class Initialized
DEBUG - 2011-07-27 15:53:23 --> Router Class Initialized
ERROR - 2011-07-27 15:53:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 15:53:44 --> Config Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Hooks Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Utf8 Class Initialized
DEBUG - 2011-07-27 15:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 15:53:44 --> URI Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Router Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Output Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Input Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 15:53:44 --> Language Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Loader Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Controller Class Initialized
ERROR - 2011-07-27 15:53:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 15:53:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 15:53:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 15:53:44 --> Model Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Model Class Initialized
DEBUG - 2011-07-27 15:53:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 15:53:44 --> Database Driver Class Initialized
DEBUG - 2011-07-27 15:53:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 15:53:44 --> Helper loaded: url_helper
DEBUG - 2011-07-27 15:53:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 15:53:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 15:53:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 15:53:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 15:53:44 --> Final output sent to browser
DEBUG - 2011-07-27 15:53:44 --> Total execution time: 0.0823
DEBUG - 2011-07-27 15:53:45 --> Config Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Hooks Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Utf8 Class Initialized
DEBUG - 2011-07-27 15:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 15:53:45 --> URI Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Router Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Output Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Input Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 15:53:45 --> Language Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Loader Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Controller Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Model Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Model Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 15:53:45 --> Database Driver Class Initialized
DEBUG - 2011-07-27 15:53:45 --> Final output sent to browser
DEBUG - 2011-07-27 15:53:45 --> Total execution time: 0.6716
DEBUG - 2011-07-27 16:24:06 --> Config Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Hooks Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Utf8 Class Initialized
DEBUG - 2011-07-27 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 16:24:06 --> URI Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Router Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Output Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Input Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 16:24:06 --> Language Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Loader Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Controller Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Model Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Model Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Model Class Initialized
DEBUG - 2011-07-27 16:24:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 16:24:06 --> Database Driver Class Initialized
DEBUG - 2011-07-27 16:24:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 16:24:06 --> Helper loaded: url_helper
DEBUG - 2011-07-27 16:24:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 16:24:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 16:24:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 16:24:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 16:24:06 --> Final output sent to browser
DEBUG - 2011-07-27 16:24:06 --> Total execution time: 0.3120
DEBUG - 2011-07-27 19:09:11 --> Config Class Initialized
DEBUG - 2011-07-27 19:09:11 --> Hooks Class Initialized
DEBUG - 2011-07-27 19:09:11 --> Utf8 Class Initialized
DEBUG - 2011-07-27 19:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 19:09:11 --> URI Class Initialized
DEBUG - 2011-07-27 19:09:11 --> Router Class Initialized
DEBUG - 2011-07-27 19:09:11 --> No URI present. Default controller set.
DEBUG - 2011-07-27 19:09:11 --> Output Class Initialized
DEBUG - 2011-07-27 19:09:11 --> Input Class Initialized
DEBUG - 2011-07-27 19:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 19:09:11 --> Language Class Initialized
DEBUG - 2011-07-27 19:09:11 --> Loader Class Initialized
DEBUG - 2011-07-27 19:09:11 --> Controller Class Initialized
DEBUG - 2011-07-27 19:09:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-27 19:09:12 --> Helper loaded: url_helper
DEBUG - 2011-07-27 19:09:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 19:09:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 19:09:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 19:09:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 19:09:12 --> Final output sent to browser
DEBUG - 2011-07-27 19:09:12 --> Total execution time: 0.1802
DEBUG - 2011-07-27 21:00:16 --> Config Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Hooks Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Utf8 Class Initialized
DEBUG - 2011-07-27 21:00:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 21:00:16 --> URI Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Router Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Output Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Input Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 21:00:16 --> Language Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Loader Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Controller Class Initialized
ERROR - 2011-07-27 21:00:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 21:00:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 21:00:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 21:00:16 --> Model Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Model Class Initialized
DEBUG - 2011-07-27 21:00:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 21:00:16 --> Database Driver Class Initialized
DEBUG - 2011-07-27 21:00:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 21:00:16 --> Helper loaded: url_helper
DEBUG - 2011-07-27 21:00:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 21:00:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 21:00:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 21:00:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 21:00:16 --> Final output sent to browser
DEBUG - 2011-07-27 21:00:16 --> Total execution time: 0.1969
DEBUG - 2011-07-27 21:00:17 --> Config Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Hooks Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Utf8 Class Initialized
DEBUG - 2011-07-27 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 21:00:17 --> URI Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Router Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Output Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Input Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 21:00:17 --> Language Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Loader Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Controller Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Model Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Model Class Initialized
DEBUG - 2011-07-27 21:00:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 21:00:17 --> Database Driver Class Initialized
DEBUG - 2011-07-27 21:00:18 --> Final output sent to browser
DEBUG - 2011-07-27 21:00:18 --> Total execution time: 1.2397
DEBUG - 2011-07-27 21:00:19 --> Config Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Hooks Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Utf8 Class Initialized
DEBUG - 2011-07-27 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 21:00:19 --> URI Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Router Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Output Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Input Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 21:00:19 --> Language Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Loader Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Controller Class Initialized
ERROR - 2011-07-27 21:00:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 21:00:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 21:00:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 21:00:19 --> Model Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Model Class Initialized
DEBUG - 2011-07-27 21:00:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 21:00:19 --> Database Driver Class Initialized
DEBUG - 2011-07-27 21:00:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 21:00:19 --> Helper loaded: url_helper
DEBUG - 2011-07-27 21:00:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 21:00:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 21:00:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 21:00:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 21:00:19 --> Final output sent to browser
DEBUG - 2011-07-27 21:00:19 --> Total execution time: 0.0301
DEBUG - 2011-07-27 21:00:20 --> Config Class Initialized
DEBUG - 2011-07-27 21:00:20 --> Hooks Class Initialized
DEBUG - 2011-07-27 21:00:20 --> Utf8 Class Initialized
DEBUG - 2011-07-27 21:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 21:00:20 --> URI Class Initialized
DEBUG - 2011-07-27 21:00:20 --> Router Class Initialized
ERROR - 2011-07-27 21:00:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 21:00:22 --> Config Class Initialized
DEBUG - 2011-07-27 21:00:22 --> Hooks Class Initialized
DEBUG - 2011-07-27 21:00:22 --> Utf8 Class Initialized
DEBUG - 2011-07-27 21:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 21:00:22 --> URI Class Initialized
DEBUG - 2011-07-27 21:00:22 --> Router Class Initialized
ERROR - 2011-07-27 21:00:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-27 23:08:15 --> Config Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Hooks Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Utf8 Class Initialized
DEBUG - 2011-07-27 23:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 23:08:15 --> URI Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Router Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Output Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Input Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 23:08:15 --> Language Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Loader Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Controller Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Model Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Model Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Model Class Initialized
DEBUG - 2011-07-27 23:08:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 23:08:15 --> Database Driver Class Initialized
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-27 23:08:16 --> Helper loaded: url_helper
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 23:08:16 --> Final output sent to browser
DEBUG - 2011-07-27 23:08:16 --> Total execution time: 0.4520
DEBUG - 2011-07-27 23:08:16 --> Config Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Hooks Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Utf8 Class Initialized
DEBUG - 2011-07-27 23:08:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-27 23:08:16 --> URI Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Router Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Output Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Input Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-27 23:08:16 --> Language Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Loader Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Controller Class Initialized
ERROR - 2011-07-27 23:08:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-27 23:08:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 23:08:16 --> Model Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Model Class Initialized
DEBUG - 2011-07-27 23:08:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-27 23:08:16 --> Database Driver Class Initialized
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-27 23:08:16 --> Helper loaded: url_helper
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-27 23:08:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-27 23:08:16 --> Final output sent to browser
DEBUG - 2011-07-27 23:08:16 --> Total execution time: 0.0296

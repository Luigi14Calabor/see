<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-11 00:00:23 --> Config Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:00:23 --> URI Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Router Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Output Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Input Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:00:23 --> Language Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Loader Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Controller Class Initialized
ERROR - 2011-09-11 00:00:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 00:00:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 00:00:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 00:00:23 --> Model Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Model Class Initialized
DEBUG - 2011-09-11 00:00:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:00:23 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:00:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 00:00:23 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:00:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:00:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:00:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:00:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:00:23 --> Final output sent to browser
DEBUG - 2011-09-11 00:00:23 --> Total execution time: 0.1243
DEBUG - 2011-09-11 00:01:28 --> Config Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:01:28 --> URI Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Router Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Output Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Input Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:01:28 --> Language Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Loader Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Controller Class Initialized
ERROR - 2011-09-11 00:01:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 00:01:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 00:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 00:01:28 --> Model Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Model Class Initialized
DEBUG - 2011-09-11 00:01:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:01:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 00:01:28 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:01:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:01:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:01:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:01:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:01:28 --> Final output sent to browser
DEBUG - 2011-09-11 00:01:28 --> Total execution time: 0.0273
DEBUG - 2011-09-11 00:01:30 --> Config Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:01:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:01:30 --> URI Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Router Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Output Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Input Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:01:30 --> Language Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Loader Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Controller Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Model Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Model Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:01:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:01:30 --> Final output sent to browser
DEBUG - 2011-09-11 00:01:30 --> Total execution time: 0.5884
DEBUG - 2011-09-11 00:01:46 --> Config Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:01:46 --> URI Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Router Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Output Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Input Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:01:46 --> Language Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Loader Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Controller Class Initialized
ERROR - 2011-09-11 00:01:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 00:01:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 00:01:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 00:01:46 --> Model Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Model Class Initialized
DEBUG - 2011-09-11 00:01:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:01:46 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:01:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 00:01:46 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:01:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:01:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:01:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:01:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:01:46 --> Final output sent to browser
DEBUG - 2011-09-11 00:01:46 --> Total execution time: 0.0302
DEBUG - 2011-09-11 00:01:47 --> Config Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:01:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:01:47 --> URI Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Router Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Output Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Input Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:01:47 --> Language Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Loader Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Controller Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Model Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Model Class Initialized
DEBUG - 2011-09-11 00:01:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:01:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:01:48 --> Final output sent to browser
DEBUG - 2011-09-11 00:01:48 --> Total execution time: 0.5434
DEBUG - 2011-09-11 00:20:10 --> Config Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:20:10 --> URI Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Router Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Output Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Input Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:20:10 --> Language Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Loader Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Controller Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Model Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Model Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Model Class Initialized
DEBUG - 2011-09-11 00:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:20:10 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:20:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 00:20:11 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:20:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:20:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:20:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:20:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:20:11 --> Final output sent to browser
DEBUG - 2011-09-11 00:20:11 --> Total execution time: 0.4260
DEBUG - 2011-09-11 00:26:19 --> Config Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:26:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:26:19 --> URI Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Router Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Output Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Input Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:26:19 --> Language Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Loader Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Controller Class Initialized
ERROR - 2011-09-11 00:26:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 00:26:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 00:26:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 00:26:19 --> Model Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Model Class Initialized
DEBUG - 2011-09-11 00:26:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:26:19 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:26:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 00:26:19 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:26:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:26:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:26:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:26:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:26:19 --> Final output sent to browser
DEBUG - 2011-09-11 00:26:19 --> Total execution time: 0.0499
DEBUG - 2011-09-11 00:26:21 --> Config Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:26:21 --> URI Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Router Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Output Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Input Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:26:21 --> Language Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Loader Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Controller Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Model Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Model Class Initialized
DEBUG - 2011-09-11 00:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:26:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:26:22 --> Final output sent to browser
DEBUG - 2011-09-11 00:26:22 --> Total execution time: 0.4946
DEBUG - 2011-09-11 00:27:42 --> Config Class Initialized
DEBUG - 2011-09-11 00:27:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:27:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:27:42 --> URI Class Initialized
DEBUG - 2011-09-11 00:27:42 --> Router Class Initialized
ERROR - 2011-09-11 00:27:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 00:37:53 --> Config Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:37:53 --> URI Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Router Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Output Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Input Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:37:53 --> Language Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Loader Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Controller Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Model Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Model Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Model Class Initialized
DEBUG - 2011-09-11 00:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:37:53 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 00:37:53 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:37:53 --> Final output sent to browser
DEBUG - 2011-09-11 00:37:53 --> Total execution time: 0.0508
DEBUG - 2011-09-11 00:37:57 --> Config Class Initialized
DEBUG - 2011-09-11 00:37:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:37:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:37:57 --> URI Class Initialized
DEBUG - 2011-09-11 00:37:57 --> Router Class Initialized
ERROR - 2011-09-11 00:37:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 00:38:00 --> Config Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:38:00 --> URI Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Router Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Output Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Input Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:38:00 --> Language Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Loader Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Controller Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Model Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Model Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Model Class Initialized
DEBUG - 2011-09-11 00:38:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:38:00 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:38:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 00:38:00 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:38:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:38:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:38:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:38:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:38:00 --> Final output sent to browser
DEBUG - 2011-09-11 00:38:00 --> Total execution time: 0.4436
DEBUG - 2011-09-11 00:38:01 --> Config Class Initialized
DEBUG - 2011-09-11 00:38:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:38:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:38:01 --> URI Class Initialized
DEBUG - 2011-09-11 00:38:01 --> Router Class Initialized
ERROR - 2011-09-11 00:38:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 00:38:01 --> Config Class Initialized
DEBUG - 2011-09-11 00:38:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:38:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:38:01 --> URI Class Initialized
DEBUG - 2011-09-11 00:38:01 --> Router Class Initialized
ERROR - 2011-09-11 00:38:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 00:38:02 --> Config Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:38:02 --> URI Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Router Class Initialized
ERROR - 2011-09-11 00:38:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-11 00:38:02 --> Config Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:38:02 --> URI Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Router Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Output Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Input Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:38:02 --> Language Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Loader Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Controller Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Model Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Model Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Model Class Initialized
DEBUG - 2011-09-11 00:38:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:38:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:38:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 00:38:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:38:02 --> Final output sent to browser
DEBUG - 2011-09-11 00:38:02 --> Total execution time: 0.0531
DEBUG - 2011-09-11 00:43:11 --> Config Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 00:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 00:43:11 --> URI Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Router Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Output Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Input Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 00:43:11 --> Language Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Loader Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Controller Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Model Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Model Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Model Class Initialized
DEBUG - 2011-09-11 00:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 00:43:11 --> Database Driver Class Initialized
DEBUG - 2011-09-11 00:43:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 00:43:12 --> Helper loaded: url_helper
DEBUG - 2011-09-11 00:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 00:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 00:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 00:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 00:43:12 --> Final output sent to browser
DEBUG - 2011-09-11 00:43:12 --> Total execution time: 0.0441
DEBUG - 2011-09-11 01:08:05 --> Config Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 01:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 01:08:05 --> URI Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Router Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Output Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Input Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 01:08:05 --> Language Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Loader Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Controller Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Model Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Model Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Model Class Initialized
DEBUG - 2011-09-11 01:08:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 01:08:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 01:08:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 01:08:05 --> Helper loaded: url_helper
DEBUG - 2011-09-11 01:08:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 01:08:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 01:08:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 01:08:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 01:08:05 --> Final output sent to browser
DEBUG - 2011-09-11 01:08:05 --> Total execution time: 0.2631
DEBUG - 2011-09-11 01:47:28 --> Config Class Initialized
DEBUG - 2011-09-11 01:47:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 01:47:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 01:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 01:47:28 --> URI Class Initialized
DEBUG - 2011-09-11 01:47:28 --> Router Class Initialized
DEBUG - 2011-09-11 01:47:28 --> No URI present. Default controller set.
DEBUG - 2011-09-11 01:47:28 --> Output Class Initialized
DEBUG - 2011-09-11 01:47:28 --> Input Class Initialized
DEBUG - 2011-09-11 01:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 01:47:28 --> Language Class Initialized
DEBUG - 2011-09-11 01:47:28 --> Loader Class Initialized
DEBUG - 2011-09-11 01:47:28 --> Controller Class Initialized
DEBUG - 2011-09-11 01:47:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-11 01:47:28 --> Helper loaded: url_helper
DEBUG - 2011-09-11 01:47:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 01:47:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 01:47:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 01:47:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 01:47:28 --> Final output sent to browser
DEBUG - 2011-09-11 01:47:28 --> Total execution time: 0.2169
DEBUG - 2011-09-11 01:53:26 --> Config Class Initialized
DEBUG - 2011-09-11 01:53:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 01:53:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 01:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 01:53:26 --> URI Class Initialized
DEBUG - 2011-09-11 01:53:26 --> Router Class Initialized
DEBUG - 2011-09-11 01:53:26 --> No URI present. Default controller set.
DEBUG - 2011-09-11 01:53:26 --> Output Class Initialized
DEBUG - 2011-09-11 01:53:26 --> Input Class Initialized
DEBUG - 2011-09-11 01:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 01:53:26 --> Language Class Initialized
DEBUG - 2011-09-11 01:53:26 --> Loader Class Initialized
DEBUG - 2011-09-11 01:53:26 --> Controller Class Initialized
DEBUG - 2011-09-11 01:53:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-11 01:53:26 --> Helper loaded: url_helper
DEBUG - 2011-09-11 01:53:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 01:53:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 01:53:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 01:53:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 01:53:26 --> Final output sent to browser
DEBUG - 2011-09-11 01:53:26 --> Total execution time: 0.0351
DEBUG - 2011-09-11 02:15:29 --> Config Class Initialized
DEBUG - 2011-09-11 02:15:29 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:15:29 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:15:30 --> URI Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Router Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Output Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Input Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:15:30 --> Language Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Loader Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Controller Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Model Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Model Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Model Class Initialized
DEBUG - 2011-09-11 02:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:15:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:15:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 02:15:31 --> Helper loaded: url_helper
DEBUG - 2011-09-11 02:15:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 02:15:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 02:15:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 02:15:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 02:15:31 --> Final output sent to browser
DEBUG - 2011-09-11 02:15:31 --> Total execution time: 1.4828
DEBUG - 2011-09-11 02:15:39 --> Config Class Initialized
DEBUG - 2011-09-11 02:15:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:15:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:15:39 --> URI Class Initialized
DEBUG - 2011-09-11 02:15:39 --> Router Class Initialized
ERROR - 2011-09-11 02:15:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 02:15:39 --> Config Class Initialized
DEBUG - 2011-09-11 02:15:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:15:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:15:39 --> URI Class Initialized
DEBUG - 2011-09-11 02:15:39 --> Router Class Initialized
ERROR - 2011-09-11 02:15:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 02:17:13 --> Config Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:17:13 --> URI Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Router Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Output Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Input Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:17:13 --> Language Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Loader Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Controller Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:17:13 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:17:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 02:17:13 --> Helper loaded: url_helper
DEBUG - 2011-09-11 02:17:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 02:17:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 02:17:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 02:17:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 02:17:13 --> Final output sent to browser
DEBUG - 2011-09-11 02:17:13 --> Total execution time: 0.0564
DEBUG - 2011-09-11 02:17:22 --> Config Class Initialized
DEBUG - 2011-09-11 02:17:22 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:17:22 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:17:22 --> URI Class Initialized
DEBUG - 2011-09-11 02:17:22 --> Router Class Initialized
ERROR - 2011-09-11 02:17:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 02:17:22 --> Config Class Initialized
DEBUG - 2011-09-11 02:17:22 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:17:22 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:17:22 --> URI Class Initialized
DEBUG - 2011-09-11 02:17:22 --> Router Class Initialized
ERROR - 2011-09-11 02:17:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 02:17:23 --> Config Class Initialized
DEBUG - 2011-09-11 02:17:23 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:17:23 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:17:23 --> URI Class Initialized
DEBUG - 2011-09-11 02:17:23 --> Router Class Initialized
ERROR - 2011-09-11 02:17:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 02:17:35 --> Config Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:17:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:17:35 --> URI Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Router Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Output Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Input Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:17:35 --> Language Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Loader Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Controller Class Initialized
ERROR - 2011-09-11 02:17:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 02:17:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 02:17:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:17:35 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:17:35 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:17:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:17:35 --> Helper loaded: url_helper
DEBUG - 2011-09-11 02:17:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 02:17:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 02:17:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 02:17:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 02:17:35 --> Final output sent to browser
DEBUG - 2011-09-11 02:17:35 --> Total execution time: 0.0780
DEBUG - 2011-09-11 02:17:39 --> Config Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:17:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:17:39 --> URI Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Router Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Output Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Input Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:17:39 --> Language Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Loader Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Controller Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:17:39 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:17:44 --> Final output sent to browser
DEBUG - 2011-09-11 02:17:44 --> Total execution time: 4.8888
DEBUG - 2011-09-11 02:17:51 --> Config Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:17:51 --> URI Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Router Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Output Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Input Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:17:51 --> Language Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Loader Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Controller Class Initialized
ERROR - 2011-09-11 02:17:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 02:17:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 02:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:17:51 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:17:51 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:17:51 --> Helper loaded: url_helper
DEBUG - 2011-09-11 02:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 02:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 02:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 02:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 02:17:51 --> Final output sent to browser
DEBUG - 2011-09-11 02:17:51 --> Total execution time: 0.0289
DEBUG - 2011-09-11 02:17:52 --> Config Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:17:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:17:52 --> URI Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Router Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Output Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Input Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:17:52 --> Language Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Loader Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Controller Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Model Class Initialized
DEBUG - 2011-09-11 02:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:17:52 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:17:53 --> Final output sent to browser
DEBUG - 2011-09-11 02:17:53 --> Total execution time: 1.5337
DEBUG - 2011-09-11 02:19:41 --> Config Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:19:41 --> URI Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Router Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Output Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Input Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:19:41 --> Language Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Loader Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Controller Class Initialized
ERROR - 2011-09-11 02:19:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 02:19:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 02:19:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:19:41 --> Model Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Model Class Initialized
DEBUG - 2011-09-11 02:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:19:41 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:19:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:19:41 --> Helper loaded: url_helper
DEBUG - 2011-09-11 02:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 02:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 02:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 02:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 02:19:41 --> Final output sent to browser
DEBUG - 2011-09-11 02:19:41 --> Total execution time: 0.0324
DEBUG - 2011-09-11 02:19:43 --> Config Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:19:43 --> URI Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Router Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Output Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Input Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:19:43 --> Language Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Loader Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Controller Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Model Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Model Class Initialized
DEBUG - 2011-09-11 02:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:19:43 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:19:44 --> Final output sent to browser
DEBUG - 2011-09-11 02:19:44 --> Total execution time: 1.7234
DEBUG - 2011-09-11 02:20:26 --> Config Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:20:26 --> URI Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Router Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Output Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Input Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:20:26 --> Language Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Loader Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Controller Class Initialized
ERROR - 2011-09-11 02:20:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 02:20:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 02:20:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:20:26 --> Model Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Model Class Initialized
DEBUG - 2011-09-11 02:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:20:26 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:20:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:20:26 --> Helper loaded: url_helper
DEBUG - 2011-09-11 02:20:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 02:20:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 02:20:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 02:20:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 02:20:26 --> Final output sent to browser
DEBUG - 2011-09-11 02:20:26 --> Total execution time: 0.1659
DEBUG - 2011-09-11 02:20:27 --> Config Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:20:27 --> URI Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Router Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Output Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Input Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:20:27 --> Language Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Loader Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Controller Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Model Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Model Class Initialized
DEBUG - 2011-09-11 02:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:20:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:20:30 --> Final output sent to browser
DEBUG - 2011-09-11 02:20:30 --> Total execution time: 2.4409
DEBUG - 2011-09-11 02:21:03 --> Config Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:21:03 --> URI Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Router Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Output Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Input Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:21:03 --> Language Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Loader Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Controller Class Initialized
ERROR - 2011-09-11 02:21:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 02:21:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 02:21:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:21:03 --> Model Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Model Class Initialized
DEBUG - 2011-09-11 02:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:21:03 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:21:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:21:03 --> Helper loaded: url_helper
DEBUG - 2011-09-11 02:21:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 02:21:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 02:21:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 02:21:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 02:21:03 --> Final output sent to browser
DEBUG - 2011-09-11 02:21:03 --> Total execution time: 0.0959
DEBUG - 2011-09-11 02:34:04 --> Config Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:34:04 --> URI Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Router Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Output Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Input Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:34:04 --> Language Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Loader Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Controller Class Initialized
ERROR - 2011-09-11 02:34:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 02:34:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 02:34:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:34:04 --> Model Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Model Class Initialized
DEBUG - 2011-09-11 02:34:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:34:04 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:34:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 02:34:04 --> Helper loaded: url_helper
DEBUG - 2011-09-11 02:34:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 02:34:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 02:34:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 02:34:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 02:34:04 --> Final output sent to browser
DEBUG - 2011-09-11 02:34:04 --> Total execution time: 0.2991
DEBUG - 2011-09-11 02:34:06 --> Config Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:34:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:34:06 --> URI Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Router Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Output Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Input Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 02:34:06 --> Language Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Loader Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Controller Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Model Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Model Class Initialized
DEBUG - 2011-09-11 02:34:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 02:34:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 02:34:08 --> Final output sent to browser
DEBUG - 2011-09-11 02:34:08 --> Total execution time: 1.5770
DEBUG - 2011-09-11 02:34:10 --> Config Class Initialized
DEBUG - 2011-09-11 02:34:10 --> Hooks Class Initialized
DEBUG - 2011-09-11 02:34:10 --> Utf8 Class Initialized
DEBUG - 2011-09-11 02:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 02:34:10 --> URI Class Initialized
DEBUG - 2011-09-11 02:34:10 --> Router Class Initialized
ERROR - 2011-09-11 02:34:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:12:57 --> Config Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:12:57 --> URI Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Router Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Output Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Input Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:12:57 --> Language Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Loader Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Controller Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Model Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Model Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Model Class Initialized
DEBUG - 2011-09-11 03:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:12:57 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:13:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:13:01 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:13:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:13:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:13:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:13:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:13:01 --> Final output sent to browser
DEBUG - 2011-09-11 03:13:01 --> Total execution time: 3.6225
DEBUG - 2011-09-11 03:14:54 --> Config Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:14:54 --> URI Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Router Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Output Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Input Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:14:54 --> Language Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Loader Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Controller Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Model Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Model Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Model Class Initialized
DEBUG - 2011-09-11 03:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:14:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Config Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:14:59 --> URI Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Router Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Output Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Input Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:14:59 --> Language Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Loader Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Controller Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Model Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Model Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Model Class Initialized
DEBUG - 2011-09-11 03:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:14:59 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:15:04 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:15:04 --> Final output sent to browser
DEBUG - 2011-09-11 03:15:04 --> Total execution time: 4.5210
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:15:04 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:15:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:15:04 --> Final output sent to browser
DEBUG - 2011-09-11 03:15:04 --> Total execution time: 9.6256
DEBUG - 2011-09-11 03:15:18 --> Config Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:15:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:15:18 --> URI Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Router Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Output Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Input Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:15:18 --> Language Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Loader Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Controller Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Model Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Model Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Model Class Initialized
DEBUG - 2011-09-11 03:15:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:15:18 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:15:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:15:18 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:15:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:15:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:15:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:15:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:15:18 --> Final output sent to browser
DEBUG - 2011-09-11 03:15:18 --> Total execution time: 0.1056
DEBUG - 2011-09-11 03:21:33 --> Config Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:21:33 --> URI Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Router Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Output Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Input Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:21:33 --> Language Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Loader Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Controller Class Initialized
ERROR - 2011-09-11 03:21:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:21:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:21:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:21:33 --> Model Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Model Class Initialized
DEBUG - 2011-09-11 03:21:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:21:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:21:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:21:33 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:21:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:21:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:21:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:21:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:21:33 --> Final output sent to browser
DEBUG - 2011-09-11 03:21:33 --> Total execution time: 0.1992
DEBUG - 2011-09-11 03:21:36 --> Config Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:21:36 --> URI Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Router Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Output Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Input Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:21:36 --> Language Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Loader Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Controller Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Model Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Model Class Initialized
DEBUG - 2011-09-11 03:21:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:21:36 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:21:38 --> Final output sent to browser
DEBUG - 2011-09-11 03:21:38 --> Total execution time: 1.7566
DEBUG - 2011-09-11 03:21:48 --> Config Class Initialized
DEBUG - 2011-09-11 03:21:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:21:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:21:48 --> URI Class Initialized
DEBUG - 2011-09-11 03:21:48 --> Router Class Initialized
ERROR - 2011-09-11 03:21:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:21:50 --> Config Class Initialized
DEBUG - 2011-09-11 03:21:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:21:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:21:50 --> URI Class Initialized
DEBUG - 2011-09-11 03:21:50 --> Router Class Initialized
ERROR - 2011-09-11 03:21:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:22:13 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:13 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:14 --> Router Class Initialized
DEBUG - 2011-09-11 03:22:14 --> Output Class Initialized
DEBUG - 2011-09-11 03:22:14 --> Input Class Initialized
DEBUG - 2011-09-11 03:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:22:14 --> Language Class Initialized
DEBUG - 2011-09-11 03:22:14 --> Loader Class Initialized
DEBUG - 2011-09-11 03:22:14 --> Controller Class Initialized
ERROR - 2011-09-11 03:22:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:22:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:22:14 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:14 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:22:14 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:22:14 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:22:14 --> Final output sent to browser
DEBUG - 2011-09-11 03:22:14 --> Total execution time: 0.0299
DEBUG - 2011-09-11 03:22:15 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:15 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Router Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Output Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Input Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:22:15 --> Language Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Loader Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Controller Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:22:15 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:17 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Router Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Output Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Input Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:22:17 --> Language Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Loader Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Controller Class Initialized
ERROR - 2011-09-11 03:22:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:22:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:22:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:22:17 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:22:17 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:22:17 --> Final output sent to browser
DEBUG - 2011-09-11 03:22:17 --> Total execution time: 1.9179
DEBUG - 2011-09-11 03:22:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:22:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:22:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:22:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:22:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:22:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:22:17 --> Final output sent to browser
DEBUG - 2011-09-11 03:22:17 --> Total execution time: 0.3956
DEBUG - 2011-09-11 03:22:21 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:21 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Router Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Output Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Input Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:22:21 --> Language Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Loader Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Controller Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:22:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:22:22 --> Final output sent to browser
DEBUG - 2011-09-11 03:22:22 --> Total execution time: 1.4970
DEBUG - 2011-09-11 03:22:24 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:24 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:24 --> Router Class Initialized
ERROR - 2011-09-11 03:22:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:22:27 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:27 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Router Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Output Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Input Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:22:27 --> Language Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Loader Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Controller Class Initialized
ERROR - 2011-09-11 03:22:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:22:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:22:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:22:27 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:22:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:22:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:22:27 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:22:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:22:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:22:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:22:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:22:27 --> Final output sent to browser
DEBUG - 2011-09-11 03:22:27 --> Total execution time: 0.0350
DEBUG - 2011-09-11 03:22:29 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:29 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Router Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Output Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Input Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:22:29 --> Language Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Loader Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Controller Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:22:29 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:22:31 --> Final output sent to browser
DEBUG - 2011-09-11 03:22:31 --> Total execution time: 1.5266
DEBUG - 2011-09-11 03:22:43 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:43 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Router Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Output Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Input Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:22:43 --> Language Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Loader Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Controller Class Initialized
ERROR - 2011-09-11 03:22:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:22:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:22:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:22:43 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:22:43 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:22:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:22:43 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:22:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:22:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:22:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:22:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:22:43 --> Final output sent to browser
DEBUG - 2011-09-11 03:22:43 --> Total execution time: 0.0759
DEBUG - 2011-09-11 03:22:45 --> Config Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:22:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:22:45 --> URI Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Router Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Output Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Input Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:22:45 --> Language Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Loader Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Controller Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Model Class Initialized
DEBUG - 2011-09-11 03:22:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:22:46 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:22:47 --> Final output sent to browser
DEBUG - 2011-09-11 03:22:47 --> Total execution time: 1.9978
DEBUG - 2011-09-11 03:23:10 --> Config Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:23:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:23:10 --> URI Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Router Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Output Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Input Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:23:10 --> Language Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Loader Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Controller Class Initialized
ERROR - 2011-09-11 03:23:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:23:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:23:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:23:10 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:23:10 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:23:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:23:10 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:23:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:23:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:23:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:23:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:23:10 --> Final output sent to browser
DEBUG - 2011-09-11 03:23:10 --> Total execution time: 0.0282
DEBUG - 2011-09-11 03:23:14 --> Config Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:23:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:23:14 --> URI Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Router Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Output Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Input Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:23:14 --> Language Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Loader Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Controller Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:23:14 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:23:15 --> Final output sent to browser
DEBUG - 2011-09-11 03:23:15 --> Total execution time: 1.7314
DEBUG - 2011-09-11 03:23:17 --> Config Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:23:17 --> URI Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Router Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Output Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Input Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:23:17 --> Language Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Loader Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Controller Class Initialized
ERROR - 2011-09-11 03:23:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:23:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:23:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:23:17 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:23:17 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:23:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:23:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:23:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:23:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:23:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:23:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:23:17 --> Final output sent to browser
DEBUG - 2011-09-11 03:23:17 --> Total execution time: 0.2473
DEBUG - 2011-09-11 03:23:20 --> Config Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:23:20 --> URI Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Router Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Output Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Input Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:23:20 --> Language Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Loader Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Controller Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:23:20 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:23:22 --> Final output sent to browser
DEBUG - 2011-09-11 03:23:22 --> Total execution time: 1.5570
DEBUG - 2011-09-11 03:23:34 --> Config Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:23:34 --> URI Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Router Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Output Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Input Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:23:34 --> Language Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Loader Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Controller Class Initialized
ERROR - 2011-09-11 03:23:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:23:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:23:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:23:34 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:23:34 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:23:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:23:34 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:23:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:23:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:23:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:23:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:23:34 --> Final output sent to browser
DEBUG - 2011-09-11 03:23:34 --> Total execution time: 0.0276
DEBUG - 2011-09-11 03:23:37 --> Config Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:23:37 --> URI Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Router Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Output Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Input Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:23:37 --> Language Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Loader Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Controller Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:23:37 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:23:40 --> Final output sent to browser
DEBUG - 2011-09-11 03:23:40 --> Total execution time: 2.1727
DEBUG - 2011-09-11 03:23:48 --> Config Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:23:48 --> URI Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Router Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Output Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Input Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:23:48 --> Language Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Loader Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Controller Class Initialized
ERROR - 2011-09-11 03:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:23:48 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:23:48 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:23:48 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:23:48 --> Final output sent to browser
DEBUG - 2011-09-11 03:23:48 --> Total execution time: 0.0315
DEBUG - 2011-09-11 03:23:50 --> Config Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:23:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:23:50 --> URI Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Router Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Output Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Input Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:23:50 --> Language Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Loader Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Controller Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Model Class Initialized
DEBUG - 2011-09-11 03:23:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:23:50 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:23:52 --> Final output sent to browser
DEBUG - 2011-09-11 03:23:52 --> Total execution time: 2.1166
DEBUG - 2011-09-11 03:24:06 --> Config Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:24:06 --> URI Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Router Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Output Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Input Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:24:06 --> Language Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Loader Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Controller Class Initialized
ERROR - 2011-09-11 03:24:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:24:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:24:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:24:06 --> Model Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Model Class Initialized
DEBUG - 2011-09-11 03:24:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:24:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:24:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:24:06 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:24:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:24:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:24:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:24:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:24:06 --> Final output sent to browser
DEBUG - 2011-09-11 03:24:06 --> Total execution time: 0.0942
DEBUG - 2011-09-11 03:24:10 --> Config Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:24:10 --> URI Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Router Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Output Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Input Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:24:10 --> Language Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Loader Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Controller Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Model Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Model Class Initialized
DEBUG - 2011-09-11 03:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:24:10 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:24:11 --> Final output sent to browser
DEBUG - 2011-09-11 03:24:11 --> Total execution time: 1.5462
DEBUG - 2011-09-11 03:24:49 --> Config Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:24:49 --> URI Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Router Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Output Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Input Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:24:49 --> Language Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Loader Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Controller Class Initialized
ERROR - 2011-09-11 03:24:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:24:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:24:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:24:49 --> Model Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Model Class Initialized
DEBUG - 2011-09-11 03:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:24:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:24:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:24:49 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:24:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:24:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:24:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:24:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:24:49 --> Final output sent to browser
DEBUG - 2011-09-11 03:24:49 --> Total execution time: 0.0301
DEBUG - 2011-09-11 03:24:52 --> Config Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:24:52 --> URI Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Router Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Output Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Input Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:24:52 --> Language Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Loader Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Controller Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Model Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Model Class Initialized
DEBUG - 2011-09-11 03:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:24:52 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:24:54 --> Final output sent to browser
DEBUG - 2011-09-11 03:24:54 --> Total execution time: 1.9095
DEBUG - 2011-09-11 03:25:05 --> Config Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:25:05 --> URI Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Router Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Output Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Input Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:25:05 --> Language Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Loader Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Controller Class Initialized
ERROR - 2011-09-11 03:25:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:25:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:25:05 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:25:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:25:05 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:25:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:25:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:25:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:25:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:25:05 --> Final output sent to browser
DEBUG - 2011-09-11 03:25:05 --> Total execution time: 0.0275
DEBUG - 2011-09-11 03:25:07 --> Config Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:25:07 --> URI Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Router Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Output Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Input Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:25:07 --> Language Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Loader Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Controller Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:25:07 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:25:09 --> Final output sent to browser
DEBUG - 2011-09-11 03:25:09 --> Total execution time: 1.5593
DEBUG - 2011-09-11 03:25:24 --> Config Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:25:24 --> URI Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Router Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Output Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Input Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:25:24 --> Language Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Loader Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Controller Class Initialized
ERROR - 2011-09-11 03:25:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:25:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:25:24 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:25:24 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:25:24 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:25:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:25:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:25:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:25:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:25:24 --> Final output sent to browser
DEBUG - 2011-09-11 03:25:24 --> Total execution time: 0.0631
DEBUG - 2011-09-11 03:25:27 --> Config Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:25:27 --> URI Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Router Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Output Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Input Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:25:27 --> Language Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Loader Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Controller Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:25:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:25:29 --> Final output sent to browser
DEBUG - 2011-09-11 03:25:29 --> Total execution time: 1.7683
DEBUG - 2011-09-11 03:25:38 --> Config Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:25:38 --> URI Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Router Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Output Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Input Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:25:38 --> Language Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Loader Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Controller Class Initialized
ERROR - 2011-09-11 03:25:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:25:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:25:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:25:38 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:25:38 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:25:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:25:38 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:25:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:25:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:25:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:25:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:25:38 --> Final output sent to browser
DEBUG - 2011-09-11 03:25:38 --> Total execution time: 0.0285
DEBUG - 2011-09-11 03:25:42 --> Config Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:25:42 --> URI Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Router Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Output Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Input Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:25:42 --> Language Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Loader Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Controller Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:25:42 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:25:43 --> Final output sent to browser
DEBUG - 2011-09-11 03:25:43 --> Total execution time: 1.4439
DEBUG - 2011-09-11 03:25:54 --> Config Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:25:54 --> URI Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Router Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Output Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Input Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:25:54 --> Language Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Loader Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Controller Class Initialized
ERROR - 2011-09-11 03:25:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:25:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:25:54 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:25:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:25:54 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:25:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:25:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:25:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:25:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:25:54 --> Final output sent to browser
DEBUG - 2011-09-11 03:25:54 --> Total execution time: 0.0308
DEBUG - 2011-09-11 03:25:56 --> Config Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:25:56 --> URI Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Router Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Output Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Input Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:25:56 --> Language Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Loader Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Controller Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Model Class Initialized
DEBUG - 2011-09-11 03:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:25:56 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:25:58 --> Final output sent to browser
DEBUG - 2011-09-11 03:25:58 --> Total execution time: 1.4511
DEBUG - 2011-09-11 03:26:15 --> Config Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:26:15 --> URI Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Router Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Output Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Input Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:26:15 --> Language Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Loader Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Controller Class Initialized
ERROR - 2011-09-11 03:26:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:26:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:26:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:26:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:26:15 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:26:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:26:15 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:26:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:26:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:26:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:26:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:26:15 --> Final output sent to browser
DEBUG - 2011-09-11 03:26:15 --> Total execution time: 0.0295
DEBUG - 2011-09-11 03:26:20 --> Config Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:26:20 --> URI Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Router Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Output Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Input Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:26:20 --> Language Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Loader Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Controller Class Initialized
ERROR - 2011-09-11 03:26:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:26:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:26:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:26:20 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:26:20 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:26:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:26:20 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:26:20 --> Final output sent to browser
DEBUG - 2011-09-11 03:26:20 --> Total execution time: 0.0298
DEBUG - 2011-09-11 03:26:21 --> Config Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:26:21 --> URI Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Router Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Output Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Input Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:26:21 --> Language Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Loader Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Controller Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:26:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:26:24 --> Final output sent to browser
DEBUG - 2011-09-11 03:26:24 --> Total execution time: 3.0004
DEBUG - 2011-09-11 03:26:47 --> Config Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:26:47 --> URI Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Router Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Output Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Input Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:26:47 --> Language Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Loader Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Controller Class Initialized
ERROR - 2011-09-11 03:26:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:26:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:26:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:26:47 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:26:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:26:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:26:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:26:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:26:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:26:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:26:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:26:47 --> Final output sent to browser
DEBUG - 2011-09-11 03:26:47 --> Total execution time: 0.0303
DEBUG - 2011-09-11 03:26:50 --> Config Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:26:50 --> URI Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Router Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Output Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Input Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:26:50 --> Language Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Loader Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Controller Class Initialized
ERROR - 2011-09-11 03:26:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:26:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:26:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:26:50 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:26:50 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:26:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:26:50 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:26:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:26:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:26:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:26:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:26:50 --> Final output sent to browser
DEBUG - 2011-09-11 03:26:50 --> Total execution time: 0.0302
DEBUG - 2011-09-11 03:26:51 --> Config Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:26:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:26:51 --> URI Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Router Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Output Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Input Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:26:51 --> Language Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Loader Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Controller Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Model Class Initialized
DEBUG - 2011-09-11 03:26:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:26:51 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:26:53 --> Final output sent to browser
DEBUG - 2011-09-11 03:26:53 --> Total execution time: 1.8658
DEBUG - 2011-09-11 03:27:05 --> Config Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:27:05 --> URI Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Router Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Output Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Input Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:27:05 --> Language Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Loader Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Controller Class Initialized
ERROR - 2011-09-11 03:27:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:27:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:27:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:27:05 --> Model Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Model Class Initialized
DEBUG - 2011-09-11 03:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:27:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:27:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:27:05 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:27:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:27:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:27:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:27:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:27:05 --> Final output sent to browser
DEBUG - 2011-09-11 03:27:05 --> Total execution time: 0.0495
DEBUG - 2011-09-11 03:27:07 --> Config Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:27:07 --> URI Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Router Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Output Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Input Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:27:07 --> Language Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Loader Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Controller Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Model Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Model Class Initialized
DEBUG - 2011-09-11 03:27:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:27:07 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:27:09 --> Final output sent to browser
DEBUG - 2011-09-11 03:27:09 --> Total execution time: 1.9210
DEBUG - 2011-09-11 03:32:31 --> Config Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:32:31 --> URI Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Router Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Output Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Input Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:32:31 --> Language Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Loader Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Controller Class Initialized
ERROR - 2011-09-11 03:32:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:32:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:32:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:32:31 --> Model Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Model Class Initialized
DEBUG - 2011-09-11 03:32:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:32:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:32:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:32:31 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:32:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:32:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:32:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:32:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:32:31 --> Final output sent to browser
DEBUG - 2011-09-11 03:32:31 --> Total execution time: 0.0788
DEBUG - 2011-09-11 03:32:33 --> Config Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:32:33 --> URI Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Router Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Output Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Input Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:32:33 --> Language Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Loader Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Controller Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Model Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Model Class Initialized
DEBUG - 2011-09-11 03:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:32:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:32:34 --> Final output sent to browser
DEBUG - 2011-09-11 03:32:34 --> Total execution time: 1.4752
DEBUG - 2011-09-11 03:32:35 --> Config Class Initialized
DEBUG - 2011-09-11 03:32:35 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:32:35 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:32:35 --> URI Class Initialized
DEBUG - 2011-09-11 03:32:35 --> Router Class Initialized
ERROR - 2011-09-11 03:32:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:33:13 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:13 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Router Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Output Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Input Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:33:13 --> Language Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Loader Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Controller Class Initialized
ERROR - 2011-09-11 03:33:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:33:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:33:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:33:13 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:33:13 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:33:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:33:13 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:33:13 --> Final output sent to browser
DEBUG - 2011-09-11 03:33:13 --> Total execution time: 0.0337
DEBUG - 2011-09-11 03:33:14 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:14 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Router Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Output Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Input Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:33:14 --> Language Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Loader Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Controller Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:33:14 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:33:15 --> Final output sent to browser
DEBUG - 2011-09-11 03:33:15 --> Total execution time: 1.3284
DEBUG - 2011-09-11 03:33:16 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:16 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:16 --> Router Class Initialized
ERROR - 2011-09-11 03:33:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:33:27 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:27 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Router Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Output Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Input Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:33:27 --> Language Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Loader Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Controller Class Initialized
ERROR - 2011-09-11 03:33:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:33:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:33:27 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:33:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:33:27 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:33:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:33:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:33:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:33:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:33:27 --> Final output sent to browser
DEBUG - 2011-09-11 03:33:27 --> Total execution time: 0.0816
DEBUG - 2011-09-11 03:33:28 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:28 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Router Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Output Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Input Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:33:28 --> Language Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Loader Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Controller Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:33:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:33:29 --> Final output sent to browser
DEBUG - 2011-09-11 03:33:29 --> Total execution time: 1.3875
DEBUG - 2011-09-11 03:33:30 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:30 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:30 --> Router Class Initialized
ERROR - 2011-09-11 03:33:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:33:43 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:43 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Router Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Output Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Input Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:33:43 --> Language Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Loader Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Controller Class Initialized
ERROR - 2011-09-11 03:33:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:33:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:33:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:33:43 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:33:43 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:33:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:33:43 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:33:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:33:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:33:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:33:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:33:43 --> Final output sent to browser
DEBUG - 2011-09-11 03:33:43 --> Total execution time: 0.0406
DEBUG - 2011-09-11 03:33:44 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:44 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Router Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Output Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Input Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:33:44 --> Language Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Loader Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Controller Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Model Class Initialized
DEBUG - 2011-09-11 03:33:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:33:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:33:46 --> Final output sent to browser
DEBUG - 2011-09-11 03:33:46 --> Total execution time: 1.3977
DEBUG - 2011-09-11 03:33:47 --> Config Class Initialized
DEBUG - 2011-09-11 03:33:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:33:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:33:47 --> URI Class Initialized
DEBUG - 2011-09-11 03:33:47 --> Router Class Initialized
ERROR - 2011-09-11 03:33:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:34:04 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:04 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:04 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Controller Class Initialized
ERROR - 2011-09-11 03:34:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:34:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:34:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:04 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:04 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:04 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:34:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:34:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:34:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:34:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:34:04 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:04 --> Total execution time: 0.1255
DEBUG - 2011-09-11 03:34:05 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:05 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:05 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Controller Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:06 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:06 --> Total execution time: 1.4024
DEBUG - 2011-09-11 03:34:07 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:07 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:07 --> Router Class Initialized
ERROR - 2011-09-11 03:34:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:34:16 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:16 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:16 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Controller Class Initialized
ERROR - 2011-09-11 03:34:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:34:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:16 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:16 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:34:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:34:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:34:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:34:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:34:16 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:16 --> Total execution time: 0.0828
DEBUG - 2011-09-11 03:34:17 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:17 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:17 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Controller Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:17 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:18 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:18 --> Total execution time: 1.3158
DEBUG - 2011-09-11 03:34:19 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:19 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:19 --> Router Class Initialized
ERROR - 2011-09-11 03:34:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:34:35 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:35 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:35 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Controller Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:35 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:34:35 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:34:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:34:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:34:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:34:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:34:35 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:35 --> Total execution time: 0.0949
DEBUG - 2011-09-11 03:34:37 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:37 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:37 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Controller Class Initialized
ERROR - 2011-09-11 03:34:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:34:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:34:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:37 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:37 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:34:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:34:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:34:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:34:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:34:37 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:37 --> Total execution time: 0.0280
DEBUG - 2011-09-11 03:34:39 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:39 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:39 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Controller Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:39 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:40 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:40 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Controller Class Initialized
ERROR - 2011-09-11 03:34:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:34:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:34:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:40 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:40 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:40 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:34:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:34:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:34:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:34:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:34:40 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:40 --> Total execution time: 0.0300
DEBUG - 2011-09-11 03:34:41 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:41 --> Total execution time: 1.5145
DEBUG - 2011-09-11 03:34:41 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:41 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Router Class Initialized
ERROR - 2011-09-11 03:34:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:34:41 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:41 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:41 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Controller Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:41 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:42 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:42 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:42 --> Router Class Initialized
ERROR - 2011-09-11 03:34:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:34:42 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:42 --> Total execution time: 1.3089
DEBUG - 2011-09-11 03:34:43 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:43 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:43 --> Router Class Initialized
ERROR - 2011-09-11 03:34:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:34:49 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:49 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:49 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Controller Class Initialized
ERROR - 2011-09-11 03:34:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:34:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:34:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:49 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:34:49 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:34:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:34:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:34:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:34:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:34:49 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:49 --> Total execution time: 0.0662
DEBUG - 2011-09-11 03:34:50 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:50 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Router Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Output Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Input Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:34:50 --> Language Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Loader Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Controller Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Model Class Initialized
DEBUG - 2011-09-11 03:34:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:34:50 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:34:52 --> Final output sent to browser
DEBUG - 2011-09-11 03:34:52 --> Total execution time: 1.5328
DEBUG - 2011-09-11 03:34:52 --> Config Class Initialized
DEBUG - 2011-09-11 03:34:52 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:34:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:34:53 --> URI Class Initialized
DEBUG - 2011-09-11 03:34:53 --> Router Class Initialized
ERROR - 2011-09-11 03:34:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:35:06 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:06 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:06 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Controller Class Initialized
ERROR - 2011-09-11 03:35:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:35:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:35:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:35:06 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:35:06 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:35:06 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:06 --> Total execution time: 0.0435
DEBUG - 2011-09-11 03:35:07 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:07 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:07 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Controller Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:07 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:09 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:09 --> Total execution time: 1.7518
DEBUG - 2011-09-11 03:35:10 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:10 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:10 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:10 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:10 --> Router Class Initialized
ERROR - 2011-09-11 03:35:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:35:15 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:15 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:15 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Controller Class Initialized
ERROR - 2011-09-11 03:35:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:35:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:35:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:35:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:15 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:35:15 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:35:15 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:15 --> Total execution time: 0.0355
DEBUG - 2011-09-11 03:35:16 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:16 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:16 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Controller Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:17 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:17 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Controller Class Initialized
ERROR - 2011-09-11 03:35:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:35:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:35:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:35:17 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:17 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:35:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:35:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:35:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:35:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:35:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:35:17 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:17 --> Total execution time: 0.0268
DEBUG - 2011-09-11 03:35:17 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:17 --> Total execution time: 1.3611
DEBUG - 2011-09-11 03:35:18 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:18 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:18 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Controller Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:18 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:18 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:18 --> Router Class Initialized
ERROR - 2011-09-11 03:35:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 03:35:20 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:20 --> Total execution time: 1.7320
DEBUG - 2011-09-11 03:35:34 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:34 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:34 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Controller Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:34 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:35:36 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:35:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:35:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:35:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:35:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:35:36 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:36 --> Total execution time: 2.1198
DEBUG - 2011-09-11 03:35:44 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:44 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:44 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Controller Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:35:45 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:35:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:35:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:35:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:35:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:35:45 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:45 --> Total execution time: 0.6449
DEBUG - 2011-09-11 03:35:55 --> Config Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:35:55 --> URI Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Router Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Output Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Input Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:35:55 --> Language Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Loader Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Controller Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Model Class Initialized
DEBUG - 2011-09-11 03:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:35:55 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:35:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:35:56 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:35:56 --> Final output sent to browser
DEBUG - 2011-09-11 03:35:56 --> Total execution time: 0.8103
DEBUG - 2011-09-11 03:36:09 --> Config Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:36:09 --> URI Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Router Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Output Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Input Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:36:09 --> Language Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Loader Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Controller Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:36:09 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:36:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:36:10 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:36:10 --> Final output sent to browser
DEBUG - 2011-09-11 03:36:10 --> Total execution time: 0.7510
DEBUG - 2011-09-11 03:36:24 --> Config Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:36:24 --> URI Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Router Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Output Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Input Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:36:24 --> Language Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Loader Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Controller Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:36:24 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:36:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:36:25 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:36:25 --> Final output sent to browser
DEBUG - 2011-09-11 03:36:25 --> Total execution time: 0.3687
DEBUG - 2011-09-11 03:36:37 --> Config Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:36:37 --> URI Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Router Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Output Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Input Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:36:37 --> Language Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Loader Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Controller Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:36:37 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:36:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:36:38 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:36:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:36:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:36:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:36:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:36:38 --> Final output sent to browser
DEBUG - 2011-09-11 03:36:38 --> Total execution time: 0.7362
DEBUG - 2011-09-11 03:36:54 --> Config Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:36:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:36:54 --> URI Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Router Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Output Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Input Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:36:54 --> Language Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Loader Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Controller Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Model Class Initialized
DEBUG - 2011-09-11 03:36:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:36:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:36:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:36:55 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:36:55 --> Final output sent to browser
DEBUG - 2011-09-11 03:36:55 --> Total execution time: 0.6160
DEBUG - 2011-09-11 03:37:15 --> Config Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:37:15 --> URI Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Router Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Output Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Input Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:37:15 --> Language Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Loader Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Controller Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:37:15 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:37:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:37:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:37:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:37:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:37:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:37:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:37:17 --> Final output sent to browser
DEBUG - 2011-09-11 03:37:17 --> Total execution time: 1.7850
DEBUG - 2011-09-11 03:37:33 --> Config Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:37:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:37:33 --> URI Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Router Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Output Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Input Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:37:33 --> Language Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Loader Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Controller Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:37:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:37:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:37:34 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:37:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:37:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:37:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:37:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:37:34 --> Final output sent to browser
DEBUG - 2011-09-11 03:37:34 --> Total execution time: 1.1712
DEBUG - 2011-09-11 03:37:46 --> Config Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:37:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:37:46 --> URI Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Router Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Output Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Input Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:37:46 --> Language Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Loader Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Controller Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:37:46 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:37:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:37:46 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:37:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:37:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:37:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:37:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:37:46 --> Final output sent to browser
DEBUG - 2011-09-11 03:37:46 --> Total execution time: 0.0939
DEBUG - 2011-09-11 03:37:55 --> Config Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:37:55 --> URI Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Router Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Output Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Input Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:37:55 --> Language Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Loader Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Controller Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Model Class Initialized
DEBUG - 2011-09-11 03:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:37:55 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:37:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:37:59 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:37:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:37:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:37:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:37:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:37:59 --> Final output sent to browser
DEBUG - 2011-09-11 03:37:59 --> Total execution time: 4.0749
DEBUG - 2011-09-11 03:38:12 --> Config Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:38:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:38:12 --> URI Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Router Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Output Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Input Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:38:12 --> Language Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Loader Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Controller Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:38:12 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:38:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:38:13 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:38:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:38:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:38:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:38:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:38:13 --> Final output sent to browser
DEBUG - 2011-09-11 03:38:13 --> Total execution time: 0.6934
DEBUG - 2011-09-11 03:38:24 --> Config Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:38:24 --> URI Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Router Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Output Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Input Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:38:24 --> Language Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Loader Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Controller Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:38:24 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:38:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:38:25 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:38:25 --> Final output sent to browser
DEBUG - 2011-09-11 03:38:25 --> Total execution time: 0.7284
DEBUG - 2011-09-11 03:38:32 --> Config Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:38:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:38:32 --> URI Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Router Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Output Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Input Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:38:32 --> Language Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Loader Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Controller Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:38:32 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:38:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:38:33 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:38:33 --> Final output sent to browser
DEBUG - 2011-09-11 03:38:33 --> Total execution time: 0.2084
DEBUG - 2011-09-11 03:38:35 --> Config Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:38:35 --> URI Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Router Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Output Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Input Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:38:35 --> Language Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Loader Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Controller Class Initialized
ERROR - 2011-09-11 03:38:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 03:38:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 03:38:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:38:35 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:38:35 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:38:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 03:38:35 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:38:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:38:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:38:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:38:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:38:35 --> Final output sent to browser
DEBUG - 2011-09-11 03:38:35 --> Total execution time: 0.0289
DEBUG - 2011-09-11 03:38:37 --> Config Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:38:37 --> URI Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Router Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Output Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Input Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:38:37 --> Language Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Loader Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Controller Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:38:37 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:38:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:38:38 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:38:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:38:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:38:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:38:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:38:38 --> Final output sent to browser
DEBUG - 2011-09-11 03:38:38 --> Total execution time: 1.2014
DEBUG - 2011-09-11 03:38:49 --> Config Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 03:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 03:38:49 --> URI Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Router Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Output Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Input Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 03:38:49 --> Language Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Loader Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Controller Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Model Class Initialized
DEBUG - 2011-09-11 03:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 03:38:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 03:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 03:38:50 --> Helper loaded: url_helper
DEBUG - 2011-09-11 03:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 03:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 03:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 03:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 03:38:50 --> Final output sent to browser
DEBUG - 2011-09-11 03:38:50 --> Total execution time: 0.7939
DEBUG - 2011-09-11 04:28:25 --> Config Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:28:25 --> URI Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Router Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Output Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Input Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:28:25 --> Language Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Loader Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Controller Class Initialized
ERROR - 2011-09-11 04:28:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 04:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 04:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:28:25 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:28:25 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:28:26 --> Config Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:28:26 --> URI Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Router Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Output Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Input Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:28:26 --> Language Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Loader Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Controller Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:28:26 --> Final output sent to browser
DEBUG - 2011-09-11 04:28:26 --> Total execution time: 0.5994
DEBUG - 2011-09-11 04:28:26 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:28:26 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 04:28:26 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:28:26 --> Final output sent to browser
DEBUG - 2011-09-11 04:28:26 --> Total execution time: 0.8507
DEBUG - 2011-09-11 04:28:27 --> Config Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Config Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:28:27 --> URI Class Initialized
DEBUG - 2011-09-11 04:28:27 --> URI Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Router Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Router Class Initialized
ERROR - 2011-09-11 04:28:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 04:28:27 --> Output Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Input Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:28:27 --> Language Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Loader Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Controller Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:28:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:28:29 --> Final output sent to browser
DEBUG - 2011-09-11 04:28:29 --> Total execution time: 1.6917
DEBUG - 2011-09-11 04:28:43 --> Config Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:28:43 --> URI Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Router Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Output Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Input Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:28:43 --> Language Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Loader Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Controller Class Initialized
ERROR - 2011-09-11 04:28:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 04:28:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 04:28:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:28:43 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:28:43 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:28:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:28:43 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:28:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:28:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:28:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:28:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:28:43 --> Final output sent to browser
DEBUG - 2011-09-11 04:28:43 --> Total execution time: 0.0266
DEBUG - 2011-09-11 04:28:44 --> Config Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:28:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:28:44 --> URI Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Router Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Output Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Input Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:28:44 --> Language Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Loader Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Controller Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Model Class Initialized
DEBUG - 2011-09-11 04:28:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:28:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:28:46 --> Final output sent to browser
DEBUG - 2011-09-11 04:28:46 --> Total execution time: 1.7266
DEBUG - 2011-09-11 04:29:07 --> Config Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:29:07 --> URI Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Router Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Output Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Input Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:29:07 --> Language Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Loader Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Controller Class Initialized
ERROR - 2011-09-11 04:29:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 04:29:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 04:29:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:29:07 --> Model Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Model Class Initialized
DEBUG - 2011-09-11 04:29:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:29:07 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:29:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:29:07 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:29:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:29:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:29:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:29:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:29:07 --> Final output sent to browser
DEBUG - 2011-09-11 04:29:07 --> Total execution time: 0.0450
DEBUG - 2011-09-11 04:29:08 --> Config Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:29:08 --> URI Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Router Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Output Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Input Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:29:08 --> Language Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Loader Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Controller Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Model Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Model Class Initialized
DEBUG - 2011-09-11 04:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:29:08 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:29:10 --> Final output sent to browser
DEBUG - 2011-09-11 04:29:10 --> Total execution time: 1.6042
DEBUG - 2011-09-11 04:32:51 --> Config Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:32:51 --> URI Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Router Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Output Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Input Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:32:51 --> Language Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Loader Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Controller Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Model Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Model Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Model Class Initialized
DEBUG - 2011-09-11 04:32:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:32:51 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:32:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 04:32:51 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:32:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:32:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:32:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:32:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:32:51 --> Final output sent to browser
DEBUG - 2011-09-11 04:32:51 --> Total execution time: 0.0457
DEBUG - 2011-09-11 04:32:52 --> Config Class Initialized
DEBUG - 2011-09-11 04:32:52 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:32:52 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:32:52 --> URI Class Initialized
DEBUG - 2011-09-11 04:32:52 --> Router Class Initialized
ERROR - 2011-09-11 04:32:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 04:32:53 --> Config Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:32:53 --> URI Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Router Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Output Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Input Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:32:53 --> Language Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Loader Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Controller Class Initialized
ERROR - 2011-09-11 04:32:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 04:32:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 04:32:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:32:53 --> Model Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Model Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:32:53 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:32:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:32:53 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:32:53 --> Final output sent to browser
DEBUG - 2011-09-11 04:32:53 --> Total execution time: 0.0277
DEBUG - 2011-09-11 04:32:53 --> Config Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:32:53 --> URI Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Router Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Output Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Input Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:32:53 --> Language Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Loader Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Controller Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Model Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Model Class Initialized
DEBUG - 2011-09-11 04:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:32:53 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:32:54 --> Final output sent to browser
DEBUG - 2011-09-11 04:32:54 --> Total execution time: 1.3750
DEBUG - 2011-09-11 04:43:19 --> Config Class Initialized
DEBUG - 2011-09-11 04:43:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:43:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:43:19 --> URI Class Initialized
DEBUG - 2011-09-11 04:43:19 --> Router Class Initialized
DEBUG - 2011-09-11 04:43:19 --> No URI present. Default controller set.
DEBUG - 2011-09-11 04:43:19 --> Output Class Initialized
DEBUG - 2011-09-11 04:43:19 --> Input Class Initialized
DEBUG - 2011-09-11 04:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:43:19 --> Language Class Initialized
DEBUG - 2011-09-11 04:43:19 --> Loader Class Initialized
DEBUG - 2011-09-11 04:43:19 --> Controller Class Initialized
DEBUG - 2011-09-11 04:43:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-11 04:43:19 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:43:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:43:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:43:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:43:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:43:19 --> Final output sent to browser
DEBUG - 2011-09-11 04:43:19 --> Total execution time: 0.0377
DEBUG - 2011-09-11 04:49:02 --> Config Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:49:02 --> URI Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Router Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Output Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Input Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:49:02 --> Language Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Loader Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Controller Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Model Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Model Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Model Class Initialized
DEBUG - 2011-09-11 04:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:49:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:49:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 04:49:03 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:49:03 --> Final output sent to browser
DEBUG - 2011-09-11 04:49:03 --> Total execution time: 0.2203
DEBUG - 2011-09-11 04:50:07 --> Config Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 04:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 04:50:07 --> URI Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Router Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Output Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Input Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 04:50:07 --> Language Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Loader Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Controller Class Initialized
ERROR - 2011-09-11 04:50:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 04:50:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 04:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:50:07 --> Model Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Model Class Initialized
DEBUG - 2011-09-11 04:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 04:50:07 --> Database Driver Class Initialized
DEBUG - 2011-09-11 04:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 04:50:07 --> Helper loaded: url_helper
DEBUG - 2011-09-11 04:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 04:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 04:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 04:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 04:50:07 --> Final output sent to browser
DEBUG - 2011-09-11 04:50:07 --> Total execution time: 0.0598
DEBUG - 2011-09-11 05:23:55 --> Config Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:23:55 --> URI Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Router Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Output Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Input Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 05:23:55 --> Language Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Loader Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Controller Class Initialized
ERROR - 2011-09-11 05:23:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 05:23:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 05:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 05:23:55 --> Model Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Model Class Initialized
DEBUG - 2011-09-11 05:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 05:23:55 --> Database Driver Class Initialized
DEBUG - 2011-09-11 05:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 05:23:55 --> Helper loaded: url_helper
DEBUG - 2011-09-11 05:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 05:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 05:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 05:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 05:23:55 --> Final output sent to browser
DEBUG - 2011-09-11 05:23:55 --> Total execution time: 0.2839
DEBUG - 2011-09-11 05:23:56 --> Config Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:23:56 --> URI Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Router Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Output Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Input Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 05:23:56 --> Language Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Loader Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Controller Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Model Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Model Class Initialized
DEBUG - 2011-09-11 05:23:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 05:23:56 --> Database Driver Class Initialized
DEBUG - 2011-09-11 05:23:58 --> Final output sent to browser
DEBUG - 2011-09-11 05:23:58 --> Total execution time: 1.6973
DEBUG - 2011-09-11 05:23:59 --> Config Class Initialized
DEBUG - 2011-09-11 05:23:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:23:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:23:59 --> URI Class Initialized
DEBUG - 2011-09-11 05:23:59 --> Router Class Initialized
ERROR - 2011-09-11 05:23:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 05:25:05 --> Config Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:25:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:25:05 --> URI Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Router Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Output Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Input Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 05:25:05 --> Language Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Loader Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Controller Class Initialized
ERROR - 2011-09-11 05:25:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 05:25:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 05:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 05:25:05 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 05:25:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 05:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 05:25:05 --> Helper loaded: url_helper
DEBUG - 2011-09-11 05:25:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 05:25:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 05:25:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 05:25:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 05:25:05 --> Final output sent to browser
DEBUG - 2011-09-11 05:25:05 --> Total execution time: 0.0322
DEBUG - 2011-09-11 05:25:06 --> Config Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:25:06 --> URI Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Router Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Output Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Input Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 05:25:06 --> Language Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Loader Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Controller Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 05:25:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 05:25:08 --> Final output sent to browser
DEBUG - 2011-09-11 05:25:08 --> Total execution time: 1.7571
DEBUG - 2011-09-11 05:25:09 --> Config Class Initialized
DEBUG - 2011-09-11 05:25:09 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:25:09 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:25:09 --> URI Class Initialized
DEBUG - 2011-09-11 05:25:09 --> Router Class Initialized
ERROR - 2011-09-11 05:25:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 05:25:22 --> Config Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:25:22 --> URI Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Router Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Output Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Input Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 05:25:22 --> Language Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Loader Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Controller Class Initialized
ERROR - 2011-09-11 05:25:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 05:25:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 05:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 05:25:22 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 05:25:22 --> Database Driver Class Initialized
DEBUG - 2011-09-11 05:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 05:25:22 --> Helper loaded: url_helper
DEBUG - 2011-09-11 05:25:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 05:25:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 05:25:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 05:25:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 05:25:22 --> Final output sent to browser
DEBUG - 2011-09-11 05:25:22 --> Total execution time: 0.0293
DEBUG - 2011-09-11 05:25:23 --> Config Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:25:23 --> URI Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Router Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Output Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Input Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 05:25:23 --> Language Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Loader Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Controller Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 05:25:23 --> Database Driver Class Initialized
DEBUG - 2011-09-11 05:25:24 --> Final output sent to browser
DEBUG - 2011-09-11 05:25:24 --> Total execution time: 1.5821
DEBUG - 2011-09-11 05:25:25 --> Config Class Initialized
DEBUG - 2011-09-11 05:25:25 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:25:25 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:25:25 --> URI Class Initialized
DEBUG - 2011-09-11 05:25:25 --> Router Class Initialized
ERROR - 2011-09-11 05:25:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 05:25:40 --> Config Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:25:40 --> URI Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Router Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Output Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Input Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 05:25:40 --> Language Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Loader Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Controller Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Model Class Initialized
DEBUG - 2011-09-11 05:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 05:25:40 --> Database Driver Class Initialized
DEBUG - 2011-09-11 05:25:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 05:25:41 --> Helper loaded: url_helper
DEBUG - 2011-09-11 05:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 05:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 05:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 05:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 05:25:41 --> Final output sent to browser
DEBUG - 2011-09-11 05:25:41 --> Total execution time: 0.3040
DEBUG - 2011-09-11 05:25:42 --> Config Class Initialized
DEBUG - 2011-09-11 05:25:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 05:25:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 05:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 05:25:42 --> URI Class Initialized
DEBUG - 2011-09-11 05:25:42 --> Router Class Initialized
ERROR - 2011-09-11 05:25:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 06:03:29 --> Config Class Initialized
DEBUG - 2011-09-11 06:03:29 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:03:29 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:03:29 --> URI Class Initialized
DEBUG - 2011-09-11 06:03:29 --> Router Class Initialized
DEBUG - 2011-09-11 06:03:30 --> Output Class Initialized
DEBUG - 2011-09-11 06:03:30 --> Input Class Initialized
DEBUG - 2011-09-11 06:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:03:30 --> Language Class Initialized
DEBUG - 2011-09-11 06:03:30 --> Loader Class Initialized
DEBUG - 2011-09-11 06:03:30 --> Controller Class Initialized
ERROR - 2011-09-11 06:03:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:03:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:03:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:03:30 --> Model Class Initialized
DEBUG - 2011-09-11 06:03:30 --> Model Class Initialized
DEBUG - 2011-09-11 06:03:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:03:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:03:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:03:30 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:03:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:03:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:03:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:03:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:03:30 --> Final output sent to browser
DEBUG - 2011-09-11 06:03:30 --> Total execution time: 0.2463
DEBUG - 2011-09-11 06:03:32 --> Config Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:03:32 --> URI Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Router Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Output Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Input Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:03:32 --> Language Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Loader Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Controller Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Model Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Model Class Initialized
DEBUG - 2011-09-11 06:03:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:03:32 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:03:34 --> Final output sent to browser
DEBUG - 2011-09-11 06:03:34 --> Total execution time: 1.5873
DEBUG - 2011-09-11 06:03:55 --> Config Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:03:55 --> URI Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Router Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Output Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Input Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:03:55 --> Language Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Loader Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Controller Class Initialized
ERROR - 2011-09-11 06:03:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:03:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:03:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:03:55 --> Model Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Model Class Initialized
DEBUG - 2011-09-11 06:03:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:03:55 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:03:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:03:55 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:03:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:03:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:03:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:03:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:03:55 --> Final output sent to browser
DEBUG - 2011-09-11 06:03:55 --> Total execution time: 0.0285
DEBUG - 2011-09-11 06:03:58 --> Config Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:03:58 --> URI Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Router Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Output Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Input Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:03:58 --> Language Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Loader Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Controller Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Model Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Model Class Initialized
DEBUG - 2011-09-11 06:03:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:03:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:04:00 --> Final output sent to browser
DEBUG - 2011-09-11 06:04:00 --> Total execution time: 1.5149
DEBUG - 2011-09-11 06:04:13 --> Config Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:04:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:04:13 --> URI Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Router Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Output Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Input Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:04:13 --> Language Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Loader Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Controller Class Initialized
ERROR - 2011-09-11 06:04:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:04:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:04:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:04:13 --> Model Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Model Class Initialized
DEBUG - 2011-09-11 06:04:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:04:13 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:04:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:04:13 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:04:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:04:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:04:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:04:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:04:13 --> Final output sent to browser
DEBUG - 2011-09-11 06:04:13 --> Total execution time: 0.0273
DEBUG - 2011-09-11 06:04:16 --> Config Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:04:16 --> URI Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Router Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Output Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Input Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:04:16 --> Language Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Loader Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Controller Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Model Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Model Class Initialized
DEBUG - 2011-09-11 06:04:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:04:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:04:17 --> Final output sent to browser
DEBUG - 2011-09-11 06:04:17 --> Total execution time: 1.4715
DEBUG - 2011-09-11 06:19:22 --> Config Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:19:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:19:22 --> URI Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Router Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Output Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Input Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:19:22 --> Language Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Loader Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Controller Class Initialized
ERROR - 2011-09-11 06:19:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:19:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:19:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:19:22 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:19:22 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:19:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:19:22 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:19:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:19:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:19:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:19:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:19:22 --> Final output sent to browser
DEBUG - 2011-09-11 06:19:22 --> Total execution time: 0.2822
DEBUG - 2011-09-11 06:19:23 --> Config Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:19:23 --> URI Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Router Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Output Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Input Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:19:23 --> Language Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Loader Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Controller Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:19:23 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:19:25 --> Final output sent to browser
DEBUG - 2011-09-11 06:19:25 --> Total execution time: 1.5518
DEBUG - 2011-09-11 06:19:27 --> Config Class Initialized
DEBUG - 2011-09-11 06:19:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:19:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:19:27 --> URI Class Initialized
DEBUG - 2011-09-11 06:19:27 --> Router Class Initialized
ERROR - 2011-09-11 06:19:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 06:19:55 --> Config Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:19:55 --> URI Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Router Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Output Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Input Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:19:55 --> Language Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Loader Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Controller Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:19:55 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:19:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 06:19:56 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:19:56 --> Final output sent to browser
DEBUG - 2011-09-11 06:19:56 --> Total execution time: 0.5135
DEBUG - 2011-09-11 06:19:57 --> Config Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:19:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:19:57 --> URI Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Router Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Output Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Input Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:19:57 --> Language Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Loader Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Controller Class Initialized
ERROR - 2011-09-11 06:19:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:19:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:19:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:19:57 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Model Class Initialized
DEBUG - 2011-09-11 06:19:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:19:57 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:19:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:19:57 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:19:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:19:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:19:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:19:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:19:57 --> Final output sent to browser
DEBUG - 2011-09-11 06:19:57 --> Total execution time: 0.0321
DEBUG - 2011-09-11 06:24:59 --> Config Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:24:59 --> URI Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Router Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Output Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Input Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:24:59 --> Language Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Loader Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Controller Class Initialized
ERROR - 2011-09-11 06:24:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:24:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:24:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:24:59 --> Model Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Model Class Initialized
DEBUG - 2011-09-11 06:24:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:24:59 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:24:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:24:59 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:24:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:24:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:24:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:24:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:24:59 --> Final output sent to browser
DEBUG - 2011-09-11 06:24:59 --> Total execution time: 0.7155
DEBUG - 2011-09-11 06:25:07 --> Config Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:25:07 --> URI Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Router Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Output Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Input Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:25:07 --> Language Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Loader Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Controller Class Initialized
DEBUG - 2011-09-11 06:25:07 --> Model Class Initialized
DEBUG - 2011-09-11 06:25:08 --> Model Class Initialized
DEBUG - 2011-09-11 06:25:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:25:08 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:25:09 --> Final output sent to browser
DEBUG - 2011-09-11 06:25:09 --> Total execution time: 1.8821
DEBUG - 2011-09-11 06:25:16 --> Config Class Initialized
DEBUG - 2011-09-11 06:25:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:25:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:25:16 --> URI Class Initialized
DEBUG - 2011-09-11 06:25:16 --> Router Class Initialized
ERROR - 2011-09-11 06:25:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 06:25:30 --> Config Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:25:30 --> URI Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Router Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Output Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Input Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:25:30 --> Language Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Loader Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Controller Class Initialized
ERROR - 2011-09-11 06:25:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:25:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:25:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:25:30 --> Model Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Model Class Initialized
DEBUG - 2011-09-11 06:25:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:25:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:25:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:25:30 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:25:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:25:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:25:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:25:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:25:30 --> Final output sent to browser
DEBUG - 2011-09-11 06:25:30 --> Total execution time: 0.0271
DEBUG - 2011-09-11 06:25:32 --> Config Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:25:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:25:32 --> URI Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Router Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Output Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Input Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:25:32 --> Language Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Loader Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Controller Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Model Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Model Class Initialized
DEBUG - 2011-09-11 06:25:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:25:32 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:25:33 --> Final output sent to browser
DEBUG - 2011-09-11 06:25:33 --> Total execution time: 1.4909
DEBUG - 2011-09-11 06:25:44 --> Config Class Initialized
DEBUG - 2011-09-11 06:25:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:25:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:25:44 --> URI Class Initialized
DEBUG - 2011-09-11 06:25:44 --> Router Class Initialized
ERROR - 2011-09-11 06:25:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 06:31:04 --> Config Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:31:04 --> URI Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Router Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Output Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Input Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:31:04 --> Language Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Loader Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Controller Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Model Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Model Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Model Class Initialized
DEBUG - 2011-09-11 06:31:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:31:04 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:31:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 06:31:04 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:31:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:31:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:31:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:31:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:31:04 --> Final output sent to browser
DEBUG - 2011-09-11 06:31:04 --> Total execution time: 0.0908
DEBUG - 2011-09-11 06:31:06 --> Config Class Initialized
DEBUG - 2011-09-11 06:31:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:31:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:31:06 --> URI Class Initialized
DEBUG - 2011-09-11 06:31:06 --> Router Class Initialized
ERROR - 2011-09-11 06:31:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 06:31:06 --> Config Class Initialized
DEBUG - 2011-09-11 06:31:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:31:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:31:06 --> URI Class Initialized
DEBUG - 2011-09-11 06:31:06 --> Router Class Initialized
ERROR - 2011-09-11 06:31:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 06:47:27 --> Config Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:47:27 --> URI Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Router Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Output Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Input Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:47:27 --> Language Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Loader Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Controller Class Initialized
ERROR - 2011-09-11 06:47:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:47:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:47:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:47:27 --> Model Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Model Class Initialized
DEBUG - 2011-09-11 06:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:47:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:47:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:47:27 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:47:27 --> Final output sent to browser
DEBUG - 2011-09-11 06:47:27 --> Total execution time: 0.2570
DEBUG - 2011-09-11 06:47:28 --> Config Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:47:28 --> URI Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Router Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Output Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Input Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:47:28 --> Language Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Loader Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Controller Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Model Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Model Class Initialized
DEBUG - 2011-09-11 06:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:47:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:47:30 --> Final output sent to browser
DEBUG - 2011-09-11 06:47:30 --> Total execution time: 1.8498
DEBUG - 2011-09-11 06:47:36 --> Config Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:47:36 --> URI Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Router Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Output Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Input Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:47:36 --> Language Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Loader Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Controller Class Initialized
ERROR - 2011-09-11 06:47:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 06:47:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 06:47:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:47:36 --> Model Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Model Class Initialized
DEBUG - 2011-09-11 06:47:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:47:36 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:47:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 06:47:36 --> Helper loaded: url_helper
DEBUG - 2011-09-11 06:47:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 06:47:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 06:47:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 06:47:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 06:47:36 --> Final output sent to browser
DEBUG - 2011-09-11 06:47:36 --> Total execution time: 0.0427
DEBUG - 2011-09-11 06:47:38 --> Config Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:47:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:47:38 --> URI Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Router Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Output Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Input Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 06:47:38 --> Language Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Loader Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Controller Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Model Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Model Class Initialized
DEBUG - 2011-09-11 06:47:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 06:47:38 --> Database Driver Class Initialized
DEBUG - 2011-09-11 06:47:40 --> Final output sent to browser
DEBUG - 2011-09-11 06:47:40 --> Total execution time: 1.6335
DEBUG - 2011-09-11 06:47:44 --> Config Class Initialized
DEBUG - 2011-09-11 06:47:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:47:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:47:44 --> URI Class Initialized
DEBUG - 2011-09-11 06:47:44 --> Router Class Initialized
ERROR - 2011-09-11 06:47:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 06:47:47 --> Config Class Initialized
DEBUG - 2011-09-11 06:47:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:47:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:47:47 --> URI Class Initialized
DEBUG - 2011-09-11 06:47:47 --> Router Class Initialized
ERROR - 2011-09-11 06:47:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 06:47:47 --> Config Class Initialized
DEBUG - 2011-09-11 06:47:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 06:47:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 06:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 06:47:47 --> URI Class Initialized
DEBUG - 2011-09-11 06:47:47 --> Router Class Initialized
ERROR - 2011-09-11 06:47:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 07:12:12 --> Config Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:12:12 --> URI Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Router Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Output Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Input Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:12:12 --> Language Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Loader Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Controller Class Initialized
ERROR - 2011-09-11 07:12:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 07:12:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 07:12:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 07:12:12 --> Model Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Model Class Initialized
DEBUG - 2011-09-11 07:12:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:12:12 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:12:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 07:12:12 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:12:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:12:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:12:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:12:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:12:12 --> Final output sent to browser
DEBUG - 2011-09-11 07:12:12 --> Total execution time: 0.2336
DEBUG - 2011-09-11 07:34:19 --> Config Class Initialized
DEBUG - 2011-09-11 07:34:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:34:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:34:19 --> URI Class Initialized
DEBUG - 2011-09-11 07:34:19 --> Router Class Initialized
ERROR - 2011-09-11 07:34:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-11 07:34:20 --> Config Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:34:20 --> URI Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Router Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Output Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Input Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:34:20 --> Language Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Loader Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Controller Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Model Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Model Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Model Class Initialized
DEBUG - 2011-09-11 07:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:34:20 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:34:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 07:34:20 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:34:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:34:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:34:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:34:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:34:20 --> Final output sent to browser
DEBUG - 2011-09-11 07:34:20 --> Total execution time: 0.5249
DEBUG - 2011-09-11 07:57:27 --> Config Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:57:27 --> URI Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Router Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Output Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Input Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:57:27 --> Language Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Loader Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Controller Class Initialized
ERROR - 2011-09-11 07:57:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 07:57:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 07:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 07:57:27 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:57:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 07:57:27 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:57:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:57:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:57:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:57:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:57:27 --> Final output sent to browser
DEBUG - 2011-09-11 07:57:27 --> Total execution time: 0.1145
DEBUG - 2011-09-11 07:57:28 --> Config Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:57:28 --> URI Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Router Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Output Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Input Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:57:28 --> Language Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Loader Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Controller Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:57:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:57:29 --> Final output sent to browser
DEBUG - 2011-09-11 07:57:29 --> Total execution time: 1.5818
DEBUG - 2011-09-11 07:57:30 --> Config Class Initialized
DEBUG - 2011-09-11 07:57:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:57:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:57:30 --> URI Class Initialized
DEBUG - 2011-09-11 07:57:30 --> Router Class Initialized
ERROR - 2011-09-11 07:57:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 07:57:47 --> Config Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:57:47 --> URI Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Router Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Output Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Input Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:57:47 --> Language Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Loader Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Controller Class Initialized
ERROR - 2011-09-11 07:57:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 07:57:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 07:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 07:57:47 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:57:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 07:57:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:57:47 --> Final output sent to browser
DEBUG - 2011-09-11 07:57:47 --> Total execution time: 0.0306
DEBUG - 2011-09-11 07:57:48 --> Config Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:57:48 --> URI Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Router Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Output Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Input Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:57:48 --> Language Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Loader Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Controller Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:57:48 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:57:49 --> Final output sent to browser
DEBUG - 2011-09-11 07:57:49 --> Total execution time: 1.4765
DEBUG - 2011-09-11 07:57:50 --> Config Class Initialized
DEBUG - 2011-09-11 07:57:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:57:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:57:50 --> URI Class Initialized
DEBUG - 2011-09-11 07:57:50 --> Router Class Initialized
ERROR - 2011-09-11 07:57:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 07:57:55 --> Config Class Initialized
DEBUG - 2011-09-11 07:57:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:57:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:57:55 --> URI Class Initialized
DEBUG - 2011-09-11 07:57:55 --> Router Class Initialized
ERROR - 2011-09-11 07:57:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 07:57:58 --> Config Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:57:58 --> URI Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Router Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Output Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Input Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:57:58 --> Language Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Loader Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Controller Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Model Class Initialized
DEBUG - 2011-09-11 07:57:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:57:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:57:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 07:57:58 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:57:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:57:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:57:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:57:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:57:58 --> Final output sent to browser
DEBUG - 2011-09-11 07:57:58 --> Total execution time: 0.0777
DEBUG - 2011-09-11 07:58:00 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:00 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:00 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:00 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:00 --> Router Class Initialized
ERROR - 2011-09-11 07:58:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 07:58:16 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:16 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Router Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Output Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Input Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:58:16 --> Language Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Loader Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Controller Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:58:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:58:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 07:58:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:58:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:58:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:58:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:58:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:58:17 --> Final output sent to browser
DEBUG - 2011-09-11 07:58:17 --> Total execution time: 0.3963
DEBUG - 2011-09-11 07:58:18 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:18 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:18 --> Router Class Initialized
ERROR - 2011-09-11 07:58:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 07:58:19 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:19 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Router Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Output Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Input Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:58:19 --> Language Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Loader Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Controller Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:58:19 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:58:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 07:58:19 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:58:19 --> Final output sent to browser
DEBUG - 2011-09-11 07:58:19 --> Total execution time: 0.0517
DEBUG - 2011-09-11 07:58:25 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:25 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Router Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Output Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Input Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:58:25 --> Language Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Loader Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Controller Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:58:25 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:58:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 07:58:25 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:58:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:58:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:58:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:58:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:58:25 --> Final output sent to browser
DEBUG - 2011-09-11 07:58:25 --> Total execution time: 0.2971
DEBUG - 2011-09-11 07:58:26 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:26 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Router Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Output Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Input Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 07:58:26 --> Language Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Loader Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Controller Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Model Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 07:58:26 --> Database Driver Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:26 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:26 --> Router Class Initialized
ERROR - 2011-09-11 07:58:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 07:58:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 07:58:26 --> Helper loaded: url_helper
DEBUG - 2011-09-11 07:58:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 07:58:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 07:58:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 07:58:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 07:58:26 --> Final output sent to browser
DEBUG - 2011-09-11 07:58:26 --> Total execution time: 0.0544
DEBUG - 2011-09-11 07:58:41 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:41 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:41 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:41 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:41 --> Router Class Initialized
ERROR - 2011-09-11 07:58:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 07:58:42 --> Config Class Initialized
DEBUG - 2011-09-11 07:58:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 07:58:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 07:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 07:58:42 --> URI Class Initialized
DEBUG - 2011-09-11 07:58:42 --> Router Class Initialized
ERROR - 2011-09-11 07:58:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 08:11:11 --> Config Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:11:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:11:11 --> URI Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Router Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Output Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Input Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:11:11 --> Language Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Loader Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Controller Class Initialized
ERROR - 2011-09-11 08:11:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:11:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:11:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:11:11 --> Model Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Model Class Initialized
DEBUG - 2011-09-11 08:11:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:11:11 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:11:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:11:11 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:11:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:11:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:11:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:11:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:11:11 --> Final output sent to browser
DEBUG - 2011-09-11 08:11:11 --> Total execution time: 0.0290
DEBUG - 2011-09-11 08:29:41 --> Config Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:29:41 --> URI Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Router Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Output Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Input Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:29:41 --> Language Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Loader Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Controller Class Initialized
ERROR - 2011-09-11 08:29:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:29:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:29:41 --> Model Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Model Class Initialized
DEBUG - 2011-09-11 08:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:29:41 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:29:41 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:29:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:29:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:29:41 --> Final output sent to browser
DEBUG - 2011-09-11 08:29:41 --> Total execution time: 0.0279
DEBUG - 2011-09-11 08:29:46 --> Config Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:29:46 --> URI Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Router Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Output Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Input Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:29:46 --> Language Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Loader Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Controller Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Model Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Model Class Initialized
DEBUG - 2011-09-11 08:29:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:29:46 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:29:47 --> Final output sent to browser
DEBUG - 2011-09-11 08:29:47 --> Total execution time: 1.4594
DEBUG - 2011-09-11 08:29:51 --> Config Class Initialized
DEBUG - 2011-09-11 08:29:51 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:29:51 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:29:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:29:51 --> URI Class Initialized
DEBUG - 2011-09-11 08:29:51 --> Router Class Initialized
ERROR - 2011-09-11 08:29:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 08:37:34 --> Config Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:37:34 --> URI Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Router Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Output Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Input Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:37:34 --> Language Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Loader Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Controller Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Model Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Model Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Model Class Initialized
DEBUG - 2011-09-11 08:37:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:37:34 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:37:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 08:37:34 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:37:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:37:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:37:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:37:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:37:34 --> Final output sent to browser
DEBUG - 2011-09-11 08:37:34 --> Total execution time: 0.2205
DEBUG - 2011-09-11 08:38:13 --> Config Class Initialized
DEBUG - 2011-09-11 08:38:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:38:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:38:13 --> URI Class Initialized
DEBUG - 2011-09-11 08:38:13 --> Router Class Initialized
ERROR - 2011-09-11 08:38:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 08:42:51 --> Config Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:42:51 --> URI Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Router Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Output Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Input Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:42:51 --> Language Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Loader Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Controller Class Initialized
ERROR - 2011-09-11 08:42:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:42:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:42:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:42:51 --> Model Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Model Class Initialized
DEBUG - 2011-09-11 08:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:42:51 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:42:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:42:51 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:42:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:42:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:42:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:42:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:42:51 --> Final output sent to browser
DEBUG - 2011-09-11 08:42:51 --> Total execution time: 0.0501
DEBUG - 2011-09-11 08:42:52 --> Config Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:42:52 --> URI Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Router Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Output Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Input Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:42:52 --> Language Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Loader Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Controller Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Model Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Model Class Initialized
DEBUG - 2011-09-11 08:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:42:52 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:42:54 --> Final output sent to browser
DEBUG - 2011-09-11 08:42:54 --> Total execution time: 1.6942
DEBUG - 2011-09-11 08:52:06 --> Config Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:52:06 --> URI Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Router Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Output Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Input Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:52:06 --> Language Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Loader Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Controller Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Model Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Model Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Model Class Initialized
DEBUG - 2011-09-11 08:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:52:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:52:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 08:52:06 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:52:06 --> Final output sent to browser
DEBUG - 2011-09-11 08:52:06 --> Total execution time: 0.0447
DEBUG - 2011-09-11 08:52:45 --> Config Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:52:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:52:45 --> URI Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Router Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Output Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Input Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:52:45 --> Language Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Loader Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Controller Class Initialized
ERROR - 2011-09-11 08:52:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:52:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:52:45 --> Model Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Model Class Initialized
DEBUG - 2011-09-11 08:52:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:52:45 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:52:45 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:52:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:52:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:52:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:52:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:52:45 --> Final output sent to browser
DEBUG - 2011-09-11 08:52:45 --> Total execution time: 0.1621
DEBUG - 2011-09-11 08:52:48 --> Config Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:52:48 --> URI Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Router Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Output Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Input Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:52:48 --> Language Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Loader Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Controller Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Model Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Model Class Initialized
DEBUG - 2011-09-11 08:52:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:52:48 --> Database Driver Class Initialized
ERROR - 2011-09-11 08:52:49 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: SSL: connection timeout /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 60
ERROR - 2011-09-11 08:52:49 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: Failed to enable crypto /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 60
ERROR - 2011-09-11 08:52:49 --> Severity: Warning  --> fopen(https://chart.googleapis.com/chart?chid=89a588a7ad2570b2f140f1b64ed59ecb) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: operation failed /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 60
ERROR - 2011-09-11 08:52:49 --> Severity: Warning  --> fpassthru(): supplied argument is not a valid stream resource /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 61
ERROR - 2011-09-11 08:52:49 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 62
DEBUG - 2011-09-11 08:52:49 --> Final output sent to browser
DEBUG - 2011-09-11 08:52:49 --> Total execution time: 0.2190
DEBUG - 2011-09-11 08:53:03 --> Config Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:53:03 --> URI Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Router Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Output Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Input Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:53:03 --> Language Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Loader Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Controller Class Initialized
ERROR - 2011-09-11 08:53:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:53:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:53:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:53:03 --> Model Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Model Class Initialized
DEBUG - 2011-09-11 08:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:53:03 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:53:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:53:03 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:53:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:53:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:53:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:53:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:53:03 --> Final output sent to browser
DEBUG - 2011-09-11 08:53:03 --> Total execution time: 0.0322
DEBUG - 2011-09-11 08:53:06 --> Config Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:53:06 --> URI Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Router Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Output Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Input Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:53:06 --> Language Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Loader Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Controller Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Model Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Model Class Initialized
DEBUG - 2011-09-11 08:53:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:53:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:53:08 --> Final output sent to browser
DEBUG - 2011-09-11 08:53:08 --> Total execution time: 1.6810
DEBUG - 2011-09-11 08:53:57 --> Config Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:53:57 --> URI Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Router Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Output Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Input Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:53:57 --> Language Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Loader Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Controller Class Initialized
ERROR - 2011-09-11 08:53:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:53:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:53:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:53:57 --> Model Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Model Class Initialized
DEBUG - 2011-09-11 08:53:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:53:57 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:53:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:53:57 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:53:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:53:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:53:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:53:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:53:57 --> Final output sent to browser
DEBUG - 2011-09-11 08:53:57 --> Total execution time: 0.0277
DEBUG - 2011-09-11 08:54:00 --> Config Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:54:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:54:00 --> URI Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Router Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Output Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Input Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:54:00 --> Language Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Loader Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Controller Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Model Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Model Class Initialized
DEBUG - 2011-09-11 08:54:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:54:00 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:54:02 --> Final output sent to browser
DEBUG - 2011-09-11 08:54:02 --> Total execution time: 1.4175
DEBUG - 2011-09-11 08:54:46 --> Config Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:54:46 --> URI Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Router Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Output Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Input Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:54:46 --> Language Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Loader Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Controller Class Initialized
ERROR - 2011-09-11 08:54:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:54:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:54:46 --> Model Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Model Class Initialized
DEBUG - 2011-09-11 08:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:54:46 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:54:46 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:54:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:54:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:54:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:54:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:54:46 --> Final output sent to browser
DEBUG - 2011-09-11 08:54:46 --> Total execution time: 0.0278
DEBUG - 2011-09-11 08:54:50 --> Config Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:54:50 --> URI Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Router Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Output Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Input Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:54:50 --> Language Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Loader Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Controller Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Model Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Model Class Initialized
DEBUG - 2011-09-11 08:54:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:54:50 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:54:51 --> Final output sent to browser
DEBUG - 2011-09-11 08:54:51 --> Total execution time: 1.3586
DEBUG - 2011-09-11 08:55:16 --> Config Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:55:16 --> URI Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Router Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Output Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Input Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:55:16 --> Language Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Loader Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Controller Class Initialized
ERROR - 2011-09-11 08:55:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:55:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:55:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:55:16 --> Model Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Model Class Initialized
DEBUG - 2011-09-11 08:55:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:55:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:55:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:55:16 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:55:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:55:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:55:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:55:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:55:16 --> Final output sent to browser
DEBUG - 2011-09-11 08:55:16 --> Total execution time: 0.0615
DEBUG - 2011-09-11 08:55:19 --> Config Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:55:19 --> URI Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Router Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Output Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Input Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:55:19 --> Language Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Loader Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Controller Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Model Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Model Class Initialized
DEBUG - 2011-09-11 08:55:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:55:19 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:55:20 --> Final output sent to browser
DEBUG - 2011-09-11 08:55:20 --> Total execution time: 1.5898
DEBUG - 2011-09-11 08:57:47 --> Config Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:57:47 --> URI Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Router Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Output Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Input Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:57:47 --> Language Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Loader Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Controller Class Initialized
ERROR - 2011-09-11 08:57:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 08:57:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 08:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:57:47 --> Model Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Model Class Initialized
DEBUG - 2011-09-11 08:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:57:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 08:57:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 08:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 08:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 08:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 08:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 08:57:47 --> Final output sent to browser
DEBUG - 2011-09-11 08:57:47 --> Total execution time: 0.0429
DEBUG - 2011-09-11 08:57:51 --> Config Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:57:51 --> URI Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Router Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Output Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Input Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 08:57:51 --> Language Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Loader Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Controller Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Model Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Model Class Initialized
DEBUG - 2011-09-11 08:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 08:57:51 --> Database Driver Class Initialized
DEBUG - 2011-09-11 08:57:52 --> Final output sent to browser
DEBUG - 2011-09-11 08:57:52 --> Total execution time: 1.4683
DEBUG - 2011-09-11 08:57:55 --> Config Class Initialized
DEBUG - 2011-09-11 08:57:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 08:57:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 08:57:55 --> URI Class Initialized
DEBUG - 2011-09-11 08:57:55 --> Router Class Initialized
ERROR - 2011-09-11 08:57:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 09:08:03 --> Config Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:08:03 --> URI Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Router Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Output Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Input Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:08:03 --> Language Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Loader Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Controller Class Initialized
ERROR - 2011-09-11 09:08:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 09:08:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 09:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:08:03 --> Model Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Model Class Initialized
DEBUG - 2011-09-11 09:08:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:08:03 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:08:03 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:08:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:08:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:08:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:08:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:08:03 --> Final output sent to browser
DEBUG - 2011-09-11 09:08:03 --> Total execution time: 0.0292
DEBUG - 2011-09-11 09:08:05 --> Config Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:08:05 --> URI Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Router Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Output Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Input Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:08:05 --> Language Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Loader Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Controller Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Model Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Model Class Initialized
DEBUG - 2011-09-11 09:08:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:08:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:08:06 --> Final output sent to browser
DEBUG - 2011-09-11 09:08:06 --> Total execution time: 1.4784
DEBUG - 2011-09-11 09:08:18 --> Config Class Initialized
DEBUG - 2011-09-11 09:08:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:08:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:08:18 --> URI Class Initialized
DEBUG - 2011-09-11 09:08:18 --> Router Class Initialized
ERROR - 2011-09-11 09:08:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 09:08:19 --> Config Class Initialized
DEBUG - 2011-09-11 09:08:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:08:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:08:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:08:19 --> URI Class Initialized
DEBUG - 2011-09-11 09:08:19 --> Router Class Initialized
ERROR - 2011-09-11 09:08:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 09:08:22 --> Config Class Initialized
DEBUG - 2011-09-11 09:08:22 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:08:22 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:08:22 --> URI Class Initialized
DEBUG - 2011-09-11 09:08:22 --> Router Class Initialized
ERROR - 2011-09-11 09:08:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 09:15:25 --> Config Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:15:25 --> URI Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Router Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Output Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Input Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:15:25 --> Language Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Loader Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Controller Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Model Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Model Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Model Class Initialized
DEBUG - 2011-09-11 09:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:15:25 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:15:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 09:15:25 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:15:25 --> Final output sent to browser
DEBUG - 2011-09-11 09:15:25 --> Total execution time: 0.0902
DEBUG - 2011-09-11 09:16:09 --> Config Class Initialized
DEBUG - 2011-09-11 09:16:09 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:16:09 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:16:09 --> URI Class Initialized
DEBUG - 2011-09-11 09:16:09 --> Router Class Initialized
DEBUG - 2011-09-11 09:16:09 --> No URI present. Default controller set.
DEBUG - 2011-09-11 09:16:09 --> Output Class Initialized
DEBUG - 2011-09-11 09:16:09 --> Input Class Initialized
DEBUG - 2011-09-11 09:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:16:09 --> Language Class Initialized
DEBUG - 2011-09-11 09:16:09 --> Loader Class Initialized
DEBUG - 2011-09-11 09:16:09 --> Controller Class Initialized
DEBUG - 2011-09-11 09:16:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-11 09:16:09 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:16:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:16:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:16:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:16:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:16:09 --> Final output sent to browser
DEBUG - 2011-09-11 09:16:09 --> Total execution time: 0.0647
DEBUG - 2011-09-11 09:16:16 --> Config Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:16:16 --> URI Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Router Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Output Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Input Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:16:16 --> Language Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Loader Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Controller Class Initialized
ERROR - 2011-09-11 09:16:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 09:16:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 09:16:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:16:16 --> Model Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Model Class Initialized
DEBUG - 2011-09-11 09:16:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:16:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:16:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:16:16 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:16:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:16:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:16:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:16:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:16:16 --> Final output sent to browser
DEBUG - 2011-09-11 09:16:16 --> Total execution time: 0.0446
DEBUG - 2011-09-11 09:16:24 --> Config Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:16:24 --> URI Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Router Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Output Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Input Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:16:24 --> Language Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Loader Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Controller Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Model Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Model Class Initialized
DEBUG - 2011-09-11 09:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:16:24 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:16:26 --> Final output sent to browser
DEBUG - 2011-09-11 09:16:26 --> Total execution time: 1.5921
DEBUG - 2011-09-11 09:16:28 --> Config Class Initialized
DEBUG - 2011-09-11 09:16:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:16:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:16:28 --> URI Class Initialized
DEBUG - 2011-09-11 09:16:28 --> Router Class Initialized
ERROR - 2011-09-11 09:16:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 09:26:31 --> Config Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:26:31 --> URI Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Router Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Output Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Input Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:26:31 --> Language Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Loader Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Controller Class Initialized
ERROR - 2011-09-11 09:26:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 09:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 09:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:26:31 --> Model Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Model Class Initialized
DEBUG - 2011-09-11 09:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:26:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:26:31 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:26:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:26:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:26:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:26:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:26:31 --> Final output sent to browser
DEBUG - 2011-09-11 09:26:31 --> Total execution time: 0.0332
DEBUG - 2011-09-11 09:26:32 --> Config Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:26:32 --> URI Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Router Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Output Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Input Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:26:32 --> Language Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Loader Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Controller Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Model Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Model Class Initialized
DEBUG - 2011-09-11 09:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:26:32 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:26:34 --> Final output sent to browser
DEBUG - 2011-09-11 09:26:34 --> Total execution time: 1.4838
DEBUG - 2011-09-11 09:26:34 --> Config Class Initialized
DEBUG - 2011-09-11 09:26:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:26:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:26:34 --> URI Class Initialized
DEBUG - 2011-09-11 09:26:34 --> Router Class Initialized
ERROR - 2011-09-11 09:26:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 09:26:58 --> Config Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:26:58 --> URI Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Router Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Output Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Input Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:26:58 --> Language Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Loader Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Controller Class Initialized
ERROR - 2011-09-11 09:26:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 09:26:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 09:26:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:26:58 --> Model Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Model Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:26:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:26:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:26:58 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:26:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:26:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:26:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:26:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:26:58 --> Final output sent to browser
DEBUG - 2011-09-11 09:26:58 --> Total execution time: 0.0495
DEBUG - 2011-09-11 09:26:58 --> Config Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:26:58 --> URI Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Router Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Output Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Input Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:26:58 --> Language Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Loader Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Controller Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Model Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Model Class Initialized
DEBUG - 2011-09-11 09:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:26:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:27:00 --> Final output sent to browser
DEBUG - 2011-09-11 09:27:00 --> Total execution time: 1.3795
DEBUG - 2011-09-11 09:27:11 --> Config Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:27:11 --> URI Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Router Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Output Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Input Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:27:11 --> Language Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Loader Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Controller Class Initialized
ERROR - 2011-09-11 09:27:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 09:27:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 09:27:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:27:11 --> Model Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Model Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:27:11 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:27:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:27:11 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:27:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:27:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:27:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:27:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:27:11 --> Final output sent to browser
DEBUG - 2011-09-11 09:27:11 --> Total execution time: 0.0314
DEBUG - 2011-09-11 09:27:11 --> Config Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:27:11 --> URI Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Router Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Output Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Input Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:27:11 --> Language Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Loader Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Controller Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Model Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Model Class Initialized
DEBUG - 2011-09-11 09:27:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:27:11 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:27:13 --> Final output sent to browser
DEBUG - 2011-09-11 09:27:13 --> Total execution time: 1.3030
DEBUG - 2011-09-11 09:27:28 --> Config Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:27:28 --> URI Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Router Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Output Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Input Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:27:28 --> Language Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Loader Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Controller Class Initialized
ERROR - 2011-09-11 09:27:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 09:27:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 09:27:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:27:28 --> Model Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Model Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:27:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:27:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 09:27:28 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:27:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:27:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:27:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:27:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:27:28 --> Final output sent to browser
DEBUG - 2011-09-11 09:27:28 --> Total execution time: 0.0266
DEBUG - 2011-09-11 09:27:28 --> Config Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:27:28 --> URI Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Router Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Output Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Input Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:27:28 --> Language Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Loader Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Controller Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Model Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Model Class Initialized
DEBUG - 2011-09-11 09:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:27:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:27:30 --> Final output sent to browser
DEBUG - 2011-09-11 09:27:30 --> Total execution time: 1.3183
DEBUG - 2011-09-11 09:48:27 --> Config Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:48:27 --> URI Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Router Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Output Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Input Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:48:27 --> Language Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Loader Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Controller Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Model Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Model Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Model Class Initialized
DEBUG - 2011-09-11 09:48:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:48:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:48:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 09:48:27 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:48:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:48:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:48:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:48:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:48:27 --> Final output sent to browser
DEBUG - 2011-09-11 09:48:27 --> Total execution time: 0.4030
DEBUG - 2011-09-11 09:50:06 --> Config Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:50:06 --> URI Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Router Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Output Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Input Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 09:50:06 --> Language Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Loader Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Controller Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Model Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Model Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Model Class Initialized
DEBUG - 2011-09-11 09:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 09:50:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 09:50:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 09:50:06 --> Helper loaded: url_helper
DEBUG - 2011-09-11 09:50:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 09:50:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 09:50:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 09:50:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 09:50:06 --> Final output sent to browser
DEBUG - 2011-09-11 09:50:06 --> Total execution time: 0.0462
DEBUG - 2011-09-11 09:50:09 --> Config Class Initialized
DEBUG - 2011-09-11 09:50:09 --> Hooks Class Initialized
DEBUG - 2011-09-11 09:50:09 --> Utf8 Class Initialized
DEBUG - 2011-09-11 09:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 09:50:09 --> URI Class Initialized
DEBUG - 2011-09-11 09:50:09 --> Router Class Initialized
ERROR - 2011-09-11 09:50:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:02:26 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:26 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Router Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Output Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Input Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:02:26 --> Language Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Loader Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Controller Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:02:26 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:02:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:02:26 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:02:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:02:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:02:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:02:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:02:26 --> Final output sent to browser
DEBUG - 2011-09-11 10:02:26 --> Total execution time: 0.0448
DEBUG - 2011-09-11 10:02:28 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:28 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:28 --> Router Class Initialized
ERROR - 2011-09-11 10:02:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:02:40 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:40 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Router Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Output Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Input Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:02:40 --> Language Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Loader Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Controller Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:02:40 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:02:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:02:41 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:02:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:02:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:02:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:02:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:02:41 --> Final output sent to browser
DEBUG - 2011-09-11 10:02:41 --> Total execution time: 0.3198
DEBUG - 2011-09-11 10:02:42 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:42 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Router Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Output Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Input Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:02:42 --> Language Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Loader Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Controller Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:02:42 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:02:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:02:42 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:02:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:02:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:02:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:02:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:02:42 --> Final output sent to browser
DEBUG - 2011-09-11 10:02:42 --> Total execution time: 0.0431
DEBUG - 2011-09-11 10:02:42 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:42 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Router Class Initialized
ERROR - 2011-09-11 10:02:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:02:42 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:42 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:42 --> Router Class Initialized
ERROR - 2011-09-11 10:02:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:02:52 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:52 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Router Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Output Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Input Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:02:52 --> Language Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Loader Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Controller Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:02:52 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:02:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:02:52 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:02:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:02:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:02:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:02:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:02:52 --> Final output sent to browser
DEBUG - 2011-09-11 10:02:52 --> Total execution time: 0.5787
DEBUG - 2011-09-11 10:02:54 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:54 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Router Class Initialized
ERROR - 2011-09-11 10:02:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:02:54 --> Config Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:02:54 --> URI Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Router Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Output Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Input Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:02:54 --> Language Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Loader Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Controller Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Model Class Initialized
DEBUG - 2011-09-11 10:02:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:02:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:02:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:02:54 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:02:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:02:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:02:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:02:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:02:54 --> Final output sent to browser
DEBUG - 2011-09-11 10:02:54 --> Total execution time: 0.0492
DEBUG - 2011-09-11 10:03:02 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:02 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Router Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Output Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Input Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:03:02 --> Language Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Loader Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Controller Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:03:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:03:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:03:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:03:02 --> Final output sent to browser
DEBUG - 2011-09-11 10:03:02 --> Total execution time: 0.3481
DEBUG - 2011-09-11 10:03:04 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:04 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Router Class Initialized
ERROR - 2011-09-11 10:03:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:03:04 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:04 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Router Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Output Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Input Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:03:04 --> Language Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Loader Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Controller Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:03:04 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:03:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:03:04 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:03:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:03:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:03:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:03:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:03:04 --> Final output sent to browser
DEBUG - 2011-09-11 10:03:04 --> Total execution time: 0.1671
DEBUG - 2011-09-11 10:03:21 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:21 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Router Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Output Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Input Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:03:21 --> Language Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Loader Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Controller Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:03:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:03:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:03:21 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:03:21 --> Final output sent to browser
DEBUG - 2011-09-11 10:03:21 --> Total execution time: 0.2934
DEBUG - 2011-09-11 10:03:22 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:22 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Router Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Output Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Input Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:03:22 --> Language Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Loader Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Controller Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:03:22 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:03:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:03:22 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:03:22 --> Final output sent to browser
DEBUG - 2011-09-11 10:03:22 --> Total execution time: 0.0490
DEBUG - 2011-09-11 10:03:23 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:23 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:23 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:23 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:23 --> Router Class Initialized
ERROR - 2011-09-11 10:03:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:03:29 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:29 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Router Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Output Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Input Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:03:29 --> Language Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Loader Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Controller Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:03:29 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:03:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:03:29 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:03:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:03:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:03:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:03:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:03:29 --> Final output sent to browser
DEBUG - 2011-09-11 10:03:29 --> Total execution time: 0.2078
DEBUG - 2011-09-11 10:03:30 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:30 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:30 --> Router Class Initialized
ERROR - 2011-09-11 10:03:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:03:42 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:42 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Router Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Output Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Input Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:03:42 --> Language Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Loader Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Controller Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:03:42 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:03:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:03:42 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:03:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:03:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:03:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:03:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:03:42 --> Final output sent to browser
DEBUG - 2011-09-11 10:03:42 --> Total execution time: 0.4418
DEBUG - 2011-09-11 10:03:43 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:43 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:43 --> Router Class Initialized
ERROR - 2011-09-11 10:03:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:03:56 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:56 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Router Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Output Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Input Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:03:56 --> Language Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Loader Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Controller Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:03:56 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:03:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:03:56 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:03:56 --> Final output sent to browser
DEBUG - 2011-09-11 10:03:56 --> Total execution time: 0.2281
DEBUG - 2011-09-11 10:03:58 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:58 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Router Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Output Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Input Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:03:58 --> Language Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Loader Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Controller Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Model Class Initialized
DEBUG - 2011-09-11 10:03:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:03:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:03:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 10:03:58 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:03:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:03:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:03:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:03:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:03:58 --> Final output sent to browser
DEBUG - 2011-09-11 10:03:58 --> Total execution time: 0.0482
DEBUG - 2011-09-11 10:03:59 --> Config Class Initialized
DEBUG - 2011-09-11 10:03:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:03:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:03:59 --> URI Class Initialized
DEBUG - 2011-09-11 10:03:59 --> Router Class Initialized
ERROR - 2011-09-11 10:03:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:04:41 --> Config Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:04:41 --> URI Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Router Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Output Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Input Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:04:41 --> Language Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Loader Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Controller Class Initialized
ERROR - 2011-09-11 10:04:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:04:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:04:41 --> Model Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Model Class Initialized
DEBUG - 2011-09-11 10:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:04:41 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:04:41 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:04:41 --> Final output sent to browser
DEBUG - 2011-09-11 10:04:41 --> Total execution time: 0.0322
DEBUG - 2011-09-11 10:04:42 --> Config Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:04:42 --> URI Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Router Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Output Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Input Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:04:42 --> Language Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Loader Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Controller Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:04:42 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:04:44 --> Final output sent to browser
DEBUG - 2011-09-11 10:04:44 --> Total execution time: 1.5290
DEBUG - 2011-09-11 10:04:45 --> Config Class Initialized
DEBUG - 2011-09-11 10:04:45 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:04:45 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:04:45 --> URI Class Initialized
DEBUG - 2011-09-11 10:04:45 --> Router Class Initialized
ERROR - 2011-09-11 10:04:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:10:28 --> Config Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:10:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:10:28 --> URI Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Router Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Output Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Input Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:10:28 --> Language Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Loader Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Controller Class Initialized
ERROR - 2011-09-11 10:10:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:10:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:10:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:10:28 --> Model Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Model Class Initialized
DEBUG - 2011-09-11 10:10:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:10:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:10:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:10:28 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:10:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:10:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:10:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:10:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:10:28 --> Final output sent to browser
DEBUG - 2011-09-11 10:10:28 --> Total execution time: 0.0307
DEBUG - 2011-09-11 10:10:36 --> Config Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:10:36 --> URI Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Router Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Output Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Input Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:10:36 --> Language Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Loader Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Controller Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Model Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Model Class Initialized
DEBUG - 2011-09-11 10:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:10:36 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:10:38 --> Final output sent to browser
DEBUG - 2011-09-11 10:10:38 --> Total execution time: 2.2849
DEBUG - 2011-09-11 10:11:30 --> Config Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:11:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:11:30 --> URI Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Router Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Output Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Input Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:11:30 --> Language Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Loader Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Controller Class Initialized
ERROR - 2011-09-11 10:11:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:11:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:11:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:11:30 --> Model Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Model Class Initialized
DEBUG - 2011-09-11 10:11:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:11:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:11:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:11:30 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:11:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:11:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:11:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:11:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:11:30 --> Final output sent to browser
DEBUG - 2011-09-11 10:11:30 --> Total execution time: 0.0289
DEBUG - 2011-09-11 10:11:31 --> Config Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:11:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:11:31 --> URI Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Router Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Output Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Input Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:11:31 --> Language Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Loader Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Controller Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Model Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Model Class Initialized
DEBUG - 2011-09-11 10:11:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:11:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:11:32 --> Final output sent to browser
DEBUG - 2011-09-11 10:11:32 --> Total execution time: 1.5910
DEBUG - 2011-09-11 10:12:11 --> Config Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:12:11 --> URI Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Router Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Output Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Input Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:12:11 --> Language Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Loader Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Controller Class Initialized
ERROR - 2011-09-11 10:12:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:12:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:12:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:12:11 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:12:11 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:12:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:12:11 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:12:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:12:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:12:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:12:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:12:11 --> Final output sent to browser
DEBUG - 2011-09-11 10:12:11 --> Total execution time: 0.0272
DEBUG - 2011-09-11 10:12:12 --> Config Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:12:12 --> URI Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Router Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Output Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Input Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:12:12 --> Language Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Loader Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Controller Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:12:12 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:12:14 --> Final output sent to browser
DEBUG - 2011-09-11 10:12:14 --> Total execution time: 1.6231
DEBUG - 2011-09-11 10:12:30 --> Config Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:12:30 --> URI Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Router Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Output Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Input Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:12:30 --> Language Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Loader Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Controller Class Initialized
ERROR - 2011-09-11 10:12:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:12:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:12:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:12:30 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:12:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:12:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:12:30 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:12:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:12:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:12:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:12:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:12:30 --> Final output sent to browser
DEBUG - 2011-09-11 10:12:30 --> Total execution time: 0.0394
DEBUG - 2011-09-11 10:12:31 --> Config Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:12:31 --> URI Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Router Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Output Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Input Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:12:31 --> Language Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Loader Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Controller Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:12:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:12:32 --> Final output sent to browser
DEBUG - 2011-09-11 10:12:32 --> Total execution time: 1.4274
DEBUG - 2011-09-11 10:12:42 --> Config Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:12:42 --> URI Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Router Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Output Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Input Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:12:42 --> Language Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Loader Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Controller Class Initialized
ERROR - 2011-09-11 10:12:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:12:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:12:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:12:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:12:42 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:12:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:12:42 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:12:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:12:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:12:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:12:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:12:42 --> Final output sent to browser
DEBUG - 2011-09-11 10:12:42 --> Total execution time: 0.0930
DEBUG - 2011-09-11 10:12:43 --> Config Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:12:43 --> URI Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Router Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Output Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Input Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:12:43 --> Language Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Loader Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Controller Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:12:43 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:12:45 --> Final output sent to browser
DEBUG - 2011-09-11 10:12:45 --> Total execution time: 1.5287
DEBUG - 2011-09-11 10:12:49 --> Config Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:12:49 --> URI Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Router Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Output Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Input Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:12:49 --> Language Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Loader Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Controller Class Initialized
ERROR - 2011-09-11 10:12:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:12:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:12:49 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:12:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:12:49 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:12:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:12:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:12:49 --> Final output sent to browser
DEBUG - 2011-09-11 10:12:49 --> Total execution time: 0.0366
DEBUG - 2011-09-11 10:12:50 --> Config Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:12:50 --> URI Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Router Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Output Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Input Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:12:50 --> Language Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Loader Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Controller Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Model Class Initialized
DEBUG - 2011-09-11 10:12:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:12:50 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:12:52 --> Final output sent to browser
DEBUG - 2011-09-11 10:12:52 --> Total execution time: 1.6227
DEBUG - 2011-09-11 10:31:07 --> Config Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:31:07 --> URI Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Router Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Output Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Input Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:31:07 --> Language Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Loader Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Controller Class Initialized
ERROR - 2011-09-11 10:31:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:31:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:31:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:31:07 --> Model Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Model Class Initialized
DEBUG - 2011-09-11 10:31:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:31:07 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:31:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:31:07 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:31:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:31:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:31:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:31:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:31:07 --> Final output sent to browser
DEBUG - 2011-09-11 10:31:07 --> Total execution time: 0.0287
DEBUG - 2011-09-11 10:31:08 --> Config Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:31:08 --> URI Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Router Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Output Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Input Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:31:08 --> Language Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Loader Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Controller Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Model Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Model Class Initialized
DEBUG - 2011-09-11 10:31:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:31:08 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:31:09 --> Final output sent to browser
DEBUG - 2011-09-11 10:31:09 --> Total execution time: 1.3902
DEBUG - 2011-09-11 10:31:10 --> Config Class Initialized
DEBUG - 2011-09-11 10:31:10 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:31:10 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:31:10 --> URI Class Initialized
DEBUG - 2011-09-11 10:31:10 --> Router Class Initialized
ERROR - 2011-09-11 10:31:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:48:15 --> Config Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:48:15 --> URI Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Router Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Output Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Input Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:48:15 --> Language Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Loader Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Controller Class Initialized
ERROR - 2011-09-11 10:48:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:48:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:48:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:48:15 --> Model Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Model Class Initialized
DEBUG - 2011-09-11 10:48:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:48:15 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:48:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:48:15 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:48:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:48:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:48:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:48:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:48:15 --> Final output sent to browser
DEBUG - 2011-09-11 10:48:15 --> Total execution time: 0.0297
DEBUG - 2011-09-11 10:48:16 --> Config Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:48:16 --> URI Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Router Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Output Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Input Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:48:16 --> Language Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Loader Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Controller Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Model Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Model Class Initialized
DEBUG - 2011-09-11 10:48:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:48:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:48:17 --> Final output sent to browser
DEBUG - 2011-09-11 10:48:17 --> Total execution time: 1.6288
DEBUG - 2011-09-11 10:57:19 --> Config Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:57:19 --> URI Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Router Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Output Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Input Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:57:19 --> Language Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Loader Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Controller Class Initialized
ERROR - 2011-09-11 10:57:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:57:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:57:19 --> Model Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Model Class Initialized
DEBUG - 2011-09-11 10:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:57:19 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:57:19 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:57:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:57:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:57:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:57:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:57:19 --> Final output sent to browser
DEBUG - 2011-09-11 10:57:19 --> Total execution time: 0.0284
DEBUG - 2011-09-11 10:57:23 --> Config Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:57:23 --> URI Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Router Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Output Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Input Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:57:23 --> Language Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Loader Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Controller Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Model Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Model Class Initialized
DEBUG - 2011-09-11 10:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:57:23 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:57:25 --> Final output sent to browser
DEBUG - 2011-09-11 10:57:25 --> Total execution time: 1.4744
DEBUG - 2011-09-11 10:57:30 --> Config Class Initialized
DEBUG - 2011-09-11 10:57:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:57:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:57:30 --> URI Class Initialized
DEBUG - 2011-09-11 10:57:30 --> Router Class Initialized
ERROR - 2011-09-11 10:57:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:57:30 --> Config Class Initialized
DEBUG - 2011-09-11 10:57:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:57:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:57:30 --> URI Class Initialized
DEBUG - 2011-09-11 10:57:30 --> Router Class Initialized
ERROR - 2011-09-11 10:57:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 10:57:33 --> Config Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:57:33 --> URI Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Router Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Output Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Input Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:57:33 --> Language Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Loader Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Controller Class Initialized
ERROR - 2011-09-11 10:57:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 10:57:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 10:57:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:57:33 --> Model Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Model Class Initialized
DEBUG - 2011-09-11 10:57:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:57:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:57:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 10:57:33 --> Helper loaded: url_helper
DEBUG - 2011-09-11 10:57:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 10:57:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 10:57:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 10:57:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 10:57:33 --> Final output sent to browser
DEBUG - 2011-09-11 10:57:33 --> Total execution time: 0.0286
DEBUG - 2011-09-11 10:57:34 --> Config Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 10:57:34 --> URI Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Router Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Output Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Input Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 10:57:34 --> Language Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Loader Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Controller Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Model Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Model Class Initialized
DEBUG - 2011-09-11 10:57:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 10:57:34 --> Database Driver Class Initialized
DEBUG - 2011-09-11 10:57:35 --> Final output sent to browser
DEBUG - 2011-09-11 10:57:35 --> Total execution time: 1.4428
DEBUG - 2011-09-11 11:01:08 --> Config Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:01:08 --> URI Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Router Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Output Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Input Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 11:01:08 --> Language Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Loader Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Controller Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Model Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Model Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Model Class Initialized
DEBUG - 2011-09-11 11:01:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 11:01:08 --> Database Driver Class Initialized
DEBUG - 2011-09-11 11:01:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 11:01:08 --> Helper loaded: url_helper
DEBUG - 2011-09-11 11:01:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 11:01:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 11:01:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 11:01:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 11:01:08 --> Final output sent to browser
DEBUG - 2011-09-11 11:01:08 --> Total execution time: 0.3058
DEBUG - 2011-09-11 11:19:06 --> Config Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:19:06 --> URI Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Router Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Output Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Input Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 11:19:06 --> Language Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Loader Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Controller Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Model Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Model Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Model Class Initialized
DEBUG - 2011-09-11 11:19:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 11:19:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 11:19:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 11:19:06 --> Helper loaded: url_helper
DEBUG - 2011-09-11 11:19:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 11:19:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 11:19:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 11:19:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 11:19:06 --> Final output sent to browser
DEBUG - 2011-09-11 11:19:06 --> Total execution time: 0.0564
DEBUG - 2011-09-11 11:19:11 --> Config Class Initialized
DEBUG - 2011-09-11 11:19:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:19:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:19:11 --> URI Class Initialized
DEBUG - 2011-09-11 11:19:11 --> Router Class Initialized
ERROR - 2011-09-11 11:19:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 11:28:45 --> Config Class Initialized
DEBUG - 2011-09-11 11:28:45 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:28:45 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:28:45 --> URI Class Initialized
DEBUG - 2011-09-11 11:28:45 --> Router Class Initialized
DEBUG - 2011-09-11 11:28:45 --> No URI present. Default controller set.
DEBUG - 2011-09-11 11:28:45 --> Output Class Initialized
DEBUG - 2011-09-11 11:28:45 --> Input Class Initialized
DEBUG - 2011-09-11 11:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 11:28:45 --> Language Class Initialized
DEBUG - 2011-09-11 11:28:45 --> Loader Class Initialized
DEBUG - 2011-09-11 11:28:45 --> Controller Class Initialized
DEBUG - 2011-09-11 11:28:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-11 11:28:45 --> Helper loaded: url_helper
DEBUG - 2011-09-11 11:28:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 11:28:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 11:28:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 11:28:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 11:28:45 --> Final output sent to browser
DEBUG - 2011-09-11 11:28:45 --> Total execution time: 0.0530
DEBUG - 2011-09-11 11:29:17 --> Config Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:29:17 --> URI Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Router Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Output Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Input Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 11:29:17 --> Language Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Loader Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Controller Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Model Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Model Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Model Class Initialized
DEBUG - 2011-09-11 11:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 11:29:17 --> Database Driver Class Initialized
DEBUG - 2011-09-11 11:29:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 11:29:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 11:29:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 11:29:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 11:29:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 11:29:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 11:29:17 --> Final output sent to browser
DEBUG - 2011-09-11 11:29:17 --> Total execution time: 0.4279
DEBUG - 2011-09-11 11:29:19 --> Config Class Initialized
DEBUG - 2011-09-11 11:29:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:29:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:29:19 --> URI Class Initialized
DEBUG - 2011-09-11 11:29:19 --> Router Class Initialized
ERROR - 2011-09-11 11:29:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 11:41:28 --> Config Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:41:28 --> URI Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Router Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Output Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Input Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 11:41:28 --> Language Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Loader Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Controller Class Initialized
ERROR - 2011-09-11 11:41:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 11:41:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 11:41:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 11:41:28 --> Model Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Model Class Initialized
DEBUG - 2011-09-11 11:41:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 11:41:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 11:41:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 11:41:28 --> Helper loaded: url_helper
DEBUG - 2011-09-11 11:41:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 11:41:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 11:41:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 11:41:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 11:41:28 --> Final output sent to browser
DEBUG - 2011-09-11 11:41:28 --> Total execution time: 0.0738
DEBUG - 2011-09-11 11:41:30 --> Config Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:41:30 --> URI Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Router Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Output Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Input Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 11:41:30 --> Language Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Loader Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Controller Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Model Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Model Class Initialized
DEBUG - 2011-09-11 11:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 11:41:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 11:41:32 --> Final output sent to browser
DEBUG - 2011-09-11 11:41:32 --> Total execution time: 1.7915
DEBUG - 2011-09-11 11:41:36 --> Config Class Initialized
DEBUG - 2011-09-11 11:41:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:41:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:41:36 --> URI Class Initialized
DEBUG - 2011-09-11 11:41:36 --> Router Class Initialized
ERROR - 2011-09-11 11:41:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 11:41:36 --> Config Class Initialized
DEBUG - 2011-09-11 11:41:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 11:41:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 11:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 11:41:36 --> URI Class Initialized
DEBUG - 2011-09-11 11:41:36 --> Router Class Initialized
ERROR - 2011-09-11 11:41:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:19:51 --> Config Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:19:51 --> URI Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Router Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Output Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Input Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:19:51 --> Language Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Loader Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Controller Class Initialized
ERROR - 2011-09-11 12:19:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:19:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:19:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:19:51 --> Model Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Model Class Initialized
DEBUG - 2011-09-11 12:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:19:51 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:19:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:19:51 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:19:51 --> Final output sent to browser
DEBUG - 2011-09-11 12:19:51 --> Total execution time: 0.3883
DEBUG - 2011-09-11 12:19:52 --> Config Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:19:52 --> URI Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Router Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Output Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Input Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:19:52 --> Language Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Loader Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Controller Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Model Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Model Class Initialized
DEBUG - 2011-09-11 12:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:19:52 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:19:53 --> Final output sent to browser
DEBUG - 2011-09-11 12:19:53 --> Total execution time: 1.5767
DEBUG - 2011-09-11 12:19:54 --> Config Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:19:54 --> URI Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Router Class Initialized
ERROR - 2011-09-11 12:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:19:54 --> Config Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:19:54 --> URI Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Router Class Initialized
ERROR - 2011-09-11 12:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:19:54 --> Config Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:19:54 --> URI Class Initialized
DEBUG - 2011-09-11 12:19:54 --> Router Class Initialized
ERROR - 2011-09-11 12:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:20:36 --> Config Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:20:36 --> URI Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Router Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Output Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Input Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:20:36 --> Language Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Loader Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Controller Class Initialized
ERROR - 2011-09-11 12:20:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:20:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:20:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:20:36 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:20:36 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:20:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:20:36 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:20:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:20:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:20:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:20:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:20:36 --> Final output sent to browser
DEBUG - 2011-09-11 12:20:36 --> Total execution time: 0.0313
DEBUG - 2011-09-11 12:20:36 --> Config Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:20:36 --> URI Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Router Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Output Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Input Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:20:36 --> Language Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Loader Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Controller Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:20:36 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Config Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:20:37 --> URI Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Router Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Output Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Input Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:20:37 --> Language Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Loader Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Controller Class Initialized
ERROR - 2011-09-11 12:20:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:20:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:20:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:20:37 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:20:37 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:20:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:20:37 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:20:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:20:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:20:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:20:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:20:37 --> Final output sent to browser
DEBUG - 2011-09-11 12:20:37 --> Total execution time: 0.0271
DEBUG - 2011-09-11 12:20:37 --> Final output sent to browser
DEBUG - 2011-09-11 12:20:37 --> Total execution time: 1.2671
DEBUG - 2011-09-11 12:20:47 --> Config Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:20:47 --> URI Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Router Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Output Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Input Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:20:47 --> Language Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Loader Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Controller Class Initialized
ERROR - 2011-09-11 12:20:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:20:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:20:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:20:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:20:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:20:47 --> Final output sent to browser
DEBUG - 2011-09-11 12:20:47 --> Total execution time: 0.0450
DEBUG - 2011-09-11 12:20:47 --> Config Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:20:47 --> URI Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Router Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Output Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Input Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:20:47 --> Language Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Loader Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Controller Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:20:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:20:49 --> Final output sent to browser
DEBUG - 2011-09-11 12:20:49 --> Total execution time: 1.2712
DEBUG - 2011-09-11 12:22:14 --> Config Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:22:14 --> URI Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Router Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Output Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Input Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:22:14 --> Language Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Loader Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Controller Class Initialized
ERROR - 2011-09-11 12:22:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:22:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:22:14 --> Model Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Model Class Initialized
DEBUG - 2011-09-11 12:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:22:14 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:22:14 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:22:14 --> Final output sent to browser
DEBUG - 2011-09-11 12:22:14 --> Total execution time: 0.0268
DEBUG - 2011-09-11 12:22:15 --> Config Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:22:15 --> URI Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Router Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Output Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Input Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:22:15 --> Language Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Loader Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Controller Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Model Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Model Class Initialized
DEBUG - 2011-09-11 12:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:22:15 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:22:16 --> Final output sent to browser
DEBUG - 2011-09-11 12:22:16 --> Total execution time: 1.6262
DEBUG - 2011-09-11 12:22:19 --> Config Class Initialized
DEBUG - 2011-09-11 12:22:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:22:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:22:19 --> URI Class Initialized
DEBUG - 2011-09-11 12:22:19 --> Router Class Initialized
ERROR - 2011-09-11 12:22:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:22:19 --> Config Class Initialized
DEBUG - 2011-09-11 12:22:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:22:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:22:19 --> URI Class Initialized
DEBUG - 2011-09-11 12:22:19 --> Router Class Initialized
ERROR - 2011-09-11 12:22:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:22:39 --> Config Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:22:39 --> URI Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Router Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Output Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Input Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:22:39 --> Language Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Loader Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Controller Class Initialized
ERROR - 2011-09-11 12:22:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:22:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:22:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:22:39 --> Model Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Model Class Initialized
DEBUG - 2011-09-11 12:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:22:39 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:22:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:22:39 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:22:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:22:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:22:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:22:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:22:39 --> Final output sent to browser
DEBUG - 2011-09-11 12:22:39 --> Total execution time: 0.0299
DEBUG - 2011-09-11 12:22:49 --> Config Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:22:49 --> URI Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Router Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Output Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Input Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:22:49 --> Language Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Loader Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Controller Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Model Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Model Class Initialized
DEBUG - 2011-09-11 12:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:22:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:22:51 --> Final output sent to browser
DEBUG - 2011-09-11 12:22:51 --> Total execution time: 1.4711
DEBUG - 2011-09-11 12:22:54 --> Config Class Initialized
DEBUG - 2011-09-11 12:22:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:22:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:22:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:22:54 --> URI Class Initialized
DEBUG - 2011-09-11 12:22:54 --> Router Class Initialized
ERROR - 2011-09-11 12:22:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:23:00 --> Config Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:23:00 --> URI Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Router Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Output Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Input Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:23:00 --> Language Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Loader Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Controller Class Initialized
ERROR - 2011-09-11 12:23:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:23:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:23:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:23:00 --> Model Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Model Class Initialized
DEBUG - 2011-09-11 12:23:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:23:00 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:23:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:23:00 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:23:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:23:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:23:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:23:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:23:00 --> Final output sent to browser
DEBUG - 2011-09-11 12:23:00 --> Total execution time: 0.0466
DEBUG - 2011-09-11 12:23:01 --> Config Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:23:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:23:01 --> URI Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Router Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Output Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Input Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:23:01 --> Language Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Loader Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Controller Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Model Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Model Class Initialized
DEBUG - 2011-09-11 12:23:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:23:01 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:23:02 --> Final output sent to browser
DEBUG - 2011-09-11 12:23:02 --> Total execution time: 1.5082
DEBUG - 2011-09-11 12:23:04 --> Config Class Initialized
DEBUG - 2011-09-11 12:23:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:23:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:23:04 --> URI Class Initialized
DEBUG - 2011-09-11 12:23:04 --> Router Class Initialized
ERROR - 2011-09-11 12:23:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:29:44 --> Config Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:29:44 --> URI Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Router Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Output Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Input Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:29:44 --> Language Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Loader Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Controller Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Model Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Model Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Model Class Initialized
DEBUG - 2011-09-11 12:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:29:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:29:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:29:45 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:29:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:29:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:29:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:29:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:29:45 --> Final output sent to browser
DEBUG - 2011-09-11 12:29:45 --> Total execution time: 0.2816
DEBUG - 2011-09-11 12:29:47 --> Config Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:29:47 --> URI Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Router Class Initialized
ERROR - 2011-09-11 12:29:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:29:47 --> Config Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:29:47 --> URI Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Router Class Initialized
ERROR - 2011-09-11 12:29:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:29:47 --> Config Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:29:47 --> URI Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Router Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Output Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Input Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:29:47 --> Language Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Loader Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Controller Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:29:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:29:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:29:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:29:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:29:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:29:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:29:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:29:47 --> Final output sent to browser
DEBUG - 2011-09-11 12:29:47 --> Total execution time: 0.0524
DEBUG - 2011-09-11 12:31:44 --> Config Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:31:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:31:44 --> URI Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Router Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Output Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Input Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:31:44 --> Language Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Loader Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Controller Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Model Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Model Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Model Class Initialized
DEBUG - 2011-09-11 12:31:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:31:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:31:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:31:44 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:31:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:31:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:31:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:31:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:31:44 --> Final output sent to browser
DEBUG - 2011-09-11 12:31:44 --> Total execution time: 0.0448
DEBUG - 2011-09-11 12:32:19 --> Config Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:32:19 --> URI Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Router Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Output Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Input Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:32:19 --> Language Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Loader Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Controller Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Model Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Model Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Model Class Initialized
DEBUG - 2011-09-11 12:32:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:32:19 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:32:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:32:20 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:32:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:32:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:32:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:32:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:32:20 --> Final output sent to browser
DEBUG - 2011-09-11 12:32:20 --> Total execution time: 0.2063
DEBUG - 2011-09-11 12:32:25 --> Config Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:32:25 --> URI Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Router Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Output Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Input Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:32:25 --> Language Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Loader Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Controller Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Model Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Model Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Model Class Initialized
DEBUG - 2011-09-11 12:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:32:25 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:32:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:32:25 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:32:25 --> Final output sent to browser
DEBUG - 2011-09-11 12:32:25 --> Total execution time: 0.0838
DEBUG - 2011-09-11 12:33:18 --> Config Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:33:18 --> URI Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Router Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Output Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Input Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:33:18 --> Language Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Loader Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Controller Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Model Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Model Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Model Class Initialized
DEBUG - 2011-09-11 12:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:33:18 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:33:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:33:19 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:33:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:33:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:33:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:33:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:33:19 --> Final output sent to browser
DEBUG - 2011-09-11 12:33:19 --> Total execution time: 0.1009
DEBUG - 2011-09-11 12:33:54 --> Config Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:33:54 --> URI Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Router Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Output Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Input Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:33:54 --> Language Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Loader Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Controller Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Model Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Model Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Model Class Initialized
DEBUG - 2011-09-11 12:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:33:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:33:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:33:54 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:33:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:33:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:33:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:33:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:33:54 --> Final output sent to browser
DEBUG - 2011-09-11 12:33:54 --> Total execution time: 0.0405
DEBUG - 2011-09-11 12:34:53 --> Config Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:34:53 --> URI Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Router Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Output Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Input Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:34:53 --> Language Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Loader Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Controller Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Model Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Model Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Model Class Initialized
DEBUG - 2011-09-11 12:34:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:34:53 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:34:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:34:53 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:34:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:34:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:34:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:34:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:34:53 --> Final output sent to browser
DEBUG - 2011-09-11 12:34:53 --> Total execution time: 0.3923
DEBUG - 2011-09-11 12:34:55 --> Config Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:34:55 --> URI Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Router Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Output Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Input Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:34:55 --> Language Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Loader Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Controller Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Model Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Model Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Model Class Initialized
DEBUG - 2011-09-11 12:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:34:55 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:34:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:34:55 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:34:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:34:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:34:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:34:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:34:55 --> Final output sent to browser
DEBUG - 2011-09-11 12:34:55 --> Total execution time: 0.0482
DEBUG - 2011-09-11 12:35:17 --> Config Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:35:17 --> URI Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Router Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Output Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Input Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:35:17 --> Language Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Loader Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Controller Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Model Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Model Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Model Class Initialized
DEBUG - 2011-09-11 12:35:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:35:17 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:35:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:35:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:35:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:35:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:35:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:35:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:35:17 --> Final output sent to browser
DEBUG - 2011-09-11 12:35:17 --> Total execution time: 0.2255
DEBUG - 2011-09-11 12:35:21 --> Config Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:35:21 --> URI Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Router Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Output Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Input Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:35:21 --> Language Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Loader Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Controller Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Model Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Model Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Model Class Initialized
DEBUG - 2011-09-11 12:35:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:35:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:35:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 12:35:21 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:35:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:35:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:35:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:35:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:35:21 --> Final output sent to browser
DEBUG - 2011-09-11 12:35:21 --> Total execution time: 0.0480
DEBUG - 2011-09-11 12:35:28 --> Config Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:35:28 --> URI Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Router Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Output Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Input Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:35:28 --> Language Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Loader Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Controller Class Initialized
ERROR - 2011-09-11 12:35:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:35:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:35:28 --> Model Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Model Class Initialized
DEBUG - 2011-09-11 12:35:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:35:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:35:28 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:35:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:35:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:35:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:35:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:35:28 --> Final output sent to browser
DEBUG - 2011-09-11 12:35:28 --> Total execution time: 0.0309
DEBUG - 2011-09-11 12:42:58 --> Config Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:42:58 --> URI Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Router Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Output Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Input Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:42:58 --> Language Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Loader Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Controller Class Initialized
ERROR - 2011-09-11 12:42:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:42:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:42:58 --> Model Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Model Class Initialized
DEBUG - 2011-09-11 12:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:42:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:42:58 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:42:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:42:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:42:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:42:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:42:58 --> Final output sent to browser
DEBUG - 2011-09-11 12:42:58 --> Total execution time: 0.0357
DEBUG - 2011-09-11 12:43:01 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:01 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Router Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Output Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Input Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:43:01 --> Language Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Loader Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Controller Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:43:01 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:43:02 --> Final output sent to browser
DEBUG - 2011-09-11 12:43:02 --> Total execution time: 1.5892
DEBUG - 2011-09-11 12:43:04 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:04 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:04 --> Router Class Initialized
ERROR - 2011-09-11 12:43:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:43:32 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:32 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Router Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Output Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Input Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:43:32 --> Language Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Loader Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Controller Class Initialized
ERROR - 2011-09-11 12:43:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:43:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:43:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:43:32 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:43:32 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:43:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:43:32 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:43:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:43:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:43:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:43:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:43:32 --> Final output sent to browser
DEBUG - 2011-09-11 12:43:32 --> Total execution time: 0.0285
DEBUG - 2011-09-11 12:43:32 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:32 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Router Class Initialized
DEBUG - 2011-09-11 12:43:32 --> Output Class Initialized
DEBUG - 2011-09-11 12:43:33 --> Input Class Initialized
DEBUG - 2011-09-11 12:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:43:33 --> Language Class Initialized
DEBUG - 2011-09-11 12:43:33 --> Loader Class Initialized
DEBUG - 2011-09-11 12:43:33 --> Controller Class Initialized
DEBUG - 2011-09-11 12:43:33 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:33 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:43:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:43:34 --> Final output sent to browser
DEBUG - 2011-09-11 12:43:34 --> Total execution time: 1.5673
DEBUG - 2011-09-11 12:43:35 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:35 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:35 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:35 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:35 --> Router Class Initialized
ERROR - 2011-09-11 12:43:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:43:45 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:45 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Router Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Output Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Input Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:43:45 --> Language Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Loader Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Controller Class Initialized
ERROR - 2011-09-11 12:43:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:43:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:43:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:43:45 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:43:45 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:43:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:43:45 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:43:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:43:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:43:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:43:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:43:45 --> Final output sent to browser
DEBUG - 2011-09-11 12:43:45 --> Total execution time: 0.0280
DEBUG - 2011-09-11 12:43:46 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:46 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:46 --> Router Class Initialized
DEBUG - 2011-09-11 12:43:46 --> Output Class Initialized
DEBUG - 2011-09-11 12:43:46 --> Input Class Initialized
DEBUG - 2011-09-11 12:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:43:46 --> Language Class Initialized
DEBUG - 2011-09-11 12:43:47 --> Loader Class Initialized
DEBUG - 2011-09-11 12:43:47 --> Controller Class Initialized
DEBUG - 2011-09-11 12:43:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:47 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:43:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:43:48 --> Final output sent to browser
DEBUG - 2011-09-11 12:43:48 --> Total execution time: 1.6734
DEBUG - 2011-09-11 12:43:49 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:49 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:49 --> Router Class Initialized
ERROR - 2011-09-11 12:43:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:43:57 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:57 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Router Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Output Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Input Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:43:57 --> Language Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Loader Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Controller Class Initialized
ERROR - 2011-09-11 12:43:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:43:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:43:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:43:57 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:43:57 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:43:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:43:57 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:43:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:43:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:43:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:43:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:43:57 --> Final output sent to browser
DEBUG - 2011-09-11 12:43:57 --> Total execution time: 0.0314
DEBUG - 2011-09-11 12:43:59 --> Config Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:43:59 --> URI Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Router Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Output Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Input Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:43:59 --> Language Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Loader Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Controller Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Model Class Initialized
DEBUG - 2011-09-11 12:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:43:59 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:44:01 --> Final output sent to browser
DEBUG - 2011-09-11 12:44:01 --> Total execution time: 1.4529
DEBUG - 2011-09-11 12:44:02 --> Config Class Initialized
DEBUG - 2011-09-11 12:44:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:44:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:44:02 --> URI Class Initialized
DEBUG - 2011-09-11 12:44:02 --> Router Class Initialized
ERROR - 2011-09-11 12:44:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:48:02 --> Config Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:48:02 --> URI Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Router Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Output Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Input Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:48:02 --> Language Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Loader Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Controller Class Initialized
ERROR - 2011-09-11 12:48:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:48:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:48:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:48:02 --> Model Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Model Class Initialized
DEBUG - 2011-09-11 12:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:48:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:48:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:48:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:48:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:48:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:48:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:48:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:48:02 --> Final output sent to browser
DEBUG - 2011-09-11 12:48:02 --> Total execution time: 0.0375
DEBUG - 2011-09-11 12:48:04 --> Config Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:48:04 --> URI Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Router Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Output Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Input Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:48:04 --> Language Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Loader Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Controller Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Model Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Model Class Initialized
DEBUG - 2011-09-11 12:48:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:48:04 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:48:05 --> Final output sent to browser
DEBUG - 2011-09-11 12:48:05 --> Total execution time: 1.3160
DEBUG - 2011-09-11 12:48:38 --> Config Class Initialized
DEBUG - 2011-09-11 12:48:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:48:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:48:38 --> URI Class Initialized
DEBUG - 2011-09-11 12:48:38 --> Router Class Initialized
ERROR - 2011-09-11 12:48:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:48:41 --> Config Class Initialized
DEBUG - 2011-09-11 12:48:41 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:48:41 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:48:41 --> URI Class Initialized
DEBUG - 2011-09-11 12:48:41 --> Router Class Initialized
ERROR - 2011-09-11 12:48:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 12:52:29 --> Config Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:52:29 --> URI Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Router Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Output Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Input Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:52:29 --> Language Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Loader Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Controller Class Initialized
ERROR - 2011-09-11 12:52:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 12:52:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 12:52:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:52:29 --> Model Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Model Class Initialized
DEBUG - 2011-09-11 12:52:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:52:29 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:52:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 12:52:29 --> Helper loaded: url_helper
DEBUG - 2011-09-11 12:52:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 12:52:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 12:52:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 12:52:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 12:52:29 --> Final output sent to browser
DEBUG - 2011-09-11 12:52:29 --> Total execution time: 0.0293
DEBUG - 2011-09-11 12:52:33 --> Config Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:52:33 --> URI Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Router Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Output Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Input Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 12:52:33 --> Language Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Loader Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Controller Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Model Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Model Class Initialized
DEBUG - 2011-09-11 12:52:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 12:52:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 12:52:35 --> Final output sent to browser
DEBUG - 2011-09-11 12:52:35 --> Total execution time: 1.3335
DEBUG - 2011-09-11 12:52:38 --> Config Class Initialized
DEBUG - 2011-09-11 12:52:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 12:52:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 12:52:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 12:52:38 --> URI Class Initialized
DEBUG - 2011-09-11 12:52:38 --> Router Class Initialized
ERROR - 2011-09-11 12:52:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 13:26:43 --> Config Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 13:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 13:26:43 --> URI Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Router Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Output Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Input Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 13:26:43 --> Language Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Loader Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Controller Class Initialized
ERROR - 2011-09-11 13:26:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 13:26:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 13:26:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 13:26:43 --> Model Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Model Class Initialized
DEBUG - 2011-09-11 13:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 13:26:43 --> Database Driver Class Initialized
DEBUG - 2011-09-11 13:26:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 13:26:43 --> Helper loaded: url_helper
DEBUG - 2011-09-11 13:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 13:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 13:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 13:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 13:26:43 --> Final output sent to browser
DEBUG - 2011-09-11 13:26:43 --> Total execution time: 0.0611
DEBUG - 2011-09-11 13:26:44 --> Config Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 13:26:44 --> URI Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Router Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Output Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Input Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 13:26:44 --> Language Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Loader Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Controller Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Model Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Model Class Initialized
DEBUG - 2011-09-11 13:26:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 13:26:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 13:26:45 --> Final output sent to browser
DEBUG - 2011-09-11 13:26:45 --> Total execution time: 1.5186
DEBUG - 2011-09-11 13:26:47 --> Config Class Initialized
DEBUG - 2011-09-11 13:26:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 13:26:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 13:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 13:26:47 --> URI Class Initialized
DEBUG - 2011-09-11 13:26:47 --> Router Class Initialized
ERROR - 2011-09-11 13:26:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 13:26:48 --> Config Class Initialized
DEBUG - 2011-09-11 13:26:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 13:26:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 13:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 13:26:48 --> URI Class Initialized
DEBUG - 2011-09-11 13:26:48 --> Router Class Initialized
ERROR - 2011-09-11 13:26:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 13:31:32 --> Config Class Initialized
DEBUG - 2011-09-11 13:31:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 13:31:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 13:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 13:31:32 --> URI Class Initialized
DEBUG - 2011-09-11 13:31:32 --> Router Class Initialized
ERROR - 2011-09-11 13:31:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-11 14:05:43 --> Config Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:05:43 --> URI Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Router Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Output Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Input Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:05:43 --> Language Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Loader Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Controller Class Initialized
ERROR - 2011-09-11 14:05:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 14:05:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 14:05:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:05:43 --> Model Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Model Class Initialized
DEBUG - 2011-09-11 14:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:05:43 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:05:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:05:43 --> Helper loaded: url_helper
DEBUG - 2011-09-11 14:05:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 14:05:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 14:05:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 14:05:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 14:05:43 --> Final output sent to browser
DEBUG - 2011-09-11 14:05:43 --> Total execution time: 0.0695
DEBUG - 2011-09-11 14:05:46 --> Config Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:05:46 --> URI Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Router Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Output Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Input Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:05:46 --> Language Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Loader Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Controller Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Model Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Model Class Initialized
DEBUG - 2011-09-11 14:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:05:46 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:05:48 --> Final output sent to browser
DEBUG - 2011-09-11 14:05:48 --> Total execution time: 1.7057
DEBUG - 2011-09-11 14:05:49 --> Config Class Initialized
DEBUG - 2011-09-11 14:05:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:05:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:05:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:05:49 --> URI Class Initialized
DEBUG - 2011-09-11 14:05:49 --> Router Class Initialized
ERROR - 2011-09-11 14:05:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 14:06:34 --> Config Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:06:34 --> URI Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Router Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Output Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Input Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:06:34 --> Language Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Loader Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Controller Class Initialized
ERROR - 2011-09-11 14:06:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 14:06:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 14:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:06:34 --> Model Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Model Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:06:34 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:06:34 --> Helper loaded: url_helper
DEBUG - 2011-09-11 14:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 14:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 14:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 14:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 14:06:34 --> Final output sent to browser
DEBUG - 2011-09-11 14:06:34 --> Total execution time: 0.0279
DEBUG - 2011-09-11 14:06:34 --> Config Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:06:34 --> URI Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Router Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Output Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Input Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:06:34 --> Language Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Loader Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Controller Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Model Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Model Class Initialized
DEBUG - 2011-09-11 14:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:06:34 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:06:36 --> Final output sent to browser
DEBUG - 2011-09-11 14:06:36 --> Total execution time: 1.5525
DEBUG - 2011-09-11 14:06:38 --> Config Class Initialized
DEBUG - 2011-09-11 14:06:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:06:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:06:38 --> URI Class Initialized
DEBUG - 2011-09-11 14:06:38 --> Router Class Initialized
ERROR - 2011-09-11 14:06:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 14:10:36 --> Config Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:10:36 --> URI Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Router Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Output Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Input Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:10:36 --> Language Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Loader Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Controller Class Initialized
ERROR - 2011-09-11 14:10:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 14:10:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 14:10:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:10:36 --> Model Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Model Class Initialized
DEBUG - 2011-09-11 14:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:10:36 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:10:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:10:36 --> Helper loaded: url_helper
DEBUG - 2011-09-11 14:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 14:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 14:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 14:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 14:10:36 --> Final output sent to browser
DEBUG - 2011-09-11 14:10:36 --> Total execution time: 0.0306
DEBUG - 2011-09-11 14:10:37 --> Config Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:10:37 --> URI Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Router Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Output Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Input Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:10:37 --> Language Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Loader Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Controller Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Model Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Model Class Initialized
DEBUG - 2011-09-11 14:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:10:37 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:10:38 --> Final output sent to browser
DEBUG - 2011-09-11 14:10:38 --> Total execution time: 1.4569
DEBUG - 2011-09-11 14:10:39 --> Config Class Initialized
DEBUG - 2011-09-11 14:10:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:10:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:10:39 --> URI Class Initialized
DEBUG - 2011-09-11 14:10:39 --> Router Class Initialized
ERROR - 2011-09-11 14:10:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 14:22:21 --> Config Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:22:21 --> URI Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Router Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Output Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Input Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:22:21 --> Language Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Loader Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Controller Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Model Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Model Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Model Class Initialized
DEBUG - 2011-09-11 14:22:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:22:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:22:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 14:22:21 --> Helper loaded: url_helper
DEBUG - 2011-09-11 14:22:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 14:22:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 14:22:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 14:22:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 14:22:21 --> Final output sent to browser
DEBUG - 2011-09-11 14:22:21 --> Total execution time: 0.5143
DEBUG - 2011-09-11 14:35:58 --> Config Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:35:58 --> URI Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Router Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Output Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Input Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:35:58 --> Language Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Loader Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Controller Class Initialized
ERROR - 2011-09-11 14:35:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 14:35:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 14:35:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:35:58 --> Model Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Model Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:35:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:35:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:35:58 --> Helper loaded: url_helper
DEBUG - 2011-09-11 14:35:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 14:35:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 14:35:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 14:35:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 14:35:58 --> Final output sent to browser
DEBUG - 2011-09-11 14:35:58 --> Total execution time: 0.0319
DEBUG - 2011-09-11 14:35:58 --> Config Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:35:58 --> URI Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Router Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Output Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Input Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:35:58 --> Language Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Loader Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Controller Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Model Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Model Class Initialized
DEBUG - 2011-09-11 14:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:35:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:36:00 --> Final output sent to browser
DEBUG - 2011-09-11 14:36:00 --> Total execution time: 1.5225
DEBUG - 2011-09-11 14:59:43 --> Config Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:59:43 --> URI Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Router Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Output Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Input Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:59:43 --> Language Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Loader Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Controller Class Initialized
ERROR - 2011-09-11 14:59:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 14:59:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 14:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:59:43 --> Model Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Model Class Initialized
DEBUG - 2011-09-11 14:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:59:43 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 14:59:43 --> Helper loaded: url_helper
DEBUG - 2011-09-11 14:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 14:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 14:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 14:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 14:59:43 --> Final output sent to browser
DEBUG - 2011-09-11 14:59:43 --> Total execution time: 0.0344
DEBUG - 2011-09-11 14:59:45 --> Config Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Hooks Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Utf8 Class Initialized
DEBUG - 2011-09-11 14:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 14:59:45 --> URI Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Router Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Output Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Input Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 14:59:45 --> Language Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Loader Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Controller Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Model Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Model Class Initialized
DEBUG - 2011-09-11 14:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 14:59:45 --> Database Driver Class Initialized
DEBUG - 2011-09-11 14:59:47 --> Final output sent to browser
DEBUG - 2011-09-11 14:59:47 --> Total execution time: 1.6056
DEBUG - 2011-09-11 15:09:56 --> Config Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:09:56 --> URI Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Router Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Output Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Input Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:09:56 --> Language Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Loader Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Controller Class Initialized
ERROR - 2011-09-11 15:09:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 15:09:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 15:09:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:09:56 --> Model Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Model Class Initialized
DEBUG - 2011-09-11 15:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:09:56 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:09:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:09:56 --> Helper loaded: url_helper
DEBUG - 2011-09-11 15:09:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 15:09:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 15:09:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 15:09:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 15:09:56 --> Final output sent to browser
DEBUG - 2011-09-11 15:09:56 --> Total execution time: 0.1031
DEBUG - 2011-09-11 15:09:57 --> Config Class Initialized
DEBUG - 2011-09-11 15:09:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:09:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:09:58 --> URI Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Router Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Output Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Input Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:09:58 --> Language Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Loader Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Controller Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Model Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Model Class Initialized
DEBUG - 2011-09-11 15:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:09:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:09:59 --> Final output sent to browser
DEBUG - 2011-09-11 15:09:59 --> Total execution time: 1.5271
DEBUG - 2011-09-11 15:10:02 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:02 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:02 --> Router Class Initialized
ERROR - 2011-09-11 15:10:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 15:10:05 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:05 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Router Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Output Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Input Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:10:05 --> Language Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Loader Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Controller Class Initialized
ERROR - 2011-09-11 15:10:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 15:10:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 15:10:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:10:05 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:10:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:10:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:10:05 --> Helper loaded: url_helper
DEBUG - 2011-09-11 15:10:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 15:10:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 15:10:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 15:10:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 15:10:05 --> Final output sent to browser
DEBUG - 2011-09-11 15:10:05 --> Total execution time: 0.0273
DEBUG - 2011-09-11 15:10:06 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:06 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Router Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Output Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Input Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:10:06 --> Language Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Loader Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Controller Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:10:06 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:10:07 --> Final output sent to browser
DEBUG - 2011-09-11 15:10:07 --> Total execution time: 1.4664
DEBUG - 2011-09-11 15:10:08 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:08 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:08 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:08 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:08 --> Router Class Initialized
ERROR - 2011-09-11 15:10:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 15:10:18 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:18 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Router Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Output Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Input Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:10:18 --> Language Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Loader Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Controller Class Initialized
ERROR - 2011-09-11 15:10:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 15:10:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 15:10:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:10:18 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:10:18 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:10:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:10:18 --> Helper loaded: url_helper
DEBUG - 2011-09-11 15:10:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 15:10:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 15:10:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 15:10:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 15:10:18 --> Final output sent to browser
DEBUG - 2011-09-11 15:10:18 --> Total execution time: 0.0276
DEBUG - 2011-09-11 15:10:19 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:19 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Router Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Output Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Input Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:10:19 --> Language Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Loader Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Controller Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:10:19 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:10:20 --> Final output sent to browser
DEBUG - 2011-09-11 15:10:20 --> Total execution time: 1.4372
DEBUG - 2011-09-11 15:10:21 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:21 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:21 --> Router Class Initialized
ERROR - 2011-09-11 15:10:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 15:10:32 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:32 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Router Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Output Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Input Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:10:32 --> Language Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Loader Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Controller Class Initialized
ERROR - 2011-09-11 15:10:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 15:10:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 15:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:10:32 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:10:32 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:10:32 --> Helper loaded: url_helper
DEBUG - 2011-09-11 15:10:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 15:10:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 15:10:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 15:10:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 15:10:32 --> Final output sent to browser
DEBUG - 2011-09-11 15:10:32 --> Total execution time: 0.0458
DEBUG - 2011-09-11 15:10:33 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:33 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Router Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Output Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Input Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:10:33 --> Language Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Loader Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Controller Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:10:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:10:34 --> Final output sent to browser
DEBUG - 2011-09-11 15:10:34 --> Total execution time: 1.5978
DEBUG - 2011-09-11 15:10:35 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:35 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:35 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:35 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:35 --> Router Class Initialized
ERROR - 2011-09-11 15:10:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 15:10:44 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:44 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Router Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Output Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Input Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:10:44 --> Language Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Loader Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Controller Class Initialized
ERROR - 2011-09-11 15:10:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 15:10:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 15:10:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:10:44 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:10:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:10:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:10:44 --> Helper loaded: url_helper
DEBUG - 2011-09-11 15:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 15:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 15:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 15:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 15:10:44 --> Final output sent to browser
DEBUG - 2011-09-11 15:10:44 --> Total execution time: 0.0281
DEBUG - 2011-09-11 15:10:44 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:44 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Router Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Output Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Input Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:10:44 --> Language Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Loader Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Controller Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Model Class Initialized
DEBUG - 2011-09-11 15:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:10:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:10:46 --> Final output sent to browser
DEBUG - 2011-09-11 15:10:46 --> Total execution time: 1.5026
DEBUG - 2011-09-11 15:10:47 --> Config Class Initialized
DEBUG - 2011-09-11 15:10:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:10:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:10:47 --> URI Class Initialized
DEBUG - 2011-09-11 15:10:47 --> Router Class Initialized
ERROR - 2011-09-11 15:10:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 15:11:42 --> Config Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:11:42 --> URI Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Router Class Initialized
ERROR - 2011-09-11 15:11:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-11 15:11:42 --> Config Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:11:42 --> URI Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Router Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Output Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Input Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:11:42 --> Language Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Loader Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Controller Class Initialized
ERROR - 2011-09-11 15:11:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 15:11:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 15:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:11:42 --> Model Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Model Class Initialized
DEBUG - 2011-09-11 15:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:11:42 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:11:42 --> Helper loaded: url_helper
DEBUG - 2011-09-11 15:11:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 15:11:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 15:11:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 15:11:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 15:11:42 --> Final output sent to browser
DEBUG - 2011-09-11 15:11:42 --> Total execution time: 0.0276
DEBUG - 2011-09-11 15:41:53 --> Config Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:41:53 --> URI Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Router Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Output Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Input Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:41:53 --> Language Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Loader Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Controller Class Initialized
ERROR - 2011-09-11 15:41:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 15:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 15:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:41:53 --> Model Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Model Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:41:53 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 15:41:53 --> Helper loaded: url_helper
DEBUG - 2011-09-11 15:41:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 15:41:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 15:41:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 15:41:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 15:41:53 --> Final output sent to browser
DEBUG - 2011-09-11 15:41:53 --> Total execution time: 0.0335
DEBUG - 2011-09-11 15:41:53 --> Config Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:41:53 --> URI Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Router Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Output Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Input Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:41:53 --> Language Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Loader Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Controller Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Model Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Model Class Initialized
DEBUG - 2011-09-11 15:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:41:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:41:55 --> Final output sent to browser
DEBUG - 2011-09-11 15:41:55 --> Total execution time: 1.5735
DEBUG - 2011-09-11 15:41:56 --> Config Class Initialized
DEBUG - 2011-09-11 15:41:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:41:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:41:56 --> URI Class Initialized
DEBUG - 2011-09-11 15:41:56 --> Router Class Initialized
ERROR - 2011-09-11 15:41:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 15:54:56 --> Config Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:54:56 --> URI Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Router Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Output Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Input Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 15:54:56 --> Language Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Loader Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Controller Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Model Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Model Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Model Class Initialized
DEBUG - 2011-09-11 15:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 15:54:56 --> Database Driver Class Initialized
DEBUG - 2011-09-11 15:54:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 15:54:56 --> Helper loaded: url_helper
DEBUG - 2011-09-11 15:54:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 15:54:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 15:54:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 15:54:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 15:54:56 --> Final output sent to browser
DEBUG - 2011-09-11 15:54:56 --> Total execution time: 0.2410
DEBUG - 2011-09-11 15:54:58 --> Config Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:54:58 --> URI Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Router Class Initialized
ERROR - 2011-09-11 15:54:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 15:54:58 --> Config Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:54:58 --> URI Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Router Class Initialized
ERROR - 2011-09-11 15:54:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 15:54:58 --> Config Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 15:54:58 --> URI Class Initialized
DEBUG - 2011-09-11 15:54:58 --> Router Class Initialized
ERROR - 2011-09-11 15:54:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:03:01 --> Config Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:03:01 --> URI Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Router Class Initialized
ERROR - 2011-09-11 16:03:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-11 16:03:01 --> Config Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:03:01 --> URI Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Router Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Output Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Input Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:03:01 --> Language Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Loader Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Controller Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Model Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Model Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Model Class Initialized
DEBUG - 2011-09-11 16:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:03:01 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:03:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:03:01 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:03:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:03:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:03:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:03:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:03:01 --> Final output sent to browser
DEBUG - 2011-09-11 16:03:01 --> Total execution time: 0.0479
DEBUG - 2011-09-11 16:09:34 --> Config Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:09:34 --> URI Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Router Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Output Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Input Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:09:34 --> Language Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Loader Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Controller Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Model Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Model Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Model Class Initialized
DEBUG - 2011-09-11 16:09:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:09:34 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:09:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:09:34 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:09:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:09:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:09:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:09:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:09:34 --> Final output sent to browser
DEBUG - 2011-09-11 16:09:34 --> Total execution time: 0.0493
DEBUG - 2011-09-11 16:09:36 --> Config Class Initialized
DEBUG - 2011-09-11 16:09:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:09:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:09:36 --> URI Class Initialized
DEBUG - 2011-09-11 16:09:36 --> Router Class Initialized
ERROR - 2011-09-11 16:09:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:09:53 --> Config Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:09:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:09:53 --> URI Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Router Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Output Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Input Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:09:53 --> Language Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Loader Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Controller Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Model Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Model Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Model Class Initialized
DEBUG - 2011-09-11 16:09:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:09:53 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:09:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:09:53 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:09:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:09:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:09:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:09:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:09:53 --> Final output sent to browser
DEBUG - 2011-09-11 16:09:53 --> Total execution time: 0.2531
DEBUG - 2011-09-11 16:09:54 --> Config Class Initialized
DEBUG - 2011-09-11 16:09:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:09:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:09:54 --> URI Class Initialized
DEBUG - 2011-09-11 16:09:54 --> Router Class Initialized
ERROR - 2011-09-11 16:09:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:10:12 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:12 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Router Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Output Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Input Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:10:12 --> Language Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Loader Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Controller Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:10:12 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:10:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:10:12 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:10:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:10:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:10:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:10:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:10:12 --> Final output sent to browser
DEBUG - 2011-09-11 16:10:12 --> Total execution time: 0.1990
DEBUG - 2011-09-11 16:10:13 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:13 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:13 --> Router Class Initialized
ERROR - 2011-09-11 16:10:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:10:24 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:24 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Router Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Output Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Input Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:10:24 --> Language Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Loader Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Controller Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:10:24 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:10:24 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:10:24 --> Final output sent to browser
DEBUG - 2011-09-11 16:10:24 --> Total execution time: 0.2298
DEBUG - 2011-09-11 16:10:25 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:25 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:25 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:25 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:25 --> Router Class Initialized
ERROR - 2011-09-11 16:10:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:10:33 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:33 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Router Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Output Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Input Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:10:33 --> Language Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Loader Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Controller Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:10:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:10:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:10:33 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:10:33 --> Final output sent to browser
DEBUG - 2011-09-11 16:10:33 --> Total execution time: 0.2447
DEBUG - 2011-09-11 16:10:34 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:34 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:34 --> Router Class Initialized
ERROR - 2011-09-11 16:10:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:10:38 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:38 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Router Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Output Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Input Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:10:38 --> Language Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Loader Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Controller Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:10:38 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:10:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:10:38 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:10:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:10:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:10:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:10:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:10:38 --> Final output sent to browser
DEBUG - 2011-09-11 16:10:38 --> Total execution time: 0.2046
DEBUG - 2011-09-11 16:10:40 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:40 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:40 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:40 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:40 --> Router Class Initialized
ERROR - 2011-09-11 16:10:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:10:42 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:42 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Router Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Output Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Input Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:10:42 --> Language Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Loader Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Controller Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:10:42 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:10:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:10:42 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:10:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:10:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:10:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:10:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:10:42 --> Final output sent to browser
DEBUG - 2011-09-11 16:10:42 --> Total execution time: 0.2803
DEBUG - 2011-09-11 16:10:44 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:44 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:44 --> Router Class Initialized
ERROR - 2011-09-11 16:10:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:10:44 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:44 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:44 --> Router Class Initialized
ERROR - 2011-09-11 16:10:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:10:47 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:47 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Router Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Output Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Input Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:10:47 --> Language Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Loader Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Controller Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:10:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:10:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:10:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:10:47 --> Final output sent to browser
DEBUG - 2011-09-11 16:10:47 --> Total execution time: 0.4091
DEBUG - 2011-09-11 16:10:49 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:49 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:49 --> Router Class Initialized
ERROR - 2011-09-11 16:10:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:10:58 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:58 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Router Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Output Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Input Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:10:58 --> Language Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Loader Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Controller Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Model Class Initialized
DEBUG - 2011-09-11 16:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:10:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:10:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:10:58 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:10:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:10:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:10:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:10:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:10:58 --> Final output sent to browser
DEBUG - 2011-09-11 16:10:58 --> Total execution time: 0.0447
DEBUG - 2011-09-11 16:10:59 --> Config Class Initialized
DEBUG - 2011-09-11 16:10:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:10:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:10:59 --> URI Class Initialized
DEBUG - 2011-09-11 16:10:59 --> Router Class Initialized
ERROR - 2011-09-11 16:10:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:11:02 --> Config Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:11:02 --> URI Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Router Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Output Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Input Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:11:02 --> Language Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Loader Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Controller Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Model Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Model Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Model Class Initialized
DEBUG - 2011-09-11 16:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:11:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:11:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:11:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:11:02 --> Final output sent to browser
DEBUG - 2011-09-11 16:11:02 --> Total execution time: 0.3244
DEBUG - 2011-09-11 16:11:03 --> Config Class Initialized
DEBUG - 2011-09-11 16:11:03 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:11:03 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:11:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:11:03 --> URI Class Initialized
DEBUG - 2011-09-11 16:11:03 --> Router Class Initialized
ERROR - 2011-09-11 16:11:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:11:05 --> Config Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:11:05 --> URI Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Router Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Output Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Input Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:11:05 --> Language Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Loader Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Controller Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Model Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Model Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Model Class Initialized
DEBUG - 2011-09-11 16:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:11:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:11:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 16:11:05 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:11:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:11:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:11:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:11:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:11:05 --> Final output sent to browser
DEBUG - 2011-09-11 16:11:05 --> Total execution time: 0.0422
DEBUG - 2011-09-11 16:27:09 --> Config Class Initialized
DEBUG - 2011-09-11 16:27:09 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:27:09 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:27:09 --> URI Class Initialized
DEBUG - 2011-09-11 16:27:09 --> Router Class Initialized
DEBUG - 2011-09-11 16:27:09 --> No URI present. Default controller set.
DEBUG - 2011-09-11 16:27:09 --> Output Class Initialized
DEBUG - 2011-09-11 16:27:09 --> Input Class Initialized
DEBUG - 2011-09-11 16:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:27:09 --> Language Class Initialized
DEBUG - 2011-09-11 16:27:09 --> Loader Class Initialized
DEBUG - 2011-09-11 16:27:09 --> Controller Class Initialized
DEBUG - 2011-09-11 16:27:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-11 16:27:09 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:27:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:27:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:27:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:27:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:27:09 --> Final output sent to browser
DEBUG - 2011-09-11 16:27:09 --> Total execution time: 0.0681
DEBUG - 2011-09-11 16:53:09 --> Config Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:53:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:53:09 --> URI Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Router Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Output Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Input Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:53:09 --> Language Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Loader Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Controller Class Initialized
ERROR - 2011-09-11 16:53:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 16:53:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 16:53:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 16:53:09 --> Model Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Model Class Initialized
DEBUG - 2011-09-11 16:53:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:53:09 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:53:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 16:53:09 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:53:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:53:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:53:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:53:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:53:09 --> Final output sent to browser
DEBUG - 2011-09-11 16:53:09 --> Total execution time: 0.0624
DEBUG - 2011-09-11 16:53:11 --> Config Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:53:11 --> URI Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Router Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Output Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Input Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:53:11 --> Language Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Loader Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Controller Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Model Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Model Class Initialized
DEBUG - 2011-09-11 16:53:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:53:11 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:53:12 --> Final output sent to browser
DEBUG - 2011-09-11 16:53:12 --> Total execution time: 1.5287
DEBUG - 2011-09-11 16:53:19 --> Config Class Initialized
DEBUG - 2011-09-11 16:53:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:53:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:53:19 --> URI Class Initialized
DEBUG - 2011-09-11 16:53:19 --> Router Class Initialized
ERROR - 2011-09-11 16:53:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:53:19 --> Config Class Initialized
DEBUG - 2011-09-11 16:53:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:53:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:53:19 --> URI Class Initialized
DEBUG - 2011-09-11 16:53:19 --> Router Class Initialized
ERROR - 2011-09-11 16:53:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 16:56:33 --> Config Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:56:33 --> URI Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Router Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Output Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Input Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:56:33 --> Language Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Loader Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Controller Class Initialized
ERROR - 2011-09-11 16:56:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 16:56:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 16:56:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 16:56:33 --> Model Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Model Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:56:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:56:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 16:56:33 --> Helper loaded: url_helper
DEBUG - 2011-09-11 16:56:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 16:56:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 16:56:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 16:56:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 16:56:33 --> Final output sent to browser
DEBUG - 2011-09-11 16:56:33 --> Total execution time: 0.0291
DEBUG - 2011-09-11 16:56:33 --> Config Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:56:33 --> URI Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Router Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Output Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Input Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:56:33 --> Language Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Loader Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Controller Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Model Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Model Class Initialized
DEBUG - 2011-09-11 16:56:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:56:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:56:35 --> Final output sent to browser
DEBUG - 2011-09-11 16:56:35 --> Total execution time: 1.5003
DEBUG - 2011-09-11 16:56:48 --> Config Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 16:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 16:56:48 --> URI Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Router Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Output Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Input Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 16:56:48 --> Language Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Loader Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Controller Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Model Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Model Class Initialized
DEBUG - 2011-09-11 16:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 16:56:48 --> Database Driver Class Initialized
DEBUG - 2011-09-11 16:56:49 --> Final output sent to browser
DEBUG - 2011-09-11 16:56:49 --> Total execution time: 1.3784
DEBUG - 2011-09-11 17:04:03 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:03 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Router Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Output Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Input Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:04:03 --> Language Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Loader Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Controller Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:04:03 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:04:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:04:03 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:04:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:04:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:04:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:04:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:04:03 --> Final output sent to browser
DEBUG - 2011-09-11 17:04:03 --> Total execution time: 0.3369
DEBUG - 2011-09-11 17:04:06 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:06 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:06 --> Router Class Initialized
ERROR - 2011-09-11 17:04:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 17:04:06 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:06 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:06 --> Router Class Initialized
ERROR - 2011-09-11 17:04:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 17:04:16 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:16 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:16 --> Router Class Initialized
ERROR - 2011-09-11 17:04:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-11 17:04:17 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:17 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:17 --> Router Class Initialized
DEBUG - 2011-09-11 17:04:17 --> No URI present. Default controller set.
DEBUG - 2011-09-11 17:04:17 --> Output Class Initialized
DEBUG - 2011-09-11 17:04:17 --> Input Class Initialized
DEBUG - 2011-09-11 17:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:04:17 --> Language Class Initialized
DEBUG - 2011-09-11 17:04:17 --> Loader Class Initialized
DEBUG - 2011-09-11 17:04:17 --> Controller Class Initialized
DEBUG - 2011-09-11 17:04:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-11 17:04:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:04:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:04:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:04:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:04:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:04:17 --> Final output sent to browser
DEBUG - 2011-09-11 17:04:17 --> Total execution time: 0.0434
DEBUG - 2011-09-11 17:04:18 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:18 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Router Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Output Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Input Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:04:18 --> Language Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Loader Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Controller Class Initialized
ERROR - 2011-09-11 17:04:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 17:04:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 17:04:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:04:18 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:04:18 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:04:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:04:18 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:04:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:04:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:04:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:04:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:04:18 --> Final output sent to browser
DEBUG - 2011-09-11 17:04:18 --> Total execution time: 0.0477
DEBUG - 2011-09-11 17:04:19 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:19 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Router Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Output Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Input Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:04:19 --> Language Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Loader Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Controller Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:04:19 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:04:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:04:19 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:04:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:04:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:04:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:04:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:04:19 --> Final output sent to browser
DEBUG - 2011-09-11 17:04:19 --> Total execution time: 0.0594
DEBUG - 2011-09-11 17:04:47 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:47 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Router Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Output Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Input Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:04:47 --> Language Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Loader Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Controller Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:04:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:04:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:04:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:04:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:04:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:04:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:04:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:04:47 --> Final output sent to browser
DEBUG - 2011-09-11 17:04:47 --> Total execution time: 0.2864
DEBUG - 2011-09-11 17:04:53 --> Config Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:04:53 --> URI Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Router Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Output Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Input Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:04:53 --> Language Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Loader Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Controller Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Model Class Initialized
DEBUG - 2011-09-11 17:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:04:53 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:04:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:04:53 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:04:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:04:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:04:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:04:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:04:53 --> Final output sent to browser
DEBUG - 2011-09-11 17:04:53 --> Total execution time: 0.0512
DEBUG - 2011-09-11 17:05:05 --> Config Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:05:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:05:05 --> URI Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Router Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Output Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Input Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:05:05 --> Language Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Loader Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Controller Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:05:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:05:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:05:06 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:05:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:05:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:05:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:05:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:05:06 --> Final output sent to browser
DEBUG - 2011-09-11 17:05:06 --> Total execution time: 0.3853
DEBUG - 2011-09-11 17:05:08 --> Config Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:05:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:05:08 --> URI Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Router Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Output Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Input Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:05:08 --> Language Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Loader Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Controller Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:05:08 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:05:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:05:08 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:05:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:05:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:05:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:05:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:05:08 --> Final output sent to browser
DEBUG - 2011-09-11 17:05:08 --> Total execution time: 0.0752
DEBUG - 2011-09-11 17:05:15 --> Config Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:05:15 --> URI Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Router Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Output Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Input Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:05:15 --> Language Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Loader Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Controller Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:05:15 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:05:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:05:15 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:05:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:05:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:05:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:05:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:05:15 --> Final output sent to browser
DEBUG - 2011-09-11 17:05:15 --> Total execution time: 0.2810
DEBUG - 2011-09-11 17:05:16 --> Config Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:05:16 --> URI Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Router Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Output Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Input Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:05:16 --> Language Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Loader Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Controller Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:05:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:05:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:05:16 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:05:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:05:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:05:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:05:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:05:16 --> Final output sent to browser
DEBUG - 2011-09-11 17:05:16 --> Total execution time: 0.0436
DEBUG - 2011-09-11 17:05:21 --> Config Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:05:21 --> URI Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Router Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Output Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Input Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:05:21 --> Language Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Loader Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Controller Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:05:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:05:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:05:21 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:05:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:05:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:05:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:05:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:05:21 --> Final output sent to browser
DEBUG - 2011-09-11 17:05:21 --> Total execution time: 0.5076
DEBUG - 2011-09-11 17:05:24 --> Config Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:05:24 --> URI Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Router Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Output Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Input Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:05:24 --> Language Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Loader Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Controller Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:05:24 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:05:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:05:24 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:05:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:05:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:05:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:05:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:05:24 --> Final output sent to browser
DEBUG - 2011-09-11 17:05:24 --> Total execution time: 0.1156
DEBUG - 2011-09-11 17:05:29 --> Config Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:05:29 --> URI Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Router Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Output Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Input Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:05:29 --> Language Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Loader Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Controller Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:05:29 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:05:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:05:29 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:05:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:05:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:05:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:05:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:05:29 --> Final output sent to browser
DEBUG - 2011-09-11 17:05:29 --> Total execution time: 0.2392
DEBUG - 2011-09-11 17:05:31 --> Config Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:05:31 --> URI Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Router Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Output Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Input Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:05:31 --> Language Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Loader Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Controller Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Model Class Initialized
DEBUG - 2011-09-11 17:05:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:05:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:05:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 17:05:31 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:05:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:05:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:05:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:05:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:05:31 --> Final output sent to browser
DEBUG - 2011-09-11 17:05:31 --> Total execution time: 0.0587
DEBUG - 2011-09-11 17:56:20 --> Config Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:56:20 --> URI Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Router Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Output Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Input Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:56:20 --> Language Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Loader Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Controller Class Initialized
ERROR - 2011-09-11 17:56:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 17:56:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 17:56:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:56:20 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:56:20 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:56:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:56:20 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:56:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:56:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:56:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:56:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:56:20 --> Final output sent to browser
DEBUG - 2011-09-11 17:56:20 --> Total execution time: 0.0303
DEBUG - 2011-09-11 17:56:27 --> Config Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:56:27 --> URI Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Router Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Output Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Input Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:56:27 --> Language Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Loader Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Controller Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:56:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:56:29 --> Final output sent to browser
DEBUG - 2011-09-11 17:56:29 --> Total execution time: 1.6873
DEBUG - 2011-09-11 17:56:42 --> Config Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:56:42 --> URI Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Router Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Output Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Input Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:56:42 --> Language Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Loader Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Controller Class Initialized
ERROR - 2011-09-11 17:56:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 17:56:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 17:56:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:56:42 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:56:42 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:56:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:56:42 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:56:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:56:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:56:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:56:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:56:42 --> Final output sent to browser
DEBUG - 2011-09-11 17:56:42 --> Total execution time: 0.0310
DEBUG - 2011-09-11 17:56:47 --> Config Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:56:47 --> URI Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Router Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Output Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Input Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:56:47 --> Language Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Loader Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Controller Class Initialized
ERROR - 2011-09-11 17:56:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 17:56:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 17:56:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:56:47 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:56:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:56:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:56:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:56:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:56:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:56:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:56:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:56:47 --> Final output sent to browser
DEBUG - 2011-09-11 17:56:47 --> Total execution time: 0.0303
DEBUG - 2011-09-11 17:56:48 --> Config Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:56:48 --> URI Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Router Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Output Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Input Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:56:48 --> Language Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Loader Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Controller Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Model Class Initialized
DEBUG - 2011-09-11 17:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:56:48 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:56:50 --> Final output sent to browser
DEBUG - 2011-09-11 17:56:50 --> Total execution time: 1.5896
DEBUG - 2011-09-11 17:57:12 --> Config Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:57:12 --> URI Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Router Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Output Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Input Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:57:12 --> Language Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Loader Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Controller Class Initialized
ERROR - 2011-09-11 17:57:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 17:57:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 17:57:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:57:12 --> Model Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Model Class Initialized
DEBUG - 2011-09-11 17:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:57:12 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:57:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:57:12 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:57:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:57:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:57:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:57:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:57:12 --> Final output sent to browser
DEBUG - 2011-09-11 17:57:12 --> Total execution time: 0.0423
DEBUG - 2011-09-11 17:57:16 --> Config Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:57:16 --> URI Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Router Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Output Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Input Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:57:16 --> Language Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Loader Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Controller Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Model Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Model Class Initialized
DEBUG - 2011-09-11 17:57:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:57:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:57:18 --> Final output sent to browser
DEBUG - 2011-09-11 17:57:18 --> Total execution time: 1.5281
DEBUG - 2011-09-11 17:58:34 --> Config Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:58:34 --> URI Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Router Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Output Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Input Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:58:34 --> Language Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Loader Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Controller Class Initialized
ERROR - 2011-09-11 17:58:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 17:58:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 17:58:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:58:34 --> Model Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Model Class Initialized
DEBUG - 2011-09-11 17:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:58:34 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:58:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:58:34 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:58:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:58:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:58:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:58:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:58:34 --> Final output sent to browser
DEBUG - 2011-09-11 17:58:34 --> Total execution time: 0.0303
DEBUG - 2011-09-11 17:58:40 --> Config Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:58:40 --> URI Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Router Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Output Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Input Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:58:40 --> Language Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Loader Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Controller Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Model Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Model Class Initialized
DEBUG - 2011-09-11 17:58:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:58:40 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:58:41 --> Final output sent to browser
DEBUG - 2011-09-11 17:58:41 --> Total execution time: 1.5416
DEBUG - 2011-09-11 17:59:08 --> Config Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:59:08 --> URI Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Router Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Output Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Input Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:59:08 --> Language Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Loader Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Controller Class Initialized
ERROR - 2011-09-11 17:59:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 17:59:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 17:59:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:59:08 --> Model Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Model Class Initialized
DEBUG - 2011-09-11 17:59:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:59:08 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:59:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 17:59:08 --> Helper loaded: url_helper
DEBUG - 2011-09-11 17:59:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 17:59:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 17:59:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 17:59:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 17:59:08 --> Final output sent to browser
DEBUG - 2011-09-11 17:59:08 --> Total execution time: 0.0338
DEBUG - 2011-09-11 17:59:12 --> Config Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Hooks Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Utf8 Class Initialized
DEBUG - 2011-09-11 17:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 17:59:12 --> URI Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Router Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Output Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Input Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 17:59:12 --> Language Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Loader Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Controller Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Model Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Model Class Initialized
DEBUG - 2011-09-11 17:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 17:59:12 --> Database Driver Class Initialized
DEBUG - 2011-09-11 17:59:14 --> Final output sent to browser
DEBUG - 2011-09-11 17:59:14 --> Total execution time: 1.3505
DEBUG - 2011-09-11 18:00:20 --> Config Class Initialized
DEBUG - 2011-09-11 18:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:00:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:00:21 --> URI Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Router Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Output Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Input Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:00:21 --> Language Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Loader Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Controller Class Initialized
ERROR - 2011-09-11 18:00:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:00:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:00:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:00:21 --> Model Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Model Class Initialized
DEBUG - 2011-09-11 18:00:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:00:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:00:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:00:21 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:00:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:00:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:00:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:00:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:00:21 --> Final output sent to browser
DEBUG - 2011-09-11 18:00:21 --> Total execution time: 0.2499
DEBUG - 2011-09-11 18:00:26 --> Config Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:00:26 --> URI Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Router Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Output Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Input Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:00:26 --> Language Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Loader Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Controller Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Model Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Model Class Initialized
DEBUG - 2011-09-11 18:00:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:00:26 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:00:28 --> Final output sent to browser
DEBUG - 2011-09-11 18:00:28 --> Total execution time: 1.6139
DEBUG - 2011-09-11 18:00:56 --> Config Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:00:56 --> URI Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Router Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Output Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Input Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:00:56 --> Language Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Loader Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Controller Class Initialized
ERROR - 2011-09-11 18:00:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:00:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:00:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:00:56 --> Model Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Model Class Initialized
DEBUG - 2011-09-11 18:00:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:00:56 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:00:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:00:56 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:00:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:00:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:00:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:00:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:00:56 --> Final output sent to browser
DEBUG - 2011-09-11 18:00:56 --> Total execution time: 0.0280
DEBUG - 2011-09-11 18:01:01 --> Config Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:01:01 --> URI Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Router Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Output Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Input Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:01:01 --> Language Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Loader Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Controller Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Model Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Model Class Initialized
DEBUG - 2011-09-11 18:01:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:01:01 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:01:03 --> Final output sent to browser
DEBUG - 2011-09-11 18:01:03 --> Total execution time: 1.6952
DEBUG - 2011-09-11 18:01:56 --> Config Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:01:56 --> URI Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Router Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Output Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Input Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:01:56 --> Language Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Loader Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Controller Class Initialized
ERROR - 2011-09-11 18:01:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:01:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:01:56 --> Model Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Model Class Initialized
DEBUG - 2011-09-11 18:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:01:56 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:01:56 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:01:56 --> Final output sent to browser
DEBUG - 2011-09-11 18:01:56 --> Total execution time: 0.0308
DEBUG - 2011-09-11 18:02:01 --> Config Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:02:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:02:01 --> URI Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Router Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Output Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Input Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:02:01 --> Language Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Loader Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Controller Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Model Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Model Class Initialized
DEBUG - 2011-09-11 18:02:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:02:01 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:02:03 --> Final output sent to browser
DEBUG - 2011-09-11 18:02:03 --> Total execution time: 1.3968
DEBUG - 2011-09-11 18:02:30 --> Config Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:02:30 --> URI Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Router Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Output Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Input Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:02:30 --> Language Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Loader Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Controller Class Initialized
ERROR - 2011-09-11 18:02:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:02:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:02:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:02:30 --> Model Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Model Class Initialized
DEBUG - 2011-09-11 18:02:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:02:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:02:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:02:30 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:02:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:02:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:02:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:02:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:02:30 --> Final output sent to browser
DEBUG - 2011-09-11 18:02:30 --> Total execution time: 0.0309
DEBUG - 2011-09-11 18:02:36 --> Config Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:02:36 --> URI Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Router Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Output Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Input Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:02:36 --> Language Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Loader Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Controller Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Model Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Model Class Initialized
DEBUG - 2011-09-11 18:02:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:02:36 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:02:37 --> Final output sent to browser
DEBUG - 2011-09-11 18:02:37 --> Total execution time: 1.4854
DEBUG - 2011-09-11 18:03:54 --> Config Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:03:54 --> URI Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Router Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Output Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Input Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:03:54 --> Language Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Loader Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Controller Class Initialized
ERROR - 2011-09-11 18:03:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:03:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:03:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:03:54 --> Model Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Model Class Initialized
DEBUG - 2011-09-11 18:03:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:03:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:03:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:03:54 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:03:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:03:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:03:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:03:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:03:54 --> Final output sent to browser
DEBUG - 2011-09-11 18:03:54 --> Total execution time: 0.0307
DEBUG - 2011-09-11 18:03:59 --> Config Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:03:59 --> URI Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Router Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Output Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Input Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:03:59 --> Language Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Loader Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Controller Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Model Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Model Class Initialized
DEBUG - 2011-09-11 18:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:03:59 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:04:01 --> Final output sent to browser
DEBUG - 2011-09-11 18:04:01 --> Total execution time: 1.6930
DEBUG - 2011-09-11 18:04:45 --> Config Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:04:45 --> URI Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Router Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Output Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Input Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:04:45 --> Language Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Loader Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Controller Class Initialized
ERROR - 2011-09-11 18:04:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:04:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:04:45 --> Model Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Model Class Initialized
DEBUG - 2011-09-11 18:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:04:45 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:04:45 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:04:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:04:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:04:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:04:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:04:45 --> Final output sent to browser
DEBUG - 2011-09-11 18:04:45 --> Total execution time: 0.0312
DEBUG - 2011-09-11 18:04:49 --> Config Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:04:49 --> URI Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Router Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Output Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Input Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:04:49 --> Language Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Loader Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Controller Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Model Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Model Class Initialized
DEBUG - 2011-09-11 18:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:04:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:04:50 --> Final output sent to browser
DEBUG - 2011-09-11 18:04:50 --> Total execution time: 1.3615
DEBUG - 2011-09-11 18:07:57 --> Config Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:07:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:07:57 --> URI Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Router Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Output Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Input Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:07:57 --> Language Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Loader Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Controller Class Initialized
ERROR - 2011-09-11 18:07:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:07:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:07:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:07:57 --> Model Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Model Class Initialized
DEBUG - 2011-09-11 18:07:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:07:57 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:07:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:07:57 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:07:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:07:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:07:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:07:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:07:57 --> Final output sent to browser
DEBUG - 2011-09-11 18:07:57 --> Total execution time: 0.0292
DEBUG - 2011-09-11 18:07:58 --> Config Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:07:58 --> URI Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Router Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Output Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Input Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:07:58 --> Language Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Loader Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Controller Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Model Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Model Class Initialized
DEBUG - 2011-09-11 18:07:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:07:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:08:00 --> Final output sent to browser
DEBUG - 2011-09-11 18:08:00 --> Total execution time: 1.3213
DEBUG - 2011-09-11 18:08:00 --> Config Class Initialized
DEBUG - 2011-09-11 18:08:00 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:08:00 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:08:00 --> URI Class Initialized
DEBUG - 2011-09-11 18:08:00 --> Router Class Initialized
ERROR - 2011-09-11 18:08:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:08:01 --> Config Class Initialized
DEBUG - 2011-09-11 18:08:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:08:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:08:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:08:01 --> URI Class Initialized
DEBUG - 2011-09-11 18:08:01 --> Router Class Initialized
ERROR - 2011-09-11 18:08:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:08:16 --> Config Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:08:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:08:16 --> URI Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Router Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Output Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Input Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:08:16 --> Language Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Loader Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Controller Class Initialized
ERROR - 2011-09-11 18:08:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:08:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:08:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:08:16 --> Model Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Model Class Initialized
DEBUG - 2011-09-11 18:08:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:08:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:08:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:08:16 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:08:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:08:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:08:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:08:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:08:16 --> Final output sent to browser
DEBUG - 2011-09-11 18:08:16 --> Total execution time: 0.0512
DEBUG - 2011-09-11 18:08:17 --> Config Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:08:17 --> URI Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Router Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Output Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Input Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:08:17 --> Language Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Loader Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Controller Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Model Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Model Class Initialized
DEBUG - 2011-09-11 18:08:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:08:17 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:08:18 --> Final output sent to browser
DEBUG - 2011-09-11 18:08:18 --> Total execution time: 1.4004
DEBUG - 2011-09-11 18:15:46 --> Config Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:15:46 --> URI Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Router Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Output Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Input Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:15:46 --> Language Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Loader Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Controller Class Initialized
ERROR - 2011-09-11 18:15:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:15:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:15:46 --> Model Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Model Class Initialized
DEBUG - 2011-09-11 18:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:15:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:15:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:15:47 --> Final output sent to browser
DEBUG - 2011-09-11 18:15:47 --> Total execution time: 0.0367
DEBUG - 2011-09-11 18:15:47 --> Config Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:15:47 --> URI Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Router Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Output Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Input Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:15:47 --> Language Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Loader Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Controller Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Model Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Model Class Initialized
DEBUG - 2011-09-11 18:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:15:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:15:49 --> Final output sent to browser
DEBUG - 2011-09-11 18:15:49 --> Total execution time: 1.5585
DEBUG - 2011-09-11 18:15:50 --> Config Class Initialized
DEBUG - 2011-09-11 18:15:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:15:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:15:50 --> URI Class Initialized
DEBUG - 2011-09-11 18:15:50 --> Router Class Initialized
ERROR - 2011-09-11 18:15:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:36:01 --> Config Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:36:01 --> URI Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Router Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Output Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Input Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:36:01 --> Language Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Loader Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Controller Class Initialized
ERROR - 2011-09-11 18:36:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:36:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:36:01 --> Model Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Model Class Initialized
DEBUG - 2011-09-11 18:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:36:01 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:36:01 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:36:01 --> Final output sent to browser
DEBUG - 2011-09-11 18:36:01 --> Total execution time: 0.1403
DEBUG - 2011-09-11 18:36:03 --> Config Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:36:03 --> URI Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Router Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Output Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Input Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:36:03 --> Language Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Loader Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Controller Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Model Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Model Class Initialized
DEBUG - 2011-09-11 18:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:36:03 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:36:04 --> Final output sent to browser
DEBUG - 2011-09-11 18:36:04 --> Total execution time: 1.5475
DEBUG - 2011-09-11 18:36:05 --> Config Class Initialized
DEBUG - 2011-09-11 18:36:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:36:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:36:05 --> URI Class Initialized
DEBUG - 2011-09-11 18:36:05 --> Router Class Initialized
ERROR - 2011-09-11 18:36:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:40:02 --> Config Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:40:02 --> URI Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Router Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Output Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Input Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:40:02 --> Language Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Loader Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Controller Class Initialized
ERROR - 2011-09-11 18:40:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:40:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:40:02 --> Model Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Model Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:40:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:40:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:40:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:40:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:40:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:40:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:40:02 --> Final output sent to browser
DEBUG - 2011-09-11 18:40:02 --> Total execution time: 0.0586
DEBUG - 2011-09-11 18:40:02 --> Config Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:40:02 --> URI Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Router Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Output Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Input Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:40:02 --> Language Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Loader Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Controller Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Model Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Model Class Initialized
DEBUG - 2011-09-11 18:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:40:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Final output sent to browser
DEBUG - 2011-09-11 18:40:04 --> Total execution time: 1.5045
DEBUG - 2011-09-11 18:40:04 --> Config Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:40:04 --> URI Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Router Class Initialized
ERROR - 2011-09-11 18:40:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:40:04 --> Config Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:40:04 --> URI Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Router Class Initialized
ERROR - 2011-09-11 18:40:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:40:04 --> Config Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:40:04 --> URI Class Initialized
DEBUG - 2011-09-11 18:40:04 --> Router Class Initialized
ERROR - 2011-09-11 18:40:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:41:02 --> Config Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:41:02 --> URI Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Router Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Output Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Input Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:41:02 --> Language Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Loader Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Controller Class Initialized
ERROR - 2011-09-11 18:41:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 18:41:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 18:41:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:41:02 --> Model Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Model Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:41:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:41:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 18:41:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:41:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:41:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:41:02 --> Final output sent to browser
DEBUG - 2011-09-11 18:41:02 --> Total execution time: 0.0335
DEBUG - 2011-09-11 18:41:02 --> Config Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:41:02 --> URI Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Router Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Output Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Input Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:41:02 --> Language Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Loader Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Controller Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Model Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Model Class Initialized
DEBUG - 2011-09-11 18:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:41:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:41:03 --> Final output sent to browser
DEBUG - 2011-09-11 18:41:03 --> Total execution time: 1.2136
DEBUG - 2011-09-11 18:43:11 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:11 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Router Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Output Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Input Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:43:11 --> Language Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Loader Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Controller Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:43:11 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:43:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 18:43:12 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:43:12 --> Final output sent to browser
DEBUG - 2011-09-11 18:43:12 --> Total execution time: 0.9844
DEBUG - 2011-09-11 18:43:13 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:13 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:13 --> Router Class Initialized
ERROR - 2011-09-11 18:43:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:43:21 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:21 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Router Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Output Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Input Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:43:21 --> Language Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Loader Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Controller Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:43:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:43:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 18:43:21 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:43:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:43:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:43:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:43:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:43:21 --> Final output sent to browser
DEBUG - 2011-09-11 18:43:21 --> Total execution time: 0.3619
DEBUG - 2011-09-11 18:43:22 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:22 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Router Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Output Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Input Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:43:22 --> Language Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Loader Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Controller Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:43:22 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:43:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 18:43:22 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:43:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:43:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:43:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:43:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:43:22 --> Final output sent to browser
DEBUG - 2011-09-11 18:43:22 --> Total execution time: 0.0440
DEBUG - 2011-09-11 18:43:24 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:24 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:24 --> Router Class Initialized
ERROR - 2011-09-11 18:43:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:43:38 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:38 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Router Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Output Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Input Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:43:38 --> Language Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Loader Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Controller Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:43:38 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:43:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 18:43:38 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:43:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:43:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:43:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:43:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:43:38 --> Final output sent to browser
DEBUG - 2011-09-11 18:43:38 --> Total execution time: 0.2701
DEBUG - 2011-09-11 18:43:39 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:39 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Router Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Output Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Input Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:43:39 --> Language Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Loader Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Controller Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:43:39 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:43:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 18:43:39 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:43:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:43:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:43:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:43:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:43:39 --> Final output sent to browser
DEBUG - 2011-09-11 18:43:39 --> Total execution time: 0.0422
DEBUG - 2011-09-11 18:43:39 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:39 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:39 --> Router Class Initialized
ERROR - 2011-09-11 18:43:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:43:50 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:50 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Router Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Output Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Input Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:43:50 --> Language Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Loader Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Controller Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:43:50 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:43:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 18:43:50 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:43:50 --> Final output sent to browser
DEBUG - 2011-09-11 18:43:50 --> Total execution time: 0.3754
DEBUG - 2011-09-11 18:43:51 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:51 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:51 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:51 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:51 --> Router Class Initialized
ERROR - 2011-09-11 18:43:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 18:43:57 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:57 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Router Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Output Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Input Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 18:43:57 --> Language Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Loader Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Controller Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Model Class Initialized
DEBUG - 2011-09-11 18:43:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 18:43:57 --> Database Driver Class Initialized
DEBUG - 2011-09-11 18:43:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 18:43:57 --> Helper loaded: url_helper
DEBUG - 2011-09-11 18:43:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 18:43:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 18:43:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 18:43:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 18:43:57 --> Final output sent to browser
DEBUG - 2011-09-11 18:43:57 --> Total execution time: 0.2463
DEBUG - 2011-09-11 18:43:58 --> Config Class Initialized
DEBUG - 2011-09-11 18:43:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 18:43:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 18:43:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 18:43:58 --> URI Class Initialized
DEBUG - 2011-09-11 18:43:58 --> Router Class Initialized
ERROR - 2011-09-11 18:43:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:05:57 --> Config Class Initialized
DEBUG - 2011-09-11 19:05:57 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:05:57 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:05:57 --> URI Class Initialized
DEBUG - 2011-09-11 19:05:57 --> Router Class Initialized
ERROR - 2011-09-11 19:05:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-11 19:15:23 --> Config Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:15:23 --> URI Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Router Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Output Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Input Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:15:23 --> Language Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Loader Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Controller Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:15:23 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:15:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:15:23 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:15:23 --> Final output sent to browser
DEBUG - 2011-09-11 19:15:23 --> Total execution time: 0.2649
DEBUG - 2011-09-11 19:15:26 --> Config Class Initialized
DEBUG - 2011-09-11 19:15:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:15:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:15:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:15:26 --> URI Class Initialized
DEBUG - 2011-09-11 19:15:26 --> Router Class Initialized
ERROR - 2011-09-11 19:15:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:15:28 --> Config Class Initialized
DEBUG - 2011-09-11 19:15:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:15:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:15:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:15:28 --> URI Class Initialized
DEBUG - 2011-09-11 19:15:28 --> Router Class Initialized
ERROR - 2011-09-11 19:15:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:15:47 --> Config Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:15:47 --> URI Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Router Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Output Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Input Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:15:47 --> Language Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Loader Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Controller Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:15:47 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:15:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:15:47 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:15:47 --> Final output sent to browser
DEBUG - 2011-09-11 19:15:47 --> Total execution time: 0.4055
DEBUG - 2011-09-11 19:15:48 --> Config Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:15:48 --> URI Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Router Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Output Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Input Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:15:48 --> Language Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Loader Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Controller Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:15:48 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:15:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:15:48 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:15:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:15:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:15:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:15:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:15:48 --> Final output sent to browser
DEBUG - 2011-09-11 19:15:48 --> Total execution time: 0.0424
DEBUG - 2011-09-11 19:15:48 --> Config Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:15:48 --> URI Class Initialized
DEBUG - 2011-09-11 19:15:48 --> Router Class Initialized
ERROR - 2011-09-11 19:15:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:15:59 --> Config Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:15:59 --> URI Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Router Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Output Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Input Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:15:59 --> Language Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Loader Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Controller Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Model Class Initialized
DEBUG - 2011-09-11 19:15:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:15:59 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:15:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:15:59 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:15:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:15:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:15:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:15:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:15:59 --> Final output sent to browser
DEBUG - 2011-09-11 19:15:59 --> Total execution time: 0.3416
DEBUG - 2011-09-11 19:16:02 --> Config Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:16:02 --> URI Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Router Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Output Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Input Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:16:02 --> Language Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Loader Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Controller Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Model Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Model Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Model Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:16:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:16:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:16:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:16:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:16:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:16:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:16:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:16:02 --> Final output sent to browser
DEBUG - 2011-09-11 19:16:02 --> Total execution time: 0.0824
DEBUG - 2011-09-11 19:16:02 --> Config Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:16:02 --> URI Class Initialized
DEBUG - 2011-09-11 19:16:02 --> Router Class Initialized
ERROR - 2011-09-11 19:16:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:16:38 --> Config Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:16:38 --> URI Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Router Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Output Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Input Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:16:38 --> Language Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Loader Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Controller Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Model Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Model Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Model Class Initialized
DEBUG - 2011-09-11 19:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:16:38 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:16:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:16:38 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:16:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:16:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:16:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:16:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:16:38 --> Final output sent to browser
DEBUG - 2011-09-11 19:16:38 --> Total execution time: 0.3809
DEBUG - 2011-09-11 19:16:41 --> Config Class Initialized
DEBUG - 2011-09-11 19:16:41 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:16:41 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:16:41 --> URI Class Initialized
DEBUG - 2011-09-11 19:16:41 --> Router Class Initialized
ERROR - 2011-09-11 19:16:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:17:16 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:16 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Router Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Output Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Input Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:17:16 --> Language Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Loader Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Controller Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:17:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:17:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:17:16 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:17:16 --> Final output sent to browser
DEBUG - 2011-09-11 19:17:16 --> Total execution time: 0.2630
DEBUG - 2011-09-11 19:17:17 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:17 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Router Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Output Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Input Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:17:17 --> Language Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Loader Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Controller Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:17:17 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:17:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:17:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:17:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:17:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:17:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:17:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:17:17 --> Final output sent to browser
DEBUG - 2011-09-11 19:17:17 --> Total execution time: 0.0414
DEBUG - 2011-09-11 19:17:17 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:17 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:17 --> Router Class Initialized
ERROR - 2011-09-11 19:17:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:17:30 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:30 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Router Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Output Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Input Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:17:30 --> Language Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Loader Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Controller Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:17:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:17:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:17:31 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:17:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:17:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:17:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:17:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:17:31 --> Final output sent to browser
DEBUG - 2011-09-11 19:17:31 --> Total execution time: 0.4424
DEBUG - 2011-09-11 19:17:32 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:32 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Router Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Output Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Input Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:17:32 --> Language Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Loader Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Controller Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:17:32 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:17:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:17:32 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:17:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:17:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:17:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:17:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:17:32 --> Final output sent to browser
DEBUG - 2011-09-11 19:17:32 --> Total execution time: 0.0775
DEBUG - 2011-09-11 19:17:32 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:32 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:32 --> Router Class Initialized
ERROR - 2011-09-11 19:17:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:17:53 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:53 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Router Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Output Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Input Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:17:53 --> Language Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Loader Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Controller Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:17:53 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:17:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:17:53 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:17:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:17:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:17:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:17:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:17:53 --> Final output sent to browser
DEBUG - 2011-09-11 19:17:53 --> Total execution time: 0.3015
DEBUG - 2011-09-11 19:17:54 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:54 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Router Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Output Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Input Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:17:54 --> Language Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Loader Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Controller Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Model Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:17:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:17:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:17:54 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:17:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:17:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:17:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:17:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:17:54 --> Final output sent to browser
DEBUG - 2011-09-11 19:17:54 --> Total execution time: 0.0490
DEBUG - 2011-09-11 19:17:54 --> Config Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:17:54 --> URI Class Initialized
DEBUG - 2011-09-11 19:17:54 --> Router Class Initialized
ERROR - 2011-09-11 19:17:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:18:15 --> Config Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:18:15 --> URI Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Router Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Output Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Input Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:18:15 --> Language Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Loader Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Controller Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:18:15 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:18:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:18:15 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:18:15 --> Final output sent to browser
DEBUG - 2011-09-11 19:18:15 --> Total execution time: 0.2083
DEBUG - 2011-09-11 19:18:16 --> Config Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:18:16 --> URI Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Router Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Output Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Input Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:18:16 --> Language Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Loader Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Controller Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:18:16 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:18:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:18:16 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:18:16 --> Final output sent to browser
DEBUG - 2011-09-11 19:18:16 --> Total execution time: 0.0500
DEBUG - 2011-09-11 19:18:16 --> Config Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:18:16 --> URI Class Initialized
DEBUG - 2011-09-11 19:18:16 --> Router Class Initialized
ERROR - 2011-09-11 19:18:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:18:31 --> Config Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:18:31 --> URI Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Router Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Output Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Input Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:18:31 --> Language Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Loader Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Controller Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:18:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:18:32 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:18:32 --> Final output sent to browser
DEBUG - 2011-09-11 19:18:32 --> Total execution time: 0.5181
DEBUG - 2011-09-11 19:18:32 --> Config Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:18:32 --> URI Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Router Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Output Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Input Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:18:32 --> Language Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Loader Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Controller Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:18:32 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:18:32 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:18:32 --> Final output sent to browser
DEBUG - 2011-09-11 19:18:32 --> Total execution time: 0.0421
DEBUG - 2011-09-11 19:18:33 --> Config Class Initialized
DEBUG - 2011-09-11 19:18:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:18:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:18:33 --> URI Class Initialized
DEBUG - 2011-09-11 19:18:33 --> Router Class Initialized
ERROR - 2011-09-11 19:18:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:18:49 --> Config Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:18:49 --> URI Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Router Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Output Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Input Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:18:49 --> Language Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Loader Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Controller Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Model Class Initialized
DEBUG - 2011-09-11 19:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:18:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:18:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:18:49 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:18:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:18:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:18:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:18:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:18:49 --> Final output sent to browser
DEBUG - 2011-09-11 19:18:49 --> Total execution time: 0.3593
DEBUG - 2011-09-11 19:18:50 --> Config Class Initialized
DEBUG - 2011-09-11 19:18:50 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:18:50 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:18:50 --> URI Class Initialized
DEBUG - 2011-09-11 19:18:50 --> Router Class Initialized
ERROR - 2011-09-11 19:18:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:19:07 --> Config Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:19:07 --> URI Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Router Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Output Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Input Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:19:07 --> Language Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Loader Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Controller Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:19:07 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:19:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:19:07 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:19:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:19:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:19:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:19:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:19:07 --> Final output sent to browser
DEBUG - 2011-09-11 19:19:07 --> Total execution time: 0.2238
DEBUG - 2011-09-11 19:19:08 --> Config Class Initialized
DEBUG - 2011-09-11 19:19:08 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:19:08 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:19:08 --> URI Class Initialized
DEBUG - 2011-09-11 19:19:08 --> Router Class Initialized
ERROR - 2011-09-11 19:19:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:19:25 --> Config Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:19:25 --> URI Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Router Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Output Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Input Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:19:25 --> Language Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Loader Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Controller Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:19:25 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:19:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:19:25 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:19:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:19:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:19:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:19:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:19:25 --> Final output sent to browser
DEBUG - 2011-09-11 19:19:25 --> Total execution time: 0.2182
DEBUG - 2011-09-11 19:19:26 --> Config Class Initialized
DEBUG - 2011-09-11 19:19:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:19:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:19:26 --> URI Class Initialized
DEBUG - 2011-09-11 19:19:26 --> Router Class Initialized
ERROR - 2011-09-11 19:19:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:19:27 --> Config Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:19:27 --> URI Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Router Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Output Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Input Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:19:27 --> Language Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Loader Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Controller Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:19:27 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:19:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:19:27 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:19:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:19:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:19:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:19:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:19:27 --> Final output sent to browser
DEBUG - 2011-09-11 19:19:27 --> Total execution time: 0.0677
DEBUG - 2011-09-11 19:19:36 --> Config Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:19:36 --> URI Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Router Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Output Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Input Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:19:36 --> Language Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Loader Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Controller Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Model Class Initialized
DEBUG - 2011-09-11 19:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:19:36 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:19:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:19:37 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:19:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:19:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:19:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:19:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:19:37 --> Final output sent to browser
DEBUG - 2011-09-11 19:19:37 --> Total execution time: 0.2979
DEBUG - 2011-09-11 19:19:38 --> Config Class Initialized
DEBUG - 2011-09-11 19:19:38 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:19:38 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:19:38 --> URI Class Initialized
DEBUG - 2011-09-11 19:19:38 --> Router Class Initialized
ERROR - 2011-09-11 19:19:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:20:13 --> Config Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:20:13 --> URI Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Router Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Output Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Input Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:20:13 --> Language Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Loader Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Controller Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Model Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Model Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Model Class Initialized
DEBUG - 2011-09-11 19:20:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:20:13 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:20:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:20:14 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:20:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:20:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:20:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:20:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:20:14 --> Final output sent to browser
DEBUG - 2011-09-11 19:20:14 --> Total execution time: 0.2677
DEBUG - 2011-09-11 19:20:15 --> Config Class Initialized
DEBUG - 2011-09-11 19:20:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:20:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:20:15 --> URI Class Initialized
DEBUG - 2011-09-11 19:20:15 --> Router Class Initialized
ERROR - 2011-09-11 19:20:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:20:15 --> Config Class Initialized
DEBUG - 2011-09-11 19:20:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:20:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:20:15 --> URI Class Initialized
DEBUG - 2011-09-11 19:20:15 --> Router Class Initialized
ERROR - 2011-09-11 19:20:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:20:37 --> Config Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:20:37 --> URI Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Router Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Output Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Input Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:20:37 --> Language Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Loader Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Controller Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Model Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Model Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Model Class Initialized
DEBUG - 2011-09-11 19:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:20:37 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:20:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:20:38 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:20:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:20:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:20:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:20:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:20:38 --> Final output sent to browser
DEBUG - 2011-09-11 19:20:38 --> Total execution time: 0.2846
DEBUG - 2011-09-11 19:20:39 --> Config Class Initialized
DEBUG - 2011-09-11 19:20:39 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:20:39 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:20:39 --> URI Class Initialized
DEBUG - 2011-09-11 19:20:39 --> Router Class Initialized
ERROR - 2011-09-11 19:20:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:21:05 --> Config Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:21:05 --> URI Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Router Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Output Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Input Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:21:05 --> Language Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Loader Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Controller Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:21:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:21:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:21:05 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:21:05 --> Final output sent to browser
DEBUG - 2011-09-11 19:21:05 --> Total execution time: 0.2670
DEBUG - 2011-09-11 19:21:06 --> Config Class Initialized
DEBUG - 2011-09-11 19:21:06 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:21:06 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:21:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:21:06 --> URI Class Initialized
DEBUG - 2011-09-11 19:21:06 --> Router Class Initialized
ERROR - 2011-09-11 19:21:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:21:18 --> Config Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:21:18 --> URI Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Router Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Output Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Input Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:21:18 --> Language Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Loader Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Controller Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:21:18 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:21:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:21:18 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:21:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:21:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:21:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:21:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:21:18 --> Final output sent to browser
DEBUG - 2011-09-11 19:21:18 --> Total execution time: 0.5084
DEBUG - 2011-09-11 19:21:20 --> Config Class Initialized
DEBUG - 2011-09-11 19:21:20 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:21:20 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:21:20 --> URI Class Initialized
DEBUG - 2011-09-11 19:21:20 --> Router Class Initialized
ERROR - 2011-09-11 19:21:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:21:20 --> Config Class Initialized
DEBUG - 2011-09-11 19:21:20 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:21:20 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:21:20 --> URI Class Initialized
DEBUG - 2011-09-11 19:21:20 --> Router Class Initialized
ERROR - 2011-09-11 19:21:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:21:44 --> Config Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:21:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:21:44 --> URI Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Router Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Output Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Input Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:21:44 --> Language Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Loader Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Controller Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Model Class Initialized
DEBUG - 2011-09-11 19:21:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:21:44 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:21:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:21:45 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:21:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:21:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:21:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:21:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:21:45 --> Final output sent to browser
DEBUG - 2011-09-11 19:21:45 --> Total execution time: 0.2803
DEBUG - 2011-09-11 19:21:46 --> Config Class Initialized
DEBUG - 2011-09-11 19:21:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:21:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:21:46 --> URI Class Initialized
DEBUG - 2011-09-11 19:21:46 --> Router Class Initialized
ERROR - 2011-09-11 19:21:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:22:07 --> Config Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:22:07 --> URI Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Router Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Output Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Input Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:22:07 --> Language Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Loader Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Controller Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Model Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Model Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Model Class Initialized
DEBUG - 2011-09-11 19:22:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:22:07 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:22:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:22:07 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:22:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:22:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:22:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:22:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:22:07 --> Final output sent to browser
DEBUG - 2011-09-11 19:22:07 --> Total execution time: 0.3010
DEBUG - 2011-09-11 19:22:08 --> Config Class Initialized
DEBUG - 2011-09-11 19:22:08 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:22:08 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:22:08 --> URI Class Initialized
DEBUG - 2011-09-11 19:22:08 --> Router Class Initialized
ERROR - 2011-09-11 19:22:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 19:22:28 --> Config Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:22:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:22:28 --> URI Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Router Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Output Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Input Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 19:22:28 --> Language Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Loader Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Controller Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Model Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Model Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Model Class Initialized
DEBUG - 2011-09-11 19:22:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 19:22:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 19:22:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 19:22:28 --> Helper loaded: url_helper
DEBUG - 2011-09-11 19:22:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 19:22:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 19:22:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 19:22:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 19:22:28 --> Final output sent to browser
DEBUG - 2011-09-11 19:22:28 --> Total execution time: 0.1202
DEBUG - 2011-09-11 19:22:29 --> Config Class Initialized
DEBUG - 2011-09-11 19:22:29 --> Hooks Class Initialized
DEBUG - 2011-09-11 19:22:29 --> Utf8 Class Initialized
DEBUG - 2011-09-11 19:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 19:22:29 --> URI Class Initialized
DEBUG - 2011-09-11 19:22:29 --> Router Class Initialized
ERROR - 2011-09-11 19:22:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 20:30:07 --> Config Class Initialized
DEBUG - 2011-09-11 20:30:07 --> Hooks Class Initialized
DEBUG - 2011-09-11 20:30:07 --> Utf8 Class Initialized
DEBUG - 2011-09-11 20:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 20:30:07 --> URI Class Initialized
DEBUG - 2011-09-11 20:30:07 --> Router Class Initialized
DEBUG - 2011-09-11 20:30:07 --> Output Class Initialized
DEBUG - 2011-09-11 20:30:07 --> Input Class Initialized
DEBUG - 2011-09-11 20:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 20:30:07 --> Language Class Initialized
DEBUG - 2011-09-11 20:30:07 --> Loader Class Initialized
DEBUG - 2011-09-11 20:30:07 --> Controller Class Initialized
ERROR - 2011-09-11 20:30:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 20:30:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 20:30:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 20:30:08 --> Model Class Initialized
DEBUG - 2011-09-11 20:30:08 --> Model Class Initialized
DEBUG - 2011-09-11 20:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 20:30:08 --> Database Driver Class Initialized
DEBUG - 2011-09-11 20:30:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 20:30:09 --> Helper loaded: url_helper
DEBUG - 2011-09-11 20:30:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 20:30:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 20:30:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 20:30:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 20:30:09 --> Final output sent to browser
DEBUG - 2011-09-11 20:30:09 --> Total execution time: 1.1660
DEBUG - 2011-09-11 21:32:02 --> Config Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:32:02 --> URI Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Router Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Output Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Input Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:32:02 --> Language Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Loader Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Controller Class Initialized
ERROR - 2011-09-11 21:32:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 21:32:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 21:32:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 21:32:02 --> Model Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Model Class Initialized
DEBUG - 2011-09-11 21:32:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:32:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:32:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 21:32:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:32:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:32:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:32:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:32:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:32:02 --> Final output sent to browser
DEBUG - 2011-09-11 21:32:02 --> Total execution time: 0.0485
DEBUG - 2011-09-11 21:32:04 --> Config Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:32:04 --> URI Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Router Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Output Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Input Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:32:04 --> Language Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Loader Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Controller Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Model Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Model Class Initialized
DEBUG - 2011-09-11 21:32:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:32:04 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:32:06 --> Final output sent to browser
DEBUG - 2011-09-11 21:32:06 --> Total execution time: 1.4733
DEBUG - 2011-09-11 21:32:11 --> Config Class Initialized
DEBUG - 2011-09-11 21:32:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:32:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:32:11 --> URI Class Initialized
DEBUG - 2011-09-11 21:32:11 --> Router Class Initialized
ERROR - 2011-09-11 21:32:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:32:21 --> Config Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:32:21 --> URI Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Router Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Output Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Input Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:32:21 --> Language Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Loader Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Controller Class Initialized
ERROR - 2011-09-11 21:32:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 21:32:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 21:32:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 21:32:21 --> Model Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Model Class Initialized
DEBUG - 2011-09-11 21:32:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:32:21 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:32:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 21:32:21 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:32:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:32:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:32:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:32:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:32:21 --> Final output sent to browser
DEBUG - 2011-09-11 21:32:21 --> Total execution time: 0.0300
DEBUG - 2011-09-11 21:32:22 --> Config Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:32:22 --> URI Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Router Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Output Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Input Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:32:22 --> Language Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Loader Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Controller Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Model Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Model Class Initialized
DEBUG - 2011-09-11 21:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:32:22 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:32:24 --> Final output sent to browser
DEBUG - 2011-09-11 21:32:24 --> Total execution time: 1.5297
DEBUG - 2011-09-11 21:32:28 --> Config Class Initialized
DEBUG - 2011-09-11 21:32:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:32:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:32:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:32:28 --> URI Class Initialized
DEBUG - 2011-09-11 21:32:28 --> Router Class Initialized
ERROR - 2011-09-11 21:32:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:40:14 --> Config Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:40:14 --> URI Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Router Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Output Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Input Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:40:14 --> Language Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Loader Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Controller Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Model Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Model Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Model Class Initialized
DEBUG - 2011-09-11 21:40:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:40:14 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:40:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:40:17 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:40:17 --> Final output sent to browser
DEBUG - 2011-09-11 21:40:17 --> Total execution time: 2.5074
DEBUG - 2011-09-11 21:40:37 --> Config Class Initialized
DEBUG - 2011-09-11 21:40:37 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:40:37 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:40:37 --> URI Class Initialized
DEBUG - 2011-09-11 21:40:37 --> Router Class Initialized
ERROR - 2011-09-11 21:40:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:42:31 --> Config Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:42:31 --> URI Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Router Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Output Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Input Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:42:31 --> Language Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Loader Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Controller Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Model Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Model Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Model Class Initialized
DEBUG - 2011-09-11 21:42:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:42:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:42:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:42:31 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:42:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:42:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:42:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:42:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:42:31 --> Final output sent to browser
DEBUG - 2011-09-11 21:42:31 --> Total execution time: 0.3791
DEBUG - 2011-09-11 21:42:33 --> Config Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:42:33 --> URI Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Router Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Output Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Input Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:42:33 --> Language Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Loader Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Controller Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Model Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Model Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Model Class Initialized
DEBUG - 2011-09-11 21:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:42:33 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:42:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:42:33 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:42:33 --> Final output sent to browser
DEBUG - 2011-09-11 21:42:33 --> Total execution time: 0.0443
DEBUG - 2011-09-11 21:42:44 --> Config Class Initialized
DEBUG - 2011-09-11 21:42:44 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:42:44 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:42:44 --> URI Class Initialized
DEBUG - 2011-09-11 21:42:44 --> Router Class Initialized
ERROR - 2011-09-11 21:42:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:43:24 --> Config Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:43:24 --> URI Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Router Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Output Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Input Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:43:24 --> Language Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Loader Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Controller Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:43:24 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:43:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:43:24 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:43:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:43:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:43:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:43:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:43:24 --> Final output sent to browser
DEBUG - 2011-09-11 21:43:24 --> Total execution time: 0.5809
DEBUG - 2011-09-11 21:43:26 --> Config Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:43:26 --> URI Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Router Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Output Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Input Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:43:26 --> Language Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Loader Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Controller Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:43:26 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:43:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:43:26 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:43:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:43:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:43:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:43:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:43:26 --> Final output sent to browser
DEBUG - 2011-09-11 21:43:26 --> Total execution time: 0.0452
DEBUG - 2011-09-11 21:43:28 --> Config Class Initialized
DEBUG - 2011-09-11 21:43:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:43:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:43:28 --> URI Class Initialized
DEBUG - 2011-09-11 21:43:28 --> Router Class Initialized
ERROR - 2011-09-11 21:43:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:43:46 --> Config Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:43:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:43:46 --> URI Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Router Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Output Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Input Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:43:46 --> Language Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Loader Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Controller Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:43:46 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:43:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:43:46 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:43:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:43:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:43:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:43:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:43:46 --> Final output sent to browser
DEBUG - 2011-09-11 21:43:46 --> Total execution time: 0.2360
DEBUG - 2011-09-11 21:43:49 --> Config Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:43:49 --> URI Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Router Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Output Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Input Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:43:49 --> Language Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Loader Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Controller Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:43:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:43:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:43:49 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:43:49 --> Final output sent to browser
DEBUG - 2011-09-11 21:43:49 --> Total execution time: 0.0446
DEBUG - 2011-09-11 21:43:55 --> Config Class Initialized
DEBUG - 2011-09-11 21:43:55 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:43:55 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:43:55 --> URI Class Initialized
DEBUG - 2011-09-11 21:43:55 --> Router Class Initialized
ERROR - 2011-09-11 21:43:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:43:59 --> Config Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:43:59 --> URI Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Router Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Output Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Input Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:43:59 --> Language Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Loader Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Controller Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Model Class Initialized
DEBUG - 2011-09-11 21:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:43:59 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:43:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:43:59 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:43:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:43:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:43:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:43:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:43:59 --> Final output sent to browser
DEBUG - 2011-09-11 21:43:59 --> Total execution time: 0.2407
DEBUG - 2011-09-11 21:44:02 --> Config Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:44:02 --> URI Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Router Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Output Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Input Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:44:02 --> Language Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Loader Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Controller Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:44:02 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:44:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:44:02 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:44:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:44:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:44:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:44:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:44:02 --> Final output sent to browser
DEBUG - 2011-09-11 21:44:02 --> Total execution time: 0.1384
DEBUG - 2011-09-11 21:44:04 --> Config Class Initialized
DEBUG - 2011-09-11 21:44:04 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:44:04 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:44:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:44:04 --> URI Class Initialized
DEBUG - 2011-09-11 21:44:04 --> Router Class Initialized
ERROR - 2011-09-11 21:44:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:44:25 --> Config Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:44:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:44:25 --> URI Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Router Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Output Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Input Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:44:25 --> Language Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Loader Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Controller Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:44:25 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:44:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:44:26 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:44:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:44:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:44:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:44:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:44:26 --> Final output sent to browser
DEBUG - 2011-09-11 21:44:26 --> Total execution time: 0.2370
DEBUG - 2011-09-11 21:44:28 --> Config Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:44:28 --> URI Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Router Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Output Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Input Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:44:28 --> Language Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Loader Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Controller Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Model Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:44:28 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:44:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:44:28 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:44:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:44:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:44:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:44:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:44:28 --> Final output sent to browser
DEBUG - 2011-09-11 21:44:28 --> Total execution time: 0.0464
DEBUG - 2011-09-11 21:44:28 --> Config Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:44:28 --> URI Class Initialized
DEBUG - 2011-09-11 21:44:28 --> Router Class Initialized
ERROR - 2011-09-11 21:44:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:45:54 --> Config Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:45:54 --> URI Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Router Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Output Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Input Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:45:54 --> Language Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Loader Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Controller Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Model Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Model Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Model Class Initialized
DEBUG - 2011-09-11 21:45:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:45:54 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:45:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:45:55 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:45:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:45:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:45:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:45:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:45:55 --> Final output sent to browser
DEBUG - 2011-09-11 21:45:55 --> Total execution time: 0.4032
DEBUG - 2011-09-11 21:45:56 --> Config Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:45:56 --> URI Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Router Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Output Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Input Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:45:56 --> Language Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Loader Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Controller Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Model Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Model Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Model Class Initialized
DEBUG - 2011-09-11 21:45:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:45:56 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:45:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:45:56 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:45:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:45:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:45:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:45:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:45:56 --> Final output sent to browser
DEBUG - 2011-09-11 21:45:56 --> Total execution time: 0.0508
DEBUG - 2011-09-11 21:46:00 --> Config Class Initialized
DEBUG - 2011-09-11 21:46:00 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:46:00 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:46:00 --> URI Class Initialized
DEBUG - 2011-09-11 21:46:00 --> Router Class Initialized
ERROR - 2011-09-11 21:46:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 21:46:29 --> Config Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:46:29 --> URI Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Router Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Output Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Input Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:46:29 --> Language Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Loader Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Controller Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Model Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Model Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Model Class Initialized
DEBUG - 2011-09-11 21:46:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:46:29 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:46:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:46:29 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:46:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:46:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:46:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:46:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:46:29 --> Final output sent to browser
DEBUG - 2011-09-11 21:46:29 --> Total execution time: 0.2204
DEBUG - 2011-09-11 21:46:31 --> Config Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:46:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:46:31 --> URI Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Router Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Output Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Input Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 21:46:31 --> Language Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Loader Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Controller Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Model Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Model Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Model Class Initialized
DEBUG - 2011-09-11 21:46:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 21:46:31 --> Database Driver Class Initialized
DEBUG - 2011-09-11 21:46:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 21:46:31 --> Helper loaded: url_helper
DEBUG - 2011-09-11 21:46:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 21:46:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 21:46:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 21:46:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 21:46:31 --> Final output sent to browser
DEBUG - 2011-09-11 21:46:31 --> Total execution time: 0.0453
DEBUG - 2011-09-11 21:46:34 --> Config Class Initialized
DEBUG - 2011-09-11 21:46:34 --> Hooks Class Initialized
DEBUG - 2011-09-11 21:46:34 --> Utf8 Class Initialized
DEBUG - 2011-09-11 21:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 21:46:34 --> URI Class Initialized
DEBUG - 2011-09-11 21:46:34 --> Router Class Initialized
ERROR - 2011-09-11 21:46:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 22:24:48 --> Config Class Initialized
DEBUG - 2011-09-11 22:24:48 --> Hooks Class Initialized
DEBUG - 2011-09-11 22:24:48 --> Utf8 Class Initialized
DEBUG - 2011-09-11 22:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 22:24:48 --> URI Class Initialized
DEBUG - 2011-09-11 22:24:48 --> Router Class Initialized
ERROR - 2011-09-11 22:24:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-11 22:24:49 --> Config Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Hooks Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Utf8 Class Initialized
DEBUG - 2011-09-11 22:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 22:24:49 --> URI Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Router Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Output Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Input Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 22:24:49 --> Language Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Loader Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Controller Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Model Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Model Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Model Class Initialized
DEBUG - 2011-09-11 22:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 22:24:49 --> Database Driver Class Initialized
DEBUG - 2011-09-11 22:24:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 22:24:50 --> Helper loaded: url_helper
DEBUG - 2011-09-11 22:24:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 22:24:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 22:24:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 22:24:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 22:24:50 --> Final output sent to browser
DEBUG - 2011-09-11 22:24:50 --> Total execution time: 0.6533
DEBUG - 2011-09-11 22:24:52 --> Config Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Hooks Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Utf8 Class Initialized
DEBUG - 2011-09-11 22:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 22:24:52 --> URI Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Router Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Output Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Input Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 22:24:52 --> Language Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Loader Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Controller Class Initialized
ERROR - 2011-09-11 22:24:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-11 22:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-11 22:24:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 22:24:52 --> Model Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Model Class Initialized
DEBUG - 2011-09-11 22:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 22:24:52 --> Database Driver Class Initialized
DEBUG - 2011-09-11 22:24:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-11 22:24:52 --> Helper loaded: url_helper
DEBUG - 2011-09-11 22:24:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 22:24:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 22:24:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 22:24:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 22:24:52 --> Final output sent to browser
DEBUG - 2011-09-11 22:24:52 --> Total execution time: 0.0270
DEBUG - 2011-09-11 22:48:05 --> Config Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Hooks Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Utf8 Class Initialized
DEBUG - 2011-09-11 22:48:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 22:48:05 --> URI Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Router Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Output Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Input Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 22:48:05 --> Language Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Loader Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Controller Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Model Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Model Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Model Class Initialized
DEBUG - 2011-09-11 22:48:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 22:48:05 --> Database Driver Class Initialized
DEBUG - 2011-09-11 22:48:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 22:48:05 --> Helper loaded: url_helper
DEBUG - 2011-09-11 22:48:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 22:48:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 22:48:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 22:48:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 22:48:05 --> Final output sent to browser
DEBUG - 2011-09-11 22:48:05 --> Total execution time: 0.2753
DEBUG - 2011-09-11 22:48:14 --> Config Class Initialized
DEBUG - 2011-09-11 22:48:14 --> Hooks Class Initialized
DEBUG - 2011-09-11 22:48:14 --> Utf8 Class Initialized
DEBUG - 2011-09-11 22:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 22:48:14 --> URI Class Initialized
DEBUG - 2011-09-11 22:48:14 --> Router Class Initialized
ERROR - 2011-09-11 22:48:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 22:48:14 --> Config Class Initialized
DEBUG - 2011-09-11 22:48:14 --> Hooks Class Initialized
DEBUG - 2011-09-11 22:48:14 --> Utf8 Class Initialized
DEBUG - 2011-09-11 22:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 22:48:14 --> URI Class Initialized
DEBUG - 2011-09-11 22:48:14 --> Router Class Initialized
ERROR - 2011-09-11 22:48:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 22:48:15 --> Config Class Initialized
DEBUG - 2011-09-11 22:48:15 --> Hooks Class Initialized
DEBUG - 2011-09-11 22:48:15 --> Utf8 Class Initialized
DEBUG - 2011-09-11 22:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 22:48:15 --> URI Class Initialized
DEBUG - 2011-09-11 22:48:15 --> Router Class Initialized
ERROR - 2011-09-11 22:48:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 23:25:11 --> Config Class Initialized
DEBUG - 2011-09-11 23:25:11 --> Hooks Class Initialized
DEBUG - 2011-09-11 23:25:11 --> Utf8 Class Initialized
DEBUG - 2011-09-11 23:25:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 23:25:11 --> URI Class Initialized
DEBUG - 2011-09-11 23:25:11 --> Router Class Initialized
DEBUG - 2011-09-11 23:25:12 --> No URI present. Default controller set.
DEBUG - 2011-09-11 23:25:12 --> Output Class Initialized
DEBUG - 2011-09-11 23:25:12 --> Input Class Initialized
DEBUG - 2011-09-11 23:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 23:25:12 --> Language Class Initialized
DEBUG - 2011-09-11 23:25:12 --> Loader Class Initialized
DEBUG - 2011-09-11 23:25:12 --> Controller Class Initialized
DEBUG - 2011-09-11 23:25:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-11 23:25:12 --> Helper loaded: url_helper
DEBUG - 2011-09-11 23:25:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 23:25:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 23:25:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 23:25:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 23:25:12 --> Final output sent to browser
DEBUG - 2011-09-11 23:25:12 --> Total execution time: 0.7228
DEBUG - 2011-09-11 23:38:58 --> Config Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Hooks Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Utf8 Class Initialized
DEBUG - 2011-09-11 23:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 23:38:58 --> URI Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Router Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Output Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Input Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 23:38:58 --> Language Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Loader Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Controller Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Model Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Model Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Model Class Initialized
DEBUG - 2011-09-11 23:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 23:38:58 --> Database Driver Class Initialized
DEBUG - 2011-09-11 23:38:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 23:38:58 --> Helper loaded: url_helper
DEBUG - 2011-09-11 23:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 23:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 23:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 23:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 23:38:58 --> Final output sent to browser
DEBUG - 2011-09-11 23:38:58 --> Total execution time: 0.2050
DEBUG - 2011-09-11 23:39:02 --> Config Class Initialized
DEBUG - 2011-09-11 23:39:02 --> Hooks Class Initialized
DEBUG - 2011-09-11 23:39:02 --> Utf8 Class Initialized
DEBUG - 2011-09-11 23:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 23:39:02 --> URI Class Initialized
DEBUG - 2011-09-11 23:39:02 --> Router Class Initialized
ERROR - 2011-09-11 23:39:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-11 23:52:13 --> Config Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Hooks Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Utf8 Class Initialized
DEBUG - 2011-09-11 23:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 23:52:13 --> URI Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Router Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Output Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Input Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 23:52:13 --> Language Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Loader Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Controller Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Model Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Model Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Model Class Initialized
DEBUG - 2011-09-11 23:52:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 23:52:13 --> Database Driver Class Initialized
DEBUG - 2011-09-11 23:52:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 23:52:13 --> Helper loaded: url_helper
DEBUG - 2011-09-11 23:52:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 23:52:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 23:52:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 23:52:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 23:52:13 --> Final output sent to browser
DEBUG - 2011-09-11 23:52:13 --> Total execution time: 0.0437
DEBUG - 2011-09-11 23:57:30 --> Config Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Hooks Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Utf8 Class Initialized
DEBUG - 2011-09-11 23:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-11 23:57:30 --> URI Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Router Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Output Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Input Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-11 23:57:30 --> Language Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Loader Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Controller Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Model Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Model Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Model Class Initialized
DEBUG - 2011-09-11 23:57:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-11 23:57:30 --> Database Driver Class Initialized
DEBUG - 2011-09-11 23:57:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-11 23:57:30 --> Helper loaded: url_helper
DEBUG - 2011-09-11 23:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-11 23:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-11 23:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-11 23:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-11 23:57:30 --> Final output sent to browser
DEBUG - 2011-09-11 23:57:30 --> Total execution time: 0.0512
